# host04 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host04 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 301 (SEVERE: 19, FATAL: 135, WARN: 147, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 135 | 147 | 301 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→15→…→12→13→12→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 21:35:00 (UTC)
* 現象   : 2026-06-08 21:35:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.726, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.517, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-004 active_connections の推移](charts/EVT-20260608-host04-004.svg)

# イベントID( EVT-20260608-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→13→16→17→…→15→13→11→13
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 20:40:00 (UTC)
* 現象   : 2026-06-08 20:40:00 (UTC)を境に水準が 11.9から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-005 active_connections の推移](charts/EVT-20260608-host04-005.svg)

# イベントID( EVT-20260608-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→15→…→17→15→16→15
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.298, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.317, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-006 active_connections の推移](charts/EVT-20260608-host04-006.svg)

# イベントID( EVT-20260608-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→16→15→16→…→13→14→13→15
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 21:40:00 (UTC)
* 現象   : 2026-06-08 21:40:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.92, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-007 active_connections の推移](charts/EVT-20260608-host04-007.svg)

# イベントID( EVT-20260608-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→14→…→13→16→13→14
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.99から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.633, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-008 active_connections の推移](charts/EVT-20260608-host04-008.svg)

# イベントID( EVT-20260608-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→16→18→16→…→13→15→13→14
* 開始   : 2026-06-08 04:15:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.99から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.322, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.449, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-009 active_connections の推移](charts/EVT-20260608-host04-009.svg)

# イベントID( EVT-20260615-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→17→18→19→…→15→16→12→14
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 21:40:00 (UTC)
* 現象   : 2026-06-15 21:40:00 (UTC)を境に水準が 11.84から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.229, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-001 active_connections の推移](charts/EVT-20260615-host04-001.svg)

# イベントID( EVT-20260615-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→…→15→13→14→13
* 開始   : 2026-06-15 03:25:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 12.03から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.122, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-002 active_connections の推移](charts/EVT-20260615-host04-002.svg)

# イベントID( EVT-20260615-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→14→…→15→14→15→14
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 21:45:00 (UTC)
* 現象   : 2026-06-15 21:45:00 (UTC)を境に水準が 11.78から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.875, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.655, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-004 active_connections の推移](charts/EVT-20260615-host04-004.svg)

# イベントID( EVT-20260615-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→14→18→14→…→11→13→12→10
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 20:15:00 (UTC)
* 現象   : 2026-06-15 20:15:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-005 active_connections の推移](charts/EVT-20260615-host04-005.svg)

# イベントID( EVT-20260615-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→14→16→14→…→14→11→14→11
* 開始   : 2026-06-15 04:00:00 (UTC)
* 終了   : 2026-06-15 19:30:00 (UTC)
* 現象   : 2026-06-15 19:30:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.039, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-006 active_connections の推移](charts/EVT-20260615-host04-006.svg)

# イベントID( EVT-20260620-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→9→12→9→…→14→10→14→12
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.688)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.037σ 外れた (平常値=13.15)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host04-001 active_connections の推移](charts/EVT-20260620-host04-001.svg)

# イベントID( EVT-20260621-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→10→8→9→11→11→10→12
* 開始   : 2026-06-21 18:40:00 (UTC)
* 終了   : 2026-06-21 21:55:00 (UTC)
* 現象   : 2026-06-21 21:55:00 (UTC)を境に水準が 11.8から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host04-003 active_connections の推移](charts/EVT-20260621-host04-003.svg)

# イベントID( EVT-20260622-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→17→18→16→…→15→14→15→14
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.603, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.969, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-001 active_connections の推移](charts/EVT-20260622-host04-001.svg)

# イベントID( EVT-20260622-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→13→…→16→15→16→15
* 開始   : 2026-06-22 02:15:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.75から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.013, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-002 active_connections の推移](charts/EVT-20260622-host04-002.svg)

# イベントID( EVT-20260622-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→13→…→15→11→13→11
* 開始   : 2026-06-22 03:00:00 (UTC)
* 終了   : 2026-06-22 21:30:00 (UTC)
* 現象   : 2026-06-22 21:30:00 (UTC)を境に水準が 11.79から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.807, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-004 active_connections の推移](charts/EVT-20260622-host04-004.svg)

# イベントID( EVT-20260629-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→14→…→13→12→13→12
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.745, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-003 active_connections の推移](charts/EVT-20260629-host04-003.svg)

# イベントID( EVT-20260629-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→17→…→12→15→12→14
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.83から15.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.594σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.81, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.311, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-006 active_connections の推移](charts/EVT-20260629-host04-006.svg)

# イベントID( EVT-20260629-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→14→…→13→14→13→12
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.77から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.731, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.143, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-007 active_connections の推移](charts/EVT-20260629-host04-007.svg)

# イベントID( EVT-20260601-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→11→17→15→12
* 開始   : 2026-06-01 05:30:00 (UTC)
* 終了   : 2026-06-01 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host04-001 active_connections の推移](charts/EVT-20260601-host04-001.svg)

# イベントID( EVT-20260601-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→16→19→16→16
* 開始   : 2026-06-01 06:30:00 (UTC)
* 終了   : 2026-06-01 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host04-002 active_connections の推移](charts/EVT-20260601-host04-002.svg)

# イベントID( EVT-20260601-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→22→26→22→23
* 開始   : 2026-06-01 13:45:00 (UTC)
* 終了   : 2026-06-01 13:45:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→17→18
* 開始   : 2026-06-01 17:05:00 (UTC)
* 終了   : 2026-06-01 17:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-005 active_connections の推移](charts/EVT-20260601-host04-005.svg)

# イベントID( EVT-20260602-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 7→8→5→3→…→5→3→9→6
* 開始   : 2026-06-02 00:00:00 (UTC)
* 終了   : 2026-06-02 00:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host04-001 active_connections の推移](charts/EVT-20260602-host04-001.svg)

# イベントID( EVT-20260602-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 7→8→12→5→…→12→5→6→8
* 開始   : 2026-06-02 00:55:00 (UTC)
* 終了   : 2026-06-02 01:00:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host04-002 active_connections の推移](charts/EVT-20260602-host04-002.svg)

# イベントID( EVT-20260602-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 6→9→13→7→7
* 開始   : 2026-06-02 01:35:00 (UTC)
* 終了   : 2026-06-02 01:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host04-003 active_connections の推移](charts/EVT-20260602-host04-003.svg)

# イベントID( EVT-20260602-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→13→15→13→12
* 開始   : 2026-06-02 04:15:00 (UTC)
* 終了   : 2026-06-02 04:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host04-005 active_connections の推移](charts/EVT-20260602-host04-005.svg)

# イベントID( EVT-20260602-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→16→16
* 開始   : 2026-06-02 06:00:00 (UTC)
* 終了   : 2026-06-02 06:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host04-006 active_connections の推移](charts/EVT-20260602-host04-006.svg)

# イベントID( EVT-20260602-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→14→17
* 開始   : 2026-06-02 06:25:00 (UTC)
* 終了   : 2026-06-02 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host04-007 active_connections の推移](charts/EVT-20260602-host04-007.svg)

# イベントID( EVT-20260602-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→21→26→24→21
* 開始   : 2026-06-02 10:55:00 (UTC)
* 終了   : 2026-06-02 10:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host04-011 active_connections の推移](charts/EVT-20260602-host04-011.svg)

# イベントID( EVT-20260602-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 22→23→17→22→21
* 開始   : 2026-06-02 14:05:00 (UTC)
* 終了   : 2026-06-02 14:05:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260602-host04-012 active_connections の推移](charts/EVT-20260602-host04-012.svg)

# イベントID( EVT-20260602-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→18→14→18→19
* 開始   : 2026-06-02 16:40:00 (UTC)
* 終了   : 2026-06-02 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host04-013 active_connections の推移](charts/EVT-20260602-host04-013.svg)

# イベントID( EVT-20260602-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→14→9→13→12
* 開始   : 2026-06-02 19:25:00 (UTC)
* 終了   : 2026-06-02 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260602-host04-014 active_connections の推移](charts/EVT-20260602-host04-014.svg)

# イベントID( EVT-20260602-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→9→13→9→…→13→8→12→11
* 開始   : 2026-06-02 20:00:00 (UTC)
* 終了   : 2026-06-02 21:25:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260602-host04-016 active_connections の推移](charts/EVT-20260602-host04-016.svg)

# イベントID( EVT-20260602-host04-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→9→10
* 開始   : 2026-06-02 21:35:00 (UTC)
* 終了   : 2026-06-02 21:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host04-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→12→13
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host04-004 active_connections の推移](charts/EVT-20260603-host04-004.svg)

# イベントID( EVT-20260603-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→17→…→17→13→15→14
* 開始   : 2026-06-03 16:45:00 (UTC)
* 終了   : 2026-06-03 17:30:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 30 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260603-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260603-host04-009 active_connections の推移](charts/EVT-20260603-host04-009.svg)

# イベントID( EVT-20260603-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→10→6→10→8
* 開始   : 2026-06-03 21:10:00 (UTC)
* 終了   : 2026-06-03 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.055σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host04-012 active_connections の推移](charts/EVT-20260603-host04-012.svg)

# イベントID( EVT-20260603-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→11→…→11→5→12→8
* 開始   : 2026-06-03 21:25:00 (UTC)
* 終了   : 2026-06-03 21:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260603-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host04-013 active_connections の推移](charts/EVT-20260603-host04-013.svg)

# イベントID( EVT-20260604-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→20→24→20→20
* 開始   : 2026-06-04 09:30:00 (UTC)
* 終了   : 2026-06-04 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-006 active_connections の推移](charts/EVT-20260604-host04-006.svg)

# イベントID( EVT-20260604-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→20→16→17→16→17→16→17
* 開始   : 2026-06-04 15:50:00 (UTC)
* 終了   : 2026-06-04 16:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260604-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-007 active_connections の推移](charts/EVT-20260604-host04-007.svg)

# イベントID( EVT-20260604-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→18→17→17→16→17
* 開始   : 2026-06-04 17:20:00 (UTC)
* 終了   : 2026-06-04 18:10:00 (UTC)
* 現象   : 2026-06-04 18:10:00 (UTC)を境に水準が 14.88から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.652σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→13→10→8→8→12→12→12→11
* 開始   : 2026-06-05 02:00:00 (UTC)
* 終了   : 2026-06-05 02:55:00 (UTC)
* 現象   : 2026-06-05 02:55:00 (UTC)を境に水準が 14.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.483, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host04-001 active_connections の推移](charts/EVT-20260605-host04-001.svg)

# イベントID( EVT-20260605-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→16→17
* 開始   : 2026-06-05 07:25:00 (UTC)
* 終了   : 2026-06-05 07:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host04-003 active_connections の推移](charts/EVT-20260605-host04-003.svg)

# イベントID( EVT-20260605-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→17→13→16→17
* 開始   : 2026-06-05 17:05:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host04-006 active_connections の推移](charts/EVT-20260605-host04-006.svg)

# イベントID( EVT-20260606-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→13→…→12→13→14→12
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.804, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host04-002 active_connections の推移](charts/EVT-20260606-host04-002.svg)

# イベントID( EVT-20260606-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→12→…→12→14→16→13
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.715, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host04-003 active_connections の推移](charts/EVT-20260606-host04-003.svg)

# イベントID( EVT-20260606-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→13→…→13→12→14→11
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host04-004 active_connections の推移](charts/EVT-20260606-host04-004.svg)

# イベントID( EVT-20260606-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→12→…→11→10→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.951, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host04-005 active_connections の推移](charts/EVT-20260606-host04-005.svg)

# イベントID( EVT-20260606-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→13→12→13→…→11→13→11→10
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.877, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host04-006 active_connections の推移](charts/EVT-20260606-host04-006.svg)

# イベントID( EVT-20260606-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→10→…→12→13→12→11
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.35, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host04-007 active_connections の推移](charts/EVT-20260606-host04-007.svg)

# イベントID( EVT-20260606-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→7→12→11→…→11→3→10→7
* 開始   : 2026-06-06 21:00:00 (UTC)
* 終了   : 2026-06-06 21:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260606-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260606-host04-008 active_connections の推移](charts/EVT-20260606-host04-008.svg)

# イベントID( EVT-20260606-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→10
* 開始   : 2026-06-06 23:55:00 (UTC)
* 終了   : 2026-06-07 00:00:00 (UTC)
* 現象   : 2026-06-07 00:00:00 (UTC)を境に水準が 11.76から11.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.015σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260606-host04-009 active_connections の推移](charts/EVT-20260606-host04-009.svg)

# イベントID( EVT-20260607-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→9→15→13→11
* 開始   : 2026-06-07 05:20:00 (UTC)
* 終了   : 2026-06-07 05:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→11→8→12→…→12→7→12→11
* 開始   : 2026-06-07 18:25:00 (UTC)
* 終了   : 2026-06-07 18:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host04-006 active_connections の推移](charts/EVT-20260607-host04-006.svg)

# イベントID( EVT-20260607-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 6→9→4→9→8
* 開始   : 2026-06-07 22:30:00 (UTC)
* 終了   : 2026-06-07 22:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host04-008 active_connections の推移](charts/EVT-20260607-host04-008.svg)

# イベントID( EVT-20260608-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→9→9
* 開始   : 2026-06-08 01:30:00 (UTC)
* 終了   : 2026-06-08 01:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→13→18→16→13
* 開始   : 2026-06-09 05:40:00 (UTC)
* 終了   : 2026-06-09 05:40:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-003 active_connections の推移](charts/EVT-20260609-host04-003.svg)

# イベントID( EVT-20260609-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→22→18→22→20
* 開始   : 2026-06-09 11:40:00 (UTC)
* 終了   : 2026-06-09 11:40:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→18→14→15→16→18→14→15→16
* 開始   : 2026-06-09 17:05:00 (UTC)
* 終了   : 2026-06-09 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host04-009 active_connections の推移](charts/EVT-20260609-host04-009.svg)

# イベントID( EVT-20260609-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→9→4→8→7
* 開始   : 2026-06-09 22:50:00 (UTC)
* 終了   : 2026-06-09 22:50:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.609σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-012 active_connections の推移](charts/EVT-20260609-host04-012.svg)

# イベントID( EVT-20260610-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→16→13→12
* 開始   : 2026-06-10 04:10:00 (UTC)
* 終了   : 2026-06-10 04:10:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host04-001 active_connections の推移](charts/EVT-20260610-host04-001.svg)

# イベントID( EVT-20260610-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→17→20→17→17
* 開始   : 2026-06-10 07:15:00 (UTC)
* 終了   : 2026-06-10 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host04-005 active_connections の推移](charts/EVT-20260610-host04-005.svg)

# イベントID( EVT-20260610-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 20→21→25→22→20
* 開始   : 2026-06-10 10:05:00 (UTC)
* 終了   : 2026-06-10 10:05:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→20→16→19→20
* 開始   : 2026-06-10 15:15:00 (UTC)
* 終了   : 2026-06-10 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→13→18→15→13→18→15→16→17
* 開始   : 2026-06-10 17:00:00 (UTC)
* 終了   : 2026-06-10 17:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.6996(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.89σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host04-010 active_connections の推移](charts/EVT-20260610-host04-010.svg)

# イベントID( EVT-20260610-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→14→12→14→16
* 開始   : 2026-06-10 17:50:00 (UTC)
* 終了   : 2026-06-10 17:50:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-011 active_connections の推移](charts/EVT-20260610-host04-011.svg)

# イベントID( EVT-20260610-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→13→13
* 開始   : 2026-06-10 18:50:00 (UTC)
* 終了   : 2026-06-10 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host04-012 active_connections の推移](charts/EVT-20260610-host04-012.svg)

# イベントID( EVT-20260611-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→16→18→20→…→18→20→17→18
* 開始   : 2026-06-11 07:00:00 (UTC)
* 終了   : 2026-06-11 07:40:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260611-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host04-001 active_connections の推移](charts/EVT-20260611-host04-001.svg)

# イベントID( EVT-20260611-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→19→21→16→17→19→21→16
* 開始   : 2026-06-11 07:10:00 (UTC)
* 終了   : 2026-06-11 07:15:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host04-002 active_connections の推移](charts/EVT-20260611-host04-002.svg)

# イベントID( EVT-20260611-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→19→16→19→20
* 開始   : 2026-06-11 09:35:00 (UTC)
* 終了   : 2026-06-11 09:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host04-004 active_connections の推移](charts/EVT-20260611-host04-004.svg)

# イベントID( EVT-20260611-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→16→13→18→18
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host04-007 active_connections の推移](charts/EVT-20260611-host04-007.svg)

# イベントID( EVT-20260612-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→13→17→18→…→15→18→14→16
* 開始   : 2026-06-12 05:50:00 (UTC)
* 終了   : 2026-06-12 06:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260612-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host04-004 active_connections の推移](charts/EVT-20260612-host04-004.svg)

# イベントID( EVT-20260612-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→19→22→20→19
* 開始   : 2026-06-12 08:20:00 (UTC)
* 終了   : 2026-06-12 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-006 active_connections の推移](charts/EVT-20260612-host04-006.svg)

# イベントID( EVT-20260612-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 24→22→23→23→21
* 開始   : 2026-06-12 09:15:00 (UTC)
* 終了   : 2026-06-12 09:35:00 (UTC)
* 現象   : 2026-06-12 09:35:00 (UTC)を境に水準が 15.04から14.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.228σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host04-007 active_connections の推移](charts/EVT-20260612-host04-007.svg)

# イベントID( EVT-20260612-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→21→16→22→21
* 開始   : 2026-06-12 10:40:00 (UTC)
* 終了   : 2026-06-12 10:40:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host04-008 active_connections の推移](charts/EVT-20260612-host04-008.svg)

# イベントID( EVT-20260612-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→21→26→21→21
* 開始   : 2026-06-12 12:20:00 (UTC)
* 終了   : 2026-06-12 12:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-010 active_connections の推移](charts/EVT-20260612-host04-010.svg)

# イベントID( EVT-20260612-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→13→8→9→…→8→9→12→10
* 開始   : 2026-06-12 20:15:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host02-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-073 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host04-011 active_connections の推移](charts/EVT-20260612-host04-011.svg)

# イベントID( EVT-20260612-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→7→9→10
* 開始   : 2026-06-12 20:50:00 (UTC)
* 終了   : 2026-06-12 20:50:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-012 active_connections の推移](charts/EVT-20260612-host04-012.svg)

# イベントID( EVT-20260613-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→12→14→10→9
* 開始   : 2026-06-13 03:50:00 (UTC)
* 終了   : 2026-06-13 03:50:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host04-002 active_connections の推移](charts/EVT-20260613-host04-002.svg)

# イベントID( EVT-20260613-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→11→9→10→11
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.07, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 14.5 時間
  - EVT-20260613-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間

![EVT-20260613-host04-004 active_connections の推移](charts/EVT-20260613-host04-004.svg)

# イベントID( EVT-20260613-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→9→11→9→…→9→10→11→10
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host04-005 active_connections の推移](charts/EVT-20260613-host04-005.svg)

# イベントID( EVT-20260613-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→11→…→12→11→12→11
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.501, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host04-006 active_connections の推移](charts/EVT-20260613-host04-006.svg)

# イベントID( EVT-20260613-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→13→14→13→…→15→12→14→12
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.709, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260613-host04-007 active_connections の推移](charts/EVT-20260613-host04-007.svg)

# イベントID( EVT-20260613-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→9→11→13→…→13→11→13→12
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 20:10:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.255, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host04-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.1 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host04-008 active_connections の推移](charts/EVT-20260613-host04-008.svg)

# イベントID( EVT-20260613-host04-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→10→…→10→14→11→9
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 20:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.024, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host04-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260613-host04-009 active_connections の推移](charts/EVT-20260613-host04-009.svg)

# イベントID( EVT-20260614-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→14→11→13→16
* 開始   : 2026-06-14 11:10:00 (UTC)
* 終了   : 2026-06-14 11:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host04-003 active_connections の推移](charts/EVT-20260614-host04-003.svg)

# イベントID( EVT-20260614-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→16→11→15→16
* 開始   : 2026-06-14 12:55:00 (UTC)
* 終了   : 2026-06-14 12:55:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host04-004 active_connections の推移](charts/EVT-20260614-host04-004.svg)

# イベントID( EVT-20260615-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→17→14→17→…→14→12→11→14
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.8から15.16へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.781, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-003 active_connections の推移](charts/EVT-20260615-host04-003.svg)

# イベントID( EVT-20260616-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→17→…→17→19→16→18
* 開始   : 2026-06-16 06:25:00 (UTC)
* 終了   : 2026-06-16 06:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host04-002 active_connections の推移](charts/EVT-20260616-host04-002.svg)

# イベントID( EVT-20260616-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→14→14
* 開始   : 2026-06-16 18:55:00 (UTC)
* 終了   : 2026-06-16 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host04-006 active_connections の推移](charts/EVT-20260616-host04-006.svg)

# イベントID( EVT-20260617-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→14→17
* 開始   : 2026-06-17 06:20:00 (UTC)
* 終了   : 2026-06-17 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.371倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.773σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host04-005 active_connections の推移](charts/EVT-20260617-host04-005.svg)

# イベントID( EVT-20260617-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→16→19
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 08:45:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host02-009 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260617-host04-007 active_connections の推移](charts/EVT-20260617-host04-007.svg)

# イベントID( EVT-20260617-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→13→8→14→13
* 開始   : 2026-06-17 19:25:00 (UTC)
* 終了   : 2026-06-17 19:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.715σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-010 active_connections の推移](charts/EVT-20260617-host04-010.svg)

# イベントID( EVT-20260618-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→8→13→9→9
* 開始   : 2026-06-18 02:30:00 (UTC)
* 終了   : 2026-06-18 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host04-001 active_connections の推移](charts/EVT-20260618-host04-001.svg)

# イベントID( EVT-20260618-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→18→23→19→20
* 開始   : 2026-06-18 08:50:00 (UTC)
* 終了   : 2026-06-18 08:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-003 active_connections の推移](charts/EVT-20260618-host04-003.svg)

# イベントID( EVT-20260618-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→17→15→17→18
* 開始   : 2026-06-18 16:25:00 (UTC)
* 終了   : 2026-06-18 16:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-004 active_connections の推移](charts/EVT-20260618-host04-004.svg)

# イベントID( EVT-20260618-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→16→11→13→16→11→15
* 開始   : 2026-06-18 17:55:00 (UTC)
* 終了   : 2026-06-18 18:05:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host04-005 active_connections の推移](charts/EVT-20260618-host04-005.svg)

# イベントID( EVT-20260618-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→19→12→15→14
* 開始   : 2026-06-18 17:55:00 (UTC)
* 終了   : 2026-06-18 18:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.7024(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260618-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-006 active_connections の推移](charts/EVT-20260618-host04-006.svg)

# イベントID( EVT-20260618-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→12→12
* 開始   : 2026-06-18 19:30:00 (UTC)
* 終了   : 2026-06-18 19:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host04-007 active_connections の推移](charts/EVT-20260618-host04-007.svg)

# イベントID( EVT-20260619-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→7→3→8→8
* 開始   : 2026-06-19 01:10:00 (UTC)
* 終了   : 2026-06-19 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 0.4(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→9→14→10→10
* 開始   : 2026-06-19 03:00:00 (UTC)
* 終了   : 2026-06-19 03:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.57倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-003 active_connections の推移](charts/EVT-20260619-host04-003.svg)

# イベントID( EVT-20260619-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→12→12
* 開始   : 2026-06-19 03:15:00 (UTC)
* 終了   : 2026-06-19 03:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-004 active_connections の推移](charts/EVT-20260619-host04-004.svg)

# イベントID( EVT-20260619-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 22→21→22→24→20→20→22→21→19
* 開始   : 2026-06-19 13:35:00 (UTC)
* 終了   : 2026-06-19 14:55:00 (UTC)
* 現象   : 2026-06-19 14:55:00 (UTC)を境に水準が 14.94から12.72へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.137σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.779, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host04-010 active_connections の推移](charts/EVT-20260619-host04-010.svg)

# イベントID( EVT-20260619-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→15→15→15→14→15→14→13→15
* 開始   : 2026-06-19 16:50:00 (UTC)
* 終了   : 2026-06-19 19:10:00 (UTC)
* 現象   : 2026-06-19 19:10:00 (UTC)を境に水準が 14.9から12.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→14→13
* 開始   : 2026-06-19 19:05:00 (UTC)
* 終了   : 2026-06-19 19:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-012 active_connections の推移](charts/EVT-20260619-host04-012.svg)

# イベントID( EVT-20260619-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→8→9
* 開始   : 2026-06-19 21:25:00 (UTC)
* 終了   : 2026-06-19 21:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-015 active_connections の推移](charts/EVT-20260619-host04-015.svg)

# イベントID( EVT-20260619-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→9→6→8→8
* 開始   : 2026-06-19 22:00:00 (UTC)
* 終了   : 2026-06-19 22:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-016 active_connections の推移](charts/EVT-20260619-host04-016.svg)

# イベントID( EVT-20260620-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→10→12→10→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260620-host04-002 active_connections の推移](charts/EVT-20260620-host04-002.svg)

# イベントID( EVT-20260620-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→12→…→9→11→12→10
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host04-003 active_connections の推移](charts/EVT-20260620-host04-003.svg)

# イベントID( EVT-20260620-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→12→…→12→9→12→11
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.743, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host04-004 active_connections の推移](charts/EVT-20260620-host04-004.svg)

# イベントID( EVT-20260620-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→10→…→12→11→10→12
* 開始   : 2026-06-20 06:05:00 (UTC)
* 終了   : 2026-06-20 18:20:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.817, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260620-host04-005 active_connections の推移](charts/EVT-20260620-host04-005.svg)

# イベントID( EVT-20260620-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→12→11→13→…→12→10→12→11
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.896, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host04-006 active_connections の推移](charts/EVT-20260620-host04-006.svg)

# イベントID( EVT-20260620-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 7→9→4→8→7
* 開始   : 2026-06-20 22:25:00 (UTC)
* 終了   : 2026-06-20 22:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.4248(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.774σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host04-009 active_connections の推移](charts/EVT-20260620-host04-009.svg)

# イベントID( EVT-20260621-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→11→10→9→…→10→9→12→15
* 開始   : 2026-06-21 18:05:00 (UTC)
* 終了   : 2026-06-21 19:05:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260621-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260621-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260621-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260621-host04-002 active_connections の推移](charts/EVT-20260621-host04-002.svg)

# イベントID( EVT-20260622-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→16→…→14→13→12→13
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 21:05:00 (UTC)
* 現象   : 2026-06-22 21:05:00 (UTC)を境に水準が 11.94から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.154, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-003 active_connections の推移](charts/EVT-20260622-host04-003.svg)

# イベントID( EVT-20260622-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→14→…→17→14→15→16
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.915, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-005 active_connections の推移](charts/EVT-20260622-host04-005.svg)

# イベントID( EVT-20260622-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→14→15→…→16→13→12→14
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 19:50:00 (UTC)
* 現象   : 2026-06-22 19:50:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.356, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-006 active_connections の推移](charts/EVT-20260622-host04-006.svg)

# イベントID( EVT-20260622-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 7→10→4→7→9
* 開始   : 2026-06-22 22:45:00 (UTC)
* 終了   : 2026-06-22 22:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→13→16→11→12
* 開始   : 2026-06-23 04:25:00 (UTC)
* 終了   : 2026-06-23 04:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host04-001 active_connections の推移](charts/EVT-20260623-host04-001.svg)

# イベントID( EVT-20260623-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→20→18→16→20→17→15
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host04-004 active_connections の推移](charts/EVT-20260623-host04-004.svg)

# イベントID( EVT-20260624-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→10→13→8→7
* 開始   : 2026-06-24 02:20:00 (UTC)
* 終了   : 2026-06-24 02:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-002 active_connections の推移](charts/EVT-20260624-host04-002.svg)

# イベントID( EVT-20260624-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→14→16
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-005 active_connections の推移](charts/EVT-20260624-host04-005.svg)

# イベントID( EVT-20260624-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→13→14
* 開始   : 2026-06-24 05:55:00 (UTC)
* 終了   : 2026-06-24 05:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-007 active_connections の推移](charts/EVT-20260624-host04-007.svg)

# イベントID( EVT-20260624-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→13→10→13→13
* 開始   : 2026-06-24 19:10:00 (UTC)
* 終了   : 2026-06-24 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host04-010 active_connections の推移](charts/EVT-20260624-host04-010.svg)

# イベントID( EVT-20260625-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→10→12→13→12→13→11→12
* 開始   : 2026-06-25 03:15:00 (UTC)
* 終了   : 2026-06-25 03:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分
  - EVT-20260625-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-001 active_connections の推移](charts/EVT-20260625-host04-001.svg)

# イベントID( EVT-20260625-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→15→12→10
* 開始   : 2026-06-25 04:05:00 (UTC)
* 終了   : 2026-06-25 04:05:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-002 active_connections の推移](charts/EVT-20260625-host04-002.svg)

# イベントID( EVT-20260625-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→15→19→16→18
* 開始   : 2026-06-25 06:40:00 (UTC)
* 終了   : 2026-06-25 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-005 active_connections の推移](charts/EVT-20260625-host04-005.svg)

# イベントID( EVT-20260625-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→21→21
* 開始   : 2026-06-25 15:05:00 (UTC)
* 終了   : 2026-06-25 15:05:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host04-007 active_connections の推移](charts/EVT-20260625-host04-007.svg)

# イベントID( EVT-20260625-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→…→10→9→10→9
* 開始   : 2026-06-25 19:50:00 (UTC)
* 終了   : 2026-06-25 20:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-010 active_connections の推移](charts/EVT-20260625-host04-010.svg)

# イベントID( EVT-20260625-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→5→8→8
* 開始   : 2026-06-25 21:45:00 (UTC)
* 終了   : 2026-06-25 21:45:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.4878(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-011 active_connections の推移](charts/EVT-20260625-host04-011.svg)

# イベントID( EVT-20260625-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→8→4→7→7
* 開始   : 2026-06-25 23:15:00 (UTC)
* 終了   : 2026-06-25 23:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→11→11
* 開始   : 2026-06-26 04:20:00 (UTC)
* 終了   : 2026-06-26 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host04-001 active_connections の推移](charts/EVT-20260626-host04-001.svg)

# イベントID( EVT-20260626-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→19→15→21→20
* 開始   : 2026-06-26 15:45:00 (UTC)
* 終了   : 2026-06-26 15:45:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260626-host04-007 active_connections の推移](charts/EVT-20260626-host04-007.svg)

# イベントID( EVT-20260626-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→17→11→15→15
* 開始   : 2026-06-26 18:20:00 (UTC)
* 終了   : 2026-06-26 18:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.6769(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host04-009 active_connections の推移](charts/EVT-20260626-host04-009.svg)

# イベントID( EVT-20260627-host04-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→13→…→10→11→12→11
* 開始   : 2026-06-27 04:25:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 15.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.715, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260627-host04-001 active_connections の推移](charts/EVT-20260627-host04-001.svg)

# イベントID( EVT-20260627-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→10→…→9→10→11→9
* 開始   : 2026-06-27 05:05:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.4 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host04-002 active_connections の推移](charts/EVT-20260627-host04-002.svg)

# イベントID( EVT-20260627-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→7→12→11→…→10→9→12→9
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.579, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host04-003 active_connections の推移](charts/EVT-20260627-host04-003.svg)

# イベントID( EVT-20260627-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→10→…→16→11→12→11
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 18:10:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.722, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.6 時間

![EVT-20260627-host04-004 active_connections の推移](charts/EVT-20260627-host04-004.svg)

# イベントID( EVT-20260627-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→12→…→13→10→13→12
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:20:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.7 時間

![EVT-20260627-host04-005 active_connections の推移](charts/EVT-20260627-host04-005.svg)

# イベントID( EVT-20260627-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→14→…→11→10→12→11
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.672, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host04-006 active_connections の推移](charts/EVT-20260627-host04-006.svg)

# イベントID( EVT-20260628-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→15→17→13→13
* 開始   : 2026-06-28 07:45:00 (UTC)
* 終了   : 2026-06-28 07:45:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host04-002 active_connections の推移](charts/EVT-20260628-host04-002.svg)

# イベントID( EVT-20260628-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→13→19→15→15
* 開始   : 2026-06-28 09:35:00 (UTC)
* 終了   : 2026-06-28 09:35:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host04-003 active_connections の推移](charts/EVT-20260628-host04-003.svg)

# イベントID( EVT-20260628-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→13→13
* 開始   : 2026-06-28 18:00:00 (UTC)
* 終了   : 2026-06-28 18:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host04-006 active_connections の推移](charts/EVT-20260628-host04-006.svg)

# イベントID( EVT-20260628-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→9→5→8→8
* 開始   : 2026-06-28 22:05:00 (UTC)
* 終了   : 2026-06-28 22:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→9→8
* 開始   : 2026-06-29 01:05:00 (UTC)
* 終了   : 2026-06-29 01:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260629-host04-001 active_connections の推移](charts/EVT-20260629-host04-001.svg)

# イベントID( EVT-20260629-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→16→…→17→16→12→15
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.725, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-004 active_connections の推移](charts/EVT-20260629-host04-004.svg)

# イベントID( EVT-20260629-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→15→…→12→15→12→13
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.81から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.982, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-005 active_connections の推移](charts/EVT-20260629-host04-005.svg)

# イベントID( EVT-20260629-host04-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→15→…→13→12→13→11
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 19:20:00 (UTC)
* 現象   : 2026-06-29 19:20:00 (UTC)を境に水準が 12から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.487, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-008 active_connections の推移](charts/EVT-20260629-host04-008.svg)

# イベントID( EVT-20260629-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 8→11→6→9→11
* 開始   : 2026-06-29 21:15:00 (UTC)
* 終了   : 2026-06-29 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→10→10
* 開始   : 2026-06-30 03:45:00 (UTC)
* 終了   : 2026-06-30 03:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host04-004 active_connections の推移](charts/EVT-20260630-host04-004.svg)

# イベントID( EVT-20260630-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→20→20
* 開始   : 2026-06-30 10:00:00 (UTC)
* 終了   : 2026-06-30 10:00:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host04-010 active_connections の推移](charts/EVT-20260630-host04-010.svg)

# イベントID( EVT-20260630-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→26→22→25→26→22→25→21
* 開始   : 2026-06-30 11:00:00 (UTC)
* 終了   : 2026-06-30 11:10:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-011 active_connections の推移](charts/EVT-20260630-host04-011.svg)

# イベントID( EVT-20260630-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→14→9→14→13
* 開始   : 2026-06-30 19:10:00 (UTC)
* 終了   : 2026-06-30 19:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-014 active_connections の推移](charts/EVT-20260630-host04-014.svg)

# イベントID( EVT-20260601-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→18→19→16→18→19→16→18
* 開始   : 2026-06-01 06:55:00 (UTC)
* 終了   : 2026-06-01 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 18→14→18→14→18→14→15→14
* 開始   : 2026-06-01 17:30:00 (UTC)
* 終了   : 2026-06-01 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→10→13→11→10→13→11
* 開始   : 2026-06-01 19:30:00 (UTC)
* 終了   : 2026-06-01 19:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→7→12→11→13→12→11→13→11
* 開始   : 2026-06-02 02:55:00 (UTC)
* 終了   : 2026-06-02 03:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→18→19→15→…→15→20→17→16
* 開始   : 2026-06-02 07:10:00 (UTC)
* 終了   : 2026-06-02 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260602-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→19→20→21→…→17→21→19→18
* 開始   : 2026-06-02 07:45:00 (UTC)
* 終了   : 2026-06-02 08:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260602-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→21→17→18→21→17→18
* 開始   : 2026-06-02 08:10:00 (UTC)
* 終了   : 2026-06-02 08:15:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→15→10→12→15→10→12→11
* 開始   : 2026-06-02 19:35:00 (UTC)
* 終了   : 2026-06-02 19:40:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→10→9
* 開始   : 2026-06-02 22:45:00 (UTC)
* 終了   : 2026-06-03 00:05:00 (UTC)
* 現象   : 2026-06-03 00:05:00 (UTC)を境に水準が 14.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.133σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host04-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→9→11→8→…→8→12→9→8
* 開始   : 2026-06-03 01:35:00 (UTC)
* 終了   : 2026-06-03 01:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260603-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→12→10→12→10→8
* 開始   : 2026-06-03 02:25:00 (UTC)
* 終了   : 2026-06-03 02:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→9→11→12→12→10→13→10→12
* 開始   : 2026-06-03 02:30:00 (UTC)
* 終了   : 2026-06-03 03:15:00 (UTC)
* 現象   : 2026-06-03 03:15:00 (UTC)を境に水準が 14.96から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→17→18→17→19→18→17→19→17
* 開始   : 2026-06-03 06:25:00 (UTC)
* 終了   : 2026-06-03 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→19→22→21→21→22
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:45:00 (UTC)
* 現象   : 2026-06-03 08:45:00 (UTC)を境に水準が 15.08から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→20→24→18→20→24→18→20
* 開始   : 2026-06-03 14:40:00 (UTC)
* 終了   : 2026-06-03 14:45:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→19→16→19→16→17→19
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:35:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→13→12→14→…→14→11→14→12
* 開始   : 2026-06-03 18:50:00 (UTC)
* 終了   : 2026-06-03 19:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→11→15→12→9→15→12→9→10
* 開始   : 2026-06-03 20:35:00 (UTC)
* 終了   : 2026-06-03 20:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→11→7→12→11
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 03:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→12→14→11→14→11→14→11
* 開始   : 2026-06-04 04:00:00 (UTC)
* 終了   : 2026-06-04 04:10:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→17→16→15
* 開始   : 2026-06-04 05:45:00 (UTC)
* 終了   : 2026-06-04 05:50:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→20→16→19→20→16→19
* 開始   : 2026-06-04 07:15:00 (UTC)
* 終了   : 2026-06-04 07:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→18→…→20→21→19→20
* 開始   : 2026-06-04 08:05:00 (UTC)
* 終了   : 2026-06-04 08:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→13→14→17→13→16→15
* 開始   : 2026-06-04 17:15:00 (UTC)
* 終了   : 2026-06-04 17:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→11→12→14→11→14→13
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 19:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260604-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→10→11→10→11→10→11→12
* 開始   : 2026-06-04 19:30:00 (UTC)
* 終了   : 2026-06-04 19:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→9→12→10→10→9→11
* 開始   : 2026-06-04 21:10:00 (UTC)
* 終了   : 2026-06-04 22:15:00 (UTC)
* 現象   : 2026-06-04 22:15:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→16→13→16→15
* 開始   : 2026-06-05 05:10:00 (UTC)
* 終了   : 2026-06-05 05:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→23→17→20→…→20→24→19→20
* 開始   : 2026-06-05 09:40:00 (UTC)
* 終了   : 2026-06-05 09:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→16→15→16→15→16→19
* 開始   : 2026-06-05 16:50:00 (UTC)
* 終了   : 2026-06-05 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→16→15→13→16→15
* 開始   : 2026-06-05 18:05:00 (UTC)
* 終了   : 2026-06-05 18:10:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.363σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→11→10→14→11→10→14→12
* 開始   : 2026-06-05 19:05:00 (UTC)
* 終了   : 2026-06-05 19:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→15→11→…→11→9→10→12
* 開始   : 2026-06-05 20:00:00 (UTC)
* 終了   : 2026-06-05 20:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 7→9→11→5→…→11→5→10→7
* 開始   : 2026-06-06 00:55:00 (UTC)
* 終了   : 2026-06-06 01:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260606-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→13→11→13→11→13→9→8
* 開始   : 2026-06-07 03:15:00 (UTC)
* 終了   : 2026-06-07 03:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.909σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260607-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→14→…→14→16→13→15
* 開始   : 2026-06-07 07:35:00 (UTC)
* 終了   : 2026-06-07 07:45:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→15→17→15→17→15→17
* 開始   : 2026-06-07 10:50:00 (UTC)
* 終了   : 2026-06-07 11:20:00 (UTC)
* 現象   : 2026-06-07 11:20:00 (UTC)を境に水準が 11.87から13.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→10→13→10→13
* 開始   : 2026-06-07 17:15:00 (UTC)
* 終了   : 2026-06-07 17:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→8→10→13→9→8→10
* 開始   : 2026-06-07 19:30:00 (UTC)
* 終了   : 2026-06-07 19:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 6→8→11→8→11→8→11→8
* 開始   : 2026-06-08 01:15:00 (UTC)
* 終了   : 2026-06-08 01:25:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→10→7→8→10→9→11
* 開始   : 2026-06-08 01:20:00 (UTC)
* 終了   : 2026-06-08 02:40:00 (UTC)
* 現象   : 2026-06-08 02:40:00 (UTC)を境に水準が 11.85から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→8→10→6→8
* 開始   : 2026-06-08 23:05:00 (UTC)
* 終了   : 2026-06-08 23:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260608-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260608-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260608-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→9→6→9→9→8
* 開始   : 2026-06-09 00:45:00 (UTC)
* 終了   : 2026-06-09 01:10:00 (UTC)
* 現象   : 2026-06-09 01:10:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→13→8→11→…→11→15→14→11
* 開始   : 2026-06-09 04:15:00 (UTC)
* 終了   : 2026-06-09 04:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→14→18→14→18→15→18→15→17
* 開始   : 2026-06-09 06:10:00 (UTC)
* 終了   : 2026-06-09 06:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→16→15→18→16→15
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→23→19→23→19→21
* 開始   : 2026-06-09 08:50:00 (UTC)
* 終了   : 2026-06-09 08:55:00 (UTC)
* 現象   : 平常時(19)に対し 1.211倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→18→15→17→18→15→17→18
* 開始   : 2026-06-09 17:00:00 (UTC)
* 終了   : 2026-06-09 17:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260609-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→15→13→15→14
* 開始   : 2026-06-09 17:50:00 (UTC)
* 終了   : 2026-06-09 17:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→12→15→11→12→15→11→12
* 開始   : 2026-06-09 18:55:00 (UTC)
* 終了   : 2026-06-09 19:05:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→16→14→13→16→14
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→14→…→14→17→13→14
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 05:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.594σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→17→16→18→19→17
* 開始   : 2026-06-10 06:55:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→18→22→18→…→20→23→21→22
* 開始   : 2026-06-10 08:45:00 (UTC)
* 終了   : 2026-06-10 09:25:00 (UTC)
* 現象   : 2026-06-10 09:25:00 (UTC)を境に水準が 15.06から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→17→22→16→17→22→16→18→20
* 開始   : 2026-06-10 15:40:00 (UTC)
* 終了   : 2026-06-10 15:50:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→18→16→20→18→20
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 07:45:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→17→15→16→15→16→15→16→17
* 開始   : 2026-06-11 16:40:00 (UTC)
* 終了   : 2026-06-11 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→20→15→18→20→15→18→16
* 開始   : 2026-06-11 16:45:00 (UTC)
* 終了   : 2026-06-11 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→16→12→15→12→15→12→14→12
* 開始   : 2026-06-11 18:15:00 (UTC)
* 終了   : 2026-06-11 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260611-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→6→9→6→9
* 開始   : 2026-06-11 22:05:00 (UTC)
* 終了   : 2026-06-11 22:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→11→…→11→5→7→8
* 開始   : 2026-06-11 22:50:00 (UTC)
* 終了   : 2026-06-11 23:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260611-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→9→12→9→10→9→10
* 開始   : 2026-06-11 23:20:00 (UTC)
* 終了   : 2026-06-11 23:50:00 (UTC)
* 現象   : 2026-06-11 23:50:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 8→5→8→5→8→9
* 開始   : 2026-06-11 23:25:00 (UTC)
* 終了   : 2026-06-11 23:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260611-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→14→13→11→14→13→11
* 開始   : 2026-06-12 04:05:00 (UTC)
* 終了   : 2026-06-12 04:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→15→14→11→15→14→13
* 開始   : 2026-06-12 04:50:00 (UTC)
* 終了   : 2026-06-12 04:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→16→…→15→16→11→15
* 開始   : 2026-06-12 05:10:00 (UTC)
* 終了   : 2026-06-12 05:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→22→19→21→22→19→20
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:15:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 23→25→24→21→22→22→25→23→24
* 開始   : 2026-06-12 12:05:00 (UTC)
* 終了   : 2026-06-12 12:55:00 (UTC)
* 現象   : 2026-06-12 12:55:00 (UTC)を境に水準が 15.05から13.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.436, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 7→8→12→5→8→12→5→8
* 開始   : 2026-06-12 23:00:00 (UTC)
* 終了   : 2026-06-12 23:05:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.455倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 7→8→5→8→…→8→11→8→9
* 開始   : 2026-06-13 01:45:00 (UTC)
* 終了   : 2026-06-13 01:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→11→10→11→10→11→13
* 開始   : 2026-06-13 04:40:00 (UTC)
* 終了   : 2026-06-13 04:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.141, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260613-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→9→8→9→…→11→9→11→9
* 開始   : 2026-06-13 19:45:00 (UTC)
* 終了   : 2026-06-13 20:40:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.046, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260613-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 30 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 55 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260613-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分

![EVT-20260613-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→13→10→12→13→10
* 開始   : 2026-06-14 04:55:00 (UTC)
* 終了   : 2026-06-14 05:00:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260614-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→14→14→11→13→14→14
* 開始   : 2026-06-14 06:05:00 (UTC)
* 終了   : 2026-06-14 06:35:00 (UTC)
* 現象   : 2026-06-14 06:35:00 (UTC)を境に水準が 11.64から12.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.364σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.45, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→11→10→9→10→11
* 開始   : 2026-06-15 21:30:00 (UTC)
* 終了   : 2026-06-15 21:55:00 (UTC)
* 現象   : 2026-06-15 21:55:00 (UTC)を境に水準が 14.87から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→14→…→14→16→12→14
* 開始   : 2026-06-16 04:55:00 (UTC)
* 終了   : 2026-06-16 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→23→22→18→22→23→22
* 開始   : 2026-06-16 09:15:00 (UTC)
* 終了   : 2026-06-16 09:20:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→16→18→19→16→18
* 開始   : 2026-06-16 16:05:00 (UTC)
* 終了   : 2026-06-16 16:10:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→17→19→18→16
* 開始   : 2026-06-16 16:55:00 (UTC)
* 終了   : 2026-06-16 17:15:00 (UTC)
* 現象   : 2026-06-16 17:15:00 (UTC)を境に水準が 15.06から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→10→9→10→9→10→9
* 開始   : 2026-06-16 20:25:00 (UTC)
* 終了   : 2026-06-16 20:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→5→11→5→11→9
* 開始   : 2026-06-17 00:25:00 (UTC)
* 終了   : 2026-06-17 00:35:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→10→14→10→14→13
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→14→16→15→…→16→15→16→14
* 開始   : 2026-06-17 05:10:00 (UTC)
* 終了   : 2026-06-17 05:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.914σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→16→14→13→16→14→16
* 開始   : 2026-06-17 05:35:00 (UTC)
* 終了   : 2026-06-17 05:40:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→17→19→17→19→18→15
* 開始   : 2026-06-17 07:00:00 (UTC)
* 終了   : 2026-06-17 07:10:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→17→13→15→17→13→15→18
* 開始   : 2026-06-17 18:00:00 (UTC)
* 終了   : 2026-06-17 18:05:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→17→13→12→…→13→12→15→14
* 開始   : 2026-06-17 18:35:00 (UTC)
* 終了   : 2026-06-17 18:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260617-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→…→12→9→12→13
* 開始   : 2026-06-17 19:45:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→11→12→11
* 開始   : 2026-06-17 21:30:00 (UTC)
* 終了   : 2026-06-17 21:45:00 (UTC)
* 現象   : 2026-06-17 21:45:00 (UTC)を境に水準が 15.02から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.159, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→17→18→16→18→16→18→17
* 開始   : 2026-06-18 06:40:00 (UTC)
* 終了   : 2026-06-18 06:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→12→13→12→8→12→13→12→10
* 開始   : 2026-06-19 02:50:00 (UTC)
* 終了   : 2026-06-19 02:55:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→16→15→17→16→17
* 開始   : 2026-06-19 06:00:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260619-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→16→19→16→19→16→19
* 開始   : 2026-06-19 07:05:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260619-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→17→21→22→…→21→22→21→19
* 開始   : 2026-06-19 08:45:00 (UTC)
* 終了   : 2026-06-19 08:50:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→20→22→23→21→20→22→23→21
* 開始   : 2026-06-19 09:10:00 (UTC)
* 終了   : 2026-06-19 09:15:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260619-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→23→19→23→19→23→20→23
* 開始   : 2026-06-19 09:55:00 (UTC)
* 終了   : 2026-06-19 10:05:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→9→10→9→10→9→12→10
* 開始   : 2026-06-19 20:05:00 (UTC)
* 終了   : 2026-06-19 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→12→10→12→11
* 開始   : 2026-06-19 21:00:00 (UTC)
* 終了   : 2026-06-19 22:00:00 (UTC)
* 現象   : 2026-06-19 22:00:00 (UTC)を境に水準が 14.9から11.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→10→…→10→8→11→10
* 開始   : 2026-06-20 19:25:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.674, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260620-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host04-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→7→…→7→8→9→10
* 開始   : 2026-06-20 20:15:00 (UTC)
* 終了   : 2026-06-20 21:05:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.901, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→13→14→18→13→14
* 開始   : 2026-06-21 11:05:00 (UTC)
* 終了   : 2026-06-21 11:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→7→10→8→7→10→9
* 開始   : 2026-06-21 21:00:00 (UTC)
* 終了   : 2026-06-21 21:05:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→17→12→16→17→12→16→14→15
* 開始   : 2026-06-23 05:20:00 (UTC)
* 終了   : 2026-06-23 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.333倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→15→17→16→15→17→16
* 開始   : 2026-06-23 06:10:00 (UTC)
* 終了   : 2026-06-23 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→19→20→19→16→21→20
* 開始   : 2026-06-23 15:10:00 (UTC)
* 終了   : 2026-06-23 16:30:00 (UTC)
* 現象   : 2026-06-23 16:30:00 (UTC)を境に水準が 14.96から15.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 21→20→21→19→19→17→17→18→18
* 開始   : 2026-06-23 15:40:00 (UTC)
* 終了   : 2026-06-23 17:05:00 (UTC)
* 現象   : 2026-06-23 17:05:00 (UTC)を境に水準が 15.15から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.311, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→13→9→11→9→11→9→10
* 開始   : 2026-06-23 20:05:00 (UTC)
* 終了   : 2026-06-23 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260623-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→5→11→8→9→5→11→8→7
* 開始   : 2026-06-24 01:40:00 (UTC)
* 終了   : 2026-06-24 01:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260624-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→12→…→6→12→8→11
* 開始   : 2026-06-24 02:20:00 (UTC)
* 終了   : 2026-06-24 02:25:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→12→14→12
* 開始   : 2026-06-24 04:20:00 (UTC)
* 終了   : 2026-06-24 04:25:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→17→16→14→17→15→16
* 開始   : 2026-06-24 05:40:00 (UTC)
* 終了   : 2026-06-24 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→19→16→18
* 開始   : 2026-06-24 16:10:00 (UTC)
* 終了   : 2026-06-24 16:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→16→14→15→14→16→16→15→14
* 開始   : 2026-06-24 18:10:00 (UTC)
* 終了   : 2026-06-24 18:55:00 (UTC)
* 現象   : 2026-06-24 18:55:00 (UTC)を境に水準が 15.07から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.487, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→9→12→9→12→9→10→11
* 開始   : 2026-06-24 20:10:00 (UTC)
* 終了   : 2026-06-24 20:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→9→7→11→9→7→11→9
* 開始   : 2026-06-24 20:45:00 (UTC)
* 終了   : 2026-06-24 20:50:00 (UTC)
* 現象   : 平常時(11)に対し 0.6364(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.767σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→16→14→16→15→14
* 開始   : 2026-06-25 05:40:00 (UTC)
* 終了   : 2026-06-25 05:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→16→…→16→17→16→14
* 開始   : 2026-06-25 05:55:00 (UTC)
* 終了   : 2026-06-25 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260625-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 23→24→24→22→26→22
* 開始   : 2026-06-25 11:30:00 (UTC)
* 終了   : 2026-06-25 11:55:00 (UTC)
* 現象   : 2026-06-25 11:55:00 (UTC)を境に水準が 15.08から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-008 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→18→15→14→18→15→14
* 開始   : 2026-06-25 18:00:00 (UTC)
* 終了   : 2026-06-25 18:05:00 (UTC)
* 現象   : 木曜18時台の平常値(14.3)に対し 18であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.193σ 外れた (平常値=14.3)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260625-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→14→11→15→14→11→15→16
* 開始   : 2026-06-25 18:35:00 (UTC)
* 終了   : 2026-06-25 18:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→13→16→14→16→14→16→14
* 開始   : 2026-06-26 05:30:00 (UTC)
* 終了   : 2026-06-26 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→16→…→16→18→14→16
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→18→14→18→14→18→17→16
* 開始   : 2026-06-26 06:45:00 (UTC)
* 終了   : 2026-06-26 06:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→19→20→17→15→19→20→17
* 開始   : 2026-06-26 07:15:00 (UTC)
* 終了   : 2026-06-26 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→22→23→20→18→22→23→20
* 開始   : 2026-06-26 08:55:00 (UTC)
* 終了   : 2026-06-26 09:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260626-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→15→14→20→…→14→20→14→16
* 開始   : 2026-06-26 17:30:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→8→6→10→8→6→10→8
* 開始   : 2026-06-26 22:15:00 (UTC)
* 終了   : 2026-06-26 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→8→10→9→8→10
* 開始   : 2026-06-27 20:25:00 (UTC)
* 終了   : 2026-06-27 20:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260627-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→12→14→15→12→13
* 開始   : 2026-06-28 06:00:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260628-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→13→17→13→17→13→16
* 開始   : 2026-06-28 12:00:00 (UTC)
* 終了   : 2026-06-28 12:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→13→15→17→13→15
* 開始   : 2026-06-28 13:35:00 (UTC)
* 終了   : 2026-06-28 13:40:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→11→8→11→8→11→8→11→10
* 開始   : 2026-06-28 19:10:00 (UTC)
* 終了   : 2026-06-28 19:20:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→10
* 開始   : 2026-06-29 01:50:00 (UTC)
* 終了   : 2026-06-29 02:05:00 (UTC)
* 現象   : 2026-06-29 02:05:00 (UTC)を境に水準が 11.74から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.619, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→6→8→12→6→8→12→7→9
* 開始   : 2026-06-29 22:05:00 (UTC)
* 終了   : 2026-06-29 22:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→7→6→7→6→7
* 開始   : 2026-06-29 22:40:00 (UTC)
* 終了   : 2026-06-29 22:45:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→10→9→9→9→11→9→9
* 開始   : 2026-06-30 00:45:00 (UTC)
* 終了   : 2026-06-30 01:20:00 (UTC)
* 現象   : 2026-06-30 01:20:00 (UTC)を境に水準が 14.98から15.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.317, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→10→10→10→11
* 開始   : 2026-06-30 01:45:00 (UTC)
* 終了   : 2026-06-30 02:05:00 (UTC)
* 現象   : 2026-06-30 02:05:00 (UTC)を境に水準が 14.96から15.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→11→13→11→13→11→13→9→13
* 開始   : 2026-06-30 03:20:00 (UTC)
* 終了   : 2026-06-30 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260630-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→13→12→15→13→14
* 開始   : 2026-06-30 05:15:00 (UTC)
* 終了   : 2026-06-30 05:20:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260630-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→12→17→15
* 開始   : 2026-06-30 06:10:00 (UTC)
* 終了   : 2026-06-30 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→21→…→20→21→19→20
* 開始   : 2026-06-30 07:35:00 (UTC)
* 終了   : 2026-06-30 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→18→20→18→20→19
* 開始   : 2026-06-30 07:35:00 (UTC)
* 終了   : 2026-06-30 07:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→16→21→18→21→18→21→18→17
* 開始   : 2026-06-30 08:00:00 (UTC)
* 終了   : 2026-06-30 08:10:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.883σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 20→17→19→20→17→19→18
* 開始   : 2026-06-30 15:35:00 (UTC)
* 終了   : 2026-06-30 15:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260630-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→16→15→18→…→17→14→16→17
* 開始   : 2026-06-30 17:10:00 (UTC)
* 終了   : 2026-06-30 17:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260630-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→7→9→6→7→9→6→8→10
* 開始   : 2026-06-30 21:55:00 (UTC)
* 終了   : 2026-06-30 22:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→10→10→10
* 開始   : 2026-06-30 22:35:00 (UTC)
* 終了   : 2026-06-30 22:50:00 (UTC)
* 現象   : 2026-06-30 22:50:00 (UTC)を境に水準が 15.04から8.143へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-016 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
