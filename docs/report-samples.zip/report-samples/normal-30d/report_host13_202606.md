# host13 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host13 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 329 (SEVERE: 19, FATAL: 131, WARN: 179, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 131 | 179 | 329 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→13→…→13→12→10→13
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 20:40:00 (UTC)
* 現象   : 2026-06-08 20:40:00 (UTC)を境に水準が 11.78から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-001 active_connections の推移](charts/EVT-20260608-host13-001.svg)

# イベントID( EVT-20260608-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→17→15→17→…→15→13→15→13
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.58から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.687σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.016, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-002 active_connections の推移](charts/EVT-20260608-host13-002.svg)

# イベントID( EVT-20260608-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→18→17→16→…→12→13→14→12
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 19:30:00 (UTC)
* 現象   : 2026-06-08 19:30:00 (UTC)を境に水準が 11.93から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.685, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.857, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-003 active_connections の推移](charts/EVT-20260608-host13-003.svg)

# イベントID( EVT-20260608-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→14→…→15→12→13→14
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.81から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.486, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-004 active_connections の推移](charts/EVT-20260608-host13-004.svg)

# イベントID( EVT-20260608-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→17→…→11→13→12→10
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.78から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.314, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-005 active_connections の推移](charts/EVT-20260608-host13-005.svg)

# イベントID( EVT-20260608-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→15→17→16→…→16→12→15→12
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 11.99から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.954, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.548, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-006 active_connections の推移](charts/EVT-20260608-host13-006.svg)

# イベントID( EVT-20260615-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→17→…→13→16→12→14
* 開始   : 2026-06-15 01:35:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.85から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.053, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-001 active_connections の推移](charts/EVT-20260615-host13-001.svg)

# イベントID( EVT-20260615-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→15→…→14→15→12→14
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.85から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.717σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.752, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-003 active_connections の推移](charts/EVT-20260615-host13-003.svg)

# イベントID( EVT-20260615-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→18→…→13→12→11→13
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.79から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.803, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.826, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-004 active_connections の推移](charts/EVT-20260615-host13-004.svg)

# イベントID( EVT-20260615-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→16→…→13→16→13→16
* 開始   : 2026-06-15 03:35:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.87から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.941, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-005 active_connections の推移](charts/EVT-20260615-host13-005.svg)

# イベントID( EVT-20260615-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→19→…→14→13→14→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 12から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.73, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-006 active_connections の推移](charts/EVT-20260615-host13-006.svg)

# イベントID( EVT-20260622-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→14→…→15→14→15→14
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 22:25:00 (UTC)
* 現象   : 2026-06-22 22:25:00 (UTC)を境に水準が 11.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.093, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-001 active_connections の推移](charts/EVT-20260622-host13-001.svg)

# イベントID( EVT-20260622-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→15→17→12→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.88から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.709, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-003 active_connections の推移](charts/EVT-20260622-host13-003.svg)

# イベントID( EVT-20260622-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→15→…→14→12→14→12
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.846, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-004 active_connections の推移](charts/EVT-20260622-host13-004.svg)

# イベントID( EVT-20260622-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→12→15→10→12
* 開始   : 2026-06-22 03:50:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.96から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.221σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.178, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-006 active_connections の推移](charts/EVT-20260622-host13-006.svg)

# イベントID( EVT-20260622-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→12→19→17→…→14→12→14→12
* 開始   : 2026-06-22 04:45:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.682σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.948, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=15.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-007 active_connections の推移](charts/EVT-20260622-host13-007.svg)

# イベントID( EVT-20260629-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→15→13→12→…→13→14→13→12
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.73から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.508, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-005 active_connections の推移](charts/EVT-20260629-host13-005.svg)

# イベントID( EVT-20260629-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→17→…→16→14→12→14
* 開始   : 2026-06-29 04:00:00 (UTC)
* 終了   : 2026-06-29 21:35:00 (UTC)
* 現象   : 2026-06-29 21:35:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.904, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-007 active_connections の推移](charts/EVT-20260629-host13-007.svg)

# イベントID( EVT-20260629-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→17→…→10→12→13→10
* 開始   : 2026-06-29 04:00:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.96から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.811σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.643, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-008 active_connections の推移](charts/EVT-20260629-host13-008.svg)

# イベントID( EVT-20260601-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→16→20→18→17
* 開始   : 2026-06-01 06:45:00 (UTC)
* 終了   : 2026-06-01 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host13-004 active_connections の推移](charts/EVT-20260601-host13-004.svg)

# イベントID( EVT-20260601-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→23→25→19→21
* 開始   : 2026-06-01 10:00:00 (UTC)
* 終了   : 2026-06-01 10:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host13-005 active_connections の推移](charts/EVT-20260601-host13-005.svg)

# イベントID( EVT-20260602-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→13→9→11
* 開始   : 2026-06-02 02:50:00 (UTC)
* 終了   : 2026-06-02 02:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→18→22→18→18
* 開始   : 2026-06-02 08:00:00 (UTC)
* 終了   : 2026-06-02 08:00:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-009 active_connections の推移](charts/EVT-20260602-host13-009.svg)

# イベントID( EVT-20260602-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→20→24→21→18
* 開始   : 2026-06-02 09:00:00 (UTC)
* 終了   : 2026-06-02 09:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.274倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host13-011 active_connections の推移](charts/EVT-20260602-host13-011.svg)

# イベントID( EVT-20260602-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→26→…→24→26→19→23
* 開始   : 2026-06-02 10:20:00 (UTC)
* 終了   : 2026-06-02 10:25:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-013 active_connections の推移](charts/EVT-20260602-host13-013.svg)

# イベントID( EVT-20260603-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→22→27→21→21
* 開始   : 2026-06-03 10:35:00 (UTC)
* 終了   : 2026-06-03 10:35:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.281倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host13-002 active_connections の推移](charts/EVT-20260603-host13-002.svg)

# イベントID( EVT-20260603-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→17→12→14→15
* 開始   : 2026-06-03 17:35:00 (UTC)
* 終了   : 2026-06-03 17:35:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.467σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host13-003 active_connections の推移](charts/EVT-20260603-host13-003.svg)

# イベントID( EVT-20260603-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→12→12
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host13-005 active_connections の推移](charts/EVT-20260603-host13-005.svg)

# イベントID( EVT-20260604-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→14→14
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host13-004 active_connections の推移](charts/EVT-20260604-host13-004.svg)

# イベントID( EVT-20260604-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→17→22→17→19
* 開始   : 2026-06-04 07:15:00 (UTC)
* 終了   : 2026-06-04 07:15:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-005 active_connections の推移](charts/EVT-20260604-host13-005.svg)

# イベントID( EVT-20260604-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→16→20→18→17
* 開始   : 2026-06-04 07:20:00 (UTC)
* 終了   : 2026-06-04 07:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-006 active_connections の推移](charts/EVT-20260604-host13-006.svg)

# イベントID( EVT-20260604-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→17→14→18→16
* 開始   : 2026-06-04 16:40:00 (UTC)
* 終了   : 2026-06-04 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host13-010 active_connections の推移](charts/EVT-20260604-host13-010.svg)

# イベントID( EVT-20260604-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→12→9→12→12
* 開始   : 2026-06-04 19:20:00 (UTC)
* 終了   : 2026-06-04 19:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-012 active_connections の推移](charts/EVT-20260604-host13-012.svg)

# イベントID( EVT-20260604-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→13→9→11→11
* 開始   : 2026-06-04 19:35:00 (UTC)
* 終了   : 2026-06-04 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-013 active_connections の推移](charts/EVT-20260604-host13-013.svg)

# イベントID( EVT-20260604-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→8→9
* 開始   : 2026-06-04 21:15:00 (UTC)
* 終了   : 2026-06-04 21:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.4545(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host13-015 active_connections の推移](charts/EVT-20260604-host13-015.svg)

# イベントID( EVT-20260605-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→12→12→11
* 開始   : 2026-06-05 02:20:00 (UTC)
* 終了   : 2026-06-05 03:10:00 (UTC)
* 現象   : 2026-06-05 03:10:00 (UTC)を境に水準が 14.98から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→9→15→8→10
* 開始   : 2026-06-05 03:50:00 (UTC)
* 終了   : 2026-06-05 03:50:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host13-002 active_connections の推移](charts/EVT-20260605-host13-002.svg)

# イベントID( EVT-20260605-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→20→25→22→19
* 開始   : 2026-06-05 09:55:00 (UTC)
* 終了   : 2026-06-05 09:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host13-008 active_connections の推移](charts/EVT-20260605-host13-008.svg)

# イベントID( EVT-20260605-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→19→13→12→16→19→13→12→16
* 開始   : 2026-06-05 17:25:00 (UTC)
* 終了   : 2026-06-05 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host13-011 active_connections の推移](charts/EVT-20260605-host13-011.svg)

# イベントID( EVT-20260605-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→7→5→10→9→7→5→10→11
* 開始   : 2026-06-05 21:40:00 (UTC)
* 終了   : 2026-06-05 21:45:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→12→11→12→…→11→10→12→11
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.677, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260606-host13-001 active_connections の推移](charts/EVT-20260606-host13-001.svg)

# イベントID( EVT-20260606-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→10→11→12→…→14→13→14→15
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260606-host13-003 active_connections の推移](charts/EVT-20260606-host13-003.svg)

# イベントID( EVT-20260606-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→12→14→13→…→13→11→14→15
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 18:35:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.819, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host13-004 active_connections の推移](charts/EVT-20260606-host13-004.svg)

# イベントID( EVT-20260606-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→9→11→12→…→12→9→10→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 20:15:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.113, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間

![EVT-20260606-host13-005 active_connections の推移](charts/EVT-20260606-host13-005.svg)

# イベントID( EVT-20260606-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→13→…→13→11→12→10
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260606-host13-006 active_connections の推移](charts/EVT-20260606-host13-006.svg)

# イベントID( EVT-20260606-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→10→9→13→11
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.806, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host13-007 active_connections の推移](charts/EVT-20260606-host13-007.svg)

# イベントID( EVT-20260606-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→11→5→9→9
* 開始   : 2026-06-06 21:15:00 (UTC)
* 終了   : 2026-06-06 21:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→10→13
* 開始   : 2026-06-07 05:35:00 (UTC)
* 終了   : 2026-06-07 05:35:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host13-002 active_connections の推移](charts/EVT-20260607-host13-002.svg)

# イベントID( EVT-20260607-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→16→11→16→11→14
* 開始   : 2026-06-07 06:30:00 (UTC)
* 終了   : 2026-06-07 06:35:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host13-005 active_connections の推移](charts/EVT-20260607-host13-005.svg)

# イベントID( EVT-20260607-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→14→10→12→12
* 開始   : 2026-06-07 16:10:00 (UTC)
* 終了   : 2026-06-07 16:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→15→17→15→13
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-003 active_connections の推移](charts/EVT-20260609-host13-003.svg)

# イベントID( EVT-20260609-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→18→22→17→20
* 開始   : 2026-06-09 08:05:00 (UTC)
* 終了   : 2026-06-09 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host13-006 active_connections の推移](charts/EVT-20260609-host13-006.svg)

# イベントID( EVT-20260609-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→19→24→22→19
* 開始   : 2026-06-09 09:20:00 (UTC)
* 終了   : 2026-06-09 09:20:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→8→9
* 開始   : 2026-06-09 21:40:00 (UTC)
* 終了   : 2026-06-09 21:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-015 active_connections の推移](charts/EVT-20260609-host13-015.svg)

# イベントID( EVT-20260610-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→22→17→21→23
* 開始   : 2026-06-10 12:05:00 (UTC)
* 終了   : 2026-06-10 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host13-005 active_connections の推移](charts/EVT-20260610-host13-005.svg)

# イベントID( EVT-20260610-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→18→14→17→17
* 開始   : 2026-06-10 16:45:00 (UTC)
* 終了   : 2026-06-10 16:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host13-007 active_connections の推移](charts/EVT-20260610-host13-007.svg)

# イベントID( EVT-20260611-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→9→14→11→11
* 開始   : 2026-06-11 03:20:00 (UTC)
* 終了   : 2026-06-11 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-001 active_connections の推移](charts/EVT-20260611-host13-001.svg)

# イベントID( EVT-20260611-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→12→15→12→15→12
* 開始   : 2026-06-11 04:55:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260611-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host13-003 active_connections の推移](charts/EVT-20260611-host13-003.svg)

# イベントID( EVT-20260611-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→14→19→15→18
* 開始   : 2026-06-11 06:35:00 (UTC)
* 終了   : 2026-06-11 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host13-005 active_connections の推移](charts/EVT-20260611-host13-005.svg)

# イベントID( EVT-20260611-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 22→20→17→19→21
* 開始   : 2026-06-11 14:55:00 (UTC)
* 終了   : 2026-06-11 14:55:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host13-008 active_connections の推移](charts/EVT-20260611-host13-008.svg)

# イベントID( EVT-20260611-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→13→9→13→11
* 開始   : 2026-06-11 19:35:00 (UTC)
* 終了   : 2026-06-11 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-013 active_connections の推移](charts/EVT-20260611-host13-013.svg)

# イベントID( EVT-20260611-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→5→6→8→5→6→8→10
* 開始   : 2026-06-11 23:00:00 (UTC)
* 終了   : 2026-06-11 23:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-016 active_connections の推移](charts/EVT-20260611-host13-016.svg)

# イベントID( EVT-20260611-host13-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 8→7→5→4→9→7→5→4→9
* 開始   : 2026-06-11 23:35:00 (UTC)
* 終了   : 2026-06-11 23:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.5607(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.716σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260611-host13-018 active_connections の推移](charts/EVT-20260611-host13-018.svg)

# イベントID( EVT-20260612-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→17→16→20→17→18→18→19
* 開始   : 2026-06-12 05:45:00 (UTC)
* 終了   : 2026-06-12 07:45:00 (UTC)
* 現象   : 2026-06-12 07:45:00 (UTC)を境に水準が 14.92から14.56へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.665σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.535, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-003 active_connections の推移](charts/EVT-20260612-host13-003.svg)

# イベントID( EVT-20260612-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→19→20→17→16→19→20→17→14
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:35:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-005 active_connections の推移](charts/EVT-20260612-host13-005.svg)

# イベントID( EVT-20260612-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 22→21→17→21→19
* 開始   : 2026-06-12 13:50:00 (UTC)
* 終了   : 2026-06-12 13:50:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-008 active_connections の推移](charts/EVT-20260612-host13-008.svg)

# イベントID( EVT-20260612-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→15→11→14→14
* 開始   : 2026-06-12 18:40:00 (UTC)
* 終了   : 2026-06-12 18:40:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host13-012 active_connections の推移](charts/EVT-20260612-host13-012.svg)

# イベントID( EVT-20260612-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→12→10→12→15→12→10→12→13
* 開始   : 2026-06-12 18:55:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host13-013 active_connections の推移](charts/EVT-20260612-host13-013.svg)

# イベントID( EVT-20260612-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→12→5→12→9
* 開始   : 2026-06-12 21:15:00 (UTC)
* 終了   : 2026-06-12 21:15:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.4615(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host13-016 active_connections の推移](charts/EVT-20260612-host13-016.svg)

# イベントID( EVT-20260612-host13-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 7→9→4→10→9
* 開始   : 2026-06-12 23:25:00 (UTC)
* 終了   : 2026-06-12 23:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host13-018 active_connections の推移](charts/EVT-20260612-host13-018.svg)

# イベントID( EVT-20260613-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 7→9→12→9→7
* 開始   : 2026-06-13 01:05:00 (UTC)
* 終了   : 2026-06-13 01:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→13→…→11→9→10→11
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 21:10:00 (UTC)
* 現象   : 16.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.29, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.8 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 15.3 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間

![EVT-20260613-host13-004 active_connections の推移](charts/EVT-20260613-host13-004.svg)

# イベントID( EVT-20260613-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→14→10→12→…→11→15→11→13
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.31, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host13-005 active_connections の推移](charts/EVT-20260613-host13-005.svg)

# イベントID( EVT-20260613-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→13→11→13→12
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host13-006 active_connections の推移](charts/EVT-20260613-host13-006.svg)

# イベントID( EVT-20260613-host13-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→12→13→12→10
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 20:15:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.3 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間

![EVT-20260613-host13-007 active_connections の推移](charts/EVT-20260613-host13-007.svg)

# イベントID( EVT-20260613-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→12→14→11→…→9→11→12→11
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.713, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260613-host13-008 active_connections の推移](charts/EVT-20260613-host13-008.svg)

# イベントID( EVT-20260613-host13-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→13→…→10→11→8→12
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.09, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host13-009 active_connections の推移](charts/EVT-20260613-host13-009.svg)

# イベントID( EVT-20260614-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→12→14→11→…→14→16→14→13
* 開始   : 2026-06-14 05:40:00 (UTC)
* 終了   : 2026-06-14 05:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260614-host13-002 active_connections の推移](charts/EVT-20260614-host13-002.svg)

# イベントID( EVT-20260614-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→11→13
* 開始   : 2026-06-14 06:35:00 (UTC)
* 終了   : 2026-06-14 06:35:00 (UTC)
* 現象   : 平常時(12)に対し 1.417倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host13-003 active_connections の推移](charts/EVT-20260614-host13-003.svg)

# イベントID( EVT-20260614-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→18→12→17→16
* 開始   : 2026-06-14 11:55:00 (UTC)
* 終了   : 2026-06-14 11:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host13-006 active_connections の推移](charts/EVT-20260614-host13-006.svg)

# イベントID( EVT-20260614-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→12→8→12→11
* 開始   : 2026-06-14 18:20:00 (UTC)
* 終了   : 2026-06-14 18:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host13-007 active_connections の推移](charts/EVT-20260614-host13-007.svg)

# イベントID( EVT-20260615-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→11→14→8→10
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 01:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.739σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260615-host13-002 active_connections の推移](charts/EVT-20260615-host13-002.svg)

# イベントID( EVT-20260615-host13-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→16→…→16→13→14→13
* 開始   : 2026-06-15 04:25:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 12.1から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.962, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-007 active_connections の推移](charts/EVT-20260615-host13-007.svg)

# イベントID( EVT-20260616-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→15→16
* 開始   : 2026-06-16 06:15:00 (UTC)
* 終了   : 2026-06-16 06:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host13-003 active_connections の推移](charts/EVT-20260616-host13-003.svg)

# イベントID( EVT-20260616-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→19→24→19→…→19→23→21→22
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.309倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.965σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host13-005 active_connections の推移](charts/EVT-20260616-host13-005.svg)

# イベントID( EVT-20260616-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 23→21→16→20→20
* 開始   : 2026-06-16 14:25:00 (UTC)
* 終了   : 2026-06-16 14:25:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host13-006 active_connections の推移](charts/EVT-20260616-host13-006.svg)

# イベントID( EVT-20260616-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 22→18→16→20→20
* 開始   : 2026-06-16 15:00:00 (UTC)
* 終了   : 2026-06-16 15:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host13-008 active_connections の推移](charts/EVT-20260616-host13-008.svg)

# イベントID( EVT-20260616-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→18→13→16→16
* 開始   : 2026-06-16 17:10:00 (UTC)
* 終了   : 2026-06-16 17:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host13-010 active_connections の推移](charts/EVT-20260616-host13-010.svg)

# イベントID( EVT-20260617-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→19→14→18→19
* 開始   : 2026-06-17 16:35:00 (UTC)
* 終了   : 2026-06-17 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-006 active_connections の推移](charts/EVT-20260617-host13-006.svg)

# イベントID( EVT-20260617-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→18→14→16→16
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host13-008 active_connections の推移](charts/EVT-20260617-host13-008.svg)

# イベントID( EVT-20260617-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→13→12
* 開始   : 2026-06-17 19:40:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-010 active_connections の推移](charts/EVT-20260617-host13-010.svg)

# イベントID( EVT-20260618-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→9→7
* 開始   : 2026-06-18 00:20:00 (UTC)
* 終了   : 2026-06-18 00:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host13-001 active_connections の推移](charts/EVT-20260618-host13-001.svg)

# イベントID( EVT-20260618-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→11→16→12→13
* 開始   : 2026-06-18 05:00:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260618-host13-003 active_connections の推移](charts/EVT-20260618-host13-003.svg)

# イベントID( EVT-20260618-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→16→19→18→16→19→16
* 開始   : 2026-06-18 06:50:00 (UTC)
* 終了   : 2026-06-18 07:35:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host13-004 active_connections の推移](charts/EVT-20260618-host13-004.svg)

# イベントID( EVT-20260618-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 23→23→26→21→21
* 開始   : 2026-06-18 13:05:00 (UTC)
* 終了   : 2026-06-18 13:05:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host13-006 active_connections の推移](charts/EVT-20260618-host13-006.svg)

# イベントID( EVT-20260618-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→18→16→19→…→19→15→19→18
* 開始   : 2026-06-18 16:10:00 (UTC)
* 終了   : 2026-06-18 17:15:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host14-019 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host13-008 active_connections の推移](charts/EVT-20260618-host13-008.svg)

# イベントID( EVT-20260618-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→9→11→12→14→9→11→12→16
* 開始   : 2026-06-18 19:00:00 (UTC)
* 終了   : 2026-06-18 19:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6171(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.898σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host13-011 active_connections の推移](charts/EVT-20260618-host13-011.svg)

# イベントID( EVT-20260618-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→13→8→11→12
* 開始   : 2026-06-18 20:05:00 (UTC)
* 終了   : 2026-06-18 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host13-012 active_connections の推移](charts/EVT-20260618-host13-012.svg)

# イベントID( EVT-20260619-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→18→…→17→18→17→15
* 開始   : 2026-06-19 06:05:00 (UTC)
* 終了   : 2026-06-19 06:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host13-006 active_connections の推移](charts/EVT-20260619-host13-006.svg)

# イベントID( EVT-20260619-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→8→4→9→9
* 開始   : 2026-06-19 23:20:00 (UTC)
* 終了   : 2026-06-19 23:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-012 active_connections の推移](charts/EVT-20260619-host13-012.svg)

# イベントID( EVT-20260620-host13-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→11→…→9→10→9→10
* 開始   : 2026-06-20 04:30:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260620-host13-002 active_connections の推移](charts/EVT-20260620-host13-002.svg)

# イベントID( EVT-20260620-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→12→…→12→11→9→10
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.913, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host13-004 active_connections の推移](charts/EVT-20260620-host13-004.svg)

# イベントID( EVT-20260620-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→10→12→10→11
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host13-005 active_connections の推移](charts/EVT-20260620-host13-005.svg)

# イベントID( EVT-20260620-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→11→…→9→11→12→11
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host13-006 active_connections の推移](charts/EVT-20260620-host13-006.svg)

# イベントID( EVT-20260620-host13-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→13→…→13→12→11→13
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.796, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host13-007 active_connections の推移](charts/EVT-20260620-host13-007.svg)

# イベントID( EVT-20260620-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→13→…→12→13→12→11
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host13-008 active_connections の推移](charts/EVT-20260620-host13-008.svg)

# イベントID( EVT-20260621-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→13→16→11→14
* 開始   : 2026-06-21 06:35:00 (UTC)
* 終了   : 2026-06-21 06:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.699σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host13-002 active_connections の推移](charts/EVT-20260621-host13-002.svg)

# イベントID( EVT-20260622-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→15→…→13→15→14→13
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.82から14.85へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-005 active_connections の推移](charts/EVT-20260622-host13-005.svg)

# イベントID( EVT-20260623-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→11→11→13
* 開始   : 2026-06-23 02:20:00 (UTC)
* 終了   : 2026-06-23 02:35:00 (UTC)
* 現象   : 2026-06-23 02:35:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→19→23→19→19
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:25:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host13-007 active_connections の推移](charts/EVT-20260623-host13-007.svg)

# イベントID( EVT-20260623-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 19→18→24→22→…→22→23→20→23
* 開始   : 2026-06-23 09:55:00 (UTC)
* 終了   : 2026-06-23 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→13→8→10→…→10→8→11→9
* 開始   : 2026-06-23 20:05:00 (UTC)
* 終了   : 2026-06-23 21:10:00 (UTC)
* 現象   : 2026-06-23 21:10:00 (UTC)を境に水準が 14.97から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.832σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.137, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→11→15→11→13
* 開始   : 2026-06-24 03:50:00 (UTC)
* 終了   : 2026-06-24 04:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-002 active_connections の推移](charts/EVT-20260624-host13-002.svg)

# イベントID( EVT-20260624-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→14→18→15→13
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-003 active_connections の推移](charts/EVT-20260624-host13-003.svg)

# イベントID( EVT-20260624-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→21→20→18→21→20→18
* 開始   : 2026-06-24 07:30:00 (UTC)
* 終了   : 2026-06-24 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host13-005 active_connections の推移](charts/EVT-20260624-host13-005.svg)

# イベントID( EVT-20260624-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→14→14
* 開始   : 2026-06-24 17:40:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-008 active_connections の推移](charts/EVT-20260624-host13-008.svg)

# イベントID( EVT-20260624-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→15→12→18→16
* 開始   : 2026-06-24 17:50:00 (UTC)
* 終了   : 2026-06-24 17:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.252σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host13-009 active_connections の推移](charts/EVT-20260624-host13-009.svg)

# イベントID( EVT-20260624-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→14→10→15→12
* 開始   : 2026-06-24 18:45:00 (UTC)
* 終了   : 2026-06-24 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host13-011 active_connections の推移](charts/EVT-20260624-host13-011.svg)

# イベントID( EVT-20260624-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→11→11
* 開始   : 2026-06-24 20:50:00 (UTC)
* 終了   : 2026-06-24 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-012 active_connections の推移](charts/EVT-20260624-host13-012.svg)

# イベントID( EVT-20260625-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→13→14
* 開始   : 2026-06-25 05:00:00 (UTC)
* 終了   : 2026-06-25 05:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host13-002 active_connections の推移](charts/EVT-20260625-host13-002.svg)

# イベントID( EVT-20260625-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→18→15→18→15→18→16
* 開始   : 2026-06-25 06:05:00 (UTC)
* 終了   : 2026-06-25 06:15:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260625-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-003 active_connections の推移](charts/EVT-20260625-host13-003.svg)

# イベントID( EVT-20260625-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→15→21→16→18
* 開始   : 2026-06-25 07:20:00 (UTC)
* 終了   : 2026-06-25 07:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-005 active_connections の推移](charts/EVT-20260625-host13-005.svg)

# イベントID( EVT-20260625-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→16→20→21→16→20→19
* 開始   : 2026-06-25 07:35:00 (UTC)
* 終了   : 2026-06-25 07:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host13-006 active_connections の推移](charts/EVT-20260625-host13-006.svg)

# イベントID( EVT-20260625-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→17→15→18→16
* 開始   : 2026-06-25 16:05:00 (UTC)
* 終了   : 2026-06-25 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-010 active_connections の推移](charts/EVT-20260625-host13-010.svg)

# イベントID( EVT-20260625-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→11→12
* 開始   : 2026-06-25 20:15:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host13-013 active_connections の推移](charts/EVT-20260625-host13-013.svg)

# イベントID( EVT-20260626-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→19→22→21→…→22→21→20→19
* 開始   : 2026-06-26 08:10:00 (UTC)
* 終了   : 2026-06-26 08:15:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-003 active_connections の推移](charts/EVT-20260626-host13-003.svg)

# イベントID( EVT-20260626-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 23→22→26→22→21
* 開始   : 2026-06-26 11:25:00 (UTC)
* 終了   : 2026-06-26 11:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→20→21
* 開始   : 2026-06-26 14:50:00 (UTC)
* 終了   : 2026-06-26 14:50:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→20→18→16→15→20→17
* 開始   : 2026-06-26 15:55:00 (UTC)
* 終了   : 2026-06-26 16:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host13-007 active_connections の推移](charts/EVT-20260626-host13-007.svg)

# イベントID( EVT-20260626-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→14→11→14→15
* 開始   : 2026-06-26 18:20:00 (UTC)
* 終了   : 2026-06-26 18:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.178σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host13-009 active_connections の推移](charts/EVT-20260626-host13-009.svg)

# イベントID( EVT-20260627-host13-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→13→…→13→12→14→12
* 開始   : 2026-06-27 04:25:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.705, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 14.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.4 時間

![EVT-20260627-host13-001 active_connections の推移](charts/EVT-20260627-host13-001.svg)

# イベントID( EVT-20260627-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→8→10→11→…→11→9→11→10
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.98, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.4 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host13-002 active_connections の推移](charts/EVT-20260627-host13-002.svg)

# イベントID( EVT-20260627-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→12→13→11→…→12→10→12→9
* 開始   : 2026-06-27 04:55:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.755, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host13-003 active_connections の推移](charts/EVT-20260627-host13-003.svg)

# イベントID( EVT-20260627-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→10→…→12→15→13→12
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.658σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.076, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.8 時間

![EVT-20260627-host13-004 active_connections の推移](charts/EVT-20260627-host13-004.svg)

# イベントID( EVT-20260627-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→10→…→10→9→12→14
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.955, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260627-host13-005 active_connections の推移](charts/EVT-20260627-host13-005.svg)

# イベントID( EVT-20260627-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→13→…→12→14→13→11
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.766, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host13-006 active_connections の推移](charts/EVT-20260627-host13-006.svg)

# イベントID( EVT-20260628-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 8→9→4→8→7
* 開始   : 2026-06-28 00:00:00 (UTC)
* 終了   : 2026-06-28 00:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→9→15→11→10
* 開始   : 2026-06-28 04:20:00 (UTC)
* 終了   : 2026-06-28 04:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.565倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.757σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host13-004 active_connections の推移](charts/EVT-20260628-host13-004.svg)

# イベントID( EVT-20260628-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→13→16→13→12
* 開始   : 2026-06-28 07:05:00 (UTC)
* 終了   : 2026-06-28 07:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→9→8
* 開始   : 2026-06-29 01:40:00 (UTC)
* 終了   : 2026-06-29 01:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14→…→15→14→15→14
* 開始   : 2026-06-29 01:50:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.81から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.788, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.792, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-003 active_connections の推移](charts/EVT-20260629-host13-003.svg)

# イベントID( EVT-20260629-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→16→18→17→…→14→10→13→10
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.79から15.13へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.112, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-004 active_connections の推移](charts/EVT-20260629-host13-004.svg)

# イベントID( EVT-20260629-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→15→…→13→15→13→15
* 開始   : 2026-06-29 03:40:00 (UTC)
* 終了   : 2026-06-29 21:20:00 (UTC)
* 現象   : 2026-06-29 21:20:00 (UTC)を境に水準が 11.9から15.09へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.865, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-006 active_connections の推移](charts/EVT-20260629-host13-006.svg)

# イベントID( EVT-20260630-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→10→11→12→10→10→12→14→15
* 開始   : 2026-06-30 03:10:00 (UTC)
* 終了   : 2026-06-30 04:30:00 (UTC)
* 現象   : 2026-06-30 04:30:00 (UTC)を境に水準が 14.98から16.48へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→14→11→11→13→12→12
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 04:45:00 (UTC)
* 現象   : 2026-06-30 04:45:00 (UTC)を境に水準が 14.96から16.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.806σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.643, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host13-002 active_connections の推移](charts/EVT-20260630-host13-002.svg)

# イベントID( EVT-20260630-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→10→15→10→11
* 開始   : 2026-06-30 03:25:00 (UTC)
* 終了   : 2026-06-30 03:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.295σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-003 active_connections の推移](charts/EVT-20260630-host13-003.svg)

# イベントID( EVT-20260630-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→17→20→17→…→17→22→17→16
* 開始   : 2026-06-30 07:50:00 (UTC)
* 終了   : 2026-06-30 08:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-004 active_connections の推移](charts/EVT-20260630-host13-004.svg)

# イベントID( EVT-20260630-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→18→14→19→18
* 開始   : 2026-06-30 16:20:00 (UTC)
* 終了   : 2026-06-30 16:20:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-006 active_connections の推移](charts/EVT-20260630-host13-006.svg)

# イベントID( EVT-20260630-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→18→14→16→19
* 開始   : 2026-06-30 16:55:00 (UTC)
* 終了   : 2026-06-30 16:55:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-007 active_connections の推移](charts/EVT-20260630-host13-007.svg)

# イベントID( EVT-20260630-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→12→10→13→15→12→10→13→15
* 開始   : 2026-06-30 18:35:00 (UTC)
* 終了   : 2026-06-30 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-008 active_connections の推移](charts/EVT-20260630-host13-008.svg)

# イベントID( EVT-20260601-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→5→8→11→5→8→11→9→8
* 開始   : 2026-06-01 00:55:00 (UTC)
* 終了   : 2026-06-01 01:05:00 (UTC)
* 現象   : 平常時(8.182)に対し 0.6111(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→12→14→10→13
* 開始   : 2026-06-01 04:00:00 (UTC)
* 終了   : 2026-06-01 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.342σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→17→13→17→15→13
* 開始   : 2026-06-01 06:00:00 (UTC)
* 終了   : 2026-06-01 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→18→15→18→15→17
* 開始   : 2026-06-01 16:35:00 (UTC)
* 終了   : 2026-06-01 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260601-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→16→12→15→12→15→12→15
* 開始   : 2026-06-01 18:15:00 (UTC)
* 終了   : 2026-06-01 18:25:00 (UTC)
* 現象   : 平常時(16)に対し 0.75(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.787σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→15→11→16→15→11→16→14
* 開始   : 2026-06-01 18:55:00 (UTC)
* 終了   : 2026-06-01 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.7333(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.774σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→11→7→11→9
* 開始   : 2026-06-01 21:30:00 (UTC)
* 終了   : 2026-06-01 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 7→9→11→10→…→10→5→6→8
* 開始   : 2026-06-01 23:50:00 (UTC)
* 終了   : 2026-06-02 00:50:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→8→9→11
* 開始   : 2026-06-02 00:05:00 (UTC)
* 終了   : 2026-06-02 00:20:00 (UTC)
* 現象   : 2026-06-02 00:20:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→8→12→8→12→8→12→8→11
* 開始   : 2026-06-02 02:15:00 (UTC)
* 終了   : 2026-06-02 02:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→10→12→8→12→8→12→11
* 開始   : 2026-06-02 02:35:00 (UTC)
* 終了   : 2026-06-02 02:45:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→13→11→14→13→12
* 開始   : 2026-06-02 04:20:00 (UTC)
* 終了   : 2026-06-02 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→12→15→12→15→13
* 開始   : 2026-06-02 05:05:00 (UTC)
* 終了   : 2026-06-02 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→20→17→20→17→20→19
* 開始   : 2026-06-02 07:35:00 (UTC)
* 終了   : 2026-06-02 07:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→17→20→16→…→16→21→18→19
* 開始   : 2026-06-02 07:45:00 (UTC)
* 終了   : 2026-06-02 07:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→16→21→18→16→21→18
* 開始   : 2026-06-02 08:05:00 (UTC)
* 終了   : 2026-06-02 08:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→23→…→23→25→21→20
* 開始   : 2026-06-02 10:15:00 (UTC)
* 終了   : 2026-06-02 10:25:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260602-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→22→25→19→…→25→19→23→21
* 開始   : 2026-06-02 12:55:00 (UTC)
* 終了   : 2026-06-02 13:00:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→17→19→16→17→19
* 開始   : 2026-06-02 16:30:00 (UTC)
* 終了   : 2026-06-02 16:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→15→16→14→15
* 開始   : 2026-06-02 17:25:00 (UTC)
* 終了   : 2026-06-02 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→11→14→11→14→11→13→12
* 開始   : 2026-06-02 18:40:00 (UTC)
* 終了   : 2026-06-02 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→10→8→10→8→9
* 開始   : 2026-06-02 20:50:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 21→24→21→24→21→20
* 開始   : 2026-06-03 10:15:00 (UTC)
* 終了   : 2026-06-03 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→14→11→12→14→11→12→14
* 開始   : 2026-06-03 18:55:00 (UTC)
* 終了   : 2026-06-03 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→12→10→12
* 開始   : 2026-06-03 19:50:00 (UTC)
* 終了   : 2026-06-03 19:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→8→12→8→12→8→11
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 03:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→13→11→14→12→12→13→13
* 開始   : 2026-06-04 03:50:00 (UTC)
* 終了   : 2026-06-04 04:25:00 (UTC)
* 現象   : 2026-06-04 04:25:00 (UTC)を境に水準が 14.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→14→15→16→13→14→15→16→13
* 開始   : 2026-06-04 04:55:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→19→21→19→21→17→18
* 開始   : 2026-06-04 08:00:00 (UTC)
* 終了   : 2026-06-04 08:10:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→18→19→22→18→20
* 開始   : 2026-06-04 09:00:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→23→22→24→21→24→23→24→23
* 開始   : 2026-06-04 11:40:00 (UTC)
* 終了   : 2026-06-04 12:25:00 (UTC)
* 現象   : 2026-06-04 12:25:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→11→13→11→10→11→14
* 開始   : 2026-06-04 19:15:00 (UTC)
* 終了   : 2026-06-04 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→10→9→10→9→11→10
* 開始   : 2026-06-04 20:00:00 (UTC)
* 終了   : 2026-06-04 20:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→11→15→11→15→11→15→14→11
* 開始   : 2026-06-05 04:25:00 (UTC)
* 終了   : 2026-06-05 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→13→17→14→17→14→17→15→17
* 開始   : 2026-06-05 05:40:00 (UTC)
* 終了   : 2026-06-05 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→16→17→19→16→18
* 開始   : 2026-06-05 07:20:00 (UTC)
* 終了   : 2026-06-05 07:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→17→20→17→…→17→21→19→18
* 開始   : 2026-06-05 07:40:00 (UTC)
* 終了   : 2026-06-05 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→22→23→19→23→19→23→20→19
* 開始   : 2026-06-05 09:15:00 (UTC)
* 終了   : 2026-06-05 09:25:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→21→25→22→…→22→19→20→21
* 開始   : 2026-06-05 12:20:00 (UTC)
* 終了   : 2026-06-05 12:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260605-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→16→14→16→14→16→14→16
* 開始   : 2026-06-05 16:55:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→12→6→10→9→12→6→10→8
* 開始   : 2026-06-05 22:15:00 (UTC)
* 終了   : 2026-06-05 22:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→12→10→11→12→10→11→12
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 05:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.733, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260606-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→9→7→9→…→7→10→7→10
* 開始   : 2026-06-06 20:15:00 (UTC)
* 終了   : 2026-06-06 20:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.712, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260606-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260606-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260606-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→6→7→10→6→7→9
* 開始   : 2026-06-06 22:15:00 (UTC)
* 終了   : 2026-06-06 22:20:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260606-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→10→12→10→12→10→8
* 開始   : 2026-06-07 02:55:00 (UTC)
* 終了   : 2026-06-07 03:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.284σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→13→12→14→10→15
* 開始   : 2026-06-07 05:45:00 (UTC)
* 終了   : 2026-06-07 06:10:00 (UTC)
* 現象   : 2026-06-07 06:10:00 (UTC)を境に水準が 11.89から12.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→12→12→14→13→15→15
* 開始   : 2026-06-07 05:55:00 (UTC)
* 終了   : 2026-06-07 07:00:00 (UTC)
* 現象   : 2026-06-07 07:00:00 (UTC)を境に水準が 11.88から12.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→10→13→16→10→13→16→14
* 開始   : 2026-06-07 07:00:00 (UTC)
* 終了   : 2026-06-07 07:10:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→17→17→17→17→17
* 開始   : 2026-06-07 12:30:00 (UTC)
* 終了   : 2026-06-07 12:55:00 (UTC)
* 現象   : 2026-06-07 12:55:00 (UTC)を境に水準が 11.81から13.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→10→11→9→10→11→9→13
* 開始   : 2026-06-07 17:20:00 (UTC)
* 終了   : 2026-06-07 17:30:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→7→6→12→…→6→12→8→9
* 開始   : 2026-06-07 20:55:00 (UTC)
* 終了   : 2026-06-07 21:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→8→6→8→…→8→12→7→8
* 開始   : 2026-06-07 21:50:00 (UTC)
* 終了   : 2026-06-07 22:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260607-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 6→8→5→8→…→8→11→10→9
* 開始   : 2026-06-09 00:45:00 (UTC)
* 終了   : 2026-06-09 00:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260609-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→9→13→12→9→13→12→11
* 開始   : 2026-06-09 03:50:00 (UTC)
* 終了   : 2026-06-09 03:55:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→16→15→18
* 開始   : 2026-06-09 05:55:00 (UTC)
* 終了   : 2026-06-09 06:20:00 (UTC)
* 現象   : 2026-06-09 06:20:00 (UTC)を境に水準が 15.03から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.095, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→16→15→19→16→17
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→19→19→22→23
* 開始   : 2026-06-09 08:40:00 (UTC)
* 終了   : 2026-06-09 09:00:00 (UTC)
* 現象   : 2026-06-09 09:00:00 (UTC)を境に水準が 15.11から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 23→22→23→24→24
* 開始   : 2026-06-09 10:45:00 (UTC)
* 終了   : 2026-06-09 11:05:00 (UTC)
* 現象   : 2026-06-09 11:05:00 (UTC)を境に水準が 15.07から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→23→25→21→…→21→19→23→21
* 開始   : 2026-06-09 13:00:00 (UTC)
* 終了   : 2026-06-09 13:10:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 23→22→19→21→22→19→21
* 開始   : 2026-06-09 13:40:00 (UTC)
* 終了   : 2026-06-09 13:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→12→13→15→12→15→16
* 開始   : 2026-06-09 18:00:00 (UTC)
* 終了   : 2026-06-09 18:10:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→13→12→14→17→13→12→14
* 開始   : 2026-06-09 18:20:00 (UTC)
* 終了   : 2026-06-09 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→11→9→11→10→11→12→11→11
* 開始   : 2026-06-09 20:10:00 (UTC)
* 終了   : 2026-06-09 20:50:00 (UTC)
* 現象   : 2026-06-09 20:50:00 (UTC)を境に水準が 14.94から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→11→8→9→10→8→8→9→9
* 開始   : 2026-06-09 21:55:00 (UTC)
* 終了   : 2026-06-09 22:50:00 (UTC)
* 現象   : 2026-06-09 22:50:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.535, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→11→13→14→…→13→14→9→11
* 開始   : 2026-06-10 03:50:00 (UTC)
* 終了   : 2026-06-10 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→17→18→18→17→18→20
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:55:00 (UTC)
* 現象   : 2026-06-10 06:55:00 (UTC)を境に水準が 15.06から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→16→18→17→16→18→15
* 開始   : 2026-06-10 06:15:00 (UTC)
* 終了   : 2026-06-10 06:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→18→24→…→18→24→20→21
* 開始   : 2026-06-10 11:40:00 (UTC)
* 終了   : 2026-06-10 11:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→18→16
* 開始   : 2026-06-10 16:40:00 (UTC)
* 終了   : 2026-06-10 16:45:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→17→15→17→15→18→16
* 開始   : 2026-06-10 16:55:00 (UTC)
* 終了   : 2026-06-10 17:05:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→17→13→15→17→13→15→14
* 開始   : 2026-06-10 18:00:00 (UTC)
* 終了   : 2026-06-10 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→12→14→9→…→9→8→9→10
* 開始   : 2026-06-10 20:55:00 (UTC)
* 終了   : 2026-06-10 21:05:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.225σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260610-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→8→6→7→8→6→9
* 開始   : 2026-06-10 22:20:00 (UTC)
* 終了   : 2026-06-10 22:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→9→7→11→…→11→13→11→10
* 開始   : 2026-06-11 03:30:00 (UTC)
* 終了   : 2026-06-11 03:40:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→17→15→17→15→17→15
* 開始   : 2026-06-11 05:40:00 (UTC)
* 終了   : 2026-06-11 05:50:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.921σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→17→20→17→…→17→21→20→18
* 開始   : 2026-06-11 07:55:00 (UTC)
* 終了   : 2026-06-11 08:05:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→24→21→25→24→21→25→20→22
* 開始   : 2026-06-11 10:40:00 (UTC)
* 終了   : 2026-06-11 10:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260611-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→21→20→20→21
* 開始   : 2026-06-11 15:30:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 2026-06-11 15:50:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→18→15→19→18→15→19→16
* 開始   : 2026-06-11 16:35:00 (UTC)
* 終了   : 2026-06-11 16:40:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→18→14→16→18→14→16
* 開始   : 2026-06-11 17:25:00 (UTC)
* 終了   : 2026-06-11 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→16→16→15→15→16→13→15→14
* 開始   : 2026-06-11 17:30:00 (UTC)
* 終了   : 2026-06-11 18:55:00 (UTC)
* 現象   : 2026-06-11 18:55:00 (UTC)を境に水準が 14.97から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.302, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→11→12→12→12→11→12
* 開始   : 2026-06-11 20:20:00 (UTC)
* 終了   : 2026-06-11 20:50:00 (UTC)
* 現象   : 2026-06-11 20:50:00 (UTC)を境に水準が 15から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.062, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→11→10→11→11→11→9→8→11
* 開始   : 2026-06-11 20:40:00 (UTC)
* 終了   : 2026-06-11 21:55:00 (UTC)
* 現象   : 2026-06-11 21:55:00 (UTC)を境に水準が 14.98から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.171, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→10→11→8→…→8→5→8→7
* 開始   : 2026-06-11 23:10:00 (UTC)
* 終了   : 2026-06-11 23:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→7→11→8→…→8→5→9→5
* 開始   : 2026-06-12 00:10:00 (UTC)
* 終了   : 2026-06-12 00:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→16→…→15→16→13→15
* 開始   : 2026-06-12 04:55:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→18→17→18→17→18→16
* 開始   : 2026-06-12 06:20:00 (UTC)
* 終了   : 2026-06-12 06:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.863σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→17→18→17→…→17→19→16→18
* 開始   : 2026-06-12 06:40:00 (UTC)
* 終了   : 2026-06-12 06:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→25→21→19→25→21→19→23→22
* 開始   : 2026-06-12 12:50:00 (UTC)
* 終了   : 2026-06-12 13:00:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→22→20→20→19→19→20→19
* 開始   : 2026-06-12 15:50:00 (UTC)
* 終了   : 2026-06-12 16:50:00 (UTC)
* 現象   : 2026-06-12 16:50:00 (UTC)を境に水準が 15.07から12.44へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→14→18→15→14→18
* 開始   : 2026-06-12 16:55:00 (UTC)
* 終了   : 2026-06-12 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→17→14→15→14→15→14→17→16
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→13→13→12→13→14→13→13→12
* 開始   : 2026-06-12 19:25:00 (UTC)
* 終了   : 2026-06-12 20:05:00 (UTC)
* 現象   : 2026-06-12 20:05:00 (UTC)を境に水準が 14.91から12.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.643, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→13→14
* 開始   : 2026-06-12 19:45:00 (UTC)
* 終了   : 2026-06-12 20:05:00 (UTC)
* 現象   : 2026-06-12 20:05:00 (UTC)を境に水準が 14.98から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→6→10→5→6→10→5→8→9
* 開始   : 2026-06-12 22:50:00 (UTC)
* 終了   : 2026-06-12 23:00:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→8→…→8→11→7→6
* 開始   : 2026-06-13 00:30:00 (UTC)
* 終了   : 2026-06-13 00:40:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-001 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260613-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→12→13→10→…→13→12→13→11
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 05:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.019, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260613-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→11→8→11
* 開始   : 2026-06-13 23:00:00 (UTC)
* 終了   : 2026-06-13 23:15:00 (UTC)
* 現象   : 2026-06-13 23:15:00 (UTC)を境に水準が 11.84から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260613-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→10→14→13→10→14→10
* 開始   : 2026-06-14 04:05:00 (UTC)
* 終了   : 2026-06-14 04:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→14→16→17→15
* 開始   : 2026-06-14 08:10:00 (UTC)
* 終了   : 2026-06-14 08:30:00 (UTC)
* 現象   : 2026-06-14 08:30:00 (UTC)を境に水準が 11.87から12.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→14→…→14→13→14→15
* 開始   : 2026-06-14 10:10:00 (UTC)
* 終了   : 2026-06-14 10:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260614-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→7→10→11→10
* 開始   : 2026-06-15 22:55:00 (UTC)
* 終了   : 2026-06-15 23:15:00 (UTC)
* 現象   : 2026-06-15 23:15:00 (UTC)を境に水準が 15.03から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.678, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→13→16→15
* 開始   : 2026-06-16 05:25:00 (UTC)
* 終了   : 2026-06-16 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→16→…→16→18→17→14
* 開始   : 2026-06-16 06:10:00 (UTC)
* 終了   : 2026-06-16 07:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→19→21→22→21→22→19
* 開始   : 2026-06-16 08:30:00 (UTC)
* 終了   : 2026-06-16 08:40:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→23→18→20→18→20→18→21→20
* 開始   : 2026-06-16 14:25:00 (UTC)
* 終了   : 2026-06-16 14:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→22→20→21→18→20
* 開始   : 2026-06-16 15:00:00 (UTC)
* 終了   : 2026-06-16 15:30:00 (UTC)
* 現象   : 2026-06-16 15:30:00 (UTC)を境に水準が 14.97から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→13→14→16→…→14→12→15→14
* 開始   : 2026-06-16 18:05:00 (UTC)
* 終了   : 2026-06-16 18:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→10→8→10→8→9→8
* 開始   : 2026-06-16 20:40:00 (UTC)
* 終了   : 2026-06-16 20:50:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→14→11→10→14→11→10
* 開始   : 2026-06-17 03:50:00 (UTC)
* 終了   : 2026-06-17 03:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→17→16→15→17→16→12
* 開始   : 2026-06-17 05:35:00 (UTC)
* 終了   : 2026-06-17 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→20→17→20→17→20→19→16
* 開始   : 2026-06-17 07:25:00 (UTC)
* 終了   : 2026-06-17 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→22→20→23→21→20→22→20→21
* 開始   : 2026-06-17 09:00:00 (UTC)
* 終了   : 2026-06-17 09:40:00 (UTC)
* 現象   : 2026-06-17 09:40:00 (UTC)を境に水準が 15.08から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 22→21→23
* 開始   : 2026-06-17 14:35:00 (UTC)
* 終了   : 2026-06-17 14:45:00 (UTC)
* 現象   : 2026-06-17 14:45:00 (UTC)を境に水準が 15.02から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.548, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→16→17→15→16→17
* 開始   : 2026-06-17 16:45:00 (UTC)
* 終了   : 2026-06-17 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→14→11→14→11→12→13
* 開始   : 2026-06-17 19:05:00 (UTC)
* 終了   : 2026-06-17 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→10→8→11→8→11→8→12→8
* 開始   : 2026-06-17 21:10:00 (UTC)
* 終了   : 2026-06-17 21:20:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→5→7→8→6→5→7
* 開始   : 2026-06-17 23:05:00 (UTC)
* 終了   : 2026-06-17 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-080 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260617-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→7→12→9→7→12→9
* 開始   : 2026-06-18 02:15:00 (UTC)
* 終了   : 2026-06-18 02:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→17→22→21→17→22→21
* 開始   : 2026-06-18 08:40:00 (UTC)
* 終了   : 2026-06-18 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→20→18→22→18→22→18→20
* 開始   : 2026-06-18 14:10:00 (UTC)
* 終了   : 2026-06-18 14:20:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host14-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260618-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→15→…→16→15→17→19
* 開始   : 2026-06-18 16:30:00 (UTC)
* 終了   : 2026-06-18 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→15→17→14→15→17→14→18→16
* 開始   : 2026-06-18 16:50:00 (UTC)
* 終了   : 2026-06-18 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→7→…→8→7→10→11
* 開始   : 2026-06-18 20:25:00 (UTC)
* 終了   : 2026-06-18 20:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→10→12→9→12→9→12→11→9
* 開始   : 2026-06-19 02:10:00 (UTC)
* 終了   : 2026-06-19 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.342σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→7→11→7→11→10→9
* 開始   : 2026-06-19 02:20:00 (UTC)
* 終了   : 2026-06-19 02:30:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→13→14→11→10→13→14→11→10
* 開始   : 2026-06-19 03:40:00 (UTC)
* 終了   : 2026-06-19 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→10→14→10→14→11→12
* 開始   : 2026-06-19 04:00:00 (UTC)
* 終了   : 2026-06-19 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→15→14→14→13→14→13→15→17
* 開始   : 2026-06-19 04:20:00 (UTC)
* 終了   : 2026-06-19 05:10:00 (UTC)
* 現象   : 2026-06-19 05:10:00 (UTC)を境に水準が 14.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.811σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→14→18→16→…→16→19→16→15
* 開始   : 2026-06-19 06:25:00 (UTC)
* 終了   : 2026-06-19 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 23→23→24→22→24→22→22
* 開始   : 2026-06-19 12:25:00 (UTC)
* 終了   : 2026-06-19 13:30:00 (UTC)
* 現象   : 2026-06-19 13:30:00 (UTC)を境に水準が 15.09から13.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→20→22→20→20→20→17→18→18
* 開始   : 2026-06-19 14:35:00 (UTC)
* 終了   : 2026-06-19 17:15:00 (UTC)
* 現象   : 2026-06-19 17:15:00 (UTC)を境に水準が 15から12.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→20→17→20→…→17→16→19→18
* 開始   : 2026-06-19 16:00:00 (UTC)
* 終了   : 2026-06-19 16:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→18→15→18→15→17→16
* 開始   : 2026-06-19 16:50:00 (UTC)
* 終了   : 2026-06-19 17:00:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 7→6→11→6→11→6→9
* 開始   : 2026-06-20 01:35:00 (UTC)
* 終了   : 2026-06-20 01:40:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.5倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.544σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→8→10→11→…→8→10→11→10
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 04:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→9→…→9→11→9→8
* 開始   : 2026-06-21 02:25:00 (UTC)
* 終了   : 2026-06-21 02:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.904σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→18→…→12→18→16→14
* 開始   : 2026-06-21 11:25:00 (UTC)
* 終了   : 2026-06-21 11:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→12→11→14→12→11→14→15
* 開始   : 2026-06-21 16:25:00 (UTC)
* 終了   : 2026-06-21 16:30:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→11→9→11→10→8→10→11→12
* 開始   : 2026-06-22 02:20:00 (UTC)
* 終了   : 2026-06-22 03:35:00 (UTC)
* 現象   : 2026-06-22 03:35:00 (UTC)を境に水準が 11.78から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.548, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→12→9→13→12→9→13→10→8
* 開始   : 2026-06-23 02:15:00 (UTC)
* 終了   : 2026-06-23 02:25:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→11→…→14→15→9→13
* 開始   : 2026-06-23 03:55:00 (UTC)
* 終了   : 2026-06-23 04:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.869σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→15→18→17→15→18→15
* 開始   : 2026-06-23 06:00:00 (UTC)
* 終了   : 2026-06-23 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→16→…→17→18→15→16
* 開始   : 2026-06-23 06:25:00 (UTC)
* 終了   : 2026-06-23 06:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→15→…→15→18→17→18
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 06:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host13-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→17→…→17→15→17→18
* 開始   : 2026-06-23 16:25:00 (UTC)
* 終了   : 2026-06-23 16:35:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→12→…→14→12→14→13
* 開始   : 2026-06-23 18:20:00 (UTC)
* 終了   : 2026-06-23 18:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260623-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260623-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→7→8→11→8→11→9→9→9
* 開始   : 2026-06-24 00:55:00 (UTC)
* 終了   : 2026-06-24 01:50:00 (UTC)
* 現象   : 2026-06-24 01:50:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→17→16→15→18
* 開始   : 2026-06-24 06:00:00 (UTC)
* 終了   : 2026-06-24 06:20:00 (UTC)
* 現象   : 2026-06-24 06:20:00 (UTC)を境に水準が 14.93から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.171, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→20→18
* 開始   : 2026-06-24 07:55:00 (UTC)
* 終了   : 2026-06-24 08:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→21→16→22→…→16→22→19→18
* 開始   : 2026-06-24 16:05:00 (UTC)
* 終了   : 2026-06-24 16:10:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→15→12→15→12→15
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→12→…→9→12→7→9
* 開始   : 2026-06-24 21:05:00 (UTC)
* 終了   : 2026-06-24 21:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.716σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→9→11→10→8→8→12
* 開始   : 2026-06-24 21:05:00 (UTC)
* 終了   : 2026-06-24 22:15:00 (UTC)
* 現象   : 2026-06-24 22:15:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.738, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→15→13→15→13→14
* 開始   : 2026-06-25 04:50:00 (UTC)
* 終了   : 2026-06-25 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→15→18→16→15→18→16→15
* 開始   : 2026-06-25 06:35:00 (UTC)
* 終了   : 2026-06-25 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→16→20→21→…→20→21→19→20
* 開始   : 2026-06-25 08:10:00 (UTC)
* 終了   : 2026-06-25 08:15:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 23→21→22→23→24→20→23→21→22
* 開始   : 2026-06-25 09:40:00 (UTC)
* 終了   : 2026-06-25 10:25:00 (UTC)
* 現象   : 2026-06-25 10:25:00 (UTC)を境に水準が 14.96から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.357, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→16→17→19→16→17
* 開始   : 2026-06-25 16:05:00 (UTC)
* 終了   : 2026-06-25 16:10:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→11→15→14→11→15
* 開始   : 2026-06-25 19:05:00 (UTC)
* 終了   : 2026-06-25 19:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→11→…→11→8→12→11
* 開始   : 2026-06-25 20:10:00 (UTC)
* 終了   : 2026-06-25 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→6→9→6→9→6→9→11
* 開始   : 2026-06-25 21:40:00 (UTC)
* 終了   : 2026-06-25 21:50:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→7→12→8→8→11→8
* 開始   : 2026-06-25 23:30:00 (UTC)
* 終了   : 2026-06-26 00:05:00 (UTC)
* 現象   : 2026-06-26 00:05:00 (UTC)を境に水準が 15.05から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.357, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→14→14→13→14→15→17
* 開始   : 2026-06-26 05:10:00 (UTC)
* 終了   : 2026-06-26 05:40:00 (UTC)
* 現象   : 2026-06-26 05:40:00 (UTC)を境に水準が 15.08から14.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.062, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→17→15→18→17→15→16
* 開始   : 2026-06-26 05:50:00 (UTC)
* 終了   : 2026-06-26 05:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.309倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→20→19→21→20
* 開始   : 2026-06-26 08:15:00 (UTC)
* 終了   : 2026-06-26 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→13→…→14→13→15→16
* 開始   : 2026-06-26 17:35:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→16→12→14→16→12→14→13
* 開始   : 2026-06-26 18:30:00 (UTC)
* 終了   : 2026-06-26 18:35:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→11→…→12→11→15→12
* 開始   : 2026-06-26 18:45:00 (UTC)
* 終了   : 2026-06-26 18:50:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→9→9→7→8→10→9→9
* 開始   : 2026-06-28 00:45:00 (UTC)
* 終了   : 2026-06-28 01:20:00 (UTC)
* 現象   : 2026-06-28 01:20:00 (UTC)を境に水準が 11.77から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→9→11→9→10→10→10
* 開始   : 2026-06-28 02:50:00 (UTC)
* 終了   : 2026-06-28 03:45:00 (UTC)
* 現象   : 2026-06-28 03:45:00 (UTC)を境に水準が 11.56から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→16→16→12→14→13→13→15→12
* 開始   : 2026-06-28 15:15:00 (UTC)
* 終了   : 2026-06-28 16:50:00 (UTC)
* 現象   : 2026-06-28 16:50:00 (UTC)を境に水準が 11.9から14.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.714, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→13→14
* 開始   : 2026-06-28 15:55:00 (UTC)
* 終了   : 2026-06-28 16:15:00 (UTC)
* 現象   : 2026-06-28 16:15:00 (UTC)を境に水準が 11.84から14.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→14→…→15→10→13→14
* 開始   : 2026-06-28 17:10:00 (UTC)
* 終了   : 2026-06-28 17:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260628-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→8→9→8→8→10→11
* 開始   : 2026-06-29 00:50:00 (UTC)
* 終了   : 2026-06-29 02:35:00 (UTC)
* 現象   : 2026-06-29 02:35:00 (UTC)を境に水準が 11.77から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→12→7→9→7→9→7→8→9
* 開始   : 2026-06-29 22:00:00 (UTC)
* 終了   : 2026-06-29 22:10:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 7→9→5→9→11→5→9→11→8
* 開始   : 2026-06-29 23:25:00 (UTC)
* 終了   : 2026-06-29 23:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260629-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→23→21→20→23→21→20
* 開始   : 2026-06-30 08:45:00 (UTC)
* 終了   : 2026-06-30 08:50:00 (UTC)
* 現象   : 火曜8時台の平常値(19.17)に対し 23であった
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.004σ 外れた (平常値=19.17)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→9→10→10→12→11→12
* 開始   : 2026-06-30 20:55:00 (UTC)
* 終了   : 2026-06-30 21:25:00 (UTC)
* 現象   : 2026-06-30 21:25:00 (UTC)を境に水準が 14.91から8.516へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host13-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
