# host08 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host08 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 279 (SEVERE: 22, FATAL: 130, WARN: 127, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 130 | 127 | 279 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→14→…→13→14→12→11
* 開始   : 2026-06-08 00:45:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.78から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.813σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.631, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.906, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-001 active_connections の推移](charts/EVT-20260608-host08-001.svg)

# イベントID( EVT-20260608-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→15→16→15→…→13→12→11→14
* 開始   : 2026-06-08 01:40:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.72から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.201, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-002 active_connections の推移](charts/EVT-20260608-host08-002.svg)

# イベントID( EVT-20260608-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→16→14→15→13
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.97から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.968, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-003 active_connections の推移](charts/EVT-20260608-host08-003.svg)

# イベントID( EVT-20260608-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→16→…→18→15→13→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 2026-06-08 21:20:00 (UTC)を境に水準が 11.76から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.396σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.884, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-004 active_connections の推移](charts/EVT-20260608-host08-004.svg)

# イベントID( EVT-20260608-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→17→…→16→14→13→14
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.9から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-005 active_connections の推移](charts/EVT-20260608-host08-005.svg)

# イベントID( EVT-20260608-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→14→…→14→15→12→13
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.247σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.783, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-006 active_connections の推移](charts/EVT-20260608-host08-006.svg)

# イベントID( EVT-20260615-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→13→…→14→16→13→14
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.87から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.077, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-002 active_connections の推移](charts/EVT-20260615-host08-002.svg)

# イベントID( EVT-20260615-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→15→…→15→11→13→10
* 開始   : 2026-06-15 02:50:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.87から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.897, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-003 active_connections の推移](charts/EVT-20260615-host08-003.svg)

# イベントID( EVT-20260615-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→15→…→14→13→14→13
* 開始   : 2026-06-15 03:00:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.84から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.303σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.94, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-004 active_connections の推移](charts/EVT-20260615-host08-004.svg)

# イベントID( EVT-20260615-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→17→…→16→14→11→13
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.005, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-005 active_connections の推移](charts/EVT-20260615-host08-005.svg)

# イベントID( EVT-20260615-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→14→…→12→14→12→13
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.026, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-007 active_connections の推移](charts/EVT-20260615-host08-007.svg)

# イベントID( EVT-20260622-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→14→15→14→…→14→13→11→14
* 開始   : 2026-06-22 02:20:00 (UTC)
* 終了   : 2026-06-22 22:10:00 (UTC)
* 現象   : 2026-06-22 22:10:00 (UTC)を境に水準が 11.89から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.803, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.712, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-003 active_connections の推移](charts/EVT-20260622-host08-003.svg)

# イベントID( EVT-20260622-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→13→15→12→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.667σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.893, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-004 active_connections の推移](charts/EVT-20260622-host08-004.svg)

# イベントID( EVT-20260622-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→16→…→15→14→11→12
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 11.83から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.342, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-005 active_connections の推移](charts/EVT-20260622-host08-005.svg)

# イベントID( EVT-20260622-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→…→13→15→14→13
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 21:00:00 (UTC)
* 現象   : 2026-06-22 21:00:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.192, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-006 active_connections の推移](charts/EVT-20260622-host08-006.svg)

# イベントID( EVT-20260622-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→19→…→16→15→14→13
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 19:00:00 (UTC)
* 現象   : 2026-06-22 19:00:00 (UTC)を境に水準が 11.9から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.245σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.896, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.473, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-007 active_connections の推移](charts/EVT-20260622-host08-007.svg)

# イベントID( EVT-20260629-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→13→14→13→…→15→14→10→14
* 開始   : 2026-06-29 01:45:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.031, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-002 active_connections の推移](charts/EVT-20260629-host08-002.svg)

# イベントID( EVT-20260629-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→14→17→15→…→14→13→12→14
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.418σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.084, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.322, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-003 active_connections の推移](charts/EVT-20260629-host08-003.svg)

# イベントID( EVT-20260629-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→15→…→14→12→14→13
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.175, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-004 active_connections の推移](charts/EVT-20260629-host08-004.svg)

# イベントID( EVT-20260629-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→15→…→14→16→15→14
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.86から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.67, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-005 active_connections の推移](charts/EVT-20260629-host08-005.svg)

# イベントID( EVT-20260629-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→13→12→14→13
* 開始   : 2026-06-29 03:15:00 (UTC)
* 終了   : 2026-06-29 22:10:00 (UTC)
* 現象   : 2026-06-29 22:10:00 (UTC)を境に水準が 11.9から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.247σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.867, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-006 active_connections の推移](charts/EVT-20260629-host08-006.svg)

# イベントID( EVT-20260629-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→19→17→18→…→13→16→12→13
* 開始   : 2026-06-29 03:15:00 (UTC)
* 終了   : 2026-06-29 19:10:00 (UTC)
* 現象   : 2026-06-29 19:10:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.067σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.833, 限界=2.681)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-007 active_connections の推移](charts/EVT-20260629-host08-007.svg)

# イベントID( EVT-20260601-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→13→17→16→13→17→16→13→15
* 開始   : 2026-06-01 05:05:00 (UTC)
* 終了   : 2026-06-01 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260601-host08-002 active_connections の推移](charts/EVT-20260601-host08-002.svg)

# イベントID( EVT-20260601-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→15→20→18→17
* 開始   : 2026-06-01 06:55:00 (UTC)
* 終了   : 2026-06-01 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host08-003 active_connections の推移](charts/EVT-20260601-host08-003.svg)

# イベントID( EVT-20260601-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→17→21→16→17
* 開始   : 2026-06-01 07:35:00 (UTC)
* 終了   : 2026-06-01 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host08-004 active_connections の推移](charts/EVT-20260601-host08-004.svg)

# イベントID( EVT-20260602-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→14→19→17→15
* 開始   : 2026-06-02 06:05:00 (UTC)
* 終了   : 2026-06-02 06:05:00 (UTC)
* 現象   : 平常時(14)に対し 1.357倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-002 active_connections の推移](charts/EVT-20260602-host08-002.svg)

# イベントID( EVT-20260602-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→16→19→15→15
* 開始   : 2026-06-02 06:30:00 (UTC)
* 終了   : 2026-06-02 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host08-004 active_connections の推移](charts/EVT-20260602-host08-004.svg)

# イベントID( EVT-20260602-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→20→21→20→21→19→18
* 開始   : 2026-06-02 07:45:00 (UTC)
* 終了   : 2026-06-02 08:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host08-005 active_connections の推移](charts/EVT-20260602-host08-005.svg)

# イベントID( EVT-20260602-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→20→19→21→20→19
* 開始   : 2026-06-02 07:50:00 (UTC)
* 終了   : 2026-06-02 07:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-006 active_connections の推移](charts/EVT-20260602-host08-006.svg)

# イベントID( EVT-20260602-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→22→17→21→20
* 開始   : 2026-06-02 14:15:00 (UTC)
* 終了   : 2026-06-02 14:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-008 active_connections の推移](charts/EVT-20260602-host08-008.svg)

# イベントID( EVT-20260602-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→22→18→25→…→18→25→20→19
* 開始   : 2026-06-02 14:50:00 (UTC)
* 終了   : 2026-06-02 15:40:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260602-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260602-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-009 active_connections の推移](charts/EVT-20260602-host08-009.svg)

# イベントID( EVT-20260602-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→16→15→18→…→18→14→17→15
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 18:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7965(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.679σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260602-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260602-host08-010 active_connections の推移](charts/EVT-20260602-host08-010.svg)

# イベントID( EVT-20260602-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→15→10→15→12
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 18:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-011 active_connections の推移](charts/EVT-20260602-host08-011.svg)

# イベントID( EVT-20260603-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→11→…→15→13→16→12
* 開始   : 2026-06-03 04:30:00 (UTC)
* 終了   : 2026-06-03 04:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host08-002 active_connections の推移](charts/EVT-20260603-host08-002.svg)

# イベントID( EVT-20260603-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→20→23→19→…→19→21→17→20
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.314倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.85σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host08-005 active_connections の推移](charts/EVT-20260603-host08-005.svg)

# イベントID( EVT-20260603-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→20→26→22→20
* 開始   : 2026-06-03 11:20:00 (UTC)
* 終了   : 2026-06-03 11:20:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.247σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host08-008 active_connections の推移](charts/EVT-20260603-host08-008.svg)

# イベントID( EVT-20260603-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→19→13→16→16
* 開始   : 2026-06-03 16:45:00 (UTC)
* 終了   : 2026-06-03 16:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host08-011 active_connections の推移](charts/EVT-20260603-host08-011.svg)

# イベントID( EVT-20260603-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→12→13→16→12→13→16
* 開始   : 2026-06-03 17:30:00 (UTC)
* 終了   : 2026-06-03 17:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host08-012 active_connections の推移](charts/EVT-20260603-host08-012.svg)

# イベントID( EVT-20260603-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→12→6→9→11
* 開始   : 2026-06-03 21:20:00 (UTC)
* 終了   : 2026-06-03 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host08-015 active_connections の推移](charts/EVT-20260603-host08-015.svg)

# イベントID( EVT-20260604-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→14→8→9
* 開始   : 2026-06-04 03:30:00 (UTC)
* 終了   : 2026-06-04 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host08-001 active_connections の推移](charts/EVT-20260604-host08-001.svg)

# イベントID( EVT-20260604-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→21→17→21→21
* 開始   : 2026-06-04 13:50:00 (UTC)
* 終了   : 2026-06-04 13:50:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-005 active_connections の推移](charts/EVT-20260604-host08-005.svg)

# イベントID( EVT-20260604-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→21→16→20→21
* 開始   : 2026-06-04 14:55:00 (UTC)
* 終了   : 2026-06-04 14:55:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host08-006 active_connections の推移](charts/EVT-20260604-host08-006.svg)

# イベントID( EVT-20260604-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→17→13→16→17
* 開始   : 2026-06-04 17:20:00 (UTC)
* 終了   : 2026-06-04 17:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-008 active_connections の推移](charts/EVT-20260604-host08-008.svg)

# イベントID( EVT-20260604-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→17→15
* 開始   : 2026-06-04 17:35:00 (UTC)
* 終了   : 2026-06-04 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.363σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-009 active_connections の推移](charts/EVT-20260604-host08-009.svg)

# イベントID( EVT-20260604-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→12→13
* 開始   : 2026-06-04 20:00:00 (UTC)
* 終了   : 2026-06-04 20:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.733σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-014 active_connections の推移](charts/EVT-20260604-host08-014.svg)

# イベントID( EVT-20260605-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→11→14→11→9
* 開始   : 2026-06-05 03:15:00 (UTC)
* 終了   : 2026-06-05 03:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-001 active_connections の推移](charts/EVT-20260605-host08-001.svg)

# イベントID( EVT-20260605-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→17→19→17→15
* 開始   : 2026-06-05 06:25:00 (UTC)
* 終了   : 2026-06-05 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-003 active_connections の推移](charts/EVT-20260605-host08-003.svg)

# イベントID( EVT-20260605-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→18→22→16→18
* 開始   : 2026-06-05 07:50:00 (UTC)
* 終了   : 2026-06-05 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-004 active_connections の推移](charts/EVT-20260605-host08-004.svg)

# イベントID( EVT-20260606-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→14→12→11→…→12→11→9→11
* 開始   : 2026-06-06 04:25:00 (UTC)
* 終了   : 2026-06-06 19:50:00 (UTC)
* 現象   : 15.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.418σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.996, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260606-host08-001 active_connections の推移](charts/EVT-20260606-host08-001.svg)

# イベントID( EVT-20260606-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→12→…→13→11→13→12
* 開始   : 2026-06-06 04:30:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host08-002 active_connections の推移](charts/EVT-20260606-host08-002.svg)

# イベントID( EVT-20260606-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→12→…→10→13→14→15
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.955, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host08-003 active_connections の推移](charts/EVT-20260606-host08-003.svg)

# イベントID( EVT-20260606-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→13→…→14→13→14→13
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.122, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host08-004 active_connections の推移](charts/EVT-20260606-host08-004.svg)

# イベントID( EVT-20260606-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→9→10→13→…→11→10→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.114, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host08-005 active_connections の推移](charts/EVT-20260606-host08-005.svg)

# イベントID( EVT-20260606-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→10→…→12→11→12→10
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host08-006 active_connections の推移](charts/EVT-20260606-host08-006.svg)

# イベントID( EVT-20260607-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 7→9→13→9→…→9→5→8→7
* 開始   : 2026-06-07 00:10:00 (UTC)
* 終了   : 2026-06-07 00:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host08-001 active_connections の推移](charts/EVT-20260607-host08-001.svg)

# イベントID( EVT-20260607-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→14→13
* 開始   : 2026-06-07 07:40:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host08-006 active_connections の推移](charts/EVT-20260607-host08-006.svg)

# イベントID( EVT-20260607-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→12→8→10→13
* 開始   : 2026-06-07 16:50:00 (UTC)
* 終了   : 2026-06-07 16:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260607-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host08-007 active_connections の推移](charts/EVT-20260607-host08-007.svg)

# イベントID( EVT-20260609-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→9→10
* 開始   : 2026-06-09 01:45:00 (UTC)
* 終了   : 2026-06-09 01:45:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→20→15→16
* 開始   : 2026-06-09 06:45:00 (UTC)
* 終了   : 2026-06-09 06:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host08-004 active_connections の推移](charts/EVT-20260609-host08-004.svg)

# イベントID( EVT-20260609-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→19→17→21→18→19
* 開始   : 2026-06-09 07:20:00 (UTC)
* 終了   : 2026-06-09 07:45:00 (UTC)
* 現象   : 2026-06-09 07:45:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.067σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→21→16→17→…→16→17→19→18
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260609-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260609-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host08-008 active_connections の推移](charts/EVT-20260609-host08-008.svg)

# イベントID( EVT-20260609-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→19→13→14→…→13→14→17→16
* 開始   : 2026-06-09 17:20:00 (UTC)
* 終了   : 2026-06-09 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host08-009 active_connections の推移](charts/EVT-20260609-host08-009.svg)

# イベントID( EVT-20260609-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→11→13→10→11→13
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 19:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host08-010 active_connections の推移](charts/EVT-20260609-host08-010.svg)

# イベントID( EVT-20260609-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→9→4→6→9
* 開始   : 2026-06-09 22:20:00 (UTC)
* 終了   : 2026-06-09 22:20:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260609-host08-011 active_connections の推移](charts/EVT-20260609-host08-011.svg)

# イベントID( EVT-20260610-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→14→17→15→14→17→14
* 開始   : 2026-06-10 05:00:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host08-001 active_connections の推移](charts/EVT-20260610-host08-001.svg)

# イベントID( EVT-20260610-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→16→18
* 開始   : 2026-06-10 07:15:00 (UTC)
* 終了   : 2026-06-10 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host08-003 active_connections の推移](charts/EVT-20260610-host08-003.svg)

# イベントID( EVT-20260610-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→21→15→19→18
* 開始   : 2026-06-10 15:45:00 (UTC)
* 終了   : 2026-06-10 15:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host08-005 active_connections の推移](charts/EVT-20260610-host08-005.svg)

# イベントID( EVT-20260610-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→12→9→11→12
* 開始   : 2026-06-10 19:15:00 (UTC)
* 終了   : 2026-06-10 19:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host08-006 active_connections の推移](charts/EVT-20260610-host08-006.svg)

# イベントID( EVT-20260610-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→11→9→11→14
* 開始   : 2026-06-10 19:40:00 (UTC)
* 終了   : 2026-06-10 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host08-007 active_connections の推移](charts/EVT-20260610-host08-007.svg)

# イベントID( EVT-20260611-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→16→15
* 開始   : 2026-06-11 06:15:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host08-002 active_connections の推移](charts/EVT-20260611-host08-002.svg)

# イベントID( EVT-20260611-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→17→11→16→15
* 開始   : 2026-06-11 17:15:00 (UTC)
* 終了   : 2026-06-11 17:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.6256(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.535σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-010 active_connections の推移](charts/EVT-20260611-host08-010.svg)

# イベントID( EVT-20260612-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→6→12→9→10
* 開始   : 2026-06-12 01:35:00 (UTC)
* 終了   : 2026-06-12 01:35:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host08-001 active_connections の推移](charts/EVT-20260612-host08-001.svg)

# イベントID( EVT-20260612-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→9→4→8→12→4→8→12→10
* 開始   : 2026-06-12 01:40:00 (UTC)
* 終了   : 2026-06-12 01:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host08-002 active_connections の推移](charts/EVT-20260612-host08-002.svg)

# イベントID( EVT-20260612-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→19→18→17→22→18→20→18→21
* 開始   : 2026-06-12 07:20:00 (UTC)
* 終了   : 2026-06-12 08:20:00 (UTC)
* 現象   : 2026-06-12 08:20:00 (UTC)を境に水準が 15.05から14.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→16→23→19→19
* 開始   : 2026-06-12 08:50:00 (UTC)
* 終了   : 2026-06-12 08:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host08-005 active_connections の推移](charts/EVT-20260612-host08-005.svg)

# イベントID( EVT-20260612-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→19→19
* 開始   : 2026-06-12 09:15:00 (UTC)
* 終了   : 2026-06-12 09:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.266倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host08-006 active_connections の推移](charts/EVT-20260612-host08-006.svg)

# イベントID( EVT-20260612-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→21→17→24→22→21→17→24→22
* 開始   : 2026-06-12 14:05:00 (UTC)
* 終了   : 2026-06-12 14:10:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→8→12→11
* 開始   : 2026-06-12 20:05:00 (UTC)
* 終了   : 2026-06-12 20:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host08-011 active_connections の推移](charts/EVT-20260612-host08-011.svg)

# イベントID( EVT-20260612-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→13→8→13→8→13→9
* 開始   : 2026-06-12 20:55:00 (UTC)
* 終了   : 2026-06-12 22:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host08-012 active_connections の推移](charts/EVT-20260612-host08-012.svg)

# イベントID( EVT-20260612-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→5→8→9
* 開始   : 2026-06-12 22:30:00 (UTC)
* 終了   : 2026-06-12 23:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260612-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-084 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host08-013 active_connections の推移](charts/EVT-20260612-host08-013.svg)

# イベントID( EVT-20260612-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→9→4→7→10
* 開始   : 2026-06-12 23:20:00 (UTC)
* 終了   : 2026-06-12 23:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 6→11→4→8→10
* 開始   : 2026-06-13 00:30:00 (UTC)
* 終了   : 2026-06-13 00:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host08-001 active_connections の推移](charts/EVT-20260613-host08-001.svg)

# イベントID( EVT-20260613-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→10→…→13→11→14→13
* 開始   : 2026-06-13 03:50:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260613-host08-003 active_connections の推移](charts/EVT-20260613-host08-003.svg)

# イベントID( EVT-20260613-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→…→10→12→8→11
* 開始   : 2026-06-13 04:25:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.099, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host08-004 active_connections の推移](charts/EVT-20260613-host08-004.svg)

# イベントID( EVT-20260613-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→12→9→10→…→12→13→14→13
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host08-005 active_connections の推移](charts/EVT-20260613-host08-005.svg)

# イベントID( EVT-20260613-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→9→10→12→…→9→13→9→11
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.083, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.2 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host08-006 active_connections の推移](charts/EVT-20260613-host08-006.svg)

# イベントID( EVT-20260613-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→11→…→13→10→13→9
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.781, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host08-007 active_connections の推移](charts/EVT-20260613-host08-007.svg)

# イベントID( EVT-20260613-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→11→…→10→11→12→13
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.88, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260613-host08-008 active_connections の推移](charts/EVT-20260613-host08-008.svg)

# イベントID( EVT-20260614-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→10→14→9→12
* 開始   : 2026-06-14 04:00:00 (UTC)
* 終了   : 2026-06-14 04:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.514倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260614-host08-001 active_connections の推移](charts/EVT-20260614-host08-001.svg)

# イベントID( EVT-20260614-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→10→16→10→13
* 開始   : 2026-06-14 05:45:00 (UTC)
* 終了   : 2026-06-14 05:45:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host08-002 active_connections の推移](charts/EVT-20260614-host08-002.svg)

# イベントID( EVT-20260614-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→18→13→14
* 開始   : 2026-06-14 07:15:00 (UTC)
* 終了   : 2026-06-14 07:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.412倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host08-003 active_connections の推移](charts/EVT-20260614-host08-003.svg)

# イベントID( EVT-20260615-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→14→…→15→19→17→15
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 11.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.924, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-006 active_connections の推移](charts/EVT-20260615-host08-006.svg)

# イベントID( EVT-20260616-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→16→20→15→16
* 開始   : 2026-06-16 06:45:00 (UTC)
* 終了   : 2026-06-16 06:45:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-003 active_connections の推移](charts/EVT-20260616-host08-003.svg)

# イベントID( EVT-20260616-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→19→18→15→19→18
* 開始   : 2026-06-16 06:45:00 (UTC)
* 終了   : 2026-06-16 07:15:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host08-004 active_connections の推移](charts/EVT-20260616-host08-004.svg)

# イベントID( EVT-20260616-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→18→24→19→18
* 開始   : 2026-06-16 09:00:00 (UTC)
* 終了   : 2026-06-16 09:00:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host08-005 active_connections の推移](charts/EVT-20260616-host08-005.svg)

# イベントID( EVT-20260616-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→12→13
* 開始   : 2026-06-16 19:25:00 (UTC)
* 終了   : 2026-06-16 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host08-010 active_connections の推移](charts/EVT-20260616-host08-010.svg)

# イベントID( EVT-20260616-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→12→9→13→11
* 開始   : 2026-06-16 19:45:00 (UTC)
* 終了   : 2026-06-16 19:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host08-011 active_connections の推移](charts/EVT-20260616-host08-011.svg)

# イベントID( EVT-20260617-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→18→20→21→…→17→20→18→19
* 開始   : 2026-06-17 07:40:00 (UTC)
* 終了   : 2026-06-17 08:50:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 20 分
  - EVT-20260617-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host08-002 active_connections の推移](charts/EVT-20260617-host08-002.svg)

# イベントID( EVT-20260617-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→19→23→20→21
* 開始   : 2026-06-17 08:30:00 (UTC)
* 終了   : 2026-06-17 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.284倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host08-003 active_connections の推移](charts/EVT-20260617-host08-003.svg)

# イベントID( EVT-20260617-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→19→21→20→…→21→20→23→20
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 09:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-009 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分

![EVT-20260617-host08-004 active_connections の推移](charts/EVT-20260617-host08-004.svg)

# イベントID( EVT-20260617-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→23→21
* 開始   : 2026-06-17 14:20:00 (UTC)
* 終了   : 2026-06-17 14:20:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→21→16→18→18
* 開始   : 2026-06-17 15:30:00 (UTC)
* 終了   : 2026-06-17 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host08-007 active_connections の推移](charts/EVT-20260617-host08-007.svg)

# イベントID( EVT-20260617-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→21→19→18→17→20→20
* 開始   : 2026-06-17 16:15:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 2026-06-17 17:20:00 (UTC)を境に水準が 14.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.823, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→13→11→14→15
* 開始   : 2026-06-17 18:20:00 (UTC)
* 終了   : 2026-06-17 18:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host08-009 active_connections の推移](charts/EVT-20260617-host08-009.svg)

# イベントID( EVT-20260618-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→17→20→15→16→19
* 開始   : 2026-06-18 05:55:00 (UTC)
* 終了   : 2026-06-18 06:50:00 (UTC)
* 現象   : 2026-06-18 06:50:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→17→20→19→…→19→20→19→18
* 開始   : 2026-06-18 07:20:00 (UTC)
* 終了   : 2026-06-18 07:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.247σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host08-003 active_connections の推移](charts/EVT-20260618-host08-003.svg)

# イベントID( EVT-20260618-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→18→14→18→17
* 開始   : 2026-06-18 16:05:00 (UTC)
* 終了   : 2026-06-18 16:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-006 active_connections の推移](charts/EVT-20260618-host08-006.svg)

# イベントID( EVT-20260618-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→10→7→12→9
* 開始   : 2026-06-18 20:35:00 (UTC)
* 終了   : 2026-06-18 20:35:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host08-008 active_connections の推移](charts/EVT-20260618-host08-008.svg)

# イベントID( EVT-20260619-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→10→14→12→12
* 開始   : 2026-06-19 03:35:00 (UTC)
* 終了   : 2026-06-19 03:35:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→15→18→19→15→18→17
* 開始   : 2026-06-19 06:25:00 (UTC)
* 終了   : 2026-06-19 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host08-004 active_connections の推移](charts/EVT-20260619-host08-004.svg)

# イベントID( EVT-20260619-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→18→15→18→18
* 開始   : 2026-06-19 16:05:00 (UTC)
* 終了   : 2026-06-19 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-008 active_connections の推移](charts/EVT-20260619-host08-008.svg)

# イベントID( EVT-20260619-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→13→14→15→13→14→15
* 開始   : 2026-06-19 17:35:00 (UTC)
* 終了   : 2026-06-19 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host08-009 active_connections の推移](charts/EVT-20260619-host08-009.svg)

# イベントID( EVT-20260619-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→14→9→11→14→9→11→12
* 開始   : 2026-06-19 20:10:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260619-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-011 active_connections の推移](charts/EVT-20260619-host08-011.svg)

# イベントID( EVT-20260619-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→12→7→11→10
* 開始   : 2026-06-19 20:45:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-012 active_connections の推移](charts/EVT-20260619-host08-012.svg)

# イベントID( EVT-20260619-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→10→9
* 開始   : 2026-06-19 21:10:00 (UTC)
* 終了   : 2026-06-19 21:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-081 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260619-host08-013 active_connections の推移](charts/EVT-20260619-host08-013.svg)

# イベントID( EVT-20260619-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→9→5→10→9
* 開始   : 2026-06-19 22:35:00 (UTC)
* 終了   : 2026-06-19 22:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host08-014 active_connections の推移](charts/EVT-20260619-host08-014.svg)

# イベントID( EVT-20260620-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→12→9→14→…→13→12→13→12
* 開始   : 2026-06-20 04:25:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.245σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.782, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host08-002 active_connections の推移](charts/EVT-20260620-host08-002.svg)

# イベントID( EVT-20260620-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→11→…→13→12→10→13
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host08-003 active_connections の推移](charts/EVT-20260620-host08-003.svg)

# イベントID( EVT-20260620-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→…→13→11→13→11
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 20:40:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.697, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host08-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.6 時間
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間

![EVT-20260620-host08-004 active_connections の推移](charts/EVT-20260620-host08-004.svg)

# イベントID( EVT-20260620-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→12→…→11→10→13→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host08-005 active_connections の推移](charts/EVT-20260620-host08-005.svg)

# イベントID( EVT-20260620-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→11→…→11→13→12→11
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.131, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host08-006 active_connections の推移](charts/EVT-20260620-host08-006.svg)

# イベントID( EVT-20260620-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→13→…→13→12→13→12
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間

![EVT-20260620-host08-007 active_connections の推移](charts/EVT-20260620-host08-007.svg)

# イベントID( EVT-20260621-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→12→18→14→16
* 開始   : 2026-06-21 08:45:00 (UTC)
* 終了   : 2026-06-21 08:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-003 active_connections の推移](charts/EVT-20260621-host08-003.svg)

# イベントID( EVT-20260621-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→19→12→13
* 開始   : 2026-06-21 15:05:00 (UTC)
* 終了   : 2026-06-21 15:05:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-005 active_connections の推移](charts/EVT-20260621-host08-005.svg)

# イベントID( EVT-20260621-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→6→11→7→6→11→7→9→11
* 開始   : 2026-06-21 20:50:00 (UTC)
* 終了   : 2026-06-21 21:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host08-006 active_connections の推移](charts/EVT-20260621-host08-006.svg)

# イベントID( EVT-20260621-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→10→5→10→11
* 開始   : 2026-06-21 22:45:00 (UTC)
* 終了   : 2026-06-21 22:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→17→…→14→13→11→12
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 19:25:00 (UTC)
* 現象   : 2026-06-22 19:25:00 (UTC)を境に水準が 11.77から15.16へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-002 active_connections の推移](charts/EVT-20260622-host08-002.svg)

# イベントID( EVT-20260623-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→9→10
* 開始   : 2026-06-23 01:30:00 (UTC)
* 終了   : 2026-06-23 01:30:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.677倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host08-001 active_connections の推移](charts/EVT-20260623-host08-001.svg)

# イベントID( EVT-20260623-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→10→8
* 開始   : 2026-06-23 20:55:00 (UTC)
* 終了   : 2026-06-23 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-007 active_connections の推移](charts/EVT-20260623-host08-007.svg)

# イベントID( EVT-20260623-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→8→9
* 開始   : 2026-06-23 22:15:00 (UTC)
* 終了   : 2026-06-23 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→11→14→10→13
* 開始   : 2026-06-24 03:25:00 (UTC)
* 終了   : 2026-06-24 03:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host08-001 active_connections の推移](charts/EVT-20260624-host08-001.svg)

# イベントID( EVT-20260625-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→12→15→12→11
* 開始   : 2026-06-25 04:05:00 (UTC)
* 終了   : 2026-06-25 04:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-001 active_connections の推移](charts/EVT-20260625-host08-001.svg)

# イベントID( EVT-20260625-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→15→13→17→15
* 開始   : 2026-06-25 05:35:00 (UTC)
* 終了   : 2026-06-25 05:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.705σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host08-003 active_connections の推移](charts/EVT-20260625-host08-003.svg)

# イベントID( EVT-20260625-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→17→18→15→17→18→15→18
* 開始   : 2026-06-25 16:15:00 (UTC)
* 終了   : 2026-06-25 16:25:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-006 active_connections の推移](charts/EVT-20260625-host08-006.svg)

# イベントID( EVT-20260625-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→11→11
* 開始   : 2026-06-25 20:10:00 (UTC)
* 終了   : 2026-06-25 20:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.5793(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host08-010 active_connections の推移](charts/EVT-20260625-host08-010.svg)

# イベントID( EVT-20260626-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→14→18→15→…→15→17→14→17
* 開始   : 2026-06-26 05:45:00 (UTC)
* 終了   : 2026-06-26 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host08-001 active_connections の推移](charts/EVT-20260626-host08-001.svg)

# イベントID( EVT-20260626-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→20→19
* 開始   : 2026-06-26 08:35:00 (UTC)
* 終了   : 2026-06-26 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.296倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.653σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260626-host08-003 active_connections の推移](charts/EVT-20260626-host08-003.svg)

# イベントID( EVT-20260627-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 7→10→13→7→10
* 開始   : 2026-06-27 01:55:00 (UTC)
* 終了   : 2026-06-27 01:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host08-001 active_connections の推移](charts/EVT-20260627-host08-001.svg)

# イベントID( EVT-20260627-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→12→…→10→12→10→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.681)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host08-002 active_connections の推移](charts/EVT-20260627-host08-002.svg)

# イベントID( EVT-20260627-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→12→9→12→…→11→12→13→11
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 4.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.053, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host08-003 active_connections の推移](charts/EVT-20260627-host08-003.svg)

# イベントID( EVT-20260627-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→11→…→11→9→11→9
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.272, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host08-004 active_connections の推移](charts/EVT-20260627-host08-004.svg)

# イベントID( EVT-20260627-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→14→13→…→11→13→14→13
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.187σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.803, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host08-005 active_connections の推移](charts/EVT-20260627-host08-005.svg)

# イベントID( EVT-20260627-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→11→…→10→11→12→10
* 開始   : 2026-06-27 06:30:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.783, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.1 時間

![EVT-20260627-host08-006 active_connections の推移](charts/EVT-20260627-host08-006.svg)

# イベントID( EVT-20260627-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→14→12→14→…→12→14→12→13
* 開始   : 2026-06-27 06:35:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.755, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host08-007 active_connections の推移](charts/EVT-20260627-host08-007.svg)

# イベントID( EVT-20260627-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→8→6→…→8→6→9→10
* 開始   : 2026-06-27 19:50:00 (UTC)
* 終了   : 2026-06-27 19:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260627-host08-008 active_connections の推移](charts/EVT-20260627-host08-008.svg)

# イベントID( EVT-20260627-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→7→14→7→8
* 開始   : 2026-06-27 21:15:00 (UTC)
* 終了   : 2026-06-27 21:15:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host08-009 active_connections の推移](charts/EVT-20260627-host08-009.svg)

# イベントID( EVT-20260628-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→17→20→15→17
* 開始   : 2026-06-28 11:00:00 (UTC)
* 終了   : 2026-06-28 11:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host08-003 active_connections の推移](charts/EVT-20260628-host08-003.svg)

# イベントID( EVT-20260628-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→7→11→10
* 開始   : 2026-06-28 19:25:00 (UTC)
* 終了   : 2026-06-28 19:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host08-005 active_connections の推移](charts/EVT-20260628-host08-005.svg)

# イベントID( EVT-20260629-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 7→7→12→8→9
* 開始   : 2026-06-29 00:50:00 (UTC)
* 終了   : 2026-06-29 00:50:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 25→22→25→23→23→23
* 開始   : 2026-06-30 12:35:00 (UTC)
* 終了   : 2026-06-30 13:35:00 (UTC)
* 現象   : 2026-06-30 13:35:00 (UTC)を境に水準が 15.07から14.45へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.328, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→17→17
* 開始   : 2026-06-30 17:20:00 (UTC)
* 終了   : 2026-06-30 17:20:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host08-007 active_connections の推移](charts/EVT-20260630-host08-007.svg)

# イベントID( EVT-20260630-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→14→18→14→…→14→11→12→14
* 開始   : 2026-06-30 18:50:00 (UTC)
* 終了   : 2026-06-30 20:40:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260630-host05-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260630-host08-008 active_connections の推移](charts/EVT-20260630-host08-008.svg)

# イベントID( EVT-20260601-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→11→10→12→11→9
* 開始   : 2026-06-01 02:15:00 (UTC)
* 終了   : 2026-06-01 02:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→20→19→22→20→21
* 開始   : 2026-06-01 08:25:00 (UTC)
* 終了   : 2026-06-01 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.228倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.841σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→15→17
* 開始   : 2026-06-01 16:35:00 (UTC)
* 終了   : 2026-06-01 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260601-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→14→15→14→15→14→17
* 開始   : 2026-06-01 17:35:00 (UTC)
* 終了   : 2026-06-01 17:45:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→10→9→10→9→11→9
* 開始   : 2026-06-01 20:15:00 (UTC)
* 終了   : 2026-06-01 20:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→8→10→6→8
* 開始   : 2026-06-01 22:05:00 (UTC)
* 終了   : 2026-06-01 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→7→5→8→5→8→5→7→9
* 開始   : 2026-06-02 01:25:00 (UTC)
* 終了   : 2026-06-02 01:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260602-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→16→13→17→16→15
* 開始   : 2026-06-02 06:05:00 (UTC)
* 終了   : 2026-06-02 06:10:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→20→24→22→…→22→17→21→19
* 開始   : 2026-06-02 09:25:00 (UTC)
* 終了   : 2026-06-02 09:35:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.195倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.705σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260602-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→8→11→10→8→11→8
* 開始   : 2026-06-02 21:05:00 (UTC)
* 終了   : 2026-06-02 21:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→6→…→6→12→11→10
* 開始   : 2026-06-03 02:25:00 (UTC)
* 終了   : 2026-06-03 02:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→17→…→16→17→12→14
* 開始   : 2026-06-03 05:25:00 (UTC)
* 終了   : 2026-06-03 05:30:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→18→21→18→21→18→21
* 開始   : 2026-06-03 08:05:00 (UTC)
* 終了   : 2026-06-03 08:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→20→22→21→22→21→22→21
* 開始   : 2026-06-03 08:55:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 21→20→23→21→24→23→21→24→21
* 開始   : 2026-06-03 09:40:00 (UTC)
* 終了   : 2026-06-03 09:50:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260603-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→23→21→24→22
* 開始   : 2026-06-03 11:25:00 (UTC)
* 終了   : 2026-06-03 11:45:00 (UTC)
* 現象   : 2026-06-03 11:45:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→18→21→17→18→21→17→19→21
* 開始   : 2026-06-03 14:55:00 (UTC)
* 終了   : 2026-06-03 15:05:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→14→16→14→16→15→15→16
* 開始   : 2026-06-03 18:15:00 (UTC)
* 終了   : 2026-06-03 18:50:00 (UTC)
* 現象   : 2026-06-03 18:50:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→14→13→14→13→15→14→13→13
* 開始   : 2026-06-03 19:25:00 (UTC)
* 終了   : 2026-06-03 20:05:00 (UTC)
* 現象   : 2026-06-03 20:05:00 (UTC)を境に水準が 15.04から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→19→21→17→19→21→17→20
* 開始   : 2026-06-04 07:55:00 (UTC)
* 終了   : 2026-06-04 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→21→18→21→18→21→20→19
* 開始   : 2026-06-04 08:15:00 (UTC)
* 終了   : 2026-06-04 08:25:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→19→21→20→19→21→20→19
* 開始   : 2026-06-04 08:35:00 (UTC)
* 終了   : 2026-06-04 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→21→16→21→16→21→20
* 開始   : 2026-06-04 15:45:00 (UTC)
* 終了   : 2026-06-04 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→12→16→…→15→12→16→13
* 開始   : 2026-06-04 18:15:00 (UTC)
* 終了   : 2026-06-04 18:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260604-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→11→…→14→11→14→12
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260604-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260604-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→16→11→10→…→11→10→13→14
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260604-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→11→15→11→15→11→14→13
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.85σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260604-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 15 分

![EVT-20260604-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→14→13→16→14→15
* 開始   : 2026-06-05 05:35:00 (UTC)
* 終了   : 2026-06-05 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→21→19→17→21→19
* 開始   : 2026-06-05 08:00:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 22→22→22→20→20→23→20→23→21
* 開始   : 2026-06-05 13:40:00 (UTC)
* 終了   : 2026-06-05 14:25:00 (UTC)
* 現象   : 2026-06-05 14:25:00 (UTC)を境に水準が 15.04から12.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.175, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→22→22→21→21→21→21→21→21
* 開始   : 2026-06-05 14:05:00 (UTC)
* 終了   : 2026-06-05 14:50:00 (UTC)
* 現象   : 2026-06-05 14:50:00 (UTC)を境に水準が 15.01から12.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→10→…→11→10→13→11
* 開始   : 2026-06-05 19:10:00 (UTC)
* 終了   : 2026-06-05 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→15→11→10→12→15→11→10→12
* 開始   : 2026-06-05 19:10:00 (UTC)
* 終了   : 2026-06-05 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→8→11→7→8→11
* 開始   : 2026-06-05 21:05:00 (UTC)
* 終了   : 2026-06-05 21:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-090 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→6→…→11→6→10→9
* 開始   : 2026-06-05 22:45:00 (UTC)
* 終了   : 2026-06-05 23:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→9→5→9→5→8→7
* 開始   : 2026-06-06 23:25:00 (UTC)
* 終了   : 2026-06-06 23:35:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→10→5→6→11→5→6→11→9
* 開始   : 2026-06-07 02:35:00 (UTC)
* 終了   : 2026-06-07 02:45:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.354σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→9→12→9→10
* 開始   : 2026-06-07 03:05:00 (UTC)
* 終了   : 2026-06-07 03:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→10→12→10→12→10→12→10→11
* 開始   : 2026-06-07 03:25:00 (UTC)
* 終了   : 2026-06-07 03:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260607-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→11→13→12→…→12→14→10→11
* 開始   : 2026-06-07 04:50:00 (UTC)
* 終了   : 2026-06-07 05:00:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260607-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→8→9→14→8→9→14→10
* 開始   : 2026-06-07 18:50:00 (UTC)
* 終了   : 2026-06-07 19:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→6→7→6→7→6→8→10
* 開始   : 2026-06-07 21:50:00 (UTC)
* 終了   : 2026-06-07 22:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.85σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→6→11→7→…→7→11→9→10
* 開始   : 2026-06-09 01:10:00 (UTC)
* 終了   : 2026-06-09 01:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.475σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-002 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→13→13→14→14→16→14→16→16
* 開始   : 2026-06-09 04:25:00 (UTC)
* 終了   : 2026-06-09 05:25:00 (UTC)
* 現象   : 2026-06-09 05:25:00 (UTC)を境に水準が 14.88から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→21→21→21→20→17→19→17→20
* 開始   : 2026-06-09 15:10:00 (UTC)
* 終了   : 2026-06-09 17:30:00 (UTC)
* 現象   : 2026-06-09 17:30:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.354σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→21→17→22→17→22→17→18
* 開始   : 2026-06-09 15:25:00 (UTC)
* 終了   : 2026-06-09 15:35:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→14→15→17→14
* 開始   : 2026-06-10 05:35:00 (UTC)
* 終了   : 2026-06-10 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→20→21→20→21→20
* 開始   : 2026-06-10 08:35:00 (UTC)
* 終了   : 2026-06-10 08:40:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→9→…→9→6→10→7
* 開始   : 2026-06-10 22:30:00 (UTC)
* 終了   : 2026-06-10 22:40:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→12→15→14→15→14→15→14
* 開始   : 2026-06-11 05:00:00 (UTC)
* 終了   : 2026-06-11 05:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→21→18→…→18→14→19→18
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.917σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→19→19→18→19→19→21→20→21
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 08:45:00 (UTC)
* 現象   : 2026-06-11 08:45:00 (UTC)を境に水準が 15.09から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→20→21→18→20→18
* 開始   : 2026-06-11 15:00:00 (UTC)
* 終了   : 2026-06-11 15:05:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→20→20→22→22→19→20→19→20
* 開始   : 2026-06-11 15:00:00 (UTC)
* 終了   : 2026-06-11 16:10:00 (UTC)
* 現象   : 2026-06-11 16:10:00 (UTC)を境に水準が 14.92から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→19→17→19→17→19→20
* 開始   : 2026-06-11 15:05:00 (UTC)
* 終了   : 2026-06-11 15:10:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→14→15→19→14→18→17
* 開始   : 2026-06-11 16:35:00 (UTC)
* 終了   : 2026-06-11 16:45:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→18→14→16→…→14→18→13→16
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.417σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→12→16→12→16→12→15→12
* 開始   : 2026-06-11 18:45:00 (UTC)
* 終了   : 2026-06-11 18:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→11→13→10→11
* 開始   : 2026-06-11 19:50:00 (UTC)
* 終了   : 2026-06-11 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→10→…→10→7→10→9
* 開始   : 2026-06-11 20:20:00 (UTC)
* 終了   : 2026-06-11 21:05:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260611-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→9→8→11
* 開始   : 2026-06-11 23:30:00 (UTC)
* 終了   : 2026-06-11 23:45:00 (UTC)
* 現象   : 2026-06-11 23:45:00 (UTC)を境に水準が 15.01から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.684, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→10→…→12→13→10→11
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 03:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→20→19→19→17→18→19
* 開始   : 2026-06-12 16:15:00 (UTC)
* 終了   : 2026-06-12 16:45:00 (UTC)
* 現象   : 2026-06-12 16:45:00 (UTC)を境に水準が 15.11から12.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.949, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→18→16→15→…→17→15→16→18
* 開始   : 2026-06-12 16:30:00 (UTC)
* 終了   : 2026-06-12 16:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→17→16→18→14→16→16→18→16
* 開始   : 2026-06-12 17:15:00 (UTC)
* 終了   : 2026-06-12 19:05:00 (UTC)
* 現象   : 2026-06-12 19:05:00 (UTC)を境に水準が 14.85から12.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.052, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→12→…→11→12→7→9
* 開始   : 2026-06-13 01:50:00 (UTC)
* 終了   : 2026-06-13 01:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→10→14→10→14→11
* 開始   : 2026-06-13 20:05:00 (UTC)
* 終了   : 2026-06-13 20:15:00 (UTC)
* 現象   : 土曜20時台の平常値(9.851)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.187σ 外れた (平常値=9.851)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260613-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→17→15→16→16→17→15→16→17
* 開始   : 2026-06-14 09:35:00 (UTC)
* 終了   : 2026-06-14 11:05:00 (UTC)
* 現象   : 2026-06-14 11:05:00 (UTC)を境に水準が 11.78から13.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→16→16→17→16→16→17→17→17
* 開始   : 2026-06-14 12:10:00 (UTC)
* 終了   : 2026-06-14 12:55:00 (UTC)
* 現象   : 2026-06-14 12:55:00 (UTC)を境に水準が 11.92から13.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→10→12→10→11→10
* 開始   : 2026-06-14 16:55:00 (UTC)
* 終了   : 2026-06-14 17:05:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.647σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→14→13→11→12→13→13
* 開始   : 2026-06-14 17:15:00 (UTC)
* 終了   : 2026-06-14 18:25:00 (UTC)
* 現象   : 2026-06-14 18:25:00 (UTC)を境に水準が 11.82から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.564, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→13→8→12→8→12→8→11→10
* 開始   : 2026-06-14 18:15:00 (UTC)
* 終了   : 2026-06-14 18:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→5→8→9→…→5→8→5→8
* 開始   : 2026-06-15 00:20:00 (UTC)
* 終了   : 2026-06-15 00:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260615-lsfhost01-002 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260615-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→11→9→9
* 開始   : 2026-06-15 22:35:00 (UTC)
* 終了   : 2026-06-15 23:00:00 (UTC)
* 現象   : 2026-06-15 23:00:00 (UTC)を境に水準が 15.05から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 6→9→9→9→9→8→9→9→11
* 開始   : 2026-06-16 00:20:00 (UTC)
* 終了   : 2026-06-16 01:05:00 (UTC)
* 現象   : 2026-06-16 01:05:00 (UTC)を境に水準が 15.01から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→12→13→12→13→11
* 開始   : 2026-06-16 03:30:00 (UTC)
* 終了   : 2026-06-16 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→18→19→21→18→19→21
* 開始   : 2026-06-16 14:30:00 (UTC)
* 終了   : 2026-06-16 14:35:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.417σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→18→17→16→…→17→16→17→18
* 開始   : 2026-06-16 15:50:00 (UTC)
* 終了   : 2026-06-16 15:55:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→15→16→15→15→16→14→15→15
* 開始   : 2026-06-16 17:55:00 (UTC)
* 終了   : 2026-06-16 18:45:00 (UTC)
* 現象   : 2026-06-16 18:45:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→12→…→13→12→15→14
* 開始   : 2026-06-16 18:05:00 (UTC)
* 終了   : 2026-06-16 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→9→…→9→7→10→8
* 開始   : 2026-06-16 21:35:00 (UTC)
* 終了   : 2026-06-16 21:45:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→13→8→…→8→14→13→10
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:40:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→22→25→21→22→21→23→24→22
* 開始   : 2026-06-17 12:10:00 (UTC)
* 終了   : 2026-06-17 14:40:00 (UTC)
* 現象   : 2026-06-17 14:40:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.239σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.052, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→12→11→10→12→11
* 開始   : 2026-06-17 19:25:00 (UTC)
* 終了   : 2026-06-17 19:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→9→11→9→13
* 開始   : 2026-06-17 20:15:00 (UTC)
* 終了   : 2026-06-17 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.239σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260617-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→11→12→11→12→11→10
* 開始   : 2026-06-18 03:00:00 (UTC)
* 終了   : 2026-06-18 03:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→23→20→23→22→23→22
* 開始   : 2026-06-18 09:30:00 (UTC)
* 終了   : 2026-06-18 09:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→16→19→17→16→19→18
* 開始   : 2026-06-18 15:45:00 (UTC)
* 終了   : 2026-06-18 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host14-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→13→…→14→13→18→16
* 開始   : 2026-06-18 17:20:00 (UTC)
* 終了   : 2026-06-18 17:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→13→12→14→13→12→14→10→12
* 開始   : 2026-06-19 03:55:00 (UTC)
* 終了   : 2026-06-19 04:05:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→14→15→14→16→15→14→16→15
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 04:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→20→…→20→22→21→20
* 開始   : 2026-06-19 08:30:00 (UTC)
* 終了   : 2026-06-19 08:40:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 22→21→25→22→25→22
* 開始   : 2026-06-19 13:20:00 (UTC)
* 終了   : 2026-06-19 13:45:00 (UTC)
* 現象   : 2026-06-19 13:45:00 (UTC)を境に水準が 15.01から12.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.817, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→20→17→20→17→20→18
* 開始   : 2026-06-19 15:35:00 (UTC)
* 終了   : 2026-06-19 15:40:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→16→13→18→13→18→15→14
* 開始   : 2026-06-19 18:05:00 (UTC)
* 終了   : 2026-06-19 18:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260619-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→8→9→9→9→10→9→8→9
* 開始   : 2026-06-19 23:45:00 (UTC)
* 終了   : 2026-06-20 00:25:00 (UTC)
* 現象   : 2026-06-20 00:25:00 (UTC)を境に水準が 14.86から11.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→6→11→8→5→11→8→5→9
* 開始   : 2026-06-20 01:45:00 (UTC)
* 終了   : 2026-06-20 01:55:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→11→9→10→11→9→10→11
* 開始   : 2026-06-20 19:20:00 (UTC)
* 終了   : 2026-06-20 19:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.881, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260620-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→8→7→8→…→8→7→11→10
* 開始   : 2026-06-20 20:40:00 (UTC)
* 終了   : 2026-06-20 20:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.899, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→7→12→10→12→10→12→10
* 開始   : 2026-06-21 03:15:00 (UTC)
* 終了   : 2026-06-21 03:25:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260621-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→13→13→11→14→12
* 開始   : 2026-06-21 05:10:00 (UTC)
* 終了   : 2026-06-21 05:45:00 (UTC)
* 現象   : 2026-06-21 05:45:00 (UTC)を境に水準が 11.76から12.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.368, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→15→16→15→17→16→17
* 開始   : 2026-06-21 09:10:00 (UTC)
* 終了   : 2026-06-21 09:40:00 (UTC)
* 現象   : 2026-06-21 09:40:00 (UTC)を境に水準が 11.88から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→5→…→11→5→7→8
* 開始   : 2026-06-22 00:15:00 (UTC)
* 終了   : 2026-06-22 00:20:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260622-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→11→11→11→9→10→9→7→10
* 開始   : 2026-06-22 20:55:00 (UTC)
* 終了   : 2026-06-22 21:55:00 (UTC)
* 現象   : 2026-06-22 21:55:00 (UTC)を境に水準が 14.85から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 6→10→5→10→…→10→11→8→9
* 開始   : 2026-06-23 01:45:00 (UTC)
* 終了   : 2026-06-23 01:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→16→15→16→14→15
* 開始   : 2026-06-23 04:30:00 (UTC)
* 終了   : 2026-06-23 05:30:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 35 分
  - EVT-20260623-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260623-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 24→25→19→23→24→25→19→23→21
* 開始   : 2026-06-23 11:35:00 (UTC)
* 終了   : 2026-06-23 11:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→17→…→11→17→14→12
* 開始   : 2026-06-23 19:00:00 (UTC)
* 終了   : 2026-06-23 19:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→12→14→11→12→13→13→12
* 開始   : 2026-06-23 19:15:00 (UTC)
* 終了   : 2026-06-23 20:05:00 (UTC)
* 現象   : 2026-06-23 20:05:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→17→14→17→14→17→13→14
* 開始   : 2026-06-25 05:30:00 (UTC)
* 終了   : 2026-06-25 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→17→16→14→17→16→15
* 開始   : 2026-06-25 05:50:00 (UTC)
* 終了   : 2026-06-25 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.755σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→17→19→20→17→19→21
* 開始   : 2026-06-25 15:15:00 (UTC)
* 終了   : 2026-06-25 15:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→15→…→16→15→17→18
* 開始   : 2026-06-25 16:30:00 (UTC)
* 終了   : 2026-06-25 16:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→12→15→…→12→15→11→14
* 開始   : 2026-06-25 18:30:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260625-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→11→13→10→11→13→10→14→11
* 開始   : 2026-06-25 18:55:00 (UTC)
* 終了   : 2026-06-25 19:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→16→18→19→…→18→19→15→17
* 開始   : 2026-06-26 06:35:00 (UTC)
* 終了   : 2026-06-26 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→13→…→14→13→15→17
* 開始   : 2026-06-26 17:25:00 (UTC)
* 終了   : 2026-06-26 17:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→14→13→15→…→15→12→16→14
* 開始   : 2026-06-26 17:50:00 (UTC)
* 終了   : 2026-06-26 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260626-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→9→8→11→9→8→11→12
* 開始   : 2026-06-26 20:15:00 (UTC)
* 終了   : 2026-06-26 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→9→7→8→6→7→10→10→10
* 開始   : 2026-06-28 00:00:00 (UTC)
* 終了   : 2026-06-28 01:15:00 (UTC)
* 現象   : 2026-06-28 01:15:00 (UTC)を境に水準が 11.8から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→10→12→11→10→12→9
* 開始   : 2026-06-28 03:15:00 (UTC)
* 終了   : 2026-06-28 03:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→13→9→13→9→13→9→12
* 開始   : 2026-06-28 18:00:00 (UTC)
* 終了   : 2026-06-28 18:10:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260628-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260628-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→14→12→14→12→14→11→12
* 開始   : 2026-06-30 04:05:00 (UTC)
* 終了   : 2026-06-30 04:15:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→17→13→17→13→17→15→13
* 開始   : 2026-06-30 06:05:00 (UTC)
* 終了   : 2026-06-30 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→18→17→18→17→18→17
* 開始   : 2026-06-30 06:40:00 (UTC)
* 終了   : 2026-06-30 06:50:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→22→24→21→18→24→21→18→22
* 開始   : 2026-06-30 10:40:00 (UTC)
* 終了   : 2026-06-30 10:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 22→20→24→18→24→20→24→18→24
* 開始   : 2026-06-30 10:55:00 (UTC)
* 終了   : 2026-06-30 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host08-005 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
