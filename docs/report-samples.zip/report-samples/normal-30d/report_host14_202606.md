# host14 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host14 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 308 (SEVERE: 20, FATAL: 131, WARN: 157, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 131 | 157 | 308 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260605-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→15→12→13→13→14→13→14
* 開始   : 2026-06-05 19:00:00 (UTC)
* 終了   : 2026-06-05 20:00:00 (UTC)
* 現象   : 2026-06-05 20:00:00 (UTC)を境に水準が 14.91から12.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.43σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-009 active_connections の推移](charts/EVT-20260605-host14-009.svg)

# イベントID( EVT-20260608-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→13→…→11→13→11→13
* 開始   : 2026-06-08 01:05:00 (UTC)
* 終了   : 2026-06-08 22:15:00 (UTC)
* 現象   : 2026-06-08 22:15:00 (UTC)を境に水準が 11.8から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.108σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.663)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.724, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-001 active_connections の推移](charts/EVT-20260608-host14-001.svg)

# イベントID( EVT-20260608-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→14→17→15→…→13→15→14→13
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.79から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.525, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-002 active_connections の推移](charts/EVT-20260608-host14-002.svg)

# イベントID( EVT-20260608-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→17→…→15→13→12→13
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.86から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.082, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-003 active_connections の推移](charts/EVT-20260608-host14-003.svg)

# イベントID( EVT-20260608-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→18→…→16→15→16→14
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.852σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-004 active_connections の推移](charts/EVT-20260608-host14-004.svg)

# イベントID( EVT-20260608-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→14→…→15→14→13→15
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.89から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.801, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-005 active_connections の推移](charts/EVT-20260608-host14-005.svg)

# イベントID( EVT-20260608-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→15→17→14→…→15→12→14→11
* 開始   : 2026-06-08 04:40:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 2026-06-08 21:20:00 (UTC)を境に水準が 11.92から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.446, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.977, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-006 active_connections の推移](charts/EVT-20260608-host14-006.svg)

# イベントID( EVT-20260615-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→12→17→15→…→15→14→12→14
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 20:20:00 (UTC)
* 現象   : 2026-06-15 20:20:00 (UTC)を境に水準が 12から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.83, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-001 active_connections の推移](charts/EVT-20260615-host14-001.svg)

# イベントID( EVT-20260615-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→13→14→…→12→14→12→14
* 開始   : 2026-06-15 02:45:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.809, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-002 active_connections の推移](charts/EVT-20260615-host14-002.svg)

# イベントID( EVT-20260615-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→16→…→18→16→12→14
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 12.06から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.115σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.223, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-006 active_connections の推移](charts/EVT-20260615-host14-006.svg)

# イベントID( EVT-20260622-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→15→14→16→…→13→15→12→14
* 開始   : 2026-06-22 01:40:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.75から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.571σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.282, 限界=2.663)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-002 active_connections の推移](charts/EVT-20260622-host14-002.svg)

# イベントID( EVT-20260622-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→16→14→15→…→12→17→13→12
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 21:45:00 (UTC)
* 現象   : 2026-06-22 21:45:00 (UTC)を境に水準が 11.8から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.118, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-003 active_connections の推移](charts/EVT-20260622-host14-003.svg)

# イベントID( EVT-20260622-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→17→…→15→14→12→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.88から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-004 active_connections の推移](charts/EVT-20260622-host14-004.svg)

# イベントID( EVT-20260622-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→19→16→15→…→16→15→11→13
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.187, 限界=2.659)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.072σ 外れた (平常値=13.9)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-005 active_connections の推移](charts/EVT-20260622-host14-005.svg)

# イベントID( EVT-20260622-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→14→…→13→12→11→12
* 開始   : 2026-06-22 03:40:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.88から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.062σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.975, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.317, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-006 active_connections の推移](charts/EVT-20260622-host14-006.svg)

# イベントID( EVT-20260629-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→16→…→15→13→11→15
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 21:10:00 (UTC)
* 現象   : 2026-06-29 21:10:00 (UTC)を境に水準が 11.8から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.743, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-001 active_connections の推移](charts/EVT-20260629-host14-001.svg)

# イベントID( EVT-20260629-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→…→14→15→9→13
* 開始   : 2026-06-29 02:10:00 (UTC)
* 終了   : 2026-06-29 22:45:00 (UTC)
* 現象   : 2026-06-29 22:45:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.12, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.631, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-002 active_connections の推移](charts/EVT-20260629-host14-002.svg)

# イベントID( EVT-20260629-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→15→…→14→13→14→15
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 19:30:00 (UTC)
* 現象   : 2026-06-29 19:30:00 (UTC)を境に水準が 11.96から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.524σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.852, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-004 active_connections の推移](charts/EVT-20260629-host14-004.svg)

# イベントID( EVT-20260629-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→15→…→16→14→12→15
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 19:50:00 (UTC)
* 現象   : 2026-06-29 19:50:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.093, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-005 active_connections の推移](charts/EVT-20260629-host14-005.svg)

# イベントID( EVT-20260629-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→17→18→19→…→13→14→12→13
* 開始   : 2026-06-29 04:20:00 (UTC)
* 終了   : 2026-06-29 18:55:00 (UTC)
* 現象   : 2026-06-29 18:55:00 (UTC)を境に水準が 11.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.745, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.814, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-006 active_connections の推移](charts/EVT-20260629-host14-006.svg)

# イベントID( EVT-20260601-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→10→10
* 開始   : 2026-06-01 02:40:00 (UTC)
* 終了   : 2026-06-01 02:40:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→13→18→14→13
* 開始   : 2026-06-01 05:35:00 (UTC)
* 終了   : 2026-06-01 05:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host14-002 active_connections の推移](charts/EVT-20260601-host14-002.svg)

# イベントID( EVT-20260601-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 21→20→26→21→20
* 開始   : 2026-06-01 09:55:00 (UTC)
* 終了   : 2026-06-01 09:55:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.268倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.844σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host14-006 active_connections の推移](charts/EVT-20260601-host14-006.svg)

# イベントID( EVT-20260601-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 21→20→16→19→19
* 開始   : 2026-06-01 14:50:00 (UTC)
* 終了   : 2026-06-01 14:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.235σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260601-host14-008 active_connections の推移](charts/EVT-20260601-host14-008.svg)

# イベントID( EVT-20260601-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→20→15→19→22
* 開始   : 2026-06-01 15:35:00 (UTC)
* 終了   : 2026-06-01 15:35:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host14-009 active_connections の推移](charts/EVT-20260601-host14-009.svg)

# イベントID( EVT-20260601-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→11→8→13→11
* 開始   : 2026-06-01 19:45:00 (UTC)
* 終了   : 2026-06-01 19:45:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host14-012 active_connections の推移](charts/EVT-20260601-host14-012.svg)

# イベントID( EVT-20260602-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 7→9→8→10→7→10→10→7→13
* 開始   : 2026-06-02 00:05:00 (UTC)
* 終了   : 2026-06-02 01:05:00 (UTC)
* 現象   : 2026-06-02 01:05:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 7→14→10→7→14→10→9
* 開始   : 2026-06-02 03:05:00 (UTC)
* 終了   : 2026-06-02 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.408σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-002 active_connections の推移](charts/EVT-20260602-host14-002.svg)

# イベントID( EVT-20260602-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→18→20→17→17
* 開始   : 2026-06-02 07:05:00 (UTC)
* 終了   : 2026-06-02 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host14-004 active_connections の推移](charts/EVT-20260602-host14-004.svg)

# イベントID( EVT-20260603-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→10→13→9→11
* 開始   : 2026-06-03 02:55:00 (UTC)
* 終了   : 2026-06-03 02:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host14-001 active_connections の推移](charts/EVT-20260603-host14-001.svg)

# イベントID( EVT-20260603-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→14→18→14→14
* 開始   : 2026-06-03 05:25:00 (UTC)
* 終了   : 2026-06-03 06:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.421倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.692σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260603-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host14-004 active_connections の推移](charts/EVT-20260603-host14-004.svg)

# イベントID( EVT-20260603-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→15→20→16→16
* 開始   : 2026-06-03 06:20:00 (UTC)
* 終了   : 2026-06-03 06:20:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host14-005 active_connections の推移](charts/EVT-20260603-host14-005.svg)

# イベントID( EVT-20260603-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 23→21→17→21→21
* 開始   : 2026-06-03 14:15:00 (UTC)
* 終了   : 2026-06-03 14:15:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host14-006 active_connections の推移](charts/EVT-20260603-host14-006.svg)

# イベントID( EVT-20260603-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→15→18→18
* 開始   : 2026-06-03 16:15:00 (UTC)
* 終了   : 2026-06-03 16:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host14-008 active_connections の推移](charts/EVT-20260603-host14-008.svg)

# イベントID( EVT-20260603-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→11→6→11→11
* 開始   : 2026-06-03 20:15:00 (UTC)
* 終了   : 2026-06-03 20:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.5255(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.716σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-014 active_connections の推移](charts/EVT-20260603-host14-014.svg)

# イベントID( EVT-20260604-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→19→23→21→21
* 開始   : 2026-06-04 08:45:00 (UTC)
* 終了   : 2026-06-04 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.235σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host14-001 active_connections の推移](charts/EVT-20260604-host14-001.svg)

# イベントID( EVT-20260604-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→18→25→21→21
* 開始   : 2026-06-04 10:30:00 (UTC)
* 終了   : 2026-06-04 10:30:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host14-002 active_connections の推移](charts/EVT-20260604-host14-002.svg)

# イベントID( EVT-20260604-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→23→16→17→…→16→17→20→18
* 開始   : 2026-06-04 15:15:00 (UTC)
* 終了   : 2026-06-04 15:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host14-003 active_connections の推移](charts/EVT-20260604-host14-003.svg)

# イベントID( EVT-20260604-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→18→20→17→17→18→19→18→17
* 開始   : 2026-06-04 16:10:00 (UTC)
* 終了   : 2026-06-04 17:25:00 (UTC)
* 現象   : 2026-06-04 17:25:00 (UTC)を境に水準が 15.02から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.786σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.933, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host14-005 active_connections の推移](charts/EVT-20260604-host14-005.svg)

# イベントID( EVT-20260604-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→14→12→10→…→12→10→13→15
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 18:55:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host14-007 active_connections の推移](charts/EVT-20260604-host14-007.svg)

# イベントID( EVT-20260604-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→13→13→11→12→10→11→12→13
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 21:30:00 (UTC)
* 現象   : 2026-06-04 21:30:00 (UTC)を境に水準が 14.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host14-008 active_connections の推移](charts/EVT-20260604-host14-008.svg)

# イベントID( EVT-20260605-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→20→24→20→19
* 開始   : 2026-06-05 09:05:00 (UTC)
* 終了   : 2026-06-05 09:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host14-003 active_connections の推移](charts/EVT-20260605-host14-003.svg)

# イベントID( EVT-20260605-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→21→24→20→20
* 開始   : 2026-06-05 10:05:00 (UTC)
* 終了   : 2026-06-05 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host14-004 active_connections の推移](charts/EVT-20260605-host14-004.svg)

# イベントID( EVT-20260605-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→11→7→13→9
* 開始   : 2026-06-05 20:40:00 (UTC)
* 終了   : 2026-06-05 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host14-010 active_connections の推移](charts/EVT-20260605-host14-010.svg)

# イベントID( EVT-20260606-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→8→7
* 開始   : 2026-06-06 00:20:00 (UTC)
* 終了   : 2026-06-06 00:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→8→13→10→7
* 開始   : 2026-06-06 02:20:00 (UTC)
* 終了   : 2026-06-06 02:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→12→14→12→…→9→11→10→9
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.994, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260606-host14-004 active_connections の推移](charts/EVT-20260606-host14-004.svg)

# イベントID( EVT-20260606-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→12→14→13→…→9→11→9→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host14-005 active_connections の推移](charts/EVT-20260606-host14-005.svg)

# イベントID( EVT-20260606-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→11→…→13→12→14→11
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.964, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host14-006 active_connections の推移](charts/EVT-20260606-host14-006.svg)

# イベントID( EVT-20260606-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→12→…→13→9→14→10
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 19:50:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host14-007 active_connections の推移](charts/EVT-20260606-host14-007.svg)

# イベントID( EVT-20260606-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→9→11→12→…→14→11→12→14
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.253σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host14-008 active_connections の推移](charts/EVT-20260606-host14-008.svg)

# イベントID( EVT-20260606-host14-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→13→…→12→14→13→12
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.241, 限界=2.663)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260606-host14-009 active_connections の推移](charts/EVT-20260606-host14-009.svg)

# イベントID( EVT-20260607-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→8→14→11→9
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 03:55:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host14-002 active_connections の推移](charts/EVT-20260607-host14-002.svg)

# イベントID( EVT-20260607-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→9→10→12→14→15
* 開始   : 2026-06-07 04:35:00 (UTC)
* 終了   : 2026-06-07 05:10:00 (UTC)
* 現象   : 2026-06-07 05:10:00 (UTC)を境に水準が 11.85から11.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.574σ 外れた (平常値=10.38)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.837, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→16→19→15→16
* 開始   : 2026-06-09 06:25:00 (UTC)
* 終了   : 2026-06-09 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host14-001 active_connections の推移](charts/EVT-20260609-host14-001.svg)

# イベントID( EVT-20260609-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→17→20→17→15
* 開始   : 2026-06-09 06:55:00 (UTC)
* 終了   : 2026-06-09 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→17→23→19→21
* 開始   : 2026-06-09 08:45:00 (UTC)
* 終了   : 2026-06-09 08:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host14-004 active_connections の推移](charts/EVT-20260609-host14-004.svg)

# イベントID( EVT-20260609-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→12→6→11→9
* 開始   : 2026-06-09 20:25:00 (UTC)
* 終了   : 2026-06-09 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.4898(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host14-008 active_connections の推移](charts/EVT-20260609-host14-008.svg)

# イベントID( EVT-20260610-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→10→15→10→13
* 開始   : 2026-06-10 03:45:00 (UTC)
* 終了   : 2026-06-10 03:45:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host14-001 active_connections の推移](charts/EVT-20260610-host14-001.svg)

# イベントID( EVT-20260610-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→9→15→11→13
* 開始   : 2026-06-10 04:10:00 (UTC)
* 終了   : 2026-06-10 04:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host14-002 active_connections の推移](charts/EVT-20260610-host14-002.svg)

# イベントID( EVT-20260610-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→13→17→14→15
* 開始   : 2026-06-10 05:15:00 (UTC)
* 終了   : 2026-06-10 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.062σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host14-003 active_connections の推移](charts/EVT-20260610-host14-003.svg)

# イベントID( EVT-20260611-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→8→14→9→12
* 開始   : 2026-06-11 02:50:00 (UTC)
* 終了   : 2026-06-11 02:50:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host14-001 active_connections の推移](charts/EVT-20260611-host14-001.svg)

# イベントID( EVT-20260611-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→14→18→15→16
* 開始   : 2026-06-11 06:10:00 (UTC)
* 終了   : 2026-06-11 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.004σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host14-002 active_connections の推移](charts/EVT-20260611-host14-002.svg)

# イベントID( EVT-20260611-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→23→21→21→22→22→23→23
* 開始   : 2026-06-11 13:50:00 (UTC)
* 終了   : 2026-06-11 15:20:00 (UTC)
* 現象   : 2026-06-11 15:20:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.004σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.634, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→12→6→11→…→11→14→11→12
* 開始   : 2026-06-12 03:50:00 (UTC)
* 終了   : 2026-06-12 04:00:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-001 active_connections の推移](charts/EVT-20260612-host14-001.svg)

# イベントID( EVT-20260612-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→14→18→17→14→18→17→14→17
* 開始   : 2026-06-12 06:05:00 (UTC)
* 終了   : 2026-06-12 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host14-002 active_connections の推移](charts/EVT-20260612-host14-002.svg)

# イベントID( EVT-20260612-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→23→20→22→23→20→22→17→22
* 開始   : 2026-06-12 08:25:00 (UTC)
* 終了   : 2026-06-12 08:35:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260612-host14-003 active_connections の推移](charts/EVT-20260612-host14-003.svg)

# イベントID( EVT-20260612-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→24→20→…→20→24→23→21
* 開始   : 2026-06-12 09:40:00 (UTC)
* 終了   : 2026-06-12 10:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host14-005 active_connections の推移](charts/EVT-20260612-host14-005.svg)

# イベントID( EVT-20260612-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→16→…→16→13→17→16
* 開始   : 2026-06-12 17:00:00 (UTC)
* 終了   : 2026-06-12 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-007 active_connections の推移](charts/EVT-20260612-host14-007.svg)

# イベントID( EVT-20260612-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→13→14→16→13→14→16→15
* 開始   : 2026-06-12 17:25:00 (UTC)
* 終了   : 2026-06-12 17:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-008 active_connections の推移](charts/EVT-20260612-host14-008.svg)

# イベントID( EVT-20260612-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→13→7→10→10
* 開始   : 2026-06-12 20:35:00 (UTC)
* 終了   : 2026-06-12 20:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-009 active_connections の推移](charts/EVT-20260612-host14-009.svg)

# イベントID( EVT-20260612-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→7→4→10→7
* 開始   : 2026-06-12 22:35:00 (UTC)
* 終了   : 2026-06-12 22:35:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.466σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host14-011 active_connections の推移](charts/EVT-20260612-host14-011.svg)

# イベントID( EVT-20260613-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→…→12→11→13→10
* 開始   : 2026-06-13 04:30:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.681, 限界=2.663)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host14-001 active_connections の推移](charts/EVT-20260613-host14-001.svg)

# イベントID( EVT-20260613-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→14→12→13→…→13→15→11→12
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.976, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host14-002 active_connections の推移](charts/EVT-20260613-host14-002.svg)

# イベントID( EVT-20260613-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→11→…→12→13→12→13
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host14-003 active_connections の推移](charts/EVT-20260613-host14-003.svg)

# イベントID( EVT-20260613-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→10→…→11→10→11→10
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.665, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host14-004 active_connections の推移](charts/EVT-20260613-host14-004.svg)

# イベントID( EVT-20260613-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→12→13→12→14
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.732, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host14-005 active_connections の推移](charts/EVT-20260613-host14-005.svg)

# イベントID( EVT-20260613-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→13→9→13→…→11→9→10→11
* 開始   : 2026-06-13 06:55:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.555, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260613-host14-006 active_connections の推移](charts/EVT-20260613-host14-006.svg)

# イベントID( EVT-20260614-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→7→12→8→7
* 開始   : 2026-06-14 01:50:00 (UTC)
* 終了   : 2026-06-14 01:50:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→9→16→9→12
* 開始   : 2026-06-14 05:20:00 (UTC)
* 終了   : 2026-06-14 05:20:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.466σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host14-003 active_connections の推移](charts/EVT-20260614-host14-003.svg)

# イベントID( EVT-20260614-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→16→11→15→16→11→15→12
* 開始   : 2026-06-14 06:35:00 (UTC)
* 終了   : 2026-06-14 06:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host14-004 active_connections の推移](charts/EVT-20260614-host14-004.svg)

# イベントID( EVT-20260614-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→12→15→8→12→15→10
* 開始   : 2026-06-14 18:30:00 (UTC)
* 終了   : 2026-06-14 18:40:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→16→13→16→…→14→15→13→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.663)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-003 active_connections の推移](charts/EVT-20260615-host14-003.svg)

# イベントID( EVT-20260615-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→15→16→15→13
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 11.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.667)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-004 active_connections の推移](charts/EVT-20260615-host14-004.svg)

# イベントID( EVT-20260615-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→…→12→13→14→12
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 19:35:00 (UTC)
* 現象   : 2026-06-15 19:35:00 (UTC)を境に水準が 11.89から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.172, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-005 active_connections の推移](charts/EVT-20260615-host14-005.svg)

# イベントID( EVT-20260616-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 23→21→16→22→20
* 開始   : 2026-06-16 14:45:00 (UTC)
* 終了   : 2026-06-16 14:45:00 (UTC)
* 現象   : 平常時(21)に対し 0.7619(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-008 active_connections の推移](charts/EVT-20260616-host14-008.svg)

# イベントID( EVT-20260616-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→17→13→17→17
* 開始   : 2026-06-16 17:20:00 (UTC)
* 終了   : 2026-06-16 17:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host14-009 active_connections の推移](charts/EVT-20260616-host14-009.svg)

# イベントID( EVT-20260616-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→15→11→15→15
* 開始   : 2026-06-16 18:20:00 (UTC)
* 終了   : 2026-06-16 18:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host14-010 active_connections の推移](charts/EVT-20260616-host14-010.svg)

# イベントID( EVT-20260616-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→16→11→15→12
* 開始   : 2026-06-16 18:45:00 (UTC)
* 終了   : 2026-06-16 18:45:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host14-011 active_connections の推移](charts/EVT-20260616-host14-011.svg)

# イベントID( EVT-20260616-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→12→9
* 開始   : 2026-06-16 20:10:00 (UTC)
* 終了   : 2026-06-16 20:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host14-013 active_connections の推移](charts/EVT-20260616-host14-013.svg)

# イベントID( EVT-20260617-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→17→20→17→16
* 開始   : 2026-06-17 06:50:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host14-003 active_connections の推移](charts/EVT-20260617-host14-003.svg)

# イベントID( EVT-20260617-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→18→24→21→19
* 開始   : 2026-06-17 08:50:00 (UTC)
* 終了   : 2026-06-17 08:50:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host02-009 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260617-host14-004 active_connections の推移](charts/EVT-20260617-host14-004.svg)

# イベントID( EVT-20260617-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→20→17→21→22
* 開始   : 2026-06-17 14:45:00 (UTC)
* 終了   : 2026-06-17 14:45:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.004σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host14-006 active_connections の推移](charts/EVT-20260617-host14-006.svg)

# イベントID( EVT-20260618-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→16→15→13→…→15→13→16→15
* 開始   : 2026-06-18 05:25:00 (UTC)
* 終了   : 2026-06-18 05:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260618-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-006 active_connections の推移](charts/EVT-20260618-host14-006.svg)

# イベントID( EVT-20260618-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→17→21→17→16
* 開始   : 2026-06-18 07:00:00 (UTC)
* 終了   : 2026-06-18 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-007 active_connections の推移](charts/EVT-20260618-host14-007.svg)

# イベントID( EVT-20260618-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→17→20→16→18
* 開始   : 2026-06-18 07:05:00 (UTC)
* 終了   : 2026-06-18 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-008 active_connections の推移](charts/EVT-20260618-host14-008.svg)

# イベントID( EVT-20260618-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→21→…→22→21→18→19
* 開始   : 2026-06-18 08:20:00 (UTC)
* 終了   : 2026-06-18 08:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host14-009 active_connections の推移](charts/EVT-20260618-host14-009.svg)

# イベントID( EVT-20260618-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 22→23→26→23→22
* 開始   : 2026-06-18 10:35:00 (UTC)
* 終了   : 2026-06-18 10:35:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.248倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host14-013 active_connections の推移](charts/EVT-20260618-host14-013.svg)

# イベントID( EVT-20260618-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→22→26→22→22
* 開始   : 2026-06-18 11:10:00 (UTC)
* 終了   : 2026-06-18 11:10:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host14-014 active_connections の推移](charts/EVT-20260618-host14-014.svg)

# イベントID( EVT-20260618-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→17→19→21→17→19→17
* 開始   : 2026-06-18 14:10:00 (UTC)
* 終了   : 2026-06-18 15:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host14-015 active_connections の推移](charts/EVT-20260618-host14-015.svg)

# イベントID( EVT-20260618-host14-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→19→17→20→23
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 14:55:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-016 active_connections の推移](charts/EVT-20260618-host14-016.svg)

# イベントID( EVT-20260618-host14-021 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→11→11
* 開始   : 2026-06-18 20:10:00 (UTC)
* 終了   : 2026-06-18 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host14-021 active_connections の推移](charts/EVT-20260618-host14-021.svg)

# イベントID( EVT-20260619-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→12→17→14→12
* 開始   : 2026-06-19 05:05:00 (UTC)
* 終了   : 2026-06-19 05:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host14-003 active_connections の推移](charts/EVT-20260619-host14-003.svg)

# イベントID( EVT-20260619-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→18→…→17→18→16→14
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-004 active_connections の推移](charts/EVT-20260619-host14-004.svg)

# イベントID( EVT-20260619-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→15→16
* 開始   : 2026-06-19 06:30:00 (UTC)
* 終了   : 2026-06-19 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.364倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.692σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-005 active_connections の推移](charts/EVT-20260619-host14-005.svg)

# イベントID( EVT-20260619-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→20→…→18→20→17→18
* 開始   : 2026-06-19 06:40:00 (UTC)
* 終了   : 2026-06-19 06:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260619-host14-006 active_connections の推移](charts/EVT-20260619-host14-006.svg)

# イベントID( EVT-20260619-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→18→22→19→16
* 開始   : 2026-06-19 07:40:00 (UTC)
* 終了   : 2026-06-19 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.582σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host14-007 active_connections の推移](charts/EVT-20260619-host14-007.svg)

# イベントID( EVT-20260619-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→20→24→19→…→19→23→20→21
* 開始   : 2026-06-19 09:25:00 (UTC)
* 終了   : 2026-06-19 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→12→9→13→13
* 開始   : 2026-06-19 19:15:00 (UTC)
* 終了   : 2026-06-19 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.6353(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host14-012 active_connections の推移](charts/EVT-20260619-host14-012.svg)

# イベントID( EVT-20260619-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→13→8→12→12
* 開始   : 2026-06-19 20:00:00 (UTC)
* 終了   : 2026-06-19 20:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-013 active_connections の推移](charts/EVT-20260619-host14-013.svg)

# イベントID( EVT-20260620-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→11→…→11→12→10→11
* 開始   : 2026-06-20 03:35:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.681, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260620-host14-003 active_connections の推移](charts/EVT-20260620-host14-003.svg)

# イベントID( EVT-20260620-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→11→12
* 開始   : 2026-06-20 04:40:00 (UTC)
* 終了   : 2026-06-20 04:40:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host14-004 active_connections の推移](charts/EVT-20260620-host14-004.svg)

# イベントID( EVT-20260620-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→10→…→11→9→11→12
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.663)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host14-005 active_connections の推移](charts/EVT-20260620-host14-005.svg)

# イベントID( EVT-20260620-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→9→…→10→13→12→13
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.381, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host14-006 active_connections の推移](charts/EVT-20260620-host14-006.svg)

# イベントID( EVT-20260620-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→12→11→9→…→13→12→13→12
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.724, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host14-007 active_connections の推移](charts/EVT-20260620-host14-007.svg)

# イベントID( EVT-20260620-host14-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→11→…→9→11→9→11
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.946, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host14-008 active_connections の推移](charts/EVT-20260620-host14-008.svg)

# イベントID( EVT-20260620-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→10→…→15→12→11→13
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host14-009 active_connections の推移](charts/EVT-20260620-host14-009.svg)

# イベントID( EVT-20260620-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→12→5→9→7
* 開始   : 2026-06-20 20:50:00 (UTC)
* 終了   : 2026-06-20 20:50:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.4918(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.545σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host14-010 active_connections の推移](charts/EVT-20260620-host14-010.svg)

# イベントID( EVT-20260621-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→13→17→13→12
* 開始   : 2026-06-21 06:50:00 (UTC)
* 終了   : 2026-06-21 06:50:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host14-001 active_connections の推移](charts/EVT-20260621-host14-001.svg)

# イベントID( EVT-20260621-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→14→20→16→13
* 開始   : 2026-06-21 11:25:00 (UTC)
* 終了   : 2026-06-21 11:25:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host14-003 active_connections の推移](charts/EVT-20260621-host14-003.svg)

# イベントID( EVT-20260621-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→21→14→17
* 開始   : 2026-06-21 13:55:00 (UTC)
* 終了   : 2026-06-21 13:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260621-host14-004 active_connections の推移](charts/EVT-20260621-host14-004.svg)

# イベントID( EVT-20260621-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→13
* 開始   : 2026-06-21 15:55:00 (UTC)
* 終了   : 2026-06-21 15:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host14-005 active_connections の推移](charts/EVT-20260621-host14-005.svg)

# イベントID( EVT-20260622-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→16→…→12→15→13→12
* 開始   : 2026-06-22 01:00:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.82から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.535, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-001 active_connections の推移](charts/EVT-20260622-host14-001.svg)

# イベントID( EVT-20260623-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→19→23→17→20
* 開始   : 2026-06-23 08:30:00 (UTC)
* 終了   : 2026-06-23 08:30:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host14-005 active_connections の推移](charts/EVT-20260623-host14-005.svg)

# イベントID( EVT-20260623-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→23→18→23→22
* 開始   : 2026-06-23 13:00:00 (UTC)
* 終了   : 2026-06-23 13:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→15→…→15→13→15→16
* 開始   : 2026-06-24 16:50:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host14-006 active_connections の推移](charts/EVT-20260624-host14-006.svg)

# イベントID( EVT-20260624-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→9→15→13
* 開始   : 2026-06-24 18:40:00 (UTC)
* 終了   : 2026-06-24 18:40:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6034(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host14-008 active_connections の推移](charts/EVT-20260624-host14-008.svg)

# イベントID( EVT-20260624-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→10→14→8→11
* 開始   : 2026-06-24 21:30:00 (UTC)
* 終了   : 2026-06-24 21:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.004σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→17→…→16→17→14→13
* 開始   : 2026-06-25 05:05:00 (UTC)
* 終了   : 2026-06-25 05:10:00 (UTC)
* 現象   : 平常時(12)に対し 1.333倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.773σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host14-002 active_connections の推移](charts/EVT-20260625-host14-002.svg)

# イベントID( EVT-20260625-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→16→20→16→17
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host14-004 active_connections の推移](charts/EVT-20260625-host14-004.svg)

# イベントID( EVT-20260625-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→15→14→13→12→13→15
* 開始   : 2026-06-25 18:50:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 2026-06-25 20:15:00 (UTC)を境に水準が 14.84から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→11→7→5→…→7→5→8→9
* 開始   : 2026-06-25 21:55:00 (UTC)
* 終了   : 2026-06-25 22:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-010 active_connections の推移](charts/EVT-20260625-host14-010.svg)

# イベントID( EVT-20260626-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→14→14→13→16
* 開始   : 2026-06-26 04:25:00 (UTC)
* 終了   : 2026-06-26 05:50:00 (UTC)
* 現象   : 2026-06-26 05:50:00 (UTC)を境に水準が 14.93から14.7へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→17→21→16→17
* 開始   : 2026-06-26 07:15:00 (UTC)
* 終了   : 2026-06-26 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host14-003 active_connections の推移](charts/EVT-20260626-host14-003.svg)

# イベントID( EVT-20260626-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→20→24→21→21
* 開始   : 2026-06-26 09:25:00 (UTC)
* 終了   : 2026-06-26 09:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host14-004 active_connections の推移](charts/EVT-20260626-host14-004.svg)

# イベントID( EVT-20260626-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→19→15→19→16
* 開始   : 2026-06-26 16:20:00 (UTC)
* 終了   : 2026-06-26 16:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.119σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260626-host14-007 active_connections の推移](charts/EVT-20260626-host14-007.svg)

# イベントID( EVT-20260626-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→19→13→18→16
* 開始   : 2026-06-26 16:35:00 (UTC)
* 終了   : 2026-06-26 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.6812(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.174σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260626-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host14-008 active_connections の推移](charts/EVT-20260626-host14-008.svg)

# イベントID( EVT-20260626-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→13→10→11→14
* 開始   : 2026-06-26 19:10:00 (UTC)
* 終了   : 2026-06-26 19:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host14-010 active_connections の推移](charts/EVT-20260626-host14-010.svg)

# イベントID( EVT-20260627-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→10→…→10→13→12→11
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.172σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.255, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host14-004 active_connections の推移](charts/EVT-20260627-host14-004.svg)

# イベントID( EVT-20260627-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→14→11→14→10
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.663)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host14-005 active_connections の推移](charts/EVT-20260627-host14-005.svg)

# イベントID( EVT-20260627-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→10→13→12→…→10→12→11→12
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.809, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host14-006 active_connections の推移](charts/EVT-20260627-host14-006.svg)

# イベントID( EVT-20260627-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→13→…→13→12→13→11
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.158, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host14-007 active_connections の推移](charts/EVT-20260627-host14-007.svg)

# イベントID( EVT-20260627-host14-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→10→14→13→…→9→11→9→11
* 開始   : 2026-06-27 06:40:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.325, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host14-008 active_connections の推移](charts/EVT-20260627-host14-008.svg)

# イベントID( EVT-20260627-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→15→12→14→…→10→12→13→11
* 開始   : 2026-06-27 07:10:00 (UTC)
* 終了   : 2026-06-27 20:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.31σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.418, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host14-009 active_connections の推移](charts/EVT-20260627-host14-009.svg)

# イベントID( EVT-20260628-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→17→18
* 開始   : 2026-06-28 11:00:00 (UTC)
* 終了   : 2026-06-28 11:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host14-002 active_connections の推移](charts/EVT-20260628-host14-002.svg)

# イベントID( EVT-20260629-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→14→…→14→15→14→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:30:00 (UTC)
* 現象   : 2026-06-29 21:30:00 (UTC)を境に水準が 11.88から15.12へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.663)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-003 active_connections の推移](charts/EVT-20260629-host14-003.svg)

# イベントID( EVT-20260630-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→13→13
* 開始   : 2026-06-30 04:30:00 (UTC)
* 終了   : 2026-06-30 04:30:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-002 active_connections の推移](charts/EVT-20260630-host14-002.svg)

# イベントID( EVT-20260630-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→21→24→20→20
* 開始   : 2026-06-30 09:25:00 (UTC)
* 終了   : 2026-06-30 09:25:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→22→25→21→22
* 開始   : 2026-06-30 10:30:00 (UTC)
* 終了   : 2026-06-30 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.177σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 22→22→17→21→21
* 開始   : 2026-06-30 14:25:00 (UTC)
* 終了   : 2026-06-30 14:25:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-009 active_connections の推移](charts/EVT-20260630-host14-009.svg)

# イベントID( EVT-20260630-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→16→14→19→20→16→14→19→20
* 開始   : 2026-06-30 16:10:00 (UTC)
* 終了   : 2026-06-30 16:15:00 (UTC)
* 現象   : 平常時(20)に対し 0.8(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host14-010 active_connections の推移](charts/EVT-20260630-host14-010.svg)

# イベントID( EVT-20260601-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→16→19→20→…→17→20→15→18
* 開始   : 2026-06-01 07:10:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260601-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→19→22→19→22→19→20
* 開始   : 2026-06-01 08:35:00 (UTC)
* 終了   : 2026-06-01 08:40:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→19→22→23→20→19→22→23→20
* 開始   : 2026-06-01 08:55:00 (UTC)
* 終了   : 2026-06-01 09:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→24→22→24→23
* 開始   : 2026-06-01 10:30:00 (UTC)
* 終了   : 2026-06-01 10:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→14→17→13→14→17
* 開始   : 2026-06-01 17:55:00 (UTC)
* 終了   : 2026-06-01 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→11→…→12→11→15→14
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→6→10→6→10→6→8
* 開始   : 2026-06-01 22:55:00 (UTC)
* 終了   : 2026-06-01 23:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→13→14→11→14→11→14→13→12
* 開始   : 2026-06-02 04:15:00 (UTC)
* 終了   : 2026-06-02 04:25:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→17→20→17→18
* 開始   : 2026-06-02 07:40:00 (UTC)
* 終了   : 2026-06-02 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→21→24→21→…→21→25→22→20
* 開始   : 2026-06-02 10:30:00 (UTC)
* 終了   : 2026-06-02 10:40:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.342σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260602-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 22→21→21→22→23→24
* 開始   : 2026-06-02 10:30:00 (UTC)
* 終了   : 2026-06-02 10:55:00 (UTC)
* 現象   : 2026-06-02 10:55:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 21→19→16→15→…→17→15→18→19
* 開始   : 2026-06-02 16:30:00 (UTC)
* 終了   : 2026-06-02 16:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→12→…→12→8→11→10
* 開始   : 2026-06-02 20:25:00 (UTC)
* 終了   : 2026-06-02 20:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→13→11→10→10→11→11
* 開始   : 2026-06-02 20:25:00 (UTC)
* 終了   : 2026-06-02 21:35:00 (UTC)
* 現象   : 2026-06-02 21:35:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.875, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→10→11→10
* 開始   : 2026-06-02 21:00:00 (UTC)
* 終了   : 2026-06-02 21:25:00 (UTC)
* 現象   : 2026-06-02 21:25:00 (UTC)を境に水準が 14.99から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.862, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→12→13→14→…→10→13→14→10
* 開始   : 2026-06-03 03:15:00 (UTC)
* 終了   : 2026-06-03 03:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→12→15→16→15→16→13
* 開始   : 2026-06-03 05:05:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260603-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→17→16
* 開始   : 2026-06-03 16:05:00 (UTC)
* 終了   : 2026-06-03 16:10:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→17→15→14→…→15→14→18→17
* 開始   : 2026-06-03 17:00:00 (UTC)
* 終了   : 2026-06-03 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→10→…→11→10→13→14
* 開始   : 2026-06-03 19:15:00 (UTC)
* 終了   : 2026-06-03 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→13→13→13→13→11→13→12→12
* 開始   : 2026-06-03 19:20:00 (UTC)
* 終了   : 2026-06-03 20:30:00 (UTC)
* 現象   : 2026-06-03 20:30:00 (UTC)を境に水準が 15.11から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.693σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.724, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→9→13→11→9→13→11
* 開始   : 2026-06-03 20:00:00 (UTC)
* 終了   : 2026-06-03 20:05:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→9→11→12→9→11→10
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 20:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→17→16→21→…→21→15→17→18
* 開始   : 2026-06-04 16:05:00 (UTC)
* 終了   : 2026-06-04 16:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260604-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→19→…→19→15→17→20
* 開始   : 2026-06-04 16:20:00 (UTC)
* 終了   : 2026-06-04 16:30:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→9→11→14→10→9→11
* 開始   : 2026-06-04 19:55:00 (UTC)
* 終了   : 2026-06-04 20:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→15→17→15→17→15→16
* 開始   : 2026-06-05 05:40:00 (UTC)
* 終了   : 2026-06-05 05:50:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→21→21→20→19→21→20→22→20
* 開始   : 2026-06-05 08:20:00 (UTC)
* 終了   : 2026-06-05 09:10:00 (UTC)
* 現象   : 2026-06-05 09:10:00 (UTC)を境に水準が 14.89から14.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→19→…→19→17→20→19
* 開始   : 2026-06-05 14:25:00 (UTC)
* 終了   : 2026-06-05 14:35:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→18→14→17→…→17→13→15→17
* 開始   : 2026-06-05 17:30:00 (UTC)
* 終了   : 2026-06-05 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260605-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→14→16→12→14→15
* 開始   : 2026-06-05 18:20:00 (UTC)
* 終了   : 2026-06-05 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.634σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→12→13→14→12→13→14
* 開始   : 2026-06-05 18:45:00 (UTC)
* 終了   : 2026-06-05 18:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→10→…→10→7→10→8
* 開始   : 2026-06-05 21:20:00 (UTC)
* 終了   : 2026-06-05 21:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.628σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→10→9
* 開始   : 2026-06-05 23:50:00 (UTC)
* 終了   : 2026-06-06 00:10:00 (UTC)
* 現象   : 2026-06-06 00:10:00 (UTC)を境に水準が 14.97から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.698, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→10→…→10→6→7→8
* 開始   : 2026-06-06 02:55:00 (UTC)
* 終了   : 2026-06-06 03:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-003 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260606-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→7→9→7→9
* 開始   : 2026-06-06 21:00:00 (UTC)
* 終了   : 2026-06-06 21:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260606-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→13→…→12→13→9→11
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 04:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→16→15→…→16→15→12→11
* 開始   : 2026-06-07 07:00:00 (UTC)
* 終了   : 2026-06-07 07:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.362倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.986σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→14→16→14
* 開始   : 2026-06-07 07:55:00 (UTC)
* 終了   : 2026-06-07 08:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→16→15→15→16→15→16→18
* 開始   : 2026-06-07 14:15:00 (UTC)
* 終了   : 2026-06-07 15:00:00 (UTC)
* 現象   : 2026-06-07 15:00:00 (UTC)を境に水準が 11.84から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→11→8→11→8→11→8→11→10
* 開始   : 2026-06-07 19:15:00 (UTC)
* 終了   : 2026-06-07 19:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.596σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→9→10→6→9→10
* 開始   : 2026-06-07 21:00:00 (UTC)
* 終了   : 2026-06-07 21:05:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.81σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→7→…→7→12→7→9
* 開始   : 2026-06-07 22:55:00 (UTC)
* 終了   : 2026-06-07 23:05:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→18→16→18→19→18→15
* 開始   : 2026-06-09 06:40:00 (UTC)
* 終了   : 2026-06-09 06:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→22→25→19→22→25→19→22→21
* 開始   : 2026-06-09 10:25:00 (UTC)
* 終了   : 2026-06-09 10:30:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260609-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→23→25→24→…→24→19→22→24
* 開始   : 2026-06-09 11:00:00 (UTC)
* 終了   : 2026-06-09 11:10:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-033 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→14→…→16→11→13→12
* 開始   : 2026-06-09 18:30:00 (UTC)
* 終了   : 2026-06-09 18:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→9→6→9→6→7→9
* 開始   : 2026-06-09 22:45:00 (UTC)
* 終了   : 2026-06-09 22:55:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.634σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→14→16→15→…→15→17→14→16
* 開始   : 2026-06-10 05:55:00 (UTC)
* 終了   : 2026-06-10 07:20:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.108σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→20→…→17→20→19→17
* 開始   : 2026-06-10 07:30:00 (UTC)
* 終了   : 2026-06-10 07:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→22→23→21→22→23→21
* 開始   : 2026-06-10 09:40:00 (UTC)
* 終了   : 2026-06-10 09:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→16→…→17→16→19→20
* 開始   : 2026-06-10 15:25:00 (UTC)
* 終了   : 2026-06-10 15:30:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→13→14→15→13→15→17
* 開始   : 2026-06-10 17:45:00 (UTC)
* 終了   : 2026-06-10 17:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→18→13→16→13→16→13→14→15
* 開始   : 2026-06-10 18:05:00 (UTC)
* 終了   : 2026-06-10 18:15:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→15→12→12→14→13→12→13
* 開始   : 2026-06-10 19:20:00 (UTC)
* 終了   : 2026-06-10 19:55:00 (UTC)
* 現象   : 2026-06-10 19:55:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→17→…→19→20→14→16
* 開始   : 2026-06-11 07:10:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→23→19→23→19→23→19→20
* 開始   : 2026-06-11 09:30:00 (UTC)
* 終了   : 2026-06-11 09:40:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→22→19→23→…→23→25→24→21
* 開始   : 2026-06-11 12:30:00 (UTC)
* 終了   : 2026-06-11 12:50:00 (UTC)
* 現象   : 2026-06-11 12:50:00 (UTC)を境に水準が 14.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→21→17→23→21→17→23→21→19
* 開始   : 2026-06-11 15:10:00 (UTC)
* 終了   : 2026-06-11 15:15:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→16→17→14→16→15
* 開始   : 2026-06-11 17:10:00 (UTC)
* 終了   : 2026-06-11 17:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→9→9→9→8→10→8→10
* 開始   : 2026-06-11 23:55:00 (UTC)
* 終了   : 2026-06-12 00:30:00 (UTC)
* 現象   : 2026-06-12 00:30:00 (UTC)を境に水準が 14.93から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→22→…→20→22→19→18
* 開始   : 2026-06-12 08:50:00 (UTC)
* 終了   : 2026-06-12 09:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260612-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→18→24→22→23→18→24→22→19
* 開始   : 2026-06-12 14:20:00 (UTC)
* 終了   : 2026-06-12 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→12→7→9→7→9→7→11
* 開始   : 2026-06-12 21:05:00 (UTC)
* 終了   : 2026-06-12 21:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.6269(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.927σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→10→11→11→9→9→11→12
* 開始   : 2026-06-14 02:15:00 (UTC)
* 終了   : 2026-06-14 02:50:00 (UTC)
* 現象   : 2026-06-14 02:50:00 (UTC)を境に水準が 11.78から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.634, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→15→17→15→16→16→17
* 開始   : 2026-06-14 09:30:00 (UTC)
* 終了   : 2026-06-14 10:10:00 (UTC)
* 現象   : 2026-06-14 10:10:00 (UTC)を境に水準が 11.67から12.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.582, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→11→10→11→10→11→13
* 開始   : 2026-06-14 16:45:00 (UTC)
* 終了   : 2026-06-14 16:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→8→11→5→8→11→5→8→6
* 開始   : 2026-06-16 00:55:00 (UTC)
* 終了   : 2026-06-16 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→10→11→12→…→11→12→9→8
* 開始   : 2026-06-16 02:00:00 (UTC)
* 終了   : 2026-06-16 02:05:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→10→15→13→15→13→15→12→13
* 開始   : 2026-06-16 04:35:00 (UTC)
* 終了   : 2026-06-16 04:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.538σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→18→15→19→18→15→19→17→16
* 開始   : 2026-06-16 06:20:00 (UTC)
* 終了   : 2026-06-16 06:30:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→16→18→17→16→18→16
* 開始   : 2026-06-16 06:25:00 (UTC)
* 終了   : 2026-06-16 06:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→23→…→22→23→21→20
* 開始   : 2026-06-16 08:55:00 (UTC)
* 終了   : 2026-06-16 09:00:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→25→23→18→25→23→18→22→20
* 開始   : 2026-06-16 13:25:00 (UTC)
* 終了   : 2026-06-16 13:35:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260616-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→14→15→11→14→15
* 開始   : 2026-06-16 19:05:00 (UTC)
* 終了   : 2026-06-16 19:10:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→8→9→12→8→12→11
* 開始   : 2026-06-16 20:20:00 (UTC)
* 終了   : 2026-06-16 20:30:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→11→15→11→15→13→12
* 開始   : 2026-06-17 04:25:00 (UTC)
* 終了   : 2026-06-17 04:35:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260617-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→16→14→13
* 開始   : 2026-06-17 05:15:00 (UTC)
* 終了   : 2026-06-17 05:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→21→24→22→21→24→22→21
* 開始   : 2026-06-17 10:10:00 (UTC)
* 終了   : 2026-06-17 10:15:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→16→20→22→16→20→22→19→17
* 開始   : 2026-06-17 15:45:00 (UTC)
* 終了   : 2026-06-17 16:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→11→17→11→…→11→17→11→12
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→12→11→9→10→11→10→11
* 開始   : 2026-06-17 20:40:00 (UTC)
* 終了   : 2026-06-17 21:15:00 (UTC)
* 現象   : 2026-06-17 21:15:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→9→…→9→6→8→9
* 開始   : 2026-06-18 01:20:00 (UTC)
* 終了   : 2026-06-18 01:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→13→12→…→12→14→12→10
* 開始   : 2026-06-18 03:25:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→10→11→13→10→12
* 開始   : 2026-06-18 03:30:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→14→…→14→16→14→15
* 開始   : 2026-06-18 04:50:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260618-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→14→15→13→16→15→13→16→14
* 開始   : 2026-06-18 05:15:00 (UTC)
* 終了   : 2026-06-18 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 21→18→22→19→18→22→19→18
* 開始   : 2026-06-18 08:45:00 (UTC)
* 終了   : 2026-06-18 08:50:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→22→23→21→22→23→21
* 開始   : 2026-06-18 08:50:00 (UTC)
* 終了   : 2026-06-18 08:55:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→23→23→23→23→22→21→23→25
* 開始   : 2026-06-18 10:30:00 (UTC)
* 終了   : 2026-06-18 11:15:00 (UTC)
* 現象   : 2026-06-18 11:15:00 (UTC)を境に水準が 14.9から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→16→20→16→20→16→18→19
* 開始   : 2026-06-18 15:45:00 (UTC)
* 終了   : 2026-06-18 15:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host14-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→15→17→18→15→17→19
* 開始   : 2026-06-18 16:35:00 (UTC)
* 終了   : 2026-06-18 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.793(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-019 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→18→15→17→15→17→15→17→18
* 開始   : 2026-06-18 16:40:00 (UTC)
* 終了   : 2026-06-18 16:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→13→17→13→17→13→16→13
* 開始   : 2026-06-18 17:45:00 (UTC)
* 終了   : 2026-06-18 17:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.63σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host14-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-022 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→10→11→9→8→11→10
* 開始   : 2026-06-18 22:15:00 (UTC)
* 終了   : 2026-06-18 22:45:00 (UTC)
* 現象   : 2026-06-18 22:45:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.675, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host14-022 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→13→15→14→13→15→13
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 04:50:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.108σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→14→16→14→16→11→13
* 開始   : 2026-06-19 04:50:00 (UTC)
* 終了   : 2026-06-19 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.352倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.858σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→20→19→18→14→20→19
* 開始   : 2026-06-19 07:45:00 (UTC)
* 終了   : 2026-06-19 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→21→20→20
* 開始   : 2026-06-19 14:55:00 (UTC)
* 終了   : 2026-06-19 15:10:00 (UTC)
* 現象   : 2026-06-19 15:10:00 (UTC)を境に水準が 14.82から12.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→11→13→14→11→13→12
* 開始   : 2026-06-19 19:05:00 (UTC)
* 終了   : 2026-06-19 19:10:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260619-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→11→12→9→11→9
* 開始   : 2026-06-19 20:45:00 (UTC)
* 終了   : 2026-06-19 20:50:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→6→7→6→7→6→8
* 開始   : 2026-06-19 22:05:00 (UTC)
* 終了   : 2026-06-19 22:15:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→5→7→5→7→5→9→8
* 開始   : 2026-06-19 23:15:00 (UTC)
* 終了   : 2026-06-19 23:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host14-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→10→9→7→8→9
* 開始   : 2026-06-19 23:25:00 (UTC)
* 終了   : 2026-06-19 23:55:00 (UTC)
* 現象   : 2026-06-19 23:55:00 (UTC)を境に水準が 14.87から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→12→…→11→12→10→8
* 開始   : 2026-06-20 02:00:00 (UTC)
* 終了   : 2026-06-20 02:05:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→9→12→10→…→10→6→11→7
* 開始   : 2026-06-20 02:50:00 (UTC)
* 終了   : 2026-06-20 03:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→15→16→15→16→14→16
* 開始   : 2026-06-21 08:10:00 (UTC)
* 終了   : 2026-06-21 08:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→7→13→14→7→13→14→10→11
* 開始   : 2026-06-21 19:40:00 (UTC)
* 終了   : 2026-06-21 19:50:00 (UTC)
* 現象   : 平常時(11)に対し 0.6364(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.769σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260621-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→9→5→10→…→10→12→9→7
* 開始   : 2026-06-21 21:35:00 (UTC)
* 終了   : 2026-06-21 21:45:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.5405(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→9→9→9→10→9
* 開始   : 2026-06-22 23:30:00 (UTC)
* 終了   : 2026-06-23 00:00:00 (UTC)
* 現象   : 2026-06-23 00:00:00 (UTC)を境に水準が 15.09から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 7→5→7→11→5→7→11→9→10
* 開始   : 2026-06-22 23:50:00 (UTC)
* 終了   : 2026-06-23 00:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260622-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260622-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→10→13→11→…→11→14→11→12
* 開始   : 2026-06-23 03:35:00 (UTC)
* 終了   : 2026-06-23 03:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→9→14→9→14→9→14→12
* 開始   : 2026-06-23 04:15:00 (UTC)
* 終了   : 2026-06-23 04:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→18→…→17→18→16→14
* 開始   : 2026-06-23 06:15:00 (UTC)
* 終了   : 2026-06-23 06:20:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.108σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→14→18→15→18→15→18→16
* 開始   : 2026-06-23 06:25:00 (UTC)
* 終了   : 2026-06-23 06:35:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→20→19→22→20→21
* 開始   : 2026-06-23 08:40:00 (UTC)
* 終了   : 2026-06-23 08:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→21→16→22→21→16→22→21→20
* 開始   : 2026-06-23 09:35:00 (UTC)
* 終了   : 2026-06-23 09:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→17→18→20→17→18→17
* 開始   : 2026-06-23 15:20:00 (UTC)
* 終了   : 2026-06-23 15:25:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8127(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.751σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→13→15→14→15→14→15→11→14
* 開始   : 2026-06-24 04:30:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→15→13→17→15→16
* 開始   : 2026-06-24 05:45:00 (UTC)
* 終了   : 2026-06-24 05:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.679σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→…→18→14→19→16
* 開始   : 2026-06-24 07:00:00 (UTC)
* 終了   : 2026-06-24 07:45:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 40 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→19→24→21→19→24→21
* 開始   : 2026-06-24 10:30:00 (UTC)
* 終了   : 2026-06-24 10:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→17→20→17→20
* 開始   : 2026-06-24 15:20:00 (UTC)
* 終了   : 2026-06-24 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→19→14→13→…→14→13→16→14
* 開始   : 2026-06-24 17:25:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→13→11→14
* 開始   : 2026-06-24 19:05:00 (UTC)
* 終了   : 2026-06-24 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→11→16→10→11→16→10→11
* 開始   : 2026-06-24 20:00:00 (UTC)
* 終了   : 2026-06-24 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→11→6→11→6→9→8
* 開始   : 2026-06-24 23:05:00 (UTC)
* 終了   : 2026-06-24 23:15:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 7→9→11→12→…→11→12→8→9
* 開始   : 2026-06-24 23:35:00 (UTC)
* 終了   : 2026-06-24 23:40:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→9→13→14→12→9→13→14→12
* 開始   : 2026-06-25 03:50:00 (UTC)
* 終了   : 2026-06-25 03:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→15→17→16→17→16→17→14→16
* 開始   : 2026-06-25 05:45:00 (UTC)
* 終了   : 2026-06-25 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→16→20→16→20→16→20→17
* 開始   : 2026-06-25 07:10:00 (UTC)
* 終了   : 2026-06-25 07:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.244倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.752σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→20→21→20→19
* 開始   : 2026-06-25 08:25:00 (UTC)
* 終了   : 2026-06-25 08:30:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→20→24→22→20→24→22→21
* 開始   : 2026-06-25 10:10:00 (UTC)
* 終了   : 2026-06-25 10:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→21→17→18→21→17→18
* 開始   : 2026-06-25 15:40:00 (UTC)
* 終了   : 2026-06-25 15:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→10→15→12→…→12→16→10→13
* 開始   : 2026-06-26 05:00:00 (UTC)
* 終了   : 2026-06-26 05:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→25→22→23→22→25→23→24
* 開始   : 2026-06-26 11:05:00 (UTC)
* 終了   : 2026-06-26 11:40:00 (UTC)
* 現象   : 2026-06-26 11:40:00 (UTC)を境に水準が 15.04から13.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→21→25→23→…→23→19→22→23
* 開始   : 2026-06-26 12:30:00 (UTC)
* 終了   : 2026-06-26 12:40:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260626-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→16→13→16→13→14→15
* 開始   : 2026-06-26 17:55:00 (UTC)
* 終了   : 2026-06-26 18:05:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→9→12→9→12→9→6
* 開始   : 2026-06-27 01:45:00 (UTC)
* 終了   : 2026-06-27 01:55:00 (UTC)
* 現象   : 土曜1時台の平常値(8.191)に対し 12であった
* 説明   : ALG-A1: 移動平均からの残差が 2.888σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.06σ 外れた (平常値=8.191)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260627-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→10→7→10→…→7→10→11→10
* 開始   : 2026-06-27 04:15:00 (UTC)
* 終了   : 2026-06-27 04:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260627-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260627-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→13→10→13→11→12
* 開始   : 2026-06-27 04:45:00 (UTC)
* 終了   : 2026-06-27 05:55:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.707, 限界=2.667)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 1.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260627-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間

![EVT-20260627-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→8→6→9→8→6→9
* 開始   : 2026-06-27 23:30:00 (UTC)
* 終了   : 2026-06-27 23:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260627-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→11→12
* 開始   : 2026-06-28 03:25:00 (UTC)
* 終了   : 2026-06-28 03:35:00 (UTC)
* 現象   : 2026-06-28 03:35:00 (UTC)を境に水準が 11.79から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.359, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→12→…→12→10→12→11
* 開始   : 2026-06-28 16:30:00 (UTC)
* 終了   : 2026-06-28 16:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→9→10→9→9→10→10→10→10
* 開始   : 2026-06-28 21:15:00 (UTC)
* 終了   : 2026-06-28 21:55:00 (UTC)
* 現象   : 2026-06-28 21:55:00 (UTC)を境に水準が 11.89から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→5→…→12→5→11→8
* 開始   : 2026-06-28 21:35:00 (UTC)
* 終了   : 2026-06-28 21:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260628-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→9→9→10→9→9→10
* 開始   : 2026-06-29 22:00:00 (UTC)
* 終了   : 2026-06-29 22:40:00 (UTC)
* 現象   : 2026-06-29 22:40:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→8→9→12→8→9
* 開始   : 2026-06-30 02:40:00 (UTC)
* 終了   : 2026-06-30 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→14→11→14
* 開始   : 2026-06-30 04:40:00 (UTC)
* 終了   : 2026-06-30 04:45:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14→…→14→17→15→14
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260630-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260630-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→18→17→15→18→15
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→15→19→17
* 開始   : 2026-06-30 06:55:00 (UTC)
* 終了   : 2026-06-30 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→16→15→14→…→15→14→18→16
* 開始   : 2026-06-30 17:00:00 (UTC)
* 終了   : 2026-06-30 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→17→16→16→16→15→15→16→14
* 開始   : 2026-06-30 17:30:00 (UTC)
* 終了   : 2026-06-30 21:00:00 (UTC)
* 現象   : 2026-06-30 21:00:00 (UTC)を境に水準が 15から9.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→13→…→13→8→12→14
* 開始   : 2026-06-30 19:50:00 (UTC)
* 終了   : 2026-06-30 20:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→11→9→11→9→11→13
* 開始   : 2026-06-30 20:05:00 (UTC)
* 終了   : 2026-06-30 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→7→9→7→9→7→8→10
* 開始   : 2026-06-30 21:40:00 (UTC)
* 終了   : 2026-06-30 21:50:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host14-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
