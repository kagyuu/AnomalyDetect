# host16 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host16 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 325 (SEVERE: 20, FATAL: 127, WARN: 178, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 127 | 178 | 325 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→14→…→15→12→14→13
* 開始   : 2026-06-08 01:05:00 (UTC)
* 終了   : 2026-06-08 21:05:00 (UTC)
* 現象   : 2026-06-08 21:05:00 (UTC)を境に水準が 11.72から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.305, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-001 active_connections の推移](charts/EVT-20260608-host16-001.svg)

# イベントID( EVT-20260608-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→…→14→13→14→13
* 開始   : 2026-06-08 01:10:00 (UTC)
* 終了   : 2026-06-08 21:40:00 (UTC)
* 現象   : 2026-06-08 21:40:00 (UTC)を境に水準が 11.88から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.994, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.781, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-002 active_connections の推移](charts/EVT-20260608-host16-002.svg)

# イベントID( EVT-20260608-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→18→15→13→…→17→16→13→12
* 開始   : 2026-06-08 01:25:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.77から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.287, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-003 active_connections の推移](charts/EVT-20260608-host16-003.svg)

# イベントID( EVT-20260608-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→15→17→15→…→14→15→13→14
* 開始   : 2026-06-08 03:05:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.862, 限界=2.708)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.044, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-005 active_connections の推移](charts/EVT-20260608-host16-005.svg)

# イベントID( EVT-20260608-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→16→17→16→…→13→15→14→12
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 21:40:00 (UTC)
* 現象   : 2026-06-08 21:40:00 (UTC)を境に水準が 11.98から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.855, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.706, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-006 active_connections の推移](charts/EVT-20260608-host16-006.svg)

# イベントID( EVT-20260615-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→17→16→17→…→13→16→13→14
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.6σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.116, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-004 active_connections の推移](charts/EVT-20260615-host16-004.svg)

# イベントID( EVT-20260615-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→16→…→12→14→15→13
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 20:20:00 (UTC)
* 現象   : 2026-06-15 20:20:00 (UTC)を境に水準が 11.76から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.305σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.75, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.711, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-005 active_connections の推移](charts/EVT-20260615-host16-005.svg)

# イベントID( EVT-20260615-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→17→14→18→…→14→13→11→9
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 11.8から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.168, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-006 active_connections の推移](charts/EVT-20260615-host16-006.svg)

# イベントID( EVT-20260615-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→15→…→14→15→14→13
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 21:45:00 (UTC)
* 現象   : 2026-06-15 21:45:00 (UTC)を境に水準が 11.8から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.47σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.616, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.066, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-007 active_connections の推移](charts/EVT-20260615-host16-007.svg)

# イベントID( EVT-20260615-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→14→…→13→12→14→13
* 開始   : 2026-06-15 04:35:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.91から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.365σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.836, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-008 active_connections の推移](charts/EVT-20260615-host16-008.svg)

# イベントID( EVT-20260622-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→17→14→13→…→12→14→13→14
* 開始   : 2026-06-22 01:30:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.7から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.823σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.709, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.841, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-001 active_connections の推移](charts/EVT-20260622-host16-001.svg)

# イベントID( EVT-20260622-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→14→13→…→13→11→12→13
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 19:40:00 (UTC)
* 現象   : 2026-06-22 19:40:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.572σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.848, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-002 active_connections の推移](charts/EVT-20260622-host16-002.svg)

# イベントID( EVT-20260622-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→14→…→16→14→12→14
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 23:55:00 (UTC)
* 現象   : 2026-06-22 23:55:00 (UTC)を境に水準が 11.76から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.783, 限界=2.708)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-003 active_connections の推移](charts/EVT-20260622-host16-003.svg)

# イベントID( EVT-20260622-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→19→…→14→15→16→15
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.79から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.94, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.214, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-004 active_connections の推移](charts/EVT-20260622-host16-004.svg)

# イベントID( EVT-20260622-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→18→…→14→13→15→14
* 開始   : 2026-06-22 03:05:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.92から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.6σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.707, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-006 active_connections の推移](charts/EVT-20260622-host16-006.svg)

# イベントID( EVT-20260629-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→13→…→11→13→15→12
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 21:50:00 (UTC)
* 現象   : 2026-06-29 21:50:00 (UTC)を境に水準が 11.84から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.118σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.934, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-001 active_connections の推移](charts/EVT-20260629-host16-001.svg)

# イベントID( EVT-20260629-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→16→…→13→11→13→12
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.813, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.769, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-003 active_connections の推移](charts/EVT-20260629-host16-003.svg)

# イベントID( EVT-20260629-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→17→16→18→…→12→15→14→15
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:25:00 (UTC)
* 現象   : 2026-06-29 21:25:00 (UTC)を境に水準が 11.8から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.896, 限界=2.708)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.924, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-004 active_connections の推移](charts/EVT-20260629-host16-004.svg)

# イベントID( EVT-20260629-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→17→19→17→…→13→15→10→15
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 11.79から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.04, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-005 active_connections の推移](charts/EVT-20260629-host16-005.svg)

# イベントID( EVT-20260629-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→14→…→15→14→15→13
* 開始   : 2026-06-29 03:40:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.977σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.851, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.443, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-006 active_connections の推移](charts/EVT-20260629-host16-006.svg)

# イベントID( EVT-20260601-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→17→21→19→17→21→19
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260601-host16-004 active_connections の推移](charts/EVT-20260601-host16-004.svg)

# イベントID( EVT-20260602-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→9→14→10→12
* 開始   : 2026-06-02 03:40:00 (UTC)
* 終了   : 2026-06-02 03:40:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-004 active_connections の推移](charts/EVT-20260602-host16-004.svg)

# イベントID( EVT-20260602-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→17→16
* 開始   : 2026-06-02 06:25:00 (UTC)
* 終了   : 2026-06-02 06:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host16-005 active_connections の推移](charts/EVT-20260602-host16-005.svg)

# イベントID( EVT-20260602-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→17→20→17→15
* 開始   : 2026-06-02 06:50:00 (UTC)
* 終了   : 2026-06-02 06:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host16-006 active_connections の推移](charts/EVT-20260602-host16-006.svg)

# イベントID( EVT-20260602-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 23→22→25→18→23→22→25→18→23
* 開始   : 2026-06-02 11:55:00 (UTC)
* 終了   : 2026-06-02 12:00:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-007 active_connections の推移](charts/EVT-20260602-host16-007.svg)

# イベントID( EVT-20260602-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→21→26→22→24
* 開始   : 2026-06-02 12:20:00 (UTC)
* 終了   : 2026-06-02 12:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host16-008 active_connections の推移](charts/EVT-20260602-host16-008.svg)

# イベントID( EVT-20260602-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→15→11→14→14
* 開始   : 2026-06-02 18:10:00 (UTC)
* 終了   : 2026-06-02 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-011 active_connections の推移](charts/EVT-20260602-host16-011.svg)

# イベントID( EVT-20260602-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→8→11
* 開始   : 2026-06-02 21:00:00 (UTC)
* 終了   : 2026-06-02 21:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.4615(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host16-012 active_connections の推移](charts/EVT-20260602-host16-012.svg)

# イベントID( EVT-20260603-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→13→…→13→10→6→10
* 開始   : 2026-06-03 01:55:00 (UTC)
* 終了   : 2026-06-03 02:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 20 分
  - EVT-20260603-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-001 active_connections の推移](charts/EVT-20260603-host16-001.svg)

# イベントID( EVT-20260603-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→19→…→19→22→18→19
* 開始   : 2026-06-03 08:15:00 (UTC)
* 終了   : 2026-06-03 08:25:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.924σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-008 active_connections の推移](charts/EVT-20260603-host16-008.svg)

# イベントID( EVT-20260603-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→18→20
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.409σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host16-009 active_connections の推移](charts/EVT-20260603-host16-009.svg)

# イベントID( EVT-20260603-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→11→9→13→14
* 開始   : 2026-06-03 19:20:00 (UTC)
* 終了   : 2026-06-03 19:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-015 active_connections の推移](charts/EVT-20260603-host16-015.svg)

# イベントID( EVT-20260604-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→8→12→7→8
* 開始   : 2026-06-04 00:50:00 (UTC)
* 終了   : 2026-06-04 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→8→12→7→9
* 開始   : 2026-06-04 01:30:00 (UTC)
* 終了   : 2026-06-04 01:30:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.117σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260604-host16-002 active_connections の推移](charts/EVT-20260604-host16-002.svg)

# イベントID( EVT-20260604-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→19→20→18→22→20→18→22→17
* 開始   : 2026-06-04 07:45:00 (UTC)
* 終了   : 2026-06-04 07:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-007 active_connections の推移](charts/EVT-20260604-host16-007.svg)

# イベントID( EVT-20260604-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→22→26→20→19
* 開始   : 2026-06-04 12:40:00 (UTC)
* 終了   : 2026-06-04 12:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→14→12
* 開始   : 2026-06-05 04:40:00 (UTC)
* 終了   : 2026-06-05 04:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-003 active_connections の推移](charts/EVT-20260605-host16-003.svg)

# イベントID( EVT-20260605-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→18→23→19→19
* 開始   : 2026-06-05 08:45:00 (UTC)
* 終了   : 2026-06-05 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host16-006 active_connections の推移](charts/EVT-20260605-host16-006.svg)

# イベントID( EVT-20260606-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→12→10→11→…→14→11→14→15
* 開始   : 2026-06-06 04:45:00 (UTC)
* 終了   : 2026-06-06 20:10:00 (UTC)
* 現象   : 15.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.748, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260606-host16-002 active_connections の推移](charts/EVT-20260606-host16-002.svg)

# イベントID( EVT-20260606-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→13→…→10→12→11→12
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 20:05:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.294σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.289, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260606-host16-003 active_connections の推移](charts/EVT-20260606-host16-003.svg)

# イベントID( EVT-20260606-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→…→11→10→11→10
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.146, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host16-004 active_connections の推移](charts/EVT-20260606-host16-004.svg)

# イベントID( EVT-20260606-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→9→10→…→9→13→9→11
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.989, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host16-005 active_connections の推移](charts/EVT-20260606-host16-005.svg)

# イベントID( EVT-20260606-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→12→…→11→13→14→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.74, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host16-006 active_connections の推移](charts/EVT-20260606-host16-006.svg)

# イベントID( EVT-20260606-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→12→…→9→10→11→12
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host16-007 active_connections の推移](charts/EVT-20260606-host16-007.svg)

# イベントID( EVT-20260607-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→8→12→8→7
* 開始   : 2026-06-07 00:05:00 (UTC)
* 終了   : 2026-06-07 00:05:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.178σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host16-001 active_connections の推移](charts/EVT-20260607-host16-001.svg)

# イベントID( EVT-20260607-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→7→13→9→9
* 開始   : 2026-06-07 22:00:00 (UTC)
* 終了   : 2026-06-07 22:00:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host16-007 active_connections の推移](charts/EVT-20260607-host16-007.svg)

# イベントID( EVT-20260608-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→16→14→16→…→15→14→12→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.91から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.869, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-004 active_connections の推移](charts/EVT-20260608-host16-004.svg)

# イベントID( EVT-20260608-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→8→4→6→6
* 開始   : 2026-06-08 23:50:00 (UTC)
* 終了   : 2026-06-08 23:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host16-007 active_connections の推移](charts/EVT-20260608-host16-007.svg)

# イベントID( EVT-20260609-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→8→13→7→6
* 開始   : 2026-06-09 01:20:00 (UTC)
* 終了   : 2026-06-09 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.236σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-002 active_connections の推移](charts/EVT-20260609-host16-002.svg)

# イベントID( EVT-20260609-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→18→16→13
* 開始   : 2026-06-09 06:05:00 (UTC)
* 終了   : 2026-06-09 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.235σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-006 active_connections の推移](charts/EVT-20260609-host16-006.svg)

# イベントID( EVT-20260609-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→17→22→18→20
* 開始   : 2026-06-09 08:20:00 (UTC)
* 終了   : 2026-06-09 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-007 active_connections の推移](charts/EVT-20260609-host16-007.svg)

# イベントID( EVT-20260609-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→18→23→21→18
* 開始   : 2026-06-09 08:35:00 (UTC)
* 終了   : 2026-06-09 08:35:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host16-008 active_connections の推移](charts/EVT-20260609-host16-008.svg)

# イベントID( EVT-20260609-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 24→21
* 開始   : 2026-06-09 08:55:00 (UTC)
* 終了   : 2026-06-09 09:00:00 (UTC)
* 現象   : 2026-06-09 09:00:00 (UTC)を境に水準が 14.93から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.705σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.517, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-009 active_connections の推移](charts/EVT-20260609-host16-009.svg)

# イベントID( EVT-20260609-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→12→10→14→14
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-013 active_connections の推移](charts/EVT-20260609-host16-013.svg)

# イベントID( EVT-20260610-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→17→15→13
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.427倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host16-004 active_connections の推移](charts/EVT-20260610-host16-004.svg)

# イベントID( EVT-20260610-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→15→14→16→15→15→17→16→16
* 開始   : 2026-06-10 05:10:00 (UTC)
* 終了   : 2026-06-10 06:00:00 (UTC)
* 現象   : 2026-06-10 06:00:00 (UTC)を境に水準が 15.07から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.529σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.841, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host16-005 active_connections の推移](charts/EVT-20260610-host16-005.svg)

# イベントID( EVT-20260610-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→18→23→21→21
* 開始   : 2026-06-10 09:00:00 (UTC)
* 終了   : 2026-06-10 09:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.284倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host16-010 active_connections の推移](charts/EVT-20260610-host16-010.svg)

# イベントID( EVT-20260610-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→9→9
* 開始   : 2026-06-10 22:10:00 (UTC)
* 終了   : 2026-06-10 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host16-013 active_connections の推移](charts/EVT-20260610-host16-013.svg)

# イベントID( EVT-20260611-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→11→12→14→11
* 開始   : 2026-06-11 03:20:00 (UTC)
* 終了   : 2026-06-11 03:45:00 (UTC)
* 現象   : 2026-06-11 03:45:00 (UTC)を境に水準が 14.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.529σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.029σ 外れた (平常値=10.77)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.291, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→11→14→12→10
* 開始   : 2026-06-11 03:35:00 (UTC)
* 終了   : 2026-06-11 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-002 active_connections の推移](charts/EVT-20260611-host16-002.svg)

# イベントID( EVT-20260611-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→10→12
* 開始   : 2026-06-11 03:55:00 (UTC)
* 終了   : 2026-06-11 03:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260611-host16-003 active_connections の推移](charts/EVT-20260611-host16-003.svg)

# イベントID( EVT-20260611-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→12→17→13→14
* 開始   : 2026-06-11 05:10:00 (UTC)
* 終了   : 2026-06-11 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-004 active_connections の推移](charts/EVT-20260611-host16-004.svg)

# イベントID( EVT-20260611-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→23→23
* 開始   : 2026-06-11 10:10:00 (UTC)
* 終了   : 2026-06-11 10:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host16-009 active_connections の推移](charts/EVT-20260611-host16-009.svg)

# イベントID( EVT-20260611-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→20→22→21→22
* 開始   : 2026-06-11 15:25:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 2026-06-11 15:50:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.111σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.711, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→14→15→17→19→14→15→17→18
* 開始   : 2026-06-11 16:30:00 (UTC)
* 終了   : 2026-06-11 16:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-011 active_connections の推移](charts/EVT-20260611-host16-011.svg)

# イベントID( EVT-20260611-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→11→14→12→11→14→12→13→12
* 開始   : 2026-06-11 18:20:00 (UTC)
* 終了   : 2026-06-11 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.118σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-013 active_connections の推移](charts/EVT-20260611-host16-013.svg)

# イベントID( EVT-20260612-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→17→15→17→15→17→14→15
* 開始   : 2026-06-12 05:15:00 (UTC)
* 終了   : 2026-06-12 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host16-001 active_connections の推移](charts/EVT-20260612-host16-001.svg)

# イベントID( EVT-20260612-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→14→15
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.409σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host16-003 active_connections の推移](charts/EVT-20260612-host16-003.svg)

# イベントID( EVT-20260612-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→20→23→19→21
* 開始   : 2026-06-12 08:25:00 (UTC)
* 終了   : 2026-06-12 08:25:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-004 active_connections の推移](charts/EVT-20260612-host16-004.svg)

# イベントID( EVT-20260612-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→18→15→20→19
* 開始   : 2026-06-12 16:15:00 (UTC)
* 終了   : 2026-06-12 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-008 active_connections の推移](charts/EVT-20260612-host16-008.svg)

# イベントID( EVT-20260613-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→8→13→10→9
* 開始   : 2026-06-13 02:05:00 (UTC)
* 終了   : 2026-06-13 02:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→12→10→12→…→12→11→12→13
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 19:50:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.871, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.4 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260613-host16-003 active_connections の推移](charts/EVT-20260613-host16-003.svg)

# イベントID( EVT-20260613-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→11→13→11→…→10→11→13→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.71, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host16-004 active_connections の推移](charts/EVT-20260613-host16-004.svg)

# イベントID( EVT-20260613-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→12→11→…→12→9→11→12
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.47σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host16-005 active_connections の推移](charts/EVT-20260613-host16-005.svg)

# イベントID( EVT-20260613-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→11→10→11→10
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.294σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host16-006 active_connections の推移](charts/EVT-20260613-host16-006.svg)

# イベントID( EVT-20260613-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→12→…→10→11→12→10
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.054σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.037, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host16-007 active_connections の推移](charts/EVT-20260613-host16-007.svg)

# イベントID( EVT-20260613-host16-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→13→12→13
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.041, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host16-008 active_connections の推移](charts/EVT-20260613-host16-008.svg)

# イベントID( EVT-20260614-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→9→12
* 開始   : 2026-06-14 20:15:00 (UTC)
* 終了   : 2026-06-14 20:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.4839(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.765σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host16-004 active_connections の推移](charts/EVT-20260614-host16-004.svg)

# イベントID( EVT-20260615-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→14→…→15→16→13→14
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.987, 限界=2.708)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.849, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-002 active_connections の推移](charts/EVT-20260615-host16-002.svg)

# イベントID( EVT-20260616-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→16→14→13
* 開始   : 2026-06-16 04:30:00 (UTC)
* 終了   : 2026-06-16 04:30:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host16-001 active_connections の推移](charts/EVT-20260616-host16-001.svg)

# イベントID( EVT-20260616-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→14→14
* 開始   : 2026-06-16 05:40:00 (UTC)
* 終了   : 2026-06-16 05:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host16-003 active_connections の推移](charts/EVT-20260616-host16-003.svg)

# イベントID( EVT-20260616-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 24→20→17→21→21
* 開始   : 2026-06-16 14:05:00 (UTC)
* 終了   : 2026-06-16 14:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host16-007 active_connections の推移](charts/EVT-20260616-host16-007.svg)

# イベントID( EVT-20260616-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→17→12→16→18
* 開始   : 2026-06-16 17:15:00 (UTC)
* 終了   : 2026-06-16 17:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6923(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host16-008 active_connections の推移](charts/EVT-20260616-host16-008.svg)

# イベントID( EVT-20260616-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→17→12→18→14
* 開始   : 2026-06-16 17:35:00 (UTC)
* 終了   : 2026-06-16 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host16-009 active_connections の推移](charts/EVT-20260616-host16-009.svg)

# イベントID( EVT-20260616-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→16→12→16→16
* 開始   : 2026-06-16 17:55:00 (UTC)
* 終了   : 2026-06-16 17:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host16-010 active_connections の推移](charts/EVT-20260616-host16-010.svg)

# イベントID( EVT-20260617-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→10→11
* 開始   : 2026-06-17 03:50:00 (UTC)
* 終了   : 2026-06-17 03:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.524倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.814σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-002 active_connections の推移](charts/EVT-20260617-host16-002.svg)

# イベントID( EVT-20260617-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→16
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 06:15:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host16-003 active_connections の推移](charts/EVT-20260617-host16-003.svg)

# イベントID( EVT-20260617-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→18→22→19→19
* 開始   : 2026-06-17 08:05:00 (UTC)
* 終了   : 2026-06-17 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host16-005 active_connections の推移](charts/EVT-20260617-host16-005.svg)

# イベントID( EVT-20260617-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→19→15→18→19
* 開始   : 2026-06-17 15:45:00 (UTC)
* 終了   : 2026-06-17 15:45:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.7531(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.471σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host16-008 active_connections の推移](charts/EVT-20260617-host16-008.svg)

# イベントID( EVT-20260617-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→10→…→10→11→13→12
* 開始   : 2026-06-17 19:00:00 (UTC)
* 終了   : 2026-06-17 19:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260617-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host16-011 active_connections の推移](charts/EVT-20260617-host16-011.svg)

# イベントID( EVT-20260617-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→14→8→14→13
* 開始   : 2026-06-17 19:35:00 (UTC)
* 終了   : 2026-06-17 19:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-012 active_connections の推移](charts/EVT-20260617-host16-012.svg)

# イベントID( EVT-20260618-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→18→13→15→16
* 開始   : 2026-06-18 17:00:00 (UTC)
* 終了   : 2026-06-18 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-006 active_connections の推移](charts/EVT-20260618-host16-006.svg)

# イベントID( EVT-20260618-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→16→9→13→13
* 開始   : 2026-06-18 18:55:00 (UTC)
* 終了   : 2026-06-18 18:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6067(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host16-007 active_connections の推移](charts/EVT-20260618-host16-007.svg)

# イベントID( EVT-20260619-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→17→13→16→20
* 開始   : 2026-06-19 16:55:00 (UTC)
* 終了   : 2026-06-19 16:55:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host16-007 active_connections の推移](charts/EVT-20260619-host16-007.svg)

# イベントID( EVT-20260620-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→10→4→9→6
* 開始   : 2026-06-20 01:55:00 (UTC)
* 終了   : 2026-06-20 01:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host16-001 active_connections の推移](charts/EVT-20260620-host16-001.svg)

# イベントID( EVT-20260620-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→12→10→13→…→13→12→13→14
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host16-002 active_connections の推移](charts/EVT-20260620-host16-002.svg)

# イベントID( EVT-20260620-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→10→9→12→…→10→12→13→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.042, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host16-003 active_connections の推移](charts/EVT-20260620-host16-003.svg)

# イベントID( EVT-20260620-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→11→13→11→…→12→10→12→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:40:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.892, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host16-004 active_connections の推移](charts/EVT-20260620-host16-004.svg)

# イベントID( EVT-20260620-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→10→…→12→11→10→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.876, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host16-005 active_connections の推移](charts/EVT-20260620-host16-005.svg)

# イベントID( EVT-20260620-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→12→…→11→12→13→12
* 開始   : 2026-06-20 06:20:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.883, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host16-006 active_connections の推移](charts/EVT-20260620-host16-006.svg)

# イベントID( EVT-20260620-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→13→…→12→11→12→10
* 開始   : 2026-06-20 06:25:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.679, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260620-host16-007 active_connections の推移](charts/EVT-20260620-host16-007.svg)

# イベントID( EVT-20260620-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→12→5→11→9
* 開始   : 2026-06-20 20:55:00 (UTC)
* 終了   : 2026-06-20 20:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host16-008 active_connections の推移](charts/EVT-20260620-host16-008.svg)

# イベントID( EVT-20260620-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 7→9→13→10→…→10→5→10→9
* 開始   : 2026-06-20 21:25:00 (UTC)
* 終了   : 2026-06-20 21:35:00 (UTC)
* 現象   : 土曜21時台の平常値(8.894)に対し 13であった
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.227σ 外れた (平常値=8.894)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260620-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260620-host16-009 active_connections の推移](charts/EVT-20260620-host16-009.svg)

# イベントID( EVT-20260621-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→13→11→14→13→11→14→11→10
* 開始   : 2026-06-21 04:15:00 (UTC)
* 終了   : 2026-06-21 04:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→11→16→13→13
* 開始   : 2026-06-21 06:45:00 (UTC)
* 終了   : 2026-06-21 06:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host16-003 active_connections の推移](charts/EVT-20260621-host16-003.svg)

# イベントID( EVT-20260621-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→12→18→13→12
* 開始   : 2026-06-21 08:10:00 (UTC)
* 終了   : 2026-06-21 08:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host16-005 active_connections の推移](charts/EVT-20260621-host16-005.svg)

# イベントID( EVT-20260621-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→18→18
* 開始   : 2026-06-21 10:55:00 (UTC)
* 終了   : 2026-06-21 11:25:00 (UTC)
* 現象   : 2026-06-21 11:25:00 (UTC)を境に水準が 11.84から13.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.621σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.627, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-007 active_connections の推移](charts/EVT-20260621-host16-007.svg)

# イベントID( EVT-20260621-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→9→10→10→9→10→9
* 開始   : 2026-06-21 22:30:00 (UTC)
* 終了   : 2026-06-21 23:40:00 (UTC)
* 現象   : 2026-06-21 23:40:00 (UTC)を境に水準が 11.75から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-009 active_connections の推移](charts/EVT-20260621-host16-009.svg)

# イベントID( EVT-20260622-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→14→15→…→16→14→13→15
* 開始   : 2026-06-22 03:05:00 (UTC)
* 終了   : 2026-06-22 21:00:00 (UTC)
* 現象   : 2026-06-22 21:00:00 (UTC)を境に水準が 11.96から15.17へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.839, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.203, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-005 active_connections の推移](charts/EVT-20260622-host16-005.svg)

# イベントID( EVT-20260623-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→14→16→13→12
* 開始   : 2026-06-23 04:40:00 (UTC)
* 終了   : 2026-06-23 04:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host16-001 active_connections の推移](charts/EVT-20260623-host16-001.svg)

# イベントID( EVT-20260623-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→…→17→21→16→19
* 開始   : 2026-06-23 07:05:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-003 active_connections の推移](charts/EVT-20260623-host16-003.svg)

# イベントID( EVT-20260623-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→21→27→22→21
* 開始   : 2026-06-23 11:25:00 (UTC)
* 終了   : 2026-06-23 11:25:00 (UTC)
* 現象   : 平常時(22)に対し 1.227倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host16-006 active_connections の推移](charts/EVT-20260623-host16-006.svg)

# イベントID( EVT-20260623-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→12→6→11→…→11→7→9→10
* 開始   : 2026-06-23 21:20:00 (UTC)
* 終了   : 2026-06-23 21:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.118σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-056 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260623-host16-011 active_connections の推移](charts/EVT-20260623-host16-011.svg)

# イベントID( EVT-20260623-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→9→4→6→7
* 開始   : 2026-06-23 22:55:00 (UTC)
* 終了   : 2026-06-23 22:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-012 active_connections の推移](charts/EVT-20260623-host16-012.svg)

# イベントID( EVT-20260624-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 7→7→13→10→10
* 開始   : 2026-06-24 02:15:00 (UTC)
* 終了   : 2026-06-24 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260624-host16-001 active_connections の推移](charts/EVT-20260624-host16-001.svg)

# イベントID( EVT-20260624-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→22→24→21→20→22→24→21→20
* 開始   : 2026-06-24 09:15:00 (UTC)
* 終了   : 2026-06-24 09:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host16-004 active_connections の推移](charts/EVT-20260624-host16-004.svg)

# イベントID( EVT-20260624-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→24→…→25→24→20→22
* 開始   : 2026-06-24 10:20:00 (UTC)
* 終了   : 2026-06-24 10:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-005 active_connections の推移](charts/EVT-20260624-host16-005.svg)

# イベントID( EVT-20260624-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→18→13→16→17
* 開始   : 2026-06-24 17:00:00 (UTC)
* 終了   : 2026-06-24 17:00:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host16-009 active_connections の推移](charts/EVT-20260624-host16-009.svg)

# イベントID( EVT-20260624-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→16→11→14→16
* 開始   : 2026-06-24 18:15:00 (UTC)
* 終了   : 2026-06-24 18:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-012 active_connections の推移](charts/EVT-20260624-host16-012.svg)

# イベントID( EVT-20260624-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→14→10→13→13
* 開始   : 2026-06-24 18:50:00 (UTC)
* 終了   : 2026-06-24 18:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host16-013 active_connections の推移](charts/EVT-20260624-host16-013.svg)

# イベントID( EVT-20260624-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→7→11→11
* 開始   : 2026-06-24 20:10:00 (UTC)
* 終了   : 2026-06-24 20:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.815σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-014 active_connections の推移](charts/EVT-20260624-host16-014.svg)

# イベントID( EVT-20260624-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→11→7→10→10
* 開始   : 2026-06-24 21:00:00 (UTC)
* 終了   : 2026-06-24 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-015 active_connections の推移](charts/EVT-20260624-host16-015.svg)

# イベントID( EVT-20260624-host16-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→11→5→10→10
* 開始   : 2026-06-24 21:35:00 (UTC)
* 終了   : 2026-06-24 21:35:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.4762(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.815σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host16-017 active_connections の推移](charts/EVT-20260624-host16-017.svg)

# イベントID( EVT-20260625-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→19→18→19→18→19→17
* 開始   : 2026-06-25 05:35:00 (UTC)
* 終了   : 2026-06-25 06:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 55 分
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host16-002 active_connections の推移](charts/EVT-20260625-host16-002.svg)

# イベントID( EVT-20260625-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→16→21→17→19
* 開始   : 2026-06-25 07:35:00 (UTC)
* 終了   : 2026-06-25 07:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host16-003 active_connections の推移](charts/EVT-20260625-host16-003.svg)

# イベントID( EVT-20260625-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→19→21→23→…→18→22→20→21
* 開始   : 2026-06-25 08:20:00 (UTC)
* 終了   : 2026-06-25 08:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host16-004 active_connections の推移](charts/EVT-20260625-host16-004.svg)

# イベントID( EVT-20260625-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→20→26→23→22
* 開始   : 2026-06-25 13:00:00 (UTC)
* 終了   : 2026-06-25 13:00:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→8→14→13
* 開始   : 2026-06-25 19:20:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.5818(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-068 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-010 active_connections の推移](charts/EVT-20260625-host16-010.svg)

# イベントID( EVT-20260625-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→9→4→10→10
* 開始   : 2026-06-25 22:10:00 (UTC)
* 終了   : 2026-06-25 22:10:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.4211(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.86σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host16-012 active_connections の推移](charts/EVT-20260625-host16-012.svg)

# イベントID( EVT-20260626-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→15→14
* 開始   : 2026-06-26 05:35:00 (UTC)
* 終了   : 2026-06-26 05:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host16-003 active_connections の推移](charts/EVT-20260626-host16-003.svg)

# イベントID( EVT-20260626-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 23→23→18→22→20
* 開始   : 2026-06-26 13:00:00 (UTC)
* 終了   : 2026-06-26 13:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-007 active_connections の推移](charts/EVT-20260626-host16-007.svg)

# イベントID( EVT-20260626-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→13→14→13→14→13→15
* 開始   : 2026-06-26 18:00:00 (UTC)
* 終了   : 2026-06-26 18:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host16-012 active_connections の推移](charts/EVT-20260626-host16-012.svg)

# イベントID( EVT-20260626-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→16→11→14→15
* 開始   : 2026-06-26 18:05:00 (UTC)
* 終了   : 2026-06-26 18:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.471σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-013 active_connections の推移](charts/EVT-20260626-host16-013.svg)

# イベントID( EVT-20260627-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→9→11→12→…→11→13→11→12
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.676, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host16-003 active_connections の推移](charts/EVT-20260627-host16-003.svg)

# イベントID( EVT-20260627-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→10→11→12→…→14→15→12→14
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.3 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host16-004 active_connections の推移](charts/EVT-20260627-host16-004.svg)

# イベントID( EVT-20260627-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→11→…→14→10→11→12
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host16-005 active_connections の推移](charts/EVT-20260627-host16-005.svg)

# イベントID( EVT-20260627-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→13→…→11→9→11→13
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.134σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host16-006 active_connections の推移](charts/EVT-20260627-host16-006.svg)

# イベントID( EVT-20260627-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→…→10→12→13→11
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 18:40:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.388, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host16-007 active_connections の推移](charts/EVT-20260627-host16-007.svg)

# イベントID( EVT-20260627-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→10→11→12→…→10→9→12→10
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.19σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.703, 限界=2.656)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host16-008 active_connections の推移](charts/EVT-20260627-host16-008.svg)

# イベントID( EVT-20260628-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→10→16→11→12
* 開始   : 2026-06-28 05:50:00 (UTC)
* 終了   : 2026-06-28 05:50:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.583σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host16-002 active_connections の推移](charts/EVT-20260628-host16-002.svg)

# イベントID( EVT-20260628-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→13→13
* 開始   : 2026-06-28 06:55:00 (UTC)
* 終了   : 2026-06-28 06:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.236σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host16-003 active_connections の推移](charts/EVT-20260628-host16-003.svg)

# イベントID( EVT-20260628-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→18→15→16→18→17→16→18
* 開始   : 2026-06-28 13:00:00 (UTC)
* 終了   : 2026-06-28 14:05:00 (UTC)
* 現象   : 2026-06-28 14:05:00 (UTC)を境に水準が 11.96から13.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.177σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.066, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→11→15→14
* 開始   : 2026-06-28 15:10:00 (UTC)
* 終了   : 2026-06-28 15:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→16→9→13→14
* 開始   : 2026-06-28 17:20:00 (UTC)
* 終了   : 2026-06-28 17:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260628-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host16-008 active_connections の推移](charts/EVT-20260628-host16-008.svg)

# イベントID( EVT-20260629-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→16→17→15→…→13→15→13→15
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 21:30:00 (UTC)
* 現象   : 2026-06-29 21:30:00 (UTC)を境に水準が 11.93から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.072, 限界=2.656)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.274, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-002 active_connections の推移](charts/EVT-20260629-host16-002.svg)

# イベントID( EVT-20260630-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→13→18→16→15
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-007 active_connections の推移](charts/EVT-20260630-host16-007.svg)

# イベントID( EVT-20260630-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→21→17→19→20
* 開始   : 2026-06-30 14:00:00 (UTC)
* 終了   : 2026-06-30 14:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.111σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-008 active_connections の推移](charts/EVT-20260630-host16-008.svg)

# イベントID( EVT-20260601-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→8→11→8→12→11→8→12→8
* 開始   : 2026-06-01 01:50:00 (UTC)
* 終了   : 2026-06-01 02:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→12→17→15→17→15→17→16→17
* 開始   : 2026-06-01 05:55:00 (UTC)
* 終了   : 2026-06-01 06:05:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.658σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260601-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→15→19→15→19→15→19→17→14
* 開始   : 2026-06-01 06:35:00 (UTC)
* 終了   : 2026-06-01 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.766σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 24→21→19→18→…→18→17→22→20
* 開始   : 2026-06-01 14:10:00 (UTC)
* 終了   : 2026-06-01 14:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→22→19→16→22→19→16→18→17
* 開始   : 2026-06-01 16:05:00 (UTC)
* 終了   : 2026-06-01 16:15:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→13→16→13→…→16→13→14→13
* 開始   : 2026-06-01 17:55:00 (UTC)
* 終了   : 2026-06-01 18:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→8→9→12→9→8→9
* 開始   : 2026-06-01 20:55:00 (UTC)
* 終了   : 2026-06-01 21:00:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→11→8→5→11→8→5→7→10
* 開始   : 2026-06-02 00:55:00 (UTC)
* 終了   : 2026-06-02 01:05:00 (UTC)
* 現象   : 火曜0時台の平常値(8.017)に対し 11であった
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.387σ 外れた (平常値=8.017)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260602-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260602-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→12→11→8→12→11→8
* 開始   : 2026-06-02 01:40:00 (UTC)
* 終了   : 2026-06-02 01:45:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.889σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260602-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→13→…→7→13→10→13
* 開始   : 2026-06-02 03:25:00 (UTC)
* 終了   : 2026-06-02 03:50:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→19→18→19→18→19→21
* 開始   : 2026-06-02 14:20:00 (UTC)
* 終了   : 2026-06-02 14:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.42σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→16→18→15→16
* 開始   : 2026-06-02 17:05:00 (UTC)
* 終了   : 2026-06-02 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.294σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 6→9→11→8→11→8→11→7→8
* 開始   : 2026-06-02 23:05:00 (UTC)
* 終了   : 2026-06-02 23:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→11→14→11→14→11→13
* 開始   : 2026-06-03 03:45:00 (UTC)
* 終了   : 2026-06-03 03:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.651σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→14→10→14→11→13
* 開始   : 2026-06-03 04:35:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→15→10→15→10→15→14→13
* 開始   : 2026-06-03 04:35:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→11→15→13→15→13→15→12
* 開始   : 2026-06-03 04:50:00 (UTC)
* 終了   : 2026-06-03 05:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.249σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260603-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→17→15→18→17→15→18→15→16
* 開始   : 2026-06-03 05:55:00 (UTC)
* 終了   : 2026-06-03 06:05:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→16→21→18→16→21→18→19
* 開始   : 2026-06-03 07:55:00 (UTC)
* 終了   : 2026-06-03 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→26→19→22→26→19→22
* 開始   : 2026-06-03 13:00:00 (UTC)
* 終了   : 2026-06-03 13:05:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.195倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.979σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→15→17→19→16→15→17
* 開始   : 2026-06-03 16:30:00 (UTC)
* 終了   : 2026-06-03 16:35:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→16→14→17→…→17→13→16→15
* 開始   : 2026-06-03 17:30:00 (UTC)
* 終了   : 2026-06-03 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→15→13→14→15
* 開始   : 2026-06-03 17:50:00 (UTC)
* 終了   : 2026-06-03 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→12→…→13→12→14→13
* 開始   : 2026-06-03 18:15:00 (UTC)
* 終了   : 2026-06-03 18:20:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→8→11→12→8→11→9
* 開始   : 2026-06-03 21:15:00 (UTC)
* 終了   : 2026-06-03 21:20:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→15→11→14→15→11
* 開始   : 2026-06-04 04:25:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→15→14→15→12→13
* 開始   : 2026-06-04 04:30:00 (UTC)
* 終了   : 2026-06-04 04:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260604-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→14→17→16→14→17→13
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260604-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→16→18→19→15→16→18→19→20
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 07:55:00 (UTC)
* 現象   : 2026-06-04 07:55:00 (UTC)を境に水準が 15.04から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→20→22→20→22→20→21
* 開始   : 2026-06-04 08:35:00 (UTC)
* 終了   : 2026-06-04 08:40:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→22→22→23→22→23→22→24
* 開始   : 2026-06-04 13:15:00 (UTC)
* 終了   : 2026-06-04 13:50:00 (UTC)
* 現象   : 2026-06-04 13:50:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.066, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→21→18→21→…→21→24→22→20
* 開始   : 2026-06-04 13:50:00 (UTC)
* 終了   : 2026-06-04 14:00:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→19→17→20→19→17→20
* 開始   : 2026-06-04 15:30:00 (UTC)
* 終了   : 2026-06-04 15:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→12→9→11→12→9→11→13
* 開始   : 2026-06-04 19:40:00 (UTC)
* 終了   : 2026-06-04 19:45:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host16-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→10→16→12→…→16→12→10→11
* 開始   : 2026-06-04 19:40:00 (UTC)
* 終了   : 2026-06-04 19:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host16-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→9→11→7→10→10→10
* 開始   : 2026-06-04 21:20:00 (UTC)
* 終了   : 2026-06-04 22:35:00 (UTC)
* 現象   : 2026-06-04 22:35:00 (UTC)を境に水準が 14.9から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.132, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→8→11→5→…→11→5→9→10
* 開始   : 2026-06-05 00:30:00 (UTC)
* 終了   : 2026-06-05 00:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→9→12→9→12→10→12
* 開始   : 2026-06-05 02:45:00 (UTC)
* 終了   : 2026-06-05 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260605-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→14→18→15→17→15→15
* 開始   : 2026-06-05 05:45:00 (UTC)
* 終了   : 2026-06-05 06:15:00 (UTC)
* 現象   : 2026-06-05 06:15:00 (UTC)を境に水準が 14.99から14.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.256, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→14→19→14→19→18→16
* 開始   : 2026-06-05 06:45:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→19→23→22→…→22→24→23→21
* 開始   : 2026-06-05 10:20:00 (UTC)
* 終了   : 2026-06-05 10:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→25→21→18→25→21→18→22→20
* 開始   : 2026-06-05 13:20:00 (UTC)
* 終了   : 2026-06-05 13:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260605-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→20→17→18→16→17→18→16→18
* 開始   : 2026-06-05 15:50:00 (UTC)
* 終了   : 2026-06-05 16:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.412σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→18→17→18→…→18→16→17→18
* 開始   : 2026-06-05 15:50:00 (UTC)
* 終了   : 2026-06-05 16:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.362σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→15→17→14→15→17→14→16→17
* 開始   : 2026-06-05 16:50:00 (UTC)
* 終了   : 2026-06-05 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→18→17→17→18→15→19
* 開始   : 2026-06-05 17:05:00 (UTC)
* 終了   : 2026-06-05 18:45:00 (UTC)
* 現象   : 2026-06-05 18:45:00 (UTC)を境に水準が 15.02から12.27へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.118σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→9→8→11→12→9→8→11→9
* 開始   : 2026-06-05 20:35:00 (UTC)
* 終了   : 2026-06-05 20:40:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.7606(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260605-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→10→8→7→10→8→7→10→11
* 開始   : 2026-06-05 20:40:00 (UTC)
* 終了   : 2026-06-05 20:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 8→6→10→12→6→10→12→7→9
* 開始   : 2026-06-05 22:10:00 (UTC)
* 終了   : 2026-06-05 22:20:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→10→5→11→…→5→11→7→9
* 開始   : 2026-06-06 00:25:00 (UTC)
* 終了   : 2026-06-06 00:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.412σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260606-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→8→…→8→5→8→10
* 開始   : 2026-06-07 00:45:00 (UTC)
* 終了   : 2026-06-07 00:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.536σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260607-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→12→…→6→12→9→10
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 04:00:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→12→12→14→13→13
* 開始   : 2026-06-07 04:45:00 (UTC)
* 終了   : 2026-06-07 05:55:00 (UTC)
* 現象   : 2026-06-07 05:55:00 (UTC)を境に水準が 11.76から12.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.253, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→14→14→16→13→15→16
* 開始   : 2026-06-07 07:05:00 (UTC)
* 終了   : 2026-06-07 09:05:00 (UTC)
* 現象   : 2026-06-07 09:05:00 (UTC)を境に水準が 11.81から12.53へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.969, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→10→10→11
* 開始   : 2026-06-07 21:10:00 (UTC)
* 終了   : 2026-06-07 21:35:00 (UTC)
* 現象   : 2026-06-07 21:35:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→8→11→7→9→8→10
* 開始   : 2026-06-09 00:05:00 (UTC)
* 終了   : 2026-06-09 00:35:00 (UTC)
* 現象   : 2026-06-09 00:35:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.808, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→11→12→11→12→9→12
* 開始   : 2026-06-09 03:00:00 (UTC)
* 終了   : 2026-06-09 03:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→10→…→10→13→12→11
* 開始   : 2026-06-09 03:10:00 (UTC)
* 終了   : 2026-06-09 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→13→…→13→16→14→15
* 開始   : 2026-06-09 04:45:00 (UTC)
* 終了   : 2026-06-09 04:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→22→23→21→22→22→24→22→24
* 開始   : 2026-06-09 11:30:00 (UTC)
* 終了   : 2026-06-09 12:35:00 (UTC)
* 現象   : 2026-06-09 12:35:00 (UTC)を境に水準が 14.95から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.616, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 25→23→22→21→25
* 開始   : 2026-06-09 13:25:00 (UTC)
* 終了   : 2026-06-09 13:45:00 (UTC)
* 現象   : 2026-06-09 13:45:00 (UTC)を境に水準が 14.96から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→12→11→12→11→12→11→13→12
* 開始   : 2026-06-09 19:00:00 (UTC)
* 終了   : 2026-06-09 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→11→9→10→11→9→12
* 開始   : 2026-06-09 20:50:00 (UTC)
* 終了   : 2026-06-09 21:40:00 (UTC)
* 現象   : 2026-06-09 21:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→7→10→9→9→11→11→8→11
* 開始   : 2026-06-10 01:25:00 (UTC)
* 終了   : 2026-06-10 02:35:00 (UTC)
* 現象   : 2026-06-10 02:35:00 (UTC)を境に水準が 15.02から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→12→11→13→12→11→13→11
* 開始   : 2026-06-10 03:05:00 (UTC)
* 終了   : 2026-06-10 03:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260610-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260610-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→15→…→14→15→11→14
* 開始   : 2026-06-10 04:25:00 (UTC)
* 終了   : 2026-06-10 04:30:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260610-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→14→…→14→10→15→11
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 06:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260610-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→19→…→18→19→18→14
* 開始   : 2026-06-10 06:30:00 (UTC)
* 終了   : 2026-06-10 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→19→14→16→…→16→20→19→20
* 開始   : 2026-06-10 07:50:00 (UTC)
* 終了   : 2026-06-10 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260610-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→21→22→19→19→21
* 開始   : 2026-06-10 08:20:00 (UTC)
* 終了   : 2026-06-10 08:45:00 (UTC)
* 現象   : 2026-06-10 08:45:00 (UTC)を境に水準が 15.09から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→15→16→14→15→16→14→15→18
* 開始   : 2026-06-10 16:35:00 (UTC)
* 終了   : 2026-06-10 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.471σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→14→13→16→13→16→13→16→13
* 開始   : 2026-06-10 18:00:00 (UTC)
* 終了   : 2026-06-10 18:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→15→17→15→17→15
* 開始   : 2026-06-11 06:05:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→18→18→19→19→19→18→19→23
* 開始   : 2026-06-11 07:30:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 2026-06-11 08:40:00 (UTC)を境に水準が 14.96から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→20→19→17→20→19
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 07:55:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→23→19→20→23→19→20
* 開始   : 2026-06-11 09:30:00 (UTC)
* 終了   : 2026-06-11 09:35:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→15→15→14→14→17→16
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 18:45:00 (UTC)
* 現象   : 2026-06-11 18:45:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→10→13→…→10→12→9→11
* 開始   : 2026-06-11 19:30:00 (UTC)
* 終了   : 2026-06-11 20:05:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→10→…→10→8→9→10
* 開始   : 2026-06-11 20:50:00 (UTC)
* 終了   : 2026-06-11 21:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.652σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→9→9→11→10→9→9
* 開始   : 2026-06-11 22:00:00 (UTC)
* 終了   : 2026-06-12 00:50:00 (UTC)
* 現象   : 2026-06-12 00:50:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.353σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→14→17→16→…→16→18→14→15
* 開始   : 2026-06-12 06:10:00 (UTC)
* 終了   : 2026-06-12 06:50:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260612-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→21→23→21→22→23→23→24→23
* 開始   : 2026-06-12 10:45:00 (UTC)
* 終了   : 2026-06-12 11:50:00 (UTC)
* 現象   : 2026-06-12 11:50:00 (UTC)を境に水準が 15から13.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.616, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 23→24→22→23→24→23→25→22→24
* 開始   : 2026-06-12 11:55:00 (UTC)
* 終了   : 2026-06-12 12:40:00 (UTC)
* 現象   : 2026-06-12 12:40:00 (UTC)を境に水準が 15から13.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→19→17→20→17→20→17→21→20
* 開始   : 2026-06-12 14:50:00 (UTC)
* 終了   : 2026-06-12 15:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8063(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.832σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→17→15→19→17→15→19→17
* 開始   : 2026-06-12 16:50:00 (UTC)
* 終了   : 2026-06-12 16:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.236σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→16→17→15
* 開始   : 2026-06-12 18:20:00 (UTC)
* 終了   : 2026-06-12 19:45:00 (UTC)
* 現象   : 2026-06-12 19:45:00 (UTC)を境に水準が 14.93から12.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.996σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→12→12→11→10→9→11→12
* 開始   : 2026-06-12 20:50:00 (UTC)
* 終了   : 2026-06-12 21:25:00 (UTC)
* 現象   : 2026-06-12 21:25:00 (UTC)を境に水準が 15.02から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→10→13→10→13→11→10
* 開始   : 2026-06-13 04:20:00 (UTC)
* 終了   : 2026-06-13 04:30:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260613-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→7→6→10→6→10→6→10→9
* 開始   : 2026-06-13 21:15:00 (UTC)
* 終了   : 2026-06-13 21:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260613-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→14→15→14→14→15→15
* 開始   : 2026-06-14 07:30:00 (UTC)
* 終了   : 2026-06-14 08:35:00 (UTC)
* 現象   : 2026-06-14 08:35:00 (UTC)を境に水準が 11.82から12.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.924, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→15→17→16→17→16→17→16
* 開始   : 2026-06-14 08:55:00 (UTC)
* 終了   : 2026-06-14 09:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.294σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→7→11→7→11→7→8→11
* 開始   : 2026-06-14 20:10:00 (UTC)
* 終了   : 2026-06-14 20:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260614-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→7→11→10→7→11→10→8
* 開始   : 2026-06-15 00:55:00 (UTC)
* 終了   : 2026-06-15 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→9→12→8→11→9→11→9→11
* 開始   : 2026-06-15 02:00:00 (UTC)
* 終了   : 2026-06-15 03:30:00 (UTC)
* 現象   : 2026-06-15 03:30:00 (UTC)を境に水準が 11.73から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.928, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→12→15→12→…→12→16→13→14
* 開始   : 2026-06-16 05:15:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→17→20→21→…→20→21→19→20
* 開始   : 2026-06-16 08:00:00 (UTC)
* 終了   : 2026-06-16 08:05:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→20→22→22
* 開始   : 2026-06-16 08:30:00 (UTC)
* 終了   : 2026-06-16 08:45:00 (UTC)
* 現象   : 2026-06-16 08:45:00 (UTC)を境に水準が 15.04から15.2へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.033, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→22→24→23→21→24→23→22→24
* 開始   : 2026-06-16 12:05:00 (UTC)
* 終了   : 2026-06-16 13:05:00 (UTC)
* 現象   : 2026-06-16 13:05:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→9→12→8→9
* 開始   : 2026-06-16 20:55:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host06-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 7→11→5→9→7→11→5→9
* 開始   : 2026-06-17 01:00:00 (UTC)
* 終了   : 2026-06-17 01:05:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→19→17→15→19→17
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 19→21→23→21→…→21→24→20→22
* 開始   : 2026-06-17 09:45:00 (UTC)
* 終了   : 2026-06-17 09:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→20→23→21→20→23→21
* 開始   : 2026-06-17 10:00:00 (UTC)
* 終了   : 2026-06-17 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→17→16→17→16→17
* 開始   : 2026-06-17 16:00:00 (UTC)
* 終了   : 2026-06-17 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→14→13→15→14→13→15
* 開始   : 2026-06-17 17:10:00 (UTC)
* 終了   : 2026-06-17 17:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→12→11→9→11→13
* 開始   : 2026-06-17 21:00:00 (UTC)
* 終了   : 2026-06-17 21:25:00 (UTC)
* 現象   : 2026-06-17 21:25:00 (UTC)を境に水準が 14.97から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→7→…→8→7→10→9
* 開始   : 2026-06-17 21:00:00 (UTC)
* 終了   : 2026-06-17 21:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.362σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→9→8→10→…→10→7→11→10
* 開始   : 2026-06-17 21:10:00 (UTC)
* 終了   : 2026-06-17 21:20:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→14→…→13→14→13→12
* 開始   : 2026-06-18 04:00:00 (UTC)
* 終了   : 2026-06-18 04:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→13→…→13→15→14→15
* 開始   : 2026-06-18 04:40:00 (UTC)
* 終了   : 2026-06-18 04:50:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→18→20→17→…→17→21→19→18
* 開始   : 2026-06-18 07:35:00 (UTC)
* 終了   : 2026-06-18 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260618-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→21→19→21→23→21→21→23→21
* 開始   : 2026-06-18 09:05:00 (UTC)
* 終了   : 2026-06-18 09:50:00 (UTC)
* 現象   : 2026-06-18 09:50:00 (UTC)を境に水準が 15.04から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→23→25→19→…→25→19→25→22
* 開始   : 2026-06-18 12:40:00 (UTC)
* 終了   : 2026-06-18 12:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→14→12→15→14→12→15→11
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→19→22→19→22→19→18
* 開始   : 2026-06-19 08:40:00 (UTC)
* 終了   : 2026-06-19 08:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.764σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→18→22→19→…→19→23→18→22
* 開始   : 2026-06-19 08:45:00 (UTC)
* 終了   : 2026-06-19 08:55:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 24→23→22→23→21→21→23→23
* 開始   : 2026-06-19 13:05:00 (UTC)
* 終了   : 2026-06-19 13:40:00 (UTC)
* 現象   : 2026-06-19 13:40:00 (UTC)を境に水準が 14.93から13.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.436, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→17→16→18→…→18→15→17→18
* 開始   : 2026-06-19 16:15:00 (UTC)
* 終了   : 2026-06-19 16:25:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→19→15→17→…→17→14→18→15
* 開始   : 2026-06-19 16:30:00 (UTC)
* 終了   : 2026-06-19 16:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260619-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→18→15→14→…→15→14→16→18
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→13→12→13→12→15→14
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.594σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260619-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→13→10→11→13→12→11→12→11
* 開始   : 2026-06-19 19:45:00 (UTC)
* 終了   : 2026-06-19 20:55:00 (UTC)
* 現象   : 2026-06-19 20:55:00 (UTC)を境に水準が 15.02から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.874, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→7→11→4→…→11→4→10→9
* 開始   : 2026-06-20 23:55:00 (UTC)
* 終了   : 2026-06-21 00:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→13→14→10→14→10→14→12→13
* 開始   : 2026-06-21 05:50:00 (UTC)
* 終了   : 2026-06-21 06:00:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260621-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→14→…→14→16→15→13
* 開始   : 2026-06-21 07:45:00 (UTC)
* 終了   : 2026-06-21 07:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260621-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→16→17
* 開始   : 2026-06-21 10:30:00 (UTC)
* 終了   : 2026-06-21 10:40:00 (UTC)
* 現象   : 2026-06-21 10:40:00 (UTC)を境に水準が 11.65から13.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→19→13→18→16→19→13→18→15
* 開始   : 2026-06-21 13:10:00 (UTC)
* 終了   : 2026-06-21 13:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→17→18→14→13→17→18→14→16
* 開始   : 2026-06-23 05:45:00 (UTC)
* 終了   : 2026-06-23 05:50:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-013 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260623-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→22→20→21→21→20→22→22→22
* 開始   : 2026-06-23 08:45:00 (UTC)
* 終了   : 2026-06-23 09:35:00 (UTC)
* 現象   : 2026-06-23 09:35:00 (UTC)を境に水準が 14.96から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→19→22→19→21
* 開始   : 2026-06-23 09:00:00 (UTC)
* 終了   : 2026-06-23 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→17→18→19→17→18→19
* 開始   : 2026-06-23 15:20:00 (UTC)
* 終了   : 2026-06-23 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→15→18→15→17
* 開始   : 2026-06-23 16:35:00 (UTC)
* 終了   : 2026-06-23 16:45:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→13→…→13→10→13→11
* 開始   : 2026-06-23 19:05:00 (UTC)
* 終了   : 2026-06-23 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260623-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→8→9→8→9→8→9→11
* 開始   : 2026-06-23 20:55:00 (UTC)
* 終了   : 2026-06-23 21:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→15→13→15→12→15
* 開始   : 2026-06-24 04:45:00 (UTC)
* 終了   : 2026-06-24 04:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→13→16→13→15
* 開始   : 2026-06-24 05:20:00 (UTC)
* 終了   : 2026-06-24 05:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.363σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 24→23→25
* 開始   : 2026-06-24 12:10:00 (UTC)
* 終了   : 2026-06-24 12:20:00 (UTC)
* 現象   : 2026-06-24 12:20:00 (UTC)を境に水準が 14.87から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→17→22→20→…→20→16→18→19
* 開始   : 2026-06-24 16:10:00 (UTC)
* 終了   : 2026-06-24 16:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260624-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→19→20→17→19
* 開始   : 2026-06-24 16:35:00 (UTC)
* 終了   : 2026-06-24 16:55:00 (UTC)
* 現象   : 2026-06-24 16:55:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.044, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→16→15→16→15→16→17
* 開始   : 2026-06-24 17:00:00 (UTC)
* 終了   : 2026-06-24 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→13→16→14→13→16→17
* 開始   : 2026-06-24 17:40:00 (UTC)
* 終了   : 2026-06-24 17:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→10→10→11→10→12
* 開始   : 2026-06-24 21:20:00 (UTC)
* 終了   : 2026-06-24 21:45:00 (UTC)
* 現象   : 2026-06-24 21:45:00 (UTC)を境に水準が 14.9から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 8→11→13→10→11→13→10
* 開始   : 2026-06-25 03:00:00 (UTC)
* 終了   : 2026-06-25 03:05:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.458倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→25→19→22→25→19→22
* 開始   : 2026-06-25 10:55:00 (UTC)
* 終了   : 2026-06-25 11:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.422σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→19→18→21→19→18→21
* 開始   : 2026-06-25 14:20:00 (UTC)
* 終了   : 2026-06-25 14:25:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→18→22→17→18→22→17→18→17
* 開始   : 2026-06-25 15:10:00 (UTC)
* 終了   : 2026-06-25 15:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→17→17→18→19→14→17→16→18
* 開始   : 2026-06-25 17:00:00 (UTC)
* 終了   : 2026-06-25 17:45:00 (UTC)
* 現象   : 2026-06-25 17:45:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→12→10→12
* 開始   : 2026-06-25 19:30:00 (UTC)
* 終了   : 2026-06-25 19:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.247σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host09-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→6→…→12→6→7→10
* 開始   : 2026-06-25 22:55:00 (UTC)
* 終了   : 2026-06-25 23:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.294σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→5→10→…→10→11→9→8
* 開始   : 2026-06-26 01:30:00 (UTC)
* 終了   : 2026-06-26 01:40:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-002 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260626-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→8→11→9→11
* 開始   : 2026-06-26 01:30:00 (UTC)
* 終了   : 2026-06-26 01:50:00 (UTC)
* 現象   : 2026-06-26 01:50:00 (UTC)を境に水準が 14.93から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.291, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→17→…→16→17→15→16
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→16→20→18→20→18
* 開始   : 2026-06-26 07:20:00 (UTC)
* 終了   : 2026-06-26 07:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→21→20→22→21→20→22
* 開始   : 2026-06-26 09:15:00 (UTC)
* 終了   : 2026-06-26 09:45:00 (UTC)
* 現象   : 2026-06-26 09:45:00 (UTC)を境に水準が 14.97から13.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.808, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→20→18→20→18→19
* 開始   : 2026-06-26 14:55:00 (UTC)
* 終了   : 2026-06-26 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→20→20→19→23
* 開始   : 2026-06-26 15:20:00 (UTC)
* 終了   : 2026-06-26 15:40:00 (UTC)
* 現象   : 2026-06-26 15:40:00 (UTC)を境に水準が 14.87から12.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→20→13→17→…→17→14→16→18
* 開始   : 2026-06-26 17:10:00 (UTC)
* 終了   : 2026-06-26 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.998σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→18→14→13→…→14→13→15→18
* 開始   : 2026-06-26 17:30:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.247σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→12→14→15→12→14→13
* 開始   : 2026-06-26 18:40:00 (UTC)
* 終了   : 2026-06-26 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→8→6→8→6→8→7
* 開始   : 2026-06-26 22:35:00 (UTC)
* 終了   : 2026-06-26 22:45:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→8→…→8→12→9→11
* 開始   : 2026-06-27 02:55:00 (UTC)
* 終了   : 2026-06-27 03:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260627-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 8→9→8→10→…→8→10→11→10
* 開始   : 2026-06-27 04:15:00 (UTC)
* 終了   : 2026-06-27 04:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.051, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260627-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260627-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→10→7→8→10→7→8→10→11
* 開始   : 2026-06-27 20:20:00 (UTC)
* 終了   : 2026-06-27 20:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.708, 限界=2.708)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260627-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→7→10→8→9→12→10→11→10
* 開始   : 2026-06-28 02:45:00 (UTC)
* 終了   : 2026-06-28 04:15:00 (UTC)
* 現象   : 2026-06-28 04:15:00 (UTC)を境に水準が 11.74から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.969, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→18→16→16→16→15→17→14→18
* 開始   : 2026-06-28 10:30:00 (UTC)
* 終了   : 2026-06-28 11:30:00 (UTC)
* 現象   : 2026-06-28 11:30:00 (UTC)を境に水準が 11.93から13.31へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→14→11→17→…→11→17→13→14
* 開始   : 2026-06-28 16:40:00 (UTC)
* 終了   : 2026-06-28 16:45:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.177σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→11→10
* 開始   : 2026-06-28 22:00:00 (UTC)
* 終了   : 2026-06-28 22:10:00 (UTC)
* 現象   : 2026-06-28 22:10:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→8→6→8→6→8→9
* 開始   : 2026-06-29 22:30:00 (UTC)
* 終了   : 2026-06-29 22:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 8→6→5→9→5→9→5→8→7
* 開始   : 2026-06-30 00:10:00 (UTC)
* 終了   : 2026-06-30 00:20:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→12→11→6→12→11→6→10
* 開始   : 2026-06-30 01:45:00 (UTC)
* 終了   : 2026-06-30 01:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-003 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→10→9→12→10→11
* 開始   : 2026-06-30 02:35:00 (UTC)
* 終了   : 2026-06-30 02:40:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.235σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→12→11→13→12→11→13→9
* 開始   : 2026-06-30 02:40:00 (UTC)
* 終了   : 2026-06-30 02:50:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→14→15→14→16→15→14→16→14
* 開始   : 2026-06-30 05:05:00 (UTC)
* 終了   : 2026-06-30 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→15→…→14→18→15→14
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 06:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→20→17→20→17→20→21
* 開始   : 2026-06-30 15:20:00 (UTC)
* 終了   : 2026-06-30 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260630-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→16→19→16→19→18
* 開始   : 2026-06-30 15:45:00 (UTC)
* 終了   : 2026-06-30 15:50:00 (UTC)
* 現象   : 火曜15時台の平常値(19.34)に対し 16であった
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.056σ 外れた (平常値=19.34)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→10→…→11→10→14→13
* 開始   : 2026-06-30 18:55:00 (UTC)
* 終了   : 2026-06-30 19:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→8→10→9→9→9
* 開始   : 2026-06-30 22:15:00 (UTC)
* 終了   : 2026-06-30 22:40:00 (UTC)
* 現象   : 2026-06-30 22:40:00 (UTC)を境に水準が 15から8.188へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.077, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host16-012 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
