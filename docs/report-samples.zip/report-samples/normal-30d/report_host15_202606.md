# host15 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host15 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 302 (SEVERE: 22, FATAL: 121, WARN: 159, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 121 | 159 | 302 | ALG-A1, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 17→14→15→13→…→15→17→15→14
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.94から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.241σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.054, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.954, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-001 active_connections の推移](charts/EVT-20260608-host15-001.svg)

# イベントID( EVT-20260608-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→13→…→14→13→12→10
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 11.68から15.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.414σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.672)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-003 active_connections の推移](charts/EVT-20260608-host15-003.svg)

# イベントID( EVT-20260608-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→17→…→16→15→14→12
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 12.02から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.573, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-004 active_connections の推移](charts/EVT-20260608-host15-004.svg)

# イベントID( EVT-20260608-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→15→…→13→14→12→14
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 21:35:00 (UTC)
* 現象   : 2026-06-08 21:35:00 (UTC)を境に水準が 11.92から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.331σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.78, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.193, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-005 active_connections の推移](charts/EVT-20260608-host15-005.svg)

# イベントID( EVT-20260608-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→14→…→12→14→12→11
* 開始   : 2026-06-08 05:15:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 12から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.737, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-007 active_connections の推移](charts/EVT-20260608-host15-007.svg)

# イベントID( EVT-20260615-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→17→15→17→…→12→14→10→12
* 開始   : 2026-06-15 01:00:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.8から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.06σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.237, 限界=2.672)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-002 active_connections の推移](charts/EVT-20260615-host15-002.svg)

# イベントID( EVT-20260615-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→16→17→15→…→13→15→12→14
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.81から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.187, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-005 active_connections の推移](charts/EVT-20260615-host15-005.svg)

# イベントID( EVT-20260615-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→16→…→15→14→13→12
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 11.79から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-006 active_connections の推移](charts/EVT-20260615-host15-006.svg)

# イベントID( EVT-20260615-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→19→18→17→…→14→15→14→15
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.81から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.025, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-007 active_connections の推移](charts/EVT-20260615-host15-007.svg)

# イベントID( EVT-20260615-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→15→…→15→13→12→15
* 開始   : 2026-06-15 03:25:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.83から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.325, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-008 active_connections の推移](charts/EVT-20260615-host15-008.svg)

# イベントID( EVT-20260622-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→15→…→14→13→14→13
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-23 01:00:00 (UTC)
* 現象   : 2026-06-23 01:00:00 (UTC)を境に水準が 11.7から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.4, 限界=2.672)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-001 active_connections の推移](charts/EVT-20260622-host15-001.svg)

# イベントID( EVT-20260622-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→18→…→15→11→10→15
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.97から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-002 active_connections の推移](charts/EVT-20260622-host15-002.svg)

# イベントID( EVT-20260622-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→15→…→11→14→13→11
* 開始   : 2026-06-22 03:15:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.705, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.744, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-003 active_connections の推移](charts/EVT-20260622-host15-003.svg)

# イベントID( EVT-20260622-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→…→13→16→13→15
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 21:05:00 (UTC)
* 現象   : 2026-06-22 21:05:00 (UTC)を境に水準が 11.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.939, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-004 active_connections の推移](charts/EVT-20260622-host15-004.svg)

# イベントID( EVT-20260622-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→18→…→12→15→10→12
* 開始   : 2026-06-22 03:40:00 (UTC)
* 終了   : 2026-06-22 21:40:00 (UTC)
* 現象   : 2026-06-22 21:40:00 (UTC)を境に水準が 11.92から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.475, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.954, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-005 active_connections の推移](charts/EVT-20260622-host15-005.svg)

# イベントID( EVT-20260622-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→13→17→13→14
* 開始   : 2026-06-22 04:40:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 11.99から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-006 active_connections の推移](charts/EVT-20260622-host15-006.svg)

# イベントID( EVT-20260629-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→15→…→12→14→12→14
* 開始   : 2026-06-29 01:20:00 (UTC)
* 終了   : 2026-06-29 19:05:00 (UTC)
* 現象   : 2026-06-29 19:05:00 (UTC)を境に水準が 11.8から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.622σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.094, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.675, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-001 active_connections の推移](charts/EVT-20260629-host15-001.svg)

# イベントID( EVT-20260629-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→14→15→16→…→15→13→14→11
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 22:35:00 (UTC)
* 現象   : 2026-06-29 22:35:00 (UTC)を境に水準が 11.75から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.874, 限界=2.672)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-002 active_connections の推移](charts/EVT-20260629-host15-002.svg)

# イベントID( EVT-20260629-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→16→18→16→…→14→13→11→12
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 11.78から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-003 active_connections の推移](charts/EVT-20260629-host15-003.svg)

# イベントID( EVT-20260629-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→15→…→12→14→13→12
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.86から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.992, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-004 active_connections の推移](charts/EVT-20260629-host15-004.svg)

# イベントID( EVT-20260629-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→17→…→14→11→15→13
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 19:50:00 (UTC)
* 現象   : 2026-06-29 19:50:00 (UTC)を境に水準が 11.77から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.934, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-005 active_connections の推移](charts/EVT-20260629-host15-005.svg)

# イベントID( EVT-20260629-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→15→…→13→14→11→13
* 開始   : 2026-06-29 04:10:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.92から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.282, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-006 active_connections の推移](charts/EVT-20260629-host15-006.svg)

# イベントID( EVT-20260601-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→9→11
* 開始   : 2026-06-01 02:15:00 (UTC)
* 終了   : 2026-06-01 02:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.473σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-001 active_connections の推移](charts/EVT-20260601-host15-001.svg)

# イベントID( EVT-20260601-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→20→15→18→18
* 開始   : 2026-06-01 15:20:00 (UTC)
* 終了   : 2026-06-01 15:20:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host15-003 active_connections の推移](charts/EVT-20260601-host15-003.svg)

# イベントID( EVT-20260601-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→20→15→19→19
* 開始   : 2026-06-01 15:55:00 (UTC)
* 終了   : 2026-06-01 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host15-004 active_connections の推移](charts/EVT-20260601-host15-004.svg)

# イベントID( EVT-20260601-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→17→18
* 開始   : 2026-06-01 17:00:00 (UTC)
* 終了   : 2026-06-01 17:00:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host15-007 active_connections の推移](charts/EVT-20260601-host15-007.svg)

# イベントID( EVT-20260602-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→9→15→12→13
* 開始   : 2026-06-02 03:35:00 (UTC)
* 終了   : 2026-06-02 03:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-001 active_connections の推移](charts/EVT-20260602-host15-001.svg)

# イベントID( EVT-20260602-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→19→15→20→19→15→20→18→16
* 開始   : 2026-06-02 07:00:00 (UTC)
* 終了   : 2026-06-02 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-004 active_connections の推移](charts/EVT-20260602-host15-004.svg)

# イベントID( EVT-20260602-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→19→16→20→19
* 開始   : 2026-06-02 15:30:00 (UTC)
* 終了   : 2026-06-02 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host15-008 active_connections の推移](charts/EVT-20260602-host15-008.svg)

# イベントID( EVT-20260602-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→13→9→12→13
* 開始   : 2026-06-02 19:30:00 (UTC)
* 終了   : 2026-06-02 19:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→11→7→9→9
* 開始   : 2026-06-02 20:55:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.062σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-015 active_connections の推移](charts/EVT-20260602-host15-015.svg)

# イベントID( EVT-20260603-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→20→20
* 開始   : 2026-06-03 08:10:00 (UTC)
* 終了   : 2026-06-03 08:10:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host15-005 active_connections の推移](charts/EVT-20260603-host15-005.svg)

# イベントID( EVT-20260603-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→22→27→21→22
* 開始   : 2026-06-03 12:20:00 (UTC)
* 終了   : 2026-06-03 12:20:00 (UTC)
* 現象   : 平常時(22)に対し 1.227倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host15-006 active_connections の推移](charts/EVT-20260603-host15-006.svg)

# イベントID( EVT-20260603-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 24→23→27→22→22
* 開始   : 2026-06-03 13:15:00 (UTC)
* 終了   : 2026-06-03 13:15:00 (UTC)
* 現象   : 平常時(22.5)に対し 1.2倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→12→12→10→12→13
* 開始   : 2026-06-03 20:40:00 (UTC)
* 終了   : 2026-06-03 22:10:00 (UTC)
* 現象   : 2026-06-03 22:10:00 (UTC)を境に水準が 14.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.297σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→12→15→13→13
* 開始   : 2026-06-04 04:15:00 (UTC)
* 終了   : 2026-06-04 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host15-003 active_connections の推移](charts/EVT-20260604-host15-003.svg)

# イベントID( EVT-20260604-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→15→14
* 開始   : 2026-06-04 04:55:00 (UTC)
* 終了   : 2026-06-04 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host15-004 active_connections の推移](charts/EVT-20260604-host15-004.svg)

# イベントID( EVT-20260604-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→17→20→17→15
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 06:45:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-005 active_connections の推移](charts/EVT-20260604-host15-005.svg)

# イベントID( EVT-20260604-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→17→18→15→…→15→20→17→18
* 開始   : 2026-06-04 06:50:00 (UTC)
* 終了   : 2026-06-04 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.178σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host15-006 active_connections の推移](charts/EVT-20260604-host15-006.svg)

# イベントID( EVT-20260604-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→24→21→18→24→21→18→20→19
* 開始   : 2026-06-04 14:45:00 (UTC)
* 終了   : 2026-06-04 15:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260604-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host15-009 active_connections の推移](charts/EVT-20260604-host15-009.svg)

# イベントID( EVT-20260604-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→10→6→9→8
* 開始   : 2026-06-04 21:05:00 (UTC)
* 終了   : 2026-06-04 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-011 active_connections の推移](charts/EVT-20260604-host15-011.svg)

# イベントID( EVT-20260605-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→16→15→12→16→15
* 開始   : 2026-06-05 05:00:00 (UTC)
* 終了   : 2026-06-05 05:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host15-002 active_connections の推移](charts/EVT-20260605-host15-002.svg)

# イベントID( EVT-20260605-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→21→20→23→21→20→23→19→20
* 開始   : 2026-06-05 08:35:00 (UTC)
* 終了   : 2026-06-05 08:45:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260605-host15-004 active_connections の推移](charts/EVT-20260605-host15-004.svg)

# イベントID( EVT-20260605-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→18→16
* 開始   : 2026-06-05 16:50:00 (UTC)
* 終了   : 2026-06-05 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host15-006 active_connections の推移](charts/EVT-20260605-host15-006.svg)

# イベントID( EVT-20260605-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→19→17→18→17→17→20
* 開始   : 2026-06-05 16:55:00 (UTC)
* 終了   : 2026-06-05 18:15:00 (UTC)
* 現象   : 2026-06-05 18:15:00 (UTC)を境に水準が 14.93から12.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-007 active_connections の推移](charts/EVT-20260605-host15-007.svg)

# イベントID( EVT-20260605-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→15→12→15→14
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.062σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host15-008 active_connections の推移](charts/EVT-20260605-host15-008.svg)

# イベントID( EVT-20260605-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→8→6→9→10
* 開始   : 2026-06-05 22:00:00 (UTC)
* 終了   : 2026-06-05 22:00:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→10→5→7→8
* 開始   : 2026-06-05 22:30:00 (UTC)
* 終了   : 2026-06-05 22:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host15-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→9→13→14→…→13→14→13→14
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.325, 限界=2.672)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host15-001 active_connections の推移](charts/EVT-20260606-host15-001.svg)

# イベントID( EVT-20260606-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→14→11→12→…→11→12→14→13
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.794, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host15-002 active_connections の推移](charts/EVT-20260606-host15-002.svg)

# イベントID( EVT-20260606-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→11→…→9→13→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.703, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host15-003 active_connections の推移](charts/EVT-20260606-host15-003.svg)

# イベントID( EVT-20260606-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→10→13→10→…→11→13→11→12
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.214, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260606-host15-004 active_connections の推移](charts/EVT-20260606-host15-004.svg)

# イベントID( EVT-20260606-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→12→…→13→10→9→13
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.893, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host15-005 active_connections の推移](charts/EVT-20260606-host15-005.svg)

# イベントID( EVT-20260606-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→12→…→12→13→11→12
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.285, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260606-host15-006 active_connections の推移](charts/EVT-20260606-host15-006.svg)

# イベントID( EVT-20260607-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→9→8
* 開始   : 2026-06-07 02:15:00 (UTC)
* 終了   : 2026-06-07 02:15:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host15-001 active_connections の推移](charts/EVT-20260607-host15-001.svg)

# イベントID( EVT-20260607-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→14→17→12→12
* 開始   : 2026-06-07 06:55:00 (UTC)
* 終了   : 2026-06-07 06:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host15-002 active_connections の推移](charts/EVT-20260607-host15-002.svg)

# イベントID( EVT-20260607-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→13→13
* 開始   : 2026-06-07 07:00:00 (UTC)
* 終了   : 2026-06-07 07:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host15-003 active_connections の推移](charts/EVT-20260607-host15-003.svg)

# イベントID( EVT-20260607-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→14→19→16→17
* 開始   : 2026-06-07 12:20:00 (UTC)
* 終了   : 2026-06-07 12:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host15-004 active_connections の推移](charts/EVT-20260607-host15-004.svg)

# イベントID( EVT-20260607-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→10→17→11→10→17→11→14
* 開始   : 2026-06-07 15:00:00 (UTC)
* 終了   : 2026-06-07 15:10:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.311σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host15-005 active_connections の推移](charts/EVT-20260607-host15-005.svg)

# イベントID( EVT-20260608-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→15→…→13→15→14→13
* 開始   : 2026-06-08 04:05:00 (UTC)
* 終了   : 2026-06-08 19:40:00 (UTC)
* 現象   : 2026-06-08 19:40:00 (UTC)を境に水準が 11.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-006 active_connections の推移](charts/EVT-20260608-host15-006.svg)

# イベントID( EVT-20260609-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→18→14→16→16
* 開始   : 2026-06-09 16:30:00 (UTC)
* 終了   : 2026-06-09 16:30:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host15-007 active_connections の推移](charts/EVT-20260609-host15-007.svg)

# イベントID( EVT-20260609-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→13→14
* 開始   : 2026-06-09 19:00:00 (UTC)
* 終了   : 2026-06-09 19:00:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host15-008 active_connections の推移](charts/EVT-20260609-host15-008.svg)

# イベントID( EVT-20260609-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→10→7→11→9
* 開始   : 2026-06-09 20:25:00 (UTC)
* 終了   : 2026-06-09 20:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host15-009 active_connections の推移](charts/EVT-20260609-host15-009.svg)

# イベントID( EVT-20260610-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→15→13→16→15→13
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host15-002 active_connections の推移](charts/EVT-20260610-host15-002.svg)

# イベントID( EVT-20260610-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→13→17→13→15
* 開始   : 2026-06-10 05:15:00 (UTC)
* 終了   : 2026-06-10 05:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.724σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host15-003 active_connections の推移](charts/EVT-20260610-host15-003.svg)

# イベントID( EVT-20260610-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→23→19→22→…→23→19→21→22
* 開始   : 2026-06-10 12:40:00 (UTC)
* 終了   : 2026-06-10 14:00:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.414σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host15-008 active_connections の推移](charts/EVT-20260610-host15-008.svg)

# イベントID( EVT-20260610-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→18→16→18→…→23→15→17→20
* 開始   : 2026-06-10 16:05:00 (UTC)
* 終了   : 2026-06-10 17:05:00 (UTC)
* 現象   : 1.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.414σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host15-010 active_connections の推移](charts/EVT-20260610-host15-010.svg)

# イベントID( EVT-20260610-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→18→14→18→18
* 開始   : 2026-06-10 16:35:00 (UTC)
* 終了   : 2026-06-10 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.194σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-011 active_connections の推移](charts/EVT-20260610-host15-011.svg)

# イベントID( EVT-20260610-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→15→10→15→14
* 開始   : 2026-06-10 18:05:00 (UTC)
* 終了   : 2026-06-10 18:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.625(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-012 active_connections の推移](charts/EVT-20260610-host15-012.svg)

# イベントID( EVT-20260610-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→14→12→10→14→12
* 開始   : 2026-06-10 19:45:00 (UTC)
* 終了   : 2026-06-10 20:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host01-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260610-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host15-013 active_connections の推移](charts/EVT-20260610-host15-013.svg)

# イベントID( EVT-20260610-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 8→10→5→6→…→5→6→9→7
* 開始   : 2026-06-10 22:25:00 (UTC)
* 終了   : 2026-06-10 22:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-015 active_connections の推移](charts/EVT-20260610-host15-015.svg)

# イベントID( EVT-20260611-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→18→16→13
* 開始   : 2026-06-11 06:00:00 (UTC)
* 終了   : 2026-06-11 06:00:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.484σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host15-003 active_connections の推移](charts/EVT-20260611-host15-003.svg)

# イベントID( EVT-20260611-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→21→15→19→20
* 開始   : 2026-06-11 15:00:00 (UTC)
* 終了   : 2026-06-11 15:00:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7171(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-009 active_connections の推移](charts/EVT-20260611-host15-009.svg)

# イベントID( EVT-20260611-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→18→15→17→19
* 開始   : 2026-06-11 15:50:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-010 active_connections の推移](charts/EVT-20260611-host15-010.svg)

# イベントID( EVT-20260611-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→14→17→14→17→18
* 開始   : 2026-06-11 17:20:00 (UTC)
* 終了   : 2026-06-11 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host15-012 active_connections の推移](charts/EVT-20260611-host15-012.svg)

# イベントID( EVT-20260611-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→16→12→17→16
* 開始   : 2026-06-11 17:25:00 (UTC)
* 終了   : 2026-06-11 17:25:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-013 active_connections の推移](charts/EVT-20260611-host15-013.svg)

# イベントID( EVT-20260611-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→11→6→8→8
* 開始   : 2026-06-11 21:50:00 (UTC)
* 終了   : 2026-06-11 21:50:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260611-host15-016 active_connections の推移](charts/EVT-20260611-host15-016.svg)

# イベントID( EVT-20260611-host15-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 7→8→4→11→…→4→11→7→8
* 開始   : 2026-06-11 23:45:00 (UTC)
* 終了   : 2026-06-12 00:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.4948倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.846σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-018 active_connections の推移](charts/EVT-20260611-host15-018.svg)

# イベントID( EVT-20260612-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→21→22
* 開始   : 2026-06-12 10:00:00 (UTC)
* 終了   : 2026-06-12 10:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host15-006 active_connections の推移](charts/EVT-20260612-host15-006.svg)

# イベントID( EVT-20260612-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→22→22
* 開始   : 2026-06-12 10:05:00 (UTC)
* 終了   : 2026-06-12 10:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 23→24→18→23→23
* 開始   : 2026-06-12 13:15:00 (UTC)
* 終了   : 2026-06-12 13:15:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host15-008 active_connections の推移](charts/EVT-20260612-host15-008.svg)

# イベントID( EVT-20260612-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→8→9
* 開始   : 2026-06-12 22:35:00 (UTC)
* 終了   : 2026-06-12 23:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260612-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host15-011 active_connections の推移](charts/EVT-20260612-host15-011.svg)

# イベントID( EVT-20260613-host15-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→11→…→10→11→10→11
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.737, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host15-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.5 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260613-host15-002 active_connections の推移](charts/EVT-20260613-host15-002.svg)

# イベントID( EVT-20260613-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→13→11→14→10
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.107, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host15-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host15-003 active_connections の推移](charts/EVT-20260613-host15-003.svg)

# イベントID( EVT-20260613-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→14→…→11→12→13→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host15-004 active_connections の推移](charts/EVT-20260613-host15-004.svg)

# イベントID( EVT-20260613-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→13→9→12→10
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host15-005 active_connections の推移](charts/EVT-20260613-host15-005.svg)

# イベントID( EVT-20260613-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→14→12→11→13
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.716, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host15-006 active_connections の推移](charts/EVT-20260613-host15-006.svg)

# イベントID( EVT-20260613-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→14→…→13→12→13→15
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.107, 限界=2.672)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260613-host15-007 active_connections の推移](charts/EVT-20260613-host15-007.svg)

# イベントID( EVT-20260613-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→9→5→7→9
* 開始   : 2026-06-13 22:10:00 (UTC)
* 終了   : 2026-06-13 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→13→14
* 開始   : 2026-06-14 08:00:00 (UTC)
* 終了   : 2026-06-14 08:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host15-003 active_connections の推移](charts/EVT-20260614-host15-003.svg)

# イベントID( EVT-20260614-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→16→20→16→17
* 開始   : 2026-06-14 13:20:00 (UTC)
* 終了   : 2026-06-14 13:20:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.252σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host15-005 active_connections の推移](charts/EVT-20260614-host15-005.svg)

# イベントID( EVT-20260614-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→17→10→14→13
* 開始   : 2026-06-14 13:55:00 (UTC)
* 終了   : 2026-06-14 13:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.6486(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.782σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host15-007 active_connections の推移](charts/EVT-20260614-host15-007.svg)

# イベントID( EVT-20260614-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→15→10→14→13
* 開始   : 2026-06-14 15:50:00 (UTC)
* 終了   : 2026-06-14 15:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host15-009 active_connections の推移](charts/EVT-20260614-host15-009.svg)

# イベントID( EVT-20260614-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→15→12→11→12→14→9→11→10
* 開始   : 2026-06-14 19:00:00 (UTC)
* 終了   : 2026-06-14 19:55:00 (UTC)
* 現象   : 2026-06-14 19:55:00 (UTC)を境に水準が 11.71から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→8→4→6→7
* 開始   : 2026-06-15 00:05:00 (UTC)
* 終了   : 2026-06-15 00:05:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→15→…→14→15→13→11
* 開始   : 2026-06-15 02:15:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.81から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.775, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.617, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-004 active_connections の推移](charts/EVT-20260615-host15-004.svg)

# イベントID( EVT-20260616-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→18→23→19→19
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-003 active_connections の推移](charts/EVT-20260616-host15-003.svg)

# イベントID( EVT-20260618-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→11→14→11→…→11→13→8→10
* 開始   : 2026-06-18 03:10:00 (UTC)
* 終了   : 2026-06-18 03:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.631倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.782σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-002 active_connections の推移](charts/EVT-20260618-host15-002.svg)

# イベントID( EVT-20260618-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→12→13
* 開始   : 2026-06-18 05:00:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260618-host15-004 active_connections の推移](charts/EVT-20260618-host15-004.svg)

# イベントID( EVT-20260618-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→20→18→20→17→16
* 開始   : 2026-06-18 06:55:00 (UTC)
* 終了   : 2026-06-18 07:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host15-007 active_connections の推移](charts/EVT-20260618-host15-007.svg)

# イベントID( EVT-20260618-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→19→25→22→24→25→22→24→22
* 開始   : 2026-06-18 10:35:00 (UTC)
* 終了   : 2026-06-18 10:45:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260618-host15-010 active_connections の推移](charts/EVT-20260618-host15-010.svg)

# イベントID( EVT-20260618-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→21→18→21→20
* 開始   : 2026-06-18 14:05:00 (UTC)
* 終了   : 2026-06-18 14:05:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.809(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.003σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host15-012 active_connections の推移](charts/EVT-20260618-host15-012.svg)

# イベントID( EVT-20260619-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→9→14→13→9→14→13
* 開始   : 2026-06-19 03:50:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-003 active_connections の推移](charts/EVT-20260619-host15-003.svg)

# イベントID( EVT-20260619-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→13→13
* 開始   : 2026-06-19 04:50:00 (UTC)
* 終了   : 2026-06-19 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host15-005 active_connections の推移](charts/EVT-20260619-host15-005.svg)

# イベントID( EVT-20260619-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→11→7→10→10
* 開始   : 2026-06-19 20:40:00 (UTC)
* 終了   : 2026-06-19 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-012 active_connections の推移](charts/EVT-20260619-host15-012.svg)

# イベントID( EVT-20260620-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→9→…→10→13→10→11
* 開始   : 2026-06-20 04:20:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260620-host15-002 active_connections の推移](charts/EVT-20260620-host15-002.svg)

# イベントID( EVT-20260620-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→13→…→14→11→12→11
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.863, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host15-003 active_connections の推移](charts/EVT-20260620-host15-003.svg)

# イベントID( EVT-20260620-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→12→…→12→10→11→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.888, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host15-004 active_connections の推移](charts/EVT-20260620-host15-004.svg)

# イベントID( EVT-20260620-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→10→11→13→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.011σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.805, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host15-005 active_connections の推移](charts/EVT-20260620-host15-005.svg)

# イベントID( EVT-20260620-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→11→…→14→13→14→13
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.244, 限界=2.672)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host15-006 active_connections の推移](charts/EVT-20260620-host15-006.svg)

# イベントID( EVT-20260620-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→11→…→9→10→12→10
* 開始   : 2026-06-20 06:25:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260620-host15-007 active_connections の推移](charts/EVT-20260620-host15-007.svg)

# イベントID( EVT-20260621-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→19→…→20→19→14→16
* 開始   : 2026-06-21 11:30:00 (UTC)
* 終了   : 2026-06-21 11:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host15-004 active_connections の推移](charts/EVT-20260621-host15-004.svg)

# イベントID( EVT-20260621-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→14→10→13→15
* 開始   : 2026-06-21 16:05:00 (UTC)
* 終了   : 2026-06-21 16:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host15-005 active_connections の推移](charts/EVT-20260621-host15-005.svg)

# イベントID( EVT-20260621-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→8→10→7→8→10→8
* 開始   : 2026-06-21 19:20:00 (UTC)
* 終了   : 2026-06-21 19:25:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260621-host15-006 active_connections の推移](charts/EVT-20260621-host15-006.svg)

# イベントID( EVT-20260623-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→17→18→22→18→18→21→19→21
* 開始   : 2026-06-23 07:10:00 (UTC)
* 終了   : 2026-06-23 07:50:00 (UTC)
* 現象   : 2026-06-23 07:50:00 (UTC)を境に水準が 15.02から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.121σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host15-002 active_connections の推移](charts/EVT-20260623-host15-002.svg)

# イベントID( EVT-20260623-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→22→16→22→21
* 開始   : 2026-06-23 14:55:00 (UTC)
* 終了   : 2026-06-23 14:55:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host15-004 active_connections の推移](charts/EVT-20260623-host15-004.svg)

# イベントID( EVT-20260623-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→15→14→16→14→16→14→17→14
* 開始   : 2026-06-23 17:35:00 (UTC)
* 終了   : 2026-06-23 18:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分

![EVT-20260623-host15-006 active_connections の推移](charts/EVT-20260623-host15-006.svg)

# イベントID( EVT-20260623-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→11→16→13
* 開始   : 2026-06-23 17:45:00 (UTC)
* 終了   : 2026-06-23 17:45:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-007 active_connections の推移](charts/EVT-20260623-host15-007.svg)

# イベントID( EVT-20260623-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→14→17→14→12→14→15
* 開始   : 2026-06-23 17:45:00 (UTC)
* 終了   : 2026-06-23 17:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host15-008 active_connections の推移](charts/EVT-20260623-host15-008.svg)

# イベントID( EVT-20260623-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→11→14→14
* 開始   : 2026-06-23 18:25:00 (UTC)
* 終了   : 2026-06-23 18:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-009 active_connections の推移](charts/EVT-20260623-host15-009.svg)

# イベントID( EVT-20260623-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→13→8→12→11
* 開始   : 2026-06-23 19:35:00 (UTC)
* 終了   : 2026-06-23 19:35:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host15-010 active_connections の推移](charts/EVT-20260623-host15-010.svg)

# イベントID( EVT-20260624-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 7→10→13→9→8
* 開始   : 2026-06-24 02:30:00 (UTC)
* 終了   : 2026-06-24 02:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-001 active_connections の推移](charts/EVT-20260624-host15-001.svg)

# イベントID( EVT-20260624-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→19→18→23→20
* 開始   : 2026-06-24 08:20:00 (UTC)
* 終了   : 2026-06-24 08:40:00 (UTC)
* 現象   : 2026-06-24 08:40:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.297σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-005 active_connections の推移](charts/EVT-20260624-host15-005.svg)

# イベントID( EVT-20260624-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→18→23→20→18
* 開始   : 2026-06-24 08:45:00 (UTC)
* 終了   : 2026-06-24 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host15-006 active_connections の推移](charts/EVT-20260624-host15-006.svg)

# イベントID( EVT-20260625-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→16→13→15→16→13→15→12→14
* 開始   : 2026-06-25 05:00:00 (UTC)
* 終了   : 2026-06-25 05:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260625-host15-003 active_connections の推移](charts/EVT-20260625-host15-003.svg)

# イベントID( EVT-20260625-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→15→12→15→15→17
* 開始   : 2026-06-25 05:00:00 (UTC)
* 終了   : 2026-06-25 05:25:00 (UTC)
* 現象   : 2026-06-25 05:25:00 (UTC)を境に水準が 14.91から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→19→21→19→20
* 開始   : 2026-06-25 08:20:00 (UTC)
* 終了   : 2026-06-25 08:50:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260625-host15-005 active_connections の推移](charts/EVT-20260625-host15-005.svg)

# イベントID( EVT-20260625-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→13→14→11→13→11→12→11→14
* 開始   : 2026-06-25 18:50:00 (UTC)
* 終了   : 2026-06-25 21:35:00 (UTC)
* 現象   : 2026-06-25 21:35:00 (UTC)を境に水準が 14.95から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-007 active_connections の推移](charts/EVT-20260625-host15-007.svg)

# イベントID( EVT-20260625-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→9→11→11
* 開始   : 2026-06-25 19:25:00 (UTC)
* 終了   : 2026-06-25 19:25:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.6506(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host15-008 active_connections の推移](charts/EVT-20260625-host15-008.svg)

# イベントID( EVT-20260626-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→21→24→20→18
* 開始   : 2026-06-26 09:05:00 (UTC)
* 終了   : 2026-06-26 09:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host15-005 active_connections の推移](charts/EVT-20260626-host15-005.svg)

# イベントID( EVT-20260626-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→12→13→14
* 開始   : 2026-06-26 19:00:00 (UTC)
* 終了   : 2026-06-26 19:50:00 (UTC)
* 現象   : 2026-06-26 19:50:00 (UTC)を境に水準が 15.02から11.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.709σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host15-007 active_connections の推移](charts/EVT-20260626-host15-007.svg)

# イベントID( EVT-20260627-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→11→…→13→11→13→11
* 開始   : 2026-06-27 04:35:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.849, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 13.9 時間

![EVT-20260627-host15-002 active_connections の推移](charts/EVT-20260627-host15-002.svg)

# イベントID( EVT-20260627-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→13→…→10→13→10→13
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.194, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host15-003 active_connections の推移](charts/EVT-20260627-host15-003.svg)

# イベントID( EVT-20260627-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→8→10→11→…→13→11→12→13
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.284, 限界=2.672)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host15-004 active_connections の推移](charts/EVT-20260627-host15-004.svg)

# イベントID( EVT-20260627-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→9→…→11→12→15→13
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.804σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.689, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host15-005 active_connections の推移](charts/EVT-20260627-host15-005.svg)

# イベントID( EVT-20260627-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→15→10→11→…→10→11→10→11
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host15-006 active_connections の推移](charts/EVT-20260627-host15-006.svg)

# イベントID( EVT-20260627-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→14→…→13→10→13→11
* 開始   : 2026-06-27 06:20:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.241σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.697, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.2 時間

![EVT-20260627-host15-007 active_connections の推移](charts/EVT-20260627-host15-007.svg)

# イベントID( EVT-20260628-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→8→5→9→9
* 開始   : 2026-06-28 21:40:00 (UTC)
* 終了   : 2026-06-28 21:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host15-007 active_connections の推移](charts/EVT-20260628-host15-007.svg)

# イベントID( EVT-20260630-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→14→18→16→16
* 開始   : 2026-06-30 06:00:00 (UTC)
* 終了   : 2026-06-30 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-004 active_connections の推移](charts/EVT-20260630-host15-004.svg)

# イベントID( EVT-20260630-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→20→24→20→21
* 開始   : 2026-06-30 09:05:00 (UTC)
* 終了   : 2026-06-30 09:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-007 active_connections の推移](charts/EVT-20260630-host15-007.svg)

# イベントID( EVT-20260630-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→18→16
* 開始   : 2026-06-30 17:25:00 (UTC)
* 終了   : 2026-06-30 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host15-009 active_connections の推移](charts/EVT-20260630-host15-009.svg)

# イベントID( EVT-20260630-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→15
* 開始   : 2026-06-30 18:30:00 (UTC)
* 終了   : 2026-06-30 19:05:00 (UTC)
* 現象   : 2026-06-30 19:05:00 (UTC)を境に水準が 14.95から10.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.239σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host15-010 active_connections の推移](charts/EVT-20260630-host15-010.svg)

# イベントID( EVT-20260630-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→15→10→12→14
* 開始   : 2026-06-30 19:05:00 (UTC)
* 終了   : 2026-06-30 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host15-012 active_connections の推移](charts/EVT-20260630-host15-012.svg)

# イベントID( EVT-20260601-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→21→22→20→19→21→22→20→21
* 開始   : 2026-06-01 08:35:00 (UTC)
* 終了   : 2026-06-01 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.126σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→18→19→16→18
* 開始   : 2026-06-01 16:20:00 (UTC)
* 終了   : 2026-06-01 16:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→17→19→15→17→19
* 開始   : 2026-06-01 17:00:00 (UTC)
* 終了   : 2026-06-01 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→13→…→13→11→12→14
* 開始   : 2026-06-01 19:10:00 (UTC)
* 終了   : 2026-06-01 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.63σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260601-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260601-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→13→15→16→13→15→16→13→14
* 開始   : 2026-06-02 05:00:00 (UTC)
* 終了   : 2026-06-02 05:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→15→17→17→15→18→19
* 開始   : 2026-06-02 05:45:00 (UTC)
* 終了   : 2026-06-02 07:05:00 (UTC)
* 現象   : 2026-06-02 07:05:00 (UTC)を境に水準が 15.06から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→22→17→22→17
* 開始   : 2026-06-02 08:25:00 (UTC)
* 終了   : 2026-06-02 08:30:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.234倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.903σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→22→23→22→23→22
* 開始   : 2026-06-02 09:35:00 (UTC)
* 終了   : 2026-06-02 09:40:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 24→21→24→21→22→20→23
* 開始   : 2026-06-02 13:40:00 (UTC)
* 終了   : 2026-06-02 14:10:00 (UTC)
* 現象   : 2026-06-02 14:10:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→20→19→16→20→19
* 開始   : 2026-06-02 16:05:00 (UTC)
* 終了   : 2026-06-02 16:10:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.184σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→15→14→15→18→15→14→15→16
* 開始   : 2026-06-02 16:55:00 (UTC)
* 終了   : 2026-06-02 17:00:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→15→14→15→14→18→17
* 開始   : 2026-06-02 17:20:00 (UTC)
* 終了   : 2026-06-02 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260602-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→10→8→9→10→8→10
* 開始   : 2026-06-02 20:45:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→8→11→8→11→8→11→9
* 開始   : 2026-06-02 20:45:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→10→10→8→9→9→8→9→10
* 開始   : 2026-06-03 01:00:00 (UTC)
* 終了   : 2026-06-03 01:45:00 (UTC)
* 現象   : 2026-06-03 01:45:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.247, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→12→…→12→14→10→11
* 開始   : 2026-06-03 03:15:00 (UTC)
* 終了   : 2026-06-03 03:25:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→14→12→11→14→12→13
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.413σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→15→19→18→15→19→18
* 開始   : 2026-06-03 07:20:00 (UTC)
* 終了   : 2026-06-03 07:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→18→17→19→16→17→19→16→17
* 開始   : 2026-06-03 16:15:00 (UTC)
* 終了   : 2026-06-03 16:25:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→8→11→8→11→8→10
* 開始   : 2026-06-04 01:05:00 (UTC)
* 終了   : 2026-06-04 01:10:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→10→7→12→10→9
* 開始   : 2026-06-04 02:30:00 (UTC)
* 終了   : 2026-06-04 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.413σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→19→23→24→…→24→20→24→21
* 開始   : 2026-06-04 09:35:00 (UTC)
* 終了   : 2026-06-04 09:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→20→24→18→…→24→18→21→22
* 開始   : 2026-06-04 10:55:00 (UTC)
* 終了   : 2026-06-04 11:00:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→15→13→13→11→13→13→12→13
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 20:00:00 (UTC)
* 現象   : 2026-06-04 20:00:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.591, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→11→10→9→9→8→9
* 開始   : 2026-06-04 21:25:00 (UTC)
* 終了   : 2026-06-04 22:15:00 (UTC)
* 現象   : 2026-06-04 22:15:00 (UTC)を境に水準が 14.95から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→9→6→5→8→9→6→5→8
* 開始   : 2026-06-04 23:25:00 (UTC)
* 終了   : 2026-06-04 23:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→8→8→9→10→9→10→9→10
* 開始   : 2026-06-05 00:55:00 (UTC)
* 終了   : 2026-06-05 01:45:00 (UTC)
* 現象   : 2026-06-05 01:45:00 (UTC)を境に水準が 14.81から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→18→19→17→16→18→19→17
* 開始   : 2026-06-05 06:50:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→20→20→17→18→17→16→16→15
* 開始   : 2026-06-05 16:00:00 (UTC)
* 終了   : 2026-06-05 17:35:00 (UTC)
* 現象   : 2026-06-05 17:35:00 (UTC)を境に水準が 14.98から12.26へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.361, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→12→9→12→9→12
* 開始   : 2026-06-05 19:55:00 (UTC)
* 終了   : 2026-06-05 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→12→8→12→8→11
* 開始   : 2026-06-05 20:35:00 (UTC)
* 終了   : 2026-06-05 20:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260605-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→9→9→9→10
* 開始   : 2026-06-05 23:25:00 (UTC)
* 終了   : 2026-06-05 23:55:00 (UTC)
* 現象   : 2026-06-05 23:55:00 (UTC)を境に水準が 14.98から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→8→9→8
* 開始   : 2026-06-06 20:40:00 (UTC)
* 終了   : 2026-06-06 20:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.699, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260606-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→9→10→9→11→11→11
* 開始   : 2026-06-07 21:00:00 (UTC)
* 終了   : 2026-06-07 21:30:00 (UTC)
* 現象   : 2026-06-07 21:30:00 (UTC)を境に水準が 11.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.959, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→10→11→11→11→9→11→10→13
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 04:00:00 (UTC)
* 現象   : 2026-06-08 04:00:00 (UTC)を境に水準が 11.89から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.707, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→9→13→11→13→11→13→11→10
* 開始   : 2026-06-09 03:10:00 (UTC)
* 終了   : 2026-06-09 03:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→18→17→15→18→17→15
* 開始   : 2026-06-09 06:05:00 (UTC)
* 終了   : 2026-06-09 06:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.309倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.975σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→14→17→14→17→16
* 開始   : 2026-06-09 06:20:00 (UTC)
* 終了   : 2026-06-09 06:30:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→22→22→22→21→22→21→24
* 開始   : 2026-06-09 10:05:00 (UTC)
* 終了   : 2026-06-09 10:40:00 (UTC)
* 現象   : 2026-06-09 10:40:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.744, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 23→21→18→21→18→21→18→22→19
* 開始   : 2026-06-09 14:30:00 (UTC)
* 終了   : 2026-06-09 14:40:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.8276(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→19→17→20→16→17→20→16→19
* 開始   : 2026-06-09 15:20:00 (UTC)
* 終了   : 2026-06-09 15:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→7→9→10→7→9→8
* 開始   : 2026-06-09 21:40:00 (UTC)
* 終了   : 2026-06-09 21:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→9→7→6→…→7→6→9→8
* 開始   : 2026-06-09 22:20:00 (UTC)
* 終了   : 2026-06-09 22:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260609-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→9→8→10→9→9→9
* 開始   : 2026-06-10 00:05:00 (UTC)
* 終了   : 2026-06-10 02:15:00 (UTC)
* 現象   : 2026-06-10 02:15:00 (UTC)を境に水準が 14.93から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.887, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→17→14→13→17→14→16
* 開始   : 2026-06-10 05:40:00 (UTC)
* 終了   : 2026-06-10 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.767σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→18→…→18→20→18→17
* 開始   : 2026-06-10 07:15:00 (UTC)
* 終了   : 2026-06-10 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→22→21→23→23→20→23→22→23
* 開始   : 2026-06-10 10:00:00 (UTC)
* 終了   : 2026-06-10 10:40:00 (UTC)
* 現象   : 2026-06-10 10:40:00 (UTC)を境に水準が 14.85から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→23→22→22→24→22→23
* 開始   : 2026-06-10 11:30:00 (UTC)
* 終了   : 2026-06-10 12:30:00 (UTC)
* 現象   : 2026-06-10 12:30:00 (UTC)を境に水準が 15.06から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→17→18→19→17→18
* 開始   : 2026-06-10 15:40:00 (UTC)
* 終了   : 2026-06-10 15:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→13→9→10→13→9→12
* 開始   : 2026-06-10 19:50:00 (UTC)
* 終了   : 2026-06-10 20:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7792(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260610-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→11→9→9→9→11→10
* 開始   : 2026-06-11 01:45:00 (UTC)
* 終了   : 2026-06-11 02:15:00 (UTC)
* 現象   : 2026-06-11 02:15:00 (UTC)を境に水準が 14.88から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→11→14→11→14→11→14→11
* 開始   : 2026-06-11 04:10:00 (UTC)
* 終了   : 2026-06-11 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→18→16→18
* 開始   : 2026-06-11 06:40:00 (UTC)
* 終了   : 2026-06-11 06:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.356σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→18→17→20→18→19
* 開始   : 2026-06-11 07:45:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→20→21→22→22→22→21→23
* 開始   : 2026-06-11 09:50:00 (UTC)
* 終了   : 2026-06-11 10:25:00 (UTC)
* 現象   : 2026-06-11 10:25:00 (UTC)を境に水準が 14.95から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→23→24→21→22→22→20→21→21
* 開始   : 2026-06-11 13:05:00 (UTC)
* 終了   : 2026-06-11 15:15:00 (UTC)
* 現象   : 2026-06-11 15:15:00 (UTC)を境に水準が 14.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.669, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 19→20→24→18→21→20→24→18→21
* 開始   : 2026-06-11 14:00:00 (UTC)
* 終了   : 2026-06-11 14:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→19→17→15→18
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:25:00 (UTC)
* 現象   : 2026-06-11 17:25:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→6→9→12→6→9→12→9→10
* 開始   : 2026-06-11 20:35:00 (UTC)
* 終了   : 2026-06-11 21:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260611-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→8→7→8→7→10
* 開始   : 2026-06-11 21:20:00 (UTC)
* 終了   : 2026-06-11 21:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260611-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→8→6→5→…→6→5→7→8
* 開始   : 2026-06-11 22:15:00 (UTC)
* 終了   : 2026-06-11 22:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host02-015 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260611-host15-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→8→12→6→…→12→6→9→8
* 開始   : 2026-06-12 02:15:00 (UTC)
* 終了   : 2026-06-12 02:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260612-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→10→13→10
* 開始   : 2026-06-12 03:25:00 (UTC)
* 終了   : 2026-06-12 03:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→12→16→9→…→16→9→13→12
* 開始   : 2026-06-12 04:40:00 (UTC)
* 終了   : 2026-06-12 04:45:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→16→…→16→18→17→16
* 開始   : 2026-06-12 06:05:00 (UTC)
* 終了   : 2026-06-12 06:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→16→18→16→18→17
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→20→17→18→…→18→16→18→19
* 開始   : 2026-06-12 15:55:00 (UTC)
* 終了   : 2026-06-12 16:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→11→…→12→11→15→16
* 開始   : 2026-06-12 18:35:00 (UTC)
* 終了   : 2026-06-12 18:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host15-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→11→10→11→…→11→12→13→10
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 05:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.043, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260613-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→11→13→7→8→11→13→7→8
* 開始   : 2026-06-13 21:05:00 (UTC)
* 終了   : 2026-06-13 21:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260613-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→10→13→10→12
* 開始   : 2026-06-14 05:15:00 (UTC)
* 終了   : 2026-06-14 05:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→13→13→13→15→15
* 開始   : 2026-06-14 07:05:00 (UTC)
* 終了   : 2026-06-14 07:30:00 (UTC)
* 現象   : 2026-06-14 07:30:00 (UTC)を境に水準が 11.8から12.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.348, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→15→17→16→18→17→16→18→15
* 開始   : 2026-06-14 09:05:00 (UTC)
* 終了   : 2026-06-14 09:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260614-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→15→13→17→13→17→13→15→16
* 開始   : 2026-06-14 13:50:00 (UTC)
* 終了   : 2026-06-14 14:00:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→12→11→14→15→12→11→14
* 開始   : 2026-06-14 15:45:00 (UTC)
* 終了   : 2026-06-14 15:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→14→11→12→13
* 開始   : 2026-06-14 18:40:00 (UTC)
* 終了   : 2026-06-14 19:10:00 (UTC)
* 現象   : 2026-06-14 19:10:00 (UTC)を境に水準が 11.88から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→9→10→10→10
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 01:55:00 (UTC)
* 現象   : 2026-06-15 01:55:00 (UTC)を境に水準が 11.73から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.573, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→9→10→8→9→8
* 開始   : 2026-06-15 23:55:00 (UTC)
* 終了   : 2026-06-16 01:15:00 (UTC)
* 現象   : 2026-06-16 01:15:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.12σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→17→18→15→17→18→15→16
* 開始   : 2026-06-16 06:30:00 (UTC)
* 終了   : 2026-06-16 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→19→20→18→20→18
* 開始   : 2026-06-16 07:25:00 (UTC)
* 終了   : 2026-06-16 07:50:00 (UTC)
* 現象   : 2026-06-16 07:50:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.348, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→24→24→22→25→23→24→21→22
* 開始   : 2026-06-16 12:20:00 (UTC)
* 終了   : 2026-06-16 13:05:00 (UTC)
* 現象   : 2026-06-16 13:05:00 (UTC)を境に水準が 14.88から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.321, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→20→16→18→20→16→18
* 開始   : 2026-06-16 15:55:00 (UTC)
* 終了   : 2026-06-16 16:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→13→15→13→15→14
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 18:15:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→12→9→12→9→10→12
* 開始   : 2026-06-16 20:10:00 (UTC)
* 終了   : 2026-06-16 20:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260616-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→11→8→11→8→11→8→9
* 開始   : 2026-06-16 20:55:00 (UTC)
* 終了   : 2026-06-16 21:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host06-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→7→9→7→9→7→9→10
* 開始   : 2026-06-16 21:10:00 (UTC)
* 終了   : 2026-06-16 21:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.6462(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 7→5→8→7→5→8
* 開始   : 2026-06-17 00:10:00 (UTC)
* 終了   : 2026-06-17 00:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→17→…→15→17→14→15
* 開始   : 2026-06-17 05:15:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 2026-06-17 05:30:00 (UTC)を境に水準が 14.91から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.356σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.977, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 23→24→23→22→22→23→21
* 開始   : 2026-06-17 12:15:00 (UTC)
* 終了   : 2026-06-17 12:45:00 (UTC)
* 現象   : 2026-06-17 12:45:00 (UTC)を境に水準が 15.03から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.573, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→20→18→17→18→20→18→17→18
* 開始   : 2026-06-17 15:35:00 (UTC)
* 終了   : 2026-06-17 15:40:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.864(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→12→…→13→12→13→12
* 開始   : 2026-06-17 18:00:00 (UTC)
* 終了   : 2026-06-17 18:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→14→9→11→14→9→11→12
* 開始   : 2026-06-17 19:50:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6879(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.851σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→10→6→12→…→6→12→11→12
* 開始   : 2026-06-18 02:35:00 (UTC)
* 終了   : 2026-06-18 02:40:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→11→13→12→…→12→14→9→12
* 開始   : 2026-06-18 04:05:00 (UTC)
* 終了   : 2026-06-18 04:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.06σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→17→14→17→15
* 開始   : 2026-06-18 05:55:00 (UTC)
* 終了   : 2026-06-18 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→15→17→18→…→17→18→14→13
* 開始   : 2026-06-18 06:00:00 (UTC)
* 終了   : 2026-06-18 06:05:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.119σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→19→18→18→18→20
* 開始   : 2026-06-18 07:00:00 (UTC)
* 終了   : 2026-06-18 07:25:00 (UTC)
* 現象   : 2026-06-18 07:25:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→23→17→20→23→17→20
* 開始   : 2026-06-18 09:20:00 (UTC)
* 終了   : 2026-06-18 09:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.356σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 24→21→22→21→25→21→24
* 開始   : 2026-06-18 11:15:00 (UTC)
* 終了   : 2026-06-18 11:45:00 (UTC)
* 現象   : 2026-06-18 11:45:00 (UTC)を境に水準が 14.97から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→20→21→21
* 開始   : 2026-06-18 15:40:00 (UTC)
* 終了   : 2026-06-18 15:55:00 (UTC)
* 現象   : 2026-06-18 15:55:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 19→17→15→19→15→19→15→17→18
* 開始   : 2026-06-18 16:25:00 (UTC)
* 終了   : 2026-06-18 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.805σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→17→…→17→15→18→17
* 開始   : 2026-06-18 16:30:00 (UTC)
* 終了   : 2026-06-18 16:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→17→15→17→15→19→17
* 開始   : 2026-06-18 16:35:00 (UTC)
* 終了   : 2026-06-18 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-019 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→15→16→13→16→13→16
* 開始   : 2026-06-18 17:30:00 (UTC)
* 終了   : 2026-06-18 18:15:00 (UTC)
* 現象   : 2026-06-18 18:15:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.181, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host15-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→15→13→15→13→15→13→16→14
* 開始   : 2026-06-18 17:50:00 (UTC)
* 終了   : 2026-06-18 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host15-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→8→10→9→10→11→11→8→12
* 開始   : 2026-06-19 01:45:00 (UTC)
* 終了   : 2026-06-19 02:30:00 (UTC)
* 現象   : 2026-06-19 02:30:00 (UTC)を境に水準が 14.73から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→13→12→13→11→11→15
* 開始   : 2026-06-19 03:20:00 (UTC)
* 終了   : 2026-06-19 04:05:00 (UTC)
* 現象   : 2026-06-19 04:05:00 (UTC)を境に水準が 14.97から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→11→14→11→14→12→14
* 開始   : 2026-06-19 04:05:00 (UTC)
* 終了   : 2026-06-19 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→21→20→19→21→19→20
* 開始   : 2026-06-19 08:05:00 (UTC)
* 終了   : 2026-06-19 08:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260619-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→14→…→15→14→15→16
* 開始   : 2026-06-19 17:00:00 (UTC)
* 終了   : 2026-06-19 17:05:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→14→15→17→14→15→16
* 開始   : 2026-06-19 17:15:00 (UTC)
* 終了   : 2026-06-19 17:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→15→12→15→12→14
* 開始   : 2026-06-19 18:30:00 (UTC)
* 終了   : 2026-06-19 18:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→14→11→14→11→16→14
* 開始   : 2026-06-19 18:40:00 (UTC)
* 終了   : 2026-06-19 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.851σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→15→14
* 開始   : 2026-06-19 19:15:00 (UTC)
* 終了   : 2026-06-19 19:30:00 (UTC)
* 現象   : 2026-06-19 19:30:00 (UTC)を境に水準が 14.96から12.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→11→10→12→10→9→10
* 開始   : 2026-06-19 21:15:00 (UTC)
* 終了   : 2026-06-19 22:05:00 (UTC)
* 現象   : 2026-06-19 22:05:00 (UTC)を境に水準が 14.99から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 7→11→9→11→9→11→7→10
* 開始   : 2026-06-20 00:50:00 (UTC)
* 終了   : 2026-06-20 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→8→…→8→5→9→10
* 開始   : 2026-06-20 21:10:00 (UTC)
* 終了   : 2026-06-20 21:20:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260620-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260620-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260620-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 6→8→11→10→8→11→10→7
* 開始   : 2026-06-20 23:45:00 (UTC)
* 終了   : 2026-06-20 23:50:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→9→8→9→10→12
* 開始   : 2026-06-21 02:50:00 (UTC)
* 終了   : 2026-06-21 03:15:00 (UTC)
* 現象   : 2026-06-21 03:15:00 (UTC)を境に水準が 11.83から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→8→13→10→14→13→10→14→11
* 開始   : 2026-06-21 05:20:00 (UTC)
* 終了   : 2026-06-21 05:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→13→17→11→14→13→17→11→14
* 開始   : 2026-06-21 08:10:00 (UTC)
* 終了   : 2026-06-21 08:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.126σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→8→10→10→9→9→11
* 開始   : 2026-06-22 22:05:00 (UTC)
* 終了   : 2026-06-22 23:00:00 (UTC)
* 現象   : 2026-06-22 23:00:00 (UTC)を境に水準が 14.9から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→14→…→14→18→15→13
* 開始   : 2026-06-23 05:50:00 (UTC)
* 終了   : 2026-06-23 06:00:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-013 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→24→22→23
* 開始   : 2026-06-23 10:00:00 (UTC)
* 終了   : 2026-06-23 10:15:00 (UTC)
* 現象   : 2026-06-23 10:15:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→17→14→17→16
* 開始   : 2026-06-23 17:00:00 (UTC)
* 終了   : 2026-06-23 17:05:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→12→9→8→…→9→8→9→10
* 開始   : 2026-06-23 20:30:00 (UTC)
* 終了   : 2026-06-23 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→6→5→10→8→6→5→10→8
* 開始   : 2026-06-23 23:40:00 (UTC)
* 終了   : 2026-06-23 23:45:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→10→14→10→14→12→13
* 開始   : 2026-06-24 04:10:00 (UTC)
* 終了   : 2026-06-24 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→11→16→12→16→12→16→12→15
* 開始   : 2026-06-24 04:25:00 (UTC)
* 終了   : 2026-06-24 05:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260624-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→17→15→17→18→17→15
* 開始   : 2026-06-24 06:20:00 (UTC)
* 終了   : 2026-06-24 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→23→22→22→23→22→23→22→23
* 開始   : 2026-06-24 12:45:00 (UTC)
* 終了   : 2026-06-24 13:30:00 (UTC)
* 現象   : 2026-06-24 13:30:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→18→22→22→20→19
* 開始   : 2026-06-24 15:35:00 (UTC)
* 終了   : 2026-06-24 16:00:00 (UTC)
* 現象   : 2026-06-24 16:00:00 (UTC)を境に水準が 14.82から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.348, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→17→22→16→…→19→15→19→18
* 開始   : 2026-06-24 16:05:00 (UTC)
* 終了   : 2026-06-24 17:05:00 (UTC)
* 現象   : 2026-06-24 17:05:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.129, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→16→…→16→13→18→15
* 開始   : 2026-06-24 17:50:00 (UTC)
* 終了   : 2026-06-24 18:00:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.8317(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 7→5→10→7→5→10→9
* 開始   : 2026-06-24 23:00:00 (UTC)
* 終了   : 2026-06-24 23:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→6→10→11→8→11
* 開始   : 2026-06-25 00:15:00 (UTC)
* 終了   : 2026-06-25 00:40:00 (UTC)
* 現象   : 2026-06-25 00:40:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→12→13→14→…→13→14→11→10
* 開始   : 2026-06-25 03:55:00 (UTC)
* 終了   : 2026-06-25 04:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→17→14→17
* 開始   : 2026-06-25 17:30:00 (UTC)
* 終了   : 2026-06-25 17:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→9
* 開始   : 2026-06-25 22:50:00 (UTC)
* 終了   : 2026-06-25 23:05:00 (UTC)
* 現象   : 2026-06-25 23:05:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→7→11→5→7→11→9
* 開始   : 2026-06-26 00:40:00 (UTC)
* 終了   : 2026-06-26 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→10→10→10→11→12→13
* 開始   : 2026-06-26 01:35:00 (UTC)
* 終了   : 2026-06-26 02:55:00 (UTC)
* 現象   : 2026-06-26 02:55:00 (UTC)を境に水準が 14.86から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→11→13→11→…→14→10→14→12
* 開始   : 2026-06-26 03:35:00 (UTC)
* 終了   : 2026-06-26 03:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260626-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→10→14→13→10→14→13
* 開始   : 2026-06-26 04:20:00 (UTC)
* 終了   : 2026-06-26 04:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→14→17→18→…→17→13→16→14
* 開始   : 2026-06-26 17:00:00 (UTC)
* 終了   : 2026-06-26 17:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→9→8→11→8→11→8→9→10
* 開始   : 2026-06-26 20:50:00 (UTC)
* 終了   : 2026-06-26 21:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 7→9→4→6→…→6→11→6→7
* 開始   : 2026-06-27 00:15:00 (UTC)
* 終了   : 2026-06-27 00:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→9→9→8→10→10→7→8→12
* 開始   : 2026-06-28 01:30:00 (UTC)
* 終了   : 2026-06-28 02:15:00 (UTC)
* 現象   : 2026-06-28 02:15:00 (UTC)を境に水準が 11.72から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→9→11→5→9→11→8
* 開始   : 2026-06-28 01:50:00 (UTC)
* 終了   : 2026-06-28 02:00:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→10→13→10→11
* 開始   : 2026-06-28 04:45:00 (UTC)
* 終了   : 2026-06-28 04:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.413σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→14→11→13→12→12
* 開始   : 2026-06-28 04:45:00 (UTC)
* 終了   : 2026-06-28 05:20:00 (UTC)
* 現象   : 2026-06-28 05:20:00 (UTC)を境に水準が 11.75から12.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→16→14→13→10→16→14
* 開始   : 2026-06-28 08:15:00 (UTC)
* 終了   : 2026-06-28 08:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7792(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260628-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→11→…→11→9→10→11
* 開始   : 2026-06-28 17:40:00 (UTC)
* 終了   : 2026-06-28 17:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→10→13→11→10→13→11→10
* 開始   : 2026-06-30 03:20:00 (UTC)
* 終了   : 2026-06-30 03:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260630-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→14→…→16→17→13→15
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260630-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260630-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→12→17→13→…→13→18→15→16
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 06:00:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→15→18→15→18→16→15
* 開始   : 2026-06-30 06:10:00 (UTC)
* 終了   : 2026-06-30 06:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.301倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.873σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→19→18→20→19
* 開始   : 2026-06-30 07:30:00 (UTC)
* 終了   : 2026-06-30 07:35:00 (UTC)
* 現象   : 平常時(16)に対し 1.25倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.804σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→16→15→17→16→15→17→15
* 開始   : 2026-06-30 16:55:00 (UTC)
* 終了   : 2026-06-30 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→13→14→11→13
* 開始   : 2026-06-30 18:45:00 (UTC)
* 終了   : 2026-06-30 18:50:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
