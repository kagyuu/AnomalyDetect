# host07 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host07 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 284 (SEVERE: 26, FATAL: 128, WARN: 130, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 26 | 128 | 130 | 284 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260604-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→9→9→7→9→9
* 開始   : 2026-06-04 23:55:00 (UTC)
* 終了   : 2026-06-05 00:20:00 (UTC)
* 現象   : 2026-06-05 00:20:00 (UTC)を境に水準が 14.99から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host07-010 active_connections の推移](charts/EVT-20260604-host07-010.svg)

# イベントID( EVT-20260608-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→15→…→13→14→12→14
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.89から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.942, 限界=2.658)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-002 active_connections の推移](charts/EVT-20260608-host07-002.svg)

# イベントID( EVT-20260608-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→13→…→14→12→13→14
* 開始   : 2026-06-08 03:15:00 (UTC)
* 終了   : 2026-06-08 18:50:00 (UTC)
* 現象   : 2026-06-08 18:50:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.829, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.953, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-003 active_connections の推移](charts/EVT-20260608-host07-003.svg)

# イベントID( EVT-20260608-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→14→13→14→…→15→11→14→11
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-004 active_connections の推移](charts/EVT-20260608-host07-004.svg)

# イベントID( EVT-20260608-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→18→17→15→…→10→13→10→11
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.89から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.202, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-005 active_connections の推移](charts/EVT-20260608-host07-005.svg)

# イベントID( EVT-20260608-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→17→…→11→14→13→11
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.78から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.751, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-006 active_connections の推移](charts/EVT-20260608-host07-006.svg)

# イベントID( EVT-20260612-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→11→12→11→12→13→12→12→15
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 04:45:00 (UTC)
* 現象   : 2026-06-12 04:45:00 (UTC)を境に水準が 15.02から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.841, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host07-001 active_connections の推移](charts/EVT-20260612-host07-001.svg)

# イベントID( EVT-20260614-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→11→8→11→11→10→12→12→13
* 開始   : 2026-06-14 03:20:00 (UTC)
* 終了   : 2026-06-14 04:30:00 (UTC)
* 現象   : 2026-06-14 04:30:00 (UTC)を境に水準が 11.76から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.868, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-002 active_connections の推移](charts/EVT-20260614-host07-002.svg)

# イベントID( EVT-20260615-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→14→…→15→12→11→12
* 開始   : 2026-06-15 02:15:00 (UTC)
* 終了   : 2026-06-15 21:45:00 (UTC)
* 現象   : 2026-06-15 21:45:00 (UTC)を境に水準が 11.68から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-001 active_connections の推移](charts/EVT-20260615-host07-001.svg)

# イベントID( EVT-20260615-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→17→19→20→…→14→15→14→13
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.898, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-002 active_connections の推移](charts/EVT-20260615-host07-002.svg)

# イベントID( EVT-20260615-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→13→…→12→13→12→11
* 開始   : 2026-06-15 04:00:00 (UTC)
* 終了   : 2026-06-15 19:10:00 (UTC)
* 現象   : 2026-06-15 19:10:00 (UTC)を境に水準が 11.92から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.585σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.75, 限界=2.646)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-005 active_connections の推移](charts/EVT-20260615-host07-005.svg)

# イベントID( EVT-20260615-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→16→12→16→…→12→14→10→13
* 開始   : 2026-06-15 04:45:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.91から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.658)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-006 active_connections の推移](charts/EVT-20260615-host07-006.svg)

# イベントID( EVT-20260616-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→12→13
* 開始   : 2026-06-16 20:50:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 2026-06-16 21:00:00 (UTC)を境に水準が 14.96から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host07-009 active_connections の推移](charts/EVT-20260616-host07-009.svg)

# イベントID( EVT-20260617-host07-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→18→17→17→17→18
* 開始   : 2026-06-17 16:55:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 2026-06-17 17:20:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-014 active_connections の推移](charts/EVT-20260617-host07-014.svg)

# イベントID( EVT-20260622-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→17→16→14→…→14→15→14→13
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.312, 限界=2.646)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-001 active_connections の推移](charts/EVT-20260622-host07-001.svg)

# イベントID( EVT-20260622-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→14→…→15→13→11→14
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 2026-06-22 21:50:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-003 active_connections の推移](charts/EVT-20260622-host07-003.svg)

# イベントID( EVT-20260622-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→17→15→16→…→14→15→13→12
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.87から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.091, 限界=2.658)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-004 active_connections の推移](charts/EVT-20260622-host07-004.svg)

# イベントID( EVT-20260622-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→14→…→13→14→12→13
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.026, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-005 active_connections の推移](charts/EVT-20260622-host07-005.svg)

# イベントID( EVT-20260622-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→18→…→12→14→13→15
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 22:15:00 (UTC)
* 現象   : 2026-06-22 22:15:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.54σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.697, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-006 active_connections の推移](charts/EVT-20260622-host07-006.svg)

# イベントID( EVT-20260624-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→8→11
* 開始   : 2026-06-24 00:30:00 (UTC)
* 終了   : 2026-06-24 00:50:00 (UTC)
* 現象   : 2026-06-24 00:50:00 (UTC)を境に水準が 14.99から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.956, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-001 active_connections の推移](charts/EVT-20260624-host07-001.svg)

# イベントID( EVT-20260625-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→9→11→10→9→10→10
* 開始   : 2026-06-25 21:00:00 (UTC)
* 終了   : 2026-06-25 21:30:00 (UTC)
* 現象   : 2026-06-25 21:30:00 (UTC)を境に水準が 14.84から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.938, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host07-010 active_connections の推移](charts/EVT-20260625-host07-010.svg)

# イベントID( EVT-20260629-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→17→…→11→13→11→15
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 22:00:00 (UTC)
* 現象   : 2026-06-29 22:00:00 (UTC)を境に水準が 11.83から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.864, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-001 active_connections の推移](charts/EVT-20260629-host07-001.svg)

# イベントID( EVT-20260629-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→16→15→…→14→15→12→15
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 21:15:00 (UTC)
* 現象   : 2026-06-29 21:15:00 (UTC)を境に水準が 11.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-002 active_connections の推移](charts/EVT-20260629-host07-002.svg)

# イベントID( EVT-20260629-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→16→…→13→11→9→11
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.81から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.692, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-003 active_connections の推移](charts/EVT-20260629-host07-003.svg)

# イベントID( EVT-20260629-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→14→…→13→16→11→12
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.216, 限界=2.646)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.095, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-004 active_connections の推移](charts/EVT-20260629-host07-004.svg)

# イベントID( EVT-20260629-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→14→…→13→14→13→14
* 開始   : 2026-06-29 03:45:00 (UTC)
* 終了   : 2026-06-29 19:45:00 (UTC)
* 現象   : 2026-06-29 19:45:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.863, 限界=2.658)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-005 active_connections の推移](charts/EVT-20260629-host07-005.svg)

# イベントID( EVT-20260601-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→7→13→11→9
* 開始   : 2026-06-01 02:15:00 (UTC)
* 終了   : 2026-06-01 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-002 active_connections の推移](charts/EVT-20260601-host07-002.svg)

# イベントID( EVT-20260601-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→15→18→14→15
* 開始   : 2026-06-01 05:30:00 (UTC)
* 終了   : 2026-06-01 05:30:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host07-004 active_connections の推移](charts/EVT-20260601-host07-004.svg)

# イベントID( EVT-20260601-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→15→10→14→15
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.462σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-008 active_connections の推移](charts/EVT-20260601-host07-008.svg)

# イベントID( EVT-20260601-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→16→11→14→12
* 開始   : 2026-06-01 18:45:00 (UTC)
* 終了   : 2026-06-01 18:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-009 active_connections の推移](charts/EVT-20260601-host07-009.svg)

# イベントID( EVT-20260601-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→13→8→10→11
* 開始   : 2026-06-01 19:55:00 (UTC)
* 終了   : 2026-06-01 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host07-010 active_connections の推移](charts/EVT-20260601-host07-010.svg)

# イベントID( EVT-20260602-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→8→3→9→7
* 開始   : 2026-06-02 00:35:00 (UTC)
* 終了   : 2026-06-02 00:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.3636(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.643σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-001 active_connections の推移](charts/EVT-20260602-host07-001.svg)

# イベントID( EVT-20260602-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→18→23→18→19
* 開始   : 2026-06-02 08:20:00 (UTC)
* 終了   : 2026-06-02 08:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-002 active_connections の推移](charts/EVT-20260602-host07-002.svg)

# イベントID( EVT-20260602-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→19→24→20→19
* 開始   : 2026-06-02 09:25:00 (UTC)
* 終了   : 2026-06-02 09:25:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-003 active_connections の推移](charts/EVT-20260602-host07-003.svg)

# イベントID( EVT-20260603-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→14→10→14→12
* 開始   : 2026-06-03 18:40:00 (UTC)
* 終了   : 2026-06-03 18:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.527σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-009 active_connections の推移](charts/EVT-20260603-host07-009.svg)

# イベントID( EVT-20260603-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→11→6→10→12
* 開始   : 2026-06-03 21:20:00 (UTC)
* 終了   : 2026-06-03 21:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host07-011 active_connections の推移](charts/EVT-20260603-host07-011.svg)

# イベントID( EVT-20260604-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→11→17→13→13
* 開始   : 2026-06-04 04:35:00 (UTC)
* 終了   : 2026-06-04 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.714σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-001 active_connections の推移](charts/EVT-20260604-host07-001.svg)

# イベントID( EVT-20260604-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→12→17→15→11
* 開始   : 2026-06-04 05:00:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-002 active_connections の推移](charts/EVT-20260604-host07-002.svg)

# イベントID( EVT-20260604-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→15→10→14→14
* 開始   : 2026-06-04 18:30:00 (UTC)
* 終了   : 2026-06-04 18:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.6557(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-007 active_connections の推移](charts/EVT-20260604-host07-007.svg)

# イベントID( EVT-20260604-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→10→8→10→10
* 開始   : 2026-06-04 20:00:00 (UTC)
* 終了   : 2026-06-04 20:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-008 active_connections の推移](charts/EVT-20260604-host07-008.svg)

# イベントID( EVT-20260605-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→22→18→21→22→18→21→19→21
* 開始   : 2026-06-05 08:15:00 (UTC)
* 終了   : 2026-06-05 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260605-host07-005 active_connections の推移](charts/EVT-20260605-host07-005.svg)

# イベントID( EVT-20260605-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→21→16→19→22
* 開始   : 2026-06-05 14:45:00 (UTC)
* 終了   : 2026-06-05 14:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→19→…→19→17→18→19
* 開始   : 2026-06-05 15:35:00 (UTC)
* 終了   : 2026-06-05 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-008 active_connections の推移](charts/EVT-20260605-host07-008.svg)

# イベントID( EVT-20260606-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→11→12→11→12
* 開始   : 2026-06-06 04:05:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.643, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260606-host07-001 active_connections の推移](charts/EVT-20260606-host07-001.svg)

# イベントID( EVT-20260606-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→12→…→11→8→11→12
* 開始   : 2026-06-06 04:35:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.888, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host07-002 active_connections の推移](charts/EVT-20260606-host07-002.svg)

# イベントID( EVT-20260606-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→11→…→11→9→12→9
* 開始   : 2026-06-06 04:50:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.393σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.031, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host07-003 active_connections の推移](charts/EVT-20260606-host07-003.svg)

# イベントID( EVT-20260606-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→12→10→12→…→12→11→13→12
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.404σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.159, 限界=2.658)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host07-004 active_connections の推移](charts/EVT-20260606-host07-004.svg)

# イベントID( EVT-20260606-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→14→…→13→12→11→15
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.135, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host07-005 active_connections の推移](charts/EVT-20260606-host07-005.svg)

# イベントID( EVT-20260606-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→12→…→9→11→9→10
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.74, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host07-006 active_connections の推移](charts/EVT-20260606-host07-006.svg)

# イベントID( EVT-20260606-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→7→5→7→10
* 開始   : 2026-06-06 22:00:00 (UTC)
* 終了   : 2026-06-06 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260606-host07-007 active_connections の推移](charts/EVT-20260606-host07-007.svg)

# イベントID( EVT-20260607-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→12→15→10→13
* 開始   : 2026-06-07 05:15:00 (UTC)
* 終了   : 2026-06-07 05:15:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host07-001 active_connections の推移](charts/EVT-20260607-host07-001.svg)

# イベントID( EVT-20260607-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→9→15→12→12
* 開始   : 2026-06-07 05:30:00 (UTC)
* 終了   : 2026-06-07 05:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.227σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→14→13
* 開始   : 2026-06-07 17:30:00 (UTC)
* 終了   : 2026-06-07 17:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host07-005 active_connections の推移](charts/EVT-20260607-host07-005.svg)

# イベントID( EVT-20260608-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→17→…→16→13→15→14
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 19:50:00 (UTC)
* 現象   : 2026-06-08 19:50:00 (UTC)を境に水準が 11.96から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.186, 限界=2.646)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-007 active_connections の推移](charts/EVT-20260608-host07-007.svg)

# イベントID( EVT-20260609-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→12→17→15→15
* 開始   : 2026-06-09 05:10:00 (UTC)
* 終了   : 2026-06-09 05:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host07-001 active_connections の推移](charts/EVT-20260609-host07-001.svg)

# イベントID( EVT-20260609-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→13→18→16→15
* 開始   : 2026-06-09 06:15:00 (UTC)
* 終了   : 2026-06-09 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-002 active_connections の推移](charts/EVT-20260609-host07-002.svg)

# イベントID( EVT-20260609-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→19→22→18→19
* 開始   : 2026-06-09 07:50:00 (UTC)
* 終了   : 2026-06-09 07:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-005 active_connections の推移](charts/EVT-20260609-host07-005.svg)

# イベントID( EVT-20260609-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→19→15→20→19
* 開始   : 2026-06-09 16:05:00 (UTC)
* 終了   : 2026-06-09 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host07-008 active_connections の推移](charts/EVT-20260609-host07-008.svg)

# イベントID( EVT-20260609-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→13→14
* 開始   : 2026-06-09 18:50:00 (UTC)
* 終了   : 2026-06-09 18:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-010 active_connections の推移](charts/EVT-20260609-host07-010.svg)

# イベントID( EVT-20260609-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→12→11
* 開始   : 2026-06-09 19:55:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-011 active_connections の推移](charts/EVT-20260609-host07-011.svg)

# イベントID( EVT-20260610-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→14→10→14→12→14→12
* 開始   : 2026-06-10 04:05:00 (UTC)
* 終了   : 2026-06-10 05:00:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host07-004 active_connections の推移](charts/EVT-20260610-host07-004.svg)

# イベントID( EVT-20260610-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→16→11→12→15→16→11
* 開始   : 2026-06-10 04:15:00 (UTC)
* 終了   : 2026-06-10 04:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260610-host07-005 active_connections の推移](charts/EVT-20260610-host07-005.svg)

# イベントID( EVT-20260610-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→16→21→17→19
* 開始   : 2026-06-10 07:30:00 (UTC)
* 終了   : 2026-06-10 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-006 active_connections の推移](charts/EVT-20260610-host07-006.svg)

# イベントID( EVT-20260610-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→21→25→23→21
* 開始   : 2026-06-10 10:10:00 (UTC)
* 終了   : 2026-06-10 10:10:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→17→14→19→19
* 開始   : 2026-06-10 16:20:00 (UTC)
* 終了   : 2026-06-10 16:20:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host07-008 active_connections の推移](charts/EVT-20260610-host07-008.svg)

# イベントID( EVT-20260610-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→8→4→6→7
* 開始   : 2026-06-10 22:50:00 (UTC)
* 終了   : 2026-06-10 22:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host07-012 active_connections の推移](charts/EVT-20260610-host07-012.svg)

# イベントID( EVT-20260611-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→14→14
* 開始   : 2026-06-11 05:40:00 (UTC)
* 終了   : 2026-06-11 05:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-005 active_connections の推移](charts/EVT-20260611-host07-005.svg)

# イベントID( EVT-20260611-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→15→20→18→19→20→18→19→16
* 開始   : 2026-06-11 07:00:00 (UTC)
* 終了   : 2026-06-11 07:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-006 active_connections の推移](charts/EVT-20260611-host07-006.svg)

# イベントID( EVT-20260611-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→17→20→19→17→20→19→17→16
* 開始   : 2026-06-11 07:05:00 (UTC)
* 終了   : 2026-06-11 07:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-007 active_connections の推移](charts/EVT-20260611-host07-007.svg)

# イベントID( EVT-20260611-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→22→20→18→22→18→19
* 開始   : 2026-06-11 07:55:00 (UTC)
* 終了   : 2026-06-11 08:05:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-008 active_connections の推移](charts/EVT-20260611-host07-008.svg)

# イベントID( EVT-20260611-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→21→17→21→22
* 開始   : 2026-06-11 14:30:00 (UTC)
* 終了   : 2026-06-11 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-009 active_connections の推移](charts/EVT-20260611-host07-009.svg)

# イベントID( EVT-20260611-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→20→19→19→20→19→18
* 開始   : 2026-06-11 15:50:00 (UTC)
* 終了   : 2026-06-11 16:30:00 (UTC)
* 現象   : 2026-06-11 16:30:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.482σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host07-010 active_connections の推移](charts/EVT-20260611-host07-010.svg)

# イベントID( EVT-20260611-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→12→19→15→16→12→19→15→16
* 開始   : 2026-06-11 17:50:00 (UTC)
* 終了   : 2026-06-11 18:15:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260611-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-012 active_connections の推移](charts/EVT-20260611-host07-012.svg)

# イベントID( EVT-20260611-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→13→15
* 開始   : 2026-06-11 18:35:00 (UTC)
* 終了   : 2026-06-11 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.527σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-013 active_connections の推移](charts/EVT-20260611-host07-013.svg)

# イベントID( EVT-20260611-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→10→11
* 開始   : 2026-06-11 20:00:00 (UTC)
* 終了   : 2026-06-11 20:00:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-014 active_connections の推移](charts/EVT-20260611-host07-014.svg)

# イベントID( EVT-20260612-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→19→22→16→…→22→16→18→20
* 開始   : 2026-06-12 07:55:00 (UTC)
* 終了   : 2026-06-12 08:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.38倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host07-004 active_connections の推移](charts/EVT-20260612-host07-004.svg)

# イベントID( EVT-20260612-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→19→15→21→19
* 開始   : 2026-06-12 15:45:00 (UTC)
* 終了   : 2026-06-12 15:45:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→18→13→15→…→15→13→14→15
* 開始   : 2026-06-12 17:35:00 (UTC)
* 終了   : 2026-06-12 18:00:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host07-007 active_connections の推移](charts/EVT-20260612-host07-007.svg)

# イベントID( EVT-20260612-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→10→12→8→10
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 20:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host02-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-073 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260612-host07-008 active_connections の推移](charts/EVT-20260612-host07-008.svg)

# イベントID( EVT-20260612-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→12→9→13→11
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host07-009 active_connections の推移](charts/EVT-20260612-host07-009.svg)

# イベントID( EVT-20260613-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→13→11→10→…→12→13→14→13
* 開始   : 2026-06-13 03:45:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.72, 限界=2.658)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host07-001 active_connections の推移](charts/EVT-20260613-host07-001.svg)

# イベントID( EVT-20260613-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→13→10→12→…→12→13→14→12
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.822, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host07-003 active_connections の推移](charts/EVT-20260613-host07-003.svg)

# イベントID( EVT-20260613-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→…→13→11→13→11
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260613-host07-004 active_connections の推移](charts/EVT-20260613-host07-004.svg)

# イベントID( EVT-20260613-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→10→…→14→11→14→11
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.686σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host07-005 active_connections の推移](charts/EVT-20260613-host07-005.svg)

# イベントID( EVT-20260613-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→12→14→11→…→8→9→11→10
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host07-006 active_connections の推移](charts/EVT-20260613-host07-006.svg)

# イベントID( EVT-20260613-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→13→…→11→10→9→10
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host07-007 active_connections の推移](charts/EVT-20260613-host07-007.svg)

# イベントID( EVT-20260613-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→10→6
* 開始   : 2026-06-13 22:35:00 (UTC)
* 終了   : 2026-06-13 22:35:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-065 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260613-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host07-009 active_connections の推移](charts/EVT-20260613-host07-009.svg)

# イベントID( EVT-20260614-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→17→11→15→14
* 開始   : 2026-06-14 11:10:00 (UTC)
* 終了   : 2026-06-14 11:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host07-003 active_connections の推移](charts/EVT-20260614-host07-003.svg)

# イベントID( EVT-20260615-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→14→12→11→12
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.85から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-003 active_connections の推移](charts/EVT-20260615-host07-003.svg)

# イベントID( EVT-20260615-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→15→…→11→14→11→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.88から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.265, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-004 active_connections の推移](charts/EVT-20260615-host07-004.svg)

# イベントID( EVT-20260615-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→7→3→9→9
* 開始   : 2026-06-15 23:15:00 (UTC)
* 終了   : 2026-06-15 23:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.3462(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.961σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host07-008 active_connections の推移](charts/EVT-20260615-host07-008.svg)

# イベントID( EVT-20260616-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→15→11→15→16
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.701σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-006 active_connections の推移](charts/EVT-20260616-host07-006.svg)

# イベントID( EVT-20260616-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→14→…→14→10→12→11
* 開始   : 2026-06-16 18:50:00 (UTC)
* 終了   : 2026-06-16 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.691σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host07-008 active_connections の推移](charts/EVT-20260616-host07-008.svg)

# イベントID( EVT-20260616-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→10→10
* 開始   : 2026-06-16 21:35:00 (UTC)
* 終了   : 2026-06-16 21:35:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host07-010 active_connections の推移](charts/EVT-20260616-host07-010.svg)

# イベントID( EVT-20260616-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→5→6→9→5→6→9→10
* 開始   : 2026-06-16 21:45:00 (UTC)
* 終了   : 2026-06-16 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-011 active_connections の推移](charts/EVT-20260616-host07-011.svg)

# イベントID( EVT-20260616-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 8→8→4→9→8
* 開始   : 2026-06-16 23:50:00 (UTC)
* 終了   : 2026-06-16 23:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 7→6→12→8→7
* 開始   : 2026-06-17 01:05:00 (UTC)
* 終了   : 2026-06-17 01:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-001 active_connections の推移](charts/EVT-20260617-host07-001.svg)

# イベントID( EVT-20260617-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→9→13→10→9
* 開始   : 2026-06-17 02:35:00 (UTC)
* 終了   : 2026-06-17 02:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host07-004 active_connections の推移](charts/EVT-20260617-host07-004.svg)

# イベントID( EVT-20260617-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→11→15→10→11
* 開始   : 2026-06-17 03:55:00 (UTC)
* 終了   : 2026-06-17 03:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-005 active_connections の推移](charts/EVT-20260617-host07-005.svg)

# イベントID( EVT-20260617-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→12→16→10→13
* 開始   : 2026-06-17 04:25:00 (UTC)
* 終了   : 2026-06-17 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.714σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-006 active_connections の推移](charts/EVT-20260617-host07-006.svg)

# イベントID( EVT-20260617-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→13→…→12→9→16→12
* 開始   : 2026-06-17 04:30:00 (UTC)
* 終了   : 2026-06-17 04:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-007 active_connections の推移](charts/EVT-20260617-host07-007.svg)

# イベントID( EVT-20260617-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→20→17→20→17→20→17→18
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-010 active_connections の推移](charts/EVT-20260617-host07-010.svg)

# イベントID( EVT-20260617-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→22→25→21→21
* 開始   : 2026-06-17 10:05:00 (UTC)
* 終了   : 2026-06-17 10:05:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host07-011 active_connections の推移](charts/EVT-20260617-host07-011.svg)

# イベントID( EVT-20260617-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→13→13→14→13→12→14
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 20:35:00 (UTC)
* 現象   : 2026-06-17 20:35:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.68, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→11→15→13→10
* 開始   : 2026-06-18 03:50:00 (UTC)
* 終了   : 2026-06-18 03:50:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host07-001 active_connections の推移](charts/EVT-20260618-host07-001.svg)

# イベントID( EVT-20260618-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→14→14
* 開始   : 2026-06-18 06:15:00 (UTC)
* 終了   : 2026-06-18 06:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-002 active_connections の推移](charts/EVT-20260618-host07-002.svg)

# イベントID( EVT-20260618-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→19→18→17→16→19→18→17
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-003 active_connections の推移](charts/EVT-20260618-host07-003.svg)

# イベントID( EVT-20260618-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→16→13→14→15→16→13→14→15
* 開始   : 2026-06-18 17:40:00 (UTC)
* 終了   : 2026-06-18 17:45:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host07-005 active_connections の推移](charts/EVT-20260618-host07-005.svg)

# イベントID( EVT-20260618-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→13→14→11→13→12
* 開始   : 2026-06-18 18:40:00 (UTC)
* 終了   : 2026-06-18 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260618-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host07-007 active_connections の推移](charts/EVT-20260618-host07-007.svg)

# イベントID( EVT-20260618-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→8→5→7→…→7→6→9→10
* 開始   : 2026-06-18 23:10:00 (UTC)
* 終了   : 2026-06-18 23:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host07-010 active_connections の推移](charts/EVT-20260618-host07-010.svg)

# イベントID( EVT-20260619-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→20→…→20→16→19→18
* 開始   : 2026-06-19 07:55:00 (UTC)
* 終了   : 2026-06-19 08:05:00 (UTC)
* 現象   : 金曜7時台の平常値(17.47)に対し 22であった
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.142σ 外れた (平常値=17.47)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260619-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-003 active_connections の推移](charts/EVT-20260619-host07-003.svg)

# イベントID( EVT-20260619-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→14→13
* 開始   : 2026-06-19 18:45:00 (UTC)
* 終了   : 2026-06-19 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-007 active_connections の推移](charts/EVT-20260619-host07-007.svg)

# イベントID( EVT-20260620-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→6→12→9→8
* 開始   : 2026-06-20 01:10:00 (UTC)
* 終了   : 2026-06-20 01:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→9→9
* 開始   : 2026-06-20 03:05:00 (UTC)
* 終了   : 2026-06-20 03:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→11→13→11→…→14→16→14→13
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.892, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host07-004 active_connections の推移](charts/EVT-20260620-host07-004.svg)

# イベントID( EVT-20260620-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→12→11→13→11
* 開始   : 2026-06-20 04:40:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.776, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host07-005 active_connections の推移](charts/EVT-20260620-host07-005.svg)

# イベントID( EVT-20260620-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→11→10→11→…→10→11→12→10
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.658)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host07-006 active_connections の推移](charts/EVT-20260620-host07-006.svg)

# イベントID( EVT-20260620-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→12→13→…→8→10→12→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.988, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host07-007 active_connections の推移](charts/EVT-20260620-host07-007.svg)

# イベントID( EVT-20260620-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→11→10→11→…→10→9→11→9
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 20:25:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260620-host07-008 active_connections の推移](charts/EVT-20260620-host07-008.svg)

# イベントID( EVT-20260620-host07-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→10→…→12→10→11→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.19, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間

![EVT-20260620-host07-009 active_connections の推移](charts/EVT-20260620-host07-009.svg)

# イベントID( EVT-20260621-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→9→14→10→10
* 開始   : 2026-06-21 04:10:00 (UTC)
* 終了   : 2026-06-21 04:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.227σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260621-host07-002 active_connections の推移](charts/EVT-20260621-host07-002.svg)

# イベントID( EVT-20260621-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→16→12→16→16
* 開始   : 2026-06-21 11:40:00 (UTC)
* 終了   : 2026-06-21 11:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host07-006 active_connections の推移](charts/EVT-20260621-host07-006.svg)

# イベントID( EVT-20260621-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→10→7→11→11
* 開始   : 2026-06-21 18:25:00 (UTC)
* 終了   : 2026-06-21 18:25:00 (UTC)
* 現象   : 平常時(12)に対し 0.5833(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host07-009 active_connections の推移](charts/EVT-20260621-host07-009.svg)

# イベントID( EVT-20260621-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→9→9
* 開始   : 2026-06-21 20:00:00 (UTC)
* 終了   : 2026-06-21 20:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host07-010 active_connections の推移](charts/EVT-20260621-host07-010.svg)

# イベントID( EVT-20260622-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→14→13→14→…→13→14→13→12
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 22:40:00 (UTC)
* 現象   : 2026-06-22 22:40:00 (UTC)を境に水準が 11.74から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-002 active_connections の推移](charts/EVT-20260622-host07-002.svg)

# イベントID( EVT-20260622-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 7→10→13→10→8
* 開始   : 2026-06-22 22:30:00 (UTC)
* 終了   : 2026-06-22 22:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→7→13→8→7
* 開始   : 2026-06-23 02:10:00 (UTC)
* 終了   : 2026-06-23 02:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-001 active_connections の推移](charts/EVT-20260623-host07-001.svg)

# イベントID( EVT-20260623-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→16→19→16→16
* 開始   : 2026-06-23 06:05:00 (UTC)
* 終了   : 2026-06-23 06:05:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.462σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260623-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-003 active_connections の推移](charts/EVT-20260623-host07-003.svg)

# イベントID( EVT-20260624-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→15→17→15→14
* 開始   : 2026-06-24 05:25:00 (UTC)
* 終了   : 2026-06-24 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-002 active_connections の推移](charts/EVT-20260624-host07-002.svg)

# イベントID( EVT-20260624-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→13→16
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-003 active_connections の推移](charts/EVT-20260624-host07-003.svg)

# イベントID( EVT-20260624-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→20→25→22→21
* 開始   : 2026-06-24 09:40:00 (UTC)
* 終了   : 2026-06-24 09:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host07-006 active_connections の推移](charts/EVT-20260624-host07-006.svg)

# イベントID( EVT-20260624-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→22→20
* 開始   : 2026-06-24 14:30:00 (UTC)
* 終了   : 2026-06-24 14:30:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260624-host07-007 active_connections の推移](charts/EVT-20260624-host07-007.svg)

# イベントID( EVT-20260625-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→17→21→19→…→19→22→20→19
* 開始   : 2026-06-25 07:00:00 (UTC)
* 終了   : 2026-06-25 08:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host07-003 active_connections の推移](charts/EVT-20260625-host07-003.svg)

# イベントID( EVT-20260625-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→17→13→18→16
* 開始   : 2026-06-25 16:55:00 (UTC)
* 終了   : 2026-06-25 16:55:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host07-005 active_connections の推移](charts/EVT-20260625-host07-005.svg)

# イベントID( EVT-20260625-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→11→15→11→13→11→13→14
* 開始   : 2026-06-25 18:35:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host07-007 active_connections の推移](charts/EVT-20260625-host07-007.svg)

# イベントID( EVT-20260625-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→13→14→14→11→14→12→12
* 開始   : 2026-06-25 19:00:00 (UTC)
* 終了   : 2026-06-25 20:10:00 (UTC)
* 現象   : 2026-06-25 20:10:00 (UTC)を境に水準が 14.91から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host07-009 active_connections の推移](charts/EVT-20260625-host07-009.svg)

# イベントID( EVT-20260625-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→6→7→9→6→7→10
* 開始   : 2026-06-25 21:35:00 (UTC)
* 終了   : 2026-06-25 22:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.412σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host07-011 active_connections の推移](charts/EVT-20260625-host07-011.svg)

# イベントID( EVT-20260627-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→9→13→9→8
* 開始   : 2026-06-27 01:40:00 (UTC)
* 終了   : 2026-06-27 01:40:00 (UTC)
* 現象   : 平常時(7.25)に対し 1.793倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.989σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host07-001 active_connections の推移](charts/EVT-20260627-host07-001.svg)

# イベントID( EVT-20260627-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→13→…→11→10→11→10
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 19:40:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.885, 限界=2.658)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.7 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260627-host07-003 active_connections の推移](charts/EVT-20260627-host07-003.svg)

# イベントID( EVT-20260627-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→10→11→12→…→13→10→13→14
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.307σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.912, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host07-004 active_connections の推移](charts/EVT-20260627-host07-004.svg)

# イベントID( EVT-20260627-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→11→…→9→11→12→8
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.608, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host07-005 active_connections の推移](charts/EVT-20260627-host07-005.svg)

# イベントID( EVT-20260627-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→11→…→10→12→13→12
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 20:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.721, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host07-006 active_connections の推移](charts/EVT-20260627-host07-006.svg)

# イベントID( EVT-20260627-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→13→11→…→13→12→13→10
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 18:50:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.998, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host07-007 active_connections の推移](charts/EVT-20260627-host07-007.svg)

# イベントID( EVT-20260627-host07-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→12→13→12→…→13→12→11→13
* 開始   : 2026-06-27 06:35:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.065, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260627-host07-008 active_connections の推移](charts/EVT-20260627-host07-008.svg)

# イベントID( EVT-20260628-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→20→14→15
* 開始   : 2026-06-28 12:00:00 (UTC)
* 終了   : 2026-06-28 12:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host07-004 active_connections の推移](charts/EVT-20260628-host07-004.svg)

# イベントID( EVT-20260628-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→15→16→15→14→15→17
* 開始   : 2026-06-28 14:45:00 (UTC)
* 終了   : 2026-06-28 15:50:00 (UTC)
* 現象   : 2026-06-28 15:50:00 (UTC)を境に水準が 11.82から14.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.495σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.731, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-007 active_connections の推移](charts/EVT-20260628-host07-007.svg)

# イベントID( EVT-20260629-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→19→18→17→…→14→15→13→15
* 開始   : 2026-06-29 03:55:00 (UTC)
* 終了   : 2026-06-29 19:20:00 (UTC)
* 現象   : 2026-06-29 19:20:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.855, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-006 active_connections の推移](charts/EVT-20260629-host07-006.svg)

# イベントID( EVT-20260630-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→10→13→10→9
* 開始   : 2026-06-30 02:40:00 (UTC)
* 終了   : 2026-06-30 02:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-002 active_connections の推移](charts/EVT-20260630-host07-002.svg)

# イベントID( EVT-20260630-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→12→16→14→12
* 開始   : 2026-06-30 04:50:00 (UTC)
* 終了   : 2026-06-30 04:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-003 active_connections の推移](charts/EVT-20260630-host07-003.svg)

# イベントID( EVT-20260630-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→15→15
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-005 active_connections の推移](charts/EVT-20260630-host07-005.svg)

# イベントID( EVT-20260630-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→18→16
* 開始   : 2026-06-30 06:50:00 (UTC)
* 終了   : 2026-06-30 06:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-006 active_connections の推移](charts/EVT-20260630-host07-006.svg)

# イベントID( EVT-20260630-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 21→19→17→20→19
* 開始   : 2026-06-30 14:30:00 (UTC)
* 終了   : 2026-06-30 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host07-008 active_connections の推移](charts/EVT-20260630-host07-008.svg)

# イベントID( EVT-20260630-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→16→14
* 開始   : 2026-06-30 17:50:00 (UTC)
* 終了   : 2026-06-30 17:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.354σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host07-010 active_connections の推移](charts/EVT-20260630-host07-010.svg)

# イベントID( EVT-20260630-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→11→11
* 開始   : 2026-06-30 20:10:00 (UTC)
* 終了   : 2026-06-30 20:10:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6115(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.527σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-013 active_connections の推移](charts/EVT-20260630-host07-013.svg)

# イベントID( EVT-20260601-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→11→7→5→11→7→5→9→8
* 開始   : 2026-06-01 01:00:00 (UTC)
* 終了   : 2026-06-01 01:10:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→18→…→19→21→18→17
* 開始   : 2026-06-01 05:15:00 (UTC)
* 終了   : 2026-06-01 07:45:00 (UTC)
* 現象   : 2.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→18→16→20→18→19
* 開始   : 2026-06-01 07:25:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 20→23→21→23→21→23→21→19
* 開始   : 2026-06-01 09:10:00 (UTC)
* 終了   : 2026-06-01 09:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→12→15→16→12→15→14
* 開始   : 2026-06-01 18:20:00 (UTC)
* 終了   : 2026-06-01 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→18→17→20→17→20→17→19→17
* 開始   : 2026-06-02 16:00:00 (UTC)
* 終了   : 2026-06-02 16:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→16→19→19→19→20
* 開始   : 2026-06-02 16:40:00 (UTC)
* 終了   : 2026-06-02 18:05:00 (UTC)
* 現象   : 2026-06-02 18:05:00 (UTC)を境に水準が 15.08から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→17→17→13→16
* 開始   : 2026-06-02 18:05:00 (UTC)
* 終了   : 2026-06-02 19:10:00 (UTC)
* 現象   : 2026-06-02 19:10:00 (UTC)を境に水準が 14.92から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 8→10→13→9→12→13→9→12→11
* 開始   : 2026-06-03 02:20:00 (UTC)
* 終了   : 2026-06-03 02:30:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.891σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→9→13→11→14→13→11→14→13
* 開始   : 2026-06-03 03:35:00 (UTC)
* 終了   : 2026-06-03 03:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→13→17→13→…→17→13→17→16
* 開始   : 2026-06-03 05:50:00 (UTC)
* 終了   : 2026-06-03 06:30:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分
  - EVT-20260603-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→19→17→19→14→18
* 開始   : 2026-06-03 06:50:00 (UTC)
* 終了   : 2026-06-03 07:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→20→…→20→19→20→18
* 開始   : 2026-06-03 07:20:00 (UTC)
* 終了   : 2026-06-03 07:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→19→23→20→23→20→23→20→21
* 開始   : 2026-06-03 09:25:00 (UTC)
* 終了   : 2026-06-03 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 24→22→22→24→21→23
* 開始   : 2026-06-03 11:40:00 (UTC)
* 終了   : 2026-06-03 12:05:00 (UTC)
* 現象   : 2026-06-03 12:05:00 (UTC)を境に水準が 15.02から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→21→17→19→21→17→19→17
* 開始   : 2026-06-03 15:50:00 (UTC)
* 終了   : 2026-06-03 15:55:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→12→10→11→12→10→13
* 開始   : 2026-06-03 18:55:00 (UTC)
* 終了   : 2026-06-03 19:05:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→19→21→18→20→21→21→21→20
* 開始   : 2026-06-04 08:05:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 2026-06-04 09:05:00 (UTC)を境に水準が 14.98から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.942, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→23→22→23→19→21→23
* 開始   : 2026-06-04 08:15:00 (UTC)
* 終了   : 2026-06-04 09:45:00 (UTC)
* 現象   : 2026-06-04 09:45:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→18→19→21→18→19
* 開始   : 2026-06-04 14:45:00 (UTC)
* 終了   : 2026-06-04 14:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→17→15→16→…→16→14→19→20
* 開始   : 2026-06-04 16:50:00 (UTC)
* 終了   : 2026-06-04 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→10→11
* 開始   : 2026-06-04 22:45:00 (UTC)
* 終了   : 2026-06-04 22:55:00 (UTC)
* 現象   : 2026-06-04 22:55:00 (UTC)を境に水準が 14.96から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→13→14→14→13→15
* 開始   : 2026-06-05 04:05:00 (UTC)
* 終了   : 2026-06-05 04:40:00 (UTC)
* 現象   : 2026-06-05 04:40:00 (UTC)を境に水準が 14.88から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→15→13→12→15→13
* 開始   : 2026-06-05 04:50:00 (UTC)
* 終了   : 2026-06-05 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→17→12→16→…→16→18→16→17
* 開始   : 2026-06-05 06:35:00 (UTC)
* 終了   : 2026-06-05 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 20→19→21→18→18→20→21→19
* 開始   : 2026-06-05 07:50:00 (UTC)
* 終了   : 2026-06-05 08:25:00 (UTC)
* 現象   : 2026-06-05 08:25:00 (UTC)を境に水準が 14.94から14.3へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→22→24→20→…→20→18→20→21
* 開始   : 2026-06-05 15:05:00 (UTC)
* 終了   : 2026-06-05 15:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→16→18→19→16→18→17
* 開始   : 2026-06-05 16:00:00 (UTC)
* 終了   : 2026-06-05 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→12→15→12→15→12→13→12
* 開始   : 2026-06-05 18:25:00 (UTC)
* 終了   : 2026-06-05 18:35:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→15→14→18→15→16→16
* 開始   : 2026-06-07 09:05:00 (UTC)
* 終了   : 2026-06-07 09:55:00 (UTC)
* 現象   : 2026-06-07 09:55:00 (UTC)を境に水準が 11.78から12.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.731, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→17→17→17→14→17→16
* 開始   : 2026-06-07 11:15:00 (UTC)
* 終了   : 2026-06-07 12:15:00 (UTC)
* 現象   : 2026-06-07 12:15:00 (UTC)を境に水準が 11.83から13.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→12→8→11→…→11→14→9→10
* 開始   : 2026-06-07 18:30:00 (UTC)
* 終了   : 2026-06-07 18:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→6→9→6→9→7
* 開始   : 2026-06-07 22:45:00 (UTC)
* 終了   : 2026-06-07 22:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→11→11→10→13
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 02:20:00 (UTC)
* 現象   : 2026-06-08 02:20:00 (UTC)を境に水準が 11.79から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→18→14→18→14→18→16→17
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→16→17→20→16→19
* 開始   : 2026-06-09 07:20:00 (UTC)
* 終了   : 2026-06-09 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→19→22→20→20→21
* 開始   : 2026-06-09 08:05:00 (UTC)
* 終了   : 2026-06-09 08:30:00 (UTC)
* 現象   : 2026-06-09 08:30:00 (UTC)を境に水準が 15.01から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 21→22→24→25→22→24→25→22→23
* 開始   : 2026-06-09 10:55:00 (UTC)
* 終了   : 2026-06-09 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→17→12→13→12→13→12→15→16
* 開始   : 2026-06-09 18:15:00 (UTC)
* 終了   : 2026-06-09 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→7→11→12→7→11→12→7→8
* 開始   : 2026-06-10 01:20:00 (UTC)
* 終了   : 2026-06-10 01:25:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→8→5→11→8→5→11
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 02:25:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→12→14→11→14→11→14→12
* 開始   : 2026-06-10 03:50:00 (UTC)
* 終了   : 2026-06-10 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→19→15→14→15→14→17→16
* 開始   : 2026-06-10 16:50:00 (UTC)
* 終了   : 2026-06-10 17:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→12→15→17→12→15→16
* 開始   : 2026-06-10 18:15:00 (UTC)
* 終了   : 2026-06-10 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→13→14→12→11→13→15
* 開始   : 2026-06-10 18:45:00 (UTC)
* 終了   : 2026-06-10 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host01-016 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260610-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→9→9→9→8
* 開始   : 2026-06-11 00:50:00 (UTC)
* 終了   : 2026-06-11 01:10:00 (UTC)
* 現象   : 2026-06-11 01:10:00 (UTC)を境に水準が 15から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.672, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→9→12→11→9→12→11
* 開始   : 2026-06-11 03:15:00 (UTC)
* 終了   : 2026-06-11 03:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260611-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→8→11→15→8→11→15→11→10
* 開始   : 2026-06-11 04:00:00 (UTC)
* 終了   : 2026-06-11 04:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→13→12→15→13→11
* 開始   : 2026-06-11 04:55:00 (UTC)
* 終了   : 2026-06-11 05:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→14→13→14→17→14→13→14→18
* 開始   : 2026-06-11 17:30:00 (UTC)
* 終了   : 2026-06-11 17:35:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→12→13→13→14→13
* 開始   : 2026-06-12 04:05:00 (UTC)
* 終了   : 2026-06-12 04:40:00 (UTC)
* 現象   : 2026-06-12 04:40:00 (UTC)を境に水準が 15.06から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→19→20→19→20→18→19
* 開始   : 2026-06-12 07:35:00 (UTC)
* 終了   : 2026-06-12 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260612-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 23→23→25→22→23→23→22→23→23
* 開始   : 2026-06-12 13:00:00 (UTC)
* 終了   : 2026-06-12 13:40:00 (UTC)
* 現象   : 2026-06-12 13:40:00 (UTC)を境に水準が 15.14から13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.416, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 7→6→11→5→…→5→10→11→7
* 開始   : 2026-06-12 23:45:00 (UTC)
* 終了   : 2026-06-13 00:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→12→7→10→…→10→14→13→10
* 開始   : 2026-06-13 04:20:00 (UTC)
* 終了   : 2026-06-13 04:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260613-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host07-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→10→7→9→…→7→9→10→9
* 開始   : 2026-06-13 19:45:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10 分
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260613-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→9→12→10→9→8
* 開始   : 2026-06-14 01:25:00 (UTC)
* 終了   : 2026-06-14 01:50:00 (UTC)
* 現象   : 2026-06-14 01:50:00 (UTC)を境に水準が 11.85から11.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→11→10→…→11→10→14→13
* 開始   : 2026-06-14 16:00:00 (UTC)
* 終了   : 2026-06-14 16:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→13→10→13
* 開始   : 2026-06-14 17:05:00 (UTC)
* 終了   : 2026-06-14 17:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→8→8→10→10→9→9→10
* 開始   : 2026-06-14 21:25:00 (UTC)
* 終了   : 2026-06-14 22:15:00 (UTC)
* 現象   : 2026-06-14 22:15:00 (UTC)を境に水準が 11.85から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.709, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→13→11→11
* 開始   : 2026-06-15 20:40:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 14.82から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.258, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→14→16→15→14→16→15
* 開始   : 2026-06-16 05:05:00 (UTC)
* 終了   : 2026-06-16 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→15→16→14→15
* 開始   : 2026-06-16 05:25:00 (UTC)
* 終了   : 2026-06-16 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→17→16→19→17
* 開始   : 2026-06-16 07:05:00 (UTC)
* 終了   : 2026-06-16 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 22→23→24→22→24→23
* 開始   : 2026-06-16 11:40:00 (UTC)
* 終了   : 2026-06-16 12:05:00 (UTC)
* 現象   : 2026-06-16 12:05:00 (UTC)を境に水準が 14.99から15.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.387, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→17→21→17→21→17→19→18
* 開始   : 2026-06-16 15:35:00 (UTC)
* 終了   : 2026-06-16 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→13→15→…→15→12→14→15
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→7→10→11→9→10→11→11→11
* 開始   : 2026-06-17 02:10:00 (UTC)
* 終了   : 2026-06-17 02:50:00 (UTC)
* 現象   : 2026-06-17 02:50:00 (UTC)を境に水準が 14.84から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.416, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→9→12→10→9→12→10
* 開始   : 2026-06-17 02:25:00 (UTC)
* 終了   : 2026-06-17 02:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→13→16→13→16
* 開始   : 2026-06-17 05:30:00 (UTC)
* 終了   : 2026-06-17 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→17→19→16→17→19→16→17
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→21→24→20→…→20→18→19→22
* 開始   : 2026-06-17 10:20:00 (UTC)
* 終了   : 2026-06-17 10:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260617-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→15→14→15→19→15→14→15→17
* 開始   : 2026-06-17 16:40:00 (UTC)
* 終了   : 2026-06-17 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→7→6→12→…→6→12→9→11
* 開始   : 2026-06-17 21:50:00 (UTC)
* 終了   : 2026-06-17 21:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→8→…→8→5→7→8
* 開始   : 2026-06-17 22:25:00 (UTC)
* 終了   : 2026-06-17 22:35:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→19→14→16→19→14→16
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:10:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260618-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→12→14→16→12→14→16
* 開始   : 2026-06-18 18:25:00 (UTC)
* 終了   : 2026-06-18 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→13→13→11→13→11→11→12
* 開始   : 2026-06-18 20:10:00 (UTC)
* 終了   : 2026-06-18 20:45:00 (UTC)
* 現象   : 2026-06-18 20:45:00 (UTC)を境に水準が 15.1から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→12→9→12→10→11→12
* 開始   : 2026-06-18 21:00:00 (UTC)
* 終了   : 2026-06-18 21:30:00 (UTC)
* 現象   : 2026-06-18 21:30:00 (UTC)を境に水準が 14.8から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→10→11→7→…→7→5→8→6
* 開始   : 2026-06-19 01:50:00 (UTC)
* 終了   : 2026-06-19 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→19→20→17→…→17→21→20→18
* 開始   : 2026-06-19 07:50:00 (UTC)
* 終了   : 2026-06-19 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→19→23→22→19→23→22→21
* 開始   : 2026-06-19 09:40:00 (UTC)
* 終了   : 2026-06-19 09:45:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.216倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.843σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 24→22→23→24→25→23→24
* 開始   : 2026-06-19 12:10:00 (UTC)
* 終了   : 2026-06-19 12:40:00 (UTC)
* 現象   : 2026-06-19 12:40:00 (UTC)を境に水準が 15.06から13.25へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→20→22→21→21→20→19→21→21
* 開始   : 2026-06-19 14:45:00 (UTC)
* 終了   : 2026-06-19 15:45:00 (UTC)
* 現象   : 2026-06-19 15:45:00 (UTC)を境に水準が 14.96から12.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→11→10→10→10→9→8→10→9
* 開始   : 2026-06-19 22:30:00 (UTC)
* 終了   : 2026-06-19 23:10:00 (UTC)
* 現象   : 2026-06-19 23:10:00 (UTC)を境に水準が 14.94から11.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.009, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→7→11→10→7→11→10→7
* 開始   : 2026-06-20 01:45:00 (UTC)
* 終了   : 2026-06-20 01:50:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→8→10→…→7→10→7→10
* 開始   : 2026-06-20 19:45:00 (UTC)
* 終了   : 2026-06-20 20:10:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.678, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 20 分

![EVT-20260620-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→8→10→8→11→8→9
* 開始   : 2026-06-21 01:05:00 (UTC)
* 終了   : 2026-06-21 02:00:00 (UTC)
* 現象   : 2026-06-21 02:00:00 (UTC)を境に水準が 11.87から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→13→10→11→13→10
* 開始   : 2026-06-21 04:45:00 (UTC)
* 終了   : 2026-06-21 04:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→16→15→12→16→13
* 開始   : 2026-06-21 06:40:00 (UTC)
* 終了   : 2026-06-21 06:50:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→16→13→15→16
* 開始   : 2026-06-21 08:05:00 (UTC)
* 終了   : 2026-06-21 08:30:00 (UTC)
* 現象   : 2026-06-21 08:30:00 (UTC)を境に水準が 11.71から12.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→16→15→16→17→17→19→17→16
* 開始   : 2026-06-21 13:00:00 (UTC)
* 終了   : 2026-06-21 13:45:00 (UTC)
* 現象   : 2026-06-21 13:45:00 (UTC)を境に水準が 11.85から13.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→18→15→18→17→17→15→15→17
* 開始   : 2026-06-21 13:15:00 (UTC)
* 終了   : 2026-06-21 14:05:00 (UTC)
* 現象   : 2026-06-21 14:05:00 (UTC)を境に水準が 11.78から13.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→8→7→9→7→9→7→10
* 開始   : 2026-06-21 20:55:00 (UTC)
* 終了   : 2026-06-21 21:35:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260621-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260621-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→12→8→12→11→9
* 開始   : 2026-06-23 02:25:00 (UTC)
* 終了   : 2026-06-23 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→20→21→18→20→21→18→19
* 開始   : 2026-06-23 08:05:00 (UTC)
* 終了   : 2026-06-23 08:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→20→22→23→…→22→23→19→22
* 開始   : 2026-06-23 09:20:00 (UTC)
* 終了   : 2026-06-23 09:25:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 23→19→24→21→…→21→18→21→20
* 開始   : 2026-06-23 13:55:00 (UTC)
* 終了   : 2026-06-23 14:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→18→18
* 開始   : 2026-06-23 17:15:00 (UTC)
* 終了   : 2026-06-23 17:25:00 (UTC)
* 現象   : 2026-06-23 17:25:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→11→14→11→…→15→10→14→13
* 開始   : 2026-06-23 18:45:00 (UTC)
* 終了   : 2026-06-23 19:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260623-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→13→11→13→11→13→11→13→11
* 開始   : 2026-06-23 18:50:00 (UTC)
* 終了   : 2026-06-23 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.66σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→15→…→16→17→15→16
* 開始   : 2026-06-24 05:45:00 (UTC)
* 終了   : 2026-06-24 06:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.785σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260624-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→19→18→17→18→20
* 開始   : 2026-06-24 06:45:00 (UTC)
* 終了   : 2026-06-24 07:10:00 (UTC)
* 現象   : 2026-06-24 07:10:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→16→14→18→16→14→18→16
* 開始   : 2026-06-24 17:20:00 (UTC)
* 終了   : 2026-06-24 17:25:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→11→12→9→12
* 開始   : 2026-06-24 20:45:00 (UTC)
* 終了   : 2026-06-24 21:15:00 (UTC)
* 現象   : 2026-06-24 21:15:00 (UTC)を境に水準が 15.01から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→9→7→9→8
* 開始   : 2026-06-24 21:05:00 (UTC)
* 終了   : 2026-06-24 21:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.582σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→6→11→7→6→11→7→10
* 開始   : 2026-06-25 01:35:00 (UTC)
* 終了   : 2026-06-25 01:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→12→9→6→12→9→6→8
* 開始   : 2026-06-25 01:35:00 (UTC)
* 終了   : 2026-06-25 01:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→17→21→18→22→21→18→22→19
* 開始   : 2026-06-25 08:30:00 (UTC)
* 終了   : 2026-06-25 09:10:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260625-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260625-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→13→15→16→13→15→17
* 開始   : 2026-06-25 17:35:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7685(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.727σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 20 分
  - EVT-20260625-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260625-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260625-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→15→12→14→12→14→12→13
* 開始   : 2026-06-25 18:35:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→13→…→14→17→15→16
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 06:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260626-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→16→18→16→14
* 開始   : 2026-06-26 06:15:00 (UTC)
* 終了   : 2026-06-26 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→21→24→22→24→22→24→21→22
* 開始   : 2026-06-26 10:25:00 (UTC)
* 終了   : 2026-06-26 10:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→16→18→15→16→18
* 開始   : 2026-06-26 17:05:00 (UTC)
* 終了   : 2026-06-26 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→11→11
* 開始   : 2026-06-26 22:00:00 (UTC)
* 終了   : 2026-06-26 22:10:00 (UTC)
* 現象   : 2026-06-26 22:10:00 (UTC)を境に水準が 14.94から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.193, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→10→11→12→13
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 05:20:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.023, 限界=2.646)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 40 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 30 分

![EVT-20260627-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→11→…→9→11→9→10
* 開始   : 2026-06-27 20:10:00 (UTC)
* 終了   : 2026-06-27 20:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260627-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→12→10→12→10→12→10→9
* 開始   : 2026-06-28 03:40:00 (UTC)
* 終了   : 2026-06-28 03:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 7→11→13→8→13→8→13→10→11
* 開始   : 2026-06-28 04:15:00 (UTC)
* 終了   : 2026-06-28 04:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→12→12→13→12→12
* 開始   : 2026-06-28 05:40:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 2026-06-28 06:05:00 (UTC)を境に水準が 11.79から12.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→15→14→13→14→15→14→16→16
* 開始   : 2026-06-28 13:45:00 (UTC)
* 終了   : 2026-06-28 15:05:00 (UTC)
* 現象   : 2026-06-28 15:05:00 (UTC)を境に水準が 11.71から14.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.683, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→13→18→13→…→13→12→17→15
* 開始   : 2026-06-28 14:30:00 (UTC)
* 終了   : 2026-06-28 14:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→7→8→9→9
* 開始   : 2026-06-28 23:20:00 (UTC)
* 終了   : 2026-06-28 23:40:00 (UTC)
* 現象   : 2026-06-28 23:40:00 (UTC)を境に水準が 11.9から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→12→7→11→12→12→11
* 開始   : 2026-06-30 02:25:00 (UTC)
* 終了   : 2026-06-30 03:15:00 (UTC)
* 現象   : 2026-06-30 03:15:00 (UTC)を境に水準が 14.83から15.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.953, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→15→…→15→17→14→15
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260630-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 22→21→18→25→20→21→18→25→20
* 開始   : 2026-06-30 12:15:00 (UTC)
* 終了   : 2026-06-30 12:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.8308(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→20→15→18→20→15→18
* 開始   : 2026-06-30 16:20:00 (UTC)
* 終了   : 2026-06-30 16:25:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.786σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→15→10→14→15→10→14→13
* 開始   : 2026-06-30 19:20:00 (UTC)
* 終了   : 2026-06-30 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host05-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→12→9→11→12→9→11
* 開始   : 2026-06-30 20:05:00 (UTC)
* 終了   : 2026-06-30 20:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host07-012 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
