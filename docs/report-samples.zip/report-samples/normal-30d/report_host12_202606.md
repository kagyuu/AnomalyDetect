# host12 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host12 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 309 (SEVERE: 27, FATAL: 125, WARN: 157, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 27 | 125 | 157 | 309 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→15→…→16→14→13→12
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.92から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.778, 限界=2.677)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.499σ 外れた (平常値=21.46)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.467, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-001 active_connections の推移](charts/EVT-20260608-host12-001.svg)

# イベントID( EVT-20260608-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→17→14→13→…→12→14→12→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.83から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.932, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-002 active_connections の推移](charts/EVT-20260608-host12-002.svg)

# イベントID( EVT-20260608-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→15→16→15→…→12→16→11→14
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.91から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.348σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.874, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-003 active_connections の推移](charts/EVT-20260608-host12-003.svg)

# イベントID( EVT-20260608-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→13→16→17→…→12→14→13→12
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 21:30:00 (UTC)
* 現象   : 2026-06-08 21:30:00 (UTC)を境に水準が 11.82から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.351σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.831, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-004 active_connections の推移](charts/EVT-20260608-host12-004.svg)

# イベントID( EVT-20260608-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→14→…→12→14→11→12
* 開始   : 2026-06-08 03:10:00 (UTC)
* 終了   : 2026-06-08 19:10:00 (UTC)
* 現象   : 2026-06-08 19:10:00 (UTC)を境に水準が 11.94から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.66)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-005 active_connections の推移](charts/EVT-20260608-host12-005.svg)

# イベントID( EVT-20260608-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→17→16→…→14→15→14→13
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.74, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-006 active_connections の推移](charts/EVT-20260608-host12-006.svg)

# イベントID( EVT-20260611-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→20→19
* 開始   : 2026-06-11 07:20:00 (UTC)
* 終了   : 2026-06-11 07:30:00 (UTC)
* 現象   : 2026-06-11 07:30:00 (UTC)を境に水準が 14.94から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-007 active_connections の推移](charts/EVT-20260611-host12-007.svg)

# イベントID( EVT-20260612-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→11→11→14
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 03:45:00 (UTC)
* 現象   : 2026-06-12 03:45:00 (UTC)を境に水準が 14.94から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.02σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host12-001 active_connections の推移](charts/EVT-20260612-host12-001.svg)

# イベントID( EVT-20260613-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→11→10→12→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 20:15:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.677)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.05σ 外れた (平常値=9.468)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 14.5 時間

![EVT-20260613-host12-003 active_connections の推移](charts/EVT-20260613-host12-003.svg)

# イベントID( EVT-20260615-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→13→16→14→…→13→15→13→15
* 開始   : 2026-06-15 02:15:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.261σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.833, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-002 active_connections の推移](charts/EVT-20260615-host12-002.svg)

# イベントID( EVT-20260615-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→16→…→13→15→11→14
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.93から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.248, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-003 active_connections の推移](charts/EVT-20260615-host12-003.svg)

# イベントID( EVT-20260615-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→13→17→14→…→12→13→11→10
* 開始   : 2026-06-15 02:45:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.81から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.458, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-004 active_connections の推移](charts/EVT-20260615-host12-004.svg)

# イベントID( EVT-20260615-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→13→16→15→…→15→12→11→14
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 11.78から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.067, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-005 active_connections の推移](charts/EVT-20260615-host12-005.svg)

# イベントID( EVT-20260615-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→16→12→16→…→14→16→13→12
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 11.84から15.2へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.067, 限界=2.66)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-007 active_connections の推移](charts/EVT-20260615-host12-007.svg)

# イベントID( EVT-20260616-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→15→12→12→12→11→13→12
* 開始   : 2026-06-16 19:05:00 (UTC)
* 終了   : 2026-06-16 20:30:00 (UTC)
* 現象   : 2026-06-16 20:30:00 (UTC)を境に水準が 14.79から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host12-009 active_connections の推移](charts/EVT-20260616-host12-009.svg)

# イベントID( EVT-20260617-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→7→9→8→9→10→7→8→10
* 開始   : 2026-06-17 21:40:00 (UTC)
* 終了   : 2026-06-18 01:10:00 (UTC)
* 現象   : 2026-06-18 01:10:00 (UTC)を境に水準が 14.88から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.425σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.016, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host12-011 active_connections の推移](charts/EVT-20260617-host12-011.svg)

# イベントID( EVT-20260618-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→14→15→13→13→13→15
* 開始   : 2026-06-18 18:00:00 (UTC)
* 終了   : 2026-06-18 19:30:00 (UTC)
* 現象   : 2026-06-18 19:30:00 (UTC)を境に水準が 15.03から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.06σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.735, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-012 active_connections の推移](charts/EVT-20260618-host12-012.svg)

# イベントID( EVT-20260619-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→13→9→14→14→12→11→13→12
* 開始   : 2026-06-19 19:20:00 (UTC)
* 終了   : 2026-06-19 20:05:00 (UTC)
* 現象   : 2026-06-19 20:05:00 (UTC)を境に水準が 14.96から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.823, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-010 active_connections の推移](charts/EVT-20260619-host12-010.svg)

# イベントID( EVT-20260622-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→16→…→12→13→12→13
* 開始   : 2026-06-22 00:40:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.655, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-001 active_connections の推移](charts/EVT-20260622-host12-001.svg)

# イベントID( EVT-20260622-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→14→…→15→16→15→17
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.935, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-003 active_connections の推移](charts/EVT-20260622-host12-003.svg)

# イベントID( EVT-20260622-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→14→…→15→13→14→12
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.95から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.66)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-005 active_connections の推移](charts/EVT-20260622-host12-005.svg)

# イベントID( EVT-20260622-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→13→15→13→12
* 開始   : 2026-06-22 03:40:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.89から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.016σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.791, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.641, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-006 active_connections の推移](charts/EVT-20260622-host12-006.svg)

# イベントID( EVT-20260622-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→18→…→12→13→12→13
* 開始   : 2026-06-22 03:45:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 12から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.727σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.969, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-007 active_connections の推移](charts/EVT-20260622-host12-007.svg)

# イベントID( EVT-20260629-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→16→…→14→12→14→12
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 19:45:00 (UTC)
* 現象   : 2026-06-29 19:45:00 (UTC)を境に水準が 11.85から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.66)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-002 active_connections の推移](charts/EVT-20260629-host12-002.svg)

# イベントID( EVT-20260629-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→…→12→15→14→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:35:00 (UTC)
* 現象   : 2026-06-29 21:35:00 (UTC)を境に水準が 11.87から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-003 active_connections の推移](charts/EVT-20260629-host12-003.svg)

# イベントID( EVT-20260629-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→14→17→15→…→14→13→12→15
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.75から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.851, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-004 active_connections の推移](charts/EVT-20260629-host12-004.svg)

# イベントID( EVT-20260629-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→17→…→17→15→14→13
* 開始   : 2026-06-29 03:45:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.866, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-006 active_connections の推移](charts/EVT-20260629-host12-006.svg)

# イベントID( EVT-20260601-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→13→18→15→15
* 開始   : 2026-06-01 05:35:00 (UTC)
* 終了   : 2026-06-01 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.412倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.652σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host12-002 active_connections の推移](charts/EVT-20260601-host12-002.svg)

# イベントID( EVT-20260601-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→17→21→16→16
* 開始   : 2026-06-01 06:50:00 (UTC)
* 終了   : 2026-06-01 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.884σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host12-003 active_connections の推移](charts/EVT-20260601-host12-003.svg)

# イベントID( EVT-20260601-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→17→21→16→19
* 開始   : 2026-06-01 07:30:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-005 active_connections の推移](charts/EVT-20260601-host12-005.svg)

# イベントID( EVT-20260601-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 20→20→24→21→18
* 開始   : 2026-06-01 09:15:00 (UTC)
* 終了   : 2026-06-01 09:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host12-006 active_connections の推移](charts/EVT-20260601-host12-006.svg)

# イベントID( EVT-20260601-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 20→19→16→21→18
* 開始   : 2026-06-01 15:15:00 (UTC)
* 終了   : 2026-06-01 15:15:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260601-host12-007 active_connections の推移](charts/EVT-20260601-host12-007.svg)

# イベントID( EVT-20260601-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→13→21→18→17→13→21→18→17
* 開始   : 2026-06-01 17:05:00 (UTC)
* 終了   : 2026-06-01 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-008 active_connections の推移](charts/EVT-20260601-host12-008.svg)

# イベントID( EVT-20260601-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→17→…→11→15→12→13
* 開始   : 2026-06-01 18:10:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260601-host12-009 active_connections の推移](charts/EVT-20260601-host12-009.svg)

# イベントID( EVT-20260601-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→9→11→9
* 開始   : 2026-06-01 19:25:00 (UTC)
* 終了   : 2026-06-01 20:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 25 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260601-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260601-host12-012 active_connections の推移](charts/EVT-20260601-host12-012.svg)

# イベントID( EVT-20260602-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→20→15→18→18
* 開始   : 2026-06-02 16:00:00 (UTC)
* 終了   : 2026-06-02 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-002 active_connections の推移](charts/EVT-20260602-host12-002.svg)

# イベントID( EVT-20260602-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→12→…→12→8→12→10
* 開始   : 2026-06-02 19:55:00 (UTC)
* 終了   : 2026-06-02 20:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260602-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-004 active_connections の推移](charts/EVT-20260602-host12-004.svg)

# イベントID( EVT-20260602-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→6→11→10
* 開始   : 2026-06-02 21:05:00 (UTC)
* 終了   : 2026-06-02 21:05:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.5373(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-005 active_connections の推移](charts/EVT-20260602-host12-005.svg)

# イベントID( EVT-20260603-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→15→15
* 開始   : 2026-06-03 05:15:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-003 active_connections の推移](charts/EVT-20260603-host12-003.svg)

# イベントID( EVT-20260603-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→19→16→22→19
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 15:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.174σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host02-009 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260603-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-005 active_connections の推移](charts/EVT-20260603-host12-005.svg)

# イベントID( EVT-20260603-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→14→10→15→13
* 開始   : 2026-06-03 18:55:00 (UTC)
* 終了   : 2026-06-03 18:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host12-009 active_connections の推移](charts/EVT-20260603-host12-009.svg)

# イベントID( EVT-20260603-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→10→10
* 開始   : 2026-06-03 21:05:00 (UTC)
* 終了   : 2026-06-03 21:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host12-011 active_connections の推移](charts/EVT-20260603-host12-011.svg)

# イベントID( EVT-20260603-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→9→7
* 開始   : 2026-06-03 22:00:00 (UTC)
* 終了   : 2026-06-03 22:00:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260603-host12-012 active_connections の推移](charts/EVT-20260603-host12-012.svg)

# イベントID( EVT-20260604-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→8→11
* 開始   : 2026-06-04 02:45:00 (UTC)
* 終了   : 2026-06-04 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→11→12
* 開始   : 2026-06-04 03:15:00 (UTC)
* 終了   : 2026-06-04 03:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host12-002 active_connections の推移](charts/EVT-20260604-host12-002.svg)

# イベントID( EVT-20260604-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→10→14→11→11
* 開始   : 2026-06-04 03:50:00 (UTC)
* 終了   : 2026-06-04 03:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.225σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host12-003 active_connections の推移](charts/EVT-20260604-host12-003.svg)

# イベントID( EVT-20260604-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→18→21→19→19
* 開始   : 2026-06-04 07:25:00 (UTC)
* 終了   : 2026-06-04 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→10→12→9→10→12→9→11
* 開始   : 2026-06-04 18:55:00 (UTC)
* 終了   : 2026-06-04 19:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.656σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260604-host12-012 active_connections の推移](charts/EVT-20260604-host12-012.svg)

# イベントID( EVT-20260605-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→19→22→16→19
* 開始   : 2026-06-05 07:25:00 (UTC)
* 終了   : 2026-06-05 07:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host12-007 active_connections の推移](charts/EVT-20260605-host12-007.svg)

# イベントID( EVT-20260605-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→25→22→22
* 開始   : 2026-06-05 09:40:00 (UTC)
* 終了   : 2026-06-05 09:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.255倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-008 active_connections の推移](charts/EVT-20260605-host12-008.svg)

# イベントID( EVT-20260605-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→12→9→12→12
* 開始   : 2026-06-05 19:30:00 (UTC)
* 終了   : 2026-06-05 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-082 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-084 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host12-015 active_connections の推移](charts/EVT-20260605-host12-015.svg)

# イベントID( EVT-20260606-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 7→9→3→8→11→3→8→11→9
* 開始   : 2026-06-06 02:00:00 (UTC)
* 終了   : 2026-06-06 02:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.3462(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.926σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260606-host12-001 active_connections の推移](charts/EVT-20260606-host12-001.svg)

# イベントID( EVT-20260606-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→10→…→14→12→14→12
* 開始   : 2026-06-06 04:45:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.055σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260606-host12-002 active_connections の推移](charts/EVT-20260606-host12-002.svg)

# イベントID( EVT-20260606-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→14→12→14→…→12→11→10→11
* 開始   : 2026-06-06 04:50:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.696, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260606-host12-003 active_connections の推移](charts/EVT-20260606-host12-003.svg)

# イベントID( EVT-20260606-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→12→…→10→16→11→12
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.313, 限界=2.66)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host12-004 active_connections の推移](charts/EVT-20260606-host12-004.svg)

# イベントID( EVT-20260606-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→12→…→12→11→13→10
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host12-005 active_connections の推移](charts/EVT-20260606-host12-005.svg)

# イベントID( EVT-20260606-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→13→9→11→…→14→12→13→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host12-006 active_connections の推移](charts/EVT-20260606-host12-006.svg)

# イベントID( EVT-20260606-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→13→…→11→13→12→10
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.542, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host12-007 active_connections の推移](charts/EVT-20260606-host12-007.svg)

# イベントID( EVT-20260606-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→9→5→6→8→9→5→6→8
* 開始   : 2026-06-06 21:45:00 (UTC)
* 終了   : 2026-06-06 21:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host12-008 active_connections の推移](charts/EVT-20260606-host12-008.svg)

# イベントID( EVT-20260609-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→20→17→20→22
* 開始   : 2026-06-09 14:20:00 (UTC)
* 終了   : 2026-06-09 14:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-003 active_connections の推移](charts/EVT-20260609-host12-003.svg)

# イベントID( EVT-20260609-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→11→9→13→12
* 開始   : 2026-06-09 19:30:00 (UTC)
* 終了   : 2026-06-09 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host12-005 active_connections の推移](charts/EVT-20260609-host12-005.svg)

# イベントID( EVT-20260609-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→11→7→11→12
* 開始   : 2026-06-09 20:25:00 (UTC)
* 終了   : 2026-06-09 20:25:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host12-006 active_connections の推移](charts/EVT-20260609-host12-006.svg)

# イベントID( EVT-20260609-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→11→6→10→11
* 開始   : 2026-06-09 21:25:00 (UTC)
* 終了   : 2026-06-09 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host12-008 active_connections の推移](charts/EVT-20260609-host12-008.svg)

# イベントID( EVT-20260610-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→14→19→16→14
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.416倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.901σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-003 active_connections の推移](charts/EVT-20260610-host12-003.svg)

# イベントID( EVT-20260610-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→22→21→20→22→21→19
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260610-host12-006 active_connections の推移](charts/EVT-20260610-host12-006.svg)

# イベントID( EVT-20260610-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→19→23→18→21
* 開始   : 2026-06-10 08:55:00 (UTC)
* 終了   : 2026-06-10 08:55:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 21→22→17→21→18→17→21→18→21
* 開始   : 2026-06-10 13:55:00 (UTC)
* 終了   : 2026-06-10 14:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260610-host12-009 active_connections の推移](charts/EVT-20260610-host12-009.svg)

# イベントID( EVT-20260610-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→7→…→9→7→10→12
* 開始   : 2026-06-10 19:55:00 (UTC)
* 終了   : 2026-06-10 20:00:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host12-013 active_connections の推移](charts/EVT-20260610-host12-013.svg)

# イベントID( EVT-20260611-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→10→16→15→10→16→15
* 開始   : 2026-06-11 05:10:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.29σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260611-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-004 active_connections の推移](charts/EVT-20260611-host12-004.svg)

# イベントID( EVT-20260611-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→21→25→21→23
* 開始   : 2026-06-11 10:25:00 (UTC)
* 終了   : 2026-06-11 10:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 23→18→19→24→…→19→24→18→20
* 開始   : 2026-06-11 11:45:00 (UTC)
* 終了   : 2026-06-11 12:55:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host12-011 active_connections の推移](charts/EVT-20260611-host12-011.svg)

# イベントID( EVT-20260611-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→12→8→13→11
* 開始   : 2026-06-11 19:35:00 (UTC)
* 終了   : 2026-06-11 19:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-015 active_connections の推移](charts/EVT-20260611-host12-015.svg)

# イベントID( EVT-20260611-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→12→7→9→9
* 開始   : 2026-06-11 21:05:00 (UTC)
* 終了   : 2026-06-11 21:05:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-016 active_connections の推移](charts/EVT-20260611-host12-016.svg)

# イベントID( EVT-20260612-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→21→26→21→22
* 開始   : 2026-06-12 10:35:00 (UTC)
* 終了   : 2026-06-12 10:35:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host12-005 active_connections の推移](charts/EVT-20260612-host12-005.svg)

# イベントID( EVT-20260612-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→21→27→22→22
* 開始   : 2026-06-12 12:55:00 (UTC)
* 終了   : 2026-06-12 12:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.237倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-007 active_connections の推移](charts/EVT-20260612-host12-007.svg)

# イベントID( EVT-20260612-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→19→19→19→19→17→16→16→20
* 開始   : 2026-06-12 15:40:00 (UTC)
* 終了   : 2026-06-12 17:20:00 (UTC)
* 現象   : 2026-06-12 17:20:00 (UTC)を境に水準が 14.94から12.26へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.448σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.103, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host12-008 active_connections の推移](charts/EVT-20260612-host12-008.svg)

# イベントID( EVT-20260613-host12-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→9→10→12→…→10→12→13→12
* 開始   : 2026-06-13 04:50:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.048, 限界=2.66)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host12-001 active_connections の推移](charts/EVT-20260613-host12-001.svg)

# イベントID( EVT-20260613-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→11→12→10→11
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.419σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.887, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host12-002 active_connections の推移](charts/EVT-20260613-host12-002.svg)

# イベントID( EVT-20260613-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→14→…→12→11→12→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.349σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.971, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 14.1 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host12-004 active_connections の推移](charts/EVT-20260613-host12-004.svg)

# イベントID( EVT-20260613-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→12→…→11→10→13→12
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.059σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host12-005 active_connections の推移](charts/EVT-20260613-host12-005.svg)

# イベントID( EVT-20260613-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→9→12→13→9
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.931, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host12-006 active_connections の推移](charts/EVT-20260613-host12-006.svg)

# イベントID( EVT-20260614-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→12→16→12→10
* 開始   : 2026-06-14 18:55:00 (UTC)
* 終了   : 2026-06-14 18:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host12-005 active_connections の推移](charts/EVT-20260614-host12-005.svg)

# イベントID( EVT-20260615-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→8→4→7→8
* 開始   : 2026-06-15 00:35:00 (UTC)
* 終了   : 2026-06-15 00:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.304σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260615-host12-001 active_connections の推移](charts/EVT-20260615-host12-001.svg)

# イベントID( EVT-20260615-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→20→…→14→15→14→13
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.735, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-006 active_connections の推移](charts/EVT-20260615-host12-006.svg)

# イベントID( EVT-20260616-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→9→13→9→9
* 開始   : 2026-06-16 02:45:00 (UTC)
* 終了   : 2026-06-16 02:45:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.29σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host12-001 active_connections の推移](charts/EVT-20260616-host12-001.svg)

# イベントID( EVT-20260616-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→16→14→16→14→16→13
* 開始   : 2026-06-16 05:05:00 (UTC)
* 終了   : 2026-06-16 05:15:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-004 active_connections の推移](charts/EVT-20260616-host12-004.svg)

# イベントID( EVT-20260616-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→13→8→10→13
* 開始   : 2026-06-16 19:55:00 (UTC)
* 終了   : 2026-06-16 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.467σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host12-011 active_connections の推移](charts/EVT-20260616-host12-011.svg)

# イベントID( EVT-20260616-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→11→6→10→10
* 開始   : 2026-06-16 21:00:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.585σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-012 active_connections の推移](charts/EVT-20260616-host12-012.svg)

# イベントID( EVT-20260616-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 8→9→4→9→10
* 開始   : 2026-06-16 22:55:00 (UTC)
* 終了   : 2026-06-16 22:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→12→14→10→10
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-002 active_connections の推移](charts/EVT-20260617-host12-002.svg)

# イベントID( EVT-20260617-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→15→18→14→14
* 開始   : 2026-06-17 05:40:00 (UTC)
* 終了   : 2026-06-17 05:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-003 active_connections の推移](charts/EVT-20260617-host12-003.svg)

# イベントID( EVT-20260617-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→13→…→13→10→15→14
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host12-009 active_connections の推移](charts/EVT-20260617-host12-009.svg)

# イベントID( EVT-20260617-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→7→12→11
* 開始   : 2026-06-17 20:20:00 (UTC)
* 終了   : 2026-06-17 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.826σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-010 active_connections の推移](charts/EVT-20260617-host12-010.svg)

# イベントID( EVT-20260618-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→12→11→11→9→15
* 開始   : 2026-06-18 02:50:00 (UTC)
* 終了   : 2026-06-18 03:15:00 (UTC)
* 現象   : 2026-06-18 03:15:00 (UTC)を境に水準が 14.97から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-001 active_connections の推移](charts/EVT-20260618-host12-001.svg)

# イベントID( EVT-20260618-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→15→21→15→17
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.44倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host12-005 active_connections の推移](charts/EVT-20260618-host12-005.svg)

# イベントID( EVT-20260618-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 20→17→23→19→19
* 開始   : 2026-06-18 08:05:00 (UTC)
* 終了   : 2026-06-18 08:05:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.525σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host12-006 active_connections の推移](charts/EVT-20260618-host12-006.svg)

# イベントID( EVT-20260618-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→20→25→19→21
* 開始   : 2026-06-18 09:50:00 (UTC)
* 終了   : 2026-06-18 09:50:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host12-007 active_connections の推移](charts/EVT-20260618-host12-007.svg)

# イベントID( EVT-20260618-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→21→26→18→…→26→18→23→20
* 開始   : 2026-06-18 13:50:00 (UTC)
* 終了   : 2026-06-18 13:55:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260618-host12-009 active_connections の推移](charts/EVT-20260618-host12-009.svg)

# イベントID( EVT-20260619-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→12→11
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host12-002 active_connections の推移](charts/EVT-20260619-host12-002.svg)

# イベントID( EVT-20260619-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→15→18→15→16
* 開始   : 2026-06-19 05:45:00 (UTC)
* 終了   : 2026-06-19 05:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host12-003 active_connections の推移](charts/EVT-20260619-host12-003.svg)

# イベントID( EVT-20260619-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→17→13
* 開始   : 2026-06-19 06:05:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host12-004 active_connections の推移](charts/EVT-20260619-host12-004.svg)

# イベントID( EVT-20260619-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→22→17→22→22
* 開始   : 2026-06-19 10:45:00 (UTC)
* 終了   : 2026-06-19 10:45:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.348σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host12-006 active_connections の推移](charts/EVT-20260619-host12-006.svg)

# イベントID( EVT-20260620-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→13→…→10→11→13→12
* 開始   : 2026-06-20 04:55:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.828σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.021, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host12-001 active_connections の推移](charts/EVT-20260620-host12-001.svg)

# イベントID( EVT-20260620-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→11→…→10→12→10→12
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.855, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host12-002 active_connections の推移](charts/EVT-20260620-host12-002.svg)

# イベントID( EVT-20260620-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→14→…→10→11→12→10
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.128, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260620-host12-003 active_connections の推移](charts/EVT-20260620-host12-003.svg)

# イベントID( EVT-20260620-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→8→11→12→…→12→13→14→12
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 20:15:00 (UTC)
* 現象   : 15.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.021, 限界=2.66)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260620-host12-004 active_connections の推移](charts/EVT-20260620-host12-004.svg)

# イベントID( EVT-20260620-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→11→9→10→9
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host12-005 active_connections の推移](charts/EVT-20260620-host12-005.svg)

# イベントID( EVT-20260620-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→13→…→8→11→8→10
* 開始   : 2026-06-20 06:35:00 (UTC)
* 終了   : 2026-06-20 20:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.131σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.881, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260620-host12-006 active_connections の推移](charts/EVT-20260620-host12-006.svg)

# イベントID( EVT-20260621-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→10→10
* 開始   : 2026-06-21 03:00:00 (UTC)
* 終了   : 2026-06-21 03:00:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→14→…→14→10→13→11
* 開始   : 2026-06-22 02:55:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.819, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.992, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-004 active_connections の推移](charts/EVT-20260622-host12-004.svg)

# イベントID( EVT-20260623-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→11→15→10→12
* 開始   : 2026-06-23 03:20:00 (UTC)
* 終了   : 2026-06-23 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.552倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host12-002 active_connections の推移](charts/EVT-20260623-host12-002.svg)

# イベントID( EVT-20260623-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→17→19→13→17→19→13→16
* 開始   : 2026-06-23 05:45:00 (UTC)
* 終了   : 2026-06-23 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.585σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-013 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260623-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host12-004 active_connections の推移](charts/EVT-20260623-host12-004.svg)

# イベントID( EVT-20260623-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→14→19→15→14
* 開始   : 2026-06-23 06:15:00 (UTC)
* 終了   : 2026-06-23 06:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260623-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-005 active_connections の推移](charts/EVT-20260623-host12-005.svg)

# イベントID( EVT-20260623-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→12→15
* 開始   : 2026-06-23 18:30:00 (UTC)
* 終了   : 2026-06-23 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-010 active_connections の推移](charts/EVT-20260623-host12-010.svg)

# イベントID( EVT-20260623-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→6→11→7→…→7→6→8→9
* 開始   : 2026-06-23 21:20:00 (UTC)
* 終了   : 2026-06-23 21:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.291σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-056 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260623-host12-011 active_connections の推移](charts/EVT-20260623-host12-011.svg)

# イベントID( EVT-20260624-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→12→13
* 開始   : 2026-06-24 04:15:00 (UTC)
* 終了   : 2026-06-24 04:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-002 active_connections の推移](charts/EVT-20260624-host12-002.svg)

# イベントID( EVT-20260624-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→21→25→22→22
* 開始   : 2026-06-24 10:30:00 (UTC)
* 終了   : 2026-06-24 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-006 active_connections の推移](charts/EVT-20260624-host12-006.svg)

# イベントID( EVT-20260624-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→23→26→24→23
* 開始   : 2026-06-24 12:30:00 (UTC)
* 終了   : 2026-06-24 12:30:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-007 active_connections の推移](charts/EVT-20260624-host12-007.svg)

# イベントID( EVT-20260624-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→16→13→16→18
* 開始   : 2026-06-24 16:45:00 (UTC)
* 終了   : 2026-06-24 16:45:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7123(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.702σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host12-009 active_connections の推移](charts/EVT-20260624-host12-009.svg)

# イベントID( EVT-20260624-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→17→15
* 開始   : 2026-06-24 17:20:00 (UTC)
* 終了   : 2026-06-24 17:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-011 active_connections の推移](charts/EVT-20260624-host12-011.svg)

# イベントID( EVT-20260624-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→16→11→15→15
* 開始   : 2026-06-24 18:10:00 (UTC)
* 終了   : 2026-06-24 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-012 active_connections の推移](charts/EVT-20260624-host12-012.svg)

# イベントID( EVT-20260625-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→11→9
* 開始   : 2026-06-25 03:55:00 (UTC)
* 終了   : 2026-06-25 03:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-003 active_connections の推移](charts/EVT-20260625-host12-003.svg)

# イベントID( EVT-20260625-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→15→13→16→15→13
* 開始   : 2026-06-25 04:40:00 (UTC)
* 終了   : 2026-06-25 04:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host12-004 active_connections の推移](charts/EVT-20260625-host12-004.svg)

# イベントID( EVT-20260625-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→20→19→15→…→20→19→16→18
* 開始   : 2026-06-25 06:55:00 (UTC)
* 終了   : 2026-06-25 07:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.29σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host12-006 active_connections の推移](charts/EVT-20260625-host12-006.svg)

# イベントID( EVT-20260625-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→20→25→22→20
* 開始   : 2026-06-25 09:25:00 (UTC)
* 終了   : 2026-06-25 09:25:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.463σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host12-009 active_connections の推移](charts/EVT-20260625-host12-009.svg)

# イベントID( EVT-20260625-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→21→26→21→22
* 開始   : 2026-06-25 10:15:00 (UTC)
* 終了   : 2026-06-25 10:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.258倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.727σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-010 active_connections の推移](charts/EVT-20260625-host12-010.svg)

# イベントID( EVT-20260625-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→19→13→19→15
* 開始   : 2026-06-25 16:45:00 (UTC)
* 終了   : 2026-06-25 16:45:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.409σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host12-013 active_connections の推移](charts/EVT-20260625-host12-013.svg)

# イベントID( EVT-20260625-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→13→9→12→12
* 開始   : 2026-06-25 19:40:00 (UTC)
* 終了   : 2026-06-25 19:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-016 active_connections の推移](charts/EVT-20260625-host12-016.svg)

# イベントID( EVT-20260626-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→7→13→10→8
* 開始   : 2026-06-26 02:45:00 (UTC)
* 終了   : 2026-06-26 02:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→12→12
* 開始   : 2026-06-26 04:05:00 (UTC)
* 終了   : 2026-06-26 04:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-004 active_connections の推移](charts/EVT-20260626-host12-004.svg)

# イベントID( EVT-20260626-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→19→14→18→…→18→20→16→17
* 開始   : 2026-06-26 06:10:00 (UTC)
* 終了   : 2026-06-26 07:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host12-007 active_connections の推移](charts/EVT-20260626-host12-007.svg)

# イベントID( EVT-20260626-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→16→21→19→18
* 開始   : 2026-06-26 07:25:00 (UTC)
* 終了   : 2026-06-26 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.29σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-008 active_connections の推移](charts/EVT-20260626-host12-008.svg)

# イベントID( EVT-20260627-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→10→13→8→10
* 開始   : 2026-06-27 03:20:00 (UTC)
* 終了   : 2026-06-27 03:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→10→…→11→12→13→12
* 開始   : 2026-06-27 04:30:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.995, 限界=2.66)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 14.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.9 時間

![EVT-20260627-host12-003 active_connections の推移](charts/EVT-20260627-host12-003.svg)

# イベントID( EVT-20260627-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→14→12→14→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.698, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host12-004 active_connections の推移](charts/EVT-20260627-host12-004.svg)

# イベントID( EVT-20260627-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→10→11→14→12
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.736, 限界=2.649)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host12-005 active_connections の推移](charts/EVT-20260627-host12-005.svg)

# イベントID( EVT-20260627-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→12→10→13→12
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host12-006 active_connections の推移](charts/EVT-20260627-host12-006.svg)

# イベントID( EVT-20260627-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→14→10→12→…→9→15→14→11
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.375, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host12-007 active_connections の推移](charts/EVT-20260627-host12-007.svg)

# イベントID( EVT-20260627-host12-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→13→…→11→10→11→10
* 開始   : 2026-06-27 06:30:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.192, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host12-008 active_connections の推移](charts/EVT-20260627-host12-008.svg)

# イベントID( EVT-20260628-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→10→15→11→10
* 開始   : 2026-06-28 04:35:00 (UTC)
* 終了   : 2026-06-28 04:35:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host12-003 active_connections の推移](charts/EVT-20260628-host12-003.svg)

# イベントID( EVT-20260628-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→17→…→15→17→13→14
* 開始   : 2026-06-28 07:25:00 (UTC)
* 終了   : 2026-06-28 07:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host12-004 active_connections の推移](charts/EVT-20260628-host12-004.svg)

# イベントID( EVT-20260628-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 7→6→12→6→10
* 開始   : 2026-06-28 23:10:00 (UTC)
* 終了   : 2026-06-28 23:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host12-008 active_connections の推移](charts/EVT-20260628-host12-008.svg)

# イベントID( EVT-20260629-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→18→…→13→14→12→14
* 開始   : 2026-06-29 03:30:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.94から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.036, 限界=2.649)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-005 active_connections の推移](charts/EVT-20260629-host12-005.svg)

# イベントID( EVT-20260629-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→15→16→14→…→15→13→14→15
* 開始   : 2026-06-29 04:05:00 (UTC)
* 終了   : 2026-06-29 21:10:00 (UTC)
* 現象   : 2026-06-29 21:10:00 (UTC)を境に水準が 11.98から15.13へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-007 active_connections の推移](charts/EVT-20260629-host12-007.svg)

# イベントID( EVT-20260630-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→14→17→16→…→17→16→15→16
* 開始   : 2026-06-30 05:35:00 (UTC)
* 終了   : 2026-06-30 05:40:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host12-001 active_connections の推移](charts/EVT-20260630-host12-001.svg)

# イベントID( EVT-20260630-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→17→21→17→17
* 開始   : 2026-06-30 07:15:00 (UTC)
* 終了   : 2026-06-30 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host12-002 active_connections の推移](charts/EVT-20260630-host12-002.svg)

# イベントID( EVT-20260630-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→22→26→21→21
* 開始   : 2026-06-30 10:20:00 (UTC)
* 終了   : 2026-06-30 10:20:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.233倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host12-004 active_connections の推移](charts/EVT-20260630-host12-004.svg)

# イベントID( EVT-20260630-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→22→17→18→…→17→18→21→18
* 開始   : 2026-06-30 14:45:00 (UTC)
* 終了   : 2026-06-30 14:50:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host12-007 active_connections の推移](charts/EVT-20260630-host12-007.svg)

# イベントID( EVT-20260630-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→14→…→13→14→17→15
* 開始   : 2026-06-30 17:25:00 (UTC)
* 終了   : 2026-06-30 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host12-008 active_connections の推移](charts/EVT-20260630-host12-008.svg)

# イベントID( EVT-20260630-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→19→13→17→15
* 開始   : 2026-06-30 17:45:00 (UTC)
* 終了   : 2026-06-30 18:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260630-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260630-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host12-009 active_connections の推移](charts/EVT-20260630-host12-009.svg)

# イベントID( EVT-20260630-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→7→12→8→7→12→8→11→10
* 開始   : 2026-06-30 20:40:00 (UTC)
* 終了   : 2026-06-30 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.115σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260630-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-075 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260630-host12-012 active_connections の推移](charts/EVT-20260630-host12-012.svg)

# イベントID( EVT-20260630-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→7→5→7→9
* 開始   : 2026-06-30 22:40:00 (UTC)
* 終了   : 2026-06-30 22:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→18→…→17→18→14→15
* 開始   : 2026-06-01 05:30:00 (UTC)
* 終了   : 2026-06-01 05:35:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→19→18→19→18→19→18
* 開始   : 2026-06-01 06:55:00 (UTC)
* 終了   : 2026-06-01 07:05:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→13→12→15→13→12→15→14
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→14→12→13→11→12→13→11→16
* 開始   : 2026-06-01 18:35:00 (UTC)
* 終了   : 2026-06-01 18:45:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260601-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→21→20→19→22→21→22→21→22
* 開始   : 2026-06-02 08:45:00 (UTC)
* 終了   : 2026-06-02 09:50:00 (UTC)
* 現象   : 2026-06-02 09:50:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→14→…→14→19→13→16
* 開始   : 2026-06-02 17:55:00 (UTC)
* 終了   : 2026-06-02 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→9→11→11→11→10→9→11
* 開始   : 2026-06-03 01:45:00 (UTC)
* 終了   : 2026-06-03 02:20:00 (UTC)
* 現象   : 2026-06-03 02:20:00 (UTC)を境に水準が 14.96から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→13→12→11→11→13→12
* 開始   : 2026-06-03 03:10:00 (UTC)
* 終了   : 2026-06-03 03:40:00 (UTC)
* 現象   : 2026-06-03 03:40:00 (UTC)を境に水準が 14.9から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→17→20→21→17→20→21→17
* 開始   : 2026-06-03 07:55:00 (UTC)
* 終了   : 2026-06-03 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→18→15→19→15→19→15→16→17
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.476σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→18→17→15→14→18→17
* 開始   : 2026-06-03 16:40:00 (UTC)
* 終了   : 2026-06-03 16:45:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→16→12→16→12→13
* 開始   : 2026-06-03 18:35:00 (UTC)
* 終了   : 2026-06-03 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→14→11→10→…→11→10→11→12
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→9→…→15→9→11→13
* 開始   : 2026-06-04 04:40:00 (UTC)
* 終了   : 2026-06-04 04:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→16→14→13→16→14→12
* 開始   : 2026-06-04 05:20:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.362倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.937σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→20→21→19→21→19→21→20
* 開始   : 2026-06-04 08:05:00 (UTC)
* 終了   : 2026-06-04 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→23→20→22→23→20
* 開始   : 2026-06-04 09:00:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 24→21→22→22→24→24→24→21→22
* 開始   : 2026-06-04 12:20:00 (UTC)
* 終了   : 2026-06-04 13:20:00 (UTC)
* 現象   : 2026-06-04 13:20:00 (UTC)を境に水準が 14.98から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→18→16→19→18
* 開始   : 2026-06-04 16:20:00 (UTC)
* 終了   : 2026-06-04 16:25:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→15→16→14→13→14→14→16→14
* 開始   : 2026-06-04 18:25:00 (UTC)
* 終了   : 2026-06-04 19:10:00 (UTC)
* 現象   : 2026-06-04 19:10:00 (UTC)を境に水準が 14.88から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.52, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→11→6→13→…→6→13→9→10
* 開始   : 2026-06-04 21:30:00 (UTC)
* 終了   : 2026-06-04 21:35:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.821σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→7→8→10→8→10→12
* 開始   : 2026-06-05 00:25:00 (UTC)
* 終了   : 2026-06-05 01:20:00 (UTC)
* 現象   : 2026-06-05 01:20:00 (UTC)を境に水準が 15.04から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→15→13→15→13→15→14→11
* 開始   : 2026-06-05 04:30:00 (UTC)
* 終了   : 2026-06-05 04:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.385倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→14→15→12→11→14→15→12→13
* 開始   : 2026-06-05 04:30:00 (UTC)
* 終了   : 2026-06-05 04:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→14→…→14→17→14→16
* 開始   : 2026-06-05 05:40:00 (UTC)
* 終了   : 2026-06-05 05:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→18→16→14→17→18→16
* 開始   : 2026-06-05 06:05:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.54σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→15→…→18→20→16→18
* 開始   : 2026-06-05 07:05:00 (UTC)
* 終了   : 2026-06-05 07:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.476σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260605-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→25→21→24→25→21→24→22→21
* 開始   : 2026-06-05 10:40:00 (UTC)
* 終了   : 2026-06-05 10:50:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.2倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.924σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→16→18→15→16→18→15→18→16
* 開始   : 2026-06-05 16:25:00 (UTC)
* 終了   : 2026-06-05 16:35:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.252σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→15→18→18→15→16→18→17
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 18:10:00 (UTC)
* 現象   : 2026-06-05 18:10:00 (UTC)を境に水準が 15.11から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.304, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→19→14→15→…→15→13→14→13
* 開始   : 2026-06-05 17:45:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→13→10→13→10→13→14
* 開始   : 2026-06-05 19:15:00 (UTC)
* 終了   : 2026-06-05 19:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-083 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→12→10→11→10→11→10→11→12
* 開始   : 2026-06-05 19:25:00 (UTC)
* 終了   : 2026-06-05 19:35:00 (UTC)
* 現象   : 平常時(14)に対し 0.7143(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.783σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-083 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-082 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-084 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→12→10→11→…→11→9→10→13
* 開始   : 2026-06-05 19:45:00 (UTC)
* 終了   : 2026-06-05 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host06-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→9→7→9→11
* 開始   : 2026-06-05 21:10:00 (UTC)
* 終了   : 2026-06-05 21:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→12→10→14→12
* 開始   : 2026-06-07 05:40:00 (UTC)
* 終了   : 2026-06-07 05:45:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.409σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260607-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→15→18→17→18→17
* 開始   : 2026-06-07 10:15:00 (UTC)
* 終了   : 2026-06-07 10:40:00 (UTC)
* 現象   : 2026-06-07 10:40:00 (UTC)を境に水準が 11.86から13.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→14→12→18→15→14→12→18→15
* 開始   : 2026-06-07 13:40:00 (UTC)
* 終了   : 2026-06-07 13:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260607-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→8→9→10→10
* 開始   : 2026-06-07 21:45:00 (UTC)
* 終了   : 2026-06-07 22:15:00 (UTC)
* 現象   : 2026-06-07 22:15:00 (UTC)を境に水準が 11.89から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.689, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→8→12→8→12→8→12→9→7
* 開始   : 2026-06-09 02:45:00 (UTC)
* 終了   : 2026-06-09 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.233σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 21→20→22→21→21→21→23→22
* 開始   : 2026-06-09 09:10:00 (UTC)
* 終了   : 2026-06-09 09:45:00 (UTC)
* 現象   : 2026-06-09 09:45:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→18→20→16→18
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260609-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→10→12→10→11→11
* 開始   : 2026-06-09 21:05:00 (UTC)
* 終了   : 2026-06-09 21:30:00 (UTC)
* 現象   : 2026-06-09 21:30:00 (UTC)を境に水準が 14.91から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→8→12
* 開始   : 2026-06-09 22:30:00 (UTC)
* 終了   : 2026-06-09 23:40:00 (UTC)
* 現象   : 2026-06-09 23:40:00 (UTC)を境に水準が 14.89から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.188σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→13→11→11→12→10→13→9→14
* 開始   : 2026-06-10 02:50:00 (UTC)
* 終了   : 2026-06-10 03:50:00 (UTC)
* 現象   : 2026-06-10 03:50:00 (UTC)を境に水準が 14.96から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→10→13→10→11
* 開始   : 2026-06-10 03:20:00 (UTC)
* 終了   : 2026-06-10 03:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→17→18→19→…→18→19→18→17
* 開始   : 2026-06-10 06:55:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→15→19→16→15→19→16→17
* 開始   : 2026-06-10 06:55:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 22→23→19→24→19→24→19→22
* 開始   : 2026-06-10 11:50:00 (UTC)
* 終了   : 2026-06-10 12:00:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→19→19→19→21→20
* 開始   : 2026-06-10 15:35:00 (UTC)
* 終了   : 2026-06-10 16:05:00 (UTC)
* 現象   : 2026-06-10 16:05:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→19→16→20→…→20→15→17→18
* 開始   : 2026-06-10 16:30:00 (UTC)
* 終了   : 2026-06-10 16:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→18→15→14→17→18→15→14→17
* 開始   : 2026-06-10 17:10:00 (UTC)
* 終了   : 2026-06-10 17:15:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 7→9→6→5→…→6→5→8→9
* 開始   : 2026-06-10 23:05:00 (UTC)
* 終了   : 2026-06-10 23:10:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→9→9→8→8→10→10
* 開始   : 2026-06-11 00:25:00 (UTC)
* 終了   : 2026-06-11 01:10:00 (UTC)
* 現象   : 2026-06-11 01:10:00 (UTC)を境に水準が 14.82から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.413, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→8→10→9→10→8→9→9→10
* 開始   : 2026-06-11 00:50:00 (UTC)
* 終了   : 2026-06-11 01:35:00 (UTC)
* 現象   : 2026-06-11 01:35:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 6→9→12→9→12→9→11
* 開始   : 2026-06-11 02:30:00 (UTC)
* 終了   : 2026-06-11 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→16→12→17→16→12→17→12→14
* 開始   : 2026-06-11 05:20:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→16→14→17→16
* 開始   : 2026-06-11 06:10:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→18→21→20→18→21→20→19
* 開始   : 2026-06-11 08:50:00 (UTC)
* 終了   : 2026-06-11 08:55:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→21→23→21→23→23→21→23→24
* 開始   : 2026-06-11 10:15:00 (UTC)
* 終了   : 2026-06-11 11:00:00 (UTC)
* 現象   : 2026-06-11 11:00:00 (UTC)を境に水準が 15.04から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→20→25→21→18→25→21→18→21
* 開始   : 2026-06-11 14:30:00 (UTC)
* 終了   : 2026-06-11 14:40:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→13→17→15→14→16→16
* 開始   : 2026-06-11 18:25:00 (UTC)
* 終了   : 2026-06-11 19:10:00 (UTC)
* 現象   : 2026-06-11 19:10:00 (UTC)を境に水準が 14.96から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→13→12→13→12→15→14
* 開始   : 2026-06-11 18:40:00 (UTC)
* 終了   : 2026-06-11 18:50:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→13→12→12→13→15→14→14→14
* 開始   : 2026-06-12 03:55:00 (UTC)
* 終了   : 2026-06-12 05:50:00 (UTC)
* 現象   : 2026-06-12 05:50:00 (UTC)を境に水準が 14.86から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→16→20→18→16→20→18→17
* 開始   : 2026-06-12 07:25:00 (UTC)
* 終了   : 2026-06-12 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260612-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260612-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→22→23→24→…→23→24→20→22
* 開始   : 2026-06-12 09:30:00 (UTC)
* 終了   : 2026-06-12 09:35:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→24
* 開始   : 2026-06-12 12:40:00 (UTC)
* 終了   : 2026-06-12 13:25:00 (UTC)
* 現象   : 2026-06-12 13:25:00 (UTC)を境に水準が 14.95から13.26へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→16→18→14→16→15
* 開始   : 2026-06-12 17:05:00 (UTC)
* 終了   : 2026-06-12 17:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.41σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→11→14→12→11→14
* 開始   : 2026-06-12 18:55:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→8→6→8→6→8→10
* 開始   : 2026-06-13 22:15:00 (UTC)
* 終了   : 2026-06-13 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→14→15→14→15→13
* 開始   : 2026-06-14 06:30:00 (UTC)
* 終了   : 2026-06-14 06:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260614-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→13→15→13→15→14→15
* 開始   : 2026-06-14 07:05:00 (UTC)
* 終了   : 2026-06-14 07:15:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.644σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→16→13→16→15→12
* 開始   : 2026-06-14 07:15:00 (UTC)
* 終了   : 2026-06-14 07:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260614-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→17→…→17→13→17→15
* 開始   : 2026-06-14 12:10:00 (UTC)
* 終了   : 2026-06-14 12:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→11→11→12
* 開始   : 2026-06-14 20:30:00 (UTC)
* 終了   : 2026-06-14 20:45:00 (UTC)
* 現象   : 2026-06-14 20:45:00 (UTC)を境に水準が 11.88から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→12
* 開始   : 2026-06-14 22:15:00 (UTC)
* 終了   : 2026-06-14 22:20:00 (UTC)
* 現象   : 2026-06-14 22:20:00 (UTC)を境に水準が 11.92から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→11→…→11→13→10→11
* 開始   : 2026-06-16 02:55:00 (UTC)
* 終了   : 2026-06-16 03:05:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→13→13→8→10→13→12
* 開始   : 2026-06-16 03:00:00 (UTC)
* 終了   : 2026-06-16 03:30:00 (UTC)
* 現象   : 2026-06-16 03:30:00 (UTC)を境に水準が 15.13から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.689, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→20→19→18→20→18
* 開始   : 2026-06-16 07:15:00 (UTC)
* 終了   : 2026-06-16 07:40:00 (UTC)
* 現象   : 2026-06-16 07:40:00 (UTC)を境に水準が 14.9から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→17→20→19→17→20→17
* 開始   : 2026-06-16 07:20:00 (UTC)
* 終了   : 2026-06-16 07:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→20→21→20→21→20
* 開始   : 2026-06-16 08:45:00 (UTC)
* 終了   : 2026-06-16 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→21→22→20→…→21→23→22→23
* 開始   : 2026-06-16 09:20:00 (UTC)
* 終了   : 2026-06-16 09:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.174σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→14→10→11→…→12→9→11→12
* 開始   : 2026-06-16 19:35:00 (UTC)
* 終了   : 2026-06-16 19:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.706σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260616-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260616-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 7→9→11→8→9→11→8
* 開始   : 2026-06-17 00:50:00 (UTC)
* 終了   : 2026-06-17 00:55:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→17→14→17→14→17→16
* 開始   : 2026-06-17 05:50:00 (UTC)
* 終了   : 2026-06-17 06:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.316倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.841σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→20→22→19→21→20→22→21→23
* 開始   : 2026-06-17 08:30:00 (UTC)
* 終了   : 2026-06-17 09:35:00 (UTC)
* 現象   : 2026-06-17 09:35:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→18→16→18→16→17→18
* 開始   : 2026-06-17 16:05:00 (UTC)
* 終了   : 2026-06-17 16:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→17→13→14→17→13→15
* 開始   : 2026-06-17 17:30:00 (UTC)
* 終了   : 2026-06-17 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260617-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→13→12→13→12→15→14
* 開始   : 2026-06-17 18:20:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260617-host02-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260617-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→13→…→13→14→13→14
* 開始   : 2026-06-18 04:15:00 (UTC)
* 終了   : 2026-06-18 04:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→13→15→13→14→15
* 開始   : 2026-06-18 04:35:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 2026-06-18 05:00:00 (UTC)を境に水準が 15.06から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→16→15→18→19→16→17→20
* 開始   : 2026-06-18 05:50:00 (UTC)
* 終了   : 2026-06-18 07:40:00 (UTC)
* 現象   : 2026-06-18 07:40:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→22→24→21→21→24→21→22→24
* 開始   : 2026-06-18 11:05:00 (UTC)
* 終了   : 2026-06-18 12:00:00 (UTC)
* 現象   : 2026-06-18 12:00:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.994, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→21→17→20→21→17→20→18
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 15:00:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.527σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→17→20→16→17→18
* 開始   : 2026-06-18 16:15:00 (UTC)
* 終了   : 2026-06-18 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→10→9→7→10→11
* 開始   : 2026-06-18 22:05:00 (UTC)
* 終了   : 2026-06-18 22:10:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 7→9→12→9→12→9→12→10→12
* 開始   : 2026-06-19 02:45:00 (UTC)
* 終了   : 2026-06-19 02:55:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→15→17→16→18→18
* 開始   : 2026-06-19 06:20:00 (UTC)
* 終了   : 2026-06-19 06:45:00 (UTC)
* 現象   : 2026-06-19 06:45:00 (UTC)を境に水準が 14.98から14.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 22→23→21→19→20→21→22
* 開始   : 2026-06-19 14:30:00 (UTC)
* 終了   : 2026-06-19 15:00:00 (UTC)
* 現象   : 2026-06-19 15:00:00 (UTC)を境に水準が 14.91から12.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.361, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 22→23→22
* 開始   : 2026-06-19 14:45:00 (UTC)
* 終了   : 2026-06-19 14:55:00 (UTC)
* 現象   : 2026-06-19 14:55:00 (UTC)を境に水準が 14.96から12.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→16→20→20→16→15→17
* 開始   : 2026-06-19 17:15:00 (UTC)
* 終了   : 2026-06-19 17:45:00 (UTC)
* 現象   : 2026-06-19 17:45:00 (UTC)を境に水準が 15.01から12.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.689, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→10→13→10
* 開始   : 2026-06-19 19:50:00 (UTC)
* 終了   : 2026-06-19 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→7→10→7→10→7→9
* 開始   : 2026-06-19 21:20:00 (UTC)
* 終了   : 2026-06-19 21:30:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→8→12→9→…→9→6→8→10
* 開始   : 2026-06-20 22:00:00 (UTC)
* 終了   : 2026-06-20 22:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→11→12→11→11→11
* 開始   : 2026-06-21 03:30:00 (UTC)
* 終了   : 2026-06-21 03:55:00 (UTC)
* 現象   : 2026-06-21 03:55:00 (UTC)を境に水準が 11.76から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→11→12→13→14→13→14
* 開始   : 2026-06-21 05:10:00 (UTC)
* 終了   : 2026-06-21 05:40:00 (UTC)
* 現象   : 2026-06-21 05:40:00 (UTC)を境に水準が 11.94から12.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→10→…→16→10→15→14
* 開始   : 2026-06-21 16:40:00 (UTC)
* 終了   : 2026-06-21 16:45:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→11
* 開始   : 2026-06-21 21:25:00 (UTC)
* 終了   : 2026-06-21 21:40:00 (UTC)
* 現象   : 2026-06-21 21:40:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→11→11→9
* 開始   : 2026-06-21 21:25:00 (UTC)
* 終了   : 2026-06-21 21:50:00 (UTC)
* 現象   : 2026-06-21 21:50:00 (UTC)を境に水準が 11.86から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→6→8→9→6→8
* 開始   : 2026-06-21 22:50:00 (UTC)
* 終了   : 2026-06-21 22:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→10→8→12→10
* 開始   : 2026-06-22 01:45:00 (UTC)
* 終了   : 2026-06-22 01:50:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.548倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.937σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→6→…→12→6→10→9
* 開始   : 2026-06-23 02:40:00 (UTC)
* 終了   : 2026-06-23 02:45:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→16→13→13→15→15
* 開始   : 2026-06-23 04:55:00 (UTC)
* 終了   : 2026-06-23 05:20:00 (UTC)
* 現象   : 2026-06-23 05:20:00 (UTC)を境に水準が 14.85から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→16→18→18→18→17→17→17→20
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 07:35:00 (UTC)
* 現象   : 2026-06-23 07:35:00 (UTC)を境に水準が 14.9から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→20→22→20→22→20→22→21→20
* 開始   : 2026-06-23 09:10:00 (UTC)
* 終了   : 2026-06-23 09:20:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→23→22→21→23→25→20→23→23
* 開始   : 2026-06-23 10:45:00 (UTC)
* 終了   : 2026-06-23 11:30:00 (UTC)
* 現象   : 2026-06-23 11:30:00 (UTC)を境に水準が 14.87から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 20→18→19→17→18→19→17→20→21
* 開始   : 2026-06-23 14:45:00 (UTC)
* 終了   : 2026-06-23 14:55:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→12→11→13→11→13→13→14→14
* 開始   : 2026-06-24 03:55:00 (UTC)
* 終了   : 2026-06-24 04:55:00 (UTC)
* 現象   : 2026-06-24 04:55:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→11→16→14→16→14→16→15→16
* 開始   : 2026-06-24 05:45:00 (UTC)
* 終了   : 2026-06-24 05:55:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→15→17→17→18→16→18
* 開始   : 2026-06-24 05:55:00 (UTC)
* 終了   : 2026-06-24 06:35:00 (UTC)
* 現象   : 2026-06-24 06:35:00 (UTC)を境に水準が 15.1から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.412, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→18→20→18→20→17
* 開始   : 2026-06-24 07:50:00 (UTC)
* 終了   : 2026-06-24 07:55:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→23→19→18→…→19→18→20→23
* 開始   : 2026-06-24 13:35:00 (UTC)
* 終了   : 2026-06-24 13:40:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260624-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→14→15→17→15→14→15
* 開始   : 2026-06-24 16:55:00 (UTC)
* 終了   : 2026-06-24 17:00:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→15→12→15→12→15→12→13
* 開始   : 2026-06-24 18:20:00 (UTC)
* 終了   : 2026-06-24 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260624-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 6→8→5→9→11→5→9→11→7
* 開始   : 2026-06-24 23:25:00 (UTC)
* 終了   : 2026-06-24 23:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 8→9→5→11→…→5→11→6→9
* 開始   : 2026-06-25 00:40:00 (UTC)
* 終了   : 2026-06-25 00:45:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host02-001 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260625-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→8→12→10→…→10→6→8→9
* 開始   : 2026-06-25 02:00:00 (UTC)
* 終了   : 2026-06-25 02:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.409σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→17→19→17→19→16→17
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 06:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.281倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.886σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→18→13→16→20→13→16→20→17
* 開始   : 2026-06-25 07:00:00 (UTC)
* 終了   : 2026-06-25 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→19→19→18→17→20
* 開始   : 2026-06-25 07:10:00 (UTC)
* 終了   : 2026-06-25 07:35:00 (UTC)
* 現象   : 2026-06-25 07:35:00 (UTC)を境に水準が 14.96から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→18→17→19→17→19→17→18
* 開始   : 2026-06-25 15:55:00 (UTC)
* 終了   : 2026-06-25 16:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→17→15→17
* 開始   : 2026-06-25 16:45:00 (UTC)
* 終了   : 2026-06-25 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.476σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→14→16→13→14→16→13→14→15
* 開始   : 2026-06-25 17:40:00 (UTC)
* 終了   : 2026-06-25 17:50:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→11→10→14→11→10→14→16
* 開始   : 2026-06-25 18:55:00 (UTC)
* 終了   : 2026-06-25 19:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→10→8→7→8→10→9→9→9
* 開始   : 2026-06-25 23:05:00 (UTC)
* 終了   : 2026-06-26 00:15:00 (UTC)
* 現象   : 2026-06-26 00:15:00 (UTC)を境に水準が 15から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 8→7→11→9→…→9→5→8→6
* 開始   : 2026-06-26 00:35:00 (UTC)
* 終了   : 2026-06-26 00:45:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→12→9→10→11→11→11→10→9
* 開始   : 2026-06-26 01:50:00 (UTC)
* 終了   : 2026-06-26 02:50:00 (UTC)
* 現象   : 2026-06-26 02:50:00 (UTC)を境に水準が 14.96から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→12→14→12→14→11→12
* 開始   : 2026-06-26 04:20:00 (UTC)
* 終了   : 2026-06-26 04:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.304σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→16→17→17→18→17→18
* 開始   : 2026-06-26 06:00:00 (UTC)
* 終了   : 2026-06-26 07:00:00 (UTC)
* 現象   : 2026-06-26 07:00:00 (UTC)を境に水準が 15.03から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→21→19→21→19→21→19
* 開始   : 2026-06-26 08:00:00 (UTC)
* 終了   : 2026-06-26 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→19→24→23→19→24→21
* 開始   : 2026-06-26 12:15:00 (UTC)
* 終了   : 2026-06-26 12:20:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→24→23→24
* 開始   : 2026-06-26 13:45:00 (UTC)
* 終了   : 2026-06-26 14:00:00 (UTC)
* 現象   : 2026-06-26 14:00:00 (UTC)を境に水準が 15.01から12.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→7→9→7→9→7→10→7
* 開始   : 2026-06-26 21:55:00 (UTC)
* 終了   : 2026-06-26 22:05:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→5→7→12→5→7→12→7→8
* 開始   : 2026-06-27 01:10:00 (UTC)
* 終了   : 2026-06-27 01:20:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260627-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→7→11→6→7→11→6→10
* 開始   : 2026-06-28 02:30:00 (UTC)
* 終了   : 2026-06-28 02:35:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 7→10→12→9→12→9→12→11→8
* 開始   : 2026-06-28 03:55:00 (UTC)
* 終了   : 2026-06-28 04:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→11→15→17→11→15→17→14
* 開始   : 2026-06-28 09:15:00 (UTC)
* 終了   : 2026-06-28 09:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260628-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→13→18→16→19→13→18
* 開始   : 2026-06-28 11:15:00 (UTC)
* 終了   : 2026-06-28 11:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→10→7→10→7→9
* 開始   : 2026-06-28 19:25:00 (UTC)
* 終了   : 2026-06-28 19:35:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.6269(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.879σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260628-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→8→10→10
* 開始   : 2026-06-29 01:55:00 (UTC)
* 終了   : 2026-06-29 02:15:00 (UTC)
* 現象   : 2026-06-29 02:15:00 (UTC)を境に水準が 11.89から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→6→10→6→10→6→7
* 開始   : 2026-06-29 22:10:00 (UTC)
* 終了   : 2026-06-29 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→21→23→20→21→23→20→22
* 開始   : 2026-06-30 09:10:00 (UTC)
* 終了   : 2026-06-30 09:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.598σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→25→23→21→22→24→23→23
* 開始   : 2026-06-30 12:05:00 (UTC)
* 終了   : 2026-06-30 12:40:00 (UTC)
* 現象   : 2026-06-30 12:40:00 (UTC)を境に水準が 14.93から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→19→21→22→19→21
* 開始   : 2026-06-30 14:00:00 (UTC)
* 終了   : 2026-06-30 14:05:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→17→12→13→17→12→14→15
* 開始   : 2026-06-30 17:55:00 (UTC)
* 終了   : 2026-06-30 18:05:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260630-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→14
* 開始   : 2026-06-30 18:55:00 (UTC)
* 終了   : 2026-06-30 19:35:00 (UTC)
* 現象   : 2026-06-30 19:35:00 (UTC)を境に水準が 15.06から9.931へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→11→10→10
* 開始   : 2026-06-30 22:00:00 (UTC)
* 終了   : 2026-06-30 22:25:00 (UTC)
* 現象   : 2026-06-30 22:25:00 (UTC)を境に水準が 15.08から8.421へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
