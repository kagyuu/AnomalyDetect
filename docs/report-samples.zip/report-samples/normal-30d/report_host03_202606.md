# host03 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host03 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 309 (SEVERE: 19, FATAL: 129, WARN: 161, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 129 | 161 | 309 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→14→13→12→11
* 開始   : 2026-06-08 01:45:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.92から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.699, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-001 active_connections の推移](charts/EVT-20260608-host03-001.svg)

# イベントID( EVT-20260608-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→14→16→…→12→14→13→12
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 21:50:00 (UTC)
* 現象   : 2026-06-08 21:50:00 (UTC)を境に水準が 11.88から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.198, 限界=2.67)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.004, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-002 active_connections の推移](charts/EVT-20260608-host03-002.svg)

# イベントID( EVT-20260608-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→16→13→15→…→15→12→14→13
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.74から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.683, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-003 active_connections の推移](charts/EVT-20260608-host03-003.svg)

# イベントID( EVT-20260608-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→18→16→15→…→14→12→10→12
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 21:05:00 (UTC)
* 現象   : 2026-06-08 21:05:00 (UTC)を境に水準が 11.84から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.295, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-004 active_connections の推移](charts/EVT-20260608-host03-004.svg)

# イベントID( EVT-20260608-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→17→18→17→…→15→13→11→14
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.602σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.147, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-005 active_connections の推移](charts/EVT-20260608-host03-005.svg)

# イベントID( EVT-20260608-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→15→14→15→…→17→14→13→15
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.93から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.697, 限界=2.644)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-006 active_connections の推移](charts/EVT-20260608-host03-006.svg)

# イベントID( EVT-20260615-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→15→13→12→13
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.86から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.978, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-001 active_connections の推移](charts/EVT-20260615-host03-001.svg)

# イベントID( EVT-20260615-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→15→…→12→11→13→12
* 開始   : 2026-06-15 02:45:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.789, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-002 active_connections の推移](charts/EVT-20260615-host03-002.svg)

# イベントID( EVT-20260615-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→15→…→16→14→12→13
* 開始   : 2026-06-15 03:15:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 12から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.47, 限界=2.644)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.531, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-003 active_connections の推移](charts/EVT-20260615-host03-003.svg)

# イベントID( EVT-20260615-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→12→15→12→14
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 19:40:00 (UTC)
* 現象   : 2026-06-15 19:40:00 (UTC)を境に水準が 11.97から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.489σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.038, 限界=2.67)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.004, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-005 active_connections の推移](charts/EVT-20260615-host03-005.svg)

# イベントID( EVT-20260615-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→17→16→15→…→12→13→11→12
* 開始   : 2026-06-15 04:00:00 (UTC)
* 終了   : 2026-06-15 19:30:00 (UTC)
* 現象   : 2026-06-15 19:30:00 (UTC)を境に水準が 11.99から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-006 active_connections の推移](charts/EVT-20260615-host03-006.svg)

# イベントID( EVT-20260622-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→18→19→17→…→13→16→14→10
* 開始   : 2026-06-22 02:15:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.85から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.8, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.958, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-003 active_connections の推移](charts/EVT-20260622-host03-003.svg)

# イベントID( EVT-20260622-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→17→…→16→13→12→13
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 11.94から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-004 active_connections の推移](charts/EVT-20260622-host03-004.svg)

# イベントID( EVT-20260622-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→14→…→18→14→12→13
* 開始   : 2026-06-22 03:00:00 (UTC)
* 終了   : 2026-06-22 21:35:00 (UTC)
* 現象   : 2026-06-22 21:35:00 (UTC)を境に水準が 11.75から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.73, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-005 active_connections の推移](charts/EVT-20260622-host03-005.svg)

# イベントID( EVT-20260622-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→17→18→17→…→12→15→12→14
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 22:10:00 (UTC)
* 現象   : 2026-06-22 22:10:00 (UTC)を境に水準が 12から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.644)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.969, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-006 active_connections の推移](charts/EVT-20260622-host03-006.svg)

# イベントID( EVT-20260622-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→16→15→16→…→18→15→13→15
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.85から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.489σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.669, 限界=2.67)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-007 active_connections の推移](charts/EVT-20260622-host03-007.svg)

# イベントID( EVT-20260629-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→14→15→14→…→15→12→13→14
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.95から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.677, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.892, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-004 active_connections の推移](charts/EVT-20260629-host03-004.svg)

# イベントID( EVT-20260629-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→17→…→16→15→12→14
* 開始   : 2026-06-29 04:00:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.926σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.047, 限界=2.644)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-005 active_connections の推移](charts/EVT-20260629-host03-005.svg)

# イベントID( EVT-20260629-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→14→18→15→…→14→15→14→13
* 開始   : 2026-06-29 04:20:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 12.01から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.033, 限界=2.67)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-006 active_connections の推移](charts/EVT-20260629-host03-006.svg)

# イベントID( EVT-20260601-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→10→10
* 開始   : 2026-06-01 02:35:00 (UTC)
* 終了   : 2026-06-01 02:35:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-001 active_connections の推移](charts/EVT-20260601-host03-001.svg)

# イベントID( EVT-20260601-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→9→14→10→10
* 開始   : 2026-06-01 02:45:00 (UTC)
* 終了   : 2026-06-01 02:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host03-002 active_connections の推移](charts/EVT-20260601-host03-002.svg)

# イベントID( EVT-20260601-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→11→15→12→10
* 開始   : 2026-06-01 03:35:00 (UTC)
* 終了   : 2026-06-01 03:35:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-003 active_connections の推移](charts/EVT-20260601-host03-003.svg)

# イベントID( EVT-20260601-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→15→16
* 開始   : 2026-06-01 05:50:00 (UTC)
* 終了   : 2026-06-01 05:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host03-004 active_connections の推移](charts/EVT-20260601-host03-004.svg)

# イベントID( EVT-20260601-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→18→19→21→…→19→21→17→19
* 開始   : 2026-06-01 07:20:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-005 active_connections の推移](charts/EVT-20260601-host03-005.svg)

# イベントID( EVT-20260601-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→19→15→18→18
* 開始   : 2026-06-01 15:45:00 (UTC)
* 終了   : 2026-06-01 15:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-007 active_connections の推移](charts/EVT-20260601-host03-007.svg)

# イベントID( EVT-20260601-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→14→19→18
* 開始   : 2026-06-01 16:45:00 (UTC)
* 終了   : 2026-06-01 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-008 active_connections の推移](charts/EVT-20260601-host03-008.svg)

# イベントID( EVT-20260601-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→12→13
* 開始   : 2026-06-01 19:10:00 (UTC)
* 終了   : 2026-06-01 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host03-009 active_connections の推移](charts/EVT-20260601-host03-009.svg)

# イベントID( EVT-20260601-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→7→10→9
* 開始   : 2026-06-01 20:50:00 (UTC)
* 終了   : 2026-06-01 20:50:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260601-host03-011 active_connections の推移](charts/EVT-20260601-host03-011.svg)

# イベントID( EVT-20260601-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→11→5→10→9
* 開始   : 2026-06-01 22:20:00 (UTC)
* 終了   : 2026-06-01 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-013 active_connections の推移](charts/EVT-20260601-host03-013.svg)

# イベントID( EVT-20260602-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→16→…→20→18→20→17
* 開始   : 2026-06-02 06:35:00 (UTC)
* 終了   : 2026-06-02 06:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-026 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host03-003 active_connections の推移](charts/EVT-20260602-host03-003.svg)

# イベントID( EVT-20260602-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→18→12→14→13
* 開始   : 2026-06-02 18:00:00 (UTC)
* 終了   : 2026-06-02 18:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host03-010 active_connections の推移](charts/EVT-20260602-host03-010.svg)

# イベントID( EVT-20260603-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→13→17→14→11
* 開始   : 2026-06-03 04:50:00 (UTC)
* 終了   : 2026-06-03 04:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-003 active_connections の推移](charts/EVT-20260603-host03-003.svg)

# イベントID( EVT-20260603-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→15→16
* 開始   : 2026-06-03 05:40:00 (UTC)
* 終了   : 2026-06-03 05:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host03-004 active_connections の推移](charts/EVT-20260603-host03-004.svg)

# イベントID( EVT-20260603-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→14→17→17
* 開始   : 2026-06-03 16:45:00 (UTC)
* 終了   : 2026-06-03 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host03-009 active_connections の推移](charts/EVT-20260603-host03-009.svg)

# イベントID( EVT-20260603-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→19→14→16→14→16→14→17→19
* 開始   : 2026-06-03 16:55:00 (UTC)
* 終了   : 2026-06-03 17:05:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260603-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host03-010 active_connections の推移](charts/EVT-20260603-host03-010.svg)

# イベントID( EVT-20260603-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→9→6→10→9
* 開始   : 2026-06-03 21:25:00 (UTC)
* 終了   : 2026-06-03 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host03-014 active_connections の推移](charts/EVT-20260603-host03-014.svg)

# イベントID( EVT-20260604-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→13→11
* 開始   : 2026-06-04 05:20:00 (UTC)
* 終了   : 2026-06-04 05:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host03-003 active_connections の推移](charts/EVT-20260604-host03-003.svg)

# イベントID( EVT-20260604-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→18→12→14→18→12→14
* 開始   : 2026-06-04 18:40:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260604-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260604-host03-009 active_connections の推移](charts/EVT-20260604-host03-009.svg)

# イベントID( EVT-20260605-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→10→…→10→14→11→10
* 開始   : 2026-06-05 02:50:00 (UTC)
* 終了   : 2026-06-05 03:00:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260605-host03-002 active_connections の推移](charts/EVT-20260605-host03-002.svg)

# イベントID( EVT-20260605-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→20→17→20→17→18
* 開始   : 2026-06-05 07:10:00 (UTC)
* 終了   : 2026-06-05 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host03-006 active_connections の推移](charts/EVT-20260605-host03-006.svg)

# イベントID( EVT-20260605-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→20→26→20→20
* 開始   : 2026-06-05 10:55:00 (UTC)
* 終了   : 2026-06-05 10:55:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.233倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host03-008 active_connections の推移](charts/EVT-20260605-host03-008.svg)

# イベントID( EVT-20260605-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→17→12→14→13
* 開始   : 2026-06-05 17:40:00 (UTC)
* 終了   : 2026-06-05 17:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host03-011 active_connections の推移](charts/EVT-20260605-host03-011.svg)

# イベントID( EVT-20260605-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→14→8→9→12→14→8→9→12
* 開始   : 2026-06-05 19:50:00 (UTC)
* 終了   : 2026-06-05 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-014 active_connections の推移](charts/EVT-20260605-host03-014.svg)

# イベントID( EVT-20260605-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→8→11→12
* 開始   : 2026-06-05 20:05:00 (UTC)
* 終了   : 2026-06-05 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-015 active_connections の推移](charts/EVT-20260605-host03-015.svg)

# イベントID( EVT-20260605-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→9→5→12→…→5→12→10→7
* 開始   : 2026-06-05 22:15:00 (UTC)
* 終了   : 2026-06-05 22:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host03-016 active_connections の推移](charts/EVT-20260605-host03-016.svg)

# イベントID( EVT-20260606-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 6→9→12→9→7
* 開始   : 2026-06-06 00:10:00 (UTC)
* 終了   : 2026-06-06 00:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host03-002 active_connections の推移](charts/EVT-20260606-host03-002.svg)

# イベントID( EVT-20260606-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→10→…→14→12→13→11
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host03-003 active_connections の推移](charts/EVT-20260606-host03-003.svg)

# イベントID( EVT-20260606-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→13→15→11→…→10→12→10→12
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 20:20:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260606-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260606-host03-004 active_connections の推移](charts/EVT-20260606-host03-004.svg)

# イベントID( EVT-20260606-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→12→…→14→13→14→13
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.059, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host03-005 active_connections の推移](charts/EVT-20260606-host03-005.svg)

# イベントID( EVT-20260606-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→9→…→11→12→11→13
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.379, 限界=2.67)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host03-006 active_connections の推移](charts/EVT-20260606-host03-006.svg)

# イベントID( EVT-20260606-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→12→…→12→11→13→12
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 18:10:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.644)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260606-host03-007 active_connections の推移](charts/EVT-20260606-host03-007.svg)

# イベントID( EVT-20260606-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→12→…→11→10→12→10
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.028, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host03-008 active_connections の推移](charts/EVT-20260606-host03-008.svg)

# イベントID( EVT-20260607-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→13→17→13→14
* 開始   : 2026-06-07 07:35:00 (UTC)
* 終了   : 2026-06-07 07:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host03-004 active_connections の推移](charts/EVT-20260607-host03-004.svg)

# イベントID( EVT-20260607-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→15→18→10→…→18→10→16→14
* 開始   : 2026-06-07 15:35:00 (UTC)
* 終了   : 2026-06-07 15:40:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host03-007 active_connections の推移](charts/EVT-20260607-host03-007.svg)

# イベントID( EVT-20260607-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→8→11→12
* 開始   : 2026-06-07 18:30:00 (UTC)
* 終了   : 2026-06-07 18:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host03-009 active_connections の推移](charts/EVT-20260607-host03-009.svg)

# イベントID( EVT-20260609-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→13→17→14→11
* 開始   : 2026-06-09 05:30:00 (UTC)
* 終了   : 2026-06-09 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-003 active_connections の推移](charts/EVT-20260609-host03-003.svg)

# イベントID( EVT-20260609-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→21→23→18→18
* 開始   : 2026-06-09 08:20:00 (UTC)
* 終了   : 2026-06-09 08:20:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.126σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-004 active_connections の推移](charts/EVT-20260609-host03-004.svg)

# イベントID( EVT-20260609-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→19→23→17→21
* 開始   : 2026-06-09 08:25:00 (UTC)
* 終了   : 2026-06-09 08:25:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host03-005 active_connections の推移](charts/EVT-20260609-host03-005.svg)

# イベントID( EVT-20260609-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→22→26→21→…→21→18→20→23
* 開始   : 2026-06-09 13:55:00 (UTC)
* 終了   : 2026-06-09 14:15:00 (UTC)
* 現象   : 2026-06-09 14:15:00 (UTC)を境に水準が 14.94から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.789, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→19→14→18→18
* 開始   : 2026-06-09 16:25:00 (UTC)
* 終了   : 2026-06-09 16:25:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host03-010 active_connections の推移](charts/EVT-20260609-host03-010.svg)

# イベントID( EVT-20260609-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→18→13→14→15
* 開始   : 2026-06-09 17:15:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host03-011 active_connections の推移](charts/EVT-20260609-host03-011.svg)

# イベントID( EVT-20260609-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→9→5→11→12
* 開始   : 2026-06-09 22:00:00 (UTC)
* 終了   : 2026-06-09 22:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→10→13→9→10
* 開始   : 2026-06-10 02:25:00 (UTC)
* 終了   : 2026-06-10 02:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-001 active_connections の推移](charts/EVT-20260610-host03-001.svg)

# イベントID( EVT-20260610-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→19→17→22→23→21→21
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:45:00 (UTC)
* 現象   : 2026-06-10 08:45:00 (UTC)を境に水準が 15.03から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→17→12→15→17
* 開始   : 2026-06-10 17:45:00 (UTC)
* 終了   : 2026-06-10 17:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-005 active_connections の推移](charts/EVT-20260610-host03-005.svg)

# イベントID( EVT-20260610-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→8→9
* 開始   : 2026-06-10 21:25:00 (UTC)
* 終了   : 2026-06-10 21:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.415σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host03-007 active_connections の推移](charts/EVT-20260610-host03-007.svg)

# イベントID( EVT-20260611-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→14→19→15→15
* 開始   : 2026-06-11 05:55:00 (UTC)
* 終了   : 2026-06-11 05:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.434倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260611-host03-003 active_connections の推移](charts/EVT-20260611-host03-003.svg)

# イベントID( EVT-20260611-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→22→23→22→22→21→21→22
* 開始   : 2026-06-11 14:05:00 (UTC)
* 終了   : 2026-06-11 15:05:00 (UTC)
* 現象   : 2026-06-11 15:05:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→12→9→14→14
* 開始   : 2026-06-11 19:25:00 (UTC)
* 終了   : 2026-06-11 19:25:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.475σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host03-013 active_connections の推移](charts/EVT-20260611-host03-013.svg)

# イベントID( EVT-20260612-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→21→26→22→21
* 開始   : 2026-06-12 11:40:00 (UTC)
* 終了   : 2026-06-12 11:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→20→15→16→20→15→16
* 開始   : 2026-06-12 17:10:00 (UTC)
* 終了   : 2026-06-12 17:50:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-010 active_connections の推移](charts/EVT-20260612-host03-010.svg)

# イベントID( EVT-20260612-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→18→14→18→14→17→16
* 開始   : 2026-06-12 17:10:00 (UTC)
* 終了   : 2026-06-12 18:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260612-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host03-011 active_connections の推移](charts/EVT-20260612-host03-011.svg)

# イベントID( EVT-20260613-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→8→9
* 開始   : 2026-06-13 00:50:00 (UTC)
* 終了   : 2026-06-13 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-lsfhost01-001 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260613-host03-002 active_connections の推移](charts/EVT-20260613-host03-002.svg)

# イベントID( EVT-20260613-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→11→…→10→11→12→13
* 開始   : 2026-06-13 04:05:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host03-003 active_connections の推移](charts/EVT-20260613-host03-003.svg)

# イベントID( EVT-20260613-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→10→…→11→13→14→11
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.67)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host03-004 active_connections の推移](charts/EVT-20260613-host03-004.svg)

# イベントID( EVT-20260613-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→13→…→14→13→14→13
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.57σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.676, 限界=2.644)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host03-005 active_connections の推移](charts/EVT-20260613-host03-005.svg)

# イベントID( EVT-20260613-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→14→9→12→…→14→11→14→13
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.978, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host03-006 active_connections の推移](charts/EVT-20260613-host03-006.svg)

# イベントID( EVT-20260613-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→11→…→12→10→12→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.324, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host03-007 active_connections の推移](charts/EVT-20260613-host03-007.svg)

# イベントID( EVT-20260613-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→14→…→14→15→12→14
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host03-008 active_connections の推移](charts/EVT-20260613-host03-008.svg)

# イベントID( EVT-20260614-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→14→13
* 開始   : 2026-06-14 07:55:00 (UTC)
* 終了   : 2026-06-14 07:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.126σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→16→…→15→14→15→16
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 21:25:00 (UTC)
* 現象   : 2026-06-15 21:25:00 (UTC)を境に水準が 11.8から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.929, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-004 active_connections の推移](charts/EVT-20260615-host03-004.svg)

# イベントID( EVT-20260616-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→15→…→15→19→14→16
* 開始   : 2026-06-16 06:05:00 (UTC)
* 終了   : 2026-06-16 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.724σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host03-002 active_connections の推移](charts/EVT-20260616-host03-002.svg)

# イベントID( EVT-20260616-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→19→…→20→19→17→15
* 開始   : 2026-06-16 06:30:00 (UTC)
* 終了   : 2026-06-16 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.533σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host03-003 active_connections の推移](charts/EVT-20260616-host03-003.svg)

# イベントID( EVT-20260616-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→21→26→21→22
* 開始   : 2026-06-16 11:25:00 (UTC)
* 終了   : 2026-06-16 11:25:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.475σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host03-006 active_connections の推移](charts/EVT-20260616-host03-006.svg)

# イベントID( EVT-20260616-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→22→17→21→20
* 開始   : 2026-06-16 13:25:00 (UTC)
* 終了   : 2026-06-16 13:25:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host03-007 active_connections の推移](charts/EVT-20260616-host03-007.svg)

# イベントID( EVT-20260616-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→17→12→17→16
* 開始   : 2026-06-16 17:35:00 (UTC)
* 終了   : 2026-06-16 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6923(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.718σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host03-009 active_connections の推移](charts/EVT-20260616-host03-009.svg)

# イベントID( EVT-20260616-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→15→11→12→15→11→12→14
* 開始   : 2026-06-16 18:25:00 (UTC)
* 終了   : 2026-06-16 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host03-010 active_connections の推移](charts/EVT-20260616-host03-010.svg)

# イベントID( EVT-20260617-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→12→15→12→12
* 開始   : 2026-06-17 03:40:00 (UTC)
* 終了   : 2026-06-17 03:40:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-002 active_connections の推移](charts/EVT-20260617-host03-002.svg)

# イベントID( EVT-20260617-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→18→21→18→19
* 開始   : 2026-06-17 07:15:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-003 active_connections の推移](charts/EVT-20260617-host03-003.svg)

# イベントID( EVT-20260617-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→11→6→10→9
* 開始   : 2026-06-17 21:25:00 (UTC)
* 終了   : 2026-06-17 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→12→…→16→13→17→14
* 開始   : 2026-06-18 04:45:00 (UTC)
* 終了   : 2026-06-18 05:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260618-host03-001 active_connections の推移](charts/EVT-20260618-host03-001.svg)

# イベントID( EVT-20260618-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→19→22→18→18
* 開始   : 2026-06-18 07:45:00 (UTC)
* 終了   : 2026-06-18 07:45:00 (UTC)
* 現象   : 平常時(17)に対し 1.294倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-003 active_connections の推移](charts/EVT-20260618-host03-003.svg)

# イベントID( EVT-20260618-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→19→26→23→21
* 開始   : 2026-06-18 12:10:00 (UTC)
* 終了   : 2026-06-18 12:10:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host03-004 active_connections の推移](charts/EVT-20260618-host03-004.svg)

# イベントID( EVT-20260618-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 23→20→19→21→20→19→21
* 開始   : 2026-06-18 13:45:00 (UTC)
* 終了   : 2026-06-18 14:20:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260618-host14-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host03-005 active_connections の推移](charts/EVT-20260618-host03-005.svg)

# イベントID( EVT-20260619-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→13→15
* 開始   : 2026-06-19 06:00:00 (UTC)
* 終了   : 2026-06-19 06:00:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.531σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host03-003 active_connections の推移](charts/EVT-20260619-host03-003.svg)

# イベントID( EVT-20260619-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→18→20→19→…→19→13→17→16
* 開始   : 2026-06-19 07:05:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260619-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host03-004 active_connections の推移](charts/EVT-20260619-host03-004.svg)

# イベントID( EVT-20260619-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→16→21→17→16
* 開始   : 2026-06-19 07:30:00 (UTC)
* 終了   : 2026-06-19 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host03-005 active_connections の推移](charts/EVT-20260619-host03-005.svg)

# イベントID( EVT-20260619-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→23→25→20→20
* 開始   : 2026-06-19 09:55:00 (UTC)
* 終了   : 2026-06-19 09:55:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-008 active_connections の推移](charts/EVT-20260619-host03-008.svg)

# イベントID( EVT-20260619-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 22→20→14→18→18
* 開始   : 2026-06-19 16:10:00 (UTC)
* 終了   : 2026-06-19 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.721(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-012 active_connections の推移](charts/EVT-20260619-host03-012.svg)

# イベントID( EVT-20260619-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→10→13→12→10→13
* 開始   : 2026-06-19 18:55:00 (UTC)
* 終了   : 2026-06-19 19:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260619-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-015 active_connections の推移](charts/EVT-20260619-host03-015.svg)

# イベントID( EVT-20260620-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→14→…→11→12→11→13
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.902, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host03-002 active_connections の推移](charts/EVT-20260620-host03-002.svg)

# イベントID( EVT-20260620-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→11→…→13→10→14→13
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.824, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host03-003 active_connections の推移](charts/EVT-20260620-host03-003.svg)

# イベントID( EVT-20260620-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→11→10→11→…→11→12→11→12
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 20:20:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.644)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260620-host03-004 active_connections の推移](charts/EVT-20260620-host03-004.svg)

# イベントID( EVT-20260620-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→10→11→13→…→11→12→13→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.058, 限界=2.67)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260620-host03-005 active_connections の推移](charts/EVT-20260620-host03-005.svg)

# イベントID( EVT-20260620-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→13→12→11→…→11→9→12→11
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.693, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host03-006 active_connections の推移](charts/EVT-20260620-host03-006.svg)

# イベントID( EVT-20260620-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→11→…→15→14→12→13
* 開始   : 2026-06-20 06:25:00 (UTC)
* 終了   : 2026-06-20 17:50:00 (UTC)
* 現象   : 11.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.962, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.4 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.4 時間

![EVT-20260620-host03-007 active_connections の推移](charts/EVT-20260620-host03-007.svg)

# イベントID( EVT-20260621-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→9→9
* 開始   : 2026-06-21 02:45:00 (UTC)
* 終了   : 2026-06-21 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→11→5→9→…→9→6→10→9
* 開始   : 2026-06-21 20:45:00 (UTC)
* 終了   : 2026-06-21 20:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.4918(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.592σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host03-007 active_connections の推移](charts/EVT-20260621-host03-007.svg)

# イベントID( EVT-20260622-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→7→8
* 開始   : 2026-06-22 00:50:00 (UTC)
* 終了   : 2026-06-22 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host03-001 active_connections の推移](charts/EVT-20260622-host03-001.svg)

# イベントID( EVT-20260622-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→13→…→14→15→11→13
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 21:05:00 (UTC)
* 現象   : 2026-06-22 21:05:00 (UTC)を境に水準が 11.83から14.83へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-002 active_connections の推移](charts/EVT-20260622-host03-002.svg)

# イベントID( EVT-20260622-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→11→5→7→7
* 開始   : 2026-06-22 22:40:00 (UTC)
* 終了   : 2026-06-22 22:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.068σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→14→12→15→14→12→15→13→11
* 開始   : 2026-06-23 03:50:00 (UTC)
* 終了   : 2026-06-23 04:00:00 (UTC)
* 現象   : 平常時(10)に対し 1.4倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.809σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-003 active_connections の推移](charts/EVT-20260623-host03-003.svg)

# イベントID( EVT-20260623-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→15→20→17→18
* 開始   : 2026-06-23 06:50:00 (UTC)
* 終了   : 2026-06-23 06:50:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-006 active_connections の推移](charts/EVT-20260623-host03-006.svg)

# イベントID( EVT-20260623-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→19→20→23→18→18→21
* 開始   : 2026-06-23 07:50:00 (UTC)
* 終了   : 2026-06-23 08:20:00 (UTC)
* 現象   : 2026-06-23 08:20:00 (UTC)を境に水準が 15.01から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.647σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host03-007 active_connections の推移](charts/EVT-20260623-host03-007.svg)

# イベントID( EVT-20260623-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→11→13→10→11→14
* 開始   : 2026-06-23 18:40:00 (UTC)
* 終了   : 2026-06-23 18:45:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host03-009 active_connections の推移](charts/EVT-20260623-host03-009.svg)

# イベントID( EVT-20260623-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→11→6→9→10
* 開始   : 2026-06-23 21:05:00 (UTC)
* 終了   : 2026-06-23 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-010 active_connections の推移](charts/EVT-20260623-host03-010.svg)

# イベントID( EVT-20260624-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→8→12→6→7
* 開始   : 2026-06-24 00:15:00 (UTC)
* 終了   : 2026-06-24 00:15:00 (UTC)
* 現象   : 平常時(7.25)に対し 1.655倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host03-001 active_connections の推移](charts/EVT-20260624-host03-001.svg)

# イベントID( EVT-20260624-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→10→14→10→11
* 開始   : 2026-06-24 03:00:00 (UTC)
* 終了   : 2026-06-24 03:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→20→17→21→20
* 開始   : 2026-06-24 15:05:00 (UTC)
* 終了   : 2026-06-24 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→14→9→13→13
* 開始   : 2026-06-24 18:55:00 (UTC)
* 終了   : 2026-06-24 18:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6171(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.88σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host03-008 active_connections の推移](charts/EVT-20260624-host03-008.svg)

# イベントID( EVT-20260624-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→14→11
* 開始   : 2026-06-24 19:20:00 (UTC)
* 終了   : 2026-06-24 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-064 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260624-host03-009 active_connections の推移](charts/EVT-20260624-host03-009.svg)

# イベントID( EVT-20260625-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→10→15→10→12
* 開始   : 2026-06-25 02:55:00 (UTC)
* 終了   : 2026-06-25 02:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.82σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host03-001 active_connections の推移](charts/EVT-20260625-host03-001.svg)

# イベントID( EVT-20260625-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→19→…→17→19→15→16
* 開始   : 2026-06-25 06:10:00 (UTC)
* 終了   : 2026-06-25 06:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host03-003 active_connections の推移](charts/EVT-20260625-host03-003.svg)

# イベントID( EVT-20260625-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→21→16→19→18
* 開始   : 2026-06-25 15:35:00 (UTC)
* 終了   : 2026-06-25 15:35:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host03-008 active_connections の推移](charts/EVT-20260625-host03-008.svg)

# イベントID( EVT-20260625-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→16→14→18→17
* 開始   : 2026-06-25 16:45:00 (UTC)
* 終了   : 2026-06-25 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host03-009 active_connections の推移](charts/EVT-20260625-host03-009.svg)

# イベントID( EVT-20260625-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→13→10→13→10→13→15
* 開始   : 2026-06-25 19:25:00 (UTC)
* 終了   : 2026-06-25 20:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-host09-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260625-host03-010 active_connections の推移](charts/EVT-20260625-host03-010.svg)

# イベントID( EVT-20260625-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→10→7→9→10
* 開始   : 2026-06-25 20:30:00 (UTC)
* 終了   : 2026-06-25 20:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host03-013 active_connections の推移](charts/EVT-20260625-host03-013.svg)

# イベントID( EVT-20260626-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→21→24→21→20
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.357σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-004 active_connections の推移](charts/EVT-20260626-host03-004.svg)

# イベントID( EVT-20260626-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→20→25→21→21
* 開始   : 2026-06-26 09:30:00 (UTC)
* 終了   : 2026-06-26 09:30:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-005 active_connections の推移](charts/EVT-20260626-host03-005.svg)

# イベントID( EVT-20260626-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→21→17→20→22
* 開始   : 2026-06-26 14:15:00 (UTC)
* 終了   : 2026-06-26 14:15:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host03-007 active_connections の推移](charts/EVT-20260626-host03-007.svg)

# イベントID( EVT-20260626-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→22→16→18→19
* 開始   : 2026-06-26 15:40:00 (UTC)
* 終了   : 2026-06-26 15:40:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host03-008 active_connections の推移](charts/EVT-20260626-host03-008.svg)

# イベントID( EVT-20260626-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→16→10→14→10→14→10→14→12
* 開始   : 2026-06-26 18:50:00 (UTC)
* 終了   : 2026-06-26 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host03-013 active_connections の推移](charts/EVT-20260626-host03-013.svg)

# イベントID( EVT-20260627-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→13→…→12→10→12→11
* 開始   : 2026-06-27 04:35:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.683, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.6 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260627-host03-002 active_connections の推移](charts/EVT-20260627-host03-002.svg)

# イベントID( EVT-20260627-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→9→11→9→…→12→14→12→13
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.393, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host03-003 active_connections の推移](charts/EVT-20260627-host03-003.svg)

# イベントID( EVT-20260627-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→12→…→12→13→11→13
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:10:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.67)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間

![EVT-20260627-host03-004 active_connections の推移](charts/EVT-20260627-host03-004.svg)

# イベントID( EVT-20260627-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→9→13→12→…→11→12→13→12
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.014, 限界=2.644)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260627-host03-005 active_connections の推移](charts/EVT-20260627-host03-005.svg)

# イベントID( EVT-20260627-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→13→…→14→12→13→12
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 18:40:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260627-host03-006 active_connections の推移](charts/EVT-20260627-host03-006.svg)

# イベントID( EVT-20260627-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→13→12→11→…→13→12→11→13
* 開始   : 2026-06-27 06:35:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.271, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host03-007 active_connections の推移](charts/EVT-20260627-host03-007.svg)

# イベントID( EVT-20260627-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→7→11→9
* 開始   : 2026-06-27 19:55:00 (UTC)
* 終了   : 2026-06-27 19:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260627-host03-008 active_connections の推移](charts/EVT-20260627-host03-008.svg)

# イベントID( EVT-20260628-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→11→17→13→10
* 開始   : 2026-06-28 06:15:00 (UTC)
* 終了   : 2026-06-28 06:15:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.687σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host03-001 active_connections の推移](charts/EVT-20260628-host03-001.svg)

# イベントID( EVT-20260628-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→10→7→11→11
* 開始   : 2026-06-28 19:00:00 (UTC)
* 終了   : 2026-06-28 19:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host03-006 active_connections の推移](charts/EVT-20260628-host03-006.svg)

# イベントID( EVT-20260629-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→14→13→15→…→15→14→16→15
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.79から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.657)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-001 active_connections の推移](charts/EVT-20260629-host03-001.svg)

# イベントID( EVT-20260629-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→15→…→16→14→12→14
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 19:50:00 (UTC)
* 現象   : 2026-06-29 19:50:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.927, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-002 active_connections の推移](charts/EVT-20260629-host03-002.svg)

# イベントID( EVT-20260629-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→15→…→13→12→11→14
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.76から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.132, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-003 active_connections の推移](charts/EVT-20260629-host03-003.svg)

# イベントID( EVT-20260630-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→20→19→…→20→19→18→16
* 開始   : 2026-06-30 07:15:00 (UTC)
* 終了   : 2026-06-30 07:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-002 active_connections の推移](charts/EVT-20260630-host03-002.svg)

# イベントID( EVT-20260630-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→18→12→17→15
* 開始   : 2026-06-30 17:30:00 (UTC)
* 終了   : 2026-06-30 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-005 active_connections の推移](charts/EVT-20260630-host03-005.svg)

# イベントID( EVT-20260630-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→11→…→12→11→14→15
* 開始   : 2026-06-30 18:25:00 (UTC)
* 終了   : 2026-06-30 18:30:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260630-host03-006 active_connections の推移](charts/EVT-20260630-host03-006.svg)

# イベントID( EVT-20260630-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 6→5→12→8→7
* 開始   : 2026-06-30 23:20:00 (UTC)
* 終了   : 2026-06-30 23:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.068σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-009 active_connections の推移](charts/EVT-20260630-host03-009.svg)

# イベントID( EVT-20260601-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→20→23→21→23→21→23→22
* 開始   : 2026-06-01 09:05:00 (UTC)
* 終了   : 2026-06-01 09:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→12→…→12→9→11→12
* 開始   : 2026-06-01 19:45:00 (UTC)
* 終了   : 2026-06-01 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260601-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→8→6→10→8→6→10→9
* 開始   : 2026-06-01 22:20:00 (UTC)
* 終了   : 2026-06-01 22:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→10→11→11→8→12→12
* 開始   : 2026-06-02 01:55:00 (UTC)
* 終了   : 2026-06-02 02:40:00 (UTC)
* 現象   : 2026-06-02 02:40:00 (UTC)を境に水準が 14.95から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→14→11→15→14
* 開始   : 2026-06-02 04:55:00 (UTC)
* 終了   : 2026-06-02 05:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 22→24→19→23→24→19→23→22
* 開始   : 2026-06-02 11:05:00 (UTC)
* 終了   : 2026-06-02 11:10:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 24→24→23→24→25→22→21→21→23
* 開始   : 2026-06-02 11:55:00 (UTC)
* 終了   : 2026-06-02 13:10:00 (UTC)
* 現象   : 2026-06-02 13:10:00 (UTC)を境に水準が 14.97から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.009, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→20→25→20→25→20→22
* 開始   : 2026-06-02 12:00:00 (UTC)
* 終了   : 2026-06-02 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→23→19→16→23→19→16→18→19
* 開始   : 2026-06-02 15:25:00 (UTC)
* 終了   : 2026-06-02 15:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→17→14→16
* 開始   : 2026-06-02 17:15:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→17→14→17→14→17→15
* 開始   : 2026-06-02 17:25:00 (UTC)
* 終了   : 2026-06-02 18:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260602-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→10→12→15→11→10→12
* 開始   : 2026-06-02 19:15:00 (UTC)
* 終了   : 2026-06-02 19:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260602-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→12→9→10→12→9→10
* 開始   : 2026-06-03 02:15:00 (UTC)
* 終了   : 2026-06-03 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→10→13→10→9
* 開始   : 2026-06-03 03:10:00 (UTC)
* 終了   : 2026-06-03 03:15:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→13→17→16→13→17→16→17
* 開始   : 2026-06-03 05:45:00 (UTC)
* 終了   : 2026-06-03 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→19→20→19→19→19→21→22→21
* 開始   : 2026-06-03 07:45:00 (UTC)
* 終了   : 2026-06-03 09:25:00 (UTC)
* 現象   : 2026-06-03 09:25:00 (UTC)を境に水準が 14.84から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.643, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 20→23→25→20→…→20→19→22→21
* 開始   : 2026-06-03 11:45:00 (UTC)
* 終了   : 2026-06-03 11:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 22→21→22→24→22→21→20→22→21
* 開始   : 2026-06-03 13:35:00 (UTC)
* 終了   : 2026-06-03 14:25:00 (UTC)
* 現象   : 2026-06-03 14:25:00 (UTC)を境に水準が 14.98から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→13→11→13→11→13→12
* 開始   : 2026-06-03 18:45:00 (UTC)
* 終了   : 2026-06-03 18:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→12→…→12→8→11→10
* 開始   : 2026-06-03 20:05:00 (UTC)
* 終了   : 2026-06-03 20:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→10→9→12→10
* 開始   : 2026-06-03 20:35:00 (UTC)
* 終了   : 2026-06-03 20:40:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→8→8→7→8→8→9→9→10
* 開始   : 2026-06-04 00:05:00 (UTC)
* 終了   : 2026-06-04 01:00:00 (UTC)
* 現象   : 2026-06-04 01:00:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.65, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→11→14→12→11→14→12→13
* 開始   : 2026-06-04 04:05:00 (UTC)
* 終了   : 2026-06-04 04:10:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→15→…→15→17→12→16
* 開始   : 2026-06-04 05:40:00 (UTC)
* 終了   : 2026-06-04 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260604-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→21→20→19→23→20→20→22→23
* 開始   : 2026-06-04 08:35:00 (UTC)
* 終了   : 2026-06-04 09:50:00 (UTC)
* 現象   : 2026-06-04 09:50:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→22→21→22→…→20→23→19→20
* 開始   : 2026-06-04 08:40:00 (UTC)
* 終了   : 2026-06-04 09:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.547σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→22→23→20→22→23→20→19
* 開始   : 2026-06-04 09:10:00 (UTC)
* 終了   : 2026-06-04 09:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 20→17→18→20→17→18→19
* 開始   : 2026-06-04 15:30:00 (UTC)
* 終了   : 2026-06-04 15:35:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.8193(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→15→14→14→13→12→12→13→14
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 19:45:00 (UTC)
* 現象   : 2026-06-04 19:45:00 (UTC)を境に水準が 14.81から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→6→10→6→10→6→8→10
* 開始   : 2026-06-04 21:35:00 (UTC)
* 終了   : 2026-06-04 21:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.846σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 8→7→11→7→…→7→12→10→6
* 開始   : 2026-06-05 00:50:00 (UTC)
* 終了   : 2026-06-05 01:00:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→13→14→10→14→10→14→12
* 開始   : 2026-06-05 04:10:00 (UTC)
* 終了   : 2026-06-05 04:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→16→17
* 開始   : 2026-06-05 05:30:00 (UTC)
* 終了   : 2026-06-05 05:50:00 (UTC)
* 現象   : 2026-06-05 05:50:00 (UTC)を境に水準が 14.94から14.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.703, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→18→19→…→18→19→17→16
* 開始   : 2026-06-05 06:50:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→24→23→20→24→23→22
* 開始   : 2026-06-05 10:35:00 (UTC)
* 終了   : 2026-06-05 10:40:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.185倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→22→21→22→20→21→20
* 開始   : 2026-06-05 12:25:00 (UTC)
* 終了   : 2026-06-05 14:20:00 (UTC)
* 現象   : 2026-06-05 14:20:00 (UTC)を境に水準が 14.97から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 23→21→21→20→21→23→20→20→22
* 開始   : 2026-06-05 14:10:00 (UTC)
* 終了   : 2026-06-05 15:15:00 (UTC)
* 現象   : 2026-06-05 15:15:00 (UTC)を境に水準が 14.96から12.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.487, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→15→…→15→13→14→13
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 18:05:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→11→15→11→15→11→12→14
* 開始   : 2026-06-05 19:05:00 (UTC)
* 終了   : 2026-06-05 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 7→6→11→5→…→11→5→8→9
* 開始   : 2026-06-06 00:05:00 (UTC)
* 終了   : 2026-06-06 00:10:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→10→11→12
* 開始   : 2026-06-07 03:35:00 (UTC)
* 終了   : 2026-06-07 03:55:00 (UTC)
* 現象   : 2026-06-07 03:55:00 (UTC)を境に水準が 11.79から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.106, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→10→12→9→…→9→13→10→8
* 開始   : 2026-06-07 04:00:00 (UTC)
* 終了   : 2026-06-07 04:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→14→13→13→15
* 開始   : 2026-06-07 06:25:00 (UTC)
* 終了   : 2026-06-07 06:45:00 (UTC)
* 現象   : 2026-06-07 06:45:00 (UTC)を境に水準が 11.89から12.26へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→15→13→13→14→15→15→15→17
* 開始   : 2026-06-07 07:40:00 (UTC)
* 終了   : 2026-06-07 08:55:00 (UTC)
* 現象   : 2026-06-07 08:55:00 (UTC)を境に水準が 11.8から12.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→17→11→16→11→16→11→16→14
* 開始   : 2026-06-07 09:05:00 (UTC)
* 終了   : 2026-06-07 09:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260607-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→17→13→11→17→13→12
* 開始   : 2026-06-07 16:20:00 (UTC)
* 終了   : 2026-06-07 16:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→9→10→9→9→9→9
* 開始   : 2026-06-08 21:35:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 15から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 6→10→6→10→6→10→8
* 開始   : 2026-06-09 00:45:00 (UTC)
* 終了   : 2026-06-09 00:55:00 (UTC)
* 現象   : 平常時(6.917)に対し 1.446倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260609-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→12→15→12→15→12→14
* 開始   : 2026-06-09 04:50:00 (UTC)
* 終了   : 2026-06-09 04:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→19→23→19→23→19→23→21→22
* 開始   : 2026-06-09 09:25:00 (UTC)
* 終了   : 2026-06-09 09:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 24→24→23→22→23→21→24
* 開始   : 2026-06-09 12:10:00 (UTC)
* 終了   : 2026-06-09 12:40:00 (UTC)
* 現象   : 2026-06-09 12:40:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 22→20→18→22→18→22→18→19→21
* 開始   : 2026-06-09 14:35:00 (UTC)
* 終了   : 2026-06-09 14:45:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→14→12→14→12→15→13
* 開始   : 2026-06-09 18:20:00 (UTC)
* 終了   : 2026-06-09 18:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→11→15→10→11→15→10→13→14
* 開始   : 2026-06-09 19:10:00 (UTC)
* 終了   : 2026-06-09 19:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→16→11→13→…→13→10→11→12
* 開始   : 2026-06-09 19:20:00 (UTC)
* 終了   : 2026-06-09 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→9→9→9→8→9→7→8
* 開始   : 2026-06-09 23:45:00 (UTC)
* 終了   : 2026-06-10 00:20:00 (UTC)
* 現象   : 2026-06-10 00:20:00 (UTC)を境に水準が 14.85から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→17→15→18→17→15→18→16→15
* 開始   : 2026-06-10 05:55:00 (UTC)
* 終了   : 2026-06-10 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→23→18→…→18→17→20→18
* 開始   : 2026-06-10 15:30:00 (UTC)
* 終了   : 2026-06-10 15:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→9→11→8→9→11→8→11→10
* 開始   : 2026-06-10 20:05:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→7→10→9→9→11
* 開始   : 2026-06-10 23:15:00 (UTC)
* 終了   : 2026-06-10 23:40:00 (UTC)
* 現象   : 2026-06-10 23:40:00 (UTC)を境に水準が 15.03から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→7→11→7→…→7→12→8→7
* 開始   : 2026-06-11 00:55:00 (UTC)
* 終了   : 2026-06-11 01:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→9→12→9→12→9→12→10→8
* 開始   : 2026-06-11 02:35:00 (UTC)
* 終了   : 2026-06-11 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→14→…→14→18→14→15
* 開始   : 2026-06-11 06:00:00 (UTC)
* 終了   : 2026-06-11 06:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 18→20→22→15→…→22→15→18→17
* 開始   : 2026-06-11 08:35:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 22→21→20→22→21→21→22→23
* 開始   : 2026-06-11 09:35:00 (UTC)
* 終了   : 2026-06-11 10:10:00 (UTC)
* 現象   : 2026-06-11 10:10:00 (UTC)を境に水準が 14.84から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→21→24→21→24→21→24→21
* 開始   : 2026-06-11 10:40:00 (UTC)
* 終了   : 2026-06-11 10:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260611-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→18→17→16→17→21
* 開始   : 2026-06-11 16:45:00 (UTC)
* 終了   : 2026-06-11 17:15:00 (UTC)
* 現象   : 2026-06-11 17:15:00 (UTC)を境に水準が 14.99から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→17→15→14→17→15→14→17
* 開始   : 2026-06-11 16:50:00 (UTC)
* 終了   : 2026-06-11 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→18→15→17→18→15→17→16
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→13→15→12→13→15→12→13→15
* 開始   : 2026-06-11 18:00:00 (UTC)
* 終了   : 2026-06-11 18:10:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→6→5→8→…→8→11→8→6
* 開始   : 2026-06-12 00:35:00 (UTC)
* 終了   : 2026-06-12 00:45:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 5→6→10→8→…→8→11→7→9
* 開始   : 2026-06-12 00:45:00 (UTC)
* 終了   : 2026-06-12 00:55:00 (UTC)
* 現象   : 平常時(7.083)に対し 1.412倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→10→9→11→11→10→11→12→13
* 開始   : 2026-06-12 02:15:00 (UTC)
* 終了   : 2026-06-12 02:55:00 (UTC)
* 現象   : 2026-06-12 02:55:00 (UTC)を境に水準が 15から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→10→13→12→10→13→12→11
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 03:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.547σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→16→13→16→13→16→13→15
* 開始   : 2026-06-12 05:00:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.836σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→15→17
* 開始   : 2026-06-12 05:15:00 (UTC)
* 終了   : 2026-06-12 05:30:00 (UTC)
* 現象   : 2026-06-12 05:30:00 (UTC)を境に水準が 15.1から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.052, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 23→23→23→22→25→23→22
* 開始   : 2026-06-12 13:15:00 (UTC)
* 終了   : 2026-06-12 13:45:00 (UTC)
* 現象   : 2026-06-12 13:45:00 (UTC)を境に水準が 14.95から13.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→17→20→17→…→19→20→17→19
* 開始   : 2026-06-12 15:15:00 (UTC)
* 終了   : 2026-06-12 15:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→16→15→14→16→14→15→15→13
* 開始   : 2026-06-12 17:50:00 (UTC)
* 終了   : 2026-06-12 18:35:00 (UTC)
* 現象   : 2026-06-12 18:35:00 (UTC)を境に水準が 14.81から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→14→15→11→14→13
* 開始   : 2026-06-12 19:05:00 (UTC)
* 終了   : 2026-06-12 19:10:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260612-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→9→11→9→13→10
* 開始   : 2026-06-12 19:45:00 (UTC)
* 終了   : 2026-06-12 19:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→10→4→10→…→10→11→9→10
* 開始   : 2026-06-13 00:50:00 (UTC)
* 終了   : 2026-06-13 01:00:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.4898(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.894σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-001 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260613-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→6→12→6→12→6→7→9
* 開始   : 2026-06-13 20:35:00 (UTC)
* 終了   : 2026-06-13 20:45:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.605(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260613-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→11→8→9→5→11→8
* 開始   : 2026-06-14 00:35:00 (UTC)
* 終了   : 2026-06-14 00:40:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→12→16→10→…→16→10→16→13
* 開始   : 2026-06-14 08:10:00 (UTC)
* 終了   : 2026-06-14 08:15:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260614-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→17→…→11→17→13→15
* 開始   : 2026-06-14 09:05:00 (UTC)
* 終了   : 2026-06-14 09:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→18→15→17→18
* 開始   : 2026-06-14 09:55:00 (UTC)
* 終了   : 2026-06-14 10:25:00 (UTC)
* 現象   : 2026-06-14 10:25:00 (UTC)を境に水準が 11.91から13.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→16→17→16→15→18
* 開始   : 2026-06-14 10:45:00 (UTC)
* 終了   : 2026-06-14 11:10:00 (UTC)
* 現象   : 2026-06-14 11:10:00 (UTC)を境に水準が 11.91から13.28へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→10→7→11→10→7→11→9
* 開始   : 2026-06-14 20:10:00 (UTC)
* 終了   : 2026-06-14 20:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260614-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→13→15→13→15→13→15→13→11
* 開始   : 2026-06-16 04:15:00 (UTC)
* 終了   : 2026-06-16 04:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→17→19→21→17→18
* 開始   : 2026-06-16 08:00:00 (UTC)
* 終了   : 2026-06-16 08:05:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→19→24→23→19→24→23→22
* 開始   : 2026-06-16 10:15:00 (UTC)
* 終了   : 2026-06-16 10:20:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.195倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→22→16→18→16→18→16→19→21
* 開始   : 2026-06-16 16:05:00 (UTC)
* 終了   : 2026-06-16 16:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→14→12→14→11→11
* 開始   : 2026-06-16 19:55:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 2026-06-16 21:00:00 (UTC)を境に水準が 14.96から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→9→7→10→…→10→6→10→7
* 開始   : 2026-06-16 21:00:00 (UTC)
* 終了   : 2026-06-16 21:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 45 分
  - EVT-20260616-host06-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→9→7→6→9→7→6→9→7
* 開始   : 2026-06-16 22:05:00 (UTC)
* 終了   : 2026-06-16 22:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 7→5→9→11→5→9→11→9→8
* 開始   : 2026-06-17 01:10:00 (UTC)
* 終了   : 2026-06-17 01:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→14→…→15→14→15→17
* 開始   : 2026-06-17 17:15:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→19→18→19→18
* 開始   : 2026-06-18 07:00:00 (UTC)
* 終了   : 2026-06-18 07:10:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 22→21→19→20→20→23
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 15:20:00 (UTC)
* 現象   : 2026-06-18 15:20:00 (UTC)を境に水準が 14.9から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→20→17→15→17→18→16→17
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:40:00 (UTC)
* 現象   : 2026-06-18 17:40:00 (UTC)を境に水準が 14.96から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→16→13→16→13→15→16
* 開始   : 2026-06-18 17:40:00 (UTC)
* 終了   : 2026-06-18 17:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→10→13→9→10→13→9→10
* 開始   : 2026-06-18 19:50:00 (UTC)
* 終了   : 2026-06-18 20:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→13→9→13→12→10
* 開始   : 2026-06-19 03:05:00 (UTC)
* 終了   : 2026-06-19 03:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→17→14→17→14→16
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→18→19→20→18→19→19→20→20
* 開始   : 2026-06-19 07:30:00 (UTC)
* 終了   : 2026-06-19 08:20:00 (UTC)
* 現象   : 2026-06-19 08:20:00 (UTC)を境に水準が 14.9から14.39へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.892, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→22→23→23→22→24→22→23→24
* 開始   : 2026-06-19 09:15:00 (UTC)
* 終了   : 2026-06-19 12:30:00 (UTC)
* 現象   : 2026-06-19 12:30:00 (UTC)を境に水準が 14.94から13.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.096, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→20→23→22→20→23→22→20
* 開始   : 2026-06-19 10:15:00 (UTC)
* 終了   : 2026-06-19 10:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→25→23→21→25→23→22
* 開始   : 2026-06-19 12:50:00 (UTC)
* 終了   : 2026-06-19 12:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→18→16→19→…→20→16→19→18
* 開始   : 2026-06-19 15:45:00 (UTC)
* 終了   : 2026-06-19 16:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→16→14→17→16
* 開始   : 2026-06-19 17:15:00 (UTC)
* 終了   : 2026-06-19 17:20:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→14→…→14→12→14→12
* 開始   : 2026-06-19 18:10:00 (UTC)
* 終了   : 2026-06-19 18:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260619-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 7→10→5→10→…→10→11→9→8
* 開始   : 2026-06-20 02:40:00 (UTC)
* 終了   : 2026-06-20 02:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→9→8→10
* 開始   : 2026-06-20 20:35:00 (UTC)
* 終了   : 2026-06-20 20:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.011, 限界=2.67)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→6→11→9→11→9→11→7
* 開始   : 2026-06-21 01:45:00 (UTC)
* 終了   : 2026-06-21 01:55:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→12→14→14→15→12→14→14
* 開始   : 2026-06-21 06:25:00 (UTC)
* 終了   : 2026-06-21 07:20:00 (UTC)
* 現象   : 2026-06-21 07:20:00 (UTC)を境に水準が 11.99から12.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.155, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→12→15→16→14→13→15
* 開始   : 2026-06-21 15:20:00 (UTC)
* 終了   : 2026-06-21 16:15:00 (UTC)
* 現象   : 2026-06-21 16:15:00 (UTC)を境に水準が 11.87から14.6へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→16→11→15→11→15→11→15→13
* 開始   : 2026-06-21 15:50:00 (UTC)
* 終了   : 2026-06-21 16:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→12→9→12→9→11→10
* 開始   : 2026-06-21 18:10:00 (UTC)
* 終了   : 2026-06-21 18:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260621-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260621-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260621-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 7→10→6→9→6→9→6→8→9
* 開始   : 2026-06-21 20:55:00 (UTC)
* 終了   : 2026-06-21 21:05:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→10→8→10→9→8→9→9→10
* 開始   : 2026-06-23 00:30:00 (UTC)
* 終了   : 2026-06-23 01:25:00 (UTC)
* 現象   : 2026-06-23 01:25:00 (UTC)を境に水準が 14.9から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→5→11→9→11→9→11→10→9
* 開始   : 2026-06-23 01:00:00 (UTC)
* 終了   : 2026-06-23 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→13→14→15→…→14→15→14→15
* 開始   : 2026-06-23 04:40:00 (UTC)
* 終了   : 2026-06-23 05:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260623-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260623-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→17→16→18→16→18→15→18→19
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 2026-06-23 07:15:00 (UTC)を境に水準が 14.93から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.064, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→20→25→22→25→22→25→20→23
* 開始   : 2026-06-23 13:25:00 (UTC)
* 終了   : 2026-06-23 13:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260623-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→6→9→12→6→9→12→10
* 開始   : 2026-06-24 02:20:00 (UTC)
* 終了   : 2026-06-24 02:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260624-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→23→19→22→23→19→22→19
* 開始   : 2026-06-24 13:05:00 (UTC)
* 終了   : 2026-06-24 13:10:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→12→…→19→12→13→17
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:05:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→12→14→11→12→14→11→14→13
* 開始   : 2026-06-24 18:30:00 (UTC)
* 終了   : 2026-06-24 18:40:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260624-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→10→9→13→14→10→9→13→11
* 開始   : 2026-06-24 19:40:00 (UTC)
* 終了   : 2026-06-24 19:45:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→10→7→8→10→7→8→7
* 開始   : 2026-06-24 21:15:00 (UTC)
* 終了   : 2026-06-24 21:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→11→…→17→11→15→14
* 開始   : 2026-06-25 05:55:00 (UTC)
* 終了   : 2026-06-25 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→16→19→16→19→15→14
* 開始   : 2026-06-25 06:35:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.281倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.926σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→20→21→17→21→17→21→20→21
* 開始   : 2026-06-25 08:20:00 (UTC)
* 終了   : 2026-06-25 08:30:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→21→20→19→20→20→20→22→23
* 開始   : 2026-06-25 08:25:00 (UTC)
* 終了   : 2026-06-25 09:45:00 (UTC)
* 現象   : 2026-06-25 09:45:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→21→20→18→20→20→20
* 開始   : 2026-06-25 14:35:00 (UTC)
* 終了   : 2026-06-25 15:45:00 (UTC)
* 現象   : 2026-06-25 15:45:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→10→14
* 開始   : 2026-06-25 19:45:00 (UTC)
* 終了   : 2026-06-25 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→11→9→8→…→9→8→10→13
* 開始   : 2026-06-25 20:20:00 (UTC)
* 終了   : 2026-06-25 20:25:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→10→11→10→10→10
* 開始   : 2026-06-25 21:15:00 (UTC)
* 終了   : 2026-06-25 21:40:00 (UTC)
* 現象   : 2026-06-25 21:40:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→13→12→7→13→12→7→12→11
* 開始   : 2026-06-26 03:20:00 (UTC)
* 終了   : 2026-06-26 04:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260626-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→16→18→16→18→15
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→19→…→19→20→18→19
* 開始   : 2026-06-26 07:55:00 (UTC)
* 終了   : 2026-06-26 08:05:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→24→19→23→24→19→23→24
* 開始   : 2026-06-26 12:45:00 (UTC)
* 終了   : 2026-06-26 12:50:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260626-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→18→…→18→15→17→18
* 開始   : 2026-06-26 16:30:00 (UTC)
* 終了   : 2026-06-26 16:40:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260626-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260626-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→19→15→17→15→17→15→17→16
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→14→18→14→18→14→17→16
* 開始   : 2026-06-26 17:20:00 (UTC)
* 終了   : 2026-06-26 17:30:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→16→13→16→13
* 開始   : 2026-06-26 17:55:00 (UTC)
* 終了   : 2026-06-26 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→10→12→10→13
* 開始   : 2026-06-26 19:30:00 (UTC)
* 終了   : 2026-06-26 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→8→10→10→10→8→8
* 開始   : 2026-06-26 23:15:00 (UTC)
* 終了   : 2026-06-26 23:45:00 (UTC)
* 現象   : 2026-06-26 23:45:00 (UTC)を境に水準が 14.88から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 6→9→11→8→11→8→11→10→8
* 開始   : 2026-06-27 02:00:00 (UTC)
* 終了   : 2026-06-27 02:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host03-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→7→10→8→7→10
* 開始   : 2026-06-27 21:15:00 (UTC)
* 終了   : 2026-06-27 21:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.684, 限界=2.657)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260627-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→17→15→16→16→17→15→17
* 開始   : 2026-06-28 10:10:00 (UTC)
* 終了   : 2026-06-28 10:45:00 (UTC)
* 現象   : 2026-06-28 10:45:00 (UTC)を境に水準が 11.9から13.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.103, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→11→…→12→11→15→14
* 開始   : 2026-06-28 15:00:00 (UTC)
* 終了   : 2026-06-28 15:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260628-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→16→11→10→…→11→10→15→13
* 開始   : 2026-06-28 16:05:00 (UTC)
* 終了   : 2026-06-28 16:10:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→13→…→13→10→12→13
* 開始   : 2026-06-28 17:05:00 (UTC)
* 終了   : 2026-06-28 17:15:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 7→5→11→10→7→5→11→10→8
* 開始   : 2026-06-29 23:30:00 (UTC)
* 終了   : 2026-06-29 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260629-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→17→…→17→20→19→17
* 開始   : 2026-06-30 07:00:00 (UTC)
* 終了   : 2026-06-30 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→24→21→24→21→24→22→23
* 開始   : 2026-06-30 11:05:00 (UTC)
* 終了   : 2026-06-30 11:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→23→20→22→20→19→19→20
* 開始   : 2026-06-30 14:40:00 (UTC)
* 終了   : 2026-06-30 15:55:00 (UTC)
* 現象   : 2026-06-30 15:55:00 (UTC)を境に水準が 15.02から12.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→17→12→15→12→15→12→15→13
* 開始   : 2026-06-30 18:40:00 (UTC)
* 終了   : 2026-06-30 18:50:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→14→11→10→14→11→10→14→13
* 開始   : 2026-06-30 19:35:00 (UTC)
* 終了   : 2026-06-30 19:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260630-host05-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host03-008 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
