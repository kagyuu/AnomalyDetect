# host10 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host10 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 342 (SEVERE: 21, FATAL: 137, WARN: 184, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 137 | 184 | 342 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→16→14→…→13→12→14→13
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.68から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.322, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-001 active_connections の推移](charts/EVT-20260608-host10-001.svg)

# イベントID( EVT-20260608-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→12→16→15→…→14→15→11→15
* 開始   : 2026-06-08 02:15:00 (UTC)
* 終了   : 2026-06-08 19:20:00 (UTC)
* 現象   : 2026-06-08 19:20:00 (UTC)を境に水準が 11.74から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.248, 限界=2.668)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-002 active_connections の推移](charts/EVT-20260608-host10-002.svg)

# イベントID( EVT-20260608-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→16→…→15→13→15→14
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.74, 限界=2.651)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-003 active_connections の推移](charts/EVT-20260608-host10-003.svg)

# イベントID( EVT-20260608-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→14→17→15→…→11→14→13→12
* 開始   : 2026-06-08 02:25:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.75から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.723)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-004 active_connections の推移](charts/EVT-20260608-host10-004.svg)

# イベントID( EVT-20260608-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→15→…→15→16→15→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 22:45:00 (UTC)
* 現象   : 2026-06-08 22:45:00 (UTC)を境に水準が 11.92から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.765, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.316, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-005 active_connections の推移](charts/EVT-20260608-host10-005.svg)

# イベントID( EVT-20260608-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→14→…→15→12→14→13
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.98から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.415σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-006 active_connections の推移](charts/EVT-20260608-host10-006.svg)

# イベントID( EVT-20260615-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→18→…→13→14→12→13
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 21:15:00 (UTC)
* 現象   : 2026-06-15 21:15:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.734, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-001 active_connections の推移](charts/EVT-20260615-host10-001.svg)

# イベントID( EVT-20260615-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→13→15→17→…→12→15→12→13
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 19:05:00 (UTC)
* 現象   : 2026-06-15 19:05:00 (UTC)を境に水準が 11.93から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.123σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.986, 限界=2.723)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-004 active_connections の推移](charts/EVT-20260615-host10-004.svg)

# イベントID( EVT-20260615-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→14→…→13→14→13→14
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 11.78から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.835, 限界=2.651)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-006 active_connections の推移](charts/EVT-20260615-host10-006.svg)

# イベントID( EVT-20260622-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→15→…→12→13→11→12
* 開始   : 2026-06-22 01:10:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.87から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.714, 限界=2.668)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.414, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-001 active_connections の推移](charts/EVT-20260622-host10-001.svg)

# イベントID( EVT-20260622-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→15→…→13→11→12→10
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 19:25:00 (UTC)
* 現象   : 2026-06-22 19:25:00 (UTC)を境に水準が 11.84から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.651σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.814, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.992, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-002 active_connections の推移](charts/EVT-20260622-host10-002.svg)

# イベントID( EVT-20260622-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→14→12→14→13
* 開始   : 2026-06-22 02:20:00 (UTC)
* 終了   : 2026-06-22 22:25:00 (UTC)
* 現象   : 2026-06-22 22:25:00 (UTC)を境に水準が 11.8から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.893, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-004 active_connections の推移](charts/EVT-20260622-host10-004.svg)

# イベントID( EVT-20260622-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→17→12→16→…→13→14→13→12
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.86から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.719, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.943, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-005 active_connections の推移](charts/EVT-20260622-host10-005.svg)

# イベントID( EVT-20260622-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→18→19→18→…→14→16→13→15
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.299, 限界=2.723)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-006 active_connections の推移](charts/EVT-20260622-host10-006.svg)

# イベントID( EVT-20260622-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→17→…→12→15→13→14
* 開始   : 2026-06-22 04:05:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.159, 限界=2.651)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-007 active_connections の推移](charts/EVT-20260622-host10-007.svg)

# イベントID( EVT-20260629-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→14→…→17→16→13→14
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 21:40:00 (UTC)
* 現象   : 2026-06-29 21:40:00 (UTC)を境に水準が 11.91から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-003 active_connections の推移](charts/EVT-20260629-host10-003.svg)

# イベントID( EVT-20260629-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→12→…→13→12→13→12
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 19:25:00 (UTC)
* 現象   : 2026-06-29 19:25:00 (UTC)を境に水準が 11.79から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.894, 限界=2.651)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-004 active_connections の推移](charts/EVT-20260629-host10-004.svg)

# イベントID( EVT-20260629-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→15→…→14→12→14→11
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.94から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.475σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.93, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-005 active_connections の推移](charts/EVT-20260629-host10-005.svg)

# イベントID( EVT-20260629-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→13→14→10→13
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 21:55:00 (UTC)
* 現象   : 2026-06-29 21:55:00 (UTC)を境に水準が 12.08から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-007 active_connections の推移](charts/EVT-20260629-host10-007.svg)

# イベントID( EVT-20260629-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→17→…→13→16→15→13
* 開始   : 2026-06-29 04:10:00 (UTC)
* 終了   : 2026-06-29 19:10:00 (UTC)
* 現象   : 2026-06-29 19:10:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.372σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.939, 限界=2.723)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-008 active_connections の推移](charts/EVT-20260629-host10-008.svg)

# イベントID( EVT-20260629-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→14→15→16→…→12→14→12→10
* 開始   : 2026-06-29 05:35:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.668)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-009 active_connections の推移](charts/EVT-20260629-host10-009.svg)

# イベントID( EVT-20260601-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→12→16→12→12
* 開始   : 2026-06-01 04:30:00 (UTC)
* 終了   : 2026-06-01 04:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-003 active_connections の推移](charts/EVT-20260601-host10-003.svg)

# イベントID( EVT-20260601-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→15→19→15→16
* 開始   : 2026-06-01 06:00:00 (UTC)
* 終了   : 2026-06-01 06:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host10-004 active_connections の推移](charts/EVT-20260601-host10-004.svg)

# イベントID( EVT-20260601-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→17→17
* 開始   : 2026-06-01 06:30:00 (UTC)
* 終了   : 2026-06-01 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host10-006 active_connections の推移](charts/EVT-20260601-host10-006.svg)

# イベントID( EVT-20260601-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→18→22→18→16
* 開始   : 2026-06-01 07:40:00 (UTC)
* 終了   : 2026-06-01 07:40:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-007 active_connections の推移](charts/EVT-20260601-host10-007.svg)

# イベントID( EVT-20260601-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→23→18→25→…→18→25→22→21
* 開始   : 2026-06-01 10:25:00 (UTC)
* 終了   : 2026-06-01 10:30:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.864(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-008 active_connections の推移](charts/EVT-20260601-host10-008.svg)

# イベントID( EVT-20260601-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→22→26→22→23
* 開始   : 2026-06-01 11:55:00 (UTC)
* 終了   : 2026-06-01 11:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host10-009 active_connections の推移](charts/EVT-20260601-host10-009.svg)

# イベントID( EVT-20260601-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→22→25→27→…→25→27→23→21
* 開始   : 2026-06-01 12:10:00 (UTC)
* 終了   : 2026-06-01 12:15:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分

![EVT-20260601-host10-010 active_connections の推移](charts/EVT-20260601-host10-010.svg)

# イベントID( EVT-20260601-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→18→14→15→18→14→17
* 開始   : 2026-06-01 16:30:00 (UTC)
* 終了   : 2026-06-01 16:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.853σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host10-012 active_connections の推移](charts/EVT-20260601-host10-012.svg)

# イベントID( EVT-20260601-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→17→11→15→16
* 開始   : 2026-06-01 18:20:00 (UTC)
* 終了   : 2026-06-01 18:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-013 active_connections の推移](charts/EVT-20260601-host10-013.svg)

# イベントID( EVT-20260601-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→12→12
* 開始   : 2026-06-01 18:50:00 (UTC)
* 終了   : 2026-06-01 18:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.297σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host10-014 active_connections の推移](charts/EVT-20260601-host10-014.svg)

# イベントID( EVT-20260601-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→10→13
* 開始   : 2026-06-01 20:05:00 (UTC)
* 終了   : 2026-06-01 20:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-015 active_connections の推移](charts/EVT-20260601-host10-015.svg)

# イベントID( EVT-20260602-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→13→16→13→14
* 開始   : 2026-06-02 05:15:00 (UTC)
* 終了   : 2026-06-02 05:15:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-001 active_connections の推移](charts/EVT-20260602-host10-001.svg)

# イベントID( EVT-20260602-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→13→19→15→17
* 開始   : 2026-06-02 06:35:00 (UTC)
* 終了   : 2026-06-02 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host10-003 active_connections の推移](charts/EVT-20260602-host10-003.svg)

# イベントID( EVT-20260602-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→19→22→21→…→22→21→18→19
* 開始   : 2026-06-02 08:05:00 (UTC)
* 終了   : 2026-06-02 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-005 active_connections の推移](charts/EVT-20260602-host10-005.svg)

# イベントID( EVT-20260602-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→19→24→20→…→20→25→20→22
* 開始   : 2026-06-02 09:50:00 (UTC)
* 終了   : 2026-06-02 10:00:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.19倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→23→26→23→21
* 開始   : 2026-06-02 10:55:00 (UTC)
* 終了   : 2026-06-02 10:55:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host10-008 active_connections の推移](charts/EVT-20260602-host10-008.svg)

# イベントID( EVT-20260602-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→22→26→22→21
* 開始   : 2026-06-02 11:00:00 (UTC)
* 終了   : 2026-06-02 11:00:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host10-009 active_connections の推移](charts/EVT-20260602-host10-009.svg)

# イベントID( EVT-20260602-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→21→17→23→22
* 開始   : 2026-06-02 12:10:00 (UTC)
* 終了   : 2026-06-02 12:10:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.356σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host10-010 active_connections の推移](charts/EVT-20260602-host10-010.svg)

# イベントID( EVT-20260602-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→21→17→18→17→18→17→19→18
* 開始   : 2026-06-02 14:30:00 (UTC)
* 終了   : 2026-06-02 15:20:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260602-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host10-012 active_connections の推移](charts/EVT-20260602-host10-012.svg)

# イベントID( EVT-20260602-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→17→20
* 開始   : 2026-06-02 16:10:00 (UTC)
* 終了   : 2026-06-02 16:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-014 active_connections の推移](charts/EVT-20260602-host10-014.svg)

# イベントID( EVT-20260602-host10-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→13→7→12→8→7→12→8→10
* 開始   : 2026-06-02 20:00:00 (UTC)
* 終了   : 2026-06-02 21:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.6154(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260602-host10-018 active_connections の推移](charts/EVT-20260602-host10-018.svg)

# イベントID( EVT-20260603-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→22→18→19
* 開始   : 2026-06-03 07:50:00 (UTC)
* 終了   : 2026-06-03 07:50:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host10-005 active_connections の推移](charts/EVT-20260603-host10-005.svg)

# イベントID( EVT-20260603-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→19→22→19→20
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host10-007 active_connections の推移](charts/EVT-20260603-host10-007.svg)

# イベントID( EVT-20260603-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→14→8→11→…→11→9→11→13
* 開始   : 2026-06-03 19:50:00 (UTC)
* 終了   : 2026-06-03 20:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host10-015 active_connections の推移](charts/EVT-20260603-host10-015.svg)

# イベントID( EVT-20260603-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→12→7→11→10
* 開始   : 2026-06-03 20:25:00 (UTC)
* 終了   : 2026-06-03 20:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.768σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host10-016 active_connections の推移](charts/EVT-20260603-host10-016.svg)

# イベントID( EVT-20260604-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→18→22→20→18→22→18
* 開始   : 2026-06-04 08:00:00 (UTC)
* 終了   : 2026-06-04 08:10:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-006 active_connections の推移](charts/EVT-20260604-host10-006.svg)

# イベントID( EVT-20260604-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→17→…→17→22→17→18
* 開始   : 2026-06-04 08:05:00 (UTC)
* 終了   : 2026-06-04 08:15:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-007 active_connections の推移](charts/EVT-20260604-host10-007.svg)

# イベントID( EVT-20260604-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→21→17→22→21
* 開始   : 2026-06-04 14:15:00 (UTC)
* 終了   : 2026-06-04 14:15:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.7698(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.529σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host10-008 active_connections の推移](charts/EVT-20260604-host10-008.svg)

# イベントID( EVT-20260604-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→20→19
* 開始   : 2026-06-04 14:40:00 (UTC)
* 終了   : 2026-06-04 14:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→17→15→13→…→15→13→16→17
* 開始   : 2026-06-04 17:10:00 (UTC)
* 終了   : 2026-06-04 17:15:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-010 active_connections の推移](charts/EVT-20260604-host10-010.svg)

# イベントID( EVT-20260604-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→13
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host10-011 active_connections の推移](charts/EVT-20260604-host10-011.svg)

# イベントID( EVT-20260604-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→7→11→13
* 開始   : 2026-06-04 20:15:00 (UTC)
* 終了   : 2026-06-04 20:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.5638(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.761σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host10-012 active_connections の推移](charts/EVT-20260604-host10-012.svg)

# イベントID( EVT-20260604-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→10→6→10→10
* 開始   : 2026-06-04 20:50:00 (UTC)
* 終了   : 2026-06-04 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.704σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host10-013 active_connections の推移](charts/EVT-20260604-host10-013.svg)

# イベントID( EVT-20260604-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→10→6→10→6→9→10
* 開始   : 2026-06-04 21:10:00 (UTC)
* 終了   : 2026-06-04 21:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-014 active_connections の推移](charts/EVT-20260604-host10-014.svg)

# イベントID( EVT-20260605-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→11→14→12→12
* 開始   : 2026-06-05 03:10:00 (UTC)
* 終了   : 2026-06-05 03:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-001 active_connections の推移](charts/EVT-20260605-host10-001.svg)

# イベントID( EVT-20260605-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→18→21→19→19
* 開始   : 2026-06-05 07:25:00 (UTC)
* 終了   : 2026-06-05 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host10-008 active_connections の推移](charts/EVT-20260605-host10-008.svg)

# イベントID( EVT-20260605-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→22→19→24→…→24→18→22→23
* 開始   : 2026-06-05 12:15:00 (UTC)
* 終了   : 2026-06-05 12:50:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260605-host10-012 active_connections の推移](charts/EVT-20260605-host10-012.svg)

# イベントID( EVT-20260605-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→20→15→20→19
* 開始   : 2026-06-05 16:00:00 (UTC)
* 終了   : 2026-06-05 16:00:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.415σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-013 active_connections の推移](charts/EVT-20260605-host10-013.svg)

# イベントID( EVT-20260605-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→10→4→7→8
* 開始   : 2026-06-05 23:35:00 (UTC)
* 終了   : 2026-06-05 23:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.24σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host10-016 active_connections の推移](charts/EVT-20260605-host10-016.svg)

# イベントID( EVT-20260606-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→9→9
* 開始   : 2026-06-06 03:35:00 (UTC)
* 終了   : 2026-06-06 03:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→10→11→…→14→11→14→12
* 開始   : 2026-06-06 04:40:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.723, 限界=2.668)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260606-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260606-host10-002 active_connections の推移](charts/EVT-20260606-host10-002.svg)

# イベントID( EVT-20260606-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→13→…→11→10→12→8
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.757, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host10-003 active_connections の推移](charts/EVT-20260606-host10-003.svg)

# イベントID( EVT-20260606-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→13→10→12→…→15→13→15→13
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.723)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host10-004 active_connections の推移](charts/EVT-20260606-host10-004.svg)

# イベントID( EVT-20260606-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→14→12→13→…→10→11→13→10
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:55:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.778, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260606-host10-005 active_connections の推移](charts/EVT-20260606-host10-005.svg)

# イベントID( EVT-20260606-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→10→14→9→…→14→11→14→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.747, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host10-006 active_connections の推移](charts/EVT-20260606-host10-006.svg)

# イベントID( EVT-20260606-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→9→11→12→…→9→12→11→14
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.297σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.71, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host10-007 active_connections の推移](charts/EVT-20260606-host10-007.svg)

# イベントID( EVT-20260606-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→10→9
* 開始   : 2026-06-06 20:30:00 (UTC)
* 終了   : 2026-06-06 20:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host10-008 active_connections の推移](charts/EVT-20260606-host10-008.svg)

# イベントID( EVT-20260609-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→9→11
* 開始   : 2026-06-09 03:30:00 (UTC)
* 終了   : 2026-06-09 03:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.24σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host10-002 active_connections の推移](charts/EVT-20260609-host10-002.svg)

# イベントID( EVT-20260609-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 21→21→25→20→23
* 開始   : 2026-06-09 10:50:00 (UTC)
* 終了   : 2026-06-09 10:50:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→20→15→20→18
* 開始   : 2026-06-09 16:05:00 (UTC)
* 終了   : 2026-06-09 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host10-009 active_connections の推移](charts/EVT-20260609-host10-009.svg)

# イベントID( EVT-20260609-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→11→9→12→14→11→9→12
* 開始   : 2026-06-09 19:05:00 (UTC)
* 終了   : 2026-06-09 19:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.531σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260609-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-011 active_connections の推移](charts/EVT-20260609-host10-011.svg)

# イベントID( EVT-20260610-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→11→9→11→9→13→13
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 03:35:00 (UTC)
* 現象   : 2026-06-10 03:35:00 (UTC)を境に水準が 14.82から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.239σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-002 active_connections の推移](charts/EVT-20260610-host10-002.svg)

# イベントID( EVT-20260610-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→16→19→16→17
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host10-006 active_connections の推移](charts/EVT-20260610-host10-006.svg)

# イベントID( EVT-20260610-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→18→17→14→18→17→14→15
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260610-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host10-007 active_connections の推移](charts/EVT-20260610-host10-007.svg)

# イベントID( EVT-20260610-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→12→15→12→15→12→15→14
* 開始   : 2026-06-10 18:30:00 (UTC)
* 終了   : 2026-06-10 19:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260610-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 40 分
  - EVT-20260610-host01-016 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260610-host10-011 active_connections の推移](charts/EVT-20260610-host10-011.svg)

# イベントID( EVT-20260610-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→11→5→7→8
* 開始   : 2026-06-10 23:00:00 (UTC)
* 終了   : 2026-06-10 23:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host10-013 active_connections の推移](charts/EVT-20260610-host10-013.svg)

# イベントID( EVT-20260611-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 7→7→12→7→9
* 開始   : 2026-06-11 00:35:00 (UTC)
* 終了   : 2026-06-11 00:35:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.123σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host10-001 active_connections の推移](charts/EVT-20260611-host10-001.svg)

# イベントID( EVT-20260611-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→14→12→15→14→12
* 開始   : 2026-06-11 04:55:00 (UTC)
* 終了   : 2026-06-11 05:15:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host10-002 active_connections の推移](charts/EVT-20260611-host10-002.svg)

# イベントID( EVT-20260611-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→15→18→15→15
* 開始   : 2026-06-11 05:35:00 (UTC)
* 終了   : 2026-06-11 05:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-003 active_connections の推移](charts/EVT-20260611-host10-003.svg)

# イベントID( EVT-20260611-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→16→18→15→13
* 開始   : 2026-06-11 05:45:00 (UTC)
* 終了   : 2026-06-11 05:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-004 active_connections の推移](charts/EVT-20260611-host10-004.svg)

# イベントID( EVT-20260611-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→21→19→21→…→21→17→22→23
* 開始   : 2026-06-11 13:25:00 (UTC)
* 終了   : 2026-06-11 13:35:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.119σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host10-009 active_connections の推移](charts/EVT-20260611-host10-009.svg)

# イベントID( EVT-20260611-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→21→17→20→21→17→20→21
* 開始   : 2026-06-11 15:35:00 (UTC)
* 終了   : 2026-06-11 16:35:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.708σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-010 active_connections の推移](charts/EVT-20260611-host10-010.svg)

# イベントID( EVT-20260612-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 8→10→14→7→8
* 開始   : 2026-06-12 03:10:00 (UTC)
* 終了   : 2026-06-12 03:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.667σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host10-002 active_connections の推移](charts/EVT-20260612-host10-002.svg)

# イベントID( EVT-20260612-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→19→23→18→19
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.308倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host10-003 active_connections の推移](charts/EVT-20260612-host10-003.svg)

# イベントID( EVT-20260612-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→22→21→19→18→22→21→19→21
* 開始   : 2026-06-12 08:15:00 (UTC)
* 終了   : 2026-06-12 08:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host10-004 active_connections の推移](charts/EVT-20260612-host10-004.svg)

# イベントID( EVT-20260612-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→18→14→16→17
* 開始   : 2026-06-12 16:40:00 (UTC)
* 終了   : 2026-06-12 16:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7434(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.357σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host10-006 active_connections の推移](charts/EVT-20260612-host10-006.svg)

# イベントID( EVT-20260612-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→15→11→15→16
* 開始   : 2026-06-12 18:15:00 (UTC)
* 終了   : 2026-06-12 18:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host10-008 active_connections の推移](charts/EVT-20260612-host10-008.svg)

# イベントID( EVT-20260613-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→13→…→12→14→12→11
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.064, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host10-002 active_connections の推移](charts/EVT-20260613-host10-002.svg)

# イベントID( EVT-20260613-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→11→…→11→14→12→10
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260613-host10-003 active_connections の推移](charts/EVT-20260613-host10-003.svg)

# イベントID( EVT-20260613-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→10→13→10→…→9→11→13→11
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.912, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host10-004 active_connections の推移](charts/EVT-20260613-host10-004.svg)

# イベントID( EVT-20260613-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→11→…→10→14→13→12
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.668)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260613-host10-005 active_connections の推移](charts/EVT-20260613-host10-005.svg)

# イベントID( EVT-20260613-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→15→11→13→…→12→10→12→11
* 開始   : 2026-06-13 06:35:00 (UTC)
* 終了   : 2026-06-13 20:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.73, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host10-006 active_connections の推移](charts/EVT-20260613-host10-006.svg)

# イベントID( EVT-20260613-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→12→…→11→10→11→12
* 開始   : 2026-06-13 06:35:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.11, 限界=2.723)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260613-host10-007 active_connections の推移](charts/EVT-20260613-host10-007.svg)

# イベントID( EVT-20260613-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→10→6→8→10
* 開始   : 2026-06-13 20:30:00 (UTC)
* 終了   : 2026-06-13 20:30:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260613-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host10-009 active_connections の推移](charts/EVT-20260613-host10-009.svg)

# イベントID( EVT-20260614-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→10→16→14→13
* 開始   : 2026-06-14 06:45:00 (UTC)
* 終了   : 2026-06-14 06:45:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host10-002 active_connections の推移](charts/EVT-20260614-host10-002.svg)

# イベントID( EVT-20260614-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→11→17→13→14
* 開始   : 2026-06-14 07:15:00 (UTC)
* 終了   : 2026-06-14 07:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host10-003 active_connections の推移](charts/EVT-20260614-host10-003.svg)

# イベントID( EVT-20260615-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→…→12→15→12→13
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-003 active_connections の推移](charts/EVT-20260615-host10-003.svg)

# イベントID( EVT-20260615-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→15→…→13→12→14→13
* 開始   : 2026-06-15 03:00:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.91から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.022, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-005 active_connections の推移](charts/EVT-20260615-host10-005.svg)

# イベントID( EVT-20260615-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→13→…→16→13→16→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 19:35:00 (UTC)
* 現象   : 2026-06-15 19:35:00 (UTC)を境に水準が 11.86から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.668)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-007 active_connections の推移](charts/EVT-20260615-host10-007.svg)

# イベントID( EVT-20260615-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→12→5→6→8→12→5→6→8
* 開始   : 2026-06-15 21:55:00 (UTC)
* 終了   : 2026-06-15 22:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.4762(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.819σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.047 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260615-host10-008 active_connections の推移](charts/EVT-20260615-host10-008.svg)

# イベントID( EVT-20260616-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→15→17→13→15
* 開始   : 2026-06-16 05:40:00 (UTC)
* 終了   : 2026-06-16 06:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host10-004 active_connections の推移](charts/EVT-20260616-host10-004.svg)

# イベントID( EVT-20260617-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→12→7→9→8
* 開始   : 2026-06-17 20:55:00 (UTC)
* 終了   : 2026-06-17 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host10-005 active_connections の推移](charts/EVT-20260617-host10-005.svg)

# イベントID( EVT-20260617-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→9→5→8→9
* 開始   : 2026-06-17 22:30:00 (UTC)
* 終了   : 2026-06-17 22:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host07-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host10-006 active_connections の推移](charts/EVT-20260617-host10-006.svg)

# イベントID( EVT-20260618-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→13→16→12→13
* 開始   : 2026-06-18 04:35:00 (UTC)
* 終了   : 2026-06-18 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host10-001 active_connections の推移](charts/EVT-20260618-host10-001.svg)

# イベントID( EVT-20260619-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→15→…→10→14→11→12
* 開始   : 2026-06-19 04:20:00 (UTC)
* 終了   : 2026-06-19 05:40:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 1.0 時間
  - EVT-20260619-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260619-host10-002 active_connections の推移](charts/EVT-20260619-host10-002.svg)

# イベントID( EVT-20260619-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→11→16→13→16→13→16→14→15
* 開始   : 2026-06-19 05:30:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260619-host10-003 active_connections の推移](charts/EVT-20260619-host10-003.svg)

# イベントID( EVT-20260619-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→18→19→20→19→20→18→16
* 開始   : 2026-06-19 06:55:00 (UTC)
* 終了   : 2026-06-19 07:25:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260619-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host10-006 active_connections の推移](charts/EVT-20260619-host10-006.svg)

# イベントID( EVT-20260619-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→15→17→19
* 開始   : 2026-06-19 16:10:00 (UTC)
* 終了   : 2026-06-19 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host10-011 active_connections の推移](charts/EVT-20260619-host10-011.svg)

# イベントID( EVT-20260619-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→14→15→13→14→15→13→16→18
* 開始   : 2026-06-19 17:20:00 (UTC)
* 終了   : 2026-06-19 17:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host10-013 active_connections の推移](charts/EVT-20260619-host10-013.svg)

# イベントID( EVT-20260619-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→15→15
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 18:15:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260619-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host10-014 active_connections の推移](charts/EVT-20260619-host10-014.svg)

# イベントID( EVT-20260619-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→9→11
* 開始   : 2026-06-19 21:05:00 (UTC)
* 終了   : 2026-06-19 21:05:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→13→11→12→…→11→10→13→10
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260620-host10-002 active_connections の推移](charts/EVT-20260620-host10-002.svg)

# イベントID( EVT-20260620-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→9→11→9→…→8→10→13→9
* 開始   : 2026-06-20 05:30:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 4.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.787, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host10-003 active_connections の推移](charts/EVT-20260620-host10-003.svg)

# イベントID( EVT-20260620-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→…→14→12→13→12
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.178σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260620-host10-004 active_connections の推移](charts/EVT-20260620-host10-004.svg)

# イベントID( EVT-20260620-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→9→12→11→…→11→12→11→12
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.78, 限界=2.668)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host10-005 active_connections の推移](charts/EVT-20260620-host10-005.svg)

# イベントID( EVT-20260620-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→13→9→12→…→12→9→14→10
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.723)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host10-006 active_connections の推移](charts/EVT-20260620-host10-006.svg)

# イベントID( EVT-20260620-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→12→…→12→11→12→11
* 開始   : 2026-06-20 06:05:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.905, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間

![EVT-20260620-host10-007 active_connections の推移](charts/EVT-20260620-host10-007.svg)

# イベントID( EVT-20260621-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→10→11
* 開始   : 2026-06-21 03:20:00 (UTC)
* 終了   : 2026-06-21 03:20:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host10-002 active_connections の推移](charts/EVT-20260621-host10-002.svg)

# イベントID( EVT-20260621-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→13→19→14→15
* 開始   : 2026-06-21 09:45:00 (UTC)
* 終了   : 2026-06-21 09:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→7→4→11→6
* 開始   : 2026-06-21 23:50:00 (UTC)
* 終了   : 2026-06-21 23:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260621-host10-006 active_connections の推移](charts/EVT-20260621-host10-006.svg)

# イベントID( EVT-20260623-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→9→13→12→…→13→12→11→9
* 開始   : 2026-06-23 02:15:00 (UTC)
* 終了   : 2026-06-23 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-001 active_connections の推移](charts/EVT-20260623-host10-001.svg)

# イベントID( EVT-20260623-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→8→13→11→7
* 開始   : 2026-06-23 02:40:00 (UTC)
* 終了   : 2026-06-23 02:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-002 active_connections の推移](charts/EVT-20260623-host10-002.svg)

# イベントID( EVT-20260623-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→13→16→12→13
* 開始   : 2026-06-23 04:30:00 (UTC)
* 終了   : 2026-06-23 04:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.466倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.528σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host10-003 active_connections の推移](charts/EVT-20260623-host10-003.svg)

# イベントID( EVT-20260623-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→20→22→19→19
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host10-005 active_connections の推移](charts/EVT-20260623-host10-005.svg)

# イベントID( EVT-20260623-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→15→20→19
* 開始   : 2026-06-23 15:50:00 (UTC)
* 終了   : 2026-06-23 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.609σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host10-007 active_connections の推移](charts/EVT-20260623-host10-007.svg)

# イベントID( EVT-20260624-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→16→19→16→16
* 開始   : 2026-06-24 06:30:00 (UTC)
* 終了   : 2026-06-24 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→21→17→21→22
* 開始   : 2026-06-24 14:15:00 (UTC)
* 終了   : 2026-06-24 14:15:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-007 active_connections の推移](charts/EVT-20260624-host10-007.svg)

# イベントID( EVT-20260624-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→16→14
* 開始   : 2026-06-24 17:30:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-010 active_connections の推移](charts/EVT-20260624-host10-010.svg)

# イベントID( EVT-20260624-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→17→11→14→14
* 開始   : 2026-06-24 18:25:00 (UTC)
* 終了   : 2026-06-24 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-011 active_connections の推移](charts/EVT-20260624-host10-011.svg)

# イベントID( EVT-20260624-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→8→4→9→8
* 開始   : 2026-06-24 23:15:00 (UTC)
* 終了   : 2026-06-24 23:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-016 active_connections の推移](charts/EVT-20260624-host10-016.svg)

# イベントID( EVT-20260625-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→9→13→8→9
* 開始   : 2026-06-25 02:00:00 (UTC)
* 終了   : 2026-06-25 02:00:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.297σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-001 active_connections の推移](charts/EVT-20260625-host10-001.svg)

# イベントID( EVT-20260625-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→17→15→17→15→17→15
* 開始   : 2026-06-25 05:40:00 (UTC)
* 終了   : 2026-06-25 05:50:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-005 active_connections の推移](charts/EVT-20260625-host10-005.svg)

# イベントID( EVT-20260625-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 20→20→23→19→19
* 開始   : 2026-06-25 08:15:00 (UTC)
* 終了   : 2026-06-25 08:15:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-006 active_connections の推移](charts/EVT-20260625-host10-006.svg)

# イベントID( EVT-20260625-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 22→22→17→23→21
* 開始   : 2026-06-25 12:40:00 (UTC)
* 終了   : 2026-06-25 12:40:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.7698(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host10-008 active_connections の推移](charts/EVT-20260625-host10-008.svg)

# イベントID( EVT-20260625-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→12→13
* 開始   : 2026-06-25 19:25:00 (UTC)
* 終了   : 2026-06-25 19:25:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host10-013 active_connections の推移](charts/EVT-20260625-host10-013.svg)

# イベントID( EVT-20260626-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→9→9
* 開始   : 2026-06-26 01:15:00 (UTC)
* 終了   : 2026-06-26 01:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→15→18→15→18→15→16
* 開始   : 2026-06-26 06:30:00 (UTC)
* 終了   : 2026-06-26 06:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host10-004 active_connections の推移](charts/EVT-20260626-host10-004.svg)

# イベントID( EVT-20260626-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→23→23
* 開始   : 2026-06-26 11:40:00 (UTC)
* 終了   : 2026-06-26 11:40:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host10-008 active_connections の推移](charts/EVT-20260626-host10-008.svg)

# イベントID( EVT-20260626-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→15→10→15→14
* 開始   : 2026-06-26 18:30:00 (UTC)
* 終了   : 2026-06-26 18:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.588σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-012 active_connections の推移](charts/EVT-20260626-host10-012.svg)

# イベントID( EVT-20260626-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→14→8→13→11
* 開始   : 2026-06-26 19:40:00 (UTC)
* 終了   : 2026-06-26 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.5926(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.842σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host10-013 active_connections の推移](charts/EVT-20260626-host10-013.svg)

# イベントID( EVT-20260626-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→9→13→8→9→13→8→12→11
* 開始   : 2026-06-26 20:20:00 (UTC)
* 終了   : 2026-06-26 20:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host10-015 active_connections の推移](charts/EVT-20260626-host10-015.svg)

# イベントID( EVT-20260627-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→10→11→10→…→12→10→11→12
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.702, 限界=2.668)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host10-002 active_connections の推移](charts/EVT-20260627-host10-002.svg)

# イベントID( EVT-20260627-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→13→12→13→11
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 18:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.74, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host10-003 active_connections の推移](charts/EVT-20260627-host10-003.svg)

# イベントID( EVT-20260627-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→15→…→13→12→13→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.218, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host10-004 active_connections の推移](charts/EVT-20260627-host10-004.svg)

# イベントID( EVT-20260627-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→12→…→11→10→11→13
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.007, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260627-host10-005 active_connections の推移](charts/EVT-20260627-host10-005.svg)

# イベントID( EVT-20260627-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→11→12→11→…→12→10→12→11
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.723)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host10-006 active_connections の推移](charts/EVT-20260627-host10-006.svg)

# イベントID( EVT-20260627-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→12→13→12→…→12→10→12→13
* 開始   : 2026-06-27 06:20:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host10-007 active_connections の推移](charts/EVT-20260627-host10-007.svg)

# イベントID( EVT-20260627-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→13→8→9→…→9→7→10→11
* 開始   : 2026-06-27 20:10:00 (UTC)
* 終了   : 2026-06-27 20:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.7385(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-068 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260627-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260627-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260627-host10-008 active_connections の推移](charts/EVT-20260627-host10-008.svg)

# イベントID( EVT-20260628-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→14→9→12→14
* 開始   : 2026-06-28 07:30:00 (UTC)
* 終了   : 2026-06-28 07:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host10-002 active_connections の推移](charts/EVT-20260628-host10-002.svg)

# イベントID( EVT-20260628-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→14→16
* 開始   : 2026-06-28 08:45:00 (UTC)
* 終了   : 2026-06-28 08:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→11→19→15→11→19→15→14
* 開始   : 2026-06-28 15:00:00 (UTC)
* 終了   : 2026-06-28 15:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host10-005 active_connections の推移](charts/EVT-20260628-host10-005.svg)

# イベントID( EVT-20260628-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→13→10→15→13
* 開始   : 2026-06-28 15:55:00 (UTC)
* 終了   : 2026-06-28 15:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→9→…→9→4→9→8
* 開始   : 2026-06-28 22:30:00 (UTC)
* 終了   : 2026-06-28 23:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260628-host10-009 active_connections の推移](charts/EVT-20260628-host10-009.svg)

# イベントID( EVT-20260628-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 6→7→12→7→…→7→5→9→8
* 開始   : 2026-06-28 23:35:00 (UTC)
* 終了   : 2026-06-28 23:45:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host10-010 active_connections の推移](charts/EVT-20260628-host10-010.svg)

# イベントID( EVT-20260630-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→11→15
* 開始   : 2026-06-30 05:15:00 (UTC)
* 終了   : 2026-06-30 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-002 active_connections の推移](charts/EVT-20260630-host10-002.svg)

# イベントID( EVT-20260630-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→16→19→20→20→20→20→19→19
* 開始   : 2026-06-30 07:30:00 (UTC)
* 終了   : 2026-06-30 08:20:00 (UTC)
* 現象   : 2026-06-30 08:20:00 (UTC)を境に水準が 14.93から16.47へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.197σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host10-004 active_connections の推移](charts/EVT-20260630-host10-004.svg)

# イベントID( EVT-20260630-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→16→14→16→17
* 開始   : 2026-06-30 16:35:00 (UTC)
* 終了   : 2026-06-30 16:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→8→12→7→…→12→7→6→10
* 開始   : 2026-06-01 02:05:00 (UTC)
* 終了   : 2026-06-01 02:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→10→13→10→11
* 開始   : 2026-06-01 03:40:00 (UTC)
* 終了   : 2026-06-01 03:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→16→18→17→18→17→18→16→15
* 開始   : 2026-06-01 06:25:00 (UTC)
* 終了   : 2026-06-01 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260601-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→17→18→16→17→18→16→19→18
* 開始   : 2026-06-01 15:35:00 (UTC)
* 終了   : 2026-06-01 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→8→11→8→11→8→10→11
* 開始   : 2026-06-01 20:30:00 (UTC)
* 終了   : 2026-06-01 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→15→17→16→15→17→16→15
* 開始   : 2026-06-02 06:20:00 (UTC)
* 終了   : 2026-06-02 06:25:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→19→22→21→19→22→19
* 開始   : 2026-06-02 07:55:00 (UTC)
* 終了   : 2026-06-02 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→21→20→22→21→20→22→18→20
* 開始   : 2026-06-02 08:20:00 (UTC)
* 終了   : 2026-06-02 08:30:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→21→19→24→21→19→24→21
* 開始   : 2026-06-02 13:50:00 (UTC)
* 終了   : 2026-06-02 13:55:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→17→19→20→16→17→19
* 開始   : 2026-06-02 15:40:00 (UTC)
* 終了   : 2026-06-02 15:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7934(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260602-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→14→13→16→…→14→13→14→15
* 開始   : 2026-06-02 17:45:00 (UTC)
* 終了   : 2026-06-02 17:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→13→11→12→14→10
* 開始   : 2026-06-02 19:10:00 (UTC)
* 終了   : 2026-06-02 20:35:00 (UTC)
* 現象   : 2026-06-02 20:35:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→9→12→11→10→9→12
* 開始   : 2026-06-02 19:50:00 (UTC)
* 終了   : 2026-06-02 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host10-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-019 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→10→6→9→8→9→7→10→8
* 開始   : 2026-06-02 23:35:00 (UTC)
* 終了   : 2026-06-03 00:35:00 (UTC)
* 現象   : 2026-06-03 00:35:00 (UTC)を境に水準が 14.94から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host10-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→16→12→16→12→16→15→14
* 開始   : 2026-06-03 05:10:00 (UTC)
* 終了   : 2026-06-03 05:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→15→15→17→16→16→17→17→18
* 開始   : 2026-06-03 05:35:00 (UTC)
* 終了   : 2026-06-03 06:30:00 (UTC)
* 現象   : 2026-06-03 06:30:00 (UTC)を境に水準が 14.99から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.112, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→19→16→14→19→16→15
* 開始   : 2026-06-03 06:45:00 (UTC)
* 終了   : 2026-06-03 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→18→19→18→19→18→19→18→19
* 開始   : 2026-06-03 07:20:00 (UTC)
* 終了   : 2026-06-03 07:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→19→20→19→20→19
* 開始   : 2026-06-03 08:00:00 (UTC)
* 終了   : 2026-06-03 08:10:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.297σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→19→22→21→22→21→22→19→18
* 開始   : 2026-06-03 08:45:00 (UTC)
* 終了   : 2026-06-03 08:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.489σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→22→19→22→19
* 開始   : 2026-06-03 13:45:00 (UTC)
* 終了   : 2026-06-03 13:50:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→19→22→21→21
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 15:30:00 (UTC)
* 現象   : 2026-06-03 15:30:00 (UTC)を境に水準が 14.89から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→20→20→20→21→21→19→18→20
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 16:15:00 (UTC)
* 現象   : 2026-06-03 16:15:00 (UTC)を境に水準が 14.95から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→20→17→20→17→20→21
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 15:15:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8127(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-009 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260603-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→16→13→16→15
* 開始   : 2026-06-03 18:05:00 (UTC)
* 終了   : 2026-06-03 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→15→12→16→…→12→11→15→12
* 開始   : 2026-06-03 18:30:00 (UTC)
* 終了   : 2026-06-03 18:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→6→12→9→6→12→9→7
* 開始   : 2026-06-03 22:25:00 (UTC)
* 終了   : 2026-06-03 22:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→6→8→9→6→8→7
* 開始   : 2026-06-03 22:30:00 (UTC)
* 終了   : 2026-06-03 22:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-017 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→10→12→9→12→9→12→10→12
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 03:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→12→16→12→16→14→15
* 開始   : 2026-06-04 05:05:00 (UTC)
* 終了   : 2026-06-04 05:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260604-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→13→14→16→13→14
* 開始   : 2026-06-04 05:25:00 (UTC)
* 終了   : 2026-06-04 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→16→18→16
* 開始   : 2026-06-04 06:05:00 (UTC)
* 終了   : 2026-06-04 06:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.852σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260604-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→18→17→19→18→17→19→15→18
* 開始   : 2026-06-04 06:50:00 (UTC)
* 終了   : 2026-06-04 07:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→13→12→10→12→13→12
* 開始   : 2026-06-05 03:10:00 (UTC)
* 終了   : 2026-06-05 03:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→12→12→11→13→11→14→12→15
* 開始   : 2026-06-05 03:35:00 (UTC)
* 終了   : 2026-06-05 04:30:00 (UTC)
* 現象   : 2026-06-05 04:30:00 (UTC)を境に水準が 15.09から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.52, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→10→14→12→10→14→12
* 開始   : 2026-06-05 04:10:00 (UTC)
* 終了   : 2026-06-05 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.415σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→13→14→13→14→13
* 開始   : 2026-06-05 04:15:00 (UTC)
* 終了   : 2026-06-05 04:25:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→15→15→14→15→15→17→16
* 開始   : 2026-06-05 05:30:00 (UTC)
* 終了   : 2026-06-05 06:05:00 (UTC)
* 現象   : 2026-06-05 06:05:00 (UTC)を境に水準が 14.99から14.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.702, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→15→17→14→15→17→14→13
* 開始   : 2026-06-05 05:45:00 (UTC)
* 終了   : 2026-06-05 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→18→23→22→…→22→24→23→22
* 開始   : 2026-06-05 09:50:00 (UTC)
* 終了   : 2026-06-05 10:00:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 22→19→18→21→…→21→24→21→23
* 開始   : 2026-06-05 11:05:00 (UTC)
* 終了   : 2026-06-05 11:15:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260605-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→21→24→22→21→24→22→21
* 開始   : 2026-06-05 11:25:00 (UTC)
* 終了   : 2026-06-05 11:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.415σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→17→15→14→15→17→15→14→15
* 開始   : 2026-06-05 17:20:00 (UTC)
* 終了   : 2026-06-05 17:25:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.8411(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→13→…→14→13→15→16
* 開始   : 2026-06-05 17:50:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→6→8→10→12→6→8
* 開始   : 2026-06-06 21:40:00 (UTC)
* 終了   : 2026-06-06 21:45:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→7→5→9→…→9→11→10→9
* 開始   : 2026-06-06 23:55:00 (UTC)
* 終了   : 2026-06-07 00:05:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260606-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→8→…→8→11→7→11
* 開始   : 2026-06-07 01:30:00 (UTC)
* 終了   : 2026-06-07 01:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→11→10→9→9→9→9→10→12
* 開始   : 2026-06-07 01:50:00 (UTC)
* 終了   : 2026-06-07 03:50:00 (UTC)
* 現象   : 2026-06-07 03:50:00 (UTC)を境に水準が 11.75から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.401, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 8→10→11→8→…→8→12→7→8
* 開始   : 2026-06-07 02:00:00 (UTC)
* 終了   : 2026-06-07 02:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→9→12→8→9→12→8→11
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 04:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→16→11→16→11→16→13
* 開始   : 2026-06-07 07:30:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260607-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260607-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→14
* 開始   : 2026-06-07 07:55:00 (UTC)
* 終了   : 2026-06-07 08:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→16→17→17→17→18
* 開始   : 2026-06-07 13:20:00 (UTC)
* 終了   : 2026-06-07 13:45:00 (UTC)
* 現象   : 2026-06-07 13:45:00 (UTC)を境に水準が 11.92から13.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→10→…→10→7→11→9
* 開始   : 2026-06-08 21:10:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260608-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→10→11→8→…→4→5→9→8
* 開始   : 2026-06-08 23:10:00 (UTC)
* 終了   : 2026-06-08 23:55:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260608-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260608-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260608-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→11→9→11→9→11→7→9
* 開始   : 2026-06-09 01:50:00 (UTC)
* 終了   : 2026-06-09 02:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.356σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-003 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→13→15→12→13→15→12→14
* 開始   : 2026-06-09 04:55:00 (UTC)
* 終了   : 2026-06-09 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→18→15→18→…→15→18→17→14
* 開始   : 2026-06-09 06:10:00 (UTC)
* 終了   : 2026-06-09 06:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.71σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→21→23
* 開始   : 2026-06-09 09:20:00 (UTC)
* 終了   : 2026-06-09 09:30:00 (UTC)
* 現象   : 2026-06-09 09:30:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→24→23→25
* 開始   : 2026-06-09 11:10:00 (UTC)
* 終了   : 2026-06-09 11:25:00 (UTC)
* 現象   : 2026-06-09 11:25:00 (UTC)を境に水準が 15.03から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 21→19→25→24→…→24→19→23→20
* 開始   : 2026-06-09 13:45:00 (UTC)
* 終了   : 2026-06-09 14:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→18→15→18→15→18→15→18→16
* 開始   : 2026-06-09 16:40:00 (UTC)
* 終了   : 2026-06-09 16:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260609-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→10→10→12→11→11→13→13→11
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 03:20:00 (UTC)
* 現象   : 2026-06-10 03:20:00 (UTC)を境に水準が 14.96から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→11→12→11→12→11→9
* 開始   : 2026-06-10 03:15:00 (UTC)
* 終了   : 2026-06-10 03:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.297σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→11→15→13→…→15→16→15→12
* 開始   : 2026-06-10 05:00:00 (UTC)
* 終了   : 2026-06-10 05:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.239σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260610-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→15→16
* 開始   : 2026-06-10 05:10:00 (UTC)
* 終了   : 2026-06-10 05:20:00 (UTC)
* 現象   : 2026-06-10 05:20:00 (UTC)を境に水準が 14.88から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→21→16→19→16→19→16→21→18
* 開始   : 2026-06-10 15:55:00 (UTC)
* 終了   : 2026-06-10 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→19→17→19→16→17→15→16→16
* 開始   : 2026-06-10 16:40:00 (UTC)
* 終了   : 2026-06-10 18:20:00 (UTC)
* 現象   : 2026-06-10 18:20:00 (UTC)を境に水準が 15.1から14.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.023, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→19→20→16→…→16→13→17→15
* 開始   : 2026-06-10 17:20:00 (UTC)
* 終了   : 2026-06-10 17:30:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→13→8→11→8→11→8→11→10
* 開始   : 2026-06-10 20:35:00 (UTC)
* 終了   : 2026-06-10 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.6667(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.826σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→19→18→16→19→18→17
* 開始   : 2026-06-11 06:55:00 (UTC)
* 終了   : 2026-06-11 07:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.66σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260611-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→17→21→17→21→16→17
* 開始   : 2026-06-11 07:35:00 (UTC)
* 終了   : 2026-06-11 07:45:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→20→22→18→22→18→22→19
* 開始   : 2026-06-11 09:10:00 (UTC)
* 終了   : 2026-06-11 09:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→23→24→22→23→25→23
* 開始   : 2026-06-11 10:40:00 (UTC)
* 終了   : 2026-06-11 11:10:00 (UTC)
* 現象   : 2026-06-11 11:10:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.614, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→19→20→19→16→20→19→19→17
* 開始   : 2026-06-11 15:50:00 (UTC)
* 終了   : 2026-06-11 17:30:00 (UTC)
* 現象   : 2026-06-11 17:30:00 (UTC)を境に水準が 15.02から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.316, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→16→13→14
* 開始   : 2026-06-11 17:45:00 (UTC)
* 終了   : 2026-06-11 17:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.59σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→12→11→12→15
* 開始   : 2026-06-11 19:05:00 (UTC)
* 終了   : 2026-06-11 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260611-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→12→8→10→12→8→10→9
* 開始   : 2026-06-11 20:55:00 (UTC)
* 終了   : 2026-06-11 21:00:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→9→8→8→10→8→9→10→12
* 開始   : 2026-06-11 23:40:00 (UTC)
* 終了   : 2026-06-12 00:35:00 (UTC)
* 現象   : 2026-06-12 00:35:00 (UTC)を境に水準が 14.93から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→8→11→8→11→8→11→8→9
* 開始   : 2026-06-12 01:55:00 (UTC)
* 終了   : 2026-06-12 02:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-003 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260612-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→19→23→19→23→19→22
* 開始   : 2026-06-12 12:20:00 (UTC)
* 終了   : 2026-06-12 12:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→15→…→15→12→13→14
* 開始   : 2026-06-12 18:15:00 (UTC)
* 終了   : 2026-06-12 18:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.8211(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→8→13→8→13→8→10
* 開始   : 2026-06-12 20:45:00 (UTC)
* 終了   : 2026-06-12 20:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→14→8→6→14→8→6→10→8
* 開始   : 2026-06-12 21:40:00 (UTC)
* 終了   : 2026-06-12 21:50:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→9→11→10→…→14→10→11→14
* 開始   : 2026-06-13 04:50:00 (UTC)
* 終了   : 2026-06-13 05:25:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.66σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.723)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 0 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分

![EVT-20260613-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host10-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→10→8→9→10→11→9
* 開始   : 2026-06-13 19:35:00 (UTC)
* 終了   : 2026-06-13 19:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.997, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10 分
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260613-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→11→11→12→14→12
* 開始   : 2026-06-14 04:30:00 (UTC)
* 終了   : 2026-06-14 04:55:00 (UTC)
* 現象   : 2026-06-14 04:55:00 (UTC)を境に水準が 11.8から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→16→13→14→14→16→14
* 開始   : 2026-06-14 15:30:00 (UTC)
* 終了   : 2026-06-14 16:25:00 (UTC)
* 現象   : 2026-06-14 16:25:00 (UTC)を境に水準が 11.84から14.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→12→12→12→11→13
* 開始   : 2026-06-14 19:20:00 (UTC)
* 終了   : 2026-06-14 20:00:00 (UTC)
* 現象   : 2026-06-14 20:00:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→11
* 開始   : 2026-06-14 19:25:00 (UTC)
* 終了   : 2026-06-14 19:40:00 (UTC)
* 現象   : 2026-06-14 19:40:00 (UTC)を境に水準が 11.81から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→8→12→10
* 開始   : 2026-06-14 20:30:00 (UTC)
* 終了   : 2026-06-14 20:55:00 (UTC)
* 現象   : 2026-06-14 20:55:00 (UTC)を境に水準が 11.88から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 7→8→11→8→11→8→11→7→9
* 開始   : 2026-06-14 22:15:00 (UTC)
* 終了   : 2026-06-14 22:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 7→11→7→11→7→8
* 開始   : 2026-06-14 23:30:00 (UTC)
* 終了   : 2026-06-14 23:35:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260614-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→9→11→9→…→9→12→9→8
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260615-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→10→12→9→…→9→13→10→11
* 開始   : 2026-06-16 03:05:00 (UTC)
* 終了   : 2026-06-16 03:15:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260616-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→11→15→12→11→15→12→14
* 開始   : 2026-06-16 04:45:00 (UTC)
* 終了   : 2026-06-16 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→11→10→13→…→13→16→13→15
* 開始   : 2026-06-16 05:15:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→19→…→18→19→14→16
* 開始   : 2026-06-16 06:45:00 (UTC)
* 終了   : 2026-06-16 06:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260616-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→16→18→15→16→17
* 開始   : 2026-06-16 16:40:00 (UTC)
* 終了   : 2026-06-16 16:45:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→15→13→12→13→15→13→12→13
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 18:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.06σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→15→10→15→10→12
* 開始   : 2026-06-16 19:35:00 (UTC)
* 終了   : 2026-06-16 19:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→13→9→11→…→11→15→11→10
* 開始   : 2026-06-16 20:10:00 (UTC)
* 終了   : 2026-06-16 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260616-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→13→14→7→…→7→8→9→10
* 開始   : 2026-06-16 21:20:00 (UTC)
* 終了   : 2026-06-16 21:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→14→15→13→13→14→14→15→16
* 開始   : 2026-06-17 04:45:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 2026-06-17 05:30:00 (UTC)を境に水準が 14.98から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→20→15→16→20→15→16→18
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.59σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→14→14→14→17→15
* 開始   : 2026-06-17 18:10:00 (UTC)
* 終了   : 2026-06-17 18:35:00 (UTC)
* 現象   : 2026-06-17 18:35:00 (UTC)を境に水準が 15.09から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→11→9→8→9→11→9→8→9
* 開始   : 2026-06-17 20:30:00 (UTC)
* 終了   : 2026-06-17 20:35:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→13→18→17→13→18→17
* 開始   : 2026-06-18 06:25:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→18→17→19→18→17→19→17→15
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→21→20→21→…→21→19→22→20
* 開始   : 2026-06-18 08:10:00 (UTC)
* 終了   : 2026-06-18 08:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260618-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→20→22→20→22→20→22→19→22
* 開始   : 2026-06-18 08:50:00 (UTC)
* 終了   : 2026-06-18 09:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 24→21→25→22→…→22→19→24→23
* 開始   : 2026-06-18 11:25:00 (UTC)
* 終了   : 2026-06-18 11:35:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 25→23→23→22→23→23→21→24→22
* 開始   : 2026-06-18 11:30:00 (UTC)
* 終了   : 2026-06-18 12:50:00 (UTC)
* 現象   : 2026-06-18 12:50:00 (UTC)を境に水準が 14.96から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.592, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 23→24→24→22→23→24
* 開始   : 2026-06-18 12:55:00 (UTC)
* 終了   : 2026-06-18 13:20:00 (UTC)
* 現象   : 2026-06-18 13:20:00 (UTC)を境に水準が 15.17から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→14→14→15→14→16→12
* 開始   : 2026-06-18 18:00:00 (UTC)
* 終了   : 2026-06-18 19:05:00 (UTC)
* 現象   : 2026-06-18 19:05:00 (UTC)を境に水準が 14.96から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.228, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→15→11→12→15→11→12
* 開始   : 2026-06-18 18:50:00 (UTC)
* 終了   : 2026-06-18 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260618-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→11→10→13→11
* 開始   : 2026-06-19 03:15:00 (UTC)
* 終了   : 2026-06-19 03:20:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→18→16→18→16→18→17→16
* 開始   : 2026-06-19 06:25:00 (UTC)
* 終了   : 2026-06-19 06:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260619-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→19→16→15→19→16→17
* 開始   : 2026-06-19 06:55:00 (UTC)
* 終了   : 2026-06-19 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→23→22→20→23→22
* 開始   : 2026-06-19 10:00:00 (UTC)
* 終了   : 2026-06-19 10:05:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 22→23→24→22→24→22→24→23→22
* 開始   : 2026-06-19 10:05:00 (UTC)
* 終了   : 2026-06-19 10:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→21→25→19→21→25→21
* 開始   : 2026-06-19 11:10:00 (UTC)
* 終了   : 2026-06-19 11:20:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-040 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→21→16→21→16→18→17
* 開始   : 2026-06-19 15:40:00 (UTC)
* 終了   : 2026-06-19 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→14→17→14→…→17→14→15→18
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 17:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→14→15→11→14→13
* 開始   : 2026-06-19 18:50:00 (UTC)
* 終了   : 2026-06-19 18:55:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260619-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→12→7→9→…→9→13→12→10
* 開始   : 2026-06-20 04:15:00 (UTC)
* 終了   : 2026-06-20 04:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.7119(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→8→10→8→9→10
* 開始   : 2026-06-21 00:50:00 (UTC)
* 終了   : 2026-06-21 01:15:00 (UTC)
* 現象   : 2026-06-21 01:15:00 (UTC)を境に水準が 11.76から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→15→…→15→19→15→18
* 開始   : 2026-06-21 10:10:00 (UTC)
* 終了   : 2026-06-21 10:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→10→12→14→10→12→14
* 開始   : 2026-06-21 17:05:00 (UTC)
* 終了   : 2026-06-21 17:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260621-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→9→11→7→9→11→11
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 02:55:00 (UTC)
* 現象   : 2026-06-22 02:55:00 (UTC)を境に水準が 11.82から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 7→10→11→9→8→10→13
* 開始   : 2026-06-22 21:50:00 (UTC)
* 終了   : 2026-06-22 22:20:00 (UTC)
* 現象   : 2026-06-22 22:20:00 (UTC)を境に水準が 14.89から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→16→12→15→…→15→18→15→17
* 開始   : 2026-06-23 06:20:00 (UTC)
* 終了   : 2026-06-23 06:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→19→22→21→19→22→21→19
* 開始   : 2026-06-23 08:55:00 (UTC)
* 終了   : 2026-06-23 09:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→18→16→20→19
* 開始   : 2026-06-23 16:10:00 (UTC)
* 終了   : 2026-06-23 16:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→17→21→14→17→21→14→17→18
* 開始   : 2026-06-23 16:55:00 (UTC)
* 終了   : 2026-06-23 17:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.474σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→16→17→16→17→18→13→16→15
* 開始   : 2026-06-23 17:05:00 (UTC)
* 終了   : 2026-06-23 18:45:00 (UTC)
* 現象   : 2026-06-23 18:45:00 (UTC)を境に水準が 14.95から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→12→…→12→9→12→10
* 開始   : 2026-06-23 19:45:00 (UTC)
* 終了   : 2026-06-23 19:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260623-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→12→13→15→16→12→14
* 開始   : 2026-06-24 05:05:00 (UTC)
* 終了   : 2026-06-24 05:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→15→…→15→17→15→11
* 開始   : 2026-06-24 05:25:00 (UTC)
* 終了   : 2026-06-24 05:35:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.474σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 22→18→21→24→18→21→24→22→20
* 開始   : 2026-06-24 09:50:00 (UTC)
* 終了   : 2026-06-24 10:00:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→23→24→22→23→24→22→23
* 開始   : 2026-06-24 10:50:00 (UTC)
* 終了   : 2026-06-24 10:55:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 25→23→24→23→24→23
* 開始   : 2026-06-24 12:40:00 (UTC)
* 終了   : 2026-06-24 13:55:00 (UTC)
* 現象   : 2026-06-24 13:55:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 21→24→19→21→19→18→19→19→21
* 開始   : 2026-06-24 15:05:00 (UTC)
* 終了   : 2026-06-24 16:00:00 (UTC)
* 現象   : 2026-06-24 16:00:00 (UTC)を境に水準が 15.02から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→17→19→20→18→17→18
* 開始   : 2026-06-24 16:25:00 (UTC)
* 終了   : 2026-06-24 16:55:00 (UTC)
* 現象   : 2026-06-24 16:55:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.067, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→10→8→10→8→11
* 開始   : 2026-06-24 20:20:00 (UTC)
* 終了   : 2026-06-24 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.853σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→10→…→10→7→9→8
* 開始   : 2026-06-24 21:05:00 (UTC)
* 終了   : 2026-06-24 21:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.178σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→7→5→7→5→9→5→9
* 開始   : 2026-06-24 22:55:00 (UTC)
* 終了   : 2026-06-24 23:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→6→8→6→8→6→8→7
* 開始   : 2026-06-24 23:10:00 (UTC)
* 終了   : 2026-06-24 23:20:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→13→10→13→10→13→11→10
* 開始   : 2026-06-25 03:30:00 (UTC)
* 終了   : 2026-06-25 03:40:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260625-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→14→14→14→14→14
* 開始   : 2026-06-25 04:10:00 (UTC)
* 終了   : 2026-06-25 04:35:00 (UTC)
* 現象   : 2026-06-25 04:35:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→14→12→15→14→12→15→12→13
* 開始   : 2026-06-25 04:40:00 (UTC)
* 終了   : 2026-06-25 04:50:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.254倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.003σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→19→22→21→19→22→21
* 開始   : 2026-06-25 08:20:00 (UTC)
* 終了   : 2026-06-25 08:30:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.156倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.003σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→21→25→19→21→25→19→21→22
* 開始   : 2026-06-25 13:40:00 (UTC)
* 終了   : 2026-06-25 13:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.356σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260625-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→20→17→20→17→20
* 開始   : 2026-06-25 15:00:00 (UTC)
* 終了   : 2026-06-25 15:05:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.8193(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.649σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 20→18→17→19→17→19→17→20→17
* 開始   : 2026-06-25 15:15:00 (UTC)
* 終了   : 2026-06-25 15:25:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→10→11→12→12→11→13→10→11
* 開始   : 2026-06-25 18:40:00 (UTC)
* 終了   : 2026-06-25 20:50:00 (UTC)
* 現象   : 2026-06-25 20:50:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.287, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→10→7→10→7→10→9
* 開始   : 2026-06-25 21:45:00 (UTC)
* 終了   : 2026-06-25 21:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→12→11→12→13→14
* 開始   : 2026-06-26 04:30:00 (UTC)
* 終了   : 2026-06-26 04:55:00 (UTC)
* 現象   : 2026-06-26 04:55:00 (UTC)を境に水準が 14.75から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→16→19→16→19→16→18
* 開始   : 2026-06-26 06:30:00 (UTC)
* 終了   : 2026-06-26 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.281倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.892σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→17→18→17→18→15
* 開始   : 2026-06-26 06:45:00 (UTC)
* 終了   : 2026-06-26 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 20→19→21→17→…→17→22→20→19
* 開始   : 2026-06-26 08:35:00 (UTC)
* 終了   : 2026-06-26 08:45:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→21→24→21→…→21→25→21→20
* 開始   : 2026-06-26 10:05:00 (UTC)
* 終了   : 2026-06-26 10:15:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260626-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→16→18→20→16→18→17
* 開始   : 2026-06-26 16:00:00 (UTC)
* 終了   : 2026-06-26 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260626-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→20→15→14→…→15→14→17→15
* 開始   : 2026-06-26 17:10:00 (UTC)
* 終了   : 2026-06-26 17:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→16→14→16→14→15→17
* 開始   : 2026-06-26 17:20:00 (UTC)
* 終了   : 2026-06-26 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→9→…→10→9→12→11
* 開始   : 2026-06-26 19:45:00 (UTC)
* 終了   : 2026-06-26 19:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→10→8→7→…→8→7→9→12
* 開始   : 2026-06-26 20:40:00 (UTC)
* 終了   : 2026-06-26 20:45:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→8→11→10→8→11→9
* 開始   : 2026-06-26 20:55:00 (UTC)
* 終了   : 2026-06-26 21:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→8→9→5→8→9
* 開始   : 2026-06-26 23:00:00 (UTC)
* 終了   : 2026-06-26 23:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.649σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host10-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→12→8→11→…→11→10→11→12
* 開始   : 2026-06-27 04:35:00 (UTC)
* 終了   : 2026-06-27 04:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.651)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260627-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260627-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→8→6→8→5→6→8→5→8
* 開始   : 2026-06-27 23:10:00 (UTC)
* 終了   : 2026-06-27 23:20:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260627-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 7→11→12→8→7→11→12→8→7
* 開始   : 2026-06-28 01:20:00 (UTC)
* 終了   : 2026-06-28 01:25:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→17→12→17→12→17→15→16
* 開始   : 2026-06-28 09:05:00 (UTC)
* 終了   : 2026-06-28 10:15:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260628-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→14→11→13→12→14→14→10→15
* 開始   : 2026-06-28 16:35:00 (UTC)
* 終了   : 2026-06-28 18:00:00 (UTC)
* 現象   : 2026-06-28 18:00:00 (UTC)を境に水準が 11.87から14.65へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.743, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→8→7→10→8→7→10→13
* 開始   : 2026-06-28 19:20:00 (UTC)
* 終了   : 2026-06-28 19:25:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.119σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→8→10→10→10→11→9→9→11
* 開始   : 2026-06-29 01:15:00 (UTC)
* 終了   : 2026-06-29 02:00:00 (UTC)
* 現象   : 2026-06-29 02:00:00 (UTC)を境に水準が 11.98から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.877, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→9→10→8→11→8→8→9→13
* 開始   : 2026-06-29 01:25:00 (UTC)
* 終了   : 2026-06-29 02:20:00 (UTC)
* 現象   : 2026-06-29 02:20:00 (UTC)を境に水準が 11.74から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.52, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→11→11→12→10→10→9→11→12
* 開始   : 2026-06-29 03:05:00 (UTC)
* 終了   : 2026-06-29 04:05:00 (UTC)
* 現象   : 2026-06-29 04:05:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→10→13→9→12
* 開始   : 2026-06-29 20:20:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 14.82から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→13→6→9→13→6→9
* 開始   : 2026-06-29 22:00:00 (UTC)
* 終了   : 2026-06-29 22:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260629-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→15→12
* 開始   : 2026-06-30 04:25:00 (UTC)
* 終了   : 2026-06-30 04:40:00 (UTC)
* 現象   : 2026-06-30 04:40:00 (UTC)を境に水準が 14.96から16.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.506, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→17→20→17→18
* 開始   : 2026-06-30 07:10:00 (UTC)
* 終了   : 2026-06-30 07:15:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.244倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→18→21→18→21→18→21→20
* 開始   : 2026-06-30 07:50:00 (UTC)
* 終了   : 2026-06-30 08:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→16→17→15→15→16→15→16→16
* 開始   : 2026-06-30 17:40:00 (UTC)
* 終了   : 2026-06-30 18:35:00 (UTC)
* 現象   : 2026-06-30 18:35:00 (UTC)を境に水準が 14.9から10.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host10-007 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
