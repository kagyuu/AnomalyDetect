# 異常検知サマリ 2026-06

## 1. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| ホスト数 | 17 |
| 系列数 | 156 |
| 検知イベント数 | 7229 (SEVERE: 416, FATAL: 2898, WARN: 3915, INFO: 0) |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 2. ホスト別の集計

| ホスト | SEVERE | FATAL | WARN | 計 | 主なメトリクス | レポート |
| --- | --- | --- | --- | --- | --- | --- |
| lsfhost01 | 46 | 849 | 1288 | 2183 | pend, run, njobs | report_lsfhost01_202606.md |
| host02 | 41 | 138 | 173 | 352 | active_connections, ou, mu | report_host02_202606.md |
| host01 | 32 | 132 | 184 | 348 | active_connections, eu, fgc_delta | report_host01_202606.md |
| host12 | 27 | 125 | 157 | 309 | active_connections | report_host12_202606.md |
| host07 | 26 | 128 | 130 | 284 | active_connections | report_host07_202606.md |
| host09 | 23 | 113 | 191 | 327 | active_connections | report_host09_202606.md |
| host08 | 22 | 130 | 127 | 279 | active_connections | report_host08_202606.md |
| host15 | 22 | 121 | 159 | 302 | active_connections | report_host15_202606.md |
| host10 | 21 | 137 | 184 | 342 | active_connections | report_host10_202606.md |
| host11 | 21 | 129 | 165 | 315 | active_connections | report_host11_202606.md |

(ほか 7 ホスト。脅威度の高い順に上位 10 件のみ表示。全ホストのファイルは report_*_202606.md にある)

## 3. 日別のイベント数

| 日 | SEVERE | FATAL | WARN | 計 |
| --- | --- | --- | --- | --- |
| 06-02 | 2 | 113 | 166 | 281 |
| 06-03 | 3 | 89 | 194 | 286 |
| 06-04 | 1 | 117 | 158 | 276 |
| 06-05 | 3 | 111 | 189 | 303 |
| 06-11 | 2 | 105 | 188 | 295 |
| 06-12 | 5 | 127 | 169 | 301 |
| 06-19 | 2 | 124 | 172 | 298 |
| 06-24 | 2 | 99 | 178 | 279 |
| 06-25 | 3 | 100 | 180 | 283 |
| 06-30 | 3 | 108 | 176 | 287 |

(全 30 日中、イベント数の多い上位 10 日のみ表示)

## 4. 複数ホストで同時に発生したアノマリー

| 時間帯 | ホスト数 | イベント数 | 関与したホスト | 主なメトリクス |
| --- | --- | --- | --- | --- |
| 2026-06-06 05:20 | 12 | 11 | host01, host03, host04 ほか 9 件 | active_connections, eu, njobs |
| 2026-06-13 05:25 | 14 | 10 | host01, host02, host03 ほか 11 件 | active_connections, eu, run |
| 2026-06-06 05:40 | 15 | 9 | host01, host02, host03 ほか 12 件 | active_connections, eu, njobs |
| 2026-06-20 05:50 | 12 | 9 | host01, host02, host03 ほか 9 件 | active_connections, eu |
| 2026-06-06 05:35 | 12 | 8 | host01, host02, host03 ほか 9 件 | active_connections, eu |
| 2026-06-27 06:05 | 11 | 8 | host01, host02, host03 ほか 8 件 | active_connections, eu |
| 2026-06-20 05:05 | 12 | 7 | host01, host02, host03 ほか 9 件 | active_connections, pend |
| 2026-06-20 05:40 | 12 | 7 | host01, host02, host03 ほか 9 件 | active_connections |

(ほか 2689 件。件数の多い順に上位 8 件のみ表示)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
