# host06 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host06 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 314 (SEVERE: 19, FATAL: 116, WARN: 179, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 116 | 179 | 314 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→15→…→13→14→13→12
* 開始   : 2026-06-08 01:25:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.75から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.875, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.163, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-001 active_connections の推移](charts/EVT-20260608-host06-001.svg)

# イベントID( EVT-20260608-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→15→17→14→…→11→14→13→10
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.887, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-004 active_connections の推移](charts/EVT-20260608-host06-004.svg)

# イベントID( EVT-20260608-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→15→…→15→14→15→13
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 20:55:00 (UTC)
* 現象   : 2026-06-08 20:55:00 (UTC)を境に水準が 11.92から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.31, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-005 active_connections の推移](charts/EVT-20260608-host06-005.svg)

# イベントID( EVT-20260608-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→16→…→15→14→13→12
* 開始   : 2026-06-08 04:00:00 (UTC)
* 終了   : 2026-06-08 20:45:00 (UTC)
* 現象   : 2026-06-08 20:45:00 (UTC)を境に水準が 11.87から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.769, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-006 active_connections の推移](charts/EVT-20260608-host06-006.svg)

# イベントID( EVT-20260608-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→15→…→14→16→13→14
* 開始   : 2026-06-08 04:15:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.85から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-007 active_connections の推移](charts/EVT-20260608-host06-007.svg)

# イベントID( EVT-20260615-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→15→…→12→14→13→12
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 11.79から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.134, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-002 active_connections の推移](charts/EVT-20260615-host06-002.svg)

# イベントID( EVT-20260615-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→16→18→15→…→12→14→13→12
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.96から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.532σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.904, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-003 active_connections の推移](charts/EVT-20260615-host06-003.svg)

# イベントID( EVT-20260615-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→16→…→14→13→14→12
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 11.87から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-004 active_connections の推移](charts/EVT-20260615-host06-004.svg)

# イベントID( EVT-20260615-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→16→…→13→14→13→14
* 開始   : 2026-06-15 02:50:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 11.93から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.798, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-005 active_connections の推移](charts/EVT-20260615-host06-005.svg)

# イベントID( EVT-20260615-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→18→…→17→16→13→15
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 19:10:00 (UTC)
* 現象   : 2026-06-15 19:10:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.435σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-006 active_connections の推移](charts/EVT-20260615-host06-006.svg)

# イベントID( EVT-20260622-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→19→16→19→…→11→12→11→13
* 開始   : 2026-06-22 00:55:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.807, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-001 active_connections の推移](charts/EVT-20260622-host06-001.svg)

# イベントID( EVT-20260622-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→15→20→18→…→11→13→11→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.82から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.94σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.872, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-004 active_connections の推移](charts/EVT-20260622-host06-004.svg)

# イベントID( EVT-20260622-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→18→…→13→15→12→15
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 21:20:00 (UTC)
* 現象   : 2026-06-22 21:20:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.708, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-005 active_connections の推移](charts/EVT-20260622-host06-005.svg)

# イベントID( EVT-20260622-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→12→15→14→…→12→14→12→13
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 19:45:00 (UTC)
* 現象   : 2026-06-22 19:45:00 (UTC)を境に水準が 11.77から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.841σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.82, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-007 active_connections の推移](charts/EVT-20260622-host06-007.svg)

# イベントID( EVT-20260629-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→18→…→14→13→11→12
* 開始   : 2026-06-29 01:10:00 (UTC)
* 終了   : 2026-06-29 19:25:00 (UTC)
* 現象   : 2026-06-29 19:25:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.911, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-001 active_connections の推移](charts/EVT-20260629-host06-001.svg)

# イベントID( EVT-20260629-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→16→…→16→13→12→13
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 21:45:00 (UTC)
* 現象   : 2026-06-29 21:45:00 (UTC)を境に水準が 11.92から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.74, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.846, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-003 active_connections の推移](charts/EVT-20260629-host06-003.svg)

# イベントID( EVT-20260629-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→16→…→14→13→14→15
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 19:30:00 (UTC)
* 現象   : 2026-06-29 19:30:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.228, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-004 active_connections の推移](charts/EVT-20260629-host06-004.svg)

# イベントID( EVT-20260629-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→13→…→14→11→14→13
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 19:10:00 (UTC)
* 現象   : 2026-06-29 19:10:00 (UTC)を境に水準が 11.93から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-005 active_connections の推移](charts/EVT-20260629-host06-005.svg)

# イベントID( EVT-20260629-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→15→18→13→15
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 19:25:00 (UTC)
* 現象   : 2026-06-29 19:25:00 (UTC)を境に水準が 11.98から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.914, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.341, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-006 active_connections の推移](charts/EVT-20260629-host06-006.svg)

# イベントID( EVT-20260601-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→15→14
* 開始   : 2026-06-01 05:25:00 (UTC)
* 終了   : 2026-06-01 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host06-005 active_connections の推移](charts/EVT-20260601-host06-005.svg)

# イベントID( EVT-20260601-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→20→21→23→…→21→23→17→18
* 開始   : 2026-06-01 08:10:00 (UTC)
* 終了   : 2026-06-01 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host06-008 active_connections の推移](charts/EVT-20260601-host06-008.svg)

# イベントID( EVT-20260601-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 24→21→17→23→24
* 開始   : 2026-06-01 13:40:00 (UTC)
* 終了   : 2026-06-01 13:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host06-010 active_connections の推移](charts/EVT-20260601-host06-010.svg)

# イベントID( EVT-20260602-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→18→22→15→16
* 開始   : 2026-06-02 17:05:00 (UTC)
* 終了   : 2026-06-02 17:05:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host06-005 active_connections の推移](charts/EVT-20260602-host06-005.svg)

# イベントID( EVT-20260602-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→17→13→15→15
* 開始   : 2026-06-02 17:20:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260602-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host06-006 active_connections の推移](charts/EVT-20260602-host06-006.svg)

# イベントID( EVT-20260602-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→10→13
* 開始   : 2026-06-02 20:05:00 (UTC)
* 終了   : 2026-06-02 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260602-host06-008 active_connections の推移](charts/EVT-20260602-host06-008.svg)

# イベントID( EVT-20260603-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→8→13→8→10
* 開始   : 2026-06-03 02:20:00 (UTC)
* 終了   : 2026-06-03 02:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host06-002 active_connections の推移](charts/EVT-20260603-host06-002.svg)

# イベントID( EVT-20260603-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→19→24→22→19
* 開始   : 2026-06-03 09:35:00 (UTC)
* 終了   : 2026-06-03 09:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-004 active_connections の推移](charts/EVT-20260603-host06-004.svg)

# イベントID( EVT-20260604-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→8→4→10→7
* 開始   : 2026-06-04 01:15:00 (UTC)
* 終了   : 2026-06-04 01:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host06-001 active_connections の推移](charts/EVT-20260604-host06-001.svg)

# イベントID( EVT-20260604-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→14→14
* 開始   : 2026-06-04 05:05:00 (UTC)
* 終了   : 2026-06-04 05:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-003 active_connections の推移](charts/EVT-20260604-host06-003.svg)

# イベントID( EVT-20260604-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→19→13→16→16
* 開始   : 2026-06-04 17:40:00 (UTC)
* 終了   : 2026-06-04 17:40:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host06-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-008 active_connections の推移](charts/EVT-20260604-host06-008.svg)

# イベントID( EVT-20260604-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 7→9→4→9→10
* 開始   : 2026-06-04 22:45:00 (UTC)
* 終了   : 2026-06-04 22:45:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260604-host06-012 active_connections の推移](charts/EVT-20260604-host06-012.svg)

# イベントID( EVT-20260605-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→9→9
* 開始   : 2026-06-05 02:35:00 (UTC)
* 終了   : 2026-06-05 02:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→17→20→17→14
* 開始   : 2026-06-05 06:15:00 (UTC)
* 終了   : 2026-06-05 06:15:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host06-004 active_connections の推移](charts/EVT-20260605-host06-004.svg)

# イベントID( EVT-20260605-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→15→21→18→18
* 開始   : 2026-06-05 07:40:00 (UTC)
* 終了   : 2026-06-05 07:40:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.287σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-007 active_connections の推移](charts/EVT-20260605-host06-007.svg)

# イベントID( EVT-20260605-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→20→…→20→25→19→22
* 開始   : 2026-06-05 09:25:00 (UTC)
* 終了   : 2026-06-05 09:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host06-008 active_connections の推移](charts/EVT-20260605-host06-008.svg)

# イベントID( EVT-20260605-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→23→17→24→20
* 開始   : 2026-06-05 11:30:00 (UTC)
* 終了   : 2026-06-05 11:30:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host06-010 active_connections の推移](charts/EVT-20260605-host06-010.svg)

# イベントID( EVT-20260606-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→6→12→8→13→12→8→13→10
* 開始   : 2026-06-06 03:10:00 (UTC)
* 終了   : 2026-06-06 03:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→11→…→12→11→12→11
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.126, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host06-004 active_connections の推移](charts/EVT-20260606-host06-004.svg)

# イベントID( EVT-20260606-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→9→…→13→12→13→10
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.125, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host06-005 active_connections の推移](charts/EVT-20260606-host06-005.svg)

# イベントID( EVT-20260606-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→12→…→12→11→12→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 18:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host06-006 active_connections の推移](charts/EVT-20260606-host06-006.svg)

# イベントID( EVT-20260606-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→13→…→10→11→12→13
* 開始   : 2026-06-06 06:05:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.748, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host06-007 active_connections の推移](charts/EVT-20260606-host06-007.svg)

# イベントID( EVT-20260606-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→13→11→14→…→11→12→10→12
* 開始   : 2026-06-06 06:25:00 (UTC)
* 終了   : 2026-06-06 18:25:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.852, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260606-host06-008 active_connections の推移](charts/EVT-20260606-host06-008.svg)

# イベントID( EVT-20260606-host06-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→10→14→12→…→12→10→13→11
* 開始   : 2026-06-06 06:50:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260606-host06-009 active_connections の推移](charts/EVT-20260606-host06-009.svg)

# イベントID( EVT-20260607-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→11→…→11→17→15→12
* 開始   : 2026-06-07 07:30:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260607-host06-005 active_connections の推移](charts/EVT-20260607-host06-005.svg)

# イベントID( EVT-20260607-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→12→9→12→14
* 開始   : 2026-06-07 17:25:00 (UTC)
* 終了   : 2026-06-07 17:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host06-009 active_connections の推移](charts/EVT-20260607-host06-009.svg)

# イベントID( EVT-20260608-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→17→…→16→13→15→14
* 開始   : 2026-06-08 01:45:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.84から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.947, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.009, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-002 active_connections の推移](charts/EVT-20260608-host06-002.svg)

# イベントID( EVT-20260610-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→18→22→18→18
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260610-host06-003 active_connections の推移](charts/EVT-20260610-host06-003.svg)

# イベントID( EVT-20260611-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 7→7→12→9→9
* 開始   : 2026-06-11 02:10:00 (UTC)
* 終了   : 2026-06-11 02:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→12→…→12→15→12→9
* 開始   : 2026-06-11 03:30:00 (UTC)
* 終了   : 2026-06-11 03:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host06-002 active_connections の推移](charts/EVT-20260611-host06-002.svg)

# イベントID( EVT-20260611-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 21→22→26→19→19
* 開始   : 2026-06-11 13:05:00 (UTC)
* 終了   : 2026-06-11 13:05:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-007 active_connections の推移](charts/EVT-20260611-host06-007.svg)

# イベントID( EVT-20260612-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→19→23→20→20
* 開始   : 2026-06-12 08:50:00 (UTC)
* 終了   : 2026-06-12 08:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host06-008 active_connections の推移](charts/EVT-20260612-host06-008.svg)

# イベントID( EVT-20260612-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→19→13→16→16
* 開始   : 2026-06-12 17:05:00 (UTC)
* 終了   : 2026-06-12 17:05:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-009 active_connections の推移](charts/EVT-20260612-host06-009.svg)

# イベントID( EVT-20260612-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→12→12
* 開始   : 2026-06-12 20:10:00 (UTC)
* 終了   : 2026-06-12 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host06-010 active_connections の推移](charts/EVT-20260612-host06-010.svg)

# イベントID( EVT-20260612-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→9→6→8→9→6→8→9
* 開始   : 2026-06-12 21:50:00 (UTC)
* 終了   : 2026-06-12 21:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-012 active_connections の推移](charts/EVT-20260612-host06-012.svg)

# イベントID( EVT-20260613-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→9→10→9→…→14→11→13→11
* 開始   : 2026-06-13 04:35:00 (UTC)
* 終了   : 2026-06-13 18:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.002, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host06-002 active_connections の推移](charts/EVT-20260613-host06-002.svg)

# イベントID( EVT-20260613-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→11→…→11→12→11→14
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:05:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host06-003 active_connections の推移](charts/EVT-20260613-host06-003.svg)

# イベントID( EVT-20260613-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→14→13→12→…→14→13→15→13
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.018σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.022, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host06-004 active_connections の推移](charts/EVT-20260613-host06-004.svg)

# イベントID( EVT-20260613-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→13→…→11→10→13→11
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.863, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260613-host06-005 active_connections の推移](charts/EVT-20260613-host06-005.svg)

# イベントID( EVT-20260613-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→8→…→12→14→12→9
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.1 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host06-006 active_connections の推移](charts/EVT-20260613-host06-006.svg)

# イベントID( EVT-20260613-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→14→12→11→…→11→13→12→14
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.685, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260613-host06-007 active_connections の推移](charts/EVT-20260613-host06-007.svg)

# イベントID( EVT-20260614-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→6→8
* 開始   : 2026-06-14 00:20:00 (UTC)
* 終了   : 2026-06-14 00:20:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host06-001 active_connections の推移](charts/EVT-20260614-host06-001.svg)

# イベントID( EVT-20260614-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 8→10→13→10→7
* 開始   : 2026-06-14 03:30:00 (UTC)
* 終了   : 2026-06-14 03:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260614-host06-002 active_connections の推移](charts/EVT-20260614-host06-002.svg)

# イベントID( EVT-20260614-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→11→12
* 開始   : 2026-06-14 04:55:00 (UTC)
* 終了   : 2026-06-14 05:05:00 (UTC)
* 現象   : 2026-06-14 05:05:00 (UTC)を境に水準が 11.78から12.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.039, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host06-003 active_connections の推移](charts/EVT-20260614-host06-003.svg)

# イベントID( EVT-20260615-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→14→…→13→14→12→11
* 開始   : 2026-06-15 03:35:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.8から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-007 active_connections の推移](charts/EVT-20260615-host06-007.svg)

# イベントID( EVT-20260616-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→12→13
* 開始   : 2026-06-16 05:10:00 (UTC)
* 終了   : 2026-06-16 05:10:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-003 active_connections の推移](charts/EVT-20260616-host06-003.svg)

# イベントID( EVT-20260616-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→15→19→14→16
* 開始   : 2026-06-16 06:20:00 (UTC)
* 終了   : 2026-06-16 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-004 active_connections の推移](charts/EVT-20260616-host06-004.svg)

# イベントID( EVT-20260616-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→19→15→20→18
* 開始   : 2026-06-16 16:05:00 (UTC)
* 終了   : 2026-06-16 16:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-012 active_connections の推移](charts/EVT-20260616-host06-012.svg)

# イベントID( EVT-20260616-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→18→15→18→17
* 開始   : 2026-06-16 16:15:00 (UTC)
* 終了   : 2026-06-16 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-013 active_connections の推移](charts/EVT-20260616-host06-013.svg)

# イベントID( EVT-20260616-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→18→15→17→18
* 開始   : 2026-06-16 16:15:00 (UTC)
* 終了   : 2026-06-16 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-014 active_connections の推移](charts/EVT-20260616-host06-014.svg)

# イベントID( EVT-20260616-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→10→6→9→9
* 開始   : 2026-06-16 21:00:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-016 active_connections の推移](charts/EVT-20260616-host06-016.svg)

# イベントID( EVT-20260616-host06-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→10→6→10→9
* 開始   : 2026-06-16 21:40:00 (UTC)
* 終了   : 2026-06-16 21:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host06-017 active_connections の推移](charts/EVT-20260616-host06-017.svg)

# イベントID( EVT-20260617-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→21→24→22→20
* 開始   : 2026-06-17 09:45:00 (UTC)
* 終了   : 2026-06-17 09:45:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-009 active_connections の推移](charts/EVT-20260617-host06-009.svg)

# イベントID( EVT-20260617-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→16→15
* 開始   : 2026-06-17 18:05:00 (UTC)
* 終了   : 2026-06-17 18:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-013 active_connections の推移](charts/EVT-20260617-host06-013.svg)

# イベントID( EVT-20260617-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→9→5→10→9
* 開始   : 2026-06-17 22:20:00 (UTC)
* 終了   : 2026-06-17 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→11→10→10→10→10→9
* 開始   : 2026-06-18 02:35:00 (UTC)
* 終了   : 2026-06-18 03:50:00 (UTC)
* 現象   : 2026-06-18 03:50:00 (UTC)を境に水準が 15.02から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.425, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host06-001 active_connections の推移](charts/EVT-20260618-host06-001.svg)

# イベントID( EVT-20260618-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→10→10
* 開始   : 2026-06-18 03:40:00 (UTC)
* 終了   : 2026-06-18 03:40:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host06-002 active_connections の推移](charts/EVT-20260618-host06-002.svg)

# イベントID( EVT-20260618-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→19→25→22→22
* 開始   : 2026-06-18 10:00:00 (UTC)
* 終了   : 2026-06-18 10:00:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host06-009 active_connections の推移](charts/EVT-20260618-host06-009.svg)

# イベントID( EVT-20260618-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→8→13→7→6
* 開始   : 2026-06-18 22:55:00 (UTC)
* 終了   : 2026-06-18 22:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host06-012 active_connections の推移](charts/EVT-20260618-host06-012.svg)

# イベントID( EVT-20260619-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→11→14→15→11→14→15→11→9
* 開始   : 2026-06-19 03:40:00 (UTC)
* 終了   : 2026-06-19 03:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.388倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-004 active_connections の推移](charts/EVT-20260619-host06-004.svg)

# イベントID( EVT-20260619-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→14→12→15→13→13
* 開始   : 2026-06-19 04:15:00 (UTC)
* 終了   : 2026-06-19 04:40:00 (UTC)
* 現象   : 2026-06-19 04:40:00 (UTC)を境に水準が 15.15から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.618σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-005 active_connections の推移](charts/EVT-20260619-host06-005.svg)

# イベントID( EVT-20260619-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→11→15→13→10
* 開始   : 2026-06-19 04:20:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host06-006 active_connections の推移](charts/EVT-20260619-host06-006.svg)

# イベントID( EVT-20260619-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→15→18→15→14
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-007 active_connections の推移](charts/EVT-20260619-host06-007.svg)

# イベントID( EVT-20260619-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→18→22→18→18
* 開始   : 2026-06-19 07:40:00 (UTC)
* 終了   : 2026-06-19 07:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.313倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.651σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host06-008 active_connections の推移](charts/EVT-20260619-host06-008.svg)

# イベントID( EVT-20260619-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→17→22→20→17
* 開始   : 2026-06-19 08:05:00 (UTC)
* 終了   : 2026-06-19 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-009 active_connections の推移](charts/EVT-20260619-host06-009.svg)

# イベントID( EVT-20260619-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→11→13→14
* 開始   : 2026-06-19 18:40:00 (UTC)
* 終了   : 2026-06-19 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host06-011 active_connections の推移](charts/EVT-20260619-host06-011.svg)

# イベントID( EVT-20260619-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→13→9→13→10→9→13→10→12
* 開始   : 2026-06-19 19:10:00 (UTC)
* 終了   : 2026-06-19 19:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260619-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-012 active_connections の推移](charts/EVT-20260619-host06-012.svg)

# イベントID( EVT-20260619-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 7→8→5→8→7
* 開始   : 2026-06-19 22:15:00 (UTC)
* 終了   : 2026-06-19 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-015 active_connections の推移](charts/EVT-20260619-host06-015.svg)

# イベントID( EVT-20260619-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→9→10
* 開始   : 2026-06-19 22:20:00 (UTC)
* 終了   : 2026-06-19 22:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host06-016 active_connections の推移](charts/EVT-20260619-host06-016.svg)

# イベントID( EVT-20260620-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→9→10→12→…→9→10→12→11
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.94, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260620-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260620-host06-001 active_connections の推移](charts/EVT-20260620-host06-001.svg)

# イベントID( EVT-20260620-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→11→…→13→10→13→11
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.897, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host06-002 active_connections の推移](charts/EVT-20260620-host06-002.svg)

# イベントID( EVT-20260620-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→11→…→10→9→11→9
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.361, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host06-003 active_connections の推移](charts/EVT-20260620-host06-003.svg)

# イベントID( EVT-20260620-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→10→13→10→…→15→14→15→13
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.33, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host06-004 active_connections の推移](charts/EVT-20260620-host06-004.svg)

# イベントID( EVT-20260620-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→12→10→11→…→10→11→12→11
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 20:30:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.167, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260620-host06-005 active_connections の推移](charts/EVT-20260620-host06-005.svg)

# イベントID( EVT-20260620-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→13→…→15→12→14→11
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260620-host06-006 active_connections の推移](charts/EVT-20260620-host06-006.svg)

# イベントID( EVT-20260622-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→14→15→14→…→14→13→12→13
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 19:15:00 (UTC)
* 現象   : 2026-06-22 19:15:00 (UTC)を境に水準が 11.83から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.728, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-003 active_connections の推移](charts/EVT-20260622-host06-003.svg)

# イベントID( EVT-20260622-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→14→…→13→14→10→11
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.83から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.978, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-006 active_connections の推移](charts/EVT-20260622-host06-006.svg)

# イベントID( EVT-20260622-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→9→5→8→9
* 開始   : 2026-06-22 21:55:00 (UTC)
* 終了   : 2026-06-22 21:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host06-008 active_connections の推移](charts/EVT-20260622-host06-008.svg)

# イベントID( EVT-20260623-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→11→15→13→12
* 開始   : 2026-06-23 04:10:00 (UTC)
* 終了   : 2026-06-23 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-004 active_connections の推移](charts/EVT-20260623-host06-004.svg)

# イベントID( EVT-20260623-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 21→22→17→21→22
* 開始   : 2026-06-23 14:25:00 (UTC)
* 終了   : 2026-06-23 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→12→10→12→10→12→10→12
* 開始   : 2026-06-23 18:50:00 (UTC)
* 終了   : 2026-06-23 19:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.6102(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.999σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260623-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260623-host06-009 active_connections の推移](charts/EVT-20260623-host06-009.svg)

# イベントID( EVT-20260623-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→7→…→11→5→11→8
* 開始   : 2026-06-23 21:25:00 (UTC)
* 終了   : 2026-06-23 21:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host06-010 active_connections の推移](charts/EVT-20260623-host06-010.svg)

# イベントID( EVT-20260624-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→11→17→15→15
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-002 active_connections の推移](charts/EVT-20260624-host06-002.svg)

# イベントID( EVT-20260624-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→17→20→16→18
* 開始   : 2026-06-24 06:55:00 (UTC)
* 終了   : 2026-06-24 06:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→19→23→21→18
* 開始   : 2026-06-24 08:45:00 (UTC)
* 終了   : 2026-06-24 08:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host06-005 active_connections の推移](charts/EVT-20260624-host06-005.svg)

# イベントID( EVT-20260624-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→17→23→20→19
* 開始   : 2026-06-24 09:00:00 (UTC)
* 終了   : 2026-06-24 09:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→16→15→18→19→16→15→18
* 開始   : 2026-06-24 15:20:00 (UTC)
* 終了   : 2026-06-24 16:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260624-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-009 active_connections の推移](charts/EVT-20260624-host06-009.svg)

# イベントID( EVT-20260625-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→13→12
* 開始   : 2026-06-25 04:55:00 (UTC)
* 終了   : 2026-06-25 04:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-005 active_connections の推移](charts/EVT-20260625-host06-005.svg)

# イベントID( EVT-20260625-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→15→19→15→15
* 開始   : 2026-06-25 06:00:00 (UTC)
* 終了   : 2026-06-25 06:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host06-006 active_connections の推移](charts/EVT-20260625-host06-006.svg)

# イベントID( EVT-20260625-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→20→21
* 開始   : 2026-06-25 08:05:00 (UTC)
* 終了   : 2026-06-25 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host06-007 active_connections の推移](charts/EVT-20260625-host06-007.svg)

# イベントID( EVT-20260625-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→21→16→20→20
* 開始   : 2026-06-25 14:25:00 (UTC)
* 終了   : 2026-06-25 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.75(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host06-008 active_connections の推移](charts/EVT-20260625-host06-008.svg)

# イベントID( EVT-20260625-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→16→12→14→15
* 開始   : 2026-06-25 18:00:00 (UTC)
* 終了   : 2026-06-25 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host06-011 active_connections の推移](charts/EVT-20260625-host06-011.svg)

# イベントID( EVT-20260625-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→14→12
* 開始   : 2026-06-25 18:55:00 (UTC)
* 終了   : 2026-06-25 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host06-012 active_connections の推移](charts/EVT-20260625-host06-012.svg)

# イベントID( EVT-20260626-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→13→11
* 開始   : 2026-06-26 04:00:00 (UTC)
* 終了   : 2026-06-26 04:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.594σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-001 active_connections の推移](charts/EVT-20260626-host06-001.svg)

# イベントID( EVT-20260626-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→13→16→16→16
* 開始   : 2026-06-26 05:00:00 (UTC)
* 終了   : 2026-06-26 05:20:00 (UTC)
* 現象   : 2026-06-26 05:20:00 (UTC)を境に水準が 15.03から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.085σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host06-002 active_connections の推移](charts/EVT-20260626-host06-002.svg)

# イベントID( EVT-20260626-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→16→20→16→21→20→16→21→17
* 開始   : 2026-06-26 07:25:00 (UTC)
* 終了   : 2026-06-26 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-004 active_connections の推移](charts/EVT-20260626-host06-004.svg)

# イベントID( EVT-20260626-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→17→21→18→19
* 開始   : 2026-06-26 07:30:00 (UTC)
* 終了   : 2026-06-26 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-005 active_connections の推移](charts/EVT-20260626-host06-005.svg)

# イベントID( EVT-20260626-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→19→23→18→23→18→23→20
* 開始   : 2026-06-26 09:00:00 (UTC)
* 終了   : 2026-06-26 09:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.229σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-006 active_connections の推移](charts/EVT-20260626-host06-006.svg)

# イベントID( EVT-20260626-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→21→16→20→21
* 開始   : 2026-06-26 14:40:00 (UTC)
* 終了   : 2026-06-26 14:40:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.7529(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.651σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host06-010 active_connections の推移](charts/EVT-20260626-host06-010.svg)

# イベントID( EVT-20260626-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→18→14→19→18
* 開始   : 2026-06-26 16:35:00 (UTC)
* 終了   : 2026-06-26 16:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260626-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-011 active_connections の推移](charts/EVT-20260626-host06-011.svg)

# イベントID( EVT-20260626-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→13→9→11→13
* 開始   : 2026-06-26 19:30:00 (UTC)
* 終了   : 2026-06-26 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host06-013 active_connections の推移](charts/EVT-20260626-host06-013.svg)

# イベントID( EVT-20260626-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→13→…→8→9→11→12
* 開始   : 2026-06-26 19:40:00 (UTC)
* 終了   : 2026-06-26 19:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260626-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260626-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-014 active_connections の推移](charts/EVT-20260626-host06-014.svg)

# イベントID( EVT-20260627-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→11→…→12→10→12→10
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.7 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260627-host06-001 active_connections の推移](charts/EVT-20260627-host06-001.svg)

# イベントID( EVT-20260627-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→12→…→12→11→12→14
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.925, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host06-002 active_connections の推移](charts/EVT-20260627-host06-002.svg)

# イベントID( EVT-20260627-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→8→10→12→…→11→12→14→10
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host06-003 active_connections の推移](charts/EVT-20260627-host06-003.svg)

# イベントID( EVT-20260627-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→10→…→12→13→14→12
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.306, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host06-004 active_connections の推移](charts/EVT-20260627-host06-004.svg)

# イベントID( EVT-20260627-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→11→12→11→…→13→11→15→10
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.827, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host06-005 active_connections の推移](charts/EVT-20260627-host06-005.svg)

# イベントID( EVT-20260627-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→13→11→13→12
* 開始   : 2026-06-27 06:20:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260627-host06-006 active_connections の推移](charts/EVT-20260627-host06-006.svg)

# イベントID( EVT-20260628-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 6→8→13→8→8
* 開始   : 2026-06-28 02:40:00 (UTC)
* 終了   : 2026-06-28 02:40:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host06-001 active_connections の推移](charts/EVT-20260628-host06-001.svg)

# イベントID( EVT-20260628-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→11→5→8→8
* 開始   : 2026-06-28 22:15:00 (UTC)
* 終了   : 2026-06-28 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→17→…→12→13→12→13
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.84から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.984, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-002 active_connections の推移](charts/EVT-20260629-host06-002.svg)

# イベントID( EVT-20260630-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→9→15→9→11
* 開始   : 2026-06-30 03:40:00 (UTC)
* 終了   : 2026-06-30 03:40:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.362σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host06-001 active_connections の推移](charts/EVT-20260630-host06-001.svg)

# イベントID( EVT-20260630-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→11→15→10→11
* 開始   : 2026-06-30 03:45:00 (UTC)
* 終了   : 2026-06-30 03:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host06-002 active_connections の推移](charts/EVT-20260630-host06-002.svg)

# イベントID( EVT-20260630-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→15→13
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-004 active_connections の推移](charts/EVT-20260630-host06-004.svg)

# イベントID( EVT-20260630-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→14→20→16→16
* 開始   : 2026-06-30 06:40:00 (UTC)
* 終了   : 2026-06-30 06:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-006 active_connections の推移](charts/EVT-20260630-host06-006.svg)

# イベントID( EVT-20260630-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→17→20→18→18
* 開始   : 2026-06-30 07:05:00 (UTC)
* 終了   : 2026-06-30 07:05:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-007 active_connections の推移](charts/EVT-20260630-host06-007.svg)

# イベントID( EVT-20260601-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→5→…→6→5→9→8
* 開始   : 2026-06-01 00:45:00 (UTC)
* 終了   : 2026-06-01 00:50:00 (UTC)
* 現象   : 平常時(9.111)に対し 0.6585(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→11→14→11→14→10→11
* 開始   : 2026-06-01 03:50:00 (UTC)
* 終了   : 2026-06-01 04:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→12→11→15→12
* 開始   : 2026-06-01 04:15:00 (UTC)
* 終了   : 2026-06-01 04:20:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→15→13→11→15→13→11
* 開始   : 2026-06-01 04:30:00 (UTC)
* 終了   : 2026-06-01 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→13→16→13→17→16→13→17→15
* 開始   : 2026-06-01 05:25:00 (UTC)
* 終了   : 2026-06-01 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→15→18→15→18→17→15
* 開始   : 2026-06-01 06:25:00 (UTC)
* 終了   : 2026-06-01 06:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260601-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→21→23→22→…→22→17→20→21
* 開始   : 2026-06-01 09:20:00 (UTC)
* 終了   : 2026-06-01 09:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→17→18→19→16→17→18
* 開始   : 2026-06-01 15:45:00 (UTC)
* 終了   : 2026-06-01 15:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.998σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→13→…→13→10→14→11
* 開始   : 2026-06-01 19:15:00 (UTC)
* 終了   : 2026-06-01 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→9→13→9→13→9→11→13
* 開始   : 2026-06-01 20:00:00 (UTC)
* 終了   : 2026-06-01 20:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→13→16→13→16→14→16
* 開始   : 2026-06-02 05:10:00 (UTC)
* 終了   : 2026-06-02 05:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→18→19→18
* 開始   : 2026-06-02 06:45:00 (UTC)
* 終了   : 2026-06-02 07:00:00 (UTC)
* 現象   : 2026-06-02 07:00:00 (UTC)を境に水準が 15.04から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→21→22→21→22→20
* 開始   : 2026-06-02 09:05:00 (UTC)
* 終了   : 2026-06-02 09:10:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→22→23→23→21→22→21→23→22
* 開始   : 2026-06-02 10:20:00 (UTC)
* 終了   : 2026-06-02 11:30:00 (UTC)
* 現象   : 2026-06-02 11:30:00 (UTC)を境に水準が 14.98から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→13→13→15→16→14→14→15→12
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 20:25:00 (UTC)
* 現象   : 2026-06-02 20:25:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.314, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→13→7→11→13→7→11→10
* 開始   : 2026-06-02 21:25:00 (UTC)
* 終了   : 2026-06-02 21:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.6412(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.71σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→8→11→8→11→8→10
* 開始   : 2026-06-03 02:20:00 (UTC)
* 終了   : 2026-06-03 02:25:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→21→22→22→21→22→23→21→24
* 開始   : 2026-06-03 09:10:00 (UTC)
* 終了   : 2026-06-03 11:00:00 (UTC)
* 現象   : 2026-06-03 11:00:00 (UTC)を境に水準が 14.89から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→20→15→16→15→16→15→19→20
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→17→13→14→17→13→15
* 開始   : 2026-06-03 17:25:00 (UTC)
* 終了   : 2026-06-03 17:35:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→9→10→9
* 開始   : 2026-06-03 23:50:00 (UTC)
* 終了   : 2026-06-04 00:15:00 (UTC)
* 現象   : 2026-06-04 00:15:00 (UTC)を境に水準が 14.92から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→12→11→13→13→11→12
* 開始   : 2026-06-04 03:25:00 (UTC)
* 終了   : 2026-06-04 03:55:00 (UTC)
* 現象   : 2026-06-04 03:55:00 (UTC)を境に水準が 14.97から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.425, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→17→18→14→17→18→14→16
* 開始   : 2026-06-04 05:55:00 (UTC)
* 終了   : 2026-06-04 06:00:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→21→22→23→20→21→22→23→20
* 開始   : 2026-06-04 09:00:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 22→20→21→22
* 開始   : 2026-06-04 14:50:00 (UTC)
* 終了   : 2026-06-04 15:05:00 (UTC)
* 現象   : 2026-06-04 15:05:00 (UTC)を境に水準が 15.05から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.386, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→19→20→20→16→20
* 開始   : 2026-06-04 16:10:00 (UTC)
* 終了   : 2026-06-04 16:35:00 (UTC)
* 現象   : 2026-06-04 16:35:00 (UTC)を境に水準が 14.98から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→…→14→16→13→14
* 開始   : 2026-06-04 17:40:00 (UTC)
* 終了   : 2026-06-04 17:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→16→16→18→15→16
* 開始   : 2026-06-04 17:50:00 (UTC)
* 終了   : 2026-06-04 18:15:00 (UTC)
* 現象   : 2026-06-04 18:15:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→12→13→14→12→13→12
* 開始   : 2026-06-04 18:40:00 (UTC)
* 終了   : 2026-06-04 18:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→7→9→9→11→10→8→10
* 開始   : 2026-06-04 23:00:00 (UTC)
* 終了   : 2026-06-05 00:00:00 (UTC)
* 現象   : 2026-06-05 00:00:00 (UTC)を境に水準が 15.01から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.504, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→10→11→10→11→7
* 開始   : 2026-06-05 01:10:00 (UTC)
* 終了   : 2026-06-05 01:20:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-003 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→15→…→14→15→14→13
* 開始   : 2026-06-05 04:55:00 (UTC)
* 終了   : 2026-06-05 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→15→19→16→19→16→19→16→17
* 開始   : 2026-06-05 06:35:00 (UTC)
* 終了   : 2026-06-05 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.957σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→20→20
* 開始   : 2026-06-05 07:05:00 (UTC)
* 終了   : 2026-06-05 07:15:00 (UTC)
* 現象   : 2026-06-05 07:15:00 (UTC)を境に水準が 15.04から14.64へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.039, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 20→19→24→22→19→24→22→23
* 開始   : 2026-06-05 10:15:00 (UTC)
* 終了   : 2026-06-05 10:20:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 23→24→21→23→23→21→22→20→23
* 開始   : 2026-06-05 12:25:00 (UTC)
* 終了   : 2026-06-05 14:15:00 (UTC)
* 現象   : 2026-06-05 14:15:00 (UTC)を境に水準が 15.01から12.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→20→18→24→…→18→24→19→18
* 開始   : 2026-06-05 14:50:00 (UTC)
* 終了   : 2026-06-05 14:55:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→16→17→15→16→17
* 開始   : 2026-06-05 16:50:00 (UTC)
* 終了   : 2026-06-05 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→16→13→16→13→16→13→15→16
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 18:05:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→12→14→15→14
* 開始   : 2026-06-05 18:40:00 (UTC)
* 終了   : 2026-06-05 19:10:00 (UTC)
* 現象   : 2026-06-05 19:10:00 (UTC)を境に水準が 15.02から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→10→…→11→10→12→14
* 開始   : 2026-06-05 19:00:00 (UTC)
* 終了   : 2026-06-05 19:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→9→…→10→9→10→12
* 開始   : 2026-06-05 19:40:00 (UTC)
* 終了   : 2026-06-05 19:45:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host06-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→9→13→10→13→10→13→10→13
* 開始   : 2026-06-06 04:15:00 (UTC)
* 終了   : 2026-06-06 04:25:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260606-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260606-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260606-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→7→13→12→10→7→13→12→9
* 開始   : 2026-06-06 04:40:00 (UTC)
* 終了   : 2026-06-06 04:45:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260606-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→6→5→11→…→5→11→9→7
* 開始   : 2026-06-07 00:35:00 (UTC)
* 終了   : 2026-06-07 00:40:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→10→10→8→10→10→11
* 開始   : 2026-06-07 01:45:00 (UTC)
* 終了   : 2026-06-07 02:45:00 (UTC)
* 現象   : 2026-06-07 02:45:00 (UTC)を境に水準が 11.79から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→12→14→13→13→15
* 開始   : 2026-06-07 06:25:00 (UTC)
* 終了   : 2026-06-07 06:50:00 (UTC)
* 現象   : 2026-06-07 06:50:00 (UTC)を境に水準が 11.86から12.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→13→14→15
* 開始   : 2026-06-07 07:20:00 (UTC)
* 終了   : 2026-06-07 07:35:00 (UTC)
* 現象   : 2026-06-07 07:35:00 (UTC)を境に水準が 11.72から12.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→16→…→16→18→17→16
* 開始   : 2026-06-07 13:00:00 (UTC)
* 終了   : 2026-06-07 13:10:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→15→15→16→16
* 開始   : 2026-06-07 15:10:00 (UTC)
* 終了   : 2026-06-07 15:30:00 (UTC)
* 現象   : 2026-06-07 15:30:00 (UTC)を境に水準が 11.81から14.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.732, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→17→14→15
* 開始   : 2026-06-07 16:00:00 (UTC)
* 終了   : 2026-06-07 16:25:00 (UTC)
* 現象   : 2026-06-07 16:25:00 (UTC)を境に水準が 11.91から14.56へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→12→8→11→…→11→14→12→9
* 開始   : 2026-06-07 18:40:00 (UTC)
* 終了   : 2026-06-07 18:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→8→9→11→8→10→10→9→10
* 開始   : 2026-06-07 21:55:00 (UTC)
* 終了   : 2026-06-07 22:35:00 (UTC)
* 現象   : 2026-06-07 22:35:00 (UTC)を境に水準が 11.79から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.501, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 7→8→5→7→8→5→7→9
* 開始   : 2026-06-07 23:25:00 (UTC)
* 終了   : 2026-06-07 23:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→9→8→12→9→11
* 開始   : 2026-06-08 02:15:00 (UTC)
* 終了   : 2026-06-08 02:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→10→9→7→9→11→10→9→11
* 開始   : 2026-06-08 21:45:00 (UTC)
* 終了   : 2026-06-08 23:10:00 (UTC)
* 現象   : 2026-06-08 23:10:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.811, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→18→15→14→17→18→15
* 開始   : 2026-06-09 05:45:00 (UTC)
* 終了   : 2026-06-09 05:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→20→…→19→20→16→17
* 開始   : 2026-06-09 07:05:00 (UTC)
* 終了   : 2026-06-09 07:10:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→19→21→20→21→20→21→19→18
* 開始   : 2026-06-09 07:45:00 (UTC)
* 終了   : 2026-06-09 07:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 22→25→21→26→25→21→26→21→22
* 開始   : 2026-06-09 11:45:00 (UTC)
* 終了   : 2026-06-09 11:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→23→24→21→…→20→18→21→19
* 開始   : 2026-06-09 14:10:00 (UTC)
* 終了   : 2026-06-09 14:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→19→16→18→16→18→16→17→21
* 開始   : 2026-06-09 16:20:00 (UTC)
* 終了   : 2026-06-09 16:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260609-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→15→18→16→13→16→16→17→16
* 開始   : 2026-06-09 17:30:00 (UTC)
* 終了   : 2026-06-09 18:30:00 (UTC)
* 現象   : 2026-06-09 18:30:00 (UTC)を境に水準が 15.04から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.118, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→11→15→16→15→11→15→16→15
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→18→16→18→19→18→15
* 開始   : 2026-06-10 06:40:00 (UTC)
* 終了   : 2026-06-10 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→14→13→14→…→14→11→15→13
* 開始   : 2026-06-10 18:15:00 (UTC)
* 終了   : 2026-06-10 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→11→9→10→9→8→10→10→10
* 開始   : 2026-06-10 21:55:00 (UTC)
* 終了   : 2026-06-10 22:40:00 (UTC)
* 現象   : 2026-06-10 22:40:00 (UTC)を境に水準が 15.06から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→13→15→11→…→11→9→14→12
* 開始   : 2026-06-11 04:40:00 (UTC)
* 終了   : 2026-06-11 04:50:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260611-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→17→19→20→21→17→20
* 開始   : 2026-06-11 07:55:00 (UTC)
* 終了   : 2026-06-11 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→21→22→19→21→22→19→21
* 開始   : 2026-06-11 08:40:00 (UTC)
* 終了   : 2026-06-11 08:45:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 23→22→20→23→21→23→22→23→24
* 開始   : 2026-06-11 09:50:00 (UTC)
* 終了   : 2026-06-11 10:30:00 (UTC)
* 現象   : 2026-06-11 10:30:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 21→23→22→22→22→24→21→22→23
* 開始   : 2026-06-11 13:30:00 (UTC)
* 終了   : 2026-06-11 14:10:00 (UTC)
* 現象   : 2026-06-11 14:10:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→14→16→10→11→14→16→10→11
* 開始   : 2026-06-11 19:45:00 (UTC)
* 終了   : 2026-06-11 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→11→…→5→11→10→7
* 開始   : 2026-06-11 23:05:00 (UTC)
* 終了   : 2026-06-11 23:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→8→9→9→6→10→10→9→10
* 開始   : 2026-06-11 23:50:00 (UTC)
* 終了   : 2026-06-12 00:55:00 (UTC)
* 現象   : 2026-06-12 00:55:00 (UTC)を境に水準が 14.98から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→11→13→9→11→13→9→10
* 開始   : 2026-06-12 03:30:00 (UTC)
* 終了   : 2026-06-12 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.422σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→13→10→14→13→10→12
* 開始   : 2026-06-12 04:00:00 (UTC)
* 終了   : 2026-06-12 04:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.412倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→15→14→16→15→14
* 開始   : 2026-06-12 05:40:00 (UTC)
* 終了   : 2026-06-12 05:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→16→16→17→18→16→17→18
* 開始   : 2026-06-12 06:05:00 (UTC)
* 終了   : 2026-06-12 06:40:00 (UTC)
* 現象   : 2026-06-12 06:40:00 (UTC)を境に水準が 15から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→17→15→18→17→16
* 開始   : 2026-06-12 06:35:00 (UTC)
* 終了   : 2026-06-12 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→21→22→18→22→18→22→20
* 開始   : 2026-06-12 08:25:00 (UTC)
* 終了   : 2026-06-12 08:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260612-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→17→21→20→…→20→22→20→18
* 開始   : 2026-06-12 08:40:00 (UTC)
* 終了   : 2026-06-12 08:50:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260612-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→8→12→8→12→8→11
* 開始   : 2026-06-12 20:30:00 (UTC)
* 終了   : 2026-06-12 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→11→10→9→10
* 開始   : 2026-06-12 23:25:00 (UTC)
* 終了   : 2026-06-12 23:45:00 (UTC)
* 現象   : 2026-06-12 23:45:00 (UTC)を境に水準が 15から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.278, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→11→8→9→…→8→9→12→11
* 開始   : 2026-06-13 04:15:00 (UTC)
* 終了   : 2026-06-13 04:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260613-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→10→9→10→…→9→10→11→12
* 開始   : 2026-06-13 19:20:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.705, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10 分
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260613-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→17→14→13→17→14
* 開始   : 2026-06-14 08:40:00 (UTC)
* 終了   : 2026-06-14 08:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→18→16→15→17→17→16
* 開始   : 2026-06-14 11:15:00 (UTC)
* 終了   : 2026-06-14 11:45:00 (UTC)
* 現象   : 2026-06-14 11:45:00 (UTC)を境に水準が 11.84から13.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.425, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→12→13→12→11→12
* 開始   : 2026-06-14 18:40:00 (UTC)
* 終了   : 2026-06-14 19:10:00 (UTC)
* 現象   : 2026-06-14 19:10:00 (UTC)を境に水準が 11.84から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.425, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→7→9→9→7→11→9
* 開始   : 2026-06-15 00:10:00 (UTC)
* 終了   : 2026-06-15 01:30:00 (UTC)
* 現象   : 2026-06-15 01:30:00 (UTC)を境に水準が 11.87から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.89, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→9→11→5→9→11→5→9→7
* 開始   : 2026-06-16 01:00:00 (UTC)
* 終了   : 2026-06-16 01:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→13→…→12→13→11→9
* 開始   : 2026-06-16 02:40:00 (UTC)
* 終了   : 2026-06-16 02:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260616-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→13→17→14→17→14→17→16→17
* 開始   : 2026-06-16 06:20:00 (UTC)
* 終了   : 2026-06-16 06:30:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.249σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→16→18→19→16→17
* 開始   : 2026-06-16 06:50:00 (UTC)
* 終了   : 2026-06-16 06:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→18→21→19→…→19→22→19→20
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→21→16→22→…→22→16→22→21
* 開始   : 2026-06-16 09:05:00 (UTC)
* 終了   : 2026-06-16 09:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 21→23→25→19→22→23→25→19→22
* 開始   : 2026-06-16 11:35:00 (UTC)
* 終了   : 2026-06-16 11:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→19→18→19→18→20→19
* 開始   : 2026-06-16 14:20:00 (UTC)
* 終了   : 2026-06-16 15:00:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→19→20→18→18→19→18→16→19
* 開始   : 2026-06-16 15:45:00 (UTC)
* 終了   : 2026-06-16 16:35:00 (UTC)
* 現象   : 2026-06-16 16:35:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.844, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→16→20→14→16→20→17
* 開始   : 2026-06-16 16:30:00 (UTC)
* 終了   : 2026-06-16 16:40:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→11→5→7→8→11→5→7→9
* 開始   : 2026-06-16 23:55:00 (UTC)
* 終了   : 2026-06-17 00:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host06-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→9→9→10→9→10→11
* 開始   : 2026-06-17 01:15:00 (UTC)
* 終了   : 2026-06-17 02:30:00 (UTC)
* 現象   : 2026-06-17 02:30:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.018σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.846, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→12→9→13→12→9→13→10→9
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→12→10→12→10→9
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→13→…→13→15→10→12
* 開始   : 2026-06-17 03:35:00 (UTC)
* 終了   : 2026-06-17 03:45:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→13→11→14→13→13→14
* 開始   : 2026-06-17 03:50:00 (UTC)
* 終了   : 2026-06-17 04:45:00 (UTC)
* 現象   : 2026-06-17 04:45:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.134σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→17→19→18→17→19→18→17
* 開始   : 2026-06-17 06:55:00 (UTC)
* 終了   : 2026-06-17 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→17→21→19→17→21→19→18
* 開始   : 2026-06-17 08:10:00 (UTC)
* 終了   : 2026-06-17 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 21→21→20→22
* 開始   : 2026-06-17 08:20:00 (UTC)
* 終了   : 2026-06-17 08:35:00 (UTC)
* 現象   : 2026-06-17 08:35:00 (UTC)を境に水準が 14.97から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.386, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→18→20→19→17→20→20→21→20
* 開始   : 2026-06-17 14:20:00 (UTC)
* 終了   : 2026-06-17 16:20:00 (UTC)
* 現象   : 2026-06-17 16:20:00 (UTC)を境に水準が 15.03から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→19→17→19→…→19→16→17→21
* 開始   : 2026-06-17 16:00:00 (UTC)
* 終了   : 2026-06-17 16:10:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→16→14→15→…→15→13→16→15
* 開始   : 2026-06-17 17:10:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260617-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→7→10→7→10→7→10→9
* 開始   : 2026-06-17 21:10:00 (UTC)
* 終了   : 2026-06-17 21:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→10→8→10→10→8→10
* 開始   : 2026-06-17 21:50:00 (UTC)
* 終了   : 2026-06-17 22:45:00 (UTC)
* 現象   : 2026-06-17 22:45:00 (UTC)を境に水準が 14.95から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.158, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 7→11→5→7→11→5→7
* 開始   : 2026-06-17 23:20:00 (UTC)
* 終了   : 2026-06-17 23:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host06-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→16→13→16→13→16→15
* 開始   : 2026-06-18 05:15:00 (UTC)
* 終了   : 2026-06-18 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→13→16→14→16→14→16→13→15
* 開始   : 2026-06-18 05:20:00 (UTC)
* 終了   : 2026-06-18 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→17→…→16→17→15→14
* 開始   : 2026-06-18 05:40:00 (UTC)
* 終了   : 2026-06-18 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→18→16→…→16→19→17→15
* 開始   : 2026-06-18 06:35:00 (UTC)
* 終了   : 2026-06-18 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→17→…→17→19→16→15
* 開始   : 2026-06-18 06:45:00 (UTC)
* 終了   : 2026-06-18 07:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.905σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→20→21→20→21→20→18
* 開始   : 2026-06-18 08:15:00 (UTC)
* 終了   : 2026-06-18 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260618-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→15→17→18→15→17→15
* 開始   : 2026-06-18 16:55:00 (UTC)
* 終了   : 2026-06-18 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→11→…→11→8→10→11
* 開始   : 2026-06-18 21:05:00 (UTC)
* 終了   : 2026-06-18 21:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→9→9→11→10→8→9→10→10
* 開始   : 2026-06-19 01:00:00 (UTC)
* 終了   : 2026-06-19 01:45:00 (UTC)
* 現象   : 2026-06-19 01:45:00 (UTC)を境に水準が 14.89から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→10→9→11→10→7→12→9→10
* 開始   : 2026-06-19 01:30:00 (UTC)
* 終了   : 2026-06-19 02:15:00 (UTC)
* 現象   : 2026-06-19 02:15:00 (UTC)を境に水準が 15.09から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.585, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→10→12→11→12→12→14
* 開始   : 2026-06-19 03:10:00 (UTC)
* 終了   : 2026-06-19 04:05:00 (UTC)
* 現象   : 2026-06-19 04:05:00 (UTC)を境に水準が 14.9から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.884, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→21→25→21→18→25→21→18→22
* 開始   : 2026-06-19 13:40:00 (UTC)
* 終了   : 2026-06-19 13:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→8→…→9→8→11→9
* 開始   : 2026-06-19 20:40:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 7→6→10→7→6→10→7
* 開始   : 2026-06-19 22:00:00 (UTC)
* 終了   : 2026-06-19 22:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→7→8→10→8→7→11→8→10
* 開始   : 2026-06-19 23:45:00 (UTC)
* 終了   : 2026-06-20 00:30:00 (UTC)
* 現象   : 2026-06-20 00:30:00 (UTC)を境に水準が 15.04から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→9
* 開始   : 2026-06-21 01:00:00 (UTC)
* 終了   : 2026-06-21 02:00:00 (UTC)
* 現象   : 2026-06-21 02:00:00 (UTC)を境に水準が 11.76から11.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.034, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→8→9→9→10→10→10→12
* 開始   : 2026-06-21 02:35:00 (UTC)
* 終了   : 2026-06-21 03:10:00 (UTC)
* 現象   : 2026-06-21 03:10:00 (UTC)を境に水準が 11.7から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→8→12→10→12→10→12→9→10
* 開始   : 2026-06-21 03:25:00 (UTC)
* 終了   : 2026-06-21 03:35:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260621-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→14→14→18→18→19
* 開始   : 2026-06-21 08:55:00 (UTC)
* 終了   : 2026-06-21 09:20:00 (UTC)
* 現象   : 2026-06-21 09:20:00 (UTC)を境に水準が 11.93から12.76へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→18→…→12→18→17→15
* 開始   : 2026-06-21 10:30:00 (UTC)
* 終了   : 2026-06-21 10:35:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→9→5→10→9→5→10
* 開始   : 2026-06-22 01:45:00 (UTC)
* 終了   : 2026-06-22 01:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→11→8→11→8→9
* 開始   : 2026-06-23 01:50:00 (UTC)
* 終了   : 2026-06-23 02:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260623-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→9→12→9→12→10
* 開始   : 2026-06-23 02:05:00 (UTC)
* 終了   : 2026-06-23 02:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→9→13→7→…→13→7→10→12
* 開始   : 2026-06-23 03:00:00 (UTC)
* 終了   : 2026-06-23 03:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260623-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→17→17→15→16→18→16→16→17
* 開始   : 2026-06-23 06:05:00 (UTC)
* 終了   : 2026-06-23 06:50:00 (UTC)
* 現象   : 2026-06-23 06:50:00 (UTC)を境に水準が 15.08から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→17→21→20→19→21→19→21→21
* 開始   : 2026-06-23 07:35:00 (UTC)
* 終了   : 2026-06-23 08:30:00 (UTC)
* 現象   : 2026-06-23 08:30:00 (UTC)を境に水準が 15.07から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.376, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→18→15→18→15→18→15→17→18
* 開始   : 2026-06-23 16:40:00 (UTC)
* 終了   : 2026-06-23 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→12→9→14→12→13
* 開始   : 2026-06-24 03:50:00 (UTC)
* 終了   : 2026-06-24 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.388倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260624-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→14→17→14→17→15
* 開始   : 2026-06-24 05:35:00 (UTC)
* 終了   : 2026-06-24 05:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 24→22→23→22→23→22→21→26
* 開始   : 2026-06-24 10:55:00 (UTC)
* 終了   : 2026-06-24 12:05:00 (UTC)
* 現象   : 2026-06-24 12:05:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→23→19→22→19→22→19→21→22
* 開始   : 2026-06-24 13:50:00 (UTC)
* 終了   : 2026-06-24 14:00:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260624-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→11→8→11→8→11→8→11
* 開始   : 2026-06-24 20:55:00 (UTC)
* 終了   : 2026-06-24 21:05:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→13→10→9→13
* 開始   : 2026-06-25 02:40:00 (UTC)
* 終了   : 2026-06-25 03:00:00 (UTC)
* 現象   : 2026-06-25 03:00:00 (UTC)を境に水準が 14.85から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.732, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→12→12→10→12→12
* 開始   : 2026-06-25 02:50:00 (UTC)
* 終了   : 2026-06-25 03:15:00 (UTC)
* 現象   : 2026-06-25 03:15:00 (UTC)を境に水準が 15.06から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.551, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→15→16
* 開始   : 2026-06-25 04:20:00 (UTC)
* 終了   : 2026-06-25 04:30:00 (UTC)
* 現象   : 2026-06-25 04:30:00 (UTC)を境に水準が 15.05から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→14→11→14→11→14→13→12
* 開始   : 2026-06-25 04:20:00 (UTC)
* 終了   : 2026-06-25 04:30:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260625-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 21→21→20→20→19→21→19→19→19
* 開始   : 2026-06-25 14:30:00 (UTC)
* 終了   : 2026-06-25 16:00:00 (UTC)
* 現象   : 2026-06-25 16:00:00 (UTC)を境に水準が 14.87から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→16→20→16→20→17
* 開始   : 2026-06-25 16:10:00 (UTC)
* 終了   : 2026-06-25 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→10→8→10→8→10→8→9
* 開始   : 2026-06-25 21:10:00 (UTC)
* 終了   : 2026-06-25 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260625-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→7→8→11→7→9
* 開始   : 2026-06-25 23:05:00 (UTC)
* 終了   : 2026-06-25 23:10:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→15→17→15→17→15→16
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 22→24→22→22→23→23→21→24→24
* 開始   : 2026-06-26 11:25:00 (UTC)
* 終了   : 2026-06-26 12:10:00 (UTC)
* 現象   : 2026-06-26 12:10:00 (UTC)を境に水準が 15.08から13.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 22→23→24→21→25→24→21→25→21
* 開始   : 2026-06-26 11:30:00 (UTC)
* 終了   : 2026-06-26 11:40:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→18→…→25→18→20→19
* 開始   : 2026-06-26 13:05:00 (UTC)
* 終了   : 2026-06-26 13:10:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.181倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260626-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→17→12→17→12→13→15
* 開始   : 2026-06-26 18:40:00 (UTC)
* 終了   : 2026-06-26 18:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→5→8→12→5→8→12→8→7
* 開始   : 2026-06-26 23:10:00 (UTC)
* 終了   : 2026-06-26 23:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260626-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→8→…→8→11→7→10
* 開始   : 2026-06-26 23:45:00 (UTC)
* 終了   : 2026-06-27 00:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.026σ 外れた (平常値=8.106)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→11→11→12→11→13→13
* 開始   : 2026-06-28 05:05:00 (UTC)
* 終了   : 2026-06-28 05:35:00 (UTC)
* 現象   : 2026-06-28 05:35:00 (UTC)を境に水準が 11.85から12.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→12→16→12→16→13
* 開始   : 2026-06-28 07:55:00 (UTC)
* 終了   : 2026-06-28 08:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分

![EVT-20260628-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→15→15→14
* 開始   : 2026-06-28 07:55:00 (UTC)
* 終了   : 2026-06-28 08:20:00 (UTC)
* 現象   : 2026-06-28 08:20:00 (UTC)を境に水準が 11.85から12.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→14→18→19→…→18→19→15→14
* 開始   : 2026-06-28 10:05:00 (UTC)
* 終了   : 2026-06-28 10:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→16
* 開始   : 2026-06-28 14:40:00 (UTC)
* 終了   : 2026-06-28 14:45:00 (UTC)
* 現象   : 2026-06-28 14:45:00 (UTC)を境に水準が 11.86から14.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.693, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→13→8→12→13→8→12→9
* 開始   : 2026-06-28 19:10:00 (UTC)
* 終了   : 2026-06-28 19:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→9→6→12→7→9→6→12→7
* 開始   : 2026-06-28 21:30:00 (UTC)
* 終了   : 2026-06-28 21:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→8→11→11→13→12→11
* 開始   : 2026-06-29 20:35:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 14.86から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→14→15→16→…→15→16→15→13
* 開始   : 2026-06-30 04:50:00 (UTC)
* 終了   : 2026-06-30 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→17→16→18→19→20→19→19→20
* 開始   : 2026-06-30 06:30:00 (UTC)
* 終了   : 2026-06-30 08:10:00 (UTC)
* 現象   : 2026-06-30 08:10:00 (UTC)を境に水準が 14.92から16.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→24→25→21→…→21→19→22→23
* 開始   : 2026-06-30 12:05:00 (UTC)
* 終了   : 2026-06-30 12:15:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 24→22→22→22→22→22→21→21→23
* 開始   : 2026-06-30 13:40:00 (UTC)
* 終了   : 2026-06-30 14:40:00 (UTC)
* 現象   : 2026-06-30 14:40:00 (UTC)を境に水準が 14.95から13.32へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.585, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→18→21→22→18→21→22
* 開始   : 2026-06-30 14:35:00 (UTC)
* 終了   : 2026-06-30 14:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.8308(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→14→18→14→18→17
* 開始   : 2026-06-30 16:50:00 (UTC)
* 終了   : 2026-06-30 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7671(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→11→13→15→12→12→13→12
* 開始   : 2026-06-30 18:25:00 (UTC)
* 終了   : 2026-06-30 20:10:00 (UTC)
* 現象   : 2026-06-30 20:10:00 (UTC)を境に水準が 14.94から9.982へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→12→12→12→10→13
* 開始   : 2026-06-30 19:30:00 (UTC)
* 終了   : 2026-06-30 20:00:00 (UTC)
* 現象   : 2026-06-30 20:00:00 (UTC)を境に水準が 14.91から9.417へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→10→6→5→8→10→6→5→8
* 開始   : 2026-06-30 23:20:00 (UTC)
* 終了   : 2026-06-30 23:25:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host06-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
