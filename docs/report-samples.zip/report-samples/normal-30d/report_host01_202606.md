# host01 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host01 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 348 (SEVERE: 32, FATAL: 132, WARN: 184, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 26 | 112 | 154 | 292 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-A5, ALG-B4 |
| eu | 4 | 18 | 30 | 52 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |
| mu | 1 | 0 | 0 | 1 | ALG-B1, ALG-B2, ALG-B5 |
| ou | 1 | 0 | 0 | 1 | ALG-A1, ALG-A2, ALG-B2, ALG-B5, ALG-C1 |
| fgc_delta | 0 | 1 | 0 | 1 | ALG-B2 |
| fgct_delta | 0 | 1 | 0 | 1 | ALG-B2 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260601-host01-001 )

* イベント種別 : ALG-B1 短期/長期移動平均のクロス継続, ALG-B2 Mann-Kendall 傾向検定, ALG-B5 線形回帰の傾き
* 脅威度 : SEVERE
* データ : jvm_gc / mu (Metaspace 使用量) / container=app01, host=host01
* 値     : 55.17→59.2→63.35→67.51→71.54→75.52→79.79→83.84→87.97
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 30.0日で 55.17から87.97へ増加した(平均 1.1/日)
* 説明   : ALG-B1: 短期移動平均が長期移動平均を 290 点連続で上回った (下限 288 点)
             ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=257161, p=0, Sen勾配=1.584/日)
             ALG-B5: 線形回帰の傾きが 1 日あたり 1.1、決定係数 R²=0.9983 (総増加 32.98)
* 原因候補 : クラスローダリーク(動的クラス生成) (確度: 中) — Metaspace の使用量が増え続けているため

![EVT-20260601-host01-001 mu の推移](charts/EVT-20260601-host01-001.svg)

# イベントID( EVT-20260601-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B2 Mann-Kendall 傾向検定, ALG-B5 線形回帰の傾き, ALG-C1 上限への張り付き
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app01, host=host01
* 値     : 41.45→47.7→54.37→61.01→67.39→76.82→83.33→89.93→96.48
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 30.0日で 41.45から96.48へ増加した(平均 1.734/日)
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.973 倍に達した (閾値 3)
             ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=244156, p=6.986e-314, Sen勾配=2.497/日)
             ALG-B5: 線形回帰の傾きが 1 日あたり 1.734、決定係数 R²=0.9865 (総増加 52.01)
             ALG-C1: 実際の上限 100 の 90% (90) 以上が 1.2 日続いた (期間中の平均 93.89, 最大 98.21, 335 点)
* 原因候補 : 負荷増に伴う正常な増加 (確度: 中) — 同時刻に負荷指標(active_connections または run)のアノマリーも出ているため

![EVT-20260601-host01-002 ou の推移](charts/EVT-20260601-host01-002.svg)

# イベントID( EVT-20260605-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 21→19→213→23→…→19→20→19→21
* 開始   : 2026-06-05 14:00:00 (UTC)
* 終了   : 2026-06-05 15:00:00 (UTC)
* 現象   : 2026-06-05 15:00:00 (UTC)を境に水準が 15.72から13.63へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 74.38σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 129.2 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=213)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=37.77, 限界=4.006)
             ALG-A5: 同じ曜日・時刻帯の平常値から 139.1σ 外れた (平常値=20.79)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=190.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-005 active_connections の推移](charts/EVT-20260605-host01-005.svg)

# イベントID( EVT-20260607-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→23→25→23→…→15→17→15→17
* 開始   : 2026-06-07 08:35:00 (UTC)
* 終了   : 2026-06-07 11:45:00 (UTC)
* 現象   : 2026-06-07 11:45:00 (UTC)を境に水準が 11.75から13.5へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 5.992σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 6.07 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.104, 限界=2.737)
             ALG-A5: 同じ曜日・時刻帯の平常値から 7.435σ 外れた (平常値=15.77)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-005 active_connections の推移](charts/EVT-20260607-host01-005.svg)

# イベントID( EVT-20260608-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→13→15→17→…→15→14→15→14
* 開始   : 2026-06-08 01:55:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.77から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.02σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.901, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-001 active_connections の推移](charts/EVT-20260608-host01-001.svg)

# イベントID( EVT-20260608-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.64→53.4→52.15→54.1→…→43.59→44.2→37.98→38.58
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 40.85から49.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.232, 限界=7.226)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=26.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-002 eu の推移](charts/EVT-20260608-host01-002.svg)

# イベントID( EVT-20260608-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→22→24→22→…→10→14→10→13
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 12.66から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.737)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-003 active_connections の推移](charts/EVT-20260608-host01-003.svg)

# イベントID( EVT-20260608-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→14→…→13→12→11→13
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 21:50:00 (UTC)
* 現象   : 2026-06-08 21:50:00 (UTC)を境に水準が 11.79から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.291σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.995, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-005 active_connections の推移](charts/EVT-20260608-host01-005.svg)

# イベントID( EVT-20260608-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→15→14→16→…→16→15→12→15
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 20:45:00 (UTC)
* 現象   : 2026-06-08 20:45:00 (UTC)を境に水準が 11.91から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.075, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-007 active_connections の推移](charts/EVT-20260608-host01-007.svg)

# イベントID( EVT-20260614-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→17→17→18→16→17
* 開始   : 2026-06-14 11:50:00 (UTC)
* 終了   : 2026-06-14 12:45:00 (UTC)
* 現象   : 2026-06-14 12:45:00 (UTC)を境に水準が 11.76から13.55へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-008 active_connections の推移](charts/EVT-20260614-host01-008.svg)

# イベントID( EVT-20260615-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→18→…→17→16→15→14
* 開始   : 2026-06-15 02:05:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.114σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.417, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-002 active_connections の推移](charts/EVT-20260615-host01-002.svg)

# イベントID( EVT-20260615-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.6→48.15→57.05→45.53→…→46.34→42.26→41.63→47.03
* 開始   : 2026-06-15 02:10:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 40.64から49.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.063σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.014 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.4, 限界=7.226)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=31.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-003 eu の推移](charts/EVT-20260615-host01-003.svg)

# イベントID( EVT-20260615-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→15→…→14→13→12→11
* 開始   : 2026-06-15 02:40:00 (UTC)
* 終了   : 2026-06-15 19:15:00 (UTC)
* 現象   : 2026-06-15 19:15:00 (UTC)を境に水準が 11.85から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.183, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.424, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-004 active_connections の推移](charts/EVT-20260615-host01-004.svg)

# イベントID( EVT-20260615-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→15→…→13→16→12→11
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 21:40:00 (UTC)
* 現象   : 2026-06-15 21:40:00 (UTC)を境に水準が 11.79から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.482σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.735, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-005 active_connections の推移](charts/EVT-20260615-host01-005.svg)

# イベントID( EVT-20260615-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→19→…→13→16→15→13
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.96から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.975, 限界=2.737)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-006 active_connections の推移](charts/EVT-20260615-host01-006.svg)

# イベントID( EVT-20260615-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→16→14→15→…→14→13→14→17
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.765, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-007 active_connections の推移](charts/EVT-20260615-host01-007.svg)

# イベントID( EVT-20260617-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→13→14→14→14→16
* 開始   : 2026-06-17 19:05:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 2026-06-17 19:40:00 (UTC)を境に水準が 15.03から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host01-008 active_connections の推移](charts/EVT-20260617-host01-008.svg)

# イベントID( EVT-20260620-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→8→8→9→7→9→9
* 開始   : 2026-06-20 22:35:00 (UTC)
* 終了   : 2026-06-20 23:55:00 (UTC)
* 現象   : 2026-06-20 23:55:00 (UTC)を境に水準が 11.82から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host01-010 active_connections の推移](charts/EVT-20260620-host01-010.svg)

# イベントID( EVT-20260621-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→14→13→15
* 開始   : 2026-06-21 06:55:00 (UTC)
* 終了   : 2026-06-21 07:20:00 (UTC)
* 現象   : 2026-06-21 07:20:00 (UTC)を境に水準が 11.99から12.37へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host01-002 active_connections の推移](charts/EVT-20260621-host01-002.svg)

# イベントID( EVT-20260622-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→14→…→14→15→14→15
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.9から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.894, 限界=2.737)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.629, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-001 active_connections の推移](charts/EVT-20260622-host01-001.svg)

# イベントID( EVT-20260622-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→15→…→13→17→14→13
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 21:10:00 (UTC)
* 現象   : 2026-06-22 21:10:00 (UTC)を境に水準が 11.79から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.494σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.721, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-002 active_connections の推移](charts/EVT-20260622-host01-002.svg)

# イベントID( EVT-20260622-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.62→49.2→56.4→53.7→…→45.05→47.21→39.53→41.75
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 41.35から50.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.787, 限界=7.226)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-003 eu の推移](charts/EVT-20260622-host01-003.svg)

# イベントID( EVT-20260622-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→15→…→15→14→13→15
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.87から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.597σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.047, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-005 active_connections の推移](charts/EVT-20260622-host01-005.svg)

# イベントID( EVT-20260622-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→17→…→12→14→12→13
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 2026-06-22 21:50:00 (UTC)を境に水準が 11.92から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.168, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-006 active_connections の推移](charts/EVT-20260622-host01-006.svg)

# イベントID( EVT-20260628-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→12→12→12→13→14
* 開始   : 2026-06-28 05:10:00 (UTC)
* 終了   : 2026-06-28 05:45:00 (UTC)
* 現象   : 2026-06-28 05:45:00 (UTC)を境に水準が 11.77から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.347, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-004 active_connections の推移](charts/EVT-20260628-host01-004.svg)

# イベントID( EVT-20260629-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→17→…→16→15→16→13
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.96から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.366σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.959, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-001 active_connections の推移](charts/EVT-20260629-host01-001.svg)

# イベントID( EVT-20260629-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→18→16→18→…→16→17→14→13
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 21:30:00 (UTC)
* 現象   : 2026-06-29 21:30:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.198, 限界=2.737)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.715, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-002 active_connections の推移](charts/EVT-20260629-host01-002.svg)

# イベントID( EVT-20260629-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→15→…→16→15→12→14
* 開始   : 2026-06-29 03:15:00 (UTC)
* 終了   : 2026-06-29 20:05:00 (UTC)
* 現象   : 2026-06-29 20:05:00 (UTC)を境に水準が 11.99から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.784, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-004 active_connections の推移](charts/EVT-20260629-host01-004.svg)

# イベントID( EVT-20260629-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→14→16→14→…→16→13→15→11
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.83から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.942, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-005 active_connections の推移](charts/EVT-20260629-host01-005.svg)

# イベントID( EVT-20260629-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→14→…→15→11→10→13
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 12から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.23σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.796, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-006 active_connections の推移](charts/EVT-20260629-host01-006.svg)

# イベントID( EVT-20260629-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.14→45.22→50.54→53.89→…→42.2→44.03→37.51→41.73
* 開始   : 2026-06-29 04:15:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 40.75から50.28へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.89, 限界=7.226)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=31.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-007 eu の推移](charts/EVT-20260629-host01-007.svg)

# イベントID( EVT-20260630-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 22→26→22→23→24→25
* 開始   : 2026-06-30 12:30:00 (UTC)
* 終了   : 2026-06-30 12:55:00 (UTC)
* 現象   : 2026-06-30 12:55:00 (UTC)を境に水準が 14.93から14.62へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host01-008 active_connections の推移](charts/EVT-20260630-host01-008.svg)

# イベントID( EVT-20260601-host01-003 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : FATAL
* データ : jvm_gc / fgc_delta (区間 Full GC 回数) / container=app01, host=host01
* 値     : 0→0.08333→0.08333→0.08333→0.1667→0.1667→0.3333→0.4167→0.5455
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 30.0日で 0から0.5455へ増加した(平均 0.02589/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=207040, p=2.102e-233, Sen勾配=0.02589/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host01-003 fgc_delta の推移](charts/EVT-20260601-host01-003.svg)

# イベントID( EVT-20260601-host01-004 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : FATAL
* データ : jvm_gc / fgct_delta (区間 Full GC 時間) / container=app01, host=host01
* 値     : 0.018→0.02583→0.04908→0.08792→0.1422→0.211→0.2961→0.3965→0.5125
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 30.0日で 0.018から0.5125へ増加した(平均 0.02378/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=258785, p=0, Sen勾配=0.02378/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host01-004 fgct_delta の推移](charts/EVT-20260601-host01-004.svg)

# イベントID( EVT-20260601-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→19→23→18→17
* 開始   : 2026-06-01 07:35:00 (UTC)
* 終了   : 2026-06-01 07:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.34倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-007 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-010 active_connections の推移](charts/EVT-20260601-host01-010.svg)

# イベントID( EVT-20260601-host01-011 )

* イベント種別 : ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 18→19→25→18→19
* 開始   : 2026-06-01 08:55:00 (UTC)
* 終了   : 2026-06-01 08:55:00 (UTC)
* 現象   : 平常時(18)に対し 1.389倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-011 active_connections の推移](charts/EVT-20260601-host01-011.svg)

# イベントID( EVT-20260601-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→18→15→20→18
* 開始   : 2026-06-01 16:10:00 (UTC)
* 終了   : 2026-06-01 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-012 active_connections の推移](charts/EVT-20260601-host01-012.svg)

# イベントID( EVT-20260601-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→16→11→15→15
* 開始   : 2026-06-01 18:00:00 (UTC)
* 終了   : 2026-06-01 18:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6839(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-013 active_connections の推移](charts/EVT-20260601-host01-013.svg)

# イベントID( EVT-20260602-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→10→10
* 開始   : 2026-06-02 02:20:00 (UTC)
* 終了   : 2026-06-02 02:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-001 active_connections の推移](charts/EVT-20260602-host01-001.svg)

# イベントID( EVT-20260602-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→10→11
* 開始   : 2026-06-02 03:25:00 (UTC)
* 終了   : 2026-06-02 03:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host01-002 active_connections の推移](charts/EVT-20260602-host01-002.svg)

# イベントID( EVT-20260602-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→14→20→18→19
* 開始   : 2026-06-02 06:55:00 (UTC)
* 終了   : 2026-06-02 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host01-006 active_connections の推移](charts/EVT-20260602-host01-006.svg)

# イベントID( EVT-20260602-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→18→21→16→15
* 開始   : 2026-06-02 07:10:00 (UTC)
* 終了   : 2026-06-02 07:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.636σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-007 active_connections の推移](charts/EVT-20260602-host01-007.svg)

# イベントID( EVT-20260602-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→19→25→21→21
* 開始   : 2026-06-02 09:45:00 (UTC)
* 終了   : 2026-06-02 09:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→19→20
* 開始   : 2026-06-02 14:35:00 (UTC)
* 終了   : 2026-06-02 14:35:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host01-011 active_connections の推移](charts/EVT-20260602-host01-011.svg)

# イベントID( EVT-20260603-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→17→16→…→17→16→15→14
* 開始   : 2026-06-03 05:05:00 (UTC)
* 終了   : 2026-06-03 05:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-004 active_connections の推移](charts/EVT-20260603-host01-004.svg)

# イベントID( EVT-20260603-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→16→18→17→…→17→19→17→16
* 開始   : 2026-06-03 06:20:00 (UTC)
* 終了   : 2026-06-03 06:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host01-005 active_connections の推移](charts/EVT-20260603-host01-005.svg)

# イベントID( EVT-20260603-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→18→22→19→17
* 開始   : 2026-06-03 08:05:00 (UTC)
* 終了   : 2026-06-03 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host01-006 active_connections の推移](charts/EVT-20260603-host01-006.svg)

# イベントID( EVT-20260603-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→18→23→20→22
* 開始   : 2026-06-03 09:05:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-007 active_connections の推移](charts/EVT-20260603-host01-007.svg)

# イベントID( EVT-20260604-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→13→13
* 開始   : 2026-06-04 05:00:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host01-002 active_connections の推移](charts/EVT-20260604-host01-002.svg)

# イベントID( EVT-20260604-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 23→23→18→22→21
* 開始   : 2026-06-04 13:35:00 (UTC)
* 終了   : 2026-06-04 13:35:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→12→16→12→16→12→14
* 開始   : 2026-06-04 18:05:00 (UTC)
* 終了   : 2026-06-04 18:15:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.279σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host01-007 active_connections の推移](charts/EVT-20260604-host01-007.svg)

# イベントID( EVT-20260604-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→15→12→15→14
* 開始   : 2026-06-04 18:05:00 (UTC)
* 終了   : 2026-06-04 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host01-008 active_connections の推移](charts/EVT-20260604-host01-008.svg)

# イベントID( EVT-20260604-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→9→10→11→10→9→10
* 開始   : 2026-06-04 22:25:00 (UTC)
* 終了   : 2026-06-04 23:15:00 (UTC)
* 現象   : 2026-06-04 23:15:00 (UTC)を境に水準が 14.96から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.251σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.846, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-010 active_connections の推移](charts/EVT-20260604-host01-010.svg)

# イベントID( EVT-20260605-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 31.39→32.89→43.37→34.97→37.8
* 開始   : 2026-06-05 02:20:00 (UTC)
* 終了   : 2026-06-05 02:20:00 (UTC)
* 現象   : 平常時(32.09)に対し 1.351倍(43.37)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→21→24→26→…→24→26→20→21
* 開始   : 2026-06-05 10:05:00 (UTC)
* 終了   : 2026-06-05 10:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host01-003 active_connections の推移](charts/EVT-20260605-host01-003.svg)

# イベントID( EVT-20260605-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→9→11
* 開始   : 2026-06-05 20:40:00 (UTC)
* 終了   : 2026-06-05 20:40:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.712σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host01-011 active_connections の推移](charts/EVT-20260605-host01-011.svg)

# イベントID( EVT-20260605-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→10→12
* 開始   : 2026-06-05 20:45:00 (UTC)
* 終了   : 2026-06-05 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-012 active_connections の推移](charts/EVT-20260605-host01-012.svg)

# イベントID( EVT-20260606-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 30.03→37.78→31.26→35.97→…→39.8→34.31→38.71→37.14
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-8.148, 限界=7.226)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260606-host01-001 eu の推移](charts/EVT-20260606-host01-001.svg)

# イベントID( EVT-20260606-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→11→…→14→9→13→12
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.061, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host01-002 active_connections の推移](charts/EVT-20260606-host01-002.svg)

# イベントID( EVT-20260606-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→10→…→11→12→11→13
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:05:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.561σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.851, 限界=2.737)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260606-host01-003 active_connections の推移](charts/EVT-20260606-host01-003.svg)

# イベントID( EVT-20260606-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→…→12→13→12→11
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host01-004 active_connections の推移](charts/EVT-20260606-host01-004.svg)

# イベントID( EVT-20260606-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→11→…→11→9→12→10
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.35, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host01-005 active_connections の推移](charts/EVT-20260606-host01-005.svg)

# イベントID( EVT-20260606-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→12→…→12→13→12→13
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.13, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260606-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host01-006 active_connections の推移](charts/EVT-20260606-host01-006.svg)

# イベントID( EVT-20260606-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→12→…→12→15→14→13
* 開始   : 2026-06-06 06:40:00 (UTC)
* 終了   : 2026-06-06 16:35:00 (UTC)
* 現象   : 9.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.157, 限界=4.006)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 9.9 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.9 時間
  - EVT-20260606-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260606-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間

![EVT-20260606-host01-007 active_connections の推移](charts/EVT-20260606-host01-007.svg)

# イベントID( EVT-20260607-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 7→11→4→9→8
* 開始   : 2026-06-07 01:05:00 (UTC)
* 終了   : 2026-06-07 01:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host01-002 active_connections の推移](charts/EVT-20260607-host01-002.svg)

# イベントID( EVT-20260607-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→12→15→11→12
* 開始   : 2026-06-07 05:15:00 (UTC)
* 終了   : 2026-06-07 05:15:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.363σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host01-003 active_connections の推移](charts/EVT-20260607-host01-003.svg)

# イベントID( EVT-20260607-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→15→19→13→16
* 開始   : 2026-06-07 10:30:00 (UTC)
* 終了   : 2026-06-07 10:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.21→28.29→46.44→29.65→…→29.65→24.15→30.55→32.83
* 開始   : 2026-06-07 21:20:00 (UTC)
* 終了   : 2026-06-07 21:30:00 (UTC)
* 現象   : 平常時(32.96)に対し 1.409倍(46.44)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.704σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host01-011 eu の推移](charts/EVT-20260607-host01-011.svg)

# イベントID( EVT-20260608-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→15→…→15→13→15→13
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 19:30:00 (UTC)
* 現象   : 2026-06-08 19:30:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.723, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-006 active_connections の推移](charts/EVT-20260608-host01-006.svg)

# イベントID( EVT-20260609-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.41→45.22→53.49→38.66→43.68
* 開始   : 2026-06-09 04:40:00 (UTC)
* 終了   : 2026-06-09 04:40:00 (UTC)
* 現象   : 平常時(41.81)に対し 1.279倍(53.49)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→13→16→15→…→15→16→15→12
* 開始   : 2026-06-09 05:00:00 (UTC)
* 終了   : 2026-06-09 05:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-002 active_connections の推移](charts/EVT-20260609-host01-002.svg)

# イベントID( EVT-20260609-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→18→…→18→21→16→17
* 開始   : 2026-06-09 07:05:00 (UTC)
* 終了   : 2026-06-09 07:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host01-006 active_connections の推移](charts/EVT-20260609-host01-006.svg)

# イベントID( EVT-20260609-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→21→…→21→20→18→17
* 開始   : 2026-06-09 07:25:00 (UTC)
* 終了   : 2026-06-09 07:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host01-007 active_connections の推移](charts/EVT-20260609-host01-007.svg)

# イベントID( EVT-20260609-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→17→17
* 開始   : 2026-06-09 17:25:00 (UTC)
* 終了   : 2026-06-09 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-009 active_connections の推移](charts/EVT-20260609-host01-009.svg)

# イベントID( EVT-20260610-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 41.5→37.97→49.69→40.36→44.3
* 開始   : 2026-06-10 04:15:00 (UTC)
* 終了   : 2026-06-10 04:15:00 (UTC)
* 現象   : 平常時(38.4)に対し 1.294倍(49.69)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260610-host01-002 eu の推移](charts/EVT-20260610-host01-002.svg)

# イベントID( EVT-20260610-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→15→18→13→15
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 05:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.421倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.759σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host01-004 active_connections の推移](charts/EVT-20260610-host01-004.svg)

# イベントID( EVT-20260610-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.56→47.77→59.74→46.83→48.72
* 開始   : 2026-06-10 06:15:00 (UTC)
* 終了   : 2026-06-10 06:15:00 (UTC)
* 現象   : 平常時(48.35)に対し 1.236倍(59.74)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-005 eu の推移](charts/EVT-20260610-host01-005.svg)

# イベントID( EVT-20260610-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→19→17→16→17→15→18→20
* 開始   : 2026-06-10 06:25:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 2026-06-10 07:00:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→14→16
* 開始   : 2026-06-10 07:00:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.524σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-007 active_connections の推移](charts/EVT-20260610-host01-007.svg)

# イベントID( EVT-20260610-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→20→24→19→19
* 開始   : 2026-06-10 08:35:00 (UTC)
* 終了   : 2026-06-10 08:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.28倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.7σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host01-009 active_connections の推移](charts/EVT-20260610-host01-009.svg)

# イベントID( EVT-20260610-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→15→14
* 開始   : 2026-06-10 17:40:00 (UTC)
* 終了   : 2026-06-10 17:40:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.117σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-015 active_connections の推移](charts/EVT-20260610-host01-015.svg)

# イベントID( EVT-20260610-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→12→10→14→15
* 開始   : 2026-06-10 19:00:00 (UTC)
* 終了   : 2026-06-10 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host01-017 active_connections の推移](charts/EVT-20260610-host01-017.svg)

# イベントID( EVT-20260610-host01-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→13→11→12→…→12→9→11→10
* 開始   : 2026-06-10 19:30:00 (UTC)
* 終了   : 2026-06-10 19:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260610-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260610-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-018 active_connections の推移](charts/EVT-20260610-host01-018.svg)

# イベントID( EVT-20260611-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→11→15→12→12
* 開始   : 2026-06-11 04:05:00 (UTC)
* 終了   : 2026-06-11 04:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-003 active_connections の推移](charts/EVT-20260611-host01-003.svg)

# イベントID( EVT-20260611-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→19→23→18→20→20→21→22→23
* 開始   : 2026-06-11 07:55:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 2026-06-11 08:40:00 (UTC)を境に水準が 15.04から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.959σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-005 active_connections の推移](charts/EVT-20260611-host01-005.svg)

# イベントID( EVT-20260611-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→22→24→21→…→21→25→21→22
* 開始   : 2026-06-11 10:05:00 (UTC)
* 終了   : 2026-06-11 10:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host01-006 active_connections の推移](charts/EVT-20260611-host01-006.svg)

# イベントID( EVT-20260611-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→16→11→14→17
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.694σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host01-010 active_connections の推移](charts/EVT-20260611-host01-010.svg)

# イベントID( EVT-20260612-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 26.87→31→23.4→32.42→…→32.42→40.23→30.06→28.3
* 開始   : 2026-06-12 01:05:00 (UTC)
* 終了   : 2026-06-12 01:15:00 (UTC)
* 現象   : 金曜1時台の平常値(31.78)に対し 23.4であった
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.153σ 外れた (平常値=31.78)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→13→19→16→15
* 開始   : 2026-06-12 06:45:00 (UTC)
* 終了   : 2026-06-12 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host01-005 active_connections の推移](charts/EVT-20260612-host01-005.svg)

# イベントID( EVT-20260612-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→14→20→14→15
* 開始   : 2026-06-12 18:05:00 (UTC)
* 終了   : 2026-06-12 18:05:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-013 active_connections の推移](charts/EVT-20260612-host01-013.svg)

# イベントID( EVT-20260612-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→14→11→15→13
* 開始   : 2026-06-12 18:15:00 (UTC)
* 終了   : 2026-06-12 18:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-014 active_connections の推移](charts/EVT-20260612-host01-014.svg)

# イベントID( EVT-20260612-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.51→41.96→34.83→41.24→41.76
* 開始   : 2026-06-12 19:30:00 (UTC)
* 終了   : 2026-06-12 19:30:00 (UTC)
* 現象   : 平常時(46.07)に対し 0.7561(34.83)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→10→14→9→12
* 開始   : 2026-06-13 04:05:00 (UTC)
* 終了   : 2026-06-13 04:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host01-001 active_connections の推移](charts/EVT-20260613-host01-001.svg)

# イベントID( EVT-20260613-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→11→…→13→11→12→13
* 開始   : 2026-06-13 04:45:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.905, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host01-002 active_connections の推移](charts/EVT-20260613-host01-002.svg)

# イベントID( EVT-20260613-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→13→12→13→…→10→12→11→12
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 19:40:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.138, 限界=2.737)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.2 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 14.6 時間

![EVT-20260613-host01-003 active_connections の推移](charts/EVT-20260613-host01-003.svg)

# イベントID( EVT-20260613-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.31→40.65→42.98→41.16→…→42.22→39.86→42.66→43.02
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.497, 限界=7.226)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260613-host01-004 eu の推移](charts/EVT-20260613-host01-004.svg)

# イベントID( EVT-20260613-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→10→…→12→10→12→10
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.001σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.982, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host01-005 active_connections の推移](charts/EVT-20260613-host01-005.svg)

# イベントID( EVT-20260613-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→11→…→13→12→13→11
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host01-006 active_connections の推移](charts/EVT-20260613-host01-006.svg)

# イベントID( EVT-20260613-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→11→14→12→…→12→13→15→11
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host01-007 active_connections の推移](charts/EVT-20260613-host01-007.svg)

# イベントID( EVT-20260614-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→7→13→10→8
* 開始   : 2026-06-14 02:05:00 (UTC)
* 終了   : 2026-06-14 02:05:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-002 active_connections の推移](charts/EVT-20260614-host01-002.svg)

# イベントID( EVT-20260614-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→11→16→12→11
* 開始   : 2026-06-14 06:20:00 (UTC)
* 終了   : 2026-06-14 06:20:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→13→18→13→14
* 開始   : 2026-06-14 08:05:00 (UTC)
* 終了   : 2026-06-14 08:05:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→7→4→9→10
* 開始   : 2026-06-14 22:30:00 (UTC)
* 終了   : 2026-06-14 22:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 17→19→20→19→…→17→16→15→16
* 開始   : 2026-06-15 01:40:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.232, 限界=4.006)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→13→…→13→16→14→13
* 開始   : 2026-06-16 05:00:00 (UTC)
* 終了   : 2026-06-16 05:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host01-002 active_connections の推移](charts/EVT-20260616-host01-002.svg)

# イベントID( EVT-20260616-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→16→20→15→15
* 開始   : 2026-06-16 06:55:00 (UTC)
* 終了   : 2026-06-16 06:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.363σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host01-003 active_connections の推移](charts/EVT-20260616-host01-003.svg)

# イベントID( EVT-20260616-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→16→19→16→17
* 開始   : 2026-06-16 06:55:00 (UTC)
* 終了   : 2026-06-16 07:25:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host01-004 active_connections の推移](charts/EVT-20260616-host01-004.svg)

# イベントID( EVT-20260617-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→18→17→14→18→17→14→15
* 開始   : 2026-06-17 06:00:00 (UTC)
* 終了   : 2026-06-17 06:05:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-002 active_connections の推移](charts/EVT-20260617-host01-002.svg)

# イベントID( EVT-20260617-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 69.13→70.95→56.3→68.18→68.22
* 開始   : 2026-06-17 14:05:00 (UTC)
* 終了   : 2026-06-17 14:05:00 (UTC)
* 現象   : 平常時(69.27)に対し 0.8127(56.3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host01-005 eu の推移](charts/EVT-20260617-host01-005.svg)

# イベントID( EVT-20260617-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→17→13→19→17
* 開始   : 2026-06-17 16:40:00 (UTC)
* 終了   : 2026-06-17 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7091(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.727σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host01-006 active_connections の推移](charts/EVT-20260617-host01-006.svg)

# イベントID( EVT-20260618-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→10→13→14→…→13→14→11→13
* 開始   : 2026-06-18 04:20:00 (UTC)
* 終了   : 2026-06-18 04:50:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260618-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-001 active_connections の推移](charts/EVT-20260618-host01-001.svg)

# イベントID( EVT-20260618-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→22→22
* 開始   : 2026-06-18 09:35:00 (UTC)
* 終了   : 2026-06-18 09:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.174σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-007 active_connections の推移](charts/EVT-20260618-host01-007.svg)

# イベントID( EVT-20260618-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→16→17
* 開始   : 2026-06-18 17:20:00 (UTC)
* 終了   : 2026-06-18 17:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-012 active_connections の推移](charts/EVT-20260618-host01-012.svg)

# イベントID( EVT-20260618-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→15→12→13→…→13→10→14→13
* 開始   : 2026-06-18 19:05:00 (UTC)
* 終了   : 2026-06-18 19:15:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host01-014 active_connections の推移](charts/EVT-20260618-host01-014.svg)

# イベントID( EVT-20260619-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.08→49.33→58.41→49.97→47.56
* 開始   : 2026-06-19 05:45:00 (UTC)
* 終了   : 2026-06-19 05:45:00 (UTC)
* 現象   : 平常時(45.12)に対し 1.295倍(58.41)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.652σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host01-004 eu の推移](charts/EVT-20260619-host01-004.svg)

# イベントID( EVT-20260619-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→11→5→9→9
* 開始   : 2026-06-19 22:00:00 (UTC)
* 終了   : 2026-06-19 22:00:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-010 active_connections の推移](charts/EVT-20260619-host01-010.svg)

# イベントID( EVT-20260620-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→13→…→11→10→11→9
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.762, 限界=2.737)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host01-003 active_connections の推移](charts/EVT-20260620-host01-003.svg)

# イベントID( EVT-20260620-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→11→9→…→12→11→10→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.733, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host01-004 active_connections の推移](charts/EVT-20260620-host01-004.svg)

# イベントID( EVT-20260620-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→13→12→11→…→13→16→17→13
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.711, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host01-005 active_connections の推移](charts/EVT-20260620-host01-005.svg)

# イベントID( EVT-20260620-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.7→42.42→42.59→38.29→…→42.25→32.47→40.84→38.7
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 20:05:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-8.613, 限界=7.226)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host01-006 eu の推移](charts/EVT-20260620-host01-006.svg)

# イベントID( EVT-20260620-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→13→…→13→12→13→12
* 開始   : 2026-06-20 06:15:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.172σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.687, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260620-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host01-007 active_connections の推移](charts/EVT-20260620-host01-007.svg)

# イベントID( EVT-20260620-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→11→…→13→11→13→12
* 開始   : 2026-06-20 06:50:00 (UTC)
* 終了   : 2026-06-20 18:15:00 (UTC)
* 現象   : 11.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.4 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間

![EVT-20260620-host01-008 active_connections の推移](charts/EVT-20260620-host01-008.svg)

# イベントID( EVT-20260621-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→14→17→14→15
* 開始   : 2026-06-21 07:25:00 (UTC)
* 終了   : 2026-06-21 07:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260621-host01-003 active_connections の推移](charts/EVT-20260621-host01-003.svg)

# イベントID( EVT-20260622-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→13→…→14→12→14→12
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.87から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.438, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.134, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-004 active_connections の推移](charts/EVT-20260622-host01-004.svg)

# イベントID( EVT-20260622-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→19→…→17→16→18→17
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.91から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.063, 限界=4.006)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 32.84→34.3→22.88→33.31→34.43
* 開始   : 2026-06-22 21:50:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 平常時(34.69)に対し 0.6596(22.88)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→21→23→20→21
* 開始   : 2026-06-23 08:45:00 (UTC)
* 終了   : 2026-06-23 08:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-002 active_connections の推移](charts/EVT-20260623-host01-002.svg)

# イベントID( EVT-20260623-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→18→12→18→16
* 開始   : 2026-06-23 17:25:00 (UTC)
* 終了   : 2026-06-23 17:25:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.348σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host01-005 active_connections の推移](charts/EVT-20260623-host01-005.svg)

# イベントID( EVT-20260623-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→12→12
* 開始   : 2026-06-23 19:15:00 (UTC)
* 終了   : 2026-06-23 19:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-007 active_connections の推移](charts/EVT-20260623-host01-007.svg)

# イベントID( EVT-20260623-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→12→7→12→10
* 開始   : 2026-06-23 20:35:00 (UTC)
* 終了   : 2026-06-23 20:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-008 active_connections の推移](charts/EVT-20260623-host01-008.svg)

# イベントID( EVT-20260624-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→8→11→7→…→7→12→7→9
* 開始   : 2026-06-24 01:10:00 (UTC)
* 終了   : 2026-06-24 01:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.349σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→19→24→21→20
* 開始   : 2026-06-24 09:40:00 (UTC)
* 終了   : 2026-06-24 09:55:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host01-008 active_connections の推移](charts/EVT-20260624-host01-008.svg)

# イベントID( EVT-20260624-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→20→16→18→20
* 開始   : 2026-06-24 15:20:00 (UTC)
* 終了   : 2026-06-24 15:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.06σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host01-010 active_connections の推移](charts/EVT-20260624-host01-010.svg)

# イベントID( EVT-20260624-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→20→13→17→17
* 開始   : 2026-06-24 16:30:00 (UTC)
* 終了   : 2026-06-24 16:30:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.6903(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host01-012 active_connections の推移](charts/EVT-20260624-host01-012.svg)

# イベントID( EVT-20260624-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.63→45.13→38.6→42.06→46.82
* 開始   : 2026-06-24 18:30:00 (UTC)
* 終了   : 2026-06-24 18:30:00 (UTC)
* 現象   : 平常時(50.4)に対し 0.7658(38.6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-014 eu の推移](charts/EVT-20260624-host01-014.svg)

# イベントID( EVT-20260624-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→12→12
* 開始   : 2026-06-24 19:35:00 (UTC)
* 終了   : 2026-06-24 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host01-015 active_connections の推移](charts/EVT-20260624-host01-015.svg)

# イベントID( EVT-20260624-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→11→8→11→10
* 開始   : 2026-06-24 19:55:00 (UTC)
* 終了   : 2026-06-24 19:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-016 active_connections の推移](charts/EVT-20260624-host01-016.svg)

# イベントID( EVT-20260624-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→10→5→7→9
* 開始   : 2026-06-24 21:50:00 (UTC)
* 終了   : 2026-06-24 21:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.4959(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host01-017 active_connections の推移](charts/EVT-20260624-host01-017.svg)

# イベントID( EVT-20260624-host01-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→11→13→8→9→8→9→10→10
* 開始   : 2026-06-24 22:55:00 (UTC)
* 終了   : 2026-06-25 01:00:00 (UTC)
* 現象   : 2026-06-25 01:00:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.165, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host01-018 active_connections の推移](charts/EVT-20260624-host01-018.svg)

# イベントID( EVT-20260625-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.58→36.32→49.74→41.35→36.62
* 開始   : 2026-06-25 04:05:00 (UTC)
* 終了   : 2026-06-25 04:05:00 (UTC)
* 現象   : 平常時(37.3)に対し 1.334倍(49.74)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-001 eu の推移](charts/EVT-20260625-host01-001.svg)

# イベントID( EVT-20260625-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→12→…→12→16→14→15
* 開始   : 2026-06-25 05:10:00 (UTC)
* 終了   : 2026-06-25 05:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.465σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host01-002 active_connections の推移](charts/EVT-20260625-host01-002.svg)

# イベントID( EVT-20260625-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→15→20→15→14
* 開始   : 2026-06-25 06:05:00 (UTC)
* 終了   : 2026-06-25 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.463倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host01-003 active_connections の推移](charts/EVT-20260625-host01-003.svg)

# イベントID( EVT-20260625-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→15→15
* 開始   : 2026-06-25 18:45:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host01-011 active_connections の推移](charts/EVT-20260625-host01-011.svg)

# イベントID( EVT-20260625-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→13→12
* 開始   : 2026-06-25 19:20:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-068 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-012 active_connections の推移](charts/EVT-20260625-host01-012.svg)

# イベントID( EVT-20260626-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→18→21→19→20
* 開始   : 2026-06-26 07:25:00 (UTC)
* 終了   : 2026-06-26 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-003 active_connections の推移](charts/EVT-20260626-host01-003.svg)

# イベントID( EVT-20260626-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→21→24→20→21
* 開始   : 2026-06-26 09:15:00 (UTC)
* 終了   : 2026-06-26 09:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host01-004 active_connections の推移](charts/EVT-20260626-host01-004.svg)

# イベントID( EVT-20260626-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→20→24→21→…→21→23→22→23
* 開始   : 2026-06-26 09:55:00 (UTC)
* 終了   : 2026-06-26 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-005 active_connections の推移](charts/EVT-20260626-host01-005.svg)

# イベントID( EVT-20260626-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→24→19→20→20→20→20→21→23
* 開始   : 2026-06-26 14:15:00 (UTC)
* 終了   : 2026-06-26 16:45:00 (UTC)
* 現象   : 2026-06-26 16:45:00 (UTC)を境に水準が 14.99から12.47へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.561σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host01-006 active_connections の推移](charts/EVT-20260626-host01-006.svg)

# イベントID( EVT-20260626-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 40.54→40.35→27.12→34.26→32.14
* 開始   : 2026-06-26 21:05:00 (UTC)
* 終了   : 2026-06-26 21:05:00 (UTC)
* 現象   : 平常時(38.64)に対し 0.7018(27.12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-010 eu の推移](charts/EVT-20260626-host01-010.svg)

# イベントID( EVT-20260627-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→9→13→9→9
* 開始   : 2026-06-27 03:25:00 (UTC)
* 終了   : 2026-06-27 03:25:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260627-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host01-001 active_connections の推移](charts/EVT-20260627-host01-001.svg)

# イベントID( EVT-20260627-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→8→13→11→11
* 開始   : 2026-06-27 03:50:00 (UTC)
* 終了   : 2026-06-27 03:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.84→41.26→37.06→40.9→…→39.11→38.58→43.44→36.79
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.924, 限界=7.226)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260627-host01-003 eu の推移](charts/EVT-20260627-host01-003.svg)

# イベントID( EVT-20260627-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→10→…→12→10→12→10
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.941, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host01-004 active_connections の推移](charts/EVT-20260627-host01-004.svg)

# イベントID( EVT-20260627-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→10→…→12→10→12→14
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.003, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260627-host01-005 active_connections の推移](charts/EVT-20260627-host01-005.svg)

# イベントID( EVT-20260627-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→12→…→11→12→11→10
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 20:20:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.849, 限界=2.737)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host01-006 active_connections の推移](charts/EVT-20260627-host01-006.svg)

# イベントID( EVT-20260627-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→13→10→13→…→12→11→14→13
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host01-007 active_connections の推移](charts/EVT-20260627-host01-007.svg)

# イベントID( EVT-20260627-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→14→…→13→10→12→13
* 開始   : 2026-06-27 06:15:00 (UTC)
* 終了   : 2026-06-27 17:50:00 (UTC)
* 現象   : 11.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.885, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 11.6 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間

![EVT-20260627-host01-008 active_connections の推移](charts/EVT-20260627-host01-008.svg)

# イベントID( EVT-20260628-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→9→5→9→10
* 開始   : 2026-06-28 21:50:00 (UTC)
* 終了   : 2026-06-28 21:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→9→14→12→10
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 03:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-003 active_connections の推移](charts/EVT-20260630-host01-003.svg)

# イベントID( EVT-20260630-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 36.22→37.47→46.23→37.44→38.16
* 開始   : 2026-06-30 03:40:00 (UTC)
* 終了   : 2026-06-30 03:40:00 (UTC)
* 現象   : 平常時(34.95)に対し 1.323倍(46.23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host01-004 eu の推移](charts/EVT-20260630-host01-004.svg)

# イベントID( EVT-20260630-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→18→23→17→20
* 開始   : 2026-06-30 09:05:00 (UTC)
* 終了   : 2026-06-30 09:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-007 active_connections の推移](charts/EVT-20260630-host01-007.svg)

# イベントID( EVT-20260630-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→19→…→18→19→21→20
* 開始   : 2026-06-30 13:40:00 (UTC)
* 終了   : 2026-06-30 13:45:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-010 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260630-host01-009 active_connections の推移](charts/EVT-20260630-host01-009.svg)

# イベントID( EVT-20260630-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→17→13→14→…→13→14→15→14
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 17:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.348σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host01-011 active_connections の推移](charts/EVT-20260630-host01-011.svg)

# イベントID( EVT-20260630-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→10→6→8→10
* 開始   : 2026-06-30 21:30:00 (UTC)
* 終了   : 2026-06-30 21:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→10→14→10→14→10
* 開始   : 2026-06-01 03:15:00 (UTC)
* 終了   : 2026-06-01 03:20:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.424倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.826σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→13→17→16→13→17→14
* 開始   : 2026-06-01 05:30:00 (UTC)
* 終了   : 2026-06-01 05:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 60.27→55.4→62.71→64.38→…→62.71→64.38→55.45→59.55
* 開始   : 2026-06-01 07:30:00 (UTC)
* 終了   : 2026-06-01 07:35:00 (UTC)
* 現象   : 平常時(54.76)に対し 1.145倍(62.71)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→20→19→17→20→19→18
* 開始   : 2026-06-01 07:35:00 (UTC)
* 終了   : 2026-06-01 07:40:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.539σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host01-007 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→19→20→19→20→18→19
* 開始   : 2026-06-01 07:35:00 (UTC)
* 終了   : 2026-06-01 07:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.584σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host01-007 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260601-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→13→…→13→9→12→11
* 開始   : 2026-06-01 19:40:00 (UTC)
* 終了   : 2026-06-01 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→13→7→8→7→8→7→8→10
* 開始   : 2026-06-01 21:20:00 (UTC)
* 終了   : 2026-06-01 21:30:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.6462(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→9→6→8→9→6→8
* 開始   : 2026-06-01 22:45:00 (UTC)
* 終了   : 2026-06-01 22:50:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→7→5→7→5→7
* 開始   : 2026-06-01 23:45:00 (UTC)
* 終了   : 2026-06-01 23:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→12→…→12→15→13→14
* 開始   : 2026-06-02 04:30:00 (UTC)
* 終了   : 2026-06-02 04:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260602-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→13→15→14→12→16
* 開始   : 2026-06-02 05:05:00 (UTC)
* 終了   : 2026-06-02 05:30:00 (UTC)
* 現象   : 2026-06-02 05:30:00 (UTC)を境に水準が 14.94から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→17→16→17→15
* 開始   : 2026-06-02 05:25:00 (UTC)
* 終了   : 2026-06-02 05:35:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.114σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 23→21→23→22→23
* 開始   : 2026-06-02 10:05:00 (UTC)
* 終了   : 2026-06-02 10:25:00 (UTC)
* 現象   : 2026-06-02 10:25:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→21→19→23→…→23→19→18→21
* 開始   : 2026-06-02 13:35:00 (UTC)
* 終了   : 2026-06-02 13:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260602-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 70.21→63.71→69.5→62.31→63.85
* 開始   : 2026-06-02 15:30:00 (UTC)
* 終了   : 2026-06-02 16:30:00 (UTC)
* 現象   : 2026-06-02 16:30:00 (UTC)を境に水準が 50.12から50.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→17→18→16→17→18→16→18→17
* 開始   : 2026-06-02 15:50:00 (UTC)
* 終了   : 2026-06-02 16:00:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 18→17→17→18→16→15→16→13→16
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 18:30:00 (UTC)
* 現象   : 2026-06-02 18:30:00 (UTC)を境に水準が 14.86から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.224, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→13→11→10→13→11→10→13→14
* 開始   : 2026-06-02 19:10:00 (UTC)
* 終了   : 2026-06-02 19:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→14
* 開始   : 2026-06-02 19:20:00 (UTC)
* 終了   : 2026-06-02 19:35:00 (UTC)
* 現象   : 2026-06-02 19:35:00 (UTC)を境に水準が 15.03から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→11→12→9→11→10
* 開始   : 2026-06-02 19:50:00 (UTC)
* 終了   : 2026-06-02 19:55:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.54σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→8→…→8→6→9→8
* 開始   : 2026-06-02 21:55:00 (UTC)
* 終了   : 2026-06-02 22:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host01-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-019 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→9→9→10→9
* 開始   : 2026-06-02 23:45:00 (UTC)
* 終了   : 2026-06-03 00:05:00 (UTC)
* 現象   : 2026-06-03 00:05:00 (UTC)を境に水準が 14.99から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.163, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 33.78→33.98→37.05→29.45→…→29.45→36.69→36.63→28.53
* 開始   : 2026-06-03 01:10:00 (UTC)
* 終了   : 2026-06-03 01:20:00 (UTC)
* 現象   : 平常時(28.38)に対し 1.306倍(37.05)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260603-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→11→12→11→12→10
* 開始   : 2026-06-03 03:00:00 (UTC)
* 終了   : 2026-06-03 03:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→14→12→11→14→12→13
* 開始   : 2026-06-03 04:15:00 (UTC)
* 終了   : 2026-06-03 04:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.291σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→20→22→21→23→22→21→23→21
* 開始   : 2026-06-03 09:05:00 (UTC)
* 終了   : 2026-06-03 09:15:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 23→25→23→20→25
* 開始   : 2026-06-03 11:35:00 (UTC)
* 終了   : 2026-06-03 11:55:00 (UTC)
* 現象   : 2026-06-03 11:55:00 (UTC)を境に水準が 15.03から15.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.543, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 24→23→22→25→21→20→21→22→22
* 開始   : 2026-06-03 12:40:00 (UTC)
* 終了   : 2026-06-03 13:50:00 (UTC)
* 現象   : 2026-06-03 13:50:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→19→16→19→16→19
* 開始   : 2026-06-03 15:50:00 (UTC)
* 終了   : 2026-06-03 16:00:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 59.01→55.68→51.62→50.51→…→51.62→50.51→55.72→57.07
* 開始   : 2026-06-03 16:55:00 (UTC)
* 終了   : 2026-06-03 17:00:00 (UTC)
* 現象   : 平常時(59.21)に対し 0.8718(51.62)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→10→…→10→8→12→11
* 開始   : 2026-06-03 20:30:00 (UTC)
* 終了   : 2026-06-03 20:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 32.56→32.92→25.69→24.72→…→25.69→24.72→33.54→34.53
* 開始   : 2026-06-03 22:00:00 (UTC)
* 終了   : 2026-06-03 22:05:00 (UTC)
* 現象   : 平常時(34.12)に対し 0.7529(25.69)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→11→15→13→12→14→13
* 開始   : 2026-06-04 03:30:00 (UTC)
* 終了   : 2026-06-04 04:10:00 (UTC)
* 現象   : 2026-06-04 04:10:00 (UTC)を境に水準が 15.1から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→20→18→20→20→17→20→21→20
* 開始   : 2026-06-04 07:15:00 (UTC)
* 終了   : 2026-06-04 08:45:00 (UTC)
* 現象   : 2026-06-04 08:45:00 (UTC)を境に水準が 14.92から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 74.52→75.01→74.97→73.12→71.32→71.12→72.18→69.79→73.16
* 開始   : 2026-06-04 12:10:00 (UTC)
* 終了   : 2026-06-04 13:30:00 (UTC)
* 現象   : 2026-06-04 13:30:00 (UTC)を境に水準が 50.03から49.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 24→23→24→22→23→22→22→25
* 開始   : 2026-06-04 12:15:00 (UTC)
* 終了   : 2026-06-04 12:50:00 (UTC)
* 現象   : 2026-06-04 12:50:00 (UTC)を境に水準が 15.2から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.79→42.86→39.95→45.46→…→35.77→36.17→44.19→42.63
* 開始   : 2026-06-04 19:05:00 (UTC)
* 終了   : 2026-06-04 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260604-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→13→12→15→16→17
* 開始   : 2026-06-05 04:40:00 (UTC)
* 終了   : 2026-06-05 05:05:00 (UTC)
* 現象   : 2026-06-05 05:05:00 (UTC)を境に水準が 14.92から15.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 66.44→67.9→77.72→76.74→…→77.72→76.74→70.22→67.78
* 開始   : 2026-06-05 12:15:00 (UTC)
* 終了   : 2026-06-05 12:20:00 (UTC)
* 現象   : 平常時(67.97)に対し 1.144倍(77.72)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→16→19→16→17
* 開始   : 2026-06-05 15:45:00 (UTC)
* 終了   : 2026-06-05 15:55:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.85→42.31→38.33→38.2→…→38.33→38.2→46.53→42.17
* 開始   : 2026-06-05 19:15:00 (UTC)
* 終了   : 2026-06-05 19:20:00 (UTC)
* 現象   : 平常時(46.66)に対し 0.8214(38.33)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→14→…→14→9→13→14
* 開始   : 2026-06-05 19:20:00 (UTC)
* 終了   : 2026-06-05 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-007 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-083 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-082 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-084 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→12→13→13→14
* 開始   : 2026-06-05 19:25:00 (UTC)
* 終了   : 2026-06-05 19:45:00 (UTC)
* 現象   : 2026-06-05 19:45:00 (UTC)を境に水準が 15.71から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→12→11→10→9→12→11
* 開始   : 2026-06-05 19:50:00 (UTC)
* 終了   : 2026-06-05 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→9→…→9→12→10→9
* 開始   : 2026-06-06 22:45:00 (UTC)
* 終了   : 2026-06-06 22:55:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→11→10→10→10
* 開始   : 2026-06-07 00:50:00 (UTC)
* 終了   : 2026-06-07 01:55:00 (UTC)
* 現象   : 2026-06-07 01:55:00 (UTC)を境に水準が 11.68から11.79へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.193σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→16→…→15→16→12→14
* 開始   : 2026-06-07 06:50:00 (UTC)
* 終了   : 2026-06-07 06:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.15→45.57→57.87→48.04→…→48.04→59.61→48.15→49.67
* 開始   : 2026-06-07 09:15:00 (UTC)
* 終了   : 2026-06-07 09:25:00 (UTC)
* 現象   : 平常時(47.79)に対し 1.211倍(57.87)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.769σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→17→17→16→17→15→15→15→15
* 開始   : 2026-06-07 14:35:00 (UTC)
* 終了   : 2026-06-07 15:30:00 (UTC)
* 現象   : 2026-06-07 15:30:00 (UTC)を境に水準が 11.84から14.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→15→…→15→18→14→12
* 開始   : 2026-06-07 15:15:00 (UTC)
* 終了   : 2026-06-07 15:25:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260607-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→11→17→12→14→11→17→12→11
* 開始   : 2026-06-07 16:25:00 (UTC)
* 終了   : 2026-06-07 16:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260607-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→10→8→10→9
* 開始   : 2026-06-07 22:20:00 (UTC)
* 終了   : 2026-06-07 22:40:00 (UTC)
* 現象   : 2026-06-07 22:40:00 (UTC)を境に水準が 11.79から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 17→18→20→17→…→16→18→16→18
* 開始   : 2026-06-08 02:15:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.547, 限界=4.006)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→9→10→9→9→9→8→10→12
* 開始   : 2026-06-08 22:50:00 (UTC)
* 終了   : 2026-06-09 00:00:00 (UTC)
* 現象   : 2026-06-09 00:00:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.956, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 8→9→5→11→…→5→11→8→7
* 開始   : 2026-06-08 23:10:00 (UTC)
* 終了   : 2026-06-08 23:15:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260608-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→16→15→16→14
* 開始   : 2026-06-09 05:30:00 (UTC)
* 終了   : 2026-06-09 05:40:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 51.8→54.4→57.5→49.64→…→49.64→59.8→55.36→49.37
* 開始   : 2026-06-09 06:20:00 (UTC)
* 終了   : 2026-06-09 06:30:00 (UTC)
* 現象   : 平常時(48.28)に対し 1.191倍(57.5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.534σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→12→17→19→…→17→19→16→17
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→22→23→21→19→22→23→21
* 開始   : 2026-06-09 08:55:00 (UTC)
* 終了   : 2026-06-09 09:00:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→16→16→16→17→15
* 開始   : 2026-06-09 17:35:00 (UTC)
* 終了   : 2026-06-09 18:10:00 (UTC)
* 現象   : 2026-06-09 18:10:00 (UTC)を境に水準が 14.94から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→11→13→12→11→13→12
* 開始   : 2026-06-09 18:40:00 (UTC)
* 終了   : 2026-06-09 18:45:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.194σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.5→45.79→39.92→41.4→…→41.4→38.6→41.48→40.82
* 開始   : 2026-06-09 18:55:00 (UTC)
* 終了   : 2026-06-09 19:05:00 (UTC)
* 現象   : 平常時(47.93)に対し 0.8328(39.92)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→13→10→13→…→13→9→10→13
* 開始   : 2026-06-09 19:55:00 (UTC)
* 終了   : 2026-06-09 20:05:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→9→11→13→9→11
* 開始   : 2026-06-09 20:15:00 (UTC)
* 終了   : 2026-06-09 20:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→10→7→9→…→9→13→10→8
* 開始   : 2026-06-09 21:35:00 (UTC)
* 終了   : 2026-06-09 21:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→9→10→10→10→11→12→11
* 開始   : 2026-06-10 02:05:00 (UTC)
* 終了   : 2026-06-10 02:40:00 (UTC)
* 現象   : 2026-06-10 02:40:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→12→16
* 開始   : 2026-06-10 04:35:00 (UTC)
* 終了   : 2026-06-10 04:55:00 (UTC)
* 現象   : 2026-06-10 04:55:00 (UTC)を境に水準が 15.09から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 60.97→62.08→66.5→60.48→…→60.48→67.56→66.93→64.21
* 開始   : 2026-06-10 08:05:00 (UTC)
* 終了   : 2026-06-10 08:15:00 (UTC)
* 現象   : 平常時(57.25)に対し 1.162倍(66.5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.542σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 22→21→21→21→22→23→22
* 開始   : 2026-06-10 09:20:00 (UTC)
* 終了   : 2026-06-10 09:50:00 (UTC)
* 現象   : 2026-06-10 09:50:00 (UTC)を境に水準が 14.97から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 23→22→19→21→22→19→21→22
* 開始   : 2026-06-10 12:40:00 (UTC)
* 終了   : 2026-06-10 12:45:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 22→18→21→22→18→21
* 開始   : 2026-06-10 14:30:00 (UTC)
* 終了   : 2026-06-10 14:35:00 (UTC)
* 現象   : 平常時(22)に対し 0.8182(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.771σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260610-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→19→17→22→19→17→22→19
* 開始   : 2026-06-10 15:35:00 (UTC)
* 終了   : 2026-06-10 15:40:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→17→13→17→13→16→14
* 開始   : 2026-06-10 16:40:00 (UTC)
* 終了   : 2026-06-10 17:50:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 40 分
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260610-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.06→44.65→43.13→46.43→…→46.43→40.74→45.33→45.57
* 開始   : 2026-06-10 18:35:00 (UTC)
* 終了   : 2026-06-10 18:45:00 (UTC)
* 現象   : 平常時(51.08)に対し 0.8444(43.13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 28.66→33.61→38.28→32.99→38.41
* 開始   : 2026-06-11 00:00:00 (UTC)
* 終了   : 2026-06-11 00:20:00 (UTC)
* 現象   : 2026-06-11 00:20:00 (UTC)を境に水準が 49.89から49.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→12→11→14→12→14
* 開始   : 2026-06-11 04:05:00 (UTC)
* 終了   : 2026-06-11 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.408σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.91→43.67→49.41→43.91→…→43.91→50.97→45.95→51.62
* 開始   : 2026-06-11 05:20:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(42.05)に対し 1.175倍(49.41)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→21→21→21→22→22→22→22
* 開始   : 2026-06-11 12:50:00 (UTC)
* 終了   : 2026-06-11 14:40:00 (UTC)
* 現象   : 2026-06-11 14:40:00 (UTC)を境に水準が 14.83から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.526σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→21→17→16→…→17→16→17→18
* 開始   : 2026-06-11 15:40:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→18→17→18→…→18→16→19→20
* 開始   : 2026-06-11 15:55:00 (UTC)
* 終了   : 2026-06-11 16:05:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260611-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.14→39.86→33.02→38.95→…→38.95→32.86→38.61→37.59
* 開始   : 2026-06-11 20:25:00 (UTC)
* 終了   : 2026-06-11 20:35:00 (UTC)
* 現象   : 平常時(41.34)に対し 0.7986(33.02)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.287σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→16→15→12→16→15→12
* 開始   : 2026-06-12 05:00:00 (UTC)
* 終了   : 2026-06-12 05:05:00 (UTC)
* 現象   : 平常時(12)に対し 1.333倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.713σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.71→43.91→54.68→57.59→…→54.68→57.59→51.54→53.49
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 06:00:00 (UTC)
* 現象   : 平常時(46.43)に対し 1.178倍(54.68)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→16→18→17→18→17→18→17→15
* 開始   : 2026-06-12 06:25:00 (UTC)
* 終了   : 2026-06-12 06:35:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.584σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 20→19→20→20→20→20→20→20→23
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 09:00:00 (UTC)
* 現象   : 2026-06-12 09:00:00 (UTC)を境に水準が 14.98から14.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→19→21→18→19→21→18
* 開始   : 2026-06-12 08:20:00 (UTC)
* 終了   : 2026-06-12 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→22→24→25→…→24→25→21→22
* 開始   : 2026-06-12 10:25:00 (UTC)
* 終了   : 2026-06-12 10:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 22→22→20→22→22→23→24→24→24
* 開始   : 2026-06-12 10:30:00 (UTC)
* 終了   : 2026-06-12 11:45:00 (UTC)
* 現象   : 2026-06-12 11:45:00 (UTC)を境に水準が 14.91から13.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→25→25→23
* 開始   : 2026-06-12 11:20:00 (UTC)
* 終了   : 2026-06-12 11:35:00 (UTC)
* 現象   : 2026-06-12 11:35:00 (UTC)を境に水準が 15.16から13.53へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→21→17→19→21→17→19
* 開始   : 2026-06-12 15:15:00 (UTC)
* 終了   : 2026-06-12 15:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→16→14→15→13→14→15→13→15
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.702σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→12→…→12→9→12→11
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→6→8→10→6→8→10
* 開始   : 2026-06-12 22:20:00 (UTC)
* 終了   : 2026-06-12 22:25:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.544σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-084 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→12→13→15→…→15→16→13→15
* 開始   : 2026-06-13 07:10:00 (UTC)
* 終了   : 2026-06-13 17:35:00 (UTC)
* 現象   : 10.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.208, 限界=4.006)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 10.4 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10.4 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間
  - EVT-20260613-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.4 時間

![EVT-20260613-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→8→…→9→10→9→10
* 開始   : 2026-06-13 19:40:00 (UTC)
* 終了   : 2026-06-13 20:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.701, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 20 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分

![EVT-20260613-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→8→11→8→11→8→9
* 開始   : 2026-06-14 00:55:00 (UTC)
* 終了   : 2026-06-14 01:05:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→11→12→11→11→13→12
* 開始   : 2026-06-14 04:55:00 (UTC)
* 終了   : 2026-06-14 05:35:00 (UTC)
* 現象   : 2026-06-14 05:35:00 (UTC)を境に水準が 11.73から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→15→10→14→…→14→16→12→13
* 開始   : 2026-06-14 07:40:00 (UTC)
* 終了   : 2026-06-14 07:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→17→14→17→14→17→12→16
* 開始   : 2026-06-14 09:35:00 (UTC)
* 終了   : 2026-06-14 09:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→18→16→12→18→16→12→15→16
* 開始   : 2026-06-14 14:10:00 (UTC)
* 終了   : 2026-06-14 14:20:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260614-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→12→14→11→11→12→13→13
* 開始   : 2026-06-14 18:45:00 (UTC)
* 終了   : 2026-06-14 19:20:00 (UTC)
* 現象   : 2026-06-14 19:20:00 (UTC)を境に水準が 11.85から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→12→7→11→…→11→14→12→10
* 開始   : 2026-06-16 03:20:00 (UTC)
* 終了   : 2026-06-16 03:30:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260616-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→21→19→22→…→22→15→19→20
* 開始   : 2026-06-16 08:20:00 (UTC)
* 終了   : 2026-06-16 09:45:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→19→21→19→21
* 開始   : 2026-06-16 08:25:00 (UTC)
* 終了   : 2026-06-16 08:35:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→22→25→18→…→25→18→21→19
* 開始   : 2026-06-16 10:00:00 (UTC)
* 終了   : 2026-06-16 10:05:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.205倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.883σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→18→13→14→…→14→12→17→15
* 開始   : 2026-06-16 18:00:00 (UTC)
* 終了   : 2026-06-16 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.349σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.7→49→43.6→46.42→…→46.42→41.56→51.01→49.46
* 開始   : 2026-06-16 18:25:00 (UTC)
* 終了   : 2026-06-16 18:35:00 (UTC)
* 現象   : 平常時(52.53)に対し 0.8301(43.6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→7→10→9→9→8→10
* 開始   : 2026-06-16 21:55:00 (UTC)
* 終了   : 2026-06-16 23:10:00 (UTC)
* 現象   : 2026-06-16 23:10:00 (UTC)を境に水準が 15.03から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→12→9→6→12→9→6→8→7
* 開始   : 2026-06-16 22:35:00 (UTC)
* 終了   : 2026-06-16 22:45:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→13→17→14→17→14→17→15
* 開始   : 2026-06-17 05:45:00 (UTC)
* 終了   : 2026-06-17 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→16→16→17→16→18→17
* 開始   : 2026-06-17 06:20:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 2026-06-17 06:50:00 (UTC)を境に水準が 15.11から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.846, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 55.23→61.05→65.31→64.12→…→64.12→66.55→63.35→60.81
* 開始   : 2026-06-17 08:10:00 (UTC)
* 終了   : 2026-06-17 08:20:00 (UTC)
* 現象   : 平常時(57.49)に対し 1.136倍(65.31)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.71→51.71→41.14→39.87→…→41.14→39.87→49.47→46.95
* 開始   : 2026-06-17 18:35:00 (UTC)
* 終了   : 2026-06-17 18:40:00 (UTC)
* 現象   : 平常時(49.72)に対し 0.8274(41.14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.357σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→8→6→8→6→9
* 開始   : 2026-06-17 22:50:00 (UTC)
* 終了   : 2026-06-17 23:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→17→13→18→17→13→18→15
* 開始   : 2026-06-18 06:00:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.408σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→16→19→18→16→19→17
* 開始   : 2026-06-18 06:25:00 (UTC)
* 終了   : 2026-06-18 06:35:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 55.59→52.2→61.34→55.68→…→55.68→64.1→62.01→57.73
* 開始   : 2026-06-18 07:25:00 (UTC)
* 終了   : 2026-06-18 07:35:00 (UTC)
* 現象   : 平常時(52.36)に対し 1.171倍(61.34)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.467σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→22→19→20→22→19→21
* 開始   : 2026-06-18 09:00:00 (UTC)
* 終了   : 2026-06-18 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→19→23→21→19→23→21→20
* 開始   : 2026-06-18 09:10:00 (UTC)
* 終了   : 2026-06-18 09:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 23→22→24→23→22→24→23
* 開始   : 2026-06-18 13:05:00 (UTC)
* 終了   : 2026-06-18 13:35:00 (UTC)
* 現象   : 2026-06-18 13:35:00 (UTC)を境に水準が 15.07から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 63.7→65.62→70.55→65.84→67.35→70.98→63.88→69.22
* 開始   : 2026-06-18 14:30:00 (UTC)
* 終了   : 2026-06-18 15:05:00 (UTC)
* 現象   : 2026-06-18 15:05:00 (UTC)を境に水準が 49.62から50.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→19→16→17→19→16→17→18
* 開始   : 2026-06-18 16:00:00 (UTC)
* 終了   : 2026-06-18 16:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→18→16→15→17→18→16→15→17
* 開始   : 2026-06-18 16:35:00 (UTC)
* 終了   : 2026-06-18 16:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→15→13→15
* 開始   : 2026-06-18 18:05:00 (UTC)
* 終了   : 2026-06-18 18:10:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7761(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→12→12→11→10→11→10→10→11
* 開始   : 2026-06-18 20:30:00 (UTC)
* 終了   : 2026-06-18 21:45:00 (UTC)
* 現象   : 2026-06-18 21:45:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→10→11→13
* 開始   : 2026-06-19 02:30:00 (UTC)
* 終了   : 2026-06-19 02:45:00 (UTC)
* 現象   : 2026-06-19 02:45:00 (UTC)を境に水準が 15.07から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→11→12→10→10→7→12→14→13
* 開始   : 2026-06-19 02:45:00 (UTC)
* 終了   : 2026-06-19 04:05:00 (UTC)
* 現象   : 2026-06-19 04:05:00 (UTC)を境に水準が 14.99から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→13→10→9→12→13→10
* 開始   : 2026-06-19 02:55:00 (UTC)
* 終了   : 2026-06-19 03:00:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→19→20→18→21→20→18→21→20
* 開始   : 2026-06-19 07:35:00 (UTC)
* 終了   : 2026-06-19 07:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260619-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→14→…→15→14→15→17
* 開始   : 2026-06-19 17:05:00 (UTC)
* 終了   : 2026-06-19 17:10:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→14→11→10→12→14→11→10→12
* 開始   : 2026-06-19 19:20:00 (UTC)
* 終了   : 2026-06-19 19:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260619-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→8→10→11→8→12
* 開始   : 2026-06-19 19:45:00 (UTC)
* 終了   : 2026-06-19 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.69→39.63→32.62→37.05→…→37.05→32.43→40.59→35.67
* 開始   : 2026-06-19 20:35:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(41.09)に対し 0.7939(32.62)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 7→10→13→5→…→13→5→8→9
* 開始   : 2026-06-20 02:00:00 (UTC)
* 終了   : 2026-06-20 02:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.883σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→11→10→9→…→10→12→9→13
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 05:30:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.73, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 15 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分

![EVT-20260620-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→13→…→11→12→11→12
* 開始   : 2026-06-20 07:05:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 10.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.057, 限界=4.006)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host01-006 (同一ホスト) jvm_gc / eu : FATAL / 重なり 10.9 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10.9 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間

![EVT-20260620-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→14→13→11→12→14→14
* 開始   : 2026-06-21 04:45:00 (UTC)
* 終了   : 2026-06-21 05:30:00 (UTC)
* 現象   : 2026-06-21 05:30:00 (UTC)を境に水準が 11.89から12.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→14→18→14→18→14→15
* 開始   : 2026-06-21 10:40:00 (UTC)
* 終了   : 2026-06-21 10:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→18
* 開始   : 2026-06-21 13:20:00 (UTC)
* 終了   : 2026-06-21 13:35:00 (UTC)
* 現象   : 2026-06-21 13:35:00 (UTC)を境に水準が 11.77から13.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.055, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→8→…→9→8→9→12
* 開始   : 2026-06-21 18:40:00 (UTC)
* 終了   : 2026-06-21 18:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260621-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→18→14→19→18→14→19→17→18
* 開始   : 2026-06-23 06:55:00 (UTC)
* 終了   : 2026-06-23 07:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 20→20→19→18→19→20→19→18→21
* 開始   : 2026-06-23 15:20:00 (UTC)
* 終了   : 2026-06-23 16:00:00 (UTC)
* 現象   : 2026-06-23 16:00:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→18→16→18→16→18→19
* 開始   : 2026-06-23 16:05:00 (UTC)
* 終了   : 2026-06-23 16:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.23→50.29→44.42→47.58→…→47.58→44.79→45.4→47.37
* 開始   : 2026-06-23 18:10:00 (UTC)
* 終了   : 2026-06-23 18:20:00 (UTC)
* 現象   : 平常時(53.32)に対し 0.8331(44.42)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→13→11→14→14→15
* 開始   : 2026-06-24 03:55:00 (UTC)
* 終了   : 2026-06-24 04:20:00 (UTC)
* 現象   : 2026-06-24 04:20:00 (UTC)を境に水準が 14.94から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→14→8→11→14→8→11→12
* 開始   : 2026-06-24 04:10:00 (UTC)
* 終了   : 2026-06-24 04:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→13→11→15→13
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→16→15→13→…→13→16→14→15
* 開始   : 2026-06-24 05:15:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.842σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.04→53→56.01→56.88→…→56.01→56.88→47.57→47.32
* 開始   : 2026-06-24 05:55:00 (UTC)
* 終了   : 2026-06-24 06:00:00 (UTC)
* 現象   : 平常時(47.74)に対し 1.173倍(56.01)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→16→19→16→18
* 開始   : 2026-06-24 07:20:00 (UTC)
* 終了   : 2026-06-24 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 22→22→23→21→23→22→22→20→22
* 開始   : 2026-06-24 13:05:00 (UTC)
* 終了   : 2026-06-24 14:15:00 (UTC)
* 現象   : 2026-06-24 14:15:00 (UTC)を境に水準が 14.85から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.956, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 62.23→61.93→56.93→56.47→…→56.93→56.47→58.42→63.54
* 開始   : 2026-06-24 15:40:00 (UTC)
* 終了   : 2026-06-24 15:45:00 (UTC)
* 現象   : 平常時(64.93)に対し 0.8767(56.93)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260624-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→18→14→17→18→14→17→16
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-019 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→9→8→10→9→9→11→10
* 開始   : 2026-06-24 23:15:00 (UTC)
* 終了   : 2026-06-24 23:50:00 (UTC)
* 現象   : 2026-06-24 23:50:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host01-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.76→49.42→60.18→61.32→…→60.18→61.32→55→54.04
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 06:50:00 (UTC)
* 現象   : 平常時(50.24)に対し 1.198倍(60.18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→16→…→16→19→17→18
* 開始   : 2026-06-25 06:50:00 (UTC)
* 終了   : 2026-06-25 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.114σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-004 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→18→19→20→19→20→15→17
* 開始   : 2026-06-25 07:05:00 (UTC)
* 終了   : 2026-06-25 07:15:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→19→18→16→21
* 開始   : 2026-06-25 07:15:00 (UTC)
* 終了   : 2026-06-25 07:35:00 (UTC)
* 現象   : 2026-06-25 07:35:00 (UTC)を境に水準が 15.05から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→15→19→16→15→19→18
* 開始   : 2026-06-25 15:55:00 (UTC)
* 終了   : 2026-06-25 16:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→19→16→19→16→19
* 開始   : 2026-06-25 16:00:00 (UTC)
* 終了   : 2026-06-25 16:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→14→13→19→17→14→13→19→16
* 開始   : 2026-06-25 17:40:00 (UTC)
* 終了   : 2026-06-25 17:45:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 39.23→27.77→40.82→43.72→…→40.82→43.72→36.49→32.59
* 開始   : 2026-06-26 03:05:00 (UTC)
* 終了   : 2026-06-26 03:10:00 (UTC)
* 現象   : 平常時(32.85)に対し 1.243倍(40.82)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→15→12→14→15→12
* 開始   : 2026-06-26 04:40:00 (UTC)
* 終了   : 2026-06-26 04:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→18→14→16→18→14→16→15
* 開始   : 2026-06-26 17:20:00 (UTC)
* 終了   : 2026-06-26 17:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→10→14→10→14→11
* 開始   : 2026-06-26 19:10:00 (UTC)
* 終了   : 2026-06-26 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7059(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.937σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→10→…→10→7→9→11
* 開始   : 2026-06-26 21:00:00 (UTC)
* 終了   : 2026-06-26 21:10:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-010 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260626-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→15→…→14→11→13→15
* 開始   : 2026-06-27 07:45:00 (UTC)
* 終了   : 2026-06-27 17:50:00 (UTC)
* 現象   : 10.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.348, 限界=4.006)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 10.1 時間
  - EVT-20260627-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 10.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間

![EVT-20260627-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→11→10→9→…→12→9→12→10
* 開始   : 2026-06-27 19:15:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.7, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260627-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→11→11→11→11
* 開始   : 2026-06-28 02:40:00 (UTC)
* 終了   : 2026-06-28 03:10:00 (UTC)
* 現象   : 2026-06-28 03:10:00 (UTC)を境に水準が 11.81から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 7→10→12→9→10→12→9→10
* 開始   : 2026-06-28 03:15:00 (UTC)
* 終了   : 2026-06-28 03:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→13→13→13
* 開始   : 2026-06-28 05:00:00 (UTC)
* 終了   : 2026-06-28 05:15:00 (UTC)
* 現象   : 2026-06-28 05:15:00 (UTC)を境に水準が 11.85から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→12→14→12
* 開始   : 2026-06-28 06:00:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.408σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260628-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→15→12→14→14→16→13→15
* 開始   : 2026-06-28 07:10:00 (UTC)
* 終了   : 2026-06-28 07:45:00 (UTC)
* 現象   : 2026-06-28 07:45:00 (UTC)を境に水準が 11.79から12.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→10→16→15→16→15→16→15→12
* 開始   : 2026-06-28 07:35:00 (UTC)
* 終了   : 2026-06-28 07:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260628-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→13→…→12→13→9→12
* 開始   : 2026-06-28 18:35:00 (UTC)
* 終了   : 2026-06-28 18:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→20→18→20→…→16→15→13→16
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.82から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.44, 限界=4.006)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 8→12→9→8→12→9→11
* 開始   : 2026-06-30 02:05:00 (UTC)
* 終了   : 2026-06-30 02:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→12→11→12→11→12→9→10
* 開始   : 2026-06-30 02:25:00 (UTC)
* 終了   : 2026-06-30 02:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→10→…→10→15→16→13
* 開始   : 2026-06-30 04:15:00 (UTC)
* 終了   : 2026-06-30 04:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→20→16→20→16→20→17→18
* 開始   : 2026-06-30 07:05:00 (UTC)
* 終了   : 2026-06-30 07:15:00 (UTC)
* 現象   : 平常時(16)に対し 1.25倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.77σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 65.46→64.83→78.93→68.45→…→68.45→62.46→65.42→69.37
* 開始   : 2026-06-30 13:45:00 (UTC)
* 終了   : 2026-06-30 13:55:00 (UTC)
* 現象   : 平常時(69.32)に対し 1.139倍(78.93)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.641σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→19→15→14→17→19→15→14→17
* 開始   : 2026-06-30 17:15:00 (UTC)
* 終了   : 2026-06-30 17:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→18→15→14→…→15→14→17→16
* 開始   : 2026-06-30 17:20:00 (UTC)
* 終了   : 2026-06-30 17:25:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260630-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→14→13→11→14→13
* 開始   : 2026-06-30 19:10:00 (UTC)
* 終了   : 2026-06-30 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host01-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
