# host11 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host11 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 315 (SEVERE: 21, FATAL: 129, WARN: 165, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 129 | 165 | 315 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260606-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→14→10→11→14→10→11
* 開始   : 2026-06-06 04:05:00 (UTC)
* 終了   : 2026-06-06 04:10:00 (UTC)
* 現象   : 土曜4時台の平常値(10.66)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.854σ 外れた (平常値=10.66)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260606-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260606-host11-003 active_connections の推移](charts/EVT-20260606-host11-003.svg)

# イベントID( EVT-20260606-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→10→…→11→12→10→13
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.686, 限界=2.652)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.021σ 外れた (平常値=13.45)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host11-007 active_connections の推移](charts/EVT-20260606-host11-007.svg)

# イベントID( EVT-20260608-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→13→…→13→14→13→12
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.67から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.052, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-001 active_connections の推移](charts/EVT-20260608-host11-001.svg)

# イベントID( EVT-20260608-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→15→…→14→15→13→14
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.75から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.827, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-002 active_connections の推移](charts/EVT-20260608-host11-002.svg)

# イベントID( EVT-20260608-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→17→13→12→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.744σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.299, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-003 active_connections の推移](charts/EVT-20260608-host11-003.svg)

# イベントID( EVT-20260608-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→16→14→16→…→15→13→15→13
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:10:00 (UTC)
* 現象   : 2026-06-08 20:10:00 (UTC)を境に水準が 11.89から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-004 active_connections の推移](charts/EVT-20260608-host11-004.svg)

# イベントID( EVT-20260608-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→14→…→16→14→13→14
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.85から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.638σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.655)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-005 active_connections の推移](charts/EVT-20260608-host11-005.svg)

# イベントID( EVT-20260608-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→16→…→15→16→15→14
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 19:20:00 (UTC)
* 現象   : 2026-06-08 19:20:00 (UTC)を境に水準が 12.06から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.459σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-006 active_connections の推移](charts/EVT-20260608-host11-006.svg)

# イベントID( EVT-20260615-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→15→…→16→12→11→13
* 開始   : 2026-06-15 01:45:00 (UTC)
* 終了   : 2026-06-15 19:50:00 (UTC)
* 現象   : 2026-06-15 19:50:00 (UTC)を境に水準が 11.84から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.401σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.932, 限界=2.655)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-001 active_connections の推移](charts/EVT-20260615-host11-001.svg)

# イベントID( EVT-20260615-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→17→18→19→…→13→14→13→9
* 開始   : 2026-06-15 02:10:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.249σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.906, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-002 active_connections の推移](charts/EVT-20260615-host11-002.svg)

# イベントID( EVT-20260615-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→14→…→14→11→14→12
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.79から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.99, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-003 active_connections の推移](charts/EVT-20260615-host11-003.svg)

# イベントID( EVT-20260615-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→15→…→12→14→12→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.78から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.012, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-004 active_connections の推移](charts/EVT-20260615-host11-004.svg)

# イベントID( EVT-20260615-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→17→14→15→…→11→14→13→12
* 開始   : 2026-06-15 04:20:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 11.94から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.8, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.761, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-006 active_connections の推移](charts/EVT-20260615-host11-006.svg)

# イベントID( EVT-20260622-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→18→17→14→…→16→13→12→14
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 12.01から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.811σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.076, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.458, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-001 active_connections の推移](charts/EVT-20260622-host11-001.svg)

# イベントID( EVT-20260622-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→17→15→18→…→14→16→14→15
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.91から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.812, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-003 active_connections の推移](charts/EVT-20260622-host11-003.svg)

# イベントID( EVT-20260622-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→15→…→13→14→12→11
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.95から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.707, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-004 active_connections の推移](charts/EVT-20260622-host11-004.svg)

# イベントID( EVT-20260622-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→15→13→15→…→10→14→10→15
* 開始   : 2026-06-22 03:15:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.94から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.772, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-005 active_connections の推移](charts/EVT-20260622-host11-005.svg)

# イベントID( EVT-20260622-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→16→…→14→13→14→13
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.82から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.248σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.977, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-006 active_connections の推移](charts/EVT-20260622-host11-006.svg)

# イベントID( EVT-20260629-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→16→12→15→…→17→14→13→14
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.87から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.912, 限界=2.655)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.425, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-003 active_connections の推移](charts/EVT-20260629-host11-003.svg)

# イベントID( EVT-20260629-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→15→…→13→12→10→12
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 21:10:00 (UTC)
* 現象   : 2026-06-29 21:10:00 (UTC)を境に水準が 12.01から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-004 active_connections の推移](charts/EVT-20260629-host11-004.svg)

# イベントID( EVT-20260629-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→14→…→11→15→13→12
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.225σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.099, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.305, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-005 active_connections の推移](charts/EVT-20260629-host11-005.svg)

# イベントID( EVT-20260601-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 7→10→14→8→9
* 開始   : 2026-06-01 00:40:00 (UTC)
* 終了   : 2026-06-01 00:40:00 (UTC)
* 現象   : 平常時(8.375)に対し 1.672倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.95σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-001 active_connections の推移](charts/EVT-20260601-host11-001.svg)

# イベントID( EVT-20260601-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→16→18→19→…→19→18→17→16
* 開始   : 2026-06-01 06:35:00 (UTC)
* 終了   : 2026-06-01 06:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.576σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-004 active_connections の推移](charts/EVT-20260601-host11-004.svg)

# イベントID( EVT-20260601-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→21→25→21→23
* 開始   : 2026-06-01 10:10:00 (UTC)
* 終了   : 2026-06-01 10:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-007 active_connections の推移](charts/EVT-20260601-host11-007.svg)

# イベントID( EVT-20260601-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→23→26→21→22
* 開始   : 2026-06-01 11:20:00 (UTC)
* 終了   : 2026-06-01 11:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-008 active_connections の推移](charts/EVT-20260601-host11-008.svg)

# イベントID( EVT-20260601-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→17→13→15→18
* 開始   : 2026-06-01 17:10:00 (UTC)
* 終了   : 2026-06-01 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host11-009 active_connections の推移](charts/EVT-20260601-host11-009.svg)

# イベントID( EVT-20260601-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→10→11
* 開始   : 2026-06-01 19:50:00 (UTC)
* 終了   : 2026-06-01 19:50:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host11-010 active_connections の推移](charts/EVT-20260601-host11-010.svg)

# イベントID( EVT-20260602-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→7→13→8→6
* 開始   : 2026-06-02 01:40:00 (UTC)
* 終了   : 2026-06-02 01:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host11-001 active_connections の推移](charts/EVT-20260602-host11-001.svg)

# イベントID( EVT-20260602-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→12→16→13→13
* 開始   : 2026-06-02 04:40:00 (UTC)
* 終了   : 2026-06-02 04:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host11-002 active_connections の推移](charts/EVT-20260602-host11-002.svg)

# イベントID( EVT-20260602-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→16→9→14→15
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 18:55:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6136(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.982σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host11-007 active_connections の推移](charts/EVT-20260602-host11-007.svg)

# イベントID( EVT-20260602-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→9→5→10→8
* 開始   : 2026-06-02 22:10:00 (UTC)
* 終了   : 2026-06-02 22:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host11-008 active_connections の推移](charts/EVT-20260602-host11-008.svg)

# イベントID( EVT-20260603-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→7→13→10→11
* 開始   : 2026-06-03 02:15:00 (UTC)
* 終了   : 2026-06-03 02:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host11-001 active_connections の推移](charts/EVT-20260603-host11-001.svg)

# イベントID( EVT-20260603-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→21→17→20→21
* 開始   : 2026-06-03 13:55:00 (UTC)
* 終了   : 2026-06-03 13:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→19→15→16→19→15→16→19→17
* 開始   : 2026-06-03 15:40:00 (UTC)
* 終了   : 2026-06-03 16:50:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.7469(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 1.1 時間
  - EVT-20260603-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host11-010 active_connections の推移](charts/EVT-20260603-host11-010.svg)

# イベントID( EVT-20260603-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→20→19→17→19→19
* 開始   : 2026-06-03 16:15:00 (UTC)
* 終了   : 2026-06-03 17:45:00 (UTC)
* 現象   : 2026-06-03 17:45:00 (UTC)を境に水準が 15.04から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.868, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→14
* 開始   : 2026-06-03 18:50:00 (UTC)
* 終了   : 2026-06-03 18:50:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host11-012 active_connections の推移](charts/EVT-20260603-host11-012.svg)

# イベントID( EVT-20260603-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→9→6→9→9
* 開始   : 2026-06-03 20:45:00 (UTC)
* 終了   : 2026-06-03 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-013 active_connections の推移](charts/EVT-20260603-host11-013.svg)

# イベントID( EVT-20260603-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→7→11→…→11→8→10→11
* 開始   : 2026-06-03 20:45:00 (UTC)
* 終了   : 2026-06-03 20:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host11-014 active_connections の推移](charts/EVT-20260603-host11-014.svg)

# イベントID( EVT-20260604-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→13→13
* 開始   : 2026-06-04 04:30:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260604-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-001 active_connections の推移](charts/EVT-20260604-host11-001.svg)

# イベントID( EVT-20260604-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→14→14
* 開始   : 2026-06-04 04:35:00 (UTC)
* 終了   : 2026-06-04 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-002 active_connections の推移](charts/EVT-20260604-host11-002.svg)

# イベントID( EVT-20260604-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→13→…→13→19→16→15
* 開始   : 2026-06-04 05:45:00 (UTC)
* 終了   : 2026-06-04 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-003 active_connections の推移](charts/EVT-20260604-host11-003.svg)

# イベントID( EVT-20260604-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→17→21→17→19
* 開始   : 2026-06-04 07:30:00 (UTC)
* 終了   : 2026-06-04 07:30:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host11-006 active_connections の推移](charts/EVT-20260604-host11-006.svg)

# イベントID( EVT-20260604-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→21→24→21→…→21→23→22→20
* 開始   : 2026-06-04 09:40:00 (UTC)
* 終了   : 2026-06-04 09:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.284σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260604-host11-007 active_connections の推移](charts/EVT-20260604-host11-007.svg)

# イベントID( EVT-20260604-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→14→17→14→17→14→17→16
* 開始   : 2026-06-04 17:00:00 (UTC)
* 終了   : 2026-06-04 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-011 active_connections の推移](charts/EVT-20260604-host11-011.svg)

# イベントID( EVT-20260604-host11-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→8→13→9
* 開始   : 2026-06-04 22:20:00 (UTC)
* 終了   : 2026-06-04 22:35:00 (UTC)
* 現象   : 2026-06-04 22:35:00 (UTC)を境に水準が 15.02から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 7→10→14→8→11
* 開始   : 2026-06-05 02:05:00 (UTC)
* 終了   : 2026-06-05 02:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host11-001 active_connections の推移](charts/EVT-20260605-host11-001.svg)

# イベントID( EVT-20260605-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→13→6→11→11
* 開始   : 2026-06-05 03:40:00 (UTC)
* 終了   : 2026-06-05 03:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host11-003 active_connections の推移](charts/EVT-20260605-host11-003.svg)

# イベントID( EVT-20260605-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→18→14→13→18→14→16
* 開始   : 2026-06-05 17:25:00 (UTC)
* 終了   : 2026-06-05 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host11-012 active_connections の推移](charts/EVT-20260605-host11-012.svg)

# イベントID( EVT-20260605-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→15→12→15→14
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host11-013 active_connections の推移](charts/EVT-20260605-host11-013.svg)

# イベントID( EVT-20260605-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→9→11→11
* 開始   : 2026-06-05 19:20:00 (UTC)
* 終了   : 2026-06-05 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6279(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.744σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host11-014 active_connections の推移](charts/EVT-20260605-host11-014.svg)

# イベントID( EVT-20260606-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 6→9→12→5→…→12→5→8→9
* 開始   : 2026-06-06 01:05:00 (UTC)
* 終了   : 2026-06-06 01:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260606-host11-001 active_connections の推移](charts/EVT-20260606-host11-001.svg)

# イベントID( EVT-20260606-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→8→13→10→9
* 開始   : 2026-06-06 02:45:00 (UTC)
* 終了   : 2026-06-06 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→10→14→12→…→10→9→11→9
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:55:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.216, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-007 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260606-host11-004 active_connections の推移](charts/EVT-20260606-host11-004.svg)

# イベントID( EVT-20260606-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→14→…→12→13→12→13
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.081, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-007 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host11-005 active_connections の推移](charts/EVT-20260606-host11-005.svg)

# イベントID( EVT-20260606-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→10→13→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.296σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-007 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host11-006 active_connections の推移](charts/EVT-20260606-host11-006.svg)

# イベントID( EVT-20260606-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→11→…→10→11→10→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-007 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host11-008 active_connections の推移](charts/EVT-20260606-host11-008.svg)

# イベントID( EVT-20260606-host11-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→14→…→12→13→12→13
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.853, 限界=2.655)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-007 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host11-009 active_connections の推移](charts/EVT-20260606-host11-009.svg)

# イベントID( EVT-20260607-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→11→13→13→12→11→12→14
* 開始   : 2026-06-07 04:45:00 (UTC)
* 終了   : 2026-06-07 07:15:00 (UTC)
* 現象   : 2026-06-07 07:15:00 (UTC)を境に水準が 11.79から12.27へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.407, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→13→17→15→11
* 開始   : 2026-06-07 07:20:00 (UTC)
* 終了   : 2026-06-07 07:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host11-003 active_connections の推移](charts/EVT-20260607-host11-003.svg)

# イベントID( EVT-20260607-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→10→4→8→7
* 開始   : 2026-06-07 21:05:00 (UTC)
* 終了   : 2026-06-07 21:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.4174(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-006 active_connections の推移](charts/EVT-20260607-host11-006.svg)

# イベントID( EVT-20260609-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→15→14
* 開始   : 2026-06-09 06:00:00 (UTC)
* 終了   : 2026-06-09 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host11-004 active_connections の推移](charts/EVT-20260609-host11-004.svg)

# イベントID( EVT-20260609-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→16→19
* 開始   : 2026-06-09 07:50:00 (UTC)
* 終了   : 2026-06-09 07:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-006 active_connections の推移](charts/EVT-20260609-host11-006.svg)

# イベントID( EVT-20260609-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→19→24→22→23
* 開始   : 2026-06-09 09:45:00 (UTC)
* 終了   : 2026-06-09 09:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 20→21→17→20→21
* 開始   : 2026-06-09 14:05:00 (UTC)
* 終了   : 2026-06-09 14:05:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host11-010 active_connections の推移](charts/EVT-20260609-host11-010.svg)

# イベントID( EVT-20260610-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→12→18→14→16
* 開始   : 2026-06-10 05:45:00 (UTC)
* 終了   : 2026-06-10 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-004 active_connections の推移](charts/EVT-20260610-host11-004.svg)

# イベントID( EVT-20260610-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→23→26→22→22
* 開始   : 2026-06-10 12:45:00 (UTC)
* 終了   : 2026-06-10 12:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-008 active_connections の推移](charts/EVT-20260610-host11-008.svg)

# イベントID( EVT-20260610-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→17→14→17→17
* 開始   : 2026-06-10 16:50:00 (UTC)
* 終了   : 2026-06-10 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-010 active_connections の推移](charts/EVT-20260610-host11-010.svg)

# イベントID( EVT-20260610-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→14→11→13→15
* 開始   : 2026-06-10 18:15:00 (UTC)
* 終了   : 2026-06-10 18:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host11-011 active_connections の推移](charts/EVT-20260610-host11-011.svg)

# イベントID( EVT-20260610-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→12→…→12→9→14→12
* 開始   : 2026-06-10 19:20:00 (UTC)
* 終了   : 2026-06-10 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260610-host11-012 active_connections の推移](charts/EVT-20260610-host11-012.svg)

# イベントID( EVT-20260610-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→11→6→10→11
* 開始   : 2026-06-10 20:15:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.4832(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host11-015 active_connections の推移](charts/EVT-20260610-host11-015.svg)

# イベントID( EVT-20260610-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→8→4→9→9
* 開始   : 2026-06-10 23:10:00 (UTC)
* 終了   : 2026-06-10 23:10:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host11-016 active_connections の推移](charts/EVT-20260610-host11-016.svg)

# イベントID( EVT-20260611-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→12→7→11→11
* 開始   : 2026-06-11 20:30:00 (UTC)
* 終了   : 2026-06-11 20:30:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-009 active_connections の推移](charts/EVT-20260611-host11-009.svg)

# イベントID( EVT-20260612-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→13→19→15→16
* 開始   : 2026-06-12 05:35:00 (UTC)
* 終了   : 2026-06-12 05:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.471倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-003 active_connections の推移](charts/EVT-20260612-host11-003.svg)

# イベントID( EVT-20260612-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→18→21→18→19
* 開始   : 2026-06-12 07:30:00 (UTC)
* 終了   : 2026-06-12 07:30:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-004 active_connections の推移](charts/EVT-20260612-host11-004.svg)

# イベントID( EVT-20260612-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 22→21→16→19→18
* 開始   : 2026-06-12 15:05:00 (UTC)
* 終了   : 2026-06-12 15:05:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-006 active_connections の推移](charts/EVT-20260612-host11-006.svg)

# イベントID( EVT-20260612-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→18→16→16→15→16→16→15→18
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 18:45:00 (UTC)
* 現象   : 2026-06-12 18:45:00 (UTC)を境に水準が 14.94から12.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.583σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→15→17
* 開始   : 2026-06-12 17:40:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-008 active_connections の推移](charts/EVT-20260612-host11-008.svg)

# イベントID( EVT-20260612-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→14→11→16→13
* 開始   : 2026-06-12 17:55:00 (UTC)
* 終了   : 2026-06-12 17:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-009 active_connections の推移](charts/EVT-20260612-host11-009.svg)

# イベントID( EVT-20260613-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→13→14→13→11
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.691, 限界=2.655)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260613-host11-001 active_connections の推移](charts/EVT-20260613-host11-001.svg)

# イベントID( EVT-20260613-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→10→…→12→11→13→11
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 20:30:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.8 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260613-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間

![EVT-20260613-host11-002 active_connections の推移](charts/EVT-20260613-host11-002.svg)

# イベントID( EVT-20260613-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→14→12→11→…→13→14→15→11
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.913, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.1 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host11-003 active_connections の推移](charts/EVT-20260613-host11-003.svg)

# イベントID( EVT-20260613-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→12→…→14→12→13→12
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 20:30:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.141, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.7 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260613-host11-004 active_connections の推移](charts/EVT-20260613-host11-004.svg)

# イベントID( EVT-20260613-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→13→…→12→11→13→12
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host11-005 active_connections の推移](charts/EVT-20260613-host11-005.svg)

# イベントID( EVT-20260613-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→13→…→14→12→14→12
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.049, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host11-006 active_connections の推移](charts/EVT-20260613-host11-006.svg)

# イベントID( EVT-20260614-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→12→13
* 開始   : 2026-06-14 06:45:00 (UTC)
* 終了   : 2026-06-14 06:45:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host11-002 active_connections の推移](charts/EVT-20260614-host11-002.svg)

# イベントID( EVT-20260614-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→16→…→16→12→16→14
* 開始   : 2026-06-14 14:20:00 (UTC)
* 終了   : 2026-06-14 14:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host11-003 active_connections の推移](charts/EVT-20260614-host11-003.svg)

# イベントID( EVT-20260614-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→9→13→12→…→12→7→12→10
* 開始   : 2026-06-14 18:45:00 (UTC)
* 終了   : 2026-06-14 19:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131倍(7)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260614-host11-005 active_connections の推移](charts/EVT-20260614-host11-005.svg)

# イベントID( EVT-20260614-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→11→6→10→9
* 開始   : 2026-06-14 20:40:00 (UTC)
* 終了   : 2026-06-14 20:40:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→14→…→14→12→11→10
* 開始   : 2026-06-15 05:25:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 12.03から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.656, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.127, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-007 active_connections の推移](charts/EVT-20260615-host11-007.svg)

# イベントID( EVT-20260616-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→8→12→8→7
* 開始   : 2026-06-16 00:00:00 (UTC)
* 終了   : 2026-06-16 00:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→15→19→15→15
* 開始   : 2026-06-16 06:10:00 (UTC)
* 終了   : 2026-06-16 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.357倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.518σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-005 active_connections の推移](charts/EVT-20260616-host11-005.svg)

# イベントID( EVT-20260616-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→19→25→20→21
* 開始   : 2026-06-16 09:30:00 (UTC)
* 終了   : 2026-06-16 09:30:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host11-006 active_connections の推移](charts/EVT-20260616-host11-006.svg)

# イベントID( EVT-20260616-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→10→11→…→11→8→11→15
* 開始   : 2026-06-16 19:10:00 (UTC)
* 終了   : 2026-06-16 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-010 active_connections の推移](charts/EVT-20260616-host11-010.svg)

# イベントID( EVT-20260616-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→10→5→10→10
* 開始   : 2026-06-16 22:35:00 (UTC)
* 終了   : 2026-06-16 22:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-011 active_connections の推移](charts/EVT-20260616-host11-011.svg)

# イベントID( EVT-20260617-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→5→9
* 開始   : 2026-06-17 00:35:00 (UTC)
* 終了   : 2026-06-17 00:35:00 (UTC)
* 現象   : 平常時(7.167)に対し 1.674倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-001 active_connections の推移](charts/EVT-20260617-host11-001.svg)

# イベントID( EVT-20260617-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→11→16→11→13
* 開始   : 2026-06-17 04:30:00 (UTC)
* 終了   : 2026-06-17 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.512倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.806σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host11-003 active_connections の推移](charts/EVT-20260617-host11-003.svg)

# イベントID( EVT-20260617-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→15→20→16→16
* 開始   : 2026-06-17 06:50:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-004 active_connections の推移](charts/EVT-20260617-host11-004.svg)

# イベントID( EVT-20260617-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→14→17
* 開始   : 2026-06-17 17:55:00 (UTC)
* 終了   : 2026-06-17 17:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→9→6→9→11
* 開始   : 2026-06-17 21:00:00 (UTC)
* 終了   : 2026-06-17 21:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-009 active_connections の推移](charts/EVT-20260617-host11-009.svg)

# イベントID( EVT-20260617-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→12→4→9→9
* 開始   : 2026-06-17 21:45:00 (UTC)
* 終了   : 2026-06-17 21:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.3967(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host11-010 active_connections の推移](charts/EVT-20260617-host11-010.svg)

# イベントID( EVT-20260618-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→21→24→18→…→18→23→19→21
* 開始   : 2026-06-18 09:05:00 (UTC)
* 終了   : 2026-06-18 09:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-005 active_connections の推移](charts/EVT-20260618-host11-005.svg)

# イベントID( EVT-20260618-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→9→11→4→…→11→4→5→8
* 開始   : 2026-06-18 23:35:00 (UTC)
* 終了   : 2026-06-19 00:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host11-008 active_connections の推移](charts/EVT-20260618-host11-008.svg)

# イベントID( EVT-20260619-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→18→22→19→18
* 開始   : 2026-06-19 07:35:00 (UTC)
* 終了   : 2026-06-19 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.32倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host11-004 active_connections の推移](charts/EVT-20260619-host11-004.svg)

# イベントID( EVT-20260619-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→19→23→20→20
* 開始   : 2026-06-19 08:50:00 (UTC)
* 終了   : 2026-06-19 08:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host11-005 active_connections の推移](charts/EVT-20260619-host11-005.svg)

# イベントID( EVT-20260619-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→12→7→11→10
* 開始   : 2026-06-19 20:55:00 (UTC)
* 終了   : 2026-06-19 20:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host11-012 active_connections の推移](charts/EVT-20260619-host11-012.svg)

# イベントID( EVT-20260620-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→9→13→11→9
* 開始   : 2026-06-20 03:00:00 (UTC)
* 終了   : 2026-06-20 03:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host11-001 active_connections の推移](charts/EVT-20260620-host11-001.svg)

# イベントID( EVT-20260620-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→11→…→11→12→14→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.99, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host11-002 active_connections の推移](charts/EVT-20260620-host11-002.svg)

# イベントID( EVT-20260620-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→12→…→14→12→13→12
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.862, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260620-host11-003 active_connections の推移](charts/EVT-20260620-host11-003.svg)

# イベントID( EVT-20260620-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→12→…→12→13→12→13
* 開始   : 2026-06-20 05:30:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.903, 限界=2.655)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host11-004 active_connections の推移](charts/EVT-20260620-host11-004.svg)

# イベントID( EVT-20260620-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→12→10→…→12→11→12→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host11-005 active_connections の推移](charts/EVT-20260620-host11-005.svg)

# イベントID( EVT-20260620-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→14→13→14→13
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 17:20:00 (UTC)
* 現象   : 11.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.6 時間

![EVT-20260620-host11-006 active_connections の推移](charts/EVT-20260620-host11-006.svg)

# イベントID( EVT-20260620-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→10→14→12→…→13→12→14→12
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.743, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260620-host11-007 active_connections の推移](charts/EVT-20260620-host11-007.svg)

# イベントID( EVT-20260620-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→9→5→9→7
* 開始   : 2026-06-20 21:45:00 (UTC)
* 終了   : 2026-06-20 21:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→17→14→13
* 開始   : 2026-06-21 07:35:00 (UTC)
* 終了   : 2026-06-21 07:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→10→15→15
* 開始   : 2026-06-21 15:35:00 (UTC)
* 終了   : 2026-06-21 15:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host11-004 active_connections の推移](charts/EVT-20260621-host11-004.svg)

# イベントID( EVT-20260622-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→17→18→15→…→13→12→13→15
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 19:55:00 (UTC)
* 現象   : 2026-06-22 19:55:00 (UTC)を境に水準が 11.8から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.914, 限界=2.655)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-002 active_connections の推移](charts/EVT-20260622-host11-002.svg)

# イベントID( EVT-20260623-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→15→12→13
* 開始   : 2026-06-23 04:00:00 (UTC)
* 終了   : 2026-06-23 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.108σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-001 active_connections の推移](charts/EVT-20260623-host11-001.svg)

# イベントID( EVT-20260623-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→12
* 開始   : 2026-06-23 05:55:00 (UTC)
* 終了   : 2026-06-23 05:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.382倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.687σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-003 active_connections の推移](charts/EVT-20260623-host11-003.svg)

# イベントID( EVT-20260623-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 23→24→18→22→20
* 開始   : 2026-06-23 12:15:00 (UTC)
* 終了   : 2026-06-23 12:15:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host11-006 active_connections の推移](charts/EVT-20260623-host11-006.svg)

# イベントID( EVT-20260623-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 24→21→17→21→21
* 開始   : 2026-06-23 14:00:00 (UTC)
* 終了   : 2026-06-23 14:00:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-007 active_connections の推移](charts/EVT-20260623-host11-007.svg)

# イベントID( EVT-20260623-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→13→13
* 開始   : 2026-06-23 19:35:00 (UTC)
* 終了   : 2026-06-23 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host11-012 active_connections の推移](charts/EVT-20260623-host11-012.svg)

# イベントID( EVT-20260623-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→9→5→9→10
* 開始   : 2026-06-23 22:00:00 (UTC)
* 終了   : 2026-06-23 22:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→10→15→12→…→12→17→13→14
* 開始   : 2026-06-24 04:45:00 (UTC)
* 終了   : 2026-06-24 04:55:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-002 active_connections の推移](charts/EVT-20260624-host11-002.svg)

# イベントID( EVT-20260624-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→15→18
* 開始   : 2026-06-24 07:05:00 (UTC)
* 終了   : 2026-06-24 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host11-005 active_connections の推移](charts/EVT-20260624-host11-005.svg)

# イベントID( EVT-20260624-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→16→21→15→18
* 開始   : 2026-06-24 07:45:00 (UTC)
* 終了   : 2026-06-24 07:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-007 active_connections の推移](charts/EVT-20260624-host11-007.svg)

# イベントID( EVT-20260624-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→18→14→17→15
* 開始   : 2026-06-24 16:35:00 (UTC)
* 終了   : 2026-06-24 16:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-013 active_connections の推移](charts/EVT-20260624-host11-013.svg)

# イベントID( EVT-20260624-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→16→12→15→15
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-014 active_connections の推移](charts/EVT-20260624-host11-014.svg)

# イベントID( EVT-20260625-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→13→17→13→13
* 開始   : 2026-06-25 04:45:00 (UTC)
* 終了   : 2026-06-25 04:45:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.753σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-005 active_connections の推移](charts/EVT-20260625-host11-005.svg)

# イベントID( EVT-20260625-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→21→17→20→22
* 開始   : 2026-06-25 14:00:00 (UTC)
* 終了   : 2026-06-25 14:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→8→13→10→11
* 開始   : 2026-06-26 03:05:00 (UTC)
* 終了   : 2026-06-26 03:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260626-host11-001 active_connections の推移](charts/EVT-20260626-host11-001.svg)

# イベントID( EVT-20260626-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→14→11
* 開始   : 2026-06-26 04:30:00 (UTC)
* 終了   : 2026-06-26 04:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host11-002 active_connections の推移](charts/EVT-20260626-host11-002.svg)

# イベントID( EVT-20260626-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→9→12→11
* 開始   : 2026-06-26 19:20:00 (UTC)
* 終了   : 2026-06-26 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host11-007 active_connections の推移](charts/EVT-20260626-host11-007.svg)

# イベントID( EVT-20260626-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→11→6→9→10
* 開始   : 2026-06-26 21:35:00 (UTC)
* 終了   : 2026-06-26 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→12→…→11→13→10→13
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 18:20:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host11-003 active_connections の推移](charts/EVT-20260627-host11-003.svg)

# イベントID( EVT-20260627-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→13→…→11→14→12→13
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 20:55:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host11-004 active_connections の推移](charts/EVT-20260627-host11-004.svg)

# イベントID( EVT-20260627-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→11→9→11→…→10→11→10→11
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 20:00:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 4.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.832, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host11-005 active_connections の推移](charts/EVT-20260627-host11-005.svg)

# イベントID( EVT-20260627-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→14→…→11→8→12→10
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.655)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host11-006 active_connections の推移](charts/EVT-20260627-host11-006.svg)

# イベントID( EVT-20260627-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→13→…→10→9→12→10
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.886, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host11-007 active_connections の推移](charts/EVT-20260627-host11-007.svg)

# イベントID( EVT-20260627-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→12→14→12→…→12→13→12→11
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.1 時間

![EVT-20260627-host11-008 active_connections の推移](charts/EVT-20260627-host11-008.svg)

# イベントID( EVT-20260627-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→10→5→8→9
* 開始   : 2026-06-27 21:20:00 (UTC)
* 終了   : 2026-06-27 21:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host11-009 active_connections の推移](charts/EVT-20260627-host11-009.svg)

# イベントID( EVT-20260628-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→15→13
* 開始   : 2026-06-28 07:10:00 (UTC)
* 終了   : 2026-06-28 07:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host11-001 active_connections の推移](charts/EVT-20260628-host11-001.svg)

# イベントID( EVT-20260628-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→10→12→10→11→13
* 開始   : 2026-06-28 16:20:00 (UTC)
* 終了   : 2026-06-28 16:30:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260628-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host11-004 active_connections の推移](charts/EVT-20260628-host11-004.svg)

# イベントID( EVT-20260629-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→15→…→13→14→13→14
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-002 active_connections の推移](charts/EVT-20260629-host11-002.svg)

# イベントID( EVT-20260629-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→16→…→15→14→12→14
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 21:25:00 (UTC)
* 現象   : 2026-06-29 21:25:00 (UTC)を境に水準が 11.79から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.714, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-006 active_connections の推移](charts/EVT-20260629-host11-006.svg)

# イベントID( EVT-20260629-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→13→…→13→12→13→11
* 開始   : 2026-06-29 04:20:00 (UTC)
* 終了   : 2026-06-29 19:30:00 (UTC)
* 現象   : 2026-06-29 19:30:00 (UTC)を境に水準が 12.05から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.04, 限界=2.653)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-007 active_connections の推移](charts/EVT-20260629-host11-007.svg)

# イベントID( EVT-20260630-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→15→15
* 開始   : 2026-06-30 05:45:00 (UTC)
* 終了   : 2026-06-30 05:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-005 active_connections の推移](charts/EVT-20260630-host11-005.svg)

# イベントID( EVT-20260630-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→14→17→19→…→17→19→16→15
* 開始   : 2026-06-30 06:00:00 (UTC)
* 終了   : 2026-06-30 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-006 active_connections の推移](charts/EVT-20260630-host11-006.svg)

# イベントID( EVT-20260630-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→22→18→16→20→22→18
* 開始   : 2026-06-30 07:45:00 (UTC)
* 終了   : 2026-06-30 07:50:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-007 active_connections の推移](charts/EVT-20260630-host11-007.svg)

# イベントID( EVT-20260630-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→20→19
* 開始   : 2026-06-30 08:55:00 (UTC)
* 終了   : 2026-06-30 08:55:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-009 active_connections の推移](charts/EVT-20260630-host11-009.svg)

# イベントID( EVT-20260630-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→20→14→20→14→16
* 開始   : 2026-06-30 16:40:00 (UTC)
* 終了   : 2026-06-30 16:50:00 (UTC)
* 現象   : 火曜16時台の平常値(17.81)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 3.045σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.269σ 外れた (平常値=17.81)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260630-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-011 active_connections の推移](charts/EVT-20260630-host11-011.svg)

# イベントID( EVT-20260601-host11-002 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→11→14→12→…→12→8→12→13
* 開始   : 2026-06-01 03:50:00 (UTC)
* 終了   : 2026-06-01 04:00:00 (UTC)
* 現象   : 月曜3時台の平常値(10.63)に対し 14であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.216σ 外れた (平常値=10.63)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260601-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→16→18→17→18→17→18→15→17
* 開始   : 2026-06-01 06:30:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.638σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→20→16→19→20→16→17
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→22→24→23→24→23→24→21
* 開始   : 2026-06-01 10:05:00 (UTC)
* 終了   : 2026-06-01 10:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→11→8→12→…→7→9→7→9
* 開始   : 2026-06-01 21:00:00 (UTC)
* 終了   : 2026-06-01 21:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.284σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→12→17→14→12→17→14→15
* 開始   : 2026-06-02 05:45:00 (UTC)
* 終了   : 2026-06-02 05:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.752σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→12→17→18→16→12→17→18→16
* 開始   : 2026-06-02 06:15:00 (UTC)
* 終了   : 2026-06-02 06:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 23→19→25→21→23→19→25→21
* 開始   : 2026-06-02 12:35:00 (UTC)
* 終了   : 2026-06-02 12:40:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.46σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 20→20→18→20→19→18→18→16→20
* 開始   : 2026-06-02 15:50:00 (UTC)
* 終了   : 2026-06-02 16:55:00 (UTC)
* 現象   : 2026-06-02 16:55:00 (UTC)を境に水準が 15.09から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→8→…→8→11→8→10
* 開始   : 2026-06-02 23:50:00 (UTC)
* 終了   : 2026-06-03 00:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-081 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260602-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→13→15→12→15→12→15→13→12
* 開始   : 2026-06-03 04:45:00 (UTC)
* 終了   : 2026-06-03 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.287σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→17→16→13→17→16→17
* 開始   : 2026-06-03 06:05:00 (UTC)
* 終了   : 2026-06-03 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→15→20→15→20→18→17
* 開始   : 2026-06-03 07:25:00 (UTC)
* 終了   : 2026-06-03 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→21→23→22→…→22→17→22→19
* 開始   : 2026-06-03 09:10:00 (UTC)
* 終了   : 2026-06-03 09:20:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.404σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→22→24→21→24→21→24→21→22
* 開始   : 2026-06-03 11:05:00 (UTC)
* 終了   : 2026-06-03 11:15:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.249σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 25→22→22→24→24→23→23→22→23
* 開始   : 2026-06-03 12:10:00 (UTC)
* 終了   : 2026-06-03 12:55:00 (UTC)
* 現象   : 2026-06-03 12:55:00 (UTC)を境に水準が 15.15から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.332, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→20→24→18→…→24→18→21→19
* 開始   : 2026-06-03 14:40:00 (UTC)
* 終了   : 2026-06-03 14:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→9→11→8→9→8
* 開始   : 2026-06-03 21:10:00 (UTC)
* 終了   : 2026-06-03 21:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→19→18→16→18→17→17→16
* 開始   : 2026-06-04 06:40:00 (UTC)
* 終了   : 2026-06-04 07:15:00 (UTC)
* 現象   : 2026-06-04 07:15:00 (UTC)を境に水準が 14.91から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→17→19→17→19→17→19→17→18
* 開始   : 2026-06-04 06:55:00 (UTC)
* 終了   : 2026-06-04 07:05:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→23→23→23→23→24→22
* 開始   : 2026-06-04 12:30:00 (UTC)
* 終了   : 2026-06-04 13:40:00 (UTC)
* 現象   : 2026-06-04 13:40:00 (UTC)を境に水準が 14.9から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→21→17→18→…→18→16→20→19
* 開始   : 2026-06-04 15:25:00 (UTC)
* 終了   : 2026-06-04 15:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→16→19→15→16→19→15→19→17
* 開始   : 2026-06-04 16:15:00 (UTC)
* 終了   : 2026-06-04 16:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→12→14→11→…→12→10→15→12
* 開始   : 2026-06-04 18:45:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260604-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→12→11→14→11→14→11→13
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260604-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→10→11→13→10→11→12
* 開始   : 2026-06-04 19:45:00 (UTC)
* 終了   : 2026-06-04 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→10→12→11→12→11
* 開始   : 2026-06-04 19:55:00 (UTC)
* 終了   : 2026-06-04 20:30:00 (UTC)
* 現象   : 2026-06-04 20:30:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→7→6→9→10→7→6→9
* 開始   : 2026-06-04 21:25:00 (UTC)
* 終了   : 2026-06-04 21:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→10→9→8→10→9→8→10→10
* 開始   : 2026-06-04 21:25:00 (UTC)
* 終了   : 2026-06-04 23:40:00 (UTC)
* 現象   : 2026-06-04 23:40:00 (UTC)を境に水準が 14.88から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→9→10→10→10→13
* 開始   : 2026-06-05 02:20:00 (UTC)
* 終了   : 2026-06-05 03:50:00 (UTC)
* 現象   : 2026-06-05 03:50:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→15→11→15→11→15→13→14
* 開始   : 2026-06-05 04:50:00 (UTC)
* 終了   : 2026-06-05 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→17→15→17→16
* 開始   : 2026-06-05 05:55:00 (UTC)
* 終了   : 2026-06-05 06:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→16→18→16→18→16
* 開始   : 2026-06-05 06:20:00 (UTC)
* 終了   : 2026-06-05 06:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260605-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→20→15→21→20→17→21→18→18
* 開始   : 2026-06-05 07:15:00 (UTC)
* 終了   : 2026-06-05 08:35:00 (UTC)
* 現象   : 2026-06-05 08:35:00 (UTC)を境に水準が 14.96から14.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→18→21→19→18→21→19→18
* 開始   : 2026-06-05 07:55:00 (UTC)
* 終了   : 2026-06-05 08:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→21→24→21
* 開始   : 2026-06-05 10:35:00 (UTC)
* 終了   : 2026-06-05 10:40:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.185倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.638σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→16→…→17→16→18→21
* 開始   : 2026-06-05 15:45:00 (UTC)
* 終了   : 2026-06-05 15:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→19→16→15→…→16→15→17→19
* 開始   : 2026-06-05 16:10:00 (UTC)
* 終了   : 2026-06-05 16:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→6→5→11→…→5→11→8→7
* 開始   : 2026-06-06 23:20:00 (UTC)
* 終了   : 2026-06-06 23:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→10→12→13→…→12→13→11→9
* 開始   : 2026-06-07 03:50:00 (UTC)
* 終了   : 2026-06-07 03:55:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→11→15→10→…→10→9→11→10
* 開始   : 2026-06-07 18:35:00 (UTC)
* 終了   : 2026-06-07 18:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→9→13→8→…→8→6→7→12
* 開始   : 2026-06-07 20:10:00 (UTC)
* 終了   : 2026-06-07 20:20:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→9→6→9→6→9→8
* 開始   : 2026-06-08 22:30:00 (UTC)
* 終了   : 2026-06-08 22:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.284σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 6→8→12→11→8→12→11→9
* 開始   : 2026-06-09 01:20:00 (UTC)
* 終了   : 2026-06-09 01:25:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.87σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-002 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→12→14→14→15→14→14
* 開始   : 2026-06-09 04:30:00 (UTC)
* 終了   : 2026-06-09 05:00:00 (UTC)
* 現象   : 2026-06-09 05:00:00 (UTC)を境に水準が 14.97から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.008, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→16→14→17→16→14→17→15→14
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.225σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→17→18→15→17→18→15→16
* 開始   : 2026-06-09 06:05:00 (UTC)
* 終了   : 2026-06-09 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→20→23→20→22
* 開始   : 2026-06-09 09:25:00 (UTC)
* 終了   : 2026-06-09 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→20→23→24→…→21→18→21→23
* 開始   : 2026-06-09 09:55:00 (UTC)
* 終了   : 2026-06-09 10:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→19→20→16→19→18
* 開始   : 2026-06-09 15:45:00 (UTC)
* 終了   : 2026-06-09 15:50:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260609-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→15→14→16→15→14→16→17
* 開始   : 2026-06-09 17:05:00 (UTC)
* 終了   : 2026-06-09 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→13→13→16→12→16→13→13
* 開始   : 2026-06-09 18:30:00 (UTC)
* 終了   : 2026-06-09 19:05:00 (UTC)
* 現象   : 2026-06-09 19:05:00 (UTC)を境に水準が 15.02から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→15→13→13→12→12→11→14→12
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 20:00:00 (UTC)
* 現象   : 2026-06-09 20:00:00 (UTC)を境に水準が 15.02から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.616, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 6→8→11→7→11→7→11→9
* 開始   : 2026-06-10 01:25:00 (UTC)
* 終了   : 2026-06-10 01:35:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→12→12→13→15→12→14
* 開始   : 2026-06-10 02:40:00 (UTC)
* 終了   : 2026-06-10 04:20:00 (UTC)
* 現象   : 2026-06-10 04:20:00 (UTC)を境に水準が 14.94から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.345σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→…→12→16→15→13
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 05:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→15→14→18→15→17
* 開始   : 2026-06-10 06:30:00 (UTC)
* 終了   : 2026-06-10 07:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.576σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→19→17→19→18→16
* 開始   : 2026-06-10 07:00:00 (UTC)
* 終了   : 2026-06-10 07:10:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→15→20→18→20→18→20→18
* 開始   : 2026-06-10 07:25:00 (UTC)
* 終了   : 2026-06-10 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.463σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 22→22→23→22→21→20→24
* 開始   : 2026-06-10 14:05:00 (UTC)
* 終了   : 2026-06-10 14:35:00 (UTC)
* 現象   : 2026-06-10 14:35:00 (UTC)を境に水準が 15.1から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→12→9→12→9→12→9→10→12
* 開始   : 2026-06-10 20:05:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.536σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→13→9→12→13→9→12→13
* 開始   : 2026-06-10 20:10:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→12→13→10→12→13→10→11
* 開始   : 2026-06-11 03:05:00 (UTC)
* 終了   : 2026-06-11 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260611-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→13→15→15
* 開始   : 2026-06-11 04:20:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 2026-06-11 05:30:00 (UTC)を境に水準が 14.99から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.71σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→13→17→18→…→17→18→17→15
* 開始   : 2026-06-11 06:45:00 (UTC)
* 終了   : 2026-06-11 06:50:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 19→18→20→21→…→19→20→21→19
* 開始   : 2026-06-11 08:10:00 (UTC)
* 終了   : 2026-06-11 08:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→20→22→23→21→20→22→23→21
* 開始   : 2026-06-11 09:25:00 (UTC)
* 終了   : 2026-06-11 09:30:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.225σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 22→22→22→21
* 開始   : 2026-06-11 14:45:00 (UTC)
* 終了   : 2026-06-11 15:00:00 (UTC)
* 現象   : 2026-06-11 15:00:00 (UTC)を境に水準が 14.92から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→14→15→17→14→15
* 開始   : 2026-06-11 17:30:00 (UTC)
* 終了   : 2026-06-11 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.239σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→13→12→13→12→13→12→13
* 開始   : 2026-06-11 18:30:00 (UTC)
* 終了   : 2026-06-11 18:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260611-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→9→9→10→8→9→9→10
* 開始   : 2026-06-11 22:35:00 (UTC)
* 終了   : 2026-06-11 23:10:00 (UTC)
* 現象   : 2026-06-11 23:10:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→10→10→11→11→11
* 開始   : 2026-06-12 02:15:00 (UTC)
* 終了   : 2026-06-12 02:50:00 (UTC)
* 現象   : 2026-06-12 02:50:00 (UTC)を境に水準が 14.99から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→14→15→14→15→14→13
* 開始   : 2026-06-12 04:50:00 (UTC)
* 終了   : 2026-06-12 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.287σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 21→23→19→22→20→21→21→22→22
* 開始   : 2026-06-12 08:55:00 (UTC)
* 終了   : 2026-06-12 10:35:00 (UTC)
* 現象   : 2026-06-12 10:35:00 (UTC)を境に水準が 14.96から13.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.023, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→13→…→14→13→15→14
* 開始   : 2026-06-12 17:55:00 (UTC)
* 終了   : 2026-06-12 18:00:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→15→10→9→…→10→9→11→12
* 開始   : 2026-06-12 19:55:00 (UTC)
* 終了   : 2026-06-12 20:00:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-012 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 7→9→5→8→9→5→8→7
* 開始   : 2026-06-12 23:30:00 (UTC)
* 終了   : 2026-06-12 23:35:00 (UTC)
* 現象   : 金曜23時台の平常値(8.234)に対し 5であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.029σ 外れた (平常値=8.234)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260612-host02-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-089 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260612-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→9→…→9→12→8→10
* 開始   : 2026-06-13 22:30:00 (UTC)
* 終了   : 2026-06-13 22:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-065 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260613-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→8→11
* 開始   : 2026-06-14 00:05:00 (UTC)
* 終了   : 2026-06-14 00:25:00 (UTC)
* 現象   : 2026-06-14 00:25:00 (UTC)を境に水準が 11.82から11.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→10→11→10→14→12
* 開始   : 2026-06-14 17:25:00 (UTC)
* 終了   : 2026-06-14 17:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.518σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→8→6→8→6→8→10
* 開始   : 2026-06-14 20:45:00 (UTC)
* 終了   : 2026-06-14 20:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260614-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→12→12→10→13→11→10→13→12
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 04:20:00 (UTC)
* 現象   : 2026-06-15 04:20:00 (UTC)を境に水準が 11.87から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→9→10→8→10→10→10
* 開始   : 2026-06-15 21:30:00 (UTC)
* 終了   : 2026-06-15 23:20:00 (UTC)
* 現象   : 2026-06-15 23:20:00 (UTC)を境に水準が 14.74から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 7→9→5→10→9→5→10→8
* 開始   : 2026-06-15 23:50:00 (UTC)
* 終了   : 2026-06-15 23:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→12→10→6→12→10→12
* 開始   : 2026-06-16 02:20:00 (UTC)
* 終了   : 2026-06-16 02:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→11→10→13
* 開始   : 2026-06-16 02:25:00 (UTC)
* 終了   : 2026-06-16 02:45:00 (UTC)
* 現象   : 2026-06-16 02:45:00 (UTC)を境に水準が 14.94から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→17→13→17→13→16
* 開始   : 2026-06-16 05:45:00 (UTC)
* 終了   : 2026-06-16 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260616-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→23→25→18→22→23→25→18→22
* 開始   : 2026-06-16 12:30:00 (UTC)
* 終了   : 2026-06-16 12:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→23→20→19→22→19→21→21
* 開始   : 2026-06-16 14:50:00 (UTC)
* 終了   : 2026-06-16 15:25:00 (UTC)
* 現象   : 2026-06-16 15:25:00 (UTC)を境に水準が 15.07から15.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→20→17→18→…→18→17→16→18
* 開始   : 2026-06-16 15:35:00 (UTC)
* 終了   : 2026-06-16 15:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 8→10→7→11→9→8→9→10
* 開始   : 2026-06-16 23:50:00 (UTC)
* 終了   : 2026-06-17 00:25:00 (UTC)
* 現象   : 2026-06-17 00:25:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→9→10→12→9→11
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→15→16→17→15→16→18
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→14→…→14→17→12→14
* 開始   : 2026-06-17 19:00:00 (UTC)
* 終了   : 2026-06-17 19:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→15→12→13
* 開始   : 2026-06-17 19:10:00 (UTC)
* 終了   : 2026-06-17 19:25:00 (UTC)
* 現象   : 2026-06-17 19:25:00 (UTC)を境に水準が 15.09から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→13→9→13→9→13→12
* 開始   : 2026-06-18 03:25:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→13→19→15→19→15→19→15→17
* 開始   : 2026-06-18 06:20:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.811σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→19→15→19→15→19→18→19
* 開始   : 2026-06-18 06:55:00 (UTC)
* 終了   : 2026-06-18 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.239σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→20→22→18→…→18→23→20→19
* 開始   : 2026-06-18 08:55:00 (UTC)
* 終了   : 2026-06-18 09:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→20→15→18→15→18→15→18→17
* 開始   : 2026-06-18 16:25:00 (UTC)
* 終了   : 2026-06-18 16:35:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7965(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→7→5→11→8→7→5→11→8
* 開始   : 2026-06-18 23:10:00 (UTC)
* 終了   : 2026-06-18 23:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260618-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→8→10
* 開始   : 2026-06-19 00:25:00 (UTC)
* 終了   : 2026-06-19 00:45:00 (UTC)
* 現象   : 2026-06-19 00:45:00 (UTC)を境に水準が 15.1から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→14→15→10→14→15→14→15→14
* 開始   : 2026-06-19 04:35:00 (UTC)
* 終了   : 2026-06-19 04:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→11→…→16→14→16→14
* 開始   : 2026-06-19 04:55:00 (UTC)
* 終了   : 2026-06-19 05:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260619-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260619-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260619-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 24→21→25→19→21→25→19→21→22
* 開始   : 2026-06-19 11:35:00 (UTC)
* 終了   : 2026-06-19 11:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.342σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260619-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→16→13→16→13→16→14
* 開始   : 2026-06-19 17:35:00 (UTC)
* 終了   : 2026-06-19 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.7647(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.766σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→18→14→13→14→13→15→16
* 開始   : 2026-06-19 17:45:00 (UTC)
* 終了   : 2026-06-19 17:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260619-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→18→16→13→13→14→14→15
* 開始   : 2026-06-19 18:30:00 (UTC)
* 終了   : 2026-06-19 19:05:00 (UTC)
* 現象   : 2026-06-19 19:05:00 (UTC)を境に水準が 14.93から12.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→13→…→13→10→12→13
* 開始   : 2026-06-19 19:25:00 (UTC)
* 終了   : 2026-06-19 20:05:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.066σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260619-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→11→9→12→…→12→8→11→9
* 開始   : 2026-06-19 20:45:00 (UTC)
* 終了   : 2026-06-19 20:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→10→7→9→7→9→10→12
* 開始   : 2026-06-20 20:15:00 (UTC)
* 終了   : 2026-06-20 20:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.758, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host11-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→6→9→11→7→6→9→11→8
* 開始   : 2026-06-20 21:00:00 (UTC)
* 終了   : 2026-06-20 21:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.075, 限界=2.655)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→13→14
* 開始   : 2026-06-21 05:15:00 (UTC)
* 終了   : 2026-06-21 05:35:00 (UTC)
* 現象   : 2026-06-21 05:35:00 (UTC)を境に水準が 11.98から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→16→12→11→…→12→11→15→16
* 開始   : 2026-06-21 09:15:00 (UTC)
* 終了   : 2026-06-21 09:20:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260621-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 8→11→6→10→…→10→13→10→8
* 開始   : 2026-06-21 21:05:00 (UTC)
* 終了   : 2026-06-21 21:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.468σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260621-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260621-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→16→15→18→19→18→17
* 開始   : 2026-06-23 05:40:00 (UTC)
* 終了   : 2026-06-23 06:50:00 (UTC)
* 現象   : 2026-06-23 06:50:00 (UTC)を境に水準が 14.87から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.345σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.671, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→18→22→18→22→21→20
* 開始   : 2026-06-23 09:15:00 (UTC)
* 終了   : 2026-06-23 09:25:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 22→20→18→24→25→18→24→25→21
* 開始   : 2026-06-23 11:40:00 (UTC)
* 終了   : 2026-06-23 11:50:00 (UTC)
* 現象   : 平常時(22)に対し 0.8182(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.811σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→18→22→19→…→19→16→20→17
* 開始   : 2026-06-23 15:10:00 (UTC)
* 終了   : 2026-06-23 16:10:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260623-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→20→17→23→…→17→23→19→21
* 開始   : 2026-06-23 15:15:00 (UTC)
* 終了   : 2026-06-23 15:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→16→14→16
* 開始   : 2026-06-23 17:40:00 (UTC)
* 終了   : 2026-06-23 18:05:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260623-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→12→10→13→12→10→13→15
* 開始   : 2026-06-23 19:25:00 (UTC)
* 終了   : 2026-06-23 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→9→12→9→12→9→11→12
* 開始   : 2026-06-23 20:05:00 (UTC)
* 終了   : 2026-06-23 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.518σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260623-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→7→9→9→12→8→8→10
* 開始   : 2026-06-24 00:10:00 (UTC)
* 終了   : 2026-06-24 00:45:00 (UTC)
* 現象   : 2026-06-24 00:45:00 (UTC)を境に水準が 14.99から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→15→17
* 開始   : 2026-06-24 05:05:00 (UTC)
* 終了   : 2026-06-24 05:20:00 (UTC)
* 現象   : 2026-06-24 05:20:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→17→14→13→16→17→14
* 開始   : 2026-06-24 05:15:00 (UTC)
* 終了   : 2026-06-24 05:20:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→18→17→19→19→18→21→20→21
* 開始   : 2026-06-24 07:10:00 (UTC)
* 終了   : 2026-06-24 07:50:00 (UTC)
* 現象   : 2026-06-24 07:50:00 (UTC)を境に水準が 15から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.576σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.229, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→16→21→20→21→20→21→20→17
* 開始   : 2026-06-24 08:05:00 (UTC)
* 終了   : 2026-06-24 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.354σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260624-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→19→23→24→20→19→23→24→20
* 開始   : 2026-06-24 09:40:00 (UTC)
* 終了   : 2026-06-24 09:45:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260624-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 22→19→22→19→22→19→21→20
* 開始   : 2026-06-24 13:55:00 (UTC)
* 終了   : 2026-06-24 14:05:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260624-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→20→24→18→…→24→18→19→20
* 開始   : 2026-06-24 14:15:00 (UTC)
* 終了   : 2026-06-24 14:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260624-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→20→24→19→22→21→20→20→21
* 開始   : 2026-06-24 14:15:00 (UTC)
* 終了   : 2026-06-24 15:25:00 (UTC)
* 現象   : 2026-06-24 15:25:00 (UTC)を境に水準が 14.95から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.111σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→12→13→11→12
* 開始   : 2026-06-24 19:20:00 (UTC)
* 終了   : 2026-06-24 19:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-064 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→8→…→9→8→11→9
* 開始   : 2026-06-24 20:15:00 (UTC)
* 終了   : 2026-06-24 20:20:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.108σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→8→5→7→12→5→7→12→9
* 開始   : 2026-06-25 01:05:00 (UTC)
* 終了   : 2026-06-25 01:15:00 (UTC)
* 現象   : 木曜1時台の平常値(8.553)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 2.181σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.121σ 外れた (平常値=8.553)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-004 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→9→11→9→10
* 開始   : 2026-06-25 02:00:00 (UTC)
* 終了   : 2026-06-25 02:05:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→7→12→9→…→9→6→9→11
* 開始   : 2026-06-25 02:35:00 (UTC)
* 終了   : 2026-06-25 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→10→11
* 開始   : 2026-06-25 02:35:00 (UTC)
* 終了   : 2026-06-25 02:55:00 (UTC)
* 現象   : 2026-06-25 02:55:00 (UTC)を境に水準が 15.01から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→12→15→16→…→15→16→14→13
* 開始   : 2026-06-25 05:05:00 (UTC)
* 終了   : 2026-06-25 05:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→21→19→23→21→22
* 開始   : 2026-06-25 09:40:00 (UTC)
* 終了   : 2026-06-25 09:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→16→18→16→18
* 開始   : 2026-06-25 15:45:00 (UTC)
* 終了   : 2026-06-25 15:50:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.7967(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.824σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→18→17→18→16→16→16→18→17
* 開始   : 2026-06-25 16:35:00 (UTC)
* 終了   : 2026-06-25 17:15:00 (UTC)
* 現象   : 2026-06-25 17:15:00 (UTC)を境に水準が 15.09から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.455, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→13→17→13→17→13→14→16
* 開始   : 2026-06-25 17:45:00 (UTC)
* 終了   : 2026-06-25 17:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→13→…→11→10→13→14
* 開始   : 2026-06-25 19:05:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-068 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→9→13→9→13→9→10
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.124σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→10→8→10→11
* 開始   : 2026-06-25 21:45:00 (UTC)
* 終了   : 2026-06-25 22:15:00 (UTC)
* 現象   : 2026-06-25 22:15:00 (UTC)を境に水準が 14.89から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→17→18→16→14→17→18→16
* 開始   : 2026-06-26 06:20:00 (UTC)
* 終了   : 2026-06-26 06:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→21→21→21→21→22→21→22→23
* 開始   : 2026-06-26 09:00:00 (UTC)
* 終了   : 2026-06-26 09:55:00 (UTC)
* 現象   : 2026-06-26 09:55:00 (UTC)を境に水準が 15.07から14.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→12→14→15→12→14
* 開始   : 2026-06-26 18:25:00 (UTC)
* 終了   : 2026-06-26 18:30:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.066σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→10→12→13→11→10→12
* 開始   : 2026-06-26 19:10:00 (UTC)
* 終了   : 2026-06-26 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→6→…→12→6→8→9
* 開始   : 2026-06-27 01:55:00 (UTC)
* 終了   : 2026-06-27 02:00:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→11→…→11→10→14→12
* 開始   : 2026-06-27 04:55:00 (UTC)
* 終了   : 2026-06-27 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.655, 限界=2.653)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260627-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→19→…→18→19→16→15
* 開始   : 2026-06-28 12:15:00 (UTC)
* 終了   : 2026-06-28 12:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-033 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260628-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→13→16
* 開始   : 2026-06-28 16:10:00 (UTC)
* 終了   : 2026-06-28 16:30:00 (UTC)
* 現象   : 2026-06-28 16:30:00 (UTC)を境に水準が 11.83から14.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→11→10→10→10→11
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 02:35:00 (UTC)
* 現象   : 2026-06-29 02:35:00 (UTC)を境に水準が 11.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.466, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→8→10→10→8→10→8→8→11
* 開始   : 2026-06-30 00:10:00 (UTC)
* 終了   : 2026-06-30 00:50:00 (UTC)
* 現象   : 2026-06-30 00:50:00 (UTC)を境に水準が 14.88から15.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.802, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 7→6→11→5→…→11→5→7→8
* 開始   : 2026-06-30 00:20:00 (UTC)
* 終了   : 2026-06-30 00:25:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.401σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 6→9→11→6→11→6→11→8→6
* 開始   : 2026-06-30 00:30:00 (UTC)
* 終了   : 2026-06-30 00:40:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→12→12→14→13→12→14→14
* 開始   : 2026-06-30 03:20:00 (UTC)
* 終了   : 2026-06-30 04:25:00 (UTC)
* 現象   : 2026-06-30 04:25:00 (UTC)を境に水準が 14.89から16.26へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→22→19→20→…→22→19→22→21
* 開始   : 2026-06-30 08:55:00 (UTC)
* 終了   : 2026-06-30 09:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 24→23→20→22→19→20→20→20→21
* 開始   : 2026-06-30 13:35:00 (UTC)
* 終了   : 2026-06-30 16:00:00 (UTC)
* 現象   : 2026-06-30 16:00:00 (UTC)を境に水準が 15.08から12.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.849, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→9→…→10→9→11→13
* 開始   : 2026-06-30 19:50:00 (UTC)
* 終了   : 2026-06-30 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.066σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→8→…→9→8→11→10
* 開始   : 2026-06-30 20:30:00 (UTC)
* 終了   : 2026-06-30 20:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→8→7→8→10→8→7→8→10
* 開始   : 2026-06-30 21:15:00 (UTC)
* 終了   : 2026-06-30 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→7→5→9→…→9→12→8→9
* 開始   : 2026-06-30 23:05:00 (UTC)
* 終了   : 2026-06-30 23:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host11-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
