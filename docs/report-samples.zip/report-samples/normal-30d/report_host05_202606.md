# host05 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host05 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 302 (SEVERE: 19, FATAL: 127, WARN: 156, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 127 | 156 | 302 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→15→14→12→13
* 開始   : 2026-06-08 01:45:00 (UTC)
* 終了   : 2026-06-08 19:05:00 (UTC)
* 現象   : 2026-06-08 19:05:00 (UTC)を境に水準が 11.85から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.533, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-001 active_connections の推移](charts/EVT-20260608-host05-001.svg)

# イベントID( EVT-20260608-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→16→…→13→14→11→14
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 20:15:00 (UTC)
* 現象   : 2026-06-08 20:15:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.018, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-004 active_connections の推移](charts/EVT-20260608-host05-004.svg)

# イベントID( EVT-20260608-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→13→16→13→…→14→12→14→13
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 22:25:00 (UTC)
* 現象   : 2026-06-08 22:25:00 (UTC)を境に水準が 11.8から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.766σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-005 active_connections の推移](charts/EVT-20260608-host05-005.svg)

# イベントID( EVT-20260608-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→14→…→14→15→14→13
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.85から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-006 active_connections の推移](charts/EVT-20260608-host05-006.svg)

# イベントID( EVT-20260615-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→16→…→17→13→15→13
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.96から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.048σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-001 active_connections の推移](charts/EVT-20260615-host05-001.svg)

# イベントID( EVT-20260615-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→15→16→13→…→11→14→11→13
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.376, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-002 active_connections の推移](charts/EVT-20260615-host05-002.svg)

# イベントID( EVT-20260615-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→16→14→17→…→15→17→12→13
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.93から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.867, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-004 active_connections の推移](charts/EVT-20260615-host05-004.svg)

# イベントID( EVT-20260615-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→11→14→13→…→12→16→12→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.829, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.845, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-006 active_connections の推移](charts/EVT-20260615-host05-006.svg)

# イベントID( EVT-20260622-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→16→…→12→13→12→14
* 開始   : 2026-06-22 01:25:00 (UTC)
* 終了   : 2026-06-22 21:15:00 (UTC)
* 現象   : 2026-06-22 21:15:00 (UTC)を境に水準が 11.78から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-003 active_connections の推移](charts/EVT-20260622-host05-003.svg)

# イベントID( EVT-20260622-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→17→15→17→…→13→15→11→14
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.81から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.222, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-004 active_connections の推移](charts/EVT-20260622-host05-004.svg)

# イベントID( EVT-20260622-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→18→14→16→…→14→13→12→14
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.207, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.432, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-005 active_connections の推移](charts/EVT-20260622-host05-005.svg)

# イベントID( EVT-20260622-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→15→14→12→13
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.81から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.053σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.785, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.521, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-006 active_connections の推移](charts/EVT-20260622-host05-006.svg)

# イベントID( EVT-20260622-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→14→18→15→…→14→15→13→12
* 開始   : 2026-06-22 04:05:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.91から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.335, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-007 active_connections の推移](charts/EVT-20260622-host05-007.svg)

# イベントID( EVT-20260622-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→13→14→16→…→16→14→12→13
* 開始   : 2026-06-22 04:40:00 (UTC)
* 終了   : 2026-06-22 19:55:00 (UTC)
* 現象   : 2026-06-22 19:55:00 (UTC)を境に水準が 12.03から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.708, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-008 active_connections の推移](charts/EVT-20260622-host05-008.svg)

# イベントID( EVT-20260629-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→15→…→14→13→12→13
* 開始   : 2026-06-29 00:40:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.66から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.775, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-002 active_connections の推移](charts/EVT-20260629-host05-002.svg)

# イベントID( EVT-20260629-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→16→…→13→15→14→12
* 開始   : 2026-06-29 01:55:00 (UTC)
* 終了   : 2026-06-29 21:50:00 (UTC)
* 現象   : 2026-06-29 21:50:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-003 active_connections の推移](charts/EVT-20260629-host05-003.svg)

# イベントID( EVT-20260629-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→15→…→14→13→14→13
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 22:00:00 (UTC)
* 現象   : 2026-06-29 22:00:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.229σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.754, 限界=2.666)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.199σ 外れた (平常値=9.712)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-004 active_connections の推移](charts/EVT-20260629-host05-004.svg)

# イベントID( EVT-20260629-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→14→19→18→…→13→14→11→12
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.87から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.103, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-005 active_connections の推移](charts/EVT-20260629-host05-005.svg)

# イベントID( EVT-20260629-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→15→…→15→16→15→16
* 開始   : 2026-06-29 03:45:00 (UTC)
* 終了   : 2026-06-29 22:10:00 (UTC)
* 現象   : 2026-06-29 22:10:00 (UTC)を境に水準が 11.94から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.719, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-006 active_connections の推移](charts/EVT-20260629-host05-006.svg)

# イベントID( EVT-20260601-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→10→4→12→…→4→12→9→8
* 開始   : 2026-06-01 00:25:00 (UTC)
* 終了   : 2026-06-01 00:30:00 (UTC)
* 現象   : 月曜0時台の平常値(8.203)に対し 4であった
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.635σ 外れた (平常値=8.203)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→9→14→10→10
* 開始   : 2026-06-01 03:35:00 (UTC)
* 終了   : 2026-06-01 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host05-003 active_connections の推移](charts/EVT-20260601-host05-003.svg)

# イベントID( EVT-20260601-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→16→20→16→18
* 開始   : 2026-06-01 06:50:00 (UTC)
* 終了   : 2026-06-01 06:50:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host05-008 active_connections の推移](charts/EVT-20260601-host05-008.svg)

# イベントID( EVT-20260602-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→12→15→11→10
* 開始   : 2026-06-02 03:25:00 (UTC)
* 終了   : 2026-06-02 03:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host05-001 active_connections の推移](charts/EVT-20260602-host05-001.svg)

# イベントID( EVT-20260602-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→12→13
* 開始   : 2026-06-02 04:35:00 (UTC)
* 終了   : 2026-06-02 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host05-002 active_connections の推移](charts/EVT-20260602-host05-002.svg)

# イベントID( EVT-20260602-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→12→16→14→11
* 開始   : 2026-06-02 04:50:00 (UTC)
* 終了   : 2026-06-02 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→19→24→19→21
* 開始   : 2026-06-02 09:30:00 (UTC)
* 終了   : 2026-06-02 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-005 active_connections の推移](charts/EVT-20260602-host05-005.svg)

# イベントID( EVT-20260602-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→16→11→15→13
* 開始   : 2026-06-02 18:15:00 (UTC)
* 終了   : 2026-06-02 18:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host05-009 active_connections の推移](charts/EVT-20260602-host05-009.svg)

# イベントID( EVT-20260603-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→20→22→18→…→18→14→18→20
* 開始   : 2026-06-03 08:05:00 (UTC)
* 終了   : 2026-06-03 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host05-002 active_connections の推移](charts/EVT-20260603-host05-002.svg)

# イベントID( EVT-20260603-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→20→21
* 開始   : 2026-06-03 09:05:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host05-004 active_connections の推移](charts/EVT-20260603-host05-004.svg)

# イベントID( EVT-20260603-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→17→13→19→17
* 開始   : 2026-06-03 16:50:00 (UTC)
* 終了   : 2026-06-03 16:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host05-006 active_connections の推移](charts/EVT-20260603-host05-006.svg)

# イベントID( EVT-20260603-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→11→11→11→12→11→12→11→12
* 開始   : 2026-06-03 20:45:00 (UTC)
* 終了   : 2026-06-03 22:25:00 (UTC)
* 現象   : 2026-06-03 22:25:00 (UTC)を境に水準が 14.95から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.469, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→7→4→7→11
* 開始   : 2026-06-04 00:35:00 (UTC)
* 終了   : 2026-06-04 00:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-001 active_connections の推移](charts/EVT-20260604-host05-001.svg)

# イベントID( EVT-20260604-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→13→13
* 開始   : 2026-06-04 04:40:00 (UTC)
* 終了   : 2026-06-04 04:40:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.488倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.65σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host05-003 active_connections の推移](charts/EVT-20260604-host05-003.svg)

# イベントID( EVT-20260604-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→13→13→14→15→15→13→18
* 開始   : 2026-06-04 04:50:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 2026-06-04 05:25:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.34σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host05-004 active_connections の推移](charts/EVT-20260604-host05-004.svg)

# イベントID( EVT-20260604-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→14→18→14→16
* 開始   : 2026-06-04 06:00:00 (UTC)
* 終了   : 2026-06-04 06:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260604-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260604-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host05-005 active_connections の推移](charts/EVT-20260604-host05-005.svg)

# イベントID( EVT-20260604-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→14→16
* 開始   : 2026-06-04 06:00:00 (UTC)
* 終了   : 2026-06-04 06:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host05-006 active_connections の推移](charts/EVT-20260604-host05-006.svg)

# イベントID( EVT-20260604-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→19→24→19→22
* 開始   : 2026-06-04 09:35:00 (UTC)
* 終了   : 2026-06-04 09:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-009 active_connections の推移](charts/EVT-20260604-host05-009.svg)

# イベントID( EVT-20260604-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→15→15
* 開始   : 2026-06-04 18:35:00 (UTC)
* 終了   : 2026-06-04 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-011 active_connections の推移](charts/EVT-20260604-host05-011.svg)

# イベントID( EVT-20260604-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→6→9→9
* 開始   : 2026-06-04 21:15:00 (UTC)
* 終了   : 2026-06-04 21:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.5255(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.809σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host05-014 active_connections の推移](charts/EVT-20260604-host05-014.svg)

# イベントID( EVT-20260605-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→5→8→9→13→5→8
* 開始   : 2026-06-05 01:30:00 (UTC)
* 終了   : 2026-06-05 01:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→14→15
* 開始   : 2026-06-05 04:50:00 (UTC)
* 終了   : 2026-06-05 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host05-004 active_connections の推移](charts/EVT-20260605-host05-004.svg)

# イベントID( EVT-20260605-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→20→23→20→20
* 開始   : 2026-06-05 08:45:00 (UTC)
* 終了   : 2026-06-05 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host05-005 active_connections の推移](charts/EVT-20260605-host05-005.svg)

# イベントID( EVT-20260605-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→19→15→12→…→15→12→15→17
* 開始   : 2026-06-05 17:15:00 (UTC)
* 終了   : 2026-06-05 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host05-007 active_connections の推移](charts/EVT-20260605-host05-007.svg)

# イベントID( EVT-20260605-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→15→11→14→14
* 開始   : 2026-06-05 18:20:00 (UTC)
* 終了   : 2026-06-05 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host05-008 active_connections の推移](charts/EVT-20260605-host05-008.svg)

# イベントID( EVT-20260605-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→12→12
* 開始   : 2026-06-05 18:55:00 (UTC)
* 終了   : 2026-06-05 18:55:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→11→10→12→…→12→9→14→12
* 開始   : 2026-06-05 19:15:00 (UTC)
* 終了   : 2026-06-05 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-083 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260605-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-082 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host05-010 active_connections の推移](charts/EVT-20260605-host05-010.svg)

# イベントID( EVT-20260605-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 7→9→13→7→8
* 開始   : 2026-06-05 23:40:00 (UTC)
* 終了   : 2026-06-05 23:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host05-012 active_connections の推移](charts/EVT-20260605-host05-012.svg)

# イベントID( EVT-20260606-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→13→…→11→10→11→12
* 開始   : 2026-06-06 04:05:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.783, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260606-host05-001 active_connections の推移](charts/EVT-20260606-host05-001.svg)

# イベントID( EVT-20260606-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→13→…→13→12→13→14
* 開始   : 2026-06-06 04:40:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.686, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host05-002 active_connections の推移](charts/EVT-20260606-host05-002.svg)

# イベントID( EVT-20260606-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→11→…→12→11→13→12
* 開始   : 2026-06-06 04:50:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host05-003 active_connections の推移](charts/EVT-20260606-host05-003.svg)

# イベントID( EVT-20260606-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→12→10→11→…→13→10→12→13
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.693, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host05-004 active_connections の推移](charts/EVT-20260606-host05-004.svg)

# イベントID( EVT-20260606-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→10→14→12→…→10→12→11→13
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.945, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260606-host05-005 active_connections の推移](charts/EVT-20260606-host05-005.svg)

# イベントID( EVT-20260606-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→12→…→12→11→13→12
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 17:55:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.698, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host05-006 active_connections の推移](charts/EVT-20260606-host05-006.svg)

# イベントID( EVT-20260607-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→13→15
* 開始   : 2026-06-07 13:05:00 (UTC)
* 終了   : 2026-06-07 13:05:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host05-007 active_connections の推移](charts/EVT-20260607-host05-007.svg)

# イベントID( EVT-20260608-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→13→…→15→16→12→15
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 21:10:00 (UTC)
* 現象   : 2026-06-08 21:10:00 (UTC)を境に水準が 11.85から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.99, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-003 active_connections の推移](charts/EVT-20260608-host05-003.svg)

# イベントID( EVT-20260608-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→14→18→17→…→13→15→12→13
* 開始   : 2026-06-08 03:45:00 (UTC)
* 終了   : 2026-06-08 21:05:00 (UTC)
* 現象   : 2026-06-08 21:05:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-007 active_connections の推移](charts/EVT-20260608-host05-007.svg)

# イベントID( EVT-20260609-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→15→14→14→16→16→17
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 06:15:00 (UTC)
* 現象   : 2026-06-09 06:15:00 (UTC)を境に水準が 15.01から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→13→13
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 05:35:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host05-002 active_connections の推移](charts/EVT-20260609-host05-002.svg)

# イベントID( EVT-20260609-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→18→22→18→…→18→21→20→19
* 開始   : 2026-06-09 07:55:00 (UTC)
* 終了   : 2026-06-09 08:05:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host05-004 active_connections の推移](charts/EVT-20260609-host05-004.svg)

# イベントID( EVT-20260610-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→15→12→13→11→17→15→15→15
* 開始   : 2026-06-10 04:00:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 2026-06-10 05:10:00 (UTC)を境に水準が 14.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.165σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→13→13
* 開始   : 2026-06-10 05:25:00 (UTC)
* 終了   : 2026-06-10 05:25:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.427倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.533σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-002 active_connections の推移](charts/EVT-20260610-host05-002.svg)

# イベントID( EVT-20260610-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→17→18
* 開始   : 2026-06-10 07:50:00 (UTC)
* 終了   : 2026-06-10 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host05-003 active_connections の推移](charts/EVT-20260610-host05-003.svg)

# イベントID( EVT-20260610-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→22→21→24→22→21→24→19→20
* 開始   : 2026-06-10 09:15:00 (UTC)
* 終了   : 2026-06-10 09:25:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-006 active_connections の推移](charts/EVT-20260610-host05-006.svg)

# イベントID( EVT-20260610-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→20→17→21→21
* 開始   : 2026-06-10 13:30:00 (UTC)
* 終了   : 2026-06-10 13:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host05-008 active_connections の推移](charts/EVT-20260610-host05-008.svg)

# イベントID( EVT-20260610-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→17→17→19→18→19→20
* 開始   : 2026-06-10 16:35:00 (UTC)
* 終了   : 2026-06-10 17:45:00 (UTC)
* 現象   : 2026-06-10 17:45:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.551σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→20→14→16→18
* 開始   : 2026-06-10 16:35:00 (UTC)
* 終了   : 2026-06-10 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.7368(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-010 active_connections の推移](charts/EVT-20260610-host05-010.svg)

# イベントID( EVT-20260610-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→15→9→14→12
* 開始   : 2026-06-10 19:00:00 (UTC)
* 終了   : 2026-06-10 19:00:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.6353(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.594σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host05-011 active_connections の推移](charts/EVT-20260610-host05-011.svg)

# イベントID( EVT-20260610-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→12→…→12→7→8→10
* 開始   : 2026-06-10 20:50:00 (UTC)
* 終了   : 2026-06-10 21:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host05-012 active_connections の推移](charts/EVT-20260610-host05-012.svg)

# イベントID( EVT-20260611-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→11→12
* 開始   : 2026-06-11 04:15:00 (UTC)
* 終了   : 2026-06-11 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-002 active_connections の推移](charts/EVT-20260611-host05-002.svg)

# イベントID( EVT-20260611-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→13→14
* 開始   : 2026-06-11 05:35:00 (UTC)
* 終了   : 2026-06-11 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-004 active_connections の推移](charts/EVT-20260611-host05-004.svg)

# イベントID( EVT-20260611-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→16→19→20→…→19→20→17→18
* 開始   : 2026-06-11 07:10:00 (UTC)
* 終了   : 2026-06-11 08:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host05-005 active_connections の推移](charts/EVT-20260611-host05-005.svg)

# イベントID( EVT-20260611-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→16→20→17→17
* 開始   : 2026-06-11 07:15:00 (UTC)
* 終了   : 2026-06-11 07:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-006 active_connections の推移](charts/EVT-20260611-host05-006.svg)

# イベントID( EVT-20260611-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→17→22→19→20
* 開始   : 2026-06-11 08:20:00 (UTC)
* 終了   : 2026-06-11 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host05-009 active_connections の推移](charts/EVT-20260611-host05-009.svg)

# イベントID( EVT-20260611-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→19→22
* 開始   : 2026-06-11 09:30:00 (UTC)
* 終了   : 2026-06-11 09:30:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-010 active_connections の推移](charts/EVT-20260611-host05-010.svg)

# イベントID( EVT-20260612-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→13→16→19→…→16→19→12→15
* 開始   : 2026-06-12 05:20:00 (UTC)
* 終了   : 2026-06-12 05:25:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host05-003 active_connections の推移](charts/EVT-20260612-host05-003.svg)

# イベントID( EVT-20260612-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→15→18→13→14
* 開始   : 2026-06-12 05:25:00 (UTC)
* 終了   : 2026-06-12 06:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.44倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.875σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260612-host05-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260612-host05-004 active_connections の推移](charts/EVT-20260612-host05-004.svg)

# イベントID( EVT-20260612-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 23→21→19→20→20→21→21→21→23
* 開始   : 2026-06-12 08:40:00 (UTC)
* 終了   : 2026-06-12 09:25:00 (UTC)
* 現象   : 2026-06-12 09:25:00 (UTC)を境に水準が 15.05から14.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.301σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host05-007 active_connections の推移](charts/EVT-20260612-host05-007.svg)

# イベントID( EVT-20260612-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→21→26→22→22
* 開始   : 2026-06-12 11:15:00 (UTC)
* 終了   : 2026-06-12 11:15:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host05-008 active_connections の推移](charts/EVT-20260612-host05-008.svg)

# イベントID( EVT-20260612-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→13→…→13→10→12→14
* 開始   : 2026-06-12 18:45:00 (UTC)
* 終了   : 2026-06-12 18:55:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-010 active_connections の推移](charts/EVT-20260612-host05-010.svg)

# イベントID( EVT-20260613-host05-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→10→…→10→11→10→11
* 開始   : 2026-06-13 04:25:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.174, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host05-001 active_connections の推移](charts/EVT-20260613-host05-001.svg)

# イベントID( EVT-20260613-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→11→12→11→9
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:50:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.388, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.4 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host05-002 active_connections の推移](charts/EVT-20260613-host05-002.svg)

# イベントID( EVT-20260613-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→13→…→12→11→13→10
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.261σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host05-003 active_connections の推移](charts/EVT-20260613-host05-003.svg)

# イベントID( EVT-20260613-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→12→…→12→11→13→9
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.176, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host05-004 active_connections の推移](charts/EVT-20260613-host05-004.svg)

# イベントID( EVT-20260613-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→…→13→10→11→9
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.901, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host05-005 active_connections の推移](charts/EVT-20260613-host05-005.svg)

# イベントID( EVT-20260613-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→11→…→12→9→12→13
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.769, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host05-006 active_connections の推移](charts/EVT-20260613-host05-006.svg)

# イベントID( EVT-20260614-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→12→16→11→12
* 開始   : 2026-06-14 05:55:00 (UTC)
* 終了   : 2026-06-14 05:55:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host05-001 active_connections の推移](charts/EVT-20260614-host05-001.svg)

# イベントID( EVT-20260614-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→12→17→14→…→14→10→12→15
* 開始   : 2026-06-14 07:20:00 (UTC)
* 終了   : 2026-06-14 07:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260614-host05-002 active_connections の推移](charts/EVT-20260614-host05-002.svg)

# イベントID( EVT-20260614-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→18→12→13
* 開始   : 2026-06-14 07:20:00 (UTC)
* 終了   : 2026-06-14 07:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.421倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host05-003 active_connections の推移](charts/EVT-20260614-host05-003.svg)

# イベントID( EVT-20260614-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→7→10→10
* 開始   : 2026-06-14 19:05:00 (UTC)
* 終了   : 2026-06-14 19:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host05-005 active_connections の推移](charts/EVT-20260614-host05-005.svg)

# イベントID( EVT-20260614-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→8→5→9→10
* 開始   : 2026-06-14 22:00:00 (UTC)
* 終了   : 2026-06-14 22:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→16→…→13→14→13→12
* 開始   : 2026-06-15 02:00:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.71から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.812, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-003 active_connections の推移](charts/EVT-20260615-host05-003.svg)

# イベントID( EVT-20260615-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→17→16→15→…→12→15→14→11
* 開始   : 2026-06-15 02:45:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.73から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.883, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-005 active_connections の推移](charts/EVT-20260615-host05-005.svg)

# イベントID( EVT-20260616-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→20→16→18→20
* 開始   : 2026-06-16 15:15:00 (UTC)
* 終了   : 2026-06-16 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→15→10→13→14
* 開始   : 2026-06-16 18:05:00 (UTC)
* 終了   : 2026-06-16 18:05:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6218(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-006 active_connections の推移](charts/EVT-20260616-host05-006.svg)

# イベントID( EVT-20260617-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→8→9
* 開始   : 2026-06-17 21:15:00 (UTC)
* 終了   : 2026-06-17 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-007 active_connections の推移](charts/EVT-20260617-host05-007.svg)

# イベントID( EVT-20260618-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→18→…→24→18→20→21
* 開始   : 2026-06-18 14:00:00 (UTC)
* 終了   : 2026-06-18 14:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260618-host14-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host05-003 active_connections の推移](charts/EVT-20260618-host05-003.svg)

# イベントID( EVT-20260618-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→15→12
* 開始   : 2026-06-18 18:50:00 (UTC)
* 終了   : 2026-06-18 18:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host05-007 active_connections の推移](charts/EVT-20260618-host05-007.svg)

# イベントID( EVT-20260618-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→9→10
* 開始   : 2026-06-18 21:10:00 (UTC)
* 終了   : 2026-06-18 21:10:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-008 active_connections の推移](charts/EVT-20260618-host05-008.svg)

# イベントID( EVT-20260619-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→19→25→21→22
* 開始   : 2026-06-19 10:25:00 (UTC)
* 終了   : 2026-06-19 10:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→18→17→19→15→17→19→15→19
* 開始   : 2026-06-19 15:45:00 (UTC)
* 終了   : 2026-06-19 15:55:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host05-007 active_connections の推移](charts/EVT-20260619-host05-007.svg)

# イベントID( EVT-20260619-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→16→15→16→15→18
* 開始   : 2026-06-19 16:20:00 (UTC)
* 終了   : 2026-06-19 16:55:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.478σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260619-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host05-008 active_connections の推移](charts/EVT-20260619-host05-008.svg)

# イベントID( EVT-20260619-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→14→19→17
* 開始   : 2026-06-19 16:35:00 (UTC)
* 終了   : 2026-06-19 16:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host05-009 active_connections の推移](charts/EVT-20260619-host05-009.svg)

# イベントID( EVT-20260619-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→11→12→15→11→12→15→16
* 開始   : 2026-06-19 18:05:00 (UTC)
* 終了   : 2026-06-19 18:10:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host05-010 active_connections の推移](charts/EVT-20260619-host05-010.svg)

# イベントID( EVT-20260619-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→12→12
* 開始   : 2026-06-19 19:20:00 (UTC)
* 終了   : 2026-06-19 19:20:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host05-011 active_connections の推移](charts/EVT-20260619-host05-011.svg)

# イベントID( EVT-20260619-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→11→…→11→7→11→12
* 開始   : 2026-06-19 20:30:00 (UTC)
* 終了   : 2026-06-19 20:40:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260619-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-013 active_connections の推移](charts/EVT-20260619-host05-013.svg)

# イベントID( EVT-20260620-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→11→13→10→…→13→9→12→11
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 19:30:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.7, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260620-host05-002 active_connections の推移](charts/EVT-20260620-host05-002.svg)

# イベントID( EVT-20260620-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→12→11→12→…→10→11→12→11
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.972, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間
  - EVT-20260620-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260620-host05-003 active_connections の推移](charts/EVT-20260620-host05-003.svg)

# イベントID( EVT-20260620-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→11→10→12→…→11→12→11→12
* 開始   : 2026-06-20 04:50:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.709, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260620-host05-004 active_connections の推移](charts/EVT-20260620-host05-004.svg)

# イベントID( EVT-20260620-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→11→13→10→…→13→12→11→13
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:45:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.873, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260620-host05-005 active_connections の推移](charts/EVT-20260620-host05-005.svg)

# イベントID( EVT-20260620-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→11→12→13→10
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 20:30:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.885, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260620-host05-006 active_connections の推移](charts/EVT-20260620-host05-006.svg)

# イベントID( EVT-20260620-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→12→…→12→14→15→13
* 開始   : 2026-06-20 06:20:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.814, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260620-host05-007 active_connections の推移](charts/EVT-20260620-host05-007.svg)

# イベントID( EVT-20260621-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→9→4→7→9
* 開始   : 2026-06-21 01:20:00 (UTC)
* 終了   : 2026-06-21 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→12→13→15→13→15→13→12
* 開始   : 2026-06-21 05:30:00 (UTC)
* 終了   : 2026-06-21 05:40:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260621-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host05-003 active_connections の推移](charts/EVT-20260621-host05-003.svg)

# イベントID( EVT-20260621-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→13→10
* 開始   : 2026-06-21 06:10:00 (UTC)
* 終了   : 2026-06-21 06:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host05-004 active_connections の推移](charts/EVT-20260621-host05-004.svg)

# イベントID( EVT-20260621-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→15→20→15→15
* 開始   : 2026-06-21 11:45:00 (UTC)
* 終了   : 2026-06-21 11:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host05-005 active_connections の推移](charts/EVT-20260621-host05-005.svg)

# イベントID( EVT-20260622-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→8→4→6→9
* 開始   : 2026-06-22 00:15:00 (UTC)
* 終了   : 2026-06-22 00:15:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260622-host05-001 active_connections の推移](charts/EVT-20260622-host05-001.svg)

# イベントID( EVT-20260623-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→14→15
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 06:30:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host05-004 active_connections の推移](charts/EVT-20260623-host05-004.svg)

# イベントID( EVT-20260624-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→16→13→15→16→13→15→14
* 開始   : 2026-06-24 04:40:00 (UTC)
* 終了   : 2026-06-24 04:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-002 active_connections の推移](charts/EVT-20260624-host05-002.svg)

# イベントID( EVT-20260624-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→17→15→14→16→14→15
* 開始   : 2026-06-24 17:10:00 (UTC)
* 終了   : 2026-06-24 19:35:00 (UTC)
* 現象   : 2026-06-24 19:35:00 (UTC)を境に水準が 14.93から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.781, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host05-004 active_connections の推移](charts/EVT-20260624-host05-004.svg)

# イベントID( EVT-20260624-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→17→12→17→17
* 開始   : 2026-06-24 17:40:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-006 active_connections の推移](charts/EVT-20260624-host05-006.svg)

# イベントID( EVT-20260625-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→12→16→15→12→16→15
* 開始   : 2026-06-25 04:55:00 (UTC)
* 終了   : 2026-06-25 05:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260625-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host05-003 active_connections の推移](charts/EVT-20260625-host05-003.svg)

# イベントID( EVT-20260625-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→21→22→21→23→22→22→20→21
* 開始   : 2026-06-25 13:15:00 (UTC)
* 終了   : 2026-06-25 16:10:00 (UTC)
* 現象   : 2026-06-25 16:10:00 (UTC)を境に水準が 14.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.053σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→20→16→19→21
* 開始   : 2026-06-25 15:45:00 (UTC)
* 終了   : 2026-06-25 16:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host05-009 active_connections の推移](charts/EVT-20260625-host05-009.svg)

# イベントID( EVT-20260625-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→13→10→12→16
* 開始   : 2026-06-25 19:10:00 (UTC)
* 終了   : 2026-06-25 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-012 active_connections の推移](charts/EVT-20260625-host05-012.svg)

# イベントID( EVT-20260626-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→13→17→13→17→14→15
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 25 分
  - EVT-20260626-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260626-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-002 active_connections の推移](charts/EVT-20260626-host05-002.svg)

# イベントID( EVT-20260626-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→14→20→15→17
* 開始   : 2026-06-26 06:30:00 (UTC)
* 終了   : 2026-06-26 06:30:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.348倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-003 active_connections の推移](charts/EVT-20260626-host05-003.svg)

# イベントID( EVT-20260626-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→19→23→19→21
* 開始   : 2026-06-26 08:45:00 (UTC)
* 終了   : 2026-06-26 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-004 active_connections の推移](charts/EVT-20260626-host05-004.svg)

# イベントID( EVT-20260626-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→8→8
* 開始   : 2026-06-26 22:10:00 (UTC)
* 終了   : 2026-06-26 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→10→…→12→14→13→14
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.894, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.5 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260627-host05-003 active_connections の推移](charts/EVT-20260627-host05-003.svg)

# イベントID( EVT-20260627-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→…→12→11→12→11
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.005, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host05-004 active_connections の推移](charts/EVT-20260627-host05-004.svg)

# イベントID( EVT-20260627-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→13→12→13→…→11→10→14→10
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.71, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host05-005 active_connections の推移](charts/EVT-20260627-host05-005.svg)

# イベントID( EVT-20260627-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→12→13→9→…→10→14→11→10
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.231σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.726, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host05-006 active_connections の推移](charts/EVT-20260627-host05-006.svg)

# イベントID( EVT-20260627-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→13→…→12→10→12→15
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:40:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.609, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260627-host05-007 active_connections の推移](charts/EVT-20260627-host05-007.svg)

# イベントID( EVT-20260627-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→11→…→12→13→11→12
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.799, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.3 時間

![EVT-20260627-host05-008 active_connections の推移](charts/EVT-20260627-host05-008.svg)

# イベントID( EVT-20260628-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→8→7→9→11→9→14
* 開始   : 2026-06-28 00:40:00 (UTC)
* 終了   : 2026-06-28 01:20:00 (UTC)
* 現象   : 2026-06-28 01:20:00 (UTC)を境に水準が 11.72から11.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=15.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host05-001 active_connections の推移](charts/EVT-20260628-host05-001.svg)

# イベントID( EVT-20260628-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→12
* 開始   : 2026-06-28 06:05:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host05-004 active_connections の推移](charts/EVT-20260628-host05-004.svg)

# イベントID( EVT-20260628-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→6→4→8→6
* 開始   : 2026-06-28 23:05:00 (UTC)
* 終了   : 2026-06-28 23:05:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host05-007 active_connections の推移](charts/EVT-20260628-host05-007.svg)

# イベントID( EVT-20260629-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→13→…→13→14→13→11
* 開始   : 2026-06-29 03:55:00 (UTC)
* 終了   : 2026-06-29 20:40:00 (UTC)
* 現象   : 2026-06-29 20:40:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.371, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-007 active_connections の推移](charts/EVT-20260629-host05-007.svg)

# イベントID( EVT-20260630-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 6→7→12→9→8
* 開始   : 2026-06-30 00:00:00 (UTC)
* 終了   : 2026-06-30 00:00:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host05-001 active_connections の推移](charts/EVT-20260630-host05-001.svg)

# イベントID( EVT-20260630-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 7→7→4→6→9
* 開始   : 2026-06-30 01:20:00 (UTC)
* 終了   : 2026-06-30 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-003 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host05-002 active_connections の推移](charts/EVT-20260630-host05-002.svg)

# イベントID( EVT-20260630-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→11→12
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 03:25:00 (UTC)
* 現象   : 2026-06-30 03:25:00 (UTC)を境に水準が 14.89から15.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.282σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host05-003 active_connections の推移](charts/EVT-20260630-host05-003.svg)

# イベントID( EVT-20260630-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→15→21→17→19
* 開始   : 2026-06-30 07:25:00 (UTC)
* 終了   : 2026-06-30 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.65σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host05-006 active_connections の推移](charts/EVT-20260630-host05-006.svg)

# イベントID( EVT-20260630-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→19→23→20→21
* 開始   : 2026-06-30 08:35:00 (UTC)
* 終了   : 2026-06-30 08:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-009 active_connections の推移](charts/EVT-20260630-host05-009.svg)

# イベントID( EVT-20260630-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→21→25→21→23
* 開始   : 2026-06-30 11:05:00 (UTC)
* 終了   : 2026-06-30 11:05:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-011 active_connections の推移](charts/EVT-20260630-host05-011.svg)

# イベントID( EVT-20260630-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→17→13→15→18
* 開始   : 2026-06-30 17:25:00 (UTC)
* 終了   : 2026-06-30 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host05-015 active_connections の推移](charts/EVT-20260630-host05-015.svg)

# イベントID( EVT-20260630-host05-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→13→9→11→…→11→10→14→12
* 開始   : 2026-06-30 19:25:00 (UTC)
* 終了   : 2026-06-30 19:35:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host05-017 active_connections の推移](charts/EVT-20260630-host05-017.svg)

# イベントID( EVT-20260601-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→12→10→7→11→12→10
* 開始   : 2026-06-01 02:25:00 (UTC)
* 終了   : 2026-06-01 02:30:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→11→13→12→11→13→12→9
* 開始   : 2026-06-01 03:35:00 (UTC)
* 終了   : 2026-06-01 03:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→8→15→…→15→11→14→12
* 開始   : 2026-06-01 03:55:00 (UTC)
* 終了   : 2026-06-01 04:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→12→16→14→…→14→17→15→16
* 開始   : 2026-06-01 05:35:00 (UTC)
* 終了   : 2026-06-01 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→17→13→17→13→17→16→15
* 開始   : 2026-06-01 05:50:00 (UTC)
* 終了   : 2026-06-01 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→22→24→17→21→22→24→17→21
* 開始   : 2026-06-01 09:25:00 (UTC)
* 終了   : 2026-06-01 09:30:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.215倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.994σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→12→…→12→9→11→13
* 開始   : 2026-06-01 19:25:00 (UTC)
* 終了   : 2026-06-01 19:35:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→12→9→10→12→9→10
* 開始   : 2026-06-01 19:50:00 (UTC)
* 終了   : 2026-06-01 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.6923(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.781σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260601-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→20→22→20→20→22
* 開始   : 2026-06-02 08:20:00 (UTC)
* 終了   : 2026-06-02 08:45:00 (UTC)
* 現象   : 2026-06-02 08:45:00 (UTC)を境に水準が 15.07から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 23→21→22→22→22→22→23→21→23
* 開始   : 2026-06-02 11:25:00 (UTC)
* 終了   : 2026-06-02 12:50:00 (UTC)
* 現象   : 2026-06-02 12:50:00 (UTC)を境に水準が 15.04から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→20→17→20→17→19→20
* 開始   : 2026-06-02 15:35:00 (UTC)
* 終了   : 2026-06-02 15:45:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.579σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→14→13→15→17→14→13→15
* 開始   : 2026-06-02 17:25:00 (UTC)
* 終了   : 2026-06-02 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→12→13→11→12
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→11→9→10→11→9→11
* 開始   : 2026-06-02 19:50:00 (UTC)
* 終了   : 2026-06-02 20:00:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→12→9→10→12→9→10
* 開始   : 2026-06-02 20:20:00 (UTC)
* 終了   : 2026-06-02 20:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→12→14→13→13→13→12→11→15
* 開始   : 2026-06-03 03:50:00 (UTC)
* 終了   : 2026-06-03 04:35:00 (UTC)
* 現象   : 2026-06-03 04:35:00 (UTC)を境に水準が 14.99から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.578, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→19→22→20→…→20→23→19→18
* 開始   : 2026-06-03 08:55:00 (UTC)
* 終了   : 2026-06-03 09:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.524σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→19→24→21→…→21→18→22→23
* 開始   : 2026-06-03 10:10:00 (UTC)
* 終了   : 2026-06-03 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→15→14→14→14→13→15
* 開始   : 2026-06-03 18:20:00 (UTC)
* 終了   : 2026-06-03 19:00:00 (UTC)
* 現象   : 2026-06-03 19:00:00 (UTC)を境に水準が 15.01から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→10→13→11→10→13→12
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→8→9→8→9→8→9
* 開始   : 2026-06-03 21:00:00 (UTC)
* 終了   : 2026-06-03 21:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→8→9→8→10
* 開始   : 2026-06-03 23:15:00 (UTC)
* 終了   : 2026-06-03 23:35:00 (UTC)
* 現象   : 2026-06-03 23:35:00 (UTC)を境に水準が 15.01から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→10→10→9→10→10→10→11
* 開始   : 2026-06-04 02:05:00 (UTC)
* 終了   : 2026-06-04 02:40:00 (UTC)
* 現象   : 2026-06-04 02:40:00 (UTC)を境に水準が 15.01から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→16→14→18→16→15
* 開始   : 2026-06-04 06:05:00 (UTC)
* 終了   : 2026-06-04 06:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260604-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→19→22→19→22→19→22→19
* 開始   : 2026-06-04 08:45:00 (UTC)
* 終了   : 2026-06-04 08:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 24→23→22→22→24→23→23→23→23
* 開始   : 2026-06-04 11:45:00 (UTC)
* 終了   : 2026-06-04 13:00:00 (UTC)
* 現象   : 2026-06-04 13:00:00 (UTC)を境に水準が 15.16から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.11σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→13→14→12→13
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260604-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→9→11→12→9→11→12
* 開始   : 2026-06-04 20:20:00 (UTC)
* 終了   : 2026-06-04 20:25:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→9→11→8→12→9→12
* 開始   : 2026-06-05 01:15:00 (UTC)
* 終了   : 2026-06-05 01:45:00 (UTC)
* 現象   : 2026-06-05 01:45:00 (UTC)を境に水準が 15.07から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.11σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→12→13
* 開始   : 2026-06-05 03:45:00 (UTC)
* 終了   : 2026-06-05 04:05:00 (UTC)
* 現象   : 2026-06-05 04:05:00 (UTC)を境に水準が 15.04から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 23→20→18→20→…→20→17→19→20
* 開始   : 2026-06-05 15:10:00 (UTC)
* 終了   : 2026-06-05 15:20:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→13→8→9→8→9→8→10
* 開始   : 2026-06-05 20:50:00 (UTC)
* 終了   : 2026-06-05 21:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-091 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-090 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 8→9→10→7→10→10
* 開始   : 2026-06-07 00:20:00 (UTC)
* 終了   : 2026-06-07 00:45:00 (UTC)
* 現象   : 2026-06-07 00:45:00 (UTC)を境に水準が 11.71から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→14→10→14→16→10→14→16→14
* 開始   : 2026-06-07 07:35:00 (UTC)
* 終了   : 2026-06-07 07:45:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→15→15→14→14→17
* 開始   : 2026-06-07 08:10:00 (UTC)
* 終了   : 2026-06-07 08:35:00 (UTC)
* 現象   : 2026-06-07 08:35:00 (UTC)を境に水準が 11.84から12.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→16→18→16→18→14→15
* 開始   : 2026-06-07 09:30:00 (UTC)
* 終了   : 2026-06-07 09:40:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.696σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→17→16→15→17→17→17
* 開始   : 2026-06-07 11:30:00 (UTC)
* 終了   : 2026-06-07 12:05:00 (UTC)
* 現象   : 2026-06-07 12:05:00 (UTC)を境に水準が 11.84から13.53へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→16→12→18→15→16→12→18→15
* 開始   : 2026-06-07 12:20:00 (UTC)
* 終了   : 2026-06-07 12:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→16→16→15→15→16→14→15→16
* 開始   : 2026-06-07 15:55:00 (UTC)
* 終了   : 2026-06-07 17:55:00 (UTC)
* 現象   : 2026-06-07 17:55:00 (UTC)を境に水準が 11.88から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→15→8→…→15→8→11→10
* 開始   : 2026-06-07 18:10:00 (UTC)
* 終了   : 2026-06-07 18:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→11→10→12
* 開始   : 2026-06-07 21:05:00 (UTC)
* 終了   : 2026-06-07 21:20:00 (UTC)
* 現象   : 2026-06-07 21:20:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.506, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→11→10→11
* 開始   : 2026-06-08 01:55:00 (UTC)
* 終了   : 2026-06-08 02:25:00 (UTC)
* 現象   : 2026-06-08 02:25:00 (UTC)を境に水準が 11.75から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→10→10→12→8→9→9→13→12
* 開始   : 2026-06-08 20:50:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.551σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→12→…→16→18→16→18
* 開始   : 2026-06-09 06:15:00 (UTC)
* 終了   : 2026-06-09 06:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.524σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→18→21→20→18→21→20
* 開始   : 2026-06-09 08:15:00 (UTC)
* 終了   : 2026-06-09 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→13→…→14→13→18→15
* 開始   : 2026-06-09 17:20:00 (UTC)
* 終了   : 2026-06-09 17:25:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→13→13→11→15→11→13
* 開始   : 2026-06-09 19:05:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 2026-06-09 19:55:00 (UTC)を境に水準が 15から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.261σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→10→…→10→11→10→13
* 開始   : 2026-06-09 19:20:00 (UTC)
* 終了   : 2026-06-09 19:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→8→10→11→8→10→11
* 開始   : 2026-06-09 20:35:00 (UTC)
* 終了   : 2026-06-09 20:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.29σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→12→8→9→8→9→8→11→8
* 開始   : 2026-06-09 20:55:00 (UTC)
* 終了   : 2026-06-09 21:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→8→6→12→9→8→6→12→9
* 開始   : 2026-06-09 22:25:00 (UTC)
* 終了   : 2026-06-09 22:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260609-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→21→17→21→17→16
* 開始   : 2026-06-10 08:00:00 (UTC)
* 終了   : 2026-06-10 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260610-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→19→22→16→19→22→16→19→20
* 開始   : 2026-06-10 08:45:00 (UTC)
* 終了   : 2026-06-10 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→23→24→22→22→22→20→23→23
* 開始   : 2026-06-10 12:00:00 (UTC)
* 終了   : 2026-06-10 12:55:00 (UTC)
* 現象   : 2026-06-10 12:55:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→11→8→11→8→11→7→9
* 開始   : 2026-06-11 01:30:00 (UTC)
* 終了   : 2026-06-11 01:40:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.466σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→16→14→16→14→16→13
* 開始   : 2026-06-11 05:05:00 (UTC)
* 終了   : 2026-06-11 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.872σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→20→17→21→…→17→21→20→19
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 08:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260611-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→19→21→19→21→19→21→19→21
* 開始   : 2026-06-11 08:00:00 (UTC)
* 終了   : 2026-06-11 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→22→21→20→19→24→21→22→22
* 開始   : 2026-06-11 09:40:00 (UTC)
* 終了   : 2026-06-11 10:40:00 (UTC)
* 現象   : 2026-06-11 10:40:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→19→20→19→19
* 開始   : 2026-06-11 16:10:00 (UTC)
* 終了   : 2026-06-11 16:30:00 (UTC)
* 現象   : 2026-06-11 16:30:00 (UTC)を境に水準が 15.04から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→11→9→8→11
* 開始   : 2026-06-11 20:30:00 (UTC)
* 終了   : 2026-06-11 20:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260611-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→15→15→13→16→16
* 開始   : 2026-06-12 04:45:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 2026-06-12 05:10:00 (UTC)を境に水準が 15.01から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→13→15→16→…→15→16→14→15
* 開始   : 2026-06-12 05:05:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→15→…→15→17→14→15
* 開始   : 2026-06-12 05:30:00 (UTC)
* 終了   : 2026-06-12 05:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→12→18→16→12→18→16→14
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 06:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.754σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→17→16→16→13→17
* 開始   : 2026-06-12 18:00:00 (UTC)
* 終了   : 2026-06-12 18:45:00 (UTC)
* 現象   : 2026-06-12 18:45:00 (UTC)を境に水準が 14.94から12.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→11→9→8→11→9→8→11
* 開始   : 2026-06-12 20:30:00 (UTC)
* 終了   : 2026-06-12 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.056σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→8→7→12→8→7→12→11
* 開始   : 2026-06-12 21:05:00 (UTC)
* 終了   : 2026-06-12 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→8→…→8→6→9→7
* 開始   : 2026-06-13 21:35:00 (UTC)
* 終了   : 2026-06-13 21:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260613-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 6→9→11→5→…→11→5→8→9
* 開始   : 2026-06-13 23:45:00 (UTC)
* 終了   : 2026-06-13 23:50:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→17→17→20→17
* 開始   : 2026-06-14 13:50:00 (UTC)
* 終了   : 2026-06-14 14:10:00 (UTC)
* 現象   : 2026-06-14 14:10:00 (UTC)を境に水準が 11.94から14.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→9→11→8→9→11→8→9
* 開始   : 2026-06-14 23:05:00 (UTC)
* 終了   : 2026-06-14 23:10:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 7→10→9→10→9→10→10
* 開始   : 2026-06-15 23:50:00 (UTC)
* 終了   : 2026-06-16 00:20:00 (UTC)
* 現象   : 2026-06-16 00:20:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→11→14→11→13→14→11→13→12
* 開始   : 2026-06-16 04:00:00 (UTC)
* 終了   : 2026-06-16 04:10:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.436倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→20→16→20→16→18
* 開始   : 2026-06-16 07:40:00 (UTC)
* 終了   : 2026-06-16 07:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→24→19→24→19→24→20→21
* 開始   : 2026-06-16 10:05:00 (UTC)
* 終了   : 2026-06-16 10:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.215倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.955σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→17→19→17→19
* 開始   : 2026-06-16 15:45:00 (UTC)
* 終了   : 2026-06-16 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→9→7→11→7→11→7→9→8
* 開始   : 2026-06-16 21:20:00 (UTC)
* 終了   : 2026-06-16 21:30:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→6→8→9→6→8
* 開始   : 2026-06-16 21:50:00 (UTC)
* 終了   : 2026-06-16 21:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260616-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→9→10→8→10→11→12
* 開始   : 2026-06-17 01:50:00 (UTC)
* 終了   : 2026-06-17 02:45:00 (UTC)
* 現象   : 2026-06-17 02:45:00 (UTC)を境に水準が 14.92から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→11→…→11→14→12→13
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:20:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 22→20→24→21→20→24→21→24
* 開始   : 2026-06-17 11:10:00 (UTC)
* 終了   : 2026-06-17 11:15:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→11→13→11→13→11→14
* 開始   : 2026-06-17 18:55:00 (UTC)
* 終了   : 2026-06-17 19:05:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→11→…→11→10→12→10
* 開始   : 2026-06-17 19:45:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→12→10
* 開始   : 2026-06-17 20:45:00 (UTC)
* 終了   : 2026-06-17 21:55:00 (UTC)
* 現象   : 2026-06-17 21:55:00 (UTC)を境に水準が 15から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→9→9→8→8→9→8→8→10
* 開始   : 2026-06-17 23:45:00 (UTC)
* 終了   : 2026-06-18 00:40:00 (UTC)
* 現象   : 2026-06-18 00:40:00 (UTC)を境に水準が 14.84から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→16→17→17
* 開始   : 2026-06-18 05:40:00 (UTC)
* 終了   : 2026-06-18 06:00:00 (UTC)
* 現象   : 2026-06-18 06:00:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→18→21→20→22→21→21→21→23
* 開始   : 2026-06-18 08:10:00 (UTC)
* 終了   : 2026-06-18 09:55:00 (UTC)
* 現象   : 2026-06-18 09:55:00 (UTC)を境に水準が 15.14から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→21→18→20→21→18→20→19
* 開始   : 2026-06-18 15:10:00 (UTC)
* 終了   : 2026-06-18 15:15:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260618-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→20→18→19→20→19→19→18→19
* 開始   : 2026-06-18 15:35:00 (UTC)
* 終了   : 2026-06-18 16:15:00 (UTC)
* 現象   : 2026-06-18 16:15:00 (UTC)を境に水準が 14.89から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→19→16→18→16→18→16→19→18
* 開始   : 2026-06-18 16:05:00 (UTC)
* 終了   : 2026-06-18 16:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→12→10→13→12→10→13→9→10
* 開始   : 2026-06-19 02:25:00 (UTC)
* 終了   : 2026-06-19 02:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→13→13→13→14
* 開始   : 2026-06-19 04:15:00 (UTC)
* 終了   : 2026-06-19 04:35:00 (UTC)
* 現象   : 2026-06-19 04:35:00 (UTC)を境に水準が 14.82から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→14→17→15→14→17→15
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→18→…→18→21→20→18
* 開始   : 2026-06-19 07:50:00 (UTC)
* 終了   : 2026-06-19 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 24→23→23
* 開始   : 2026-06-19 13:45:00 (UTC)
* 終了   : 2026-06-19 14:00:00 (UTC)
* 現象   : 2026-06-19 14:00:00 (UTC)を境に水準が 14.93から12.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→9→…→11→9→10→12
* 開始   : 2026-06-19 19:50:00 (UTC)
* 終了   : 2026-06-19 20:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→10→6→10→…→10→6→12→10
* 開始   : 2026-06-19 21:45:00 (UTC)
* 終了   : 2026-06-19 22:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→7→11→7→11→7→6
* 開始   : 2026-06-20 02:00:00 (UTC)
* 終了   : 2026-06-20 02:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→11→…→11→7→12→9
* 開始   : 2026-06-20 21:00:00 (UTC)
* 終了   : 2026-06-20 21:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.819σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→9→10→9
* 開始   : 2026-06-20 23:30:00 (UTC)
* 終了   : 2026-06-20 23:45:00 (UTC)
* 現象   : 2026-06-20 23:45:00 (UTC)を境に水準が 11.78から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.506, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→9→10→8→10→11→12
* 開始   : 2026-06-21 01:40:00 (UTC)
* 終了   : 2026-06-21 02:10:00 (UTC)
* 現象   : 2026-06-21 02:10:00 (UTC)を境に水準が 11.81から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→16→16→16→14→15→16→14→17
* 開始   : 2026-06-21 14:15:00 (UTC)
* 終了   : 2026-06-21 15:05:00 (UTC)
* 現象   : 2026-06-21 15:05:00 (UTC)を境に水準が 11.8から14.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→10→14→13→…→12→9→10→13
* 開始   : 2026-06-21 17:55:00 (UTC)
* 終了   : 2026-06-21 18:20:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260621-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260621-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260621-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260621-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→10→9→8
* 開始   : 2026-06-22 01:20:00 (UTC)
* 終了   : 2026-06-22 01:35:00 (UTC)
* 現象   : 2026-06-22 01:35:00 (UTC)を境に水準が 11.83から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→9→6→10→9→6→10→8
* 開始   : 2026-06-22 22:10:00 (UTC)
* 終了   : 2026-06-22 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→11→9→9→12→11
* 開始   : 2026-06-23 01:55:00 (UTC)
* 終了   : 2026-06-23 02:20:00 (UTC)
* 現象   : 2026-06-23 02:20:00 (UTC)を境に水準が 15.03から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→13→12→12→12→13→13→12
* 開始   : 2026-06-23 03:55:00 (UTC)
* 終了   : 2026-06-23 04:30:00 (UTC)
* 現象   : 2026-06-23 04:30:00 (UTC)を境に水準が 14.86から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→14→16→13→16→13→16→14→15
* 開始   : 2026-06-23 05:25:00 (UTC)
* 終了   : 2026-06-23 05:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→17→21→20→21→20→21→18→21
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.407σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260623-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→23→23→21→22→22→24→22→24
* 開始   : 2026-06-23 10:10:00 (UTC)
* 終了   : 2026-06-23 11:25:00 (UTC)
* 現象   : 2026-06-23 11:25:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 18→17→16→18→16→17→15→14→15
* 開始   : 2026-06-23 17:15:00 (UTC)
* 終了   : 2026-06-23 18:10:00 (UTC)
* 現象   : 2026-06-23 18:10:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→13→…→13→10→14→13
* 開始   : 2026-06-23 19:10:00 (UTC)
* 終了   : 2026-06-23 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→9→8→9
* 開始   : 2026-06-23 21:15:00 (UTC)
* 終了   : 2026-06-23 21:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-056 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→8→6→8→6→9→8
* 開始   : 2026-06-23 22:55:00 (UTC)
* 終了   : 2026-06-23 23:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→14→…→14→16→11→13
* 開始   : 2026-06-24 04:30:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.696σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→18→…→17→18→17→14
* 開始   : 2026-06-24 06:10:00 (UTC)
* 終了   : 2026-06-24 06:15:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→19→13→14→15→19→13→14→17
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→14→9→10→14→9→12
* 開始   : 2026-06-24 19:45:00 (UTC)
* 終了   : 2026-06-24 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→6→10→9→6→10→7
* 開始   : 2026-06-24 22:55:00 (UTC)
* 終了   : 2026-06-24 23:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→10→13→7→…→13→7→12→13
* 開始   : 2026-06-25 03:20:00 (UTC)
* 終了   : 2026-06-25 03:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→13→14→15→15
* 開始   : 2026-06-25 04:35:00 (UTC)
* 終了   : 2026-06-25 04:55:00 (UTC)
* 現象   : 2026-06-25 04:55:00 (UTC)を境に水準が 14.85から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→10→16→13→16→13→16→15→13
* 開始   : 2026-06-25 05:15:00 (UTC)
* 終了   : 2026-06-25 05:25:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→19→…→18→19→18→17
* 開始   : 2026-06-25 06:30:00 (UTC)
* 終了   : 2026-06-25 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→15→18→15→16
* 開始   : 2026-06-25 06:40:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→22→17→18→22→17→18→21
* 開始   : 2026-06-25 15:15:00 (UTC)
* 終了   : 2026-06-25 15:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→16→18→19→19→18→17→20→19
* 開始   : 2026-06-25 16:05:00 (UTC)
* 終了   : 2026-06-25 16:45:00 (UTC)
* 現象   : 2026-06-25 16:45:00 (UTC)を境に水準が 14.89から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.163, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→15→…→15→13→17→15
* 開始   : 2026-06-25 17:45:00 (UTC)
* 終了   : 2026-06-25 17:55:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→8→7→10→8→7→10→11
* 開始   : 2026-06-25 20:55:00 (UTC)
* 終了   : 2026-06-25 21:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260625-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→7→10→…→10→7→9→10
* 開始   : 2026-06-25 21:35:00 (UTC)
* 終了   : 2026-06-25 21:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 7→9→9→8→8→10→9→10→12
* 開始   : 2026-06-25 23:35:00 (UTC)
* 終了   : 2026-06-26 00:40:00 (UTC)
* 現象   : 2026-06-26 00:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→9→9→11→8→10→11→9→12
* 開始   : 2026-06-26 01:25:00 (UTC)
* 終了   : 2026-06-26 03:15:00 (UTC)
* 現象   : 2026-06-26 03:15:00 (UTC)を境に水準が 14.87から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.907, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 22→22→24→23→22→22→20→23→24
* 開始   : 2026-06-26 11:25:00 (UTC)
* 終了   : 2026-06-26 12:40:00 (UTC)
* 現象   : 2026-06-26 12:40:00 (UTC)を境に水準が 15.05から13.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.033, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 25→23→24→23
* 開始   : 2026-06-26 11:50:00 (UTC)
* 終了   : 2026-06-26 12:05:00 (UTC)
* 現象   : 2026-06-26 12:05:00 (UTC)を境に水準が 15.06から13.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→18→19→18
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 17:05:00 (UTC)
* 現象   : 2026-06-26 17:05:00 (UTC)を境に水準が 15.09から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→19→14→18→19→14→18→16
* 開始   : 2026-06-26 17:00:00 (UTC)
* 終了   : 2026-06-26 17:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→15→…→15→11→15→13
* 開始   : 2026-06-26 18:35:00 (UTC)
* 終了   : 2026-06-26 18:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→11→…→11→14→8→11
* 開始   : 2026-06-26 20:55:00 (UTC)
* 終了   : 2026-06-26 21:05:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→6→5→11→…→5→11→9→7
* 開始   : 2026-06-27 01:10:00 (UTC)
* 終了   : 2026-06-27 01:15:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260627-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 7→11→9→7→11→9→8
* 開始   : 2026-06-27 01:50:00 (UTC)
* 終了   : 2026-06-27 01:55:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→8→10→8→7→11→10→11→9
* 開始   : 2026-06-27 23:20:00 (UTC)
* 終了   : 2026-06-28 01:15:00 (UTC)
* 現象   : 2026-06-28 01:15:00 (UTC)を境に水準が 11.87から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→11→…→5→11→7→9
* 開始   : 2026-06-28 01:55:00 (UTC)
* 終了   : 2026-06-28 02:00:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.114σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→14→12→14→…→14→8→11→12
* 開始   : 2026-06-28 05:05:00 (UTC)
* 終了   : 2026-06-28 05:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.583σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→17→16
* 開始   : 2026-06-28 15:35:00 (UTC)
* 終了   : 2026-06-28 15:55:00 (UTC)
* 現象   : 2026-06-28 15:55:00 (UTC)を境に水準が 11.78から14.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.632, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→15→11→14→11→14→11→14
* 開始   : 2026-06-28 16:20:00 (UTC)
* 終了   : 2026-06-28 16:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260628-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→8→4→9→…→9→5→6→9
* 開始   : 2026-06-29 00:30:00 (UTC)
* 終了   : 2026-06-29 00:40:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.4898(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.898σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260629-lsfhost01-002 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260629-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260629-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→11→10→13→11→10
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 03:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→14→16→9→…→16→9→15→13
* 開始   : 2026-06-30 05:00:00 (UTC)
* 終了   : 2026-06-30 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→16→19→20→…→16→20→16→17
* 開始   : 2026-06-30 07:40:00 (UTC)
* 終了   : 2026-06-30 07:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.055σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→20→22→20→22→20→22→20
* 開始   : 2026-06-30 08:25:00 (UTC)
* 終了   : 2026-06-30 08:35:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260630-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 23→22→25→19→…→25→19→21→20
* 開始   : 2026-06-30 10:45:00 (UTC)
* 終了   : 2026-06-30 10:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→25→19→20→22→25→19→20
* 開始   : 2026-06-30 11:50:00 (UTC)
* 終了   : 2026-06-30 11:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→18→19→19→16→19→18→17→20
* 開始   : 2026-06-30 16:05:00 (UTC)
* 終了   : 2026-06-30 16:55:00 (UTC)
* 現象   : 2026-06-30 16:55:00 (UTC)を境に水準が 15.02から11.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→19→16→19→16
* 開始   : 2026-06-30 16:20:00 (UTC)
* 終了   : 2026-06-30 16:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→10→13→10→13→10→13→12
* 開始   : 2026-06-30 19:20:00 (UTC)
* 終了   : 2026-06-30 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-017 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→11→12→10→9→12→11→10→11
* 開始   : 2026-06-30 20:40:00 (UTC)
* 終了   : 2026-06-30 21:40:00 (UTC)
* 現象   : 2026-06-30 21:40:00 (UTC)を境に水準が 14.88から8.5へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.637σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host05-018 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
