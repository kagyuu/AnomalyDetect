# host02 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host02 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 352 (SEVERE: 41, FATAL: 138, WARN: 173, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 36 | 113 | 134 | 283 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-A5, ALG-B4 |
| ou | 4 | 25 | 31 | 60 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |
| eu | 1 | 0 | 0 | 1 | ALG-A1, ALG-A2, ALG-A4, ALG-B2, ALG-B4 |
| mu | 0 | 0 | 7 | 7 | ALG-A4, ALG-B4 |
| fgct_delta | 0 | 0 | 1 | 1 | ALG-B2 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260601-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B2 Mann-Kendall 傾向検定, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app02, host=host02
* 値     : 2404→3157→5069→4300→3537→4377→5083→3913→3483
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 2026-06-30 23:55:00 (UTC)を境に水準が 3276から3278へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.055 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-390, 限界=392.2)
             ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=69162, p=7.492e-27, Sen勾配=47.9/日)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=1194, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260601-host02-001 eu の推移](charts/EVT-20260601-host02-001.svg)

# イベントID( EVT-20260603-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→11→41→35→…→13→14→13→14
* 開始   : 2026-06-03 02:55:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 2026-06-03 04:45:00 (UTC)を境に水準が 14.97から16.21へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.56σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 21.58 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.296, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=31.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-001 active_connections の推移](charts/EVT-20260603-host02-001.svg)

# イベントID( EVT-20260607-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→13→13→11→13→14→15→14
* 開始   : 2026-06-07 05:55:00 (UTC)
* 終了   : 2026-06-07 06:55:00 (UTC)
* 現象   : 2026-06-07 06:55:00 (UTC)を境に水準が 11.85から12.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-003 active_connections の推移](charts/EVT-20260607-host02-003.svg)

# イベントID( EVT-20260608-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→19→…→14→13→14→12
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.97から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.809σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.903, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-002 active_connections の推移](charts/EVT-20260608-host02-002.svg)

# イベントID( EVT-20260608-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→13→15→13→…→14→12→11→13
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 19:30:00 (UTC)
* 現象   : 2026-06-08 19:30:00 (UTC)を境に水準が 11.84から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.689, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.333, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-003 active_connections の推移](charts/EVT-20260608-host02-003.svg)

# イベントID( EVT-20260608-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.095e+04→1.1e+04→1.085e+04→1.118e+04→…→1.102e+04→1.112e+04→1.028e+04→1.063e+04
* 開始   : 2026-06-08 02:25:00 (UTC)
* 終了   : 2026-06-08 19:15:00 (UTC)
* 現象   : 2026-06-08 19:15:00 (UTC)を境に水準が 9777から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.513σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=673.8, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-004 ou の推移](charts/EVT-20260608-host02-004.svg)

# イベントID( EVT-20260608-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→14→…→14→16→13→12
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.72から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.903σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.924, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-006 active_connections の推移](charts/EVT-20260608-host02-006.svg)

# イベントID( EVT-20260608-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→17→19→17→…→12→13→11→12
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 2026-06-08 21:20:00 (UTC)を境に水準が 11.75から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-009 active_connections の推移](charts/EVT-20260608-host02-009.svg)

# イベントID( EVT-20260610-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→44→38→49→…→13→12→14→15
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 04:45:00 (UTC)
* 現象   : 2026-06-10 04:45:00 (UTC)を境に水準が 14.99から16.27へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 13.62σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 22.93 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=44)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.648, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=36.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-002 active_connections の推移](charts/EVT-20260610-host02-002.svg)

# イベントID( EVT-20260610-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→18→17→18→18→16→17
* 開始   : 2026-06-10 17:05:00 (UTC)
* 終了   : 2026-06-10 17:50:00 (UTC)
* 現象   : 2026-06-10 17:50:00 (UTC)を境に水準が 15.07から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.985σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.181, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-006 active_connections の推移](charts/EVT-20260610-host02-006.svg)

# イベントID( EVT-20260611-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→18→15→16→16→16
* 開始   : 2026-06-11 17:40:00 (UTC)
* 終了   : 2026-06-11 18:30:00 (UTC)
* 現象   : 2026-06-11 18:30:00 (UTC)を境に水準が 15.06から14.79へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.349, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-012 active_connections の推移](charts/EVT-20260611-host02-012.svg)

# イベントID( EVT-20260612-host02-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→15→15→16→15→14→13→12→12
* 開始   : 2026-06-12 18:30:00 (UTC)
* 終了   : 2026-06-12 19:55:00 (UTC)
* 現象   : 2026-06-12 19:55:00 (UTC)を境に水準が 14.78から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.036, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-014 active_connections の推移](charts/EVT-20260612-host02-014.svg)

# イベントID( EVT-20260614-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→16→14→15→18
* 開始   : 2026-06-14 15:00:00 (UTC)
* 終了   : 2026-06-14 15:20:00 (UTC)
* 現象   : 2026-06-14 15:20:00 (UTC)を境に水準が 11.82から14.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host02-002 active_connections の推移](charts/EVT-20260614-host02-002.svg)

# イベントID( EVT-20260615-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→18→16→17→…→12→13→12→11
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.83から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.727σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.345, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-002 active_connections の推移](charts/EVT-20260615-host02-002.svg)

# イベントID( EVT-20260615-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→13→…→12→11→12→13
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 19:40:00 (UTC)
* 現象   : 2026-06-15 19:40:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.337σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.201, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-003 active_connections の推移](charts/EVT-20260615-host02-003.svg)

# イベントID( EVT-20260615-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→16→…→16→14→11→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.92から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.207, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-005 active_connections の推移](charts/EVT-20260615-host02-005.svg)

# イベントID( EVT-20260615-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→16→…→13→15→12→13
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 22:00:00 (UTC)
* 現象   : 2026-06-15 22:00:00 (UTC)を境に水準が 11.82から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.747σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.772, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-006 active_connections の推移](charts/EVT-20260615-host02-006.svg)

# イベントID( EVT-20260615-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→16→15→16→…→15→13→14→15
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.975, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-007 active_connections の推移](charts/EVT-20260615-host02-007.svg)

# イベントID( EVT-20260615-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.051e+04→1.058e+04→1.063e+04→1.084e+04→…→1.009e+04→1.038e+04→9830→1.019e+04
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 9779から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.534σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.202 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=554.9, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2449, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-008 ou の推移](charts/EVT-20260615-host02-008.svg)

# イベントID( EVT-20260616-host02-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→9→9→10→10→8→9
* 開始   : 2026-06-16 23:25:00 (UTC)
* 終了   : 2026-06-17 00:30:00 (UTC)
* 現象   : 2026-06-17 00:30:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host02-015 active_connections の推移](charts/EVT-20260616-host02-015.svg)

# イベントID( EVT-20260617-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→9→47→37→…→11→12→13→14
* 開始   : 2026-06-17 03:00:00 (UTC)
* 終了   : 2026-06-17 04:45:00 (UTC)
* 現象   : 2026-06-17 04:45:00 (UTC)を境に水準が 15.18から16.38へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 15.11σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 25.63 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=47)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.041, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=37.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-002 active_connections の推移](charts/EVT-20260617-host02-002.svg)

# イベントID( EVT-20260617-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→20→21→22→23→22→22→23→22
* 開始   : 2026-06-17 09:20:00 (UTC)
* 終了   : 2026-06-17 10:00:00 (UTC)
* 現象   : 2026-06-17 10:00:00 (UTC)を境に水準が 14.98から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-010 active_connections の推移](charts/EVT-20260617-host02-010.svg)

# イベントID( EVT-20260621-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→11→8→10→7→8→11→9→10
* 開始   : 2026-06-21 00:05:00 (UTC)
* 終了   : 2026-06-21 00:45:00 (UTC)
* 現象   : 2026-06-21 00:45:00 (UTC)を境に水準が 11.78から12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host02-001 active_connections の推移](charts/EVT-20260621-host02-001.svg)

# イベントID( EVT-20260622-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→15→…→12→15→14→12
* 開始   : 2026-06-22 01:20:00 (UTC)
* 終了   : 2026-06-22 21:30:00 (UTC)
* 現象   : 2026-06-22 21:30:00 (UTC)を境に水準が 11.75から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.032, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-002 active_connections の推移](charts/EVT-20260622-host02-002.svg)

# イベントID( EVT-20260622-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→14→12→14→12
* 開始   : 2026-06-22 02:55:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.98から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.299, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.675, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-003 active_connections の推移](charts/EVT-20260622-host02-003.svg)

# イベントID( EVT-20260622-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→18→…→16→17→14→13
* 開始   : 2026-06-22 03:15:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.81から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.199, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.833, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-004 active_connections の推移](charts/EVT-20260622-host02-004.svg)

# イベントID( EVT-20260622-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→16→…→13→14→11→14
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 19:40:00 (UTC)
* 現象   : 2026-06-22 19:40:00 (UTC)を境に水準が 11.9から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.719, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-005 active_connections の推移](charts/EVT-20260622-host02-005.svg)

# イベントID( EVT-20260622-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→14→15→16→…→15→12→11→12
* 開始   : 2026-06-22 04:00:00 (UTC)
* 終了   : 2026-06-22 19:10:00 (UTC)
* 現象   : 2026-06-22 19:10:00 (UTC)を境に水準が 11.98から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.808, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.873, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-006 active_connections の推移](charts/EVT-20260622-host02-006.svg)

# イベントID( EVT-20260622-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.003e+04→1.058e+04→1.067e+04→1.039e+04→…→1.082e+04→1.036e+04→1.04e+04→1.055e+04
* 開始   : 2026-06-22 04:40:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 9796から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=542.3, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2303, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-008 ou の推移](charts/EVT-20260622-host02-008.svg)

# イベントID( EVT-20260623-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→18→19→17→18→17→22→20→21
* 開始   : 2026-06-23 06:45:00 (UTC)
* 終了   : 2026-06-23 08:55:00 (UTC)
* 現象   : 2026-06-23 08:55:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-002 active_connections の推移](charts/EVT-20260623-host02-002.svg)

# イベントID( EVT-20260623-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→15→13→14→13→13→14→13→13
* 開始   : 2026-06-23 18:45:00 (UTC)
* 終了   : 2026-06-23 19:40:00 (UTC)
* 現象   : 2026-06-23 19:40:00 (UTC)を境に水準が 14.91から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-009 active_connections の推移](charts/EVT-20260623-host02-009.svg)

# イベントID( EVT-20260624-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→9→41→38→…→11→12→13→14
* 開始   : 2026-06-24 03:00:00 (UTC)
* 終了   : 2026-06-24 04:45:00 (UTC)
* 現象   : 2026-06-24 04:45:00 (UTC)を境に水準が 15.04から16.19へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.52σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 20.91 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.064, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=31.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host02-001 active_connections の推移](charts/EVT-20260624-host02-001.svg)

# イベントID( EVT-20260626-host02-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→10→9→8
* 開始   : 2026-06-26 22:55:00 (UTC)
* 終了   : 2026-06-26 23:20:00 (UTC)
* 現象   : 2026-06-26 23:20:00 (UTC)を境に水準が 14.98から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.012, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-016 active_connections の推移](charts/EVT-20260626-host02-016.svg)

# イベントID( EVT-20260629-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→14→…→13→16→17→13
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.75から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-002 active_connections の推移](charts/EVT-20260629-host02-002.svg)

# イベントID( EVT-20260629-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→13→…→15→14→13→14
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.657, 限界=2.64)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-003 active_connections の推移](charts/EVT-20260629-host02-003.svg)

# イベントID( EVT-20260629-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→14→…→15→13→12→13
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.914, 限界=2.675)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-004 active_connections の推移](charts/EVT-20260629-host02-004.svg)

# イベントID( EVT-20260629-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→20→19→18→…→15→14→12→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.99から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.762, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-005 active_connections の推移](charts/EVT-20260629-host02-005.svg)

# イベントID( EVT-20260629-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.068e+04→1.068e+04→1.079e+04→1.091e+04→…→1.028e+04→1.111e+04→1.003e+04→1.054e+04
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 9764から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.267σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=604.3, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2459, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-006 ou の推移](charts/EVT-20260629-host02-006.svg)

# イベントID( EVT-20260629-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→15→…→14→12→14→12
* 開始   : 2026-06-29 04:10:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.94から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.03, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-007 active_connections の推移](charts/EVT-20260629-host02-007.svg)

# イベントID( EVT-20260630-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 24→21→23→23→23→21→22→23→23
* 開始   : 2026-06-30 11:50:00 (UTC)
* 終了   : 2026-06-30 13:10:00 (UTC)
* 現象   : 2026-06-30 13:10:00 (UTC)を境に水準が 15.04から14.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.518, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host02-005 active_connections の推移](charts/EVT-20260630-host02-005.svg)

# イベントID( EVT-20260630-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→21→19→18→20→20→19
* 開始   : 2026-06-30 15:35:00 (UTC)
* 終了   : 2026-06-30 16:35:00 (UTC)
* 現象   : 2026-06-30 16:35:00 (UTC)を境に水準が 15.04から12.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host02-006 active_connections の推移](charts/EVT-20260630-host02-006.svg)

# イベントID( EVT-20260601-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→13→13
* 開始   : 2026-06-01 04:45:00 (UTC)
* 終了   : 2026-06-01 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host02-005 active_connections の推移](charts/EVT-20260601-host02-005.svg)

# イベントID( EVT-20260601-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→19→16→19→19
* 開始   : 2026-06-01 15:00:00 (UTC)
* 終了   : 2026-06-01 15:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260601-host02-009 active_connections の推移](charts/EVT-20260601-host02-009.svg)

# イベントID( EVT-20260601-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→13→13
* 開始   : 2026-06-01 18:30:00 (UTC)
* 終了   : 2026-06-01 19:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260601-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host02-010 active_connections の推移](charts/EVT-20260601-host02-010.svg)

# イベントID( EVT-20260601-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9951→9530→8995→1.044e+04→…→8995→1.044e+04→9843→9948
* 開始   : 2026-06-01 19:15:00 (UTC)
* 終了   : 2026-06-01 19:50:00 (UTC)
* 現象   : 平常時(1.012e+04)に対し 0.8917(9022)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host02-011 ou の推移](charts/EVT-20260601-host02-011.svg)

# イベントID( EVT-20260602-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.021e+04→9903→1.089e+04→1.061e+04→1.016e+04
* 開始   : 2026-06-02 05:40:00 (UTC)
* 終了   : 2026-06-02 05:40:00 (UTC)
* 現象   : 平常時(9873)に対し 1.103倍(1.089e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-002 ou の推移](charts/EVT-20260602-host02-002.svg)

# イベントID( EVT-20260602-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→19→14→18→14→18→14→18→15
* 開始   : 2026-06-02 17:15:00 (UTC)
* 終了   : 2026-06-02 17:40:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-006 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host02-007 active_connections の推移](charts/EVT-20260602-host02-007.svg)

# イベントID( EVT-20260602-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→14→10→16→14
* 開始   : 2026-06-02 18:25:00 (UTC)
* 終了   : 2026-06-02 18:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host02-008 active_connections の推移](charts/EVT-20260602-host02-008.svg)

# イベントID( EVT-20260602-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→8→…→10→8→12→11
* 開始   : 2026-06-02 19:40:00 (UTC)
* 終了   : 2026-06-02 19:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host02-009 active_connections の推移](charts/EVT-20260602-host02-009.svg)

# イベントID( EVT-20260602-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→11→8→12→12
* 開始   : 2026-06-02 20:00:00 (UTC)
* 終了   : 2026-06-02 20:00:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-010 active_connections の推移](charts/EVT-20260602-host02-010.svg)

# イベントID( EVT-20260603-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→10→15→12→10
* 開始   : 2026-06-03 03:40:00 (UTC)
* 終了   : 2026-06-03 03:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.513倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host02-002 active_connections の推移](charts/EVT-20260603-host02-002.svg)

# イベントID( EVT-20260603-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→12→17→13→14
* 開始   : 2026-06-03 05:15:00 (UTC)
* 終了   : 2026-06-03 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-006 active_connections の推移](charts/EVT-20260603-host02-006.svg)

# イベントID( EVT-20260603-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→17→17
* 開始   : 2026-06-03 17:25:00 (UTC)
* 終了   : 2026-06-03 17:45:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260603-host02-010 active_connections の推移](charts/EVT-20260603-host02-010.svg)

# イベントID( EVT-20260603-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→14→15
* 開始   : 2026-06-03 18:05:00 (UTC)
* 終了   : 2026-06-03 18:05:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host02-011 active_connections の推移](charts/EVT-20260603-host02-011.svg)

# イベントID( EVT-20260603-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→9→8
* 開始   : 2026-06-03 21:35:00 (UTC)
* 終了   : 2026-06-03 21:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host02-014 active_connections の推移](charts/EVT-20260603-host02-014.svg)

# イベントID( EVT-20260604-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→6→12→7→8
* 開始   : 2026-06-04 00:55:00 (UTC)
* 終了   : 2026-06-04 00:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→10→…→11→12→13→11
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-5.94, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-004 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260604-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260604-host02-003 active_connections の推移](charts/EVT-20260604-host02-003.svg)

# イベントID( EVT-20260604-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→13→17→12→14
* 開始   : 2026-06-04 05:00:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-005 active_connections の推移](charts/EVT-20260604-host02-005.svg)

# イベントID( EVT-20260604-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→13→14
* 開始   : 2026-06-04 05:45:00 (UTC)
* 終了   : 2026-06-04 05:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-006 active_connections の推移](charts/EVT-20260604-host02-006.svg)

# イベントID( EVT-20260604-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→19→…→18→21→17→18
* 開始   : 2026-06-04 07:30:00 (UTC)
* 終了   : 2026-06-04 08:10:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host02-009 active_connections の推移](charts/EVT-20260604-host02-009.svg)

# イベントID( EVT-20260604-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→19→20→22→20→19→20→22→20
* 開始   : 2026-06-04 07:50:00 (UTC)
* 終了   : 2026-06-04 07:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-010 active_connections の推移](charts/EVT-20260604-host02-010.svg)

# イベントID( EVT-20260604-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→17→14→19→19
* 開始   : 2026-06-04 17:00:00 (UTC)
* 終了   : 2026-06-04 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-013 active_connections の推移](charts/EVT-20260604-host02-013.svg)

# イベントID( EVT-20260604-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→11→11
* 開始   : 2026-06-04 19:10:00 (UTC)
* 終了   : 2026-06-04 19:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host02-014 active_connections の推移](charts/EVT-20260604-host02-014.svg)

# イベントID( EVT-20260605-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→15→18→15→15
* 開始   : 2026-06-05 06:10:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host02-001 active_connections の推移](charts/EVT-20260605-host02-001.svg)

# イベントID( EVT-20260605-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→18→17
* 開始   : 2026-06-05 16:30:00 (UTC)
* 終了   : 2026-06-05 16:30:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host02-004 active_connections の推移](charts/EVT-20260605-host02-004.svg)

# イベントID( EVT-20260605-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→17→13→17→18
* 開始   : 2026-06-05 17:05:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host02-005 active_connections の推移](charts/EVT-20260605-host02-005.svg)

# イベントID( EVT-20260605-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→16→12→15→14
* 開始   : 2026-06-05 17:45:00 (UTC)
* 終了   : 2026-06-05 17:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host02-006 active_connections の推移](charts/EVT-20260605-host02-006.svg)

# イベントID( EVT-20260606-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9008→9370→1.031e+04→9392→9195
* 開始   : 2026-06-06 00:30:00 (UTC)
* 終了   : 2026-06-06 00:30:00 (UTC)
* 現象   : 平常時(9288)に対し 1.11倍(1.031e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host02-001 ou の推移](charts/EVT-20260606-host02-001.svg)

# イベントID( EVT-20260606-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→13→…→10→14→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:30:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.691, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.1 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host02-003 active_connections の推移](charts/EVT-20260606-host02-003.svg)

# イベントID( EVT-20260606-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→12→…→13→14→13→12
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.874, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host02-004 active_connections の推移](charts/EVT-20260606-host02-004.svg)

# イベントID( EVT-20260606-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→11→…→12→14→11→12
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.708, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host02-005 active_connections の推移](charts/EVT-20260606-host02-005.svg)

# イベントID( EVT-20260606-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→11→…→12→11→14→11
* 開始   : 2026-06-06 06:20:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.9 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260606-host02-006 active_connections の推移](charts/EVT-20260606-host02-006.svg)

# イベントID( EVT-20260606-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→12→…→11→12→11→13
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host02-007 active_connections の推移](charts/EVT-20260606-host02-007.svg)

# イベントID( EVT-20260606-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.082e+04→1.034e+04→9871→1.06e+04→…→9981→1.006e+04→1.007e+04→1.019e+04
* 開始   : 2026-06-06 07:25:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 11.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-553.5, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260606-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.3 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.3 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間

![EVT-20260606-host02-008 ou の推移](charts/EVT-20260606-host02-008.svg)

# イベントID( EVT-20260606-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→5→9→10
* 開始   : 2026-06-06 20:55:00 (UTC)
* 終了   : 2026-06-06 20:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260606-host02-010 active_connections の推移](charts/EVT-20260606-host02-010.svg)

# イベントID( EVT-20260607-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→8→4→5→…→4→5→9→6
* 開始   : 2026-06-07 00:45:00 (UTC)
* 終了   : 2026-06-07 00:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host02-002 active_connections の推移](charts/EVT-20260607-host02-002.svg)

# イベントID( EVT-20260607-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→14→11→17→16
* 開始   : 2026-06-07 12:05:00 (UTC)
* 終了   : 2026-06-07 12:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260607-host02-005 active_connections の推移](charts/EVT-20260607-host02-005.svg)

# イベントID( EVT-20260607-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→12→11
* 開始   : 2026-06-07 17:30:00 (UTC)
* 終了   : 2026-06-07 17:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host02-008 active_connections の推移](charts/EVT-20260607-host02-008.svg)

# イベントID( EVT-20260608-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→13→12→10→9→13→12→10
* 開始   : 2026-06-08 02:55:00 (UTC)
* 終了   : 2026-06-08 03:00:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→15→…→10→13→10→14
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.84から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.011, 限界=2.652)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-008 active_connections の推移](charts/EVT-20260608-host02-008.svg)

# イベントID( EVT-20260609-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→13→19→16→14
* 開始   : 2026-06-09 06:20:00 (UTC)
* 終了   : 2026-06-09 06:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host02-001 active_connections の推移](charts/EVT-20260609-host02-001.svg)

# イベントID( EVT-20260609-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→12→13→15→17→12→13→15
* 開始   : 2026-06-09 17:30:00 (UTC)
* 終了   : 2026-06-09 17:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host02-005 active_connections の推移](charts/EVT-20260609-host02-005.svg)

# イベントID( EVT-20260610-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→16→21→17→19
* 開始   : 2026-06-10 07:25:00 (UTC)
* 終了   : 2026-06-10 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host02-004 active_connections の推移](charts/EVT-20260610-host02-004.svg)

# イベントID( EVT-20260610-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→22→18→23→22
* 開始   : 2026-06-10 13:20:00 (UTC)
* 終了   : 2026-06-10 13:20:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host02-005 active_connections の推移](charts/EVT-20260610-host02-005.svg)

# イベントID( EVT-20260610-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→12→7→13→11
* 開始   : 2026-06-10 20:30:00 (UTC)
* 終了   : 2026-06-10 20:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260610-host02-008 active_connections の推移](charts/EVT-20260610-host02-008.svg)

# イベントID( EVT-20260610-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9396→9736→8437→9042→9989
* 開始   : 2026-06-10 21:50:00 (UTC)
* 終了   : 2026-06-10 21:50:00 (UTC)
* 現象   : 平常時(9603)に対し 0.8786(8437)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host02-011 ou の推移](charts/EVT-20260610-host02-011.svg)

# イベントID( EVT-20260611-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→11→…→13→10→13→16
* 開始   : 2026-06-11 03:00:00 (UTC)
* 終了   : 2026-06-11 04:40:00 (UTC)
* 現象   : 1.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.729, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-003 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 1.0 時間
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260611-host02-001 active_connections の推移](charts/EVT-20260611-host02-001.svg)

# イベントID( EVT-20260611-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→10→10
* 開始   : 2026-06-11 03:40:00 (UTC)
* 終了   : 2026-06-11 03:40:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-002 active_connections の推移](charts/EVT-20260611-host02-002.svg)

# イベントID( EVT-20260611-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→12→17→12→13
* 開始   : 2026-06-11 04:45:00 (UTC)
* 終了   : 2026-06-11 04:45:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-003 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-004 active_connections の推移](charts/EVT-20260611-host02-004.svg)

# イベントID( EVT-20260611-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→17→15→17→15→17→15→14
* 開始   : 2026-06-11 05:40:00 (UTC)
* 終了   : 2026-06-11 05:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host02-006 active_connections の推移](charts/EVT-20260611-host02-006.svg)

# イベントID( EVT-20260611-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→16→20→17→18
* 開始   : 2026-06-11 06:55:00 (UTC)
* 終了   : 2026-06-11 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host02-007 active_connections の推移](charts/EVT-20260611-host02-007.svg)

# イベントID( EVT-20260611-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→20→14→16→15
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-011 active_connections の推移](charts/EVT-20260611-host02-011.svg)

# イベントID( EVT-20260611-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.04e+04→1.003e+04→9187→9854→1.011e+04
* 開始   : 2026-06-11 18:50:00 (UTC)
* 終了   : 2026-06-11 18:50:00 (UTC)
* 現象   : 平常時(1.032e+04)に対し 0.8903(9187)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host02-013 ou の推移](charts/EVT-20260611-host02-013.svg)

# イベントID( EVT-20260612-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→18→16→13→18→13
* 開始   : 2026-06-12 05:25:00 (UTC)
* 終了   : 2026-06-12 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host02-005 active_connections の推移](charts/EVT-20260612-host02-005.svg)

# イベントID( EVT-20260612-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→17→22→18→19
* 開始   : 2026-06-12 07:40:00 (UTC)
* 終了   : 2026-06-12 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.597σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-008 active_connections の推移](charts/EVT-20260612-host02-008.svg)

# イベントID( EVT-20260612-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→14→9→14→13
* 開始   : 2026-06-12 19:10:00 (UTC)
* 終了   : 2026-06-12 19:10:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.6353(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-015 active_connections の推移](charts/EVT-20260612-host02-015.svg)

# イベントID( EVT-20260612-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.006e+04→1.005e+04→9106→1.002e+04→1.007e+04
* 開始   : 2026-06-12 19:35:00 (UTC)
* 終了   : 2026-06-12 19:35:00 (UTC)
* 現象   : 平常時(1.024e+04)に対し 0.8889(9106)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host02-016 ou の推移](charts/EVT-20260612-host02-016.svg)

# イベントID( EVT-20260612-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→11→8→11→10
* 開始   : 2026-06-12 20:20:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host02-017 active_connections の推移](charts/EVT-20260612-host02-017.svg)

# イベントID( EVT-20260612-host02-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→9→4→8→9
* 開始   : 2026-06-12 23:30:00 (UTC)
* 終了   : 2026-06-12 23:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-019 active_connections の推移](charts/EVT-20260612-host02-019.svg)

# イベントID( EVT-20260613-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9281→9571→1.069e+04→9746→9778
* 開始   : 2026-06-13 04:45:00 (UTC)
* 終了   : 2026-06-13 04:45:00 (UTC)
* 現象   : 平常時(9652)に対し 1.108倍(1.069e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host02-003 ou の推移](charts/EVT-20260613-host02-003.svg)

# イベントID( EVT-20260613-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→11→15→11→12
* 開始   : 2026-06-13 04:50:00 (UTC)
* 終了   : 2026-06-13 04:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host02-004 active_connections の推移](charts/EVT-20260613-host02-004.svg)

# イベントID( EVT-20260613-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→11→12→11→…→10→12→13→12
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.7, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 10.6 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260613-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 40 分
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間

![EVT-20260613-host02-005 active_connections の推移](charts/EVT-20260613-host02-005.svg)

# イベントID( EVT-20260613-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→14→…→9→11→9→10
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.65, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 10.6 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260613-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 1.5 時間
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.9 時間

![EVT-20260613-host02-006 active_connections の推移](charts/EVT-20260613-host02-006.svg)

# イベントID( EVT-20260613-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→14→11→13→…→14→11→12→14
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 19:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.88, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 10.6 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260613-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 1.5 時間
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間

![EVT-20260613-host02-007 active_connections の推移](charts/EVT-20260613-host02-007.svg)

# イベントID( EVT-20260613-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→11→13→12→10
* 開始   : 2026-06-13 06:40:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.654, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 10.2 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260613-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 50 分
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間

![EVT-20260613-host02-009 active_connections の推移](charts/EVT-20260613-host02-009.svg)

# イベントID( EVT-20260613-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→14→…→13→12→13→11
* 開始   : 2026-06-13 07:00:00 (UTC)
* 終了   : 2026-06-13 18:05:00 (UTC)
* 現象   : 11.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.916, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 9.9 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.1 時間

![EVT-20260613-host02-010 active_connections の推移](charts/EVT-20260613-host02-010.svg)

# イベントID( EVT-20260614-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 5→7→12→9→8
* 開始   : 2026-06-14 01:15:00 (UTC)
* 終了   : 2026-06-14 01:15:00 (UTC)
* 現象   : 平常時(7.083)に対し 1.694倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host02-001 active_connections の推移](charts/EVT-20260614-host02-001.svg)

# イベントID( EVT-20260614-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→10→9
* 開始   : 2026-06-14 19:35:00 (UTC)
* 終了   : 2026-06-14 19:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→9→10
* 開始   : 2026-06-14 21:10:00 (UTC)
* 終了   : 2026-06-14 21:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host02-005 active_connections の推移](charts/EVT-20260614-host02-005.svg)

# イベントID( EVT-20260616-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→7→11→13→…→11→13→9→11
* 開始   : 2026-06-16 01:40:00 (UTC)
* 終了   : 2026-06-16 01:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→14→…→15→14→10→12
* 開始   : 2026-06-16 04:05:00 (UTC)
* 終了   : 2026-06-16 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host02-004 active_connections の推移](charts/EVT-20260616-host02-004.svg)

# イベントID( EVT-20260616-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→16→21→18→18
* 開始   : 2026-06-16 07:40:00 (UTC)
* 終了   : 2026-06-16 07:40:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host02-007 active_connections の推移](charts/EVT-20260616-host02-007.svg)

# イベントID( EVT-20260616-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.092e+04→1.158e+04→1.022e+04→1.156e+04→1.098e+04
* 開始   : 2026-06-16 13:40:00 (UTC)
* 終了   : 2026-06-16 13:40:00 (UTC)
* 現象   : 平常時(1.135e+04)に対し 0.901(1.022e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.357σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→13→12
* 開始   : 2026-06-16 18:55:00 (UTC)
* 終了   : 2026-06-16 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host02-010 active_connections の推移](charts/EVT-20260616-host02-010.svg)

# イベントID( EVT-20260616-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9278→9461→8619→9509→9950
* 開始   : 2026-06-16 19:50:00 (UTC)
* 終了   : 2026-06-16 19:50:00 (UTC)
* 現象   : 平常時(9790)に対し 0.8804(8619)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host02-012 ou の推移](charts/EVT-20260616-host02-012.svg)

# イベントID( EVT-20260616-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→12→12
* 開始   : 2026-06-16 20:25:00 (UTC)
* 終了   : 2026-06-16 20:25:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host02-013 active_connections の推移](charts/EVT-20260616-host02-013.svg)

# イベントID( EVT-20260617-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→14→12→11→11
* 開始   : 2026-06-17 02:30:00 (UTC)
* 終了   : 2026-06-17 03:00:00 (UTC)
* 現象   : 2026-06-17 03:00:00 (UTC)を境に水準が 15から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-001 active_connections の推移](charts/EVT-20260617-host02-001.svg)

# イベントID( EVT-20260617-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.089e+04→1.074e+04→1.213e+04→1.078e+04→1.068e+04
* 開始   : 2026-06-17 13:45:00 (UTC)
* 終了   : 2026-06-17 13:45:00 (UTC)
* 現象   : 平常時(1.112e+04)に対し 1.091倍(1.213e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host02-011 ou の推移](charts/EVT-20260617-host02-011.svg)

# イベントID( EVT-20260617-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→17→19
* 開始   : 2026-06-17 16:45:00 (UTC)
* 終了   : 2026-06-17 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-012 active_connections の推移](charts/EVT-20260617-host02-012.svg)

# イベントID( EVT-20260617-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.023e+04→1.03e+04→9971→9637
* 開始   : 2026-06-17 18:45:00 (UTC)
* 終了   : 2026-06-17 19:50:00 (UTC)
* 現象   : 2026-06-17 19:50:00 (UTC)を境に水準が 1.02e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.176σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→13→9→14→13
* 開始   : 2026-06-17 19:30:00 (UTC)
* 終了   : 2026-06-17 19:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-016 active_connections の推移](charts/EVT-20260617-host02-016.svg)

# イベントID( EVT-20260618-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→9→10→9→…→10→13→10→13
* 開始   : 2026-06-18 03:00:00 (UTC)
* 終了   : 2026-06-18 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.12, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260618-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host02-001 active_connections の推移](charts/EVT-20260618-host02-001.svg)

# イベントID( EVT-20260618-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→11→14→11→…→11→13→9→12
* 開始   : 2026-06-18 03:20:00 (UTC)
* 終了   : 2026-06-18 03:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.249σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host02-002 active_connections の推移](charts/EVT-20260618-host02-002.svg)

# イベントID( EVT-20260618-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→20→15→17→20
* 開始   : 2026-06-18 16:00:00 (UTC)
* 終了   : 2026-06-18 16:00:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-006 active_connections の推移](charts/EVT-20260618-host02-006.svg)

# イベントID( EVT-20260618-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→15→12→16→14
* 開始   : 2026-06-18 17:45:00 (UTC)
* 終了   : 2026-06-18 17:45:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-020 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host02-008 active_connections の推移](charts/EVT-20260618-host02-008.svg)

# イベントID( EVT-20260618-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→14→8→11→11
* 開始   : 2026-06-18 20:20:00 (UTC)
* 終了   : 2026-06-18 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host02-010 active_connections の推移](charts/EVT-20260618-host02-010.svg)

# イベントID( EVT-20260619-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→10→14→10→…→10→15→13→12
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-003 active_connections の推移](charts/EVT-20260619-host02-003.svg)

# イベントID( EVT-20260619-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→12→15
* 開始   : 2026-06-19 05:15:00 (UTC)
* 終了   : 2026-06-19 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host02-004 active_connections の推移](charts/EVT-20260619-host02-004.svg)

# イベントID( EVT-20260619-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→21→22
* 開始   : 2026-06-19 14:00:00 (UTC)
* 終了   : 2026-06-19 14:00:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.7669(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host02-008 active_connections の推移](charts/EVT-20260619-host02-008.svg)

# イベントID( EVT-20260619-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→13→11→16→15→13→11→16→14
* 開始   : 2026-06-19 17:50:00 (UTC)
* 終了   : 2026-06-19 17:55:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host02-010 active_connections の推移](charts/EVT-20260619-host02-010.svg)

# イベントID( EVT-20260619-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.054e+04→1.079e+04→9358→1.02e+04→1.019e+04
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 18:15:00 (UTC)
* 現象   : 平常時(1.053e+04)に対し 0.8885(9358)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host02-012 ou の推移](charts/EVT-20260619-host02-012.svg)

# イベントID( EVT-20260619-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→8→6→11→10
* 開始   : 2026-06-19 21:55:00 (UTC)
* 終了   : 2026-06-19 21:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-014 active_connections の推移](charts/EVT-20260619-host02-014.svg)

# イベントID( EVT-20260620-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→8→6→13→8→6→13→8→9
* 開始   : 2026-06-20 03:15:00 (UTC)
* 終了   : 2026-06-20 04:20:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667倍(6)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 25 分
  - EVT-20260620-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260620-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260620-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260620-host02-001 active_connections の推移](charts/EVT-20260620-host02-001.svg)

# イベントID( EVT-20260620-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→13→12→13→…→10→12→11→12
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.702, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host02-002 active_connections の推移](charts/EVT-20260620-host02-002.svg)

# イベントID( EVT-20260620-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→11→…→11→13→12→13
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.839, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.8 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host02-003 active_connections の推移](charts/EVT-20260620-host02-003.svg)

# イベントID( EVT-20260620-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→12→10→12→…→11→10→11→9
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.044, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host02-004 active_connections の推移](charts/EVT-20260620-host02-004.svg)

# イベントID( EVT-20260620-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→12→11→12→…→13→12→11→13
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 18:15:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.03, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.2 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260620-host02-005 active_connections の推移](charts/EVT-20260620-host02-005.svg)

# イベントID( EVT-20260620-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→13→…→11→10→12→9
* 開始   : 2026-06-20 06:15:00 (UTC)
* 終了   : 2026-06-20 19:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.72, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間

![EVT-20260620-host02-006 active_connections の推移](charts/EVT-20260620-host02-006.svg)

# イベントID( EVT-20260620-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.046e+04→1.013e+04→9609→9833→…→1.006e+04→9896→1.069e+04→9925
* 開始   : 2026-06-20 08:00:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 11.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-574.2, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.2 時間
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間

![EVT-20260620-host02-007 ou の推移](charts/EVT-20260620-host02-007.svg)

# イベントID( EVT-20260620-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9750→9356→8655→9825→9484
* 開始   : 2026-06-20 20:10:00 (UTC)
* 終了   : 2026-06-20 20:10:00 (UTC)
* 現象   : 平常時(9703)に対し 0.892(8655)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host02-012 ou の推移](charts/EVT-20260620-host02-012.svg)

# イベントID( EVT-20260621-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→8→3→10→9
* 開始   : 2026-06-21 00:15:00 (UTC)
* 終了   : 2026-06-21 00:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.3214(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.408σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host02-002 active_connections の推移](charts/EVT-20260621-host02-002.svg)

# イベントID( EVT-20260621-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 7→8→12→10→8
* 開始   : 2026-06-21 02:35:00 (UTC)
* 終了   : 2026-06-21 02:35:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host02-004 active_connections の推移](charts/EVT-20260621-host02-004.svg)

# イベントID( EVT-20260621-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9941→9759→8851→9456→9637
* 開始   : 2026-06-21 18:20:00 (UTC)
* 終了   : 2026-06-21 18:20:00 (UTC)
* 現象   : 平常時(9966)に対し 0.8881(8851)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host02-009 ou の推移](charts/EVT-20260621-host02-009.svg)

# イベントID( EVT-20260622-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→11→6→11→10
* 開始   : 2026-06-22 20:20:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.5373(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.596σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host02-010 active_connections の推移](charts/EVT-20260622-host02-010.svg)

# イベントID( EVT-20260623-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.031e+04→1.023e+04→1.088e+04→1.099e+04→…→1.088e+04→1.099e+04→1.054e+04→1.023e+04
* 開始   : 2026-06-23 06:05:00 (UTC)
* 終了   : 2026-06-23 06:40:00 (UTC)
* 現象   : 平常時(1.013e+04)に対し 1.074倍(1.088e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host02-001 ou の推移](charts/EVT-20260623-host02-001.svg)

# イベントID( EVT-20260623-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→17→23→20→21
* 開始   : 2026-06-23 08:50:00 (UTC)
* 終了   : 2026-06-23 08:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.14e+04→1.134e+04→1.214e+04→1.095e+04→1.153e+04
* 開始   : 2026-06-23 10:40:00 (UTC)
* 終了   : 2026-06-23 10:40:00 (UTC)
* 現象   : 平常時(1.101e+04)に対し 1.103倍(1.214e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host02-006 ou の推移](charts/EVT-20260623-host02-006.svg)

# イベントID( EVT-20260623-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 24→21→17→20→20
* 開始   : 2026-06-23 14:20:00 (UTC)
* 終了   : 2026-06-23 14:20:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→11→8→11→11
* 開始   : 2026-06-23 20:05:00 (UTC)
* 終了   : 2026-06-23 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host02-010 active_connections の推移](charts/EVT-20260623-host02-010.svg)

# イベントID( EVT-20260623-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→6→4→10→8
* 開始   : 2026-06-23 23:10:00 (UTC)
* 終了   : 2026-06-23 23:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→11→17→16→…→17→16→14→15
* 開始   : 2026-06-24 04:35:00 (UTC)
* 終了   : 2026-06-24 05:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260624-host02-004 active_connections の推移](charts/EVT-20260624-host02-004.svg)

# イベントID( EVT-20260624-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→17→22→20→17
* 開始   : 2026-06-24 07:55:00 (UTC)
* 終了   : 2026-06-24 07:55:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host02-006 active_connections の推移](charts/EVT-20260624-host02-006.svg)

# イベントID( EVT-20260624-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.116e+04→1.136e+04→1.008e+04→1.112e+04→1.12e+04
* 開始   : 2026-06-24 13:35:00 (UTC)
* 終了   : 2026-06-24 14:35:00 (UTC)
* 現象   : 平常時(1.118e+04)に対し 0.9018(1.008e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260624-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host02-010 ou の推移](charts/EVT-20260624-host02-010.svg)

# イベントID( EVT-20260624-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.039e+04→1.029e+04→9679→1.02e+04→1.075e+04
* 開始   : 2026-06-24 16:55:00 (UTC)
* 終了   : 2026-06-24 16:55:00 (UTC)
* 現象   : 平常時(1.076e+04)に対し 0.8995(9679)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.232σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host02-011 ou の推移](charts/EVT-20260624-host02-011.svg)

# イベントID( EVT-20260624-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→9→6→9→8
* 開始   : 2026-06-24 21:25:00 (UTC)
* 終了   : 2026-06-24 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host02-014 active_connections の推移](charts/EVT-20260624-host02-014.svg)

# イベントID( EVT-20260624-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→11→5→10→7
* 開始   : 2026-06-24 22:20:00 (UTC)
* 終了   : 2026-06-24 22:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host02-015 active_connections の推移](charts/EVT-20260624-host02-015.svg)

# イベントID( EVT-20260625-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→8→…→11→12→13→11
* 開始   : 2026-06-25 03:00:00 (UTC)
* 終了   : 2026-06-25 04:40:00 (UTC)
* 現象   : 1.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.085, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 45 分

![EVT-20260625-host02-002 active_connections の推移](charts/EVT-20260625-host02-002.svg)

# イベントID( EVT-20260625-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→25→24→23
* 開始   : 2026-06-25 10:20:00 (UTC)
* 終了   : 2026-06-25 10:35:00 (UTC)
* 現象   : 2026-06-25 10:35:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.666, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.059e+04→1.146e+04→1.061e+04
* 開始   : 2026-06-25 17:50:00 (UTC)
* 終了   : 2026-06-25 18:00:00 (UTC)
* 現象   : 2026-06-25 18:00:00 (UTC)を境に水準が 1.022e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.42σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-007 ou の推移](charts/EVT-20260625-host02-007.svg)

# イベントID( EVT-20260625-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→13→9→10→9→10→9→13→12
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 21:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host02-009 active_connections の推移](charts/EVT-20260625-host02-009.svg)

# イベントID( EVT-20260626-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→20→23→18→17
* 開始   : 2026-06-26 07:50:00 (UTC)
* 終了   : 2026-06-26 07:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.296倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host02-003 active_connections の推移](charts/EVT-20260626-host02-003.svg)

# イベントID( EVT-20260626-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→18→21
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host02-005 active_connections の推移](charts/EVT-20260626-host02-005.svg)

# イベントID( EVT-20260626-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.039e+04→1.125e+04→1.163e+04→1.06e+04→…→1.06e+04→9981→1.04e+04→1.063e+04
* 開始   : 2026-06-26 16:05:00 (UTC)
* 終了   : 2026-06-26 16:50:00 (UTC)
* 現象   : 平常時(1.091e+04)に対し 0.9015倍(9832)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host02-010 ou の推移](charts/EVT-20260626-host02-010.svg)

# イベントID( EVT-20260626-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9564→9882→8661→9711→1.006e+04
* 開始   : 2026-06-26 20:35:00 (UTC)
* 終了   : 2026-06-26 20:35:00 (UTC)
* 現象   : 平常時(9789)に対し 0.8847(8661)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-015 ou の推移](charts/EVT-20260626-host02-015.svg)

# イベントID( EVT-20260627-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→7→13→7→9
* 開始   : 2026-06-27 00:55:00 (UTC)
* 終了   : 2026-06-27 00:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.696倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.727σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host02-001 active_connections の推移](charts/EVT-20260627-host02-001.svg)

# イベントID( EVT-20260627-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.014e+04→9760→9995→9853→…→9594→1.012e+04→1.036e+04→9951
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-578.5, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host02-002 ou の推移](charts/EVT-20260627-host02-002.svg)

# イベントID( EVT-20260627-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→14→12→14→…→14→12→14→13
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 17:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.64, 限界=2.64)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host02-003 active_connections の推移](charts/EVT-20260627-host02-003.svg)

# イベントID( EVT-20260627-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→12→…→12→10→12→11
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.675)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host02-004 active_connections の推移](charts/EVT-20260627-host02-004.svg)

# イベントID( EVT-20260627-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→12→…→8→12→10→11
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.081, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host02-005 active_connections の推移](charts/EVT-20260627-host02-005.svg)

# イベントID( EVT-20260627-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→12→10→14→…→11→13→15→14
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 20:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.868, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.6 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host02-006 active_connections の推移](charts/EVT-20260627-host02-006.svg)

# イベントID( EVT-20260627-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→14→13→14→15
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 20:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.05, 限界=2.652)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260627-host02-007 active_connections の推移](charts/EVT-20260627-host02-007.svg)

# イベントID( EVT-20260627-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9531→9726→8617→9337→…→8617→9337→9618→9108
* 開始   : 2026-06-27 19:50:00 (UTC)
* 終了   : 2026-06-27 19:55:00 (UTC)
* 現象   : 平常時(9640)に対し 0.8939(8617)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.056σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-675.5, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260627-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260627-host02-009 ou の推移](charts/EVT-20260627-host02-009.svg)

# イベントID( EVT-20260628-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→9→8→9→10→10
* 開始   : 2026-06-28 23:30:00 (UTC)
* 終了   : 2026-06-29 00:10:00 (UTC)
* 現象   : 2026-06-29 00:10:00 (UTC)を境に水準が 11.79から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→15→18→15→13
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-002 active_connections の推移](charts/EVT-20260630-host02-002.svg)

# イベントID( EVT-20260630-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→15→16
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-003 active_connections の推移](charts/EVT-20260630-host02-003.svg)

# イベントID( EVT-20260630-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→15→19→14→15
* 開始   : 2026-06-30 06:15:00 (UTC)
* 終了   : 2026-06-30 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-004 active_connections の推移](charts/EVT-20260630-host02-004.svg)

# イベントID( EVT-20260630-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→16→13→16→13→16→15
* 開始   : 2026-06-30 17:40:00 (UTC)
* 終了   : 2026-06-30 17:45:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host02-007 active_connections の推移](charts/EVT-20260630-host02-007.svg)

# イベントID( EVT-20260630-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→16→11→13→16→11→13
* 開始   : 2026-06-30 18:25:00 (UTC)
* 終了   : 2026-06-30 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260630-host02-008 active_connections の推移](charts/EVT-20260630-host02-008.svg)

# イベントID( EVT-20260630-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→13→9→15→14
* 開始   : 2026-06-30 19:15:00 (UTC)
* 終了   : 2026-06-30 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6243(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.805σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-010 active_connections の推移](charts/EVT-20260630-host02-010.svg)

# イベントID( EVT-20260601-host02-002 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : WARN
* データ : jvm_gc / fgct_delta (区間 Full GC 時間) / container=app02, host=host02
* 値     : 0.04→0.04→0.04→0.04→0.04→0.04→0.04→0.04→0.04
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-06-30 23:55:00 (UTC)
* 現象   : 30.0日で 0.04から0.04へ増加した(平均 0/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=15255, p=0.01464, Sen勾配=0/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→9→5→8→5→8→5→8→7
* 開始   : 2026-06-01 00:35:00 (UTC)
* 終了   : 2026-06-01 00:45:00 (UTC)
* 現象   : 平常時(8.429)に対し 0.5932(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→15→12→15→12→15
* 開始   : 2026-06-01 04:40:00 (UTC)
* 終了   : 2026-06-01 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→21→22→19→…→19→23→20→21
* 開始   : 2026-06-01 08:55:00 (UTC)
* 終了   : 2026-06-01 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 22→21→23→22→21→23→22→20
* 開始   : 2026-06-01 09:25:00 (UTC)
* 終了   : 2026-06-01 09:30:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.161e+04→1.149e+04→1.05e+04→1.122e+04→…→1.094e+04→1.211e+04→1.141e+04→1.132e+04
* 開始   : 2026-06-01 12:00:00 (UTC)
* 終了   : 2026-06-01 12:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.542σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→13→14→11→10→13→14→11→12
* 開始   : 2026-06-02 04:10:00 (UTC)
* 終了   : 2026-06-02 04:15:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→16→20→18→21→20→18→21→18
* 開始   : 2026-06-02 07:35:00 (UTC)
* 終了   : 2026-06-02 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.069e+04→1.072e+04→1.153e+04→1.164e+04→…→1.153e+04→1.164e+04→1.129e+04→1.085e+04
* 開始   : 2026-06-02 10:05:00 (UTC)
* 終了   : 2026-06-02 10:10:00 (UTC)
* 現象   : 平常時(1.071e+04)に対し 1.077倍(1.153e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260602-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→18→19→16→18→16
* 開始   : 2026-06-02 16:30:00 (UTC)
* 終了   : 2026-06-02 16:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.085e+04→1.123e+04→9948→1.072e+04→…→1.072e+04→9960→1.071e+04→1e+04
* 開始   : 2026-06-02 17:10:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(1.071e+04)に対し 0.9288(9948)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→12→14→12→14→12→14→12
* 開始   : 2026-06-03 04:00:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→12→14→15→12→14
* 開始   : 2026-06-03 04:40:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9501→9578→1.041e+04→1.043e+04→…→1.041e+04→1.043e+04→1.025e+04→1.017e+04
* 開始   : 2026-06-03 05:00:00 (UTC)
* 終了   : 2026-06-03 05:05:00 (UTC)
* 現象   : 平常時(9690)に対し 1.074倍(1.041e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→22→21→21→21→19→18→20→20
* 開始   : 2026-06-03 14:30:00 (UTC)
* 終了   : 2026-06-03 15:45:00 (UTC)
* 現象   : 2026-06-03 15:45:00 (UTC)を境に水準が 14.91から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→17→23→19→20→17→23→19
* 開始   : 2026-06-03 15:05:00 (UTC)
* 終了   : 2026-06-03 15:10:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-009 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260603-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.117e+04→1.067e+04→1.18e+04→1.108e+04→…→1.108e+04→1.025e+04→1.095e+04→1.082e+04
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 15:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→11→14→12→11→14
* 開始   : 2026-06-03 18:40:00 (UTC)
* 終了   : 2026-06-03 18:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→10→…→11→10→12→11
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→12→10→9→5→12→10
* 開始   : 2026-06-03 22:20:00 (UTC)
* 終了   : 2026-06-03 22:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→11→8→11→8
* 開始   : 2026-06-04 00:30:00 (UTC)
* 終了   : 2026-06-04 00:35:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9258→1.012e+04→1.04e+04→9685→…→9685→1.061e+04→9987→1.035e+04
* 開始   : 2026-06-04 04:25:00 (UTC)
* 終了   : 2026-06-04 04:35:00 (UTC)
* 現象   : 平常時(9592)に対し 1.084倍(1.04e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→16→…→16→18→13→15
* 開始   : 2026-06-04 06:05:00 (UTC)
* 終了   : 2026-06-04 06:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260604-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→17→…→17→19→18→17
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 06:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→21→22→23→…→22→23→20→21
* 開始   : 2026-06-04 09:30:00 (UTC)
* 終了   : 2026-06-04 09:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 23→22→25→24
* 開始   : 2026-06-04 13:25:00 (UTC)
* 終了   : 2026-06-04 13:40:00 (UTC)
* 現象   : 2026-06-04 13:40:00 (UTC)を境に水準が 15.06から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→9→8→9→8→11→9
* 開始   : 2026-06-04 21:00:00 (UTC)
* 終了   : 2026-06-04 21:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9519→9481→9457→9420→9986→9256→9607→9243→9500
* 開始   : 2026-06-04 21:40:00 (UTC)
* 終了   : 2026-06-04 22:35:00 (UTC)
* 現象   : 2026-06-04 22:35:00 (UTC)を境に水準が 1.021e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→9→6→9→6→7→9
* 開始   : 2026-06-04 21:50:00 (UTC)
* 終了   : 2026-06-04 22:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.5902(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.927σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→8→11→9→7→9→9→10→10
* 開始   : 2026-06-04 23:45:00 (UTC)
* 終了   : 2026-06-05 01:05:00 (UTC)
* 現象   : 2026-06-05 01:05:00 (UTC)を境に水準が 14.92から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→19→15→17→17→18
* 開始   : 2026-06-05 06:30:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 2026-06-05 06:55:00 (UTC)を境に水準が 14.89から14.54へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→20→17→21→20→17→21→19
* 開始   : 2026-06-05 15:20:00 (UTC)
* 終了   : 2026-06-05 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→9→10→12→9→13→11
* 開始   : 2026-06-05 19:40:00 (UTC)
* 終了   : 2026-06-05 19:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host06-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→16→11→10→…→12→9→12→10
* 開始   : 2026-06-05 19:50:00 (UTC)
* 終了   : 2026-06-05 20:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→11→7→10→11→7→10
* 開始   : 2026-06-05 21:05:00 (UTC)
* 終了   : 2026-06-05 21:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.6316(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.844σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-090 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→7→10→9→7→10
* 開始   : 2026-06-05 21:20:00 (UTC)
* 終了   : 2026-06-05 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→10→10→9→9→10→8→9→11
* 開始   : 2026-06-05 22:10:00 (UTC)
* 終了   : 2026-06-05 23:05:00 (UTC)
* 現象   : 2026-06-05 23:05:00 (UTC)を境に水準が 14.87から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9575→9316→8789→9525→…→9525→8755→9818→9838
* 開始   : 2026-06-06 04:20:00 (UTC)
* 終了   : 2026-06-06 04:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-544.4, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260606-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260606-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260606-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260606-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→14→…→15→14→9→14
* 開始   : 2026-06-06 07:40:00 (UTC)
* 終了   : 2026-06-06 16:55:00 (UTC)
* 現象   : 9.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.402, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間
  - EVT-20260606-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間
  - EVT-20260606-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.2 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 9.2 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.2 時間

![EVT-20260606-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→4→…→5→4→6→9
* 開始   : 2026-06-07 00:10:00 (UTC)
* 終了   : 2026-06-07 00:15:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260607-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.08e+04→1.038e+04→1.022e+04→1.088e+04→9875→1.002e+04→1.032e+04→1.051e+04→1.043e+04
* 開始   : 2026-06-07 08:25:00 (UTC)
* 終了   : 2026-06-07 10:15:00 (UTC)
* 現象   : 2026-06-07 10:15:00 (UTC)を境に水準が 9769から9953へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→17→15→12→14→14
* 開始   : 2026-06-07 15:55:00 (UTC)
* 終了   : 2026-06-07 16:20:00 (UTC)
* 現象   : 2026-06-07 16:20:00 (UTC)を境に水準が 11.76から14.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→15→15→13→16→16
* 開始   : 2026-06-07 16:55:00 (UTC)
* 終了   : 2026-06-07 17:20:00 (UTC)
* 現象   : 2026-06-07 17:20:00 (UTC)を境に水準が 11.97から14.59へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→9→12→9
* 開始   : 2026-06-07 22:40:00 (UTC)
* 終了   : 2026-06-07 22:55:00 (UTC)
* 現象   : 2026-06-07 22:55:00 (UTC)を境に水準が 11.72から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.915, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8698→9342→8413→9727→…→8413→9727→9610→9476
* 開始   : 2026-06-08 00:05:00 (UTC)
* 終了   : 2026-06-08 00:10:00 (UTC)
* 現象   : 平常時(9115)に対し 0.9229(8413)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260608-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→17→19→17→…→20→17→15→18
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 20:45:00 (UTC)
* 現象   : 2026-06-08 20:45:00 (UTC)を境に水準が 11.97から14.84へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.485, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2530→2510→2509→2510→2541→2517→2551→2573→2534
* 開始   : 2026-06-08 07:05:00 (UTC)
* 終了   : 2026-06-08 16:15:00 (UTC)
* 現象   : 2026-06-08 16:15:00 (UTC)を境に水準が 2481から2501へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=50.38, 限界=49.88)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=249.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→22→23→22→21→21→20→22→23
* 開始   : 2026-06-09 12:55:00 (UTC)
* 終了   : 2026-06-09 14:05:00 (UTC)
* 現象   : 2026-06-09 14:05:00 (UTC)を境に水準が 15.11から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.499, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.055e+04→1.16e+04→1.037e+04→1.052e+04→…→1.052e+04→1.016e+04→1.035e+04→1.076e+04
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:50:00 (UTC)
* 現象   : 平常時(1.114e+04)に対し 0.9306(1.037e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→16→19→16→15→16→18→15
* 開始   : 2026-06-09 17:25:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 2026-06-09 18:00:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→14→16→9→…→16→9→12→13
* 開始   : 2026-06-09 19:50:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→8→14→11→…→11→7→10→9
* 開始   : 2026-06-09 20:55:00 (UTC)
* 終了   : 2026-06-09 21:05:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.459σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→10→11→12→11→11→11
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 03:30:00 (UTC)
* 現象   : 2026-06-10 03:30:00 (UTC)を境に水準が 14.89から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→17→19→17→19→17→18
* 開始   : 2026-06-10 06:50:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.576σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→16→12→14→12→13
* 開始   : 2026-06-10 19:10:00 (UTC)
* 終了   : 2026-06-10 19:35:00 (UTC)
* 現象   : 2026-06-10 19:35:00 (UTC)を境に水準が 14.89から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→12→8→9→12→8→9
* 開始   : 2026-06-10 21:15:00 (UTC)
* 終了   : 2026-06-10 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→10→8→13→8→13→8→11→8
* 開始   : 2026-06-10 21:20:00 (UTC)
* 終了   : 2026-06-10 21:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9055→9288→1.026e+04→9610→…→9610→1.037e+04→9933→9695
* 開始   : 2026-06-11 04:40:00 (UTC)
* 終了   : 2026-06-11 04:50:00 (UTC)
* 現象   : 平常時(9584)に対し 1.071倍(1.026e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260611-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→13→…→13→17→14→13
* 開始   : 2026-06-11 05:20:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→20→21→20→…→20→22→21→20
* 開始   : 2026-06-11 08:40:00 (UTC)
* 終了   : 2026-06-11 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 23→21→19→22→21→19→22→23
* 開始   : 2026-06-11 13:05:00 (UTC)
* 終了   : 2026-06-11 13:10:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 22→23→18→20→18→20→18→20
* 開始   : 2026-06-11 14:25:00 (UTC)
* 終了   : 2026-06-11 14:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→12→6→7→12→6→7→10
* 開始   : 2026-06-11 21:55:00 (UTC)
* 終了   : 2026-06-11 22:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.5854(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.96σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9812→9555→8846→9497→…→9497→8784→9516→9211
* 開始   : 2026-06-11 22:20:00 (UTC)
* 終了   : 2026-06-11 22:30:00 (UTC)
* 現象   : 平常時(9517)に対し 0.9295(8846)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→9→8→8→10→9→9→8→9
* 開始   : 2026-06-11 22:50:00 (UTC)
* 終了   : 2026-06-11 23:35:00 (UTC)
* 現象   : 2026-06-11 23:35:00 (UTC)を境に水準が 14.9から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→8→…→8→11→8→7
* 開始   : 2026-06-12 00:15:00 (UTC)
* 終了   : 2026-06-12 00:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9365→8690→9955→9541→…→9541→1.004e+04→9506→9415
* 開始   : 2026-06-12 02:30:00 (UTC)
* 終了   : 2026-06-12 02:40:00 (UTC)
* 現象   : 平常時(9213)に対し 1.081倍(9955)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260612-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→10→13→10→13→10
* 開始   : 2026-06-12 02:45:00 (UTC)
* 終了   : 2026-06-12 02:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.901σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260612-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→18→16→16→17→18→17
* 開始   : 2026-06-12 05:10:00 (UTC)
* 終了   : 2026-06-12 07:00:00 (UTC)
* 現象   : 2026-06-12 07:00:00 (UTC)を境に水準が 14.88から14.62へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→16→17→16→17→15→16
* 開始   : 2026-06-12 06:00:00 (UTC)
* 終了   : 2026-06-12 06:10:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260612-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.033e+04→1.03e+04→1.104e+04→1.072e+04→…→1.072e+04→1.115e+04→1.092e+04→1.013e+04
* 開始   : 2026-06-12 06:20:00 (UTC)
* 終了   : 2026-06-12 06:30:00 (UTC)
* 現象   : 平常時(1.026e+04)に対し 1.076倍(1.104e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→20→19→21
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:25:00 (UTC)
* 現象   : 2026-06-12 08:25:00 (UTC)を境に水準が 14.97から14.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.076e+04→1.086e+04→1.004e+04→1.178e+04→…→1.004e+04→1.178e+04→1.092e+04→1.101e+04
* 開始   : 2026-06-12 08:35:00 (UTC)
* 終了   : 2026-06-12 08:40:00 (UTC)
* 現象   : 平常時(1.086e+04)に対し 0.9244(1.004e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 24→22→22→22→21→21→20→22
* 開始   : 2026-06-12 13:30:00 (UTC)
* 終了   : 2026-06-12 14:05:00 (UTC)
* 現象   : 2026-06-12 14:05:00 (UTC)を境に水準が 15から12.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→21→18→22→18→22→18→22→20
* 開始   : 2026-06-12 13:45:00 (UTC)
* 終了   : 2026-06-12 13:55:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260612-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→18→17→14→18→16
* 開始   : 2026-06-12 17:10:00 (UTC)
* 終了   : 2026-06-12 17:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→8→14→10→11→8→14→10
* 開始   : 2026-06-12 20:55:00 (UTC)
* 終了   : 2026-06-12 21:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host02-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-001 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→7→11→10→5→11→10→5→7
* 開始   : 2026-06-13 01:45:00 (UTC)
* 終了   : 2026-06-13 01:55:00 (UTC)
* 現象   : 土曜1時台の平常値(7.851)に対し 11であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.221σ 外れた (平常値=7.851)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→14→…→13→14→12→13
* 開始   : 2026-06-13 04:40:00 (UTC)
* 終了   : 2026-06-13 04:45:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-003 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.067e+04→1.008e+04→9585→1.072e+04→…→9310→1.025e+04→1.022e+04→9908
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 16:55:00 (UTC)
* 現象   : 10.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-778.4, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.6 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.6 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.6 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.2 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.2 時間
  - EVT-20260613-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.6 時間

![EVT-20260613-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→13→12→13→12→13
* 開始   : 2026-06-13 07:20:00 (UTC)
* 終了   : 2026-06-13 07:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(13)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.385, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260613-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→14→…→11→12→14→13
* 開始   : 2026-06-13 08:45:00 (UTC)
* 終了   : 2026-06-13 17:20:00 (UTC)
* 現象   : 8.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.353, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 8.2 時間
  - EVT-20260613-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 8.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間

![EVT-20260613-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-013 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2454→2530→2428→2466→…→2428→2466→2506→2505
* 開始   : 2026-06-13 09:40:00 (UTC)
* 終了   : 2026-06-13 09:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2428)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-53.35, 限界=49.88)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260613-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260613-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-014 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9898→9653→9036→1.003e+04→…→9516→9345→9227→9236
* 開始   : 2026-06-13 18:00:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-551.5, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間
  - EVT-20260613-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間
  - EVT-20260613-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260613-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 1.5 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間
  - EVT-20260613-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.5 時間

![EVT-20260613-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→12→11→8→12→9
* 開始   : 2026-06-13 20:20:00 (UTC)
* 終了   : 2026-06-13 20:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→8→11→8→11
* 開始   : 2026-06-14 19:05:00 (UTC)
* 終了   : 2026-06-14 19:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.679σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260614-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→6→11→9→8→9→8→9→10
* 開始   : 2026-06-15 00:45:00 (UTC)
* 終了   : 2026-06-15 01:40:00 (UTC)
* 現象   : 2026-06-15 01:40:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→18→21→20→…→16→18→15→18
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.412, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2547→2526→2490→2504→2453→2534→2538→2500→2542
* 開始   : 2026-06-15 05:25:00 (UTC)
* 終了   : 2026-06-15 16:20:00 (UTC)
* 現象   : 2026-06-15 16:20:00 (UTC)を境に水準が 2482から2499へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=60.51, 限界=49.88)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=272.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→7→8→6→7→8→6→9→8
* 開始   : 2026-06-15 22:00:00 (UTC)
* 終了   : 2026-06-15 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260615-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 7→8→11→8→11→8→9
* 開始   : 2026-06-16 00:45:00 (UTC)
* 終了   : 2026-06-16 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→9→10→9→10→9→11
* 開始   : 2026-06-16 01:05:00 (UTC)
* 終了   : 2026-06-16 01:35:00 (UTC)
* 現象   : 2026-06-16 01:35:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→11→15→12→11→15→12→14
* 開始   : 2026-06-16 04:50:00 (UTC)
* 終了   : 2026-06-16 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→18→20→18→19
* 開始   : 2026-06-16 07:30:00 (UTC)
* 終了   : 2026-06-16 07:35:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.634σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 22→21→17→23→…→17→23→20→21
* 開始   : 2026-06-16 08:50:00 (UTC)
* 終了   : 2026-06-16 08:55:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→10→…→11→10→14→12
* 開始   : 2026-06-16 19:10:00 (UTC)
* 終了   : 2026-06-16 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→11→11→12→10→10→10
* 開始   : 2026-06-16 20:50:00 (UTC)
* 終了   : 2026-06-16 21:40:00 (UTC)
* 現象   : 2026-06-16 21:40:00 (UTC)を境に水準が 14.94から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→13→10→7→13→12
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:35:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→14→15→14
* 開始   : 2026-06-17 04:50:00 (UTC)
* 終了   : 2026-06-17 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260617-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→14→16→17→14→17
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 06:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→18→19→18→…→19→20→19→18
* 開始   : 2026-06-17 07:25:00 (UTC)
* 終了   : 2026-06-17 07:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 21→20→21→21→22→19→22→23
* 開始   : 2026-06-17 08:25:00 (UTC)
* 終了   : 2026-06-17 09:35:00 (UTC)
* 現象   : 2026-06-17 09:35:00 (UTC)を境に水準が 15.04から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→19→22→23→20→19→22→23→20
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-009 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.053e+04→1.065e+04→1.138e+04→1.156e+04→…→1.138e+04→1.156e+04→1.086e+04→1.019e+04
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 08:50:00 (UTC)
* 現象   : 平常時(1.069e+04)に対し 1.064倍(1.138e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→16→…→16→12→17→16
* 開始   : 2026-06-17 17:05:00 (UTC)
* 終了   : 2026-06-17 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260617-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260617-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→12→…→12→10→12→13
* 開始   : 2026-06-17 19:05:00 (UTC)
* 終了   : 2026-06-17 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→13→…→13→17→15→16
* 開始   : 2026-06-18 05:35:00 (UTC)
* 終了   : 2026-06-18 05:45:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→14→15→16→14→15
* 開始   : 2026-06-18 05:45:00 (UTC)
* 終了   : 2026-06-18 05:50:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→21→24→18→…→24→18→22→21
* 開始   : 2026-06-18 10:00:00 (UTC)
* 終了   : 2026-06-18 10:05:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.113e+04→1.004e+04→9923→9866→…→9923→9866→1.074e+04→1.088e+04
* 開始   : 2026-06-18 17:10:00 (UTC)
* 終了   : 2026-06-18 17:15:00 (UTC)
* 現象   : 平常時(1.065e+04)に対し 0.9321(9923)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.102e+04→1.052e+04→1.015e+04→1.035e+04
* 開始   : 2026-06-18 18:40:00 (UTC)
* 終了   : 2026-06-18 18:55:00 (UTC)
* 現象   : 2026-06-18 18:55:00 (UTC)を境に水準が 1.025e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2314, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→10→13→11→…→11→14→12→11
* 開始   : 2026-06-19 03:45:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→9→13→14→…→13→14→12→11
* 開始   : 2026-06-19 04:05:00 (UTC)
* 終了   : 2026-06-19 04:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→15→17→15→17→15→14
* 開始   : 2026-06-19 05:55:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.146e+04→1.198e+04→1.135e+04→1.144e+04→1.147e+04→1.159e+04
* 開始   : 2026-06-19 10:50:00 (UTC)
* 終了   : 2026-06-19 11:15:00 (UTC)
* 現象   : 2026-06-19 11:15:00 (UTC)を境に水準が 1.024e+04から1.006e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2373, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→23→18→25→…→18→25→21→23
* 開始   : 2026-06-19 11:10:00 (UTC)
* 終了   : 2026-06-19 11:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→14→13→14→…→14→12→17→16
* 開始   : 2026-06-19 17:45:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 2026-06-19 18:25:00 (UTC)を境に水準が 14.98から12.2へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→12→13→12→13→12→14→13
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.7385(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.98σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260619-host10-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→11→9→9→12→12→11
* 開始   : 2026-06-19 21:00:00 (UTC)
* 終了   : 2026-06-19 21:30:00 (UTC)
* 現象   : 2026-06-19 21:30:00 (UTC)を境に水準が 14.9から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.286, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→14→13→14→…→11→12→13→12
* 開始   : 2026-06-20 08:10:00 (UTC)
* 終了   : 2026-06-20 17:30:00 (UTC)
* 現象   : 9.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.502, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.3 時間
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260620-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.3 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間

![EVT-20260620-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2514→2503→2480→2507→…→2480→2496→2506→2526
* 開始   : 2026-06-20 12:10:00 (UTC)
* 終了   : 2026-06-20 12:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-53.3, 限界=49.88)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 15 分
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260620-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2471→2478→2478→2524→…→2524→2494→2510→2495
* 開始   : 2026-06-20 13:50:00 (UTC)
* 終了   : 2026-06-20 14:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2478)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-53.36, 限界=49.88)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 10 分
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260620-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→9→8→10→…→10→9→8→9
* 開始   : 2026-06-20 20:10:00 (UTC)
* 終了   : 2026-06-20 20:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.003e+04→9214→9342→9782→9306→9418→9758
* 開始   : 2026-06-21 01:30:00 (UTC)
* 終了   : 2026-06-21 02:00:00 (UTC)
* 現象   : 2026-06-21 02:00:00 (UTC)を境に水準が 9773から9795へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2580, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→17→16→15
* 開始   : 2026-06-21 09:10:00 (UTC)
* 終了   : 2026-06-21 09:35:00 (UTC)
* 現象   : 2026-06-21 09:35:00 (UTC)を境に水準が 11.84から12.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.873, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.047e+04→1.026e+04→9716→9523→…→9716→9523→1.01e+04→1.032e+04
* 開始   : 2026-06-21 13:30:00 (UTC)
* 終了   : 2026-06-21 13:35:00 (UTC)
* 現象   : 平常時(1.041e+04)に対し 0.9333(9716)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260621-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260621-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→14→…→14→17→14→12
* 開始   : 2026-06-21 16:05:00 (UTC)
* 終了   : 2026-06-21 16:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→10→13→11→10→13→11→13→14
* 開始   : 2026-06-21 16:25:00 (UTC)
* 終了   : 2026-06-21 16:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7059(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.912σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→6→…→12→6→8→10
* 開始   : 2026-06-21 22:35:00 (UTC)
* 終了   : 2026-06-21 22:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→7→8→7→8→7→8
* 開始   : 2026-06-22 00:15:00 (UTC)
* 終了   : 2026-06-22 02:00:00 (UTC)
* 現象   : 2026-06-22 02:00:00 (UTC)を境に水準が 11.69から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.665, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 20→18→22→20→…→19→16→17→16
* 開始   : 2026-06-22 04:00:00 (UTC)
* 終了   : 2026-06-22 19:30:00 (UTC)
* 現象   : 2026-06-22 19:30:00 (UTC)を境に水準が 11.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.845, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.368, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2552→2534→2527→2521→2532→2496→2526→2518→2570
* 開始   : 2026-06-22 08:55:00 (UTC)
* 終了   : 2026-06-22 14:55:00 (UTC)
* 現象   : 2026-06-22 14:55:00 (UTC)を境に水準が 2485から2500へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=53.7, 限界=49.88)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=259.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→12→12→11→12
* 開始   : 2026-06-22 20:45:00 (UTC)
* 終了   : 2026-06-22 21:15:00 (UTC)
* 現象   : 2026-06-22 21:15:00 (UTC)を境に水準が 14.92から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.286, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9752→9614→9523→9182→9490→9740→9770→9593
* 開始   : 2026-06-22 21:15:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 2026-06-22 21:50:00 (UTC)を境に水準が 1.023e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→6→…→12→6→8→9
* 開始   : 2026-06-22 22:10:00 (UTC)
* 終了   : 2026-06-22 22:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→19→…→18→19→18→17
* 開始   : 2026-06-23 06:50:00 (UTC)
* 終了   : 2026-06-23 07:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→16→19→16→19→17→18
* 開始   : 2026-06-23 07:00:00 (UTC)
* 終了   : 2026-06-23 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→15→13→16→14→16→14
* 開始   : 2026-06-23 18:10:00 (UTC)
* 終了   : 2026-06-23 19:00:00 (UTC)
* 現象   : 2026-06-23 19:00:00 (UTC)を境に水準が 14.97から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9717→9341→1.016e+04→1.03e+04→…→1.016e+04→1.03e+04→9772→9738
* 開始   : 2026-06-24 03:40:00 (UTC)
* 終了   : 2026-06-24 03:45:00 (UTC)
* 現象   : 平常時(9394)に対し 1.082倍(1.016e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.291σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→15→13→15→14→15→16
* 開始   : 2026-06-24 04:15:00 (UTC)
* 終了   : 2026-06-24 06:40:00 (UTC)
* 現象   : 2026-06-24 06:40:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.666, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→12→16→12→16→14
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→21→22→23→21→22→23→21
* 開始   : 2026-06-24 09:30:00 (UTC)
* 終了   : 2026-06-24 09:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→20→25→21→…→21→18→22→21
* 開始   : 2026-06-24 10:10:00 (UTC)
* 終了   : 2026-06-24 10:20:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.205倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.98σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260624-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→20→25→20→25→23→22
* 開始   : 2026-06-24 12:25:00 (UTC)
* 終了   : 2026-06-24 12:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→14→16→18→15→14→16
* 開始   : 2026-06-24 17:05:00 (UTC)
* 終了   : 2026-06-24 18:15:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→13→16→17→13→16
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 6→8→11→7→5→11→7→5→8
* 開始   : 2026-06-24 23:50:00 (UTC)
* 終了   : 2026-06-25 00:45:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-076 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260625-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9762→9476→8693→9231→…→9231→9984→9279→9741
* 開始   : 2026-06-25 00:30:00 (UTC)
* 終了   : 2026-06-25 00:40:00 (UTC)
* 現象   : 平常時(9385)に対し 0.9262(8693)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→19→18→17→20
* 開始   : 2026-06-25 06:40:00 (UTC)
* 終了   : 2026-06-25 07:00:00 (UTC)
* 現象   : 2026-06-25 07:00:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.139e+04→1.128e+04→1.195e+04→1.168e+04→1.117e+04→1.157e+04→1.125e+04→1.136e+04→1.154e+04
* 開始   : 2026-06-25 12:40:00 (UTC)
* 終了   : 2026-06-25 13:35:00 (UTC)
* 現象   : 2026-06-25 13:35:00 (UTC)を境に水準が 1.021e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2234, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 24→22→19→24→19→24→19→21→20
* 開始   : 2026-06-25 13:20:00 (UTC)
* 終了   : 2026-06-25 13:30:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→13→17→13→…→13→10→14→11
* 開始   : 2026-06-25 19:10:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-068 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→16→13→16→13→14
* 開始   : 2026-06-26 05:10:00 (UTC)
* 終了   : 2026-06-26 05:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→17→14→15→17→14
* 開始   : 2026-06-26 06:00:00 (UTC)
* 終了   : 2026-06-26 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→23→19→23→19→23→19→22
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:30:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→23→23→22→21
* 開始   : 2026-06-26 13:00:00 (UTC)
* 終了   : 2026-06-26 13:20:00 (UTC)
* 現象   : 2026-06-26 13:20:00 (UTC)を境に水準が 15.01から13.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.833, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 22→22→22→19→21→20→23→22
* 開始   : 2026-06-26 13:35:00 (UTC)
* 終了   : 2026-06-26 14:50:00 (UTC)
* 現象   : 2026-06-26 14:50:00 (UTC)を境に水準が 15.06から12.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→17→20→19→17→20→18
* 開始   : 2026-06-26 15:15:00 (UTC)
* 終了   : 2026-06-26 15:20:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→21→17→20→21→17→20→18
* 開始   : 2026-06-26 15:25:00 (UTC)
* 終了   : 2026-06-26 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→19→12→16→15→19→12→16→15
* 開始   : 2026-06-26 17:40:00 (UTC)
* 終了   : 2026-06-26 17:45:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→12→…→13→12→15→16
* 開始   : 2026-06-26 17:50:00 (UTC)
* 終了   : 2026-06-26 17:55:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.054e+04→9718→9811→1.058e+04→1.022e+04→1.045e+04→9599→1.006e+04→1.004e+04
* 開始   : 2026-06-26 18:45:00 (UTC)
* 終了   : 2026-06-26 19:25:00 (UTC)
* 現象   : 2026-06-26 19:25:00 (UTC)を境に水準が 1.025e+04から9808へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2200, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→13→10→13→10→11
* 開始   : 2026-06-26 19:20:00 (UTC)
* 終了   : 2026-06-26 19:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7101(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.844σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→13→15→13→…→13→12→13→12
* 開始   : 2026-06-27 07:55:00 (UTC)
* 終了   : 2026-06-27 16:55:00 (UTC)
* 現象   : 9.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.396, 限界=4.355)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-002 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.0 時間
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 9.0 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.0 時間

![EVT-20260627-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→9→8→9→10→10
* 開始   : 2026-06-27 23:40:00 (UTC)
* 終了   : 2026-06-28 00:05:00 (UTC)
* 現象   : 2026-06-28 00:05:00 (UTC)を境に水準が 11.82から11.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→6→11→12→…→11→12→9→8
* 開始   : 2026-06-28 00:50:00 (UTC)
* 終了   : 2026-06-28 00:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.008e+04→1.05e+04→1.038e+04→1.035e+04→1.025e+04→1.027e+04
* 開始   : 2026-06-28 06:50:00 (UTC)
* 終了   : 2026-06-28 07:15:00 (UTC)
* 現象   : 2026-06-28 07:15:00 (UTC)を境に水準が 9784から9828へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→18→21→19→…→19→21→18→20
* 開始   : 2026-06-29 00:55:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 11.89から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.677, 限界=4.355)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2562→2557→2555→2544→2529→2531→2530→2546→2533
* 開始   : 2026-06-29 09:25:00 (UTC)
* 終了   : 2026-06-29 16:25:00 (UTC)
* 現象   : 2026-06-29 16:25:00 (UTC)を境に水準が 2483から2498へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=251.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→12→11→8→10→10→10→11→12
* 開始   : 2026-06-29 20:45:00 (UTC)
* 終了   : 2026-06-29 21:25:00 (UTC)
* 現象   : 2026-06-29 21:25:00 (UTC)を境に水準が 14.81から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→9→9→10→8→10→9
* 開始   : 2026-06-30 01:00:00 (UTC)
* 終了   : 2026-06-30 01:45:00 (UTC)
* 現象   : 2026-06-30 01:45:00 (UTC)を境に水準が 14.97から15.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.666, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→12→11→12→11→14
* 開始   : 2026-06-30 18:35:00 (UTC)
* 終了   : 2026-06-30 18:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260630-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9806→9665→9032→8978→…→9032→8978→9957→9050
* 開始   : 2026-06-30 20:45:00 (UTC)
* 終了   : 2026-06-30 20:50:00 (UTC)
* 現象   : 平常時(9708)に対し 0.9304(9032)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-075 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260630-host02-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
