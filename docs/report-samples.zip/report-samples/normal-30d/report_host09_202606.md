# host09 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host09 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 327 (SEVERE: 23, FATAL: 113, WARN: 191, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 23 | 113 | 191 | 327 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:31:28 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp9ol41o8d\normal-use\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-06-30 23:55:00 (UTC) |
| 読み込んだファイル数 | 120 |
| 総レコード数 | 950,400 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260606-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→14→10→13→…→9→13→10→11
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.661)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.044σ 外れた (平常値=14.94)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host09-002 active_connections の推移](charts/EVT-20260606-host09-002.svg)

# イベントID( EVT-20260608-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→15→…→17→16→13→16
* 開始   : 2026-06-08 01:00:00 (UTC)
* 終了   : 2026-06-08 20:55:00 (UTC)
* 現象   : 2026-06-08 20:55:00 (UTC)を境に水準が 11.92から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.928σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.831, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-001 active_connections の推移](charts/EVT-20260608-host09-001.svg)

# イベントID( EVT-20260608-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→13→…→15→13→11→14
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.918, 限界=2.643)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-003 active_connections の推移](charts/EVT-20260608-host09-003.svg)

# イベントID( EVT-20260608-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→14→…→12→13→11→12
* 開始   : 2026-06-08 02:55:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.92から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.778, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-005 active_connections の推移](charts/EVT-20260608-host09-005.svg)

# イベントID( EVT-20260608-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→12→16→14→…→15→12→15→12
* 開始   : 2026-06-08 03:15:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 12から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.714σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.71, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-006 active_connections の推移](charts/EVT-20260608-host09-006.svg)

# イベントID( EVT-20260608-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→14→15→17→…→14→13→12→14
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.86から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.712, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-007 active_connections の推移](charts/EVT-20260608-host09-007.svg)

# イベントID( EVT-20260615-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→15→…→15→16→15→14
* 開始   : 2026-06-15 00:25:00 (UTC)
* 終了   : 2026-06-15 21:15:00 (UTC)
* 現象   : 2026-06-15 21:15:00 (UTC)を境に水準が 11.74から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.528σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.078, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.884, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-001 active_connections の推移](charts/EVT-20260615-host09-001.svg)

# イベントID( EVT-20260615-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→15→13→15→…→14→15→14→12
* 開始   : 2026-06-15 01:15:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.71から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.789, 限界=2.654)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-002 active_connections の推移](charts/EVT-20260615-host09-002.svg)

# イベントID( EVT-20260615-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→17→…→13→15→14→12
* 開始   : 2026-06-15 01:35:00 (UTC)
* 終了   : 2026-06-15 21:25:00 (UTC)
* 現象   : 2026-06-15 21:25:00 (UTC)を境に水準が 11.74から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.962, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-003 active_connections の推移](charts/EVT-20260615-host09-003.svg)

# イベントID( EVT-20260615-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→15→14→16→…→11→15→14→10
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.91から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.855, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.555, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-004 active_connections の推移](charts/EVT-20260615-host09-004.svg)

# イベントID( EVT-20260615-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→15→…→14→15→12→14
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.96から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.134, 限界=2.643)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.371, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-005 active_connections の推移](charts/EVT-20260615-host09-005.svg)

# イベントID( EVT-20260615-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→17→…→14→13→11→12
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.92から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.838, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-006 active_connections の推移](charts/EVT-20260615-host09-006.svg)

# イベントID( EVT-20260622-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→16→15→…→14→13→14→12
* 開始   : 2026-06-22 01:50:00 (UTC)
* 終了   : 2026-06-22 21:15:00 (UTC)
* 現象   : 2026-06-22 21:15:00 (UTC)を境に水準が 11.8から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.734, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-001 active_connections の推移](charts/EVT-20260622-host09-001.svg)

# イベントID( EVT-20260622-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→15→…→14→16→14→15
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 22:10:00 (UTC)
* 現象   : 2026-06-22 22:10:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.698, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-002 active_connections の推移](charts/EVT-20260622-host09-002.svg)

# イベントID( EVT-20260622-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→15→14→13→…→12→14→13→12
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 19:15:00 (UTC)
* 現象   : 2026-06-22 19:15:00 (UTC)を境に水準が 11.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.654)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-003 active_connections の推移](charts/EVT-20260622-host09-003.svg)

# イベントID( EVT-20260622-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→18→16→18→…→14→15→12→15
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.481σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.875, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-004 active_connections の推移](charts/EVT-20260622-host09-004.svg)

# イベントID( EVT-20260622-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→16→…→14→15→12→13
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.75から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.745, 限界=2.643)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.742, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-005 active_connections の推移](charts/EVT-20260622-host09-005.svg)

# イベントID( EVT-20260622-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→14→…→12→13→12→11
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 19:55:00 (UTC)
* 現象   : 2026-06-22 19:55:00 (UTC)を境に水準が 11.96から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.726, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.911, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-006 active_connections の推移](charts/EVT-20260622-host09-006.svg)

# イベントID( EVT-20260629-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→14→…→12→13→11→12
* 開始   : 2026-06-29 01:10:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.81から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.809, 限界=2.671)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-001 active_connections の推移](charts/EVT-20260629-host09-001.svg)

# イベントID( EVT-20260629-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→15→13→14→…→14→13→12→15
* 開始   : 2026-06-29 01:55:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.164, 限界=2.666)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-003 active_connections の推移](charts/EVT-20260629-host09-003.svg)

# イベントID( EVT-20260629-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→15→…→17→14→15→13
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.86から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.768, 限界=2.654)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-004 active_connections の推移](charts/EVT-20260629-host09-004.svg)

# イベントID( EVT-20260629-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→17→…→15→14→15→14
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 21:55:00 (UTC)
* 現象   : 2026-06-29 21:55:00 (UTC)を境に水準が 11.85から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.342σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.799, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-005 active_connections の推移](charts/EVT-20260629-host09-005.svg)

# イベントID( EVT-20260629-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→15→…→14→15→16→15
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 12から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.089, 限界=2.643)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-006 active_connections の推移](charts/EVT-20260629-host09-006.svg)

# イベントID( EVT-20260601-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→18→15→13
* 開始   : 2026-06-01 05:15:00 (UTC)
* 終了   : 2026-06-01 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.49倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host09-002 active_connections の推移](charts/EVT-20260601-host09-002.svg)

# イベントID( EVT-20260601-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→12→16→18→12→16→18→16→14
* 開始   : 2026-06-01 06:30:00 (UTC)
* 終了   : 2026-06-01 07:20:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host09-003 active_connections の推移](charts/EVT-20260601-host09-003.svg)

# イベントID( EVT-20260601-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→19→15→20→18
* 開始   : 2026-06-01 16:00:00 (UTC)
* 終了   : 2026-06-01 16:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host09-005 active_connections の推移](charts/EVT-20260601-host09-005.svg)

# イベントID( EVT-20260601-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→18→14→18→17
* 開始   : 2026-06-01 16:35:00 (UTC)
* 終了   : 2026-06-01 16:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host09-006 active_connections の推移](charts/EVT-20260601-host09-006.svg)

# イベントID( EVT-20260601-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→15→12→16→17
* 開始   : 2026-06-01 17:45:00 (UTC)
* 終了   : 2026-06-01 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host09-007 active_connections の推移](charts/EVT-20260601-host09-007.svg)

# イベントID( EVT-20260601-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→12→10→15→14
* 開始   : 2026-06-01 19:00:00 (UTC)
* 終了   : 2026-06-01 19:10:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host09-009 active_connections の推移](charts/EVT-20260601-host09-009.svg)

# イベントID( EVT-20260602-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→15→15
* 開始   : 2026-06-02 05:25:00 (UTC)
* 終了   : 2026-06-02 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host09-001 active_connections の推移](charts/EVT-20260602-host09-001.svg)

# イベントID( EVT-20260602-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→17→21→17→19
* 開始   : 2026-06-02 07:25:00 (UTC)
* 終了   : 2026-06-02 07:25:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host09-003 active_connections の推移](charts/EVT-20260602-host09-003.svg)

# イベントID( EVT-20260602-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→19→21→20→…→21→20→19→17
* 開始   : 2026-06-02 07:30:00 (UTC)
* 終了   : 2026-06-02 07:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-004 active_connections の推移](charts/EVT-20260602-host09-004.svg)

# イベントID( EVT-20260602-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→11→18→16
* 開始   : 2026-06-02 17:40:00 (UTC)
* 終了   : 2026-06-02 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.6701(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.786σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-010 active_connections の推移](charts/EVT-20260602-host09-010.svg)

# イベントID( EVT-20260602-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→9→9→10→9→7→9→9→9
* 開始   : 2026-06-02 23:25:00 (UTC)
* 終了   : 2026-06-03 00:15:00 (UTC)
* 現象   : 2026-06-03 00:15:00 (UTC)を境に水準が 14.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host09-013 active_connections の推移](charts/EVT-20260602-host09-013.svg)

# イベントID( EVT-20260603-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→15→15
* 開始   : 2026-06-03 05:25:00 (UTC)
* 終了   : 2026-06-03 05:25:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host09-004 active_connections の推移](charts/EVT-20260603-host09-004.svg)

# イベントID( EVT-20260604-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→12→13
* 開始   : 2026-06-04 04:00:00 (UTC)
* 終了   : 2026-06-04 04:00:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-001 active_connections の推移](charts/EVT-20260604-host09-001.svg)

# イベントID( EVT-20260604-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→22→26→22→22
* 開始   : 2026-06-04 11:05:00 (UTC)
* 終了   : 2026-06-04 11:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→14→17→14→14→14→14→15→14
* 開始   : 2026-06-04 18:15:00 (UTC)
* 終了   : 2026-06-04 19:40:00 (UTC)
* 現象   : 2026-06-04 19:40:00 (UTC)を境に水準が 14.96から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→12→15→11→11
* 開始   : 2026-06-05 03:55:00 (UTC)
* 終了   : 2026-06-05 03:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host09-002 active_connections の推移](charts/EVT-20260605-host09-002.svg)

# イベントID( EVT-20260605-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→13→16→12→12
* 開始   : 2026-06-05 04:35:00 (UTC)
* 終了   : 2026-06-05 04:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-003 active_connections の推移](charts/EVT-20260605-host09-003.svg)

# イベントID( EVT-20260605-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→21→16→18→14→16→18→14→17
* 開始   : 2026-06-05 16:30:00 (UTC)
* 終了   : 2026-06-05 16:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host09-008 active_connections の推移](charts/EVT-20260605-host09-008.svg)

# イベントID( EVT-20260605-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→15→12→16→13
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host09-009 active_connections の推移](charts/EVT-20260605-host09-009.svg)

# イベントID( EVT-20260605-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→14→15
* 開始   : 2026-06-05 19:00:00 (UTC)
* 終了   : 2026-06-05 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-010 active_connections の推移](charts/EVT-20260605-host09-010.svg)

# イベントID( EVT-20260605-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→10→6→10→8
* 開始   : 2026-06-05 21:25:00 (UTC)
* 終了   : 2026-06-05 21:25:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-011 active_connections の推移](charts/EVT-20260605-host09-011.svg)

# イベントID( EVT-20260606-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→10→13→10→…→12→11→12→11
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.745, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host09-001 active_connections の推移](charts/EVT-20260606-host09-001.svg)

# イベントID( EVT-20260606-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→10→…→12→11→14→12
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.643)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host09-003 active_connections の推移](charts/EVT-20260606-host09-003.svg)

# イベントID( EVT-20260606-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→13→…→10→11→10→12
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260606-host09-004 active_connections の推移](charts/EVT-20260606-host09-004.svg)

# イベントID( EVT-20260606-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→12→…→11→12→8→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.764, 限界=2.654)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host09-005 active_connections の推移](charts/EVT-20260606-host09-005.svg)

# イベントID( EVT-20260606-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→13→…→13→9→13→12
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host11-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host09-006 active_connections の推移](charts/EVT-20260606-host09-006.svg)

# イベントID( EVT-20260606-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→7→5→9→9
* 開始   : 2026-06-06 21:25:00 (UTC)
* 終了   : 2026-06-06 21:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host09-007 active_connections の推移](charts/EVT-20260606-host09-007.svg)

# イベントID( EVT-20260607-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→11→13→15→…→13→15→12→11
* 開始   : 2026-06-07 05:45:00 (UTC)
* 終了   : 2026-06-07 05:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host09-005 active_connections の推移](charts/EVT-20260607-host09-005.svg)

# イベントID( EVT-20260607-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→15→10→11→15→10→11→15
* 開始   : 2026-06-07 14:55:00 (UTC)
* 終了   : 2026-06-07 15:00:00 (UTC)
* 現象   : 日曜14時台の平常値(15.32)に対し 10であった
* 説明   : ALG-A1: 移動平均からの残差が 3.518σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 4.574σ 外れた (平常値=15.32)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260607-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host09-010 active_connections の推移](charts/EVT-20260607-host09-010.svg)

# イベントID( EVT-20260607-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→13→12
* 開始   : 2026-06-07 18:25:00 (UTC)
* 終了   : 2026-06-07 18:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host09-012 active_connections の推移](charts/EVT-20260607-host09-012.svg)

# イベントID( EVT-20260608-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→17→15→17→…→15→14→11→12
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.654)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-004 active_connections の推移](charts/EVT-20260608-host09-004.svg)

# イベントID( EVT-20260608-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→6→4→8→8
* 開始   : 2026-06-08 23:45:00 (UTC)
* 終了   : 2026-06-08 23:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host09-009 active_connections の推移](charts/EVT-20260608-host09-009.svg)

# イベントID( EVT-20260609-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→17→21→18→19
* 開始   : 2026-06-09 07:05:00 (UTC)
* 終了   : 2026-06-09 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.693σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-004 active_connections の推移](charts/EVT-20260609-host09-004.svg)

# イベントID( EVT-20260609-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→23→18→21→…→21→19→22→20
* 開始   : 2026-06-09 13:35:00 (UTC)
* 終了   : 2026-06-09 13:45:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host09-009 active_connections の推移](charts/EVT-20260609-host09-009.svg)

# イベントID( EVT-20260609-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→20→16→20→19
* 開始   : 2026-06-09 15:00:00 (UTC)
* 終了   : 2026-06-09 15:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host09-010 active_connections の推移](charts/EVT-20260609-host09-010.svg)

# イベントID( EVT-20260609-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→12→8→11→12
* 開始   : 2026-06-09 19:55:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6076(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-013 active_connections の推移](charts/EVT-20260609-host09-013.svg)

# イベントID( EVT-20260610-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→10→…→10→15→10→9
* 開始   : 2026-06-10 03:15:00 (UTC)
* 終了   : 2026-06-10 03:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host09-002 active_connections の推移](charts/EVT-20260610-host09-002.svg)

# イベントID( EVT-20260610-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→11→15→12→…→12→7→12→10
* 開始   : 2026-06-10 03:30:00 (UTC)
* 終了   : 2026-06-10 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.869σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260610-host09-003 active_connections の推移](charts/EVT-20260610-host09-003.svg)

# イベントID( EVT-20260610-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→16→21→19→17
* 開始   : 2026-06-10 07:30:00 (UTC)
* 終了   : 2026-06-10 07:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-007 active_connections の推移](charts/EVT-20260610-host09-007.svg)

# イベントID( EVT-20260610-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→17→14
* 開始   : 2026-06-10 17:15:00 (UTC)
* 終了   : 2026-06-10 17:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6346(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host09-010 active_connections の推移](charts/EVT-20260610-host09-010.svg)

# イベントID( EVT-20260610-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→15→9→12→12
* 開始   : 2026-06-10 19:15:00 (UTC)
* 終了   : 2026-06-10 19:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host09-011 active_connections の推移](charts/EVT-20260610-host09-011.svg)

# イベントID( EVT-20260610-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→11→6→9→8
* 開始   : 2026-06-10 21:55:00 (UTC)
* 終了   : 2026-06-10 21:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host09-013 active_connections の推移](charts/EVT-20260610-host09-013.svg)

# イベントID( EVT-20260611-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→16→…→16→20→19→16
* 開始   : 2026-06-11 06:40:00 (UTC)
* 終了   : 2026-06-11 06:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260611-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-006 active_connections の推移](charts/EVT-20260611-host09-006.svg)

# イベントID( EVT-20260611-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→17→22→19→19
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-008 active_connections の推移](charts/EVT-20260611-host09-008.svg)

# イベントID( EVT-20260611-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→18→21→18→17
* 開始   : 2026-06-11 07:55:00 (UTC)
* 終了   : 2026-06-11 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-009 active_connections の推移](charts/EVT-20260611-host09-009.svg)

# イベントID( EVT-20260611-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→18→19
* 開始   : 2026-06-11 09:00:00 (UTC)
* 終了   : 2026-06-11 09:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→14→15→13→13→14→12→14→13
* 開始   : 2026-06-11 17:45:00 (UTC)
* 終了   : 2026-06-11 19:30:00 (UTC)
* 現象   : 2026-06-11 19:30:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.175σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-013 active_connections の推移](charts/EVT-20260611-host09-013.svg)

# イベントID( EVT-20260612-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→11→15→12→12
* 開始   : 2026-06-12 03:50:00 (UTC)
* 終了   : 2026-06-12 03:50:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.645σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host09-001 active_connections の推移](charts/EVT-20260612-host09-001.svg)

# イベントID( EVT-20260612-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→19→16→21→20
* 開始   : 2026-06-12 15:05:00 (UTC)
* 終了   : 2026-06-12 15:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host09-011 active_connections の推移](charts/EVT-20260612-host09-011.svg)

# イベントID( EVT-20260612-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→11→10
* 開始   : 2026-06-12 20:25:00 (UTC)
* 終了   : 2026-06-12 20:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host09-016 active_connections の推移](charts/EVT-20260612-host09-016.svg)

# イベントID( EVT-20260613-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→7→9
* 開始   : 2026-06-13 00:30:00 (UTC)
* 終了   : 2026-06-13 00:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host09-002 active_connections の推移](charts/EVT-20260613-host09-002.svg)

# イベントID( EVT-20260613-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→11→10→11→12
* 開始   : 2026-06-13 04:45:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.726, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host09-003 active_connections の推移](charts/EVT-20260613-host09-003.svg)

# イベントID( EVT-20260613-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→11→…→10→12→11→9
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.169σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host09-004 active_connections の推移](charts/EVT-20260613-host09-004.svg)

# イベントID( EVT-20260613-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→12→…→10→12→11→10
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.84, 限界=2.643)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host09-005 active_connections の推移](charts/EVT-20260613-host09-005.svg)

# イベントID( EVT-20260613-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→9→…→12→14→11→10
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.701, 限界=2.654)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host09-006 active_connections の推移](charts/EVT-20260613-host09-006.svg)

# イベントID( EVT-20260613-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→11→…→12→11→12→11
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 19:40:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.905, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260613-host09-007 active_connections の推移](charts/EVT-20260613-host09-007.svg)

# イベントID( EVT-20260613-host09-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→13→11→12→…→13→14→13→12
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260613-host09-008 active_connections の推移](charts/EVT-20260613-host09-008.svg)

# イベントID( EVT-20260615-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→9→4→5→…→4→5→7→10
* 開始   : 2026-06-15 23:20:00 (UTC)
* 終了   : 2026-06-15 23:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260615-host09-007 active_connections の推移](charts/EVT-20260615-host09-007.svg)

# イベントID( EVT-20260616-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→15→11→17→15→11→16
* 開始   : 2026-06-16 05:10:00 (UTC)
* 終了   : 2026-06-16 06:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260616-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260616-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host09-001 active_connections の推移](charts/EVT-20260616-host09-001.svg)

# イベントID( EVT-20260617-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 7→6→13→9→9
* 開始   : 2026-06-17 01:40:00 (UTC)
* 終了   : 2026-06-17 01:40:00 (UTC)
* 現象   : 平常時(8)に対し 1.625倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.481σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host09-002 active_connections の推移](charts/EVT-20260617-host09-002.svg)

# イベントID( EVT-20260617-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→11→11
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-003 active_connections の推移](charts/EVT-20260617-host09-003.svg)

# イベントID( EVT-20260617-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→13→16→11→14
* 開始   : 2026-06-17 04:35:00 (UTC)
* 終了   : 2026-06-17 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host09-004 active_connections の推移](charts/EVT-20260617-host09-004.svg)

# イベントID( EVT-20260617-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→19→15→21→19→15→21→18→17
* 開始   : 2026-06-17 07:15:00 (UTC)
* 終了   : 2026-06-17 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-006 active_connections の推移](charts/EVT-20260617-host09-006.svg)

# イベントID( EVT-20260617-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→17→12→15→16
* 開始   : 2026-06-17 17:50:00 (UTC)
* 終了   : 2026-06-17 17:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host09-010 active_connections の推移](charts/EVT-20260617-host09-010.svg)

# イベントID( EVT-20260617-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→14→11→14→14
* 開始   : 2026-06-17 18:25:00 (UTC)
* 終了   : 2026-06-17 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host09-011 active_connections の推移](charts/EVT-20260617-host09-011.svg)

# イベントID( EVT-20260617-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→13→8→11→11
* 開始   : 2026-06-17 19:55:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-012 active_connections の推移](charts/EVT-20260617-host09-012.svg)

# イベントID( EVT-20260618-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→14→17→14→14
* 開始   : 2026-06-18 05:25:00 (UTC)
* 終了   : 2026-06-18 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host09-002 active_connections の推移](charts/EVT-20260618-host09-002.svg)

# イベントID( EVT-20260618-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→15→16→15→14→12→14→14→15
* 開始   : 2026-06-18 18:30:00 (UTC)
* 終了   : 2026-06-18 20:50:00 (UTC)
* 現象   : 2026-06-18 20:50:00 (UTC)を境に水準が 14.92から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.224σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host09-008 active_connections の推移](charts/EVT-20260618-host09-008.svg)

# イベントID( EVT-20260618-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→12→7→9→9
* 開始   : 2026-06-18 20:35:00 (UTC)
* 終了   : 2026-06-18 20:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host09-011 active_connections の推移](charts/EVT-20260618-host09-011.svg)

# イベントID( EVT-20260619-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→13→14
* 開始   : 2026-06-19 04:55:00 (UTC)
* 終了   : 2026-06-19 04:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host09-003 active_connections の推移](charts/EVT-20260619-host09-003.svg)

# イベントID( EVT-20260619-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→17→16→20→17→20→20→16→19
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 07:30:00 (UTC)
* 現象   : 2026-06-19 07:30:00 (UTC)を境に水準が 14.98から14.46へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-005 active_connections の推移](charts/EVT-20260619-host09-005.svg)

# イベントID( EVT-20260619-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→18→16→20→18
* 開始   : 2026-06-19 15:25:00 (UTC)
* 終了   : 2026-06-19 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host09-006 active_connections の推移](charts/EVT-20260619-host09-006.svg)

# イベントID( EVT-20260619-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→18→15→20→19
* 開始   : 2026-06-19 16:05:00 (UTC)
* 終了   : 2026-06-19 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host09-007 active_connections の推移](charts/EVT-20260619-host09-007.svg)

# イベントID( EVT-20260619-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→15→15→17→16→15→15
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 2026-06-19 18:25:00 (UTC)を境に水準が 15.05から12.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.998σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-008 active_connections の推移](charts/EVT-20260619-host09-008.svg)

# イベントID( EVT-20260620-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→7→12→9→8
* 開始   : 2026-06-20 01:20:00 (UTC)
* 終了   : 2026-06-20 01:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host09-001 active_connections の推移](charts/EVT-20260620-host09-001.svg)

# イベントID( EVT-20260620-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→8→…→12→11→13→12
* 開始   : 2026-06-20 03:45:00 (UTC)
* 終了   : 2026-06-20 05:35:00 (UTC)
* 現象   : 1.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.643)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 20 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.8 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.1 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260620-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間

![EVT-20260620-host09-002 active_connections の推移](charts/EVT-20260620-host09-002.svg)

# イベントID( EVT-20260620-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→12→…→11→12→14→10
* 開始   : 2026-06-20 04:55:00 (UTC)
* 終了   : 2026-06-20 20:50:00 (UTC)
* 現象   : 15.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.145, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 14.0 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.6 時間
  - EVT-20260620-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間

![EVT-20260620-host09-003 active_connections の推移](charts/EVT-20260620-host09-003.svg)

# イベントID( EVT-20260620-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→15→13→…→13→12→13→12
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.026, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host09-004 active_connections の推移](charts/EVT-20260620-host09-004.svg)

# イベントID( EVT-20260620-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→11→…→11→14→12→13
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host09-005 active_connections の推移](charts/EVT-20260620-host09-005.svg)

# イベントID( EVT-20260620-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→11→…→9→11→13→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:25:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間

![EVT-20260620-host09-006 active_connections の推移](charts/EVT-20260620-host09-006.svg)

# イベントID( EVT-20260620-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→12→14→12→…→12→11→12→11
* 開始   : 2026-06-20 06:05:00 (UTC)
* 終了   : 2026-06-20 18:10:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.698, 限界=2.654)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間

![EVT-20260620-host09-007 active_connections の推移](charts/EVT-20260620-host09-007.svg)

# イベントID( EVT-20260620-host09-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→13→12→14→…→11→10→11→13
* 開始   : 2026-06-20 07:00:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.643)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260620-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260620-host09-008 active_connections の推移](charts/EVT-20260620-host09-008.svg)

# イベントID( EVT-20260621-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→12→15→12→…→12→14→10→12
* 開始   : 2026-06-21 05:30:00 (UTC)
* 終了   : 2026-06-21 05:40:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260621-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host09-001 active_connections の推移](charts/EVT-20260621-host09-001.svg)

# イベントID( EVT-20260623-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→14→20→18→18
* 開始   : 2026-06-23 06:55:00 (UTC)
* 終了   : 2026-06-23 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host09-003 active_connections の推移](charts/EVT-20260623-host09-003.svg)

# イベントID( EVT-20260624-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→15→18→17→15→18→17→15
* 開始   : 2026-06-24 06:00:00 (UTC)
* 終了   : 2026-06-24 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host09-002 active_connections の推移](charts/EVT-20260624-host09-002.svg)

# イベントID( EVT-20260624-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→18→22→17→19
* 開始   : 2026-06-24 07:35:00 (UTC)
* 終了   : 2026-06-24 07:35:00 (UTC)
* 現象   : 平常時(17)に対し 1.294倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host09-005 active_connections の推移](charts/EVT-20260624-host09-005.svg)

# イベントID( EVT-20260624-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→19→23→20→21
* 開始   : 2026-06-24 08:50:00 (UTC)
* 終了   : 2026-06-24 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→17→20→19
* 開始   : 2026-06-24 14:40:00 (UTC)
* 終了   : 2026-06-24 14:40:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host09-009 active_connections の推移](charts/EVT-20260624-host09-009.svg)

# イベントID( EVT-20260624-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→14→18→14→18→14→15
* 開始   : 2026-06-24 17:30:00 (UTC)
* 終了   : 2026-06-24 18:05:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.111σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260624-host09-012 active_connections の推移](charts/EVT-20260624-host09-012.svg)

# イベントID( EVT-20260624-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→13→11→13→16
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-014 active_connections の推移](charts/EVT-20260624-host09-014.svg)

# イベントID( EVT-20260625-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→12→14→16→14→16→11→14
* 開始   : 2026-06-25 03:30:00 (UTC)
* 終了   : 2026-06-25 04:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分

![EVT-20260625-host09-002 active_connections の推移](charts/EVT-20260625-host09-002.svg)

# イベントID( EVT-20260625-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→12→12
* 開始   : 2026-06-25 03:45:00 (UTC)
* 終了   : 2026-06-25 03:45:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host09-003 active_connections の推移](charts/EVT-20260625-host09-003.svg)

# イベントID( EVT-20260625-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→16→22→20→19
* 開始   : 2026-06-25 08:05:00 (UTC)
* 終了   : 2026-06-25 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host09-006 active_connections の推移](charts/EVT-20260625-host09-006.svg)

# イベントID( EVT-20260625-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 20→19→18→16→…→19→17→20→18
* 開始   : 2026-06-25 15:20:00 (UTC)
* 終了   : 2026-06-25 15:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-011 active_connections の推移](charts/EVT-20260625-host09-011.svg)

# イベントID( EVT-20260625-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→13→14→17→…→13→14→17→14
* 開始   : 2026-06-25 17:20:00 (UTC)
* 終了   : 2026-06-25 17:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-014 active_connections の推移](charts/EVT-20260625-host09-014.svg)

# イベントID( EVT-20260626-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→10→10
* 開始   : 2026-06-26 03:25:00 (UTC)
* 終了   : 2026-06-26 03:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host09-002 active_connections の推移](charts/EVT-20260626-host09-002.svg)

# イベントID( EVT-20260626-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→11→16→11→14
* 開始   : 2026-06-26 04:55:00 (UTC)
* 終了   : 2026-06-26 04:55:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host09-003 active_connections の推移](charts/EVT-20260626-host09-003.svg)

# イベントID( EVT-20260626-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→20→22→17→19→20→22→17→18
* 開始   : 2026-06-26 07:50:00 (UTC)
* 終了   : 2026-06-26 07:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-006 active_connections の推移](charts/EVT-20260626-host09-006.svg)

# イベントID( EVT-20260626-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→19→16
* 開始   : 2026-06-26 08:15:00 (UTC)
* 終了   : 2026-06-26 08:15:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.528σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-007 active_connections の推移](charts/EVT-20260626-host09-007.svg)

# イベントID( EVT-20260626-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→21→25→22→20
* 開始   : 2026-06-26 10:05:00 (UTC)
* 終了   : 2026-06-26 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-009 active_connections の推移](charts/EVT-20260626-host09-009.svg)

# イベントID( EVT-20260626-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→14→10→11→…→10→11→13→11
* 開始   : 2026-06-26 18:50:00 (UTC)
* 終了   : 2026-06-26 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-014 active_connections の推移](charts/EVT-20260626-host09-014.svg)

# イベントID( EVT-20260626-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→11→6→10→10
* 開始   : 2026-06-26 21:20:00 (UTC)
* 終了   : 2026-06-26 21:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.576σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-079 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host09-016 active_connections の推移](charts/EVT-20260626-host09-016.svg)

# イベントID( EVT-20260627-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→13→11→…→12→10→12→9
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.046, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.7 時間
  - EVT-20260627-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260627-host09-002 active_connections の推移](charts/EVT-20260627-host09-002.svg)

# イベントID( EVT-20260627-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→12→…→11→13→14→13
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 18:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.666)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260627-host09-003 active_connections の推移](charts/EVT-20260627-host09-003.svg)

# イベントID( EVT-20260627-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→12→…→11→10→13→10
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.917, 限界=2.661)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host09-004 active_connections の推移](charts/EVT-20260627-host09-004.svg)

# イベントID( EVT-20260627-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→9→10→9→…→12→10→13→12
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.275, 限界=2.654)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.4 時間

![EVT-20260627-host09-005 active_connections の推移](charts/EVT-20260627-host09-005.svg)

# イベントID( EVT-20260627-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→10→13→…→14→13→15→14
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.671)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host09-006 active_connections の推移](charts/EVT-20260627-host09-006.svg)

# イベントID( EVT-20260627-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→10→13→11→…→12→8→10→12
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.954, 限界=2.643)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host09-007 active_connections の推移](charts/EVT-20260627-host09-007.svg)

# イベントID( EVT-20260629-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→16→…→13→12→13→11
* 開始   : 2026-06-29 01:45:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.8から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.661)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-002 active_connections の推移](charts/EVT-20260629-host09-002.svg)

# イベントID( EVT-20260630-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→8→13→10→9
* 開始   : 2026-06-30 02:15:00 (UTC)
* 終了   : 2026-06-30 02:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→21→20→21→21→19→21→20→22
* 開始   : 2026-06-30 08:30:00 (UTC)
* 終了   : 2026-06-30 09:25:00 (UTC)
* 現象   : 2026-06-30 09:25:00 (UTC)を境に水準が 15.02から16.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→24→21→21
* 開始   : 2026-06-30 09:00:00 (UTC)
* 終了   : 2026-06-30 09:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-007 active_connections の推移](charts/EVT-20260630-host09-007.svg)

# イベントID( EVT-20260630-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→17→15
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 17:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host09-010 active_connections の推移](charts/EVT-20260630-host09-010.svg)

# イベントID( EVT-20260601-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→9→12→6→9→12→10
* 開始   : 2026-06-01 02:25:00 (UTC)
* 終了   : 2026-06-01 02:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→22→16→20→…→20→23→20→19
* 開始   : 2026-06-01 09:15:00 (UTC)
* 終了   : 2026-06-01 09:25:00 (UTC)
* 現象   : 平常時(20)に対し 0.8(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→13→12→14→12→14→15
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.404σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→11→…→11→10→13→11
* 開始   : 2026-06-01 19:10:00 (UTC)
* 終了   : 2026-06-01 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260601-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260601-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→12→13→10→12→11
* 開始   : 2026-06-01 19:55:00 (UTC)
* 終了   : 2026-06-01 20:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→13→16→13→16→15
* 開始   : 2026-06-02 05:30:00 (UTC)
* 終了   : 2026-06-02 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-002 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260602-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→19→22→21→…→21→23→20→22
* 開始   : 2026-06-02 09:25:00 (UTC)
* 終了   : 2026-06-02 09:35:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260602-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 23→22→24→25→23→22→24→23→24
* 開始   : 2026-06-02 12:20:00 (UTC)
* 終了   : 2026-06-02 13:55:00 (UTC)
* 現象   : 2026-06-02 13:55:00 (UTC)を境に水準が 14.88から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→22→17→24→22→17→24→22→19
* 開始   : 2026-06-02 14:20:00 (UTC)
* 終了   : 2026-06-02 14:25:00 (UTC)
* 現象   : 平常時(21)に対し 0.8095(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→15→14→16→18→15→14→16→17
* 開始   : 2026-06-02 16:50:00 (UTC)
* 終了   : 2026-06-02 16:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→14→19→14→19→14→15→16
* 開始   : 2026-06-02 17:10:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.7778(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.814σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260602-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→12→11→12→15→12→11→12→13
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 19:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→12→8→11→8→11→8→10→11
* 開始   : 2026-06-02 20:20:00 (UTC)
* 終了   : 2026-06-02 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.844σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host10-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→8→12→10→10→11→12
* 開始   : 2026-06-03 01:25:00 (UTC)
* 終了   : 2026-06-03 03:40:00 (UTC)
* 現象   : 2026-06-03 03:40:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→10→8→9→10→9
* 開始   : 2026-06-03 01:45:00 (UTC)
* 終了   : 2026-06-03 02:10:00 (UTC)
* 現象   : 2026-06-03 02:10:00 (UTC)を境に水準が 15.02から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→14→13→12→14→14→14→16→16
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 2026-06-03 05:15:00 (UTC)を境に水準が 14.85から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→19→16→18→19→16
* 開始   : 2026-06-03 06:45:00 (UTC)
* 終了   : 2026-06-03 06:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→16→18→18→18→19→20→19→20
* 開始   : 2026-06-03 06:55:00 (UTC)
* 終了   : 2026-06-03 08:20:00 (UTC)
* 現象   : 2026-06-03 08:20:00 (UTC)を境に水準が 14.87から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.666, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→17→19→16→17→19→16→18
* 開始   : 2026-06-03 07:00:00 (UTC)
* 終了   : 2026-06-03 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→19→22→18→19→22→18→20
* 開始   : 2026-06-03 09:00:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→20→24→22→20→24→22→23
* 開始   : 2026-06-03 11:05:00 (UTC)
* 終了   : 2026-06-03 11:10:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→22→25→19→…→25→19→24→22
* 開始   : 2026-06-03 12:35:00 (UTC)
* 終了   : 2026-06-03 12:40:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→16→17→20→16→17
* 開始   : 2026-06-03 15:45:00 (UTC)
* 終了   : 2026-06-03 15:50:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→19→19→17→18→18→17→17→16
* 開始   : 2026-06-03 16:15:00 (UTC)
* 終了   : 2026-06-03 17:20:00 (UTC)
* 現象   : 2026-06-03 17:20:00 (UTC)を境に水準が 14.94から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→17→18→20→19→17→19
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:55:00 (UTC)
* 現象   : 2026-06-03 16:55:00 (UTC)を境に水準が 14.92から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.371, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→12→11→10→7→10→9→10→11
* 開始   : 2026-06-03 21:15:00 (UTC)
* 終了   : 2026-06-03 22:05:00 (UTC)
* 現象   : 2026-06-03 22:05:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.559, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→9→7→7→11→10→10
* 開始   : 2026-06-03 23:35:00 (UTC)
* 終了   : 2026-06-04 00:20:00 (UTC)
* 現象   : 2026-06-04 00:20:00 (UTC)を境に水準が 14.96から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.958, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→15→14→15→14→15→12→13
* 開始   : 2026-06-04 04:40:00 (UTC)
* 終了   : 2026-06-04 04:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→19→17→19→19→18→19→21→19
* 開始   : 2026-06-04 07:10:00 (UTC)
* 終了   : 2026-06-04 07:55:00 (UTC)
* 現象   : 2026-06-04 07:55:00 (UTC)を境に水準が 15.02から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.404σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.729, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→21→17→19→20→19→20
* 開始   : 2026-06-04 07:50:00 (UTC)
* 終了   : 2026-06-04 08:20:00 (UTC)
* 現象   : 2026-06-04 08:20:00 (UTC)を境に水準が 14.99から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→19→20→21→22
* 開始   : 2026-06-04 14:50:00 (UTC)
* 終了   : 2026-06-04 15:10:00 (UTC)
* 現象   : 2026-06-04 15:10:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→17→16→14→17→16
* 開始   : 2026-06-04 17:15:00 (UTC)
* 終了   : 2026-06-04 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→17→17→16→15→17→18
* 開始   : 2026-06-04 17:30:00 (UTC)
* 終了   : 2026-06-04 18:20:00 (UTC)
* 現象   : 2026-06-04 18:20:00 (UTC)を境に水準が 14.96から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→18→17→14→18→15
* 開始   : 2026-06-04 17:30:00 (UTC)
* 終了   : 2026-06-04 17:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→7→13→11→12→7→13→11→9
* 開始   : 2026-06-05 03:05:00 (UTC)
* 終了   : 2026-06-05 03:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→15→12→16→15→12→16→14→12
* 開始   : 2026-06-05 04:45:00 (UTC)
* 終了   : 2026-06-05 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→19→19→21→20
* 開始   : 2026-06-05 07:35:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 2026-06-05 08:05:00 (UTC)を境に水準が 14.98から14.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 24→20→22→21→23→23→21→21→23
* 開始   : 2026-06-05 12:40:00 (UTC)
* 終了   : 2026-06-05 14:05:00 (UTC)
* 現象   : 2026-06-05 14:05:00 (UTC)を境に水準が 14.91から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→21→20→21→19→20→21→21→20
* 開始   : 2026-06-05 13:50:00 (UTC)
* 終了   : 2026-06-05 15:25:00 (UTC)
* 現象   : 2026-06-05 15:25:00 (UTC)を境に水準が 15.01から12.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→9→9→10→11→9
* 開始   : 2026-06-05 22:40:00 (UTC)
* 終了   : 2026-06-05 23:10:00 (UTC)
* 現象   : 2026-06-05 23:10:00 (UTC)を境に水準が 14.95から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→6→11→8→5→11→8→5→8
* 開始   : 2026-06-07 00:25:00 (UTC)
* 終了   : 2026-06-07 00:35:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260607-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→7→5→7→…→7→12→9→10
* 開始   : 2026-06-07 02:10:00 (UTC)
* 終了   : 2026-06-07 02:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.404σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→13→10→6→13→10→6→10
* 開始   : 2026-06-07 03:30:00 (UTC)
* 終了   : 2026-06-07 03:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.458倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.881σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260607-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→12→12→13→14→13→11→12→11
* 開始   : 2026-06-07 04:50:00 (UTC)
* 終了   : 2026-06-07 05:45:00 (UTC)
* 現象   : 2026-06-07 05:45:00 (UTC)を境に水準が 11.8から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→13→14→14→13→13→16
* 開始   : 2026-06-07 06:55:00 (UTC)
* 終了   : 2026-06-07 07:25:00 (UTC)
* 現象   : 2026-06-07 07:25:00 (UTC)を境に水準が 11.88から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→13→15→18→17→16
* 開始   : 2026-06-07 09:30:00 (UTC)
* 終了   : 2026-06-07 09:55:00 (UTC)
* 現象   : 2026-06-07 09:55:00 (UTC)を境に水準が 11.87から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→16→17→17→17→18→17
* 開始   : 2026-06-07 11:55:00 (UTC)
* 終了   : 2026-06-07 12:25:00 (UTC)
* 現象   : 2026-06-07 12:25:00 (UTC)を境に水準が 11.83から13.66へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→19→15→17
* 開始   : 2026-06-07 12:10:00 (UTC)
* 終了   : 2026-06-07 12:25:00 (UTC)
* 現象   : 2026-06-07 12:25:00 (UTC)を境に水準が 11.82から13.5へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.783, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→10→15→10→15→10→11→15
* 開始   : 2026-06-07 16:45:00 (UTC)
* 終了   : 2026-06-07 16:55:00 (UTC)
* 現象   : 日曜16時台の平常値(13.19)に対し 10であった
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.217σ 外れた (平常値=13.19)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260607-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260607-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→13→10→12
* 開始   : 2026-06-07 18:50:00 (UTC)
* 終了   : 2026-06-07 19:15:00 (UTC)
* 現象   : 2026-06-07 19:15:00 (UTC)を境に水準が 11.85から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→10→7→8→…→8→6→7→8
* 開始   : 2026-06-07 21:15:00 (UTC)
* 終了   : 2026-06-07 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-011 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260607-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 6→8→11→9→8→11→9→8
* 開始   : 2026-06-08 01:05:00 (UTC)
* 終了   : 2026-06-08 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→11→8→12
* 開始   : 2026-06-08 21:15:00 (UTC)
* 終了   : 2026-06-08 21:30:00 (UTC)
* 現象   : 2026-06-08 21:30:00 (UTC)を境に水準が 15.01から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→13→11→12→10→12
* 開始   : 2026-06-09 03:10:00 (UTC)
* 終了   : 2026-06-09 03:35:00 (UTC)
* 現象   : 2026-06-09 03:35:00 (UTC)を境に水準が 15.11から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→10→16→15→10→16→13→12
* 開始   : 2026-06-09 04:50:00 (UTC)
* 終了   : 2026-06-09 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→17→14→17→14→17→16→14
* 開始   : 2026-06-09 05:25:00 (UTC)
* 終了   : 2026-06-09 05:35:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→19→21→21→23→21→20
* 開始   : 2026-06-09 08:15:00 (UTC)
* 終了   : 2026-06-09 09:40:00 (UTC)
* 現象   : 2026-06-09 09:40:00 (UTC)を境に水準が 14.97から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 20→21→23→21→…→21→24→21→22
* 開始   : 2026-06-09 10:10:00 (UTC)
* 終了   : 2026-06-09 10:20:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.111σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 23→23→21→20→24→23→23→23→22
* 開始   : 2026-06-09 13:10:00 (UTC)
* 終了   : 2026-06-09 15:20:00 (UTC)
* 現象   : 2026-06-09 15:20:00 (UTC)を境に水準が 14.92から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.169σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 24→22→23→21→22→23→21→22→23
* 開始   : 2026-06-09 13:15:00 (UTC)
* 終了   : 2026-06-09 14:05:00 (UTC)
* 現象   : 2026-06-09 14:05:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.154, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→16→13→14→…→14→12→14→15
* 開始   : 2026-06-09 17:50:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→13→12→13→12→13→14
* 開始   : 2026-06-09 18:25:00 (UTC)
* 終了   : 2026-06-09 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→7→6→7→9→7→6→7→9
* 開始   : 2026-06-09 21:40:00 (UTC)
* 終了   : 2026-06-09 21:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 7→9→11→12→…→11→12→9→11
* 開始   : 2026-06-10 02:15:00 (UTC)
* 終了   : 2026-06-10 02:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→16→17→16→18→18→16
* 開始   : 2026-06-10 05:40:00 (UTC)
* 終了   : 2026-06-10 06:45:00 (UTC)
* 現象   : 2026-06-10 06:45:00 (UTC)を境に水準が 14.95から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→18→…→17→18→16→15
* 開始   : 2026-06-10 06:15:00 (UTC)
* 終了   : 2026-06-10 06:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→20→19→18→19→20→19
* 開始   : 2026-06-10 07:20:00 (UTC)
* 終了   : 2026-06-10 07:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→20→22→20→22→20→21
* 開始   : 2026-06-10 09:10:00 (UTC)
* 終了   : 2026-06-10 09:15:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→23→22→21→21→24→22
* 開始   : 2026-06-10 13:35:00 (UTC)
* 終了   : 2026-06-10 14:05:00 (UTC)
* 現象   : 2026-06-10 14:05:00 (UTC)を境に水準が 14.96から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→11→…→11→8→10→11
* 開始   : 2026-06-10 20:35:00 (UTC)
* 終了   : 2026-06-10 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.111σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→7→11→6→…→6→5→9→7
* 開始   : 2026-06-10 23:20:00 (UTC)
* 終了   : 2026-06-10 23:30:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.111σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-083 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260610-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→11→10→7→11→8→11→11→13
* 開始   : 2026-06-11 00:35:00 (UTC)
* 終了   : 2026-06-11 03:00:00 (UTC)
* 現象   : 2026-06-11 03:00:00 (UTC)を境に水準が 14.78から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→10→10
* 開始   : 2026-06-11 01:40:00 (UTC)
* 終了   : 2026-06-11 01:50:00 (UTC)
* 現象   : 2026-06-11 01:50:00 (UTC)を境に水準が 14.87から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.096, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→13→11→14→13
* 開始   : 2026-06-11 04:10:00 (UTC)
* 終了   : 2026-06-11 04:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→13→14→12→13→14→12
* 開始   : 2026-06-11 04:20:00 (UTC)
* 終了   : 2026-06-11 04:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→12→16→12→16→14→13
* 開始   : 2026-06-11 05:05:00 (UTC)
* 終了   : 2026-06-11 05:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260611-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→17→14→17→20→14→17→20→19
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→20→18→20→19→17→17→20
* 開始   : 2026-06-11 15:30:00 (UTC)
* 終了   : 2026-06-11 16:45:00 (UTC)
* 現象   : 2026-06-11 16:45:00 (UTC)を境に水準が 14.93から15.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.177, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→13→15→16→13→15
* 開始   : 2026-06-11 17:40:00 (UTC)
* 終了   : 2026-06-11 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.7647(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→14→13→14→17→14→13→14→17
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 18:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→8→10→10→10→8→9→8
* 開始   : 2026-06-11 23:35:00 (UTC)
* 終了   : 2026-06-12 00:10:00 (UTC)
* 現象   : 2026-06-12 00:10:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→9→9→11→8→10→9→10→9
* 開始   : 2026-06-11 23:45:00 (UTC)
* 終了   : 2026-06-12 00:30:00 (UTC)
* 現象   : 2026-06-12 00:30:00 (UTC)を境に水準が 14.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.958, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→13→15→13→15→13
* 開始   : 2026-06-12 04:40:00 (UTC)
* 終了   : 2026-06-12 04:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→18→18→18→18→18→18→20→20
* 開始   : 2026-06-12 07:10:00 (UTC)
* 終了   : 2026-06-12 07:55:00 (UTC)
* 現象   : 2026-06-12 07:55:00 (UTC)を境に水準が 15.05から14.44へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.729, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→18→20→19→…→19→21→17→19
* 開始   : 2026-06-12 07:55:00 (UTC)
* 終了   : 2026-06-12 08:05:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.117σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260612-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→19→22→17→…→17→23→19→20
* 開始   : 2026-06-12 09:05:00 (UTC)
* 終了   : 2026-06-12 09:15:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 22→20→24→17→…→24→17→19→23
* 開始   : 2026-06-12 09:15:00 (UTC)
* 終了   : 2026-06-12 09:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 25→21→23→23→21→23→23→22→24
* 開始   : 2026-06-12 11:35:00 (UTC)
* 終了   : 2026-06-12 12:55:00 (UTC)
* 現象   : 2026-06-12 12:55:00 (UTC)を境に水準が 15.01から13.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 20→21→25→20→21→25→20→23
* 開始   : 2026-06-12 12:20:00 (UTC)
* 終了   : 2026-06-12 12:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→20→20→18→23→21
* 開始   : 2026-06-12 14:25:00 (UTC)
* 終了   : 2026-06-12 14:50:00 (UTC)
* 現象   : 2026-06-12 14:50:00 (UTC)を境に水準が 15.16から12.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 23→21→18→19→…→19→17→20→18
* 開始   : 2026-06-12 15:05:00 (UTC)
* 終了   : 2026-06-12 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→16→17→19→16→17→16
* 開始   : 2026-06-12 16:40:00 (UTC)
* 終了   : 2026-06-12 16:45:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→16→14→13→…→16→13→15→14
* 開始   : 2026-06-12 17:50:00 (UTC)
* 終了   : 2026-06-12 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→15→13→15→13→14→13
* 開始   : 2026-06-12 18:10:00 (UTC)
* 終了   : 2026-06-12 18:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→12→11→12→…→12→11→13→12
* 開始   : 2026-06-12 18:45:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→11→9→11
* 開始   : 2026-06-13 00:20:00 (UTC)
* 終了   : 2026-06-13 00:45:00 (UTC)
* 現象   : 2026-06-13 00:45:00 (UTC)を境に水準が 15.04から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260613-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host09-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→8→10
* 開始   : 2026-06-13 19:55:00 (UTC)
* 終了   : 2026-06-13 20:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.782, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260613-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260613-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→7→11→7→11→7→11→9
* 開始   : 2026-06-14 00:45:00 (UTC)
* 終了   : 2026-06-14 00:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→14→17→15→14→17→15
* 開始   : 2026-06-14 08:50:00 (UTC)
* 終了   : 2026-06-14 08:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→17→14→15→17→14→13
* 開始   : 2026-06-14 08:50:00 (UTC)
* 終了   : 2026-06-14 08:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.58σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→8→10→…→10→7→10→9
* 開始   : 2026-06-14 20:15:00 (UTC)
* 終了   : 2026-06-14 20:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260614-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260614-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→12→13→7→8→12→13→7→8
* 開始   : 2026-06-14 20:45:00 (UTC)
* 終了   : 2026-06-14 20:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260614-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→5→12→9→10→5→12→9
* 開始   : 2026-06-14 21:40:00 (UTC)
* 終了   : 2026-06-14 21:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.47σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→16→17→19→16→17
* 開始   : 2026-06-16 06:55:00 (UTC)
* 終了   : 2026-06-16 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→16→20→17→21→20→17→21→18
* 開始   : 2026-06-16 07:40:00 (UTC)
* 終了   : 2026-06-16 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→22→23→22→23
* 開始   : 2026-06-16 09:25:00 (UTC)
* 終了   : 2026-06-16 09:45:00 (UTC)
* 現象   : 2026-06-16 09:45:00 (UTC)を境に水準が 15.01から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→15→19→14→15→19→14→16→17
* 開始   : 2026-06-16 16:50:00 (UTC)
* 終了   : 2026-06-16 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.47σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260616-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→14→15→17→14→17→15
* 開始   : 2026-06-16 17:10:00 (UTC)
* 終了   : 2026-06-16 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→16→14→16→14→16→15
* 開始   : 2026-06-16 17:25:00 (UTC)
* 終了   : 2026-06-16 17:30:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→13→…→14→13→15→16
* 開始   : 2026-06-16 17:40:00 (UTC)
* 終了   : 2026-06-16 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260616-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→14→10→11→10→11→10→12→11
* 開始   : 2026-06-16 19:40:00 (UTC)
* 終了   : 2026-06-16 19:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260616-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→8→9→9→8→9→9→8→8
* 開始   : 2026-06-16 22:35:00 (UTC)
* 終了   : 2026-06-16 23:40:00 (UTC)
* 現象   : 2026-06-16 23:40:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 7→6→10→9→6→10→9
* 開始   : 2026-06-17 00:55:00 (UTC)
* 終了   : 2026-06-17 01:00:00 (UTC)
* 現象   : 平常時(6.917)に対し 1.446倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→18→17→19→18→17→19→18→14
* 開始   : 2026-06-17 06:45:00 (UTC)
* 終了   : 2026-06-17 06:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 20→20→20→22→21→20→20→21→21
* 開始   : 2026-06-17 08:20:00 (UTC)
* 終了   : 2026-06-17 09:30:00 (UTC)
* 現象   : 2026-06-17 09:30:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.653, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→18→21→20→18→21→20
* 開始   : 2026-06-17 14:35:00 (UTC)
* 終了   : 2026-06-17 14:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→19→16→15→…→16→15→17→18
* 開始   : 2026-06-17 15:40:00 (UTC)
* 終了   : 2026-06-17 15:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→8→8→10→8→6→8→9→9
* 開始   : 2026-06-17 23:35:00 (UTC)
* 終了   : 2026-06-18 00:35:00 (UTC)
* 現象   : 2026-06-18 00:35:00 (UTC)を境に水準が 14.91から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.546, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→13→15→11→16→15→11→16→12
* 開始   : 2026-06-18 04:25:00 (UTC)
* 終了   : 2026-06-18 06:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260618-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260618-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→19→16→19→19
* 開始   : 2026-06-18 06:35:00 (UTC)
* 終了   : 2026-06-18 06:55:00 (UTC)
* 現象   : 2026-06-18 06:55:00 (UTC)を境に水準が 14.99から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→21→17→22→21→17→22→19
* 開始   : 2026-06-18 08:25:00 (UTC)
* 終了   : 2026-06-18 08:35:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→21→21→21→19→20→20→22
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 15:30:00 (UTC)
* 現象   : 2026-06-18 15:30:00 (UTC)を境に水準が 15.04から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→21→21→20→20→19→19→19→19
* 開始   : 2026-06-18 15:05:00 (UTC)
* 終了   : 2026-06-18 15:50:00 (UTC)
* 現象   : 2026-06-18 15:50:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→17→…→17→14→17→15
* 開始   : 2026-06-18 17:00:00 (UTC)
* 終了   : 2026-06-18 17:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.521σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260618-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→12→8→11→12→8→11→12
* 開始   : 2026-06-18 20:25:00 (UTC)
* 終了   : 2026-06-18 20:30:00 (UTC)
* 現象   : 平常時(12)に対し 0.6667(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.822σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→11→9→11→8→9→11→8→10
* 開始   : 2026-06-18 20:35:00 (UTC)
* 終了   : 2026-06-18 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→11→9→8→10
* 開始   : 2026-06-19 01:10:00 (UTC)
* 終了   : 2026-06-19 01:30:00 (UTC)
* 現象   : 2026-06-19 01:30:00 (UTC)を境に水準が 14.99から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.979, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→14
* 開始   : 2026-06-19 03:40:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 2026-06-19 03:55:00 (UTC)を境に水準が 15.1から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→19→18→17→18→19→18→19→19
* 開始   : 2026-06-19 06:40:00 (UTC)
* 終了   : 2026-06-19 07:45:00 (UTC)
* 現象   : 2026-06-19 07:45:00 (UTC)を境に水準が 14.97から14.55へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.404σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→11→…→12→11→10→13
* 開始   : 2026-06-19 18:30:00 (UTC)
* 終了   : 2026-06-19 18:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→11→12→11→10
* 開始   : 2026-06-19 20:30:00 (UTC)
* 終了   : 2026-06-19 21:25:00 (UTC)
* 現象   : 2026-06-19 21:25:00 (UTC)を境に水準が 15.03から11.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→7→8→12→7→8→10
* 開始   : 2026-06-19 21:15:00 (UTC)
* 終了   : 2026-06-19 22:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→11→9→8→9→8→9→10→11
* 開始   : 2026-06-20 23:20:00 (UTC)
* 終了   : 2026-06-21 00:20:00 (UTC)
* 現象   : 2026-06-21 00:20:00 (UTC)を境に水準が 11.83から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→16→14→17→16→15
* 開始   : 2026-06-21 09:10:00 (UTC)
* 終了   : 2026-06-21 09:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→16→14→16→14→16→14→16→14
* 開始   : 2026-06-21 14:40:00 (UTC)
* 終了   : 2026-06-21 15:55:00 (UTC)
* 現象   : 2026-06-21 15:55:00 (UTC)を境に水準が 11.81から14.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.367, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→15→14→14→12→13→14→13
* 開始   : 2026-06-21 16:40:00 (UTC)
* 終了   : 2026-06-21 17:15:00 (UTC)
* 現象   : 2026-06-21 17:15:00 (UTC)を境に水準が 11.74から14.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→7→8→9→8→7→10→10→12
* 開始   : 2026-06-21 23:55:00 (UTC)
* 終了   : 2026-06-22 00:35:00 (UTC)
* 現象   : 2026-06-22 00:35:00 (UTC)を境に水準が 11.85から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→12→16→11→16→11→16→12→13
* 開始   : 2026-06-23 05:15:00 (UTC)
* 終了   : 2026-06-23 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→14→16→16→16
* 開始   : 2026-06-23 05:45:00 (UTC)
* 終了   : 2026-06-23 06:05:00 (UTC)
* 現象   : 2026-06-23 06:05:00 (UTC)を境に水準が 14.88から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→19→23→24→…→23→24→21→20
* 開始   : 2026-06-23 09:35:00 (UTC)
* 終了   : 2026-06-23 09:40:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→20→23→24→20→23→24→20→22
* 開始   : 2026-06-23 10:25:00 (UTC)
* 終了   : 2026-06-23 10:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→23→23
* 開始   : 2026-06-23 10:55:00 (UTC)
* 終了   : 2026-06-23 11:15:00 (UTC)
* 現象   : 2026-06-23 11:15:00 (UTC)を境に水準が 14.97から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.618, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→14→12→15→12→15→12→13→14
* 開始   : 2026-06-23 18:25:00 (UTC)
* 終了   : 2026-06-23 19:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260623-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260623-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→13→15→13→15→13
* 開始   : 2026-06-23 18:40:00 (UTC)
* 終了   : 2026-06-23 19:05:00 (UTC)
* 現象   : 2026-06-23 19:05:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→10→8→10→8→10
* 開始   : 2026-06-23 20:45:00 (UTC)
* 終了   : 2026-06-23 20:50:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→5→8→5→8→5→8→6
* 開始   : 2026-06-24 00:00:00 (UTC)
* 終了   : 2026-06-24 00:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.5769(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→17→18→18→17→19→16→20→18
* 開始   : 2026-06-24 06:45:00 (UTC)
* 終了   : 2026-06-24 07:40:00 (UTC)
* 現象   : 2026-06-24 07:40:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→19→20→16→20→16→20→18→16
* 開始   : 2026-06-24 07:25:00 (UTC)
* 終了   : 2026-06-24 07:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260624-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→20→21→16→21→16→21
* 開始   : 2026-06-24 08:20:00 (UTC)
* 終了   : 2026-06-24 08:30:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260624-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→21→23→20→…→20→24→21→20
* 開始   : 2026-06-24 09:30:00 (UTC)
* 終了   : 2026-06-24 09:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260624-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→18→16→20→16→20→16→17→18
* 開始   : 2026-06-24 16:05:00 (UTC)
* 終了   : 2026-06-24 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→18→17→19
* 開始   : 2026-06-24 16:40:00 (UTC)
* 終了   : 2026-06-24 17:05:00 (UTC)
* 現象   : 2026-06-24 17:05:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→16→…→16→12→15→16
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:45:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→12
* 開始   : 2026-06-24 20:30:00 (UTC)
* 終了   : 2026-06-24 20:45:00 (UTC)
* 現象   : 2026-06-24 20:45:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.148, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→9→9→9→9
* 開始   : 2026-06-25 00:00:00 (UTC)
* 終了   : 2026-06-25 00:20:00 (UTC)
* 現象   : 2026-06-25 00:20:00 (UTC)を境に水準が 14.92から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.618, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→10→…→10→15→11→10
* 開始   : 2026-06-25 04:00:00 (UTC)
* 終了   : 2026-06-25 04:10:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→13→17→15→17
* 開始   : 2026-06-25 05:15:00 (UTC)
* 終了   : 2026-06-25 05:45:00 (UTC)
* 現象   : 2026-06-25 05:45:00 (UTC)を境に水準が 15から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→23→19→23→21→22→22→22
* 開始   : 2026-06-25 09:20:00 (UTC)
* 終了   : 2026-06-25 10:15:00 (UTC)
* 現象   : 2026-06-25 10:15:00 (UTC)を境に水準が 15.05から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.883, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→22→23→22→23→22→19
* 開始   : 2026-06-25 10:05:00 (UTC)
* 終了   : 2026-06-25 10:10:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 23→24→22→23→24
* 開始   : 2026-06-25 10:05:00 (UTC)
* 終了   : 2026-06-25 11:20:00 (UTC)
* 現象   : 2026-06-25 11:20:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→18→19→17→18→19→17→20→18
* 開始   : 2026-06-25 14:35:00 (UTC)
* 終了   : 2026-06-25 14:45:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→22→17→19→…→19→16→19→17
* 開始   : 2026-06-25 15:55:00 (UTC)
* 終了   : 2026-06-25 16:05:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→15→17→15→15
* 開始   : 2026-06-25 17:00:00 (UTC)
* 終了   : 2026-06-25 18:30:00 (UTC)
* 現象   : 2026-06-25 18:30:00 (UTC)を境に水準が 14.92から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.911, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→17
* 開始   : 2026-06-25 17:55:00 (UTC)
* 終了   : 2026-06-25 18:00:00 (UTC)
* 現象   : 2026-06-25 18:00:00 (UTC)を境に水準が 15.04から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.647, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→10→13
* 開始   : 2026-06-25 19:35:00 (UTC)
* 終了   : 2026-06-25 19:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→12→9→8→9→9→11
* 開始   : 2026-06-26 00:15:00 (UTC)
* 終了   : 2026-06-26 00:45:00 (UTC)
* 現象   : 2026-06-26 00:45:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→12→17→14→12→17→14
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 05:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.58σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→20→17→20→17→20→17→19
* 開始   : 2026-06-26 07:35:00 (UTC)
* 終了   : 2026-06-26 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 21→21→19→21→23→22→23→20→24
* 開始   : 2026-06-26 09:00:00 (UTC)
* 終了   : 2026-06-26 09:50:00 (UTC)
* 現象   : 2026-06-26 09:50:00 (UTC)を境に水準が 15.01から13.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.679, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 24→24→23→23→23→22→23→23→23
* 開始   : 2026-06-26 11:15:00 (UTC)
* 終了   : 2026-06-26 12:10:00 (UTC)
* 現象   : 2026-06-26 12:10:00 (UTC)を境に水準が 15.04から13.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.883, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→22→23→21→19→20→20→22
* 開始   : 2026-06-26 14:20:00 (UTC)
* 終了   : 2026-06-26 14:55:00 (UTC)
* 現象   : 2026-06-26 14:55:00 (UTC)を境に水準が 15.07から12.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→19→17→18→20
* 開始   : 2026-06-26 16:55:00 (UTC)
* 終了   : 2026-06-26 17:50:00 (UTC)
* 現象   : 2026-06-26 17:50:00 (UTC)を境に水準が 15.08から12.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.618, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→15→16→13→15→13
* 開始   : 2026-06-26 17:30:00 (UTC)
* 終了   : 2026-06-26 17:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→10→13→10→13→10→12
* 開始   : 2026-06-26 19:35:00 (UTC)
* 終了   : 2026-06-26 19:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260626-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→9→11→8→10→10
* 開始   : 2026-06-26 22:35:00 (UTC)
* 終了   : 2026-06-26 23:10:00 (UTC)
* 現象   : 2026-06-26 23:10:00 (UTC)を境に水準が 14.9から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host09-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→9→13→9→12→13→9→12→9
* 開始   : 2026-06-27 03:25:00 (UTC)
* 終了   : 2026-06-27 03:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260627-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→8→12→8→12→8→9
* 開始   : 2026-06-28 02:45:00 (UTC)
* 終了   : 2026-06-28 02:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→13→13→11→14
* 開始   : 2026-06-28 05:50:00 (UTC)
* 終了   : 2026-06-28 06:10:00 (UTC)
* 現象   : 2026-06-28 06:10:00 (UTC)を境に水準が 11.73から12.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→16→16→16
* 開始   : 2026-06-28 14:30:00 (UTC)
* 終了   : 2026-06-28 14:55:00 (UTC)
* 現象   : 2026-06-28 14:55:00 (UTC)を境に水準が 11.75から14.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→13→13→14→11→10→11→13→11
* 開始   : 2026-06-28 17:55:00 (UTC)
* 終了   : 2026-06-28 19:05:00 (UTC)
* 現象   : 2026-06-28 19:05:00 (UTC)を境に水準が 11.75から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→10→7→8→7→8→7→10
* 開始   : 2026-06-28 20:20:00 (UTC)
* 終了   : 2026-06-28 20:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260628-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→12→8→6→12→8→6→9→10
* 開始   : 2026-06-30 02:25:00 (UTC)
* 終了   : 2026-06-30 02:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→10→…→10→14→10→11
* 開始   : 2026-06-30 03:55:00 (UTC)
* 終了   : 2026-06-30 04:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→15→16→17→…→16→17→12→15
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 05:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→15→18→17→15→18→17
* 開始   : 2026-06-30 06:00:00 (UTC)
* 終了   : 2026-06-30 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→22→…→22→25→23→21
* 開始   : 2026-06-30 10:40:00 (UTC)
* 終了   : 2026-06-30 10:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→19→16→19→18→18→21→19→19
* 開始   : 2026-06-30 15:50:00 (UTC)
* 終了   : 2026-06-30 16:30:00 (UTC)
* 現象   : 2026-06-30 16:30:00 (UTC)を境に水準が 14.93から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→14→11→14→11→14→11→13
* 開始   : 2026-06-30 19:10:00 (UTC)
* 終了   : 2026-06-30 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→12→12→14
* 開始   : 2026-06-30 19:35:00 (UTC)
* 終了   : 2026-06-30 20:05:00 (UTC)
* 現象   : 2026-06-30 20:05:00 (UTC)を境に水準が 14.92から9.213へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→11→12→12→12→12→12→10→14
* 開始   : 2026-06-30 19:45:00 (UTC)
* 終了   : 2026-06-30 20:50:00 (UTC)
* 現象   : 2026-06-30 20:50:00 (UTC)を境に水準が 15.03から8.789へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.742, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→11→9→12→12→9→12
* 開始   : 2026-06-30 21:05:00 (UTC)
* 終了   : 2026-06-30 21:45:00 (UTC)
* 現象   : 2026-06-30 21:45:00 (UTC)を境に水準が 15.07から8.296へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 18 |

### 5.3 失敗したアルゴリズム

(なし)
