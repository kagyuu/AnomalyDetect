# host10 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host10 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 296 (SEVERE: 20, FATAL: 122, WARN: 154, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 122 | 154 | 296 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→15→…→14→13→14→13
* 開始   : 2026-06-08 02:25:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.85から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.618σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.694, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-002 active_connections の推移](charts/EVT-20260608-host10-002.svg)

# イベントID( EVT-20260608-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→16→…→13→16→13→15
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.83から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.029, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-003 active_connections の推移](charts/EVT-20260608-host10-003.svg)

# イベントID( EVT-20260608-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→13→19→15→…→16→15→12→13
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:30:00 (UTC)
* 現象   : 2026-06-08 20:30:00 (UTC)を境に水準が 11.87から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.827, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-005 active_connections の推移](charts/EVT-20260608-host10-005.svg)

# イベントID( EVT-20260608-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→17→16→15→…→15→12→13→12
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 21:45:00 (UTC)
* 現象   : 2026-06-08 21:45:00 (UTC)を境に水準が 11.82から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.822, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.658, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-006 active_connections の推移](charts/EVT-20260608-host10-006.svg)

# イベントID( EVT-20260608-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→15→…→13→12→14→12
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.93から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.819, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-007 active_connections の推移](charts/EVT-20260608-host10-007.svg)

# イベントID( EVT-20260615-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→17→…→14→15→12→13
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 11.91から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.09, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-001 active_connections の推移](charts/EVT-20260615-host10-001.svg)

# イベントID( EVT-20260615-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→18→17→16→…→13→15→14→13
* 開始   : 2026-06-15 02:10:00 (UTC)
* 終了   : 2026-06-15 19:00:00 (UTC)
* 現象   : 2026-06-15 19:00:00 (UTC)を境に水準が 11.97から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.826, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.045, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-002 active_connections の推移](charts/EVT-20260615-host10-002.svg)

# イベントID( EVT-20260615-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→14→15→14→…→15→13→11→14
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 19:10:00 (UTC)
* 現象   : 2026-06-15 19:10:00 (UTC)を境に水準が 11.88から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.729, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-003 active_connections の推移](charts/EVT-20260615-host10-003.svg)

# イベントID( EVT-20260615-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→13→…→13→12→10→13
* 開始   : 2026-06-15 02:50:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 11.88から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.694, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-004 active_connections の推移](charts/EVT-20260615-host10-004.svg)

# イベントID( EVT-20260615-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→16→…→12→15→12→14
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.84から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.737, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-006 active_connections の推移](charts/EVT-20260615-host10-006.svg)

# イベントID( EVT-20260622-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→14→15→14→…→15→14→11→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.82から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.497, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-002 active_connections の推移](charts/EVT-20260622-host10-002.svg)

# イベントID( EVT-20260622-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→16→15→13→…→15→13→15→14
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 21:15:00 (UTC)
* 現象   : 2026-06-22 21:15:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.777, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.363, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-003 active_connections の推移](charts/EVT-20260622-host10-003.svg)

# イベントID( EVT-20260622-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→12→…→12→14→12→14
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.78から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.667, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-004 active_connections の推移](charts/EVT-20260622-host10-004.svg)

# イベントID( EVT-20260622-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→14→…→15→13→11→12
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.196, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-005 active_connections の推移](charts/EVT-20260622-host10-005.svg)

# イベントID( EVT-20260622-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→12→…→15→16→15→13
* 開始   : 2026-06-22 04:30:00 (UTC)
* 終了   : 2026-06-22 19:40:00 (UTC)
* 現象   : 2026-06-22 19:40:00 (UTC)を境に水準が 12.03から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.856, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-006 active_connections の推移](charts/EVT-20260622-host10-006.svg)

# イベントID( EVT-20260629-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→14→…→14→15→13→14
* 開始   : 2026-06-29 01:15:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.92から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.158, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-001 active_connections の推移](charts/EVT-20260629-host10-001.svg)

# イベントID( EVT-20260629-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→16→15→18→…→14→12→13→14
* 開始   : 2026-06-29 02:25:00 (UTC)
* 終了   : 2026-06-29 20:45:00 (UTC)
* 現象   : 2026-06-29 20:45:00 (UTC)を境に水準が 11.72から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.713, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.417, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-003 active_connections の推移](charts/EVT-20260629-host10-003.svg)

# イベントID( EVT-20260629-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→16→14→17→…→15→14→15→14
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 22:00:00 (UTC)
* 現象   : 2026-06-29 22:00:00 (UTC)を境に水準が 12.01から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.771, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-004 active_connections の推移](charts/EVT-20260629-host10-004.svg)

# イベントID( EVT-20260629-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→17→…→13→11→13→12
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.84から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.974, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-005 active_connections の推移](charts/EVT-20260629-host10-005.svg)

# イベントID( EVT-20260629-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→16→17→13→…→15→14→13→14
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.93から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.822, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-006 active_connections の推移](charts/EVT-20260629-host10-006.svg)

# イベントID( EVT-20260601-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→7→12→7→10
* 開始   : 2026-06-01 00:25:00 (UTC)
* 終了   : 2026-06-01 00:25:00 (UTC)
* 現象   : 平常時(7.6)に対し 1.579倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-004 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260601-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→21→25→22→20
* 開始   : 2026-06-01 10:50:00 (UTC)
* 終了   : 2026-06-01 10:50:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260601-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 23→24→18→20→23
* 開始   : 2026-06-01 13:30:00 (UTC)
* 終了   : 2026-06-01 13:30:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→16→14
* 開始   : 2026-06-01 18:30:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→12→11
* 開始   : 2026-06-01 20:50:00 (UTC)
* 終了   : 2026-06-01 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→7→4→6→6
* 開始   : 2026-06-01 23:30:00 (UTC)
* 終了   : 2026-06-01 23:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→7→13→11→10
* 開始   : 2026-06-02 02:45:00 (UTC)
* 終了   : 2026-06-02 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→13→19→17→16
* 開始   : 2026-06-02 05:55:00 (UTC)
* 終了   : 2026-06-02 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.399倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.803σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→15→13→14→17→15→13→14→17
* 開始   : 2026-06-02 17:30:00 (UTC)
* 終了   : 2026-06-02 17:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→12→14
* 開始   : 2026-06-02 19:35:00 (UTC)
* 終了   : 2026-06-02 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→16→…→16→18→17→14
* 開始   : 2026-06-03 06:30:00 (UTC)
* 終了   : 2026-06-03 06:55:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→14→20→17→17
* 開始   : 2026-06-03 06:35:00 (UTC)
* 終了   : 2026-06-03 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.371倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.783σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-003 active_connections の推移](charts/EVT-20260603-host10-003.svg)

# イベントID( EVT-20260603-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→19→15→20→17
* 開始   : 2026-06-03 15:55:00 (UTC)
* 終了   : 2026-06-03 15:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→11→17→14→15
* 開始   : 2026-06-04 05:25:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→17→20→17→16
* 開始   : 2026-06-04 07:10:00 (UTC)
* 終了   : 2026-06-04 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→18→23→21→20
* 開始   : 2026-06-04 08:40:00 (UTC)
* 終了   : 2026-06-04 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→22→19→24→…→25→19→21→22
* 開始   : 2026-06-04 13:20:00 (UTC)
* 終了   : 2026-06-04 14:35:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→13→15→15
* 開始   : 2026-06-04 16:45:00 (UTC)
* 終了   : 2026-06-04 16:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-008 active_connections の推移](charts/EVT-20260604-host10-008.svg)

# イベントID( EVT-20260605-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→19→20→18→23→20→20
* 開始   : 2026-06-05 07:20:00 (UTC)
* 終了   : 2026-06-05 07:50:00 (UTC)
* 現象   : 2026-06-05 07:50:00 (UTC)を境に水準が 14.97から14.5へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.596, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host10-003 active_connections の推移](charts/EVT-20260605-host10-003.svg)

# イベントID( EVT-20260605-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→19→23→18→21
* 開始   : 2026-06-05 08:30:00 (UTC)
* 終了   : 2026-06-05 08:30:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260605-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→11→9→12→…→10→11→12→13
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.725, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host10-001 active_connections の推移](charts/EVT-20260606-host10-001.svg)

# イベントID( EVT-20260606-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→16→…→11→10→11→12
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host10-002 active_connections の推移](charts/EVT-20260606-host10-002.svg)

# イベントID( EVT-20260606-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→10→9→12→11
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host10-003 active_connections の推移](charts/EVT-20260606-host10-003.svg)

# イベントID( EVT-20260606-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→13→…→11→9→11→9
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.049, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host10-004 active_connections の推移](charts/EVT-20260606-host10-004.svg)

# イベントID( EVT-20260606-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→10→…→15→11→15→11
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.718, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host10-005 active_connections の推移](charts/EVT-20260606-host10-005.svg)

# イベントID( EVT-20260606-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→14→…→11→12→11→10
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.346, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260606-host10-006 active_connections の推移](charts/EVT-20260606-host10-006.svg)

# イベントID( EVT-20260606-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→5→10→8→5→10→8→7
* 開始   : 2026-06-06 20:45:00 (UTC)
* 終了   : 2026-06-06 20:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.268, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260606-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→9→15→9→11
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 03:55:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.538倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260607-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host10-001 active_connections の推移](charts/EVT-20260607-host10-001.svg)

# イベントID( EVT-20260608-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→17→…→13→14→12→11
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 19:35:00 (UTC)
* 現象   : 2026-06-08 19:35:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.038, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-004 active_connections の推移](charts/EVT-20260608-host10-004.svg)

# イベントID( EVT-20260609-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→18→21→19→19
* 開始   : 2026-06-09 07:45:00 (UTC)
* 終了   : 2026-06-09 07:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→23→20→20
* 開始   : 2026-06-09 09:10:00 (UTC)
* 終了   : 2026-06-09 09:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→19→24→18→21
* 開始   : 2026-06-09 09:10:00 (UTC)
* 終了   : 2026-06-09 09:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→19→14→21→20
* 開始   : 2026-06-09 16:10:00 (UTC)
* 終了   : 2026-06-09 16:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-009 active_connections の推移](charts/EVT-20260609-host10-009.svg)

# イベントID( EVT-20260609-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→17→17
* 開始   : 2026-06-09 16:30:00 (UTC)
* 終了   : 2026-06-09 16:30:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→14→9→15→13
* 開始   : 2026-06-09 18:50:00 (UTC)
* 終了   : 2026-06-09 18:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6171(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.899σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-012 active_connections の推移](charts/EVT-20260609-host10-012.svg)

# イベントID( EVT-20260610-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→10→12→6→6
* 開始   : 2026-06-10 01:50:00 (UTC)
* 終了   : 2026-06-10 01:50:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→17→21→16→16
* 開始   : 2026-06-10 07:05:00 (UTC)
* 終了   : 2026-06-10 07:05:00 (UTC)
* 現象   : 平常時(16)に対し 1.312倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host10-004 active_connections の推移](charts/EVT-20260610-host10-004.svg)

# イベントID( EVT-20260610-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→13→12→16→13→12→16→15
* 開始   : 2026-06-10 17:35:00 (UTC)
* 終了   : 2026-06-10 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host10-010 active_connections の推移](charts/EVT-20260610-host10-010.svg)

# イベントID( EVT-20260610-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→11→9
* 開始   : 2026-06-10 20:55:00 (UTC)
* 終了   : 2026-06-10 20:55:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→10→5→6→…→5→6→11→7
* 開始   : 2026-06-10 22:10:00 (UTC)
* 終了   : 2026-06-10 22:15:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→21→19→18→15→21→19→18
* 開始   : 2026-06-11 07:15:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.914σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-003 active_connections の推移](charts/EVT-20260611-host10-003.svg)

# イベントID( EVT-20260611-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 22→22→17→19→21
* 開始   : 2026-06-11 14:25:00 (UTC)
* 終了   : 2026-06-11 14:25:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→21→14→18→19
* 開始   : 2026-06-11 16:00:00 (UTC)
* 終了   : 2026-06-11 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.721(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host10-007 active_connections の推移](charts/EVT-20260611-host10-007.svg)

# イベントID( EVT-20260612-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→15→21→18→19
* 開始   : 2026-06-12 07:30:00 (UTC)
* 終了   : 2026-06-12 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→17→…→17→16→19→17
* 開始   : 2026-06-12 15:50:00 (UTC)
* 終了   : 2026-06-12 16:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→10→10
* 開始   : 2026-06-12 20:20:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.628σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host10-008 active_connections の推移](charts/EVT-20260612-host10-008.svg)

# イベントID( EVT-20260613-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→11→…→11→10→11→10
* 開始   : 2026-06-13 04:10:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 15.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.848, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間

![EVT-20260613-host10-001 active_connections の推移](charts/EVT-20260613-host10-001.svg)

# イベントID( EVT-20260613-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→13→14→11→…→14→12→13→12
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host10-002 active_connections の推移](charts/EVT-20260613-host10-002.svg)

# イベントID( EVT-20260613-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→14→…→11→10→12→10
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 19:45:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260613-host10-003 active_connections の推移](charts/EVT-20260613-host10-003.svg)

# イベントID( EVT-20260613-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→11→12→10→…→13→11→10→11
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 20:05:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.999, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260613-host10-004 active_connections の推移](charts/EVT-20260613-host10-004.svg)

# イベントID( EVT-20260613-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→13→11→13→…→11→12→11→12
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.959, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host10-005 active_connections の推移](charts/EVT-20260613-host10-005.svg)

# イベントID( EVT-20260613-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→11→10→11→…→13→11→12→13
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260613-host10-006 active_connections の推移](charts/EVT-20260613-host10-006.svg)

# イベントID( EVT-20260615-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→13→14→13→…→13→12→13→12
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.73から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.68, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.381, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→11→16→15→…→14→16→14→15
* 開始   : 2026-06-16 05:05:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→18→22→21→19→18→22→21→19
* 開始   : 2026-06-16 08:15:00 (UTC)
* 終了   : 2026-06-16 08:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→18→15→18→18
* 開始   : 2026-06-16 15:40:00 (UTC)
* 終了   : 2026-06-16 15:40:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→12→10
* 開始   : 2026-06-17 03:15:00 (UTC)
* 終了   : 2026-06-17 03:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→15→12→13→16→15→12
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:15:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→13→17→16→…→17→16→12→13
* 開始   : 2026-06-17 04:55:00 (UTC)
* 終了   : 2026-06-17 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260617-host10-003 active_connections の推移](charts/EVT-20260617-host10-003.svg)

# イベントID( EVT-20260617-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→14→20→15→18
* 開始   : 2026-06-17 06:45:00 (UTC)
* 終了   : 2026-06-17 06:45:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→20→17→21→21
* 開始   : 2026-06-17 13:45:00 (UTC)
* 終了   : 2026-06-17 13:45:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host10-008 active_connections の推移](charts/EVT-20260617-host10-008.svg)

# イベントID( EVT-20260617-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→13→12→13→12→15
* 開始   : 2026-06-17 17:55:00 (UTC)
* 終了   : 2026-06-17 20:20:00 (UTC)
* 現象   : 2026-06-17 20:20:00 (UTC)を境に水準が 15.04から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.744σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→6→13→10
* 開始   : 2026-06-17 21:25:00 (UTC)
* 終了   : 2026-06-17 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→24→…→17→24→20→21
* 開始   : 2026-06-18 09:05:00 (UTC)
* 終了   : 2026-06-18 09:10:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→16→12→15→15
* 開始   : 2026-06-18 17:40:00 (UTC)
* 終了   : 2026-06-18 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→12→9→12→11
* 開始   : 2026-06-18 19:40:00 (UTC)
* 終了   : 2026-06-18 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→9→5→12→10
* 開始   : 2026-06-18 21:25:00 (UTC)
* 終了   : 2026-06-18 21:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.4878(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→9→4→8→8
* 開始   : 2026-06-19 00:30:00 (UTC)
* 終了   : 2026-06-19 00:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→13→14
* 開始   : 2026-06-19 04:35:00 (UTC)
* 終了   : 2026-06-19 04:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→17→…→17→19→17→18
* 開始   : 2026-06-19 06:50:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→20→22
* 開始   : 2026-06-19 10:00:00 (UTC)
* 終了   : 2026-06-19 10:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→9→5→9→10
* 開始   : 2026-06-20 03:20:00 (UTC)
* 終了   : 2026-06-20 03:20:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host10-002 active_connections の推移](charts/EVT-20260620-host10-002.svg)

# イベントID( EVT-20260620-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→11→10→12→…→12→10→11→12
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.692σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.759, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host10-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260620-host10-003 active_connections の推移](charts/EVT-20260620-host10-003.svg)

# イベントID( EVT-20260620-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→11→14→11→…→12→8→11→10
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.863, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host10-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host10-005 active_connections の推移](charts/EVT-20260620-host10-005.svg)

# イベントID( EVT-20260620-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→12→14→12→…→12→10→12→13
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host10-006 active_connections の推移](charts/EVT-20260620-host10-006.svg)

# イベントID( EVT-20260620-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→…→13→14→13→14
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host10-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host10-007 active_connections の推移](charts/EVT-20260620-host10-007.svg)

# イベントID( EVT-20260620-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→9→10→11→…→11→10→12→10
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.314, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host10-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host10-008 active_connections の推移](charts/EVT-20260620-host10-008.svg)

# イベントID( EVT-20260620-host10-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→13→…→11→13→12→11
* 開始   : 2026-06-20 06:50:00 (UTC)
* 終了   : 2026-06-20 19:30:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.445, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260620-host10-009 active_connections の推移](charts/EVT-20260620-host10-009.svg)

# イベントID( EVT-20260620-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→9→7
* 開始   : 2026-06-20 21:15:00 (UTC)
* 終了   : 2026-06-20 21:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→12→16→10→12
* 開始   : 2026-06-21 04:20:00 (UTC)
* 終了   : 2026-06-21 04:20:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.627倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host10-001 active_connections の推移](charts/EVT-20260621-host10-001.svg)

# イベントID( EVT-20260622-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→16→13→14→15
* 開始   : 2026-06-22 00:55:00 (UTC)
* 終了   : 2026-06-22 19:15:00 (UTC)
* 現象   : 2026-06-22 19:15:00 (UTC)を境に水準が 11.87から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.752, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.177, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→9→14→10→10→11
* 開始   : 2026-06-23 01:05:00 (UTC)
* 終了   : 2026-06-23 01:30:00 (UTC)
* 現象   : 2026-06-23 01:30:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.272σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host10-001 active_connections の推移](charts/EVT-20260623-host10-001.svg)

# イベントID( EVT-20260623-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→9→14→8→9
* 開始   : 2026-06-23 02:10:00 (UTC)
* 終了   : 2026-06-23 02:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.631倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.783σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-002 active_connections の推移](charts/EVT-20260623-host10-002.svg)

# イベントID( EVT-20260623-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→13→16→18→…→16→18→14→13
* 開始   : 2026-06-23 06:05:00 (UTC)
* 終了   : 2026-06-23 06:30:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host10-004 active_connections の推移](charts/EVT-20260623-host10-004.svg)

# イベントID( EVT-20260623-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→16→20→19→…→19→21→20→18
* 開始   : 2026-06-23 07:50:00 (UTC)
* 終了   : 2026-06-23 08:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→22→21→21→21→24
* 開始   : 2026-06-23 08:55:00 (UTC)
* 終了   : 2026-06-23 09:20:00 (UTC)
* 現象   : 2026-06-23 09:20:00 (UTC)を境に水準が 14.87から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→15→10→13→13
* 開始   : 2026-06-23 18:35:00 (UTC)
* 終了   : 2026-06-23 18:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→16→21→18→17
* 開始   : 2026-06-24 07:10:00 (UTC)
* 終了   : 2026-06-24 07:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host10-004 active_connections の推移](charts/EVT-20260624-host10-004.svg)

# イベントID( EVT-20260624-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→19→20
* 開始   : 2026-06-24 07:40:00 (UTC)
* 終了   : 2026-06-24 07:40:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→18→15→20→19
* 開始   : 2026-06-24 15:30:00 (UTC)
* 終了   : 2026-06-24 15:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→13→16→13→16→13→15
* 開始   : 2026-06-24 17:20:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→12→8→11→10
* 開始   : 2026-06-24 20:15:00 (UTC)
* 終了   : 2026-06-24 20:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→15→13
* 開始   : 2026-06-25 05:15:00 (UTC)
* 終了   : 2026-06-25 05:15:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-003 active_connections の推移](charts/EVT-20260625-host10-003.svg)

# イベントID( EVT-20260625-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→15→21→17
* 開始   : 2026-06-25 06:10:00 (UTC)
* 終了   : 2026-06-25 06:25:00 (UTC)
* 現象   : 2026-06-25 06:25:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.341, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host10-005 active_connections の推移](charts/EVT-20260625-host10-005.svg)

# イベントID( EVT-20260625-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→16→…→16→19→16→15
* 開始   : 2026-06-25 06:15:00 (UTC)
* 終了   : 2026-06-25 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.867σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260625-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→18→18
* 開始   : 2026-06-25 17:05:00 (UTC)
* 終了   : 2026-06-25 17:05:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→14→14
* 開始   : 2026-06-26 04:35:00 (UTC)
* 終了   : 2026-06-26 04:35:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-001 active_connections の推移](charts/EVT-20260626-host10-001.svg)

# イベントID( EVT-20260626-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→18→21→17→18
* 開始   : 2026-06-26 07:35:00 (UTC)
* 終了   : 2026-06-26 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→18→23→21→20
* 開始   : 2026-06-26 09:05:00 (UTC)
* 終了   : 2026-06-26 09:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→21→16→21→20
* 開始   : 2026-06-26 14:45:00 (UTC)
* 終了   : 2026-06-26 14:45:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host10-007 active_connections の推移](charts/EVT-20260626-host10-007.svg)

# イベントID( EVT-20260626-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→21→16→20→21
* 開始   : 2026-06-26 14:55:00 (UTC)
* 終了   : 2026-06-26 14:55:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→18→15→18→17
* 開始   : 2026-06-26 16:00:00 (UTC)
* 終了   : 2026-06-26 16:00:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→10→4→7→7
* 開始   : 2026-06-26 23:15:00 (UTC)
* 終了   : 2026-06-26 23:15:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→10→9→11→…→9→13→11→12
* 開始   : 2026-06-27 05:05:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host10-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260627-host10-003 active_connections の推移](charts/EVT-20260627-host10-003.svg)

# イベントID( EVT-20260627-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→12→…→14→12→14→12
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 18:50:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host10-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260627-host10-004 active_connections の推移](charts/EVT-20260627-host10-004.svg)

# イベントID( EVT-20260627-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→…→12→10→13→12
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host10-005 active_connections の推移](charts/EVT-20260627-host10-005.svg)

# イベントID( EVT-20260627-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→11→…→10→11→12→10
* 開始   : 2026-06-27 06:20:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.761, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host10-006 active_connections の推移](charts/EVT-20260627-host10-006.svg)

# イベントID( EVT-20260627-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→14→10→14→…→10→12→9→11
* 開始   : 2026-06-27 06:35:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.35, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host10-007 active_connections の推移](charts/EVT-20260627-host10-007.svg)

# イベントID( EVT-20260627-host10-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→12→13→12→…→12→13→14→12
* 開始   : 2026-06-27 06:55:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host10-008 active_connections の推移](charts/EVT-20260627-host10-008.svg)

# イベントID( EVT-20260628-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→10→9
* 開始   : 2026-06-28 05:20:00 (UTC)
* 終了   : 2026-06-28 05:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→16→16
* 開始   : 2026-06-28 14:25:00 (UTC)
* 終了   : 2026-06-28 14:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→13→…→12→13→12→14
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.8から15.1へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.861, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→10→11
* 開始   : 2026-06-30 03:20:00 (UTC)
* 終了   : 2026-06-30 03:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→12→13
* 開始   : 2026-06-30 04:20:00 (UTC)
* 終了   : 2026-06-30 04:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260630-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→14→15
* 開始   : 2026-06-30 04:55:00 (UTC)
* 終了   : 2026-06-30 04:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host10-004 active_connections の推移](charts/EVT-20260630-host10-004.svg)

# イベントID( EVT-20260630-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→18→20
* 開始   : 2026-06-30 08:15:00 (UTC)
* 終了   : 2026-06-30 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.302倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-005 active_connections の推移](charts/EVT-20260630-host10-005.svg)

# イベントID( EVT-20260630-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→18→21→23→19→18→21→23→19
* 開始   : 2026-06-30 08:25:00 (UTC)
* 終了   : 2026-06-30 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-006 active_connections の推移](charts/EVT-20260630-host10-006.svg)

# イベントID( EVT-20260630-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 24→22→23→24→22→23→22
* 開始   : 2026-06-30 11:10:00 (UTC)
* 終了   : 2026-06-30 12:00:00 (UTC)
* 現象   : 2026-06-30 12:00:00 (UTC)を境に水準が 15.14から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.624, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→17→…→17→13→15→16
* 開始   : 2026-06-30 17:10:00 (UTC)
* 終了   : 2026-06-30 17:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7742(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260630-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→14→10→13→14
* 開始   : 2026-06-30 19:00:00 (UTC)
* 終了   : 2026-06-30 19:00:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→8→13→10
* 開始   : 2026-06-30 20:15:00 (UTC)
* 終了   : 2026-06-30 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→8→10→11→9→8→10→11
* 開始   : 2026-06-30 20:40:00 (UTC)
* 終了   : 2026-06-30 21:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260630-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→12→10→12→10→12→11→10
* 開始   : 2026-06-01 02:35:00 (UTC)
* 終了   : 2026-06-01 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260601-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→16→18→14→16→18→14→12
* 開始   : 2026-06-01 06:00:00 (UTC)
* 終了   : 2026-06-01 06:05:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.301倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→19→22→20→22→20→22→19→21
* 開始   : 2026-06-01 08:40:00 (UTC)
* 終了   : 2026-06-01 08:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260601-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→22→21→23→22→21→23→20→21
* 開始   : 2026-06-01 09:00:00 (UTC)
* 終了   : 2026-06-01 09:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→20→23→19→23→19→23→20→22
* 開始   : 2026-06-01 09:35:00 (UTC)
* 終了   : 2026-06-01 09:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→19→17→19→17→18
* 開始   : 2026-06-01 15:25:00 (UTC)
* 終了   : 2026-06-01 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→12→15→11→12→13
* 開始   : 2026-06-01 19:00:00 (UTC)
* 終了   : 2026-06-01 19:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260601-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→11→12→11→10→11
* 開始   : 2026-06-01 19:35:00 (UTC)
* 終了   : 2026-06-01 19:40:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→7→8→9→10→7→8→9→10
* 開始   : 2026-06-01 21:10:00 (UTC)
* 終了   : 2026-06-01 21:15:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.6222(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.968σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→9→9→10→11→11
* 開始   : 2026-06-02 00:05:00 (UTC)
* 終了   : 2026-06-02 00:30:00 (UTC)
* 現象   : 2026-06-02 00:30:00 (UTC)を境に水準が 15.11から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 8→9→13→12→13→12→13→10→12
* 開始   : 2026-06-02 03:20:00 (UTC)
* 終了   : 2026-06-02 03:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.431倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260602-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→11→…→11→15→12→14
* 開始   : 2026-06-02 04:25:00 (UTC)
* 終了   : 2026-06-02 04:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260602-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→16→18→16→15
* 開始   : 2026-06-02 06:35:00 (UTC)
* 終了   : 2026-06-02 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 21→20→21→20→16→19→18→18→22
* 開始   : 2026-06-02 15:10:00 (UTC)
* 終了   : 2026-06-02 16:05:00 (UTC)
* 現象   : 2026-06-02 16:05:00 (UTC)を境に水準が 15.03から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→13→14→12→13→12
* 開始   : 2026-06-02 18:25:00 (UTC)
* 終了   : 2026-06-02 18:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→9→7→8→9→7→10
* 開始   : 2026-06-02 21:20:00 (UTC)
* 終了   : 2026-06-02 21:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-078 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260602-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→12→8→7→12→8→10
* 開始   : 2026-06-02 22:50:00 (UTC)
* 終了   : 2026-06-02 22:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.469倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 6→9→5→8→…→8→11→7→10
* 開始   : 2026-06-02 23:05:00 (UTC)
* 終了   : 2026-06-02 23:15:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→14→…→14→15→11→13
* 開始   : 2026-06-03 03:45:00 (UTC)
* 終了   : 2026-06-03 04:35:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 20 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→23→20→25→23→22
* 開始   : 2026-06-03 12:45:00 (UTC)
* 終了   : 2026-06-03 12:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-040 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260603-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→22→19→18→22→19→18→22→21
* 開始   : 2026-06-03 13:50:00 (UTC)
* 終了   : 2026-06-03 13:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260603-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→15→14→14→14→14→16→13
* 開始   : 2026-06-03 18:15:00 (UTC)
* 終了   : 2026-06-03 18:55:00 (UTC)
* 現象   : 2026-06-03 18:55:00 (UTC)を境に水準が 14.97から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.813, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→11→…→11→7→12→11
* 開始   : 2026-06-03 20:35:00 (UTC)
* 終了   : 2026-06-03 20:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260603-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260603-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→10→9→12→8→10→12
* 開始   : 2026-06-04 01:45:00 (UTC)
* 終了   : 2026-06-04 02:55:00 (UTC)
* 現象   : 2026-06-04 02:55:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.278, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→14→13→14→13→14→11→12
* 開始   : 2026-06-04 04:00:00 (UTC)
* 終了   : 2026-06-04 04:10:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→14→15→16→17→14→16
* 開始   : 2026-06-04 05:50:00 (UTC)
* 終了   : 2026-06-04 05:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→8→…→8→5→9→6
* 開始   : 2026-06-04 22:15:00 (UTC)
* 終了   : 2026-06-04 22:25:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→10→10→9→8→9→10→11
* 開始   : 2026-06-05 02:00:00 (UTC)
* 終了   : 2026-06-05 02:35:00 (UTC)
* 現象   : 2026-06-05 02:35:00 (UTC)を境に水準が 14.91から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→15→…→14→15→11→12
* 開始   : 2026-06-05 04:05:00 (UTC)
* 終了   : 2026-06-05 04:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→20→…→19→20→18→17
* 開始   : 2026-06-05 07:25:00 (UTC)
* 終了   : 2026-06-05 07:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260605-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→19→21→22→…→21→22→17→18
* 開始   : 2026-06-05 08:15:00 (UTC)
* 終了   : 2026-06-05 08:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260605-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→20→22→20→23→22→20→23→20
* 開始   : 2026-06-05 08:50:00 (UTC)
* 終了   : 2026-06-05 09:00:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→23→22→22→23→23→24→22→23
* 開始   : 2026-06-05 10:30:00 (UTC)
* 終了   : 2026-06-05 11:10:00 (UTC)
* 現象   : 2026-06-05 11:10:00 (UTC)を境に水準が 14.92から13.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→15→18→15
* 開始   : 2026-06-05 16:45:00 (UTC)
* 終了   : 2026-06-05 16:55:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→14→12→14→12→14→13
* 開始   : 2026-06-05 18:10:00 (UTC)
* 終了   : 2026-06-05 18:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 7→9→8→11→9→8→11→10
* 開始   : 2026-06-06 20:05:00 (UTC)
* 終了   : 2026-06-06 20:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.947, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host10-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→6→8→10→6→8→10
* 開始   : 2026-06-06 20:25:00 (UTC)
* 終了   : 2026-06-06 20:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.927, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260606-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→13→15→14→13→13→16
* 開始   : 2026-06-07 06:25:00 (UTC)
* 終了   : 2026-06-07 07:10:00 (UTC)
* 現象   : 2026-06-07 07:10:00 (UTC)を境に水準が 11.74から12.31へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→14→13→18→16→16→16
* 開始   : 2026-06-07 08:20:00 (UTC)
* 終了   : 2026-06-07 09:10:00 (UTC)
* 現象   : 2026-06-07 09:10:00 (UTC)を境に水準が 11.85から12.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→15→14→18→16→14→17→17
* 開始   : 2026-06-07 08:55:00 (UTC)
* 終了   : 2026-06-07 09:30:00 (UTC)
* 現象   : 2026-06-07 09:30:00 (UTC)を境に水準が 11.83から12.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→17→17→16→18→15→16→15→17
* 開始   : 2026-06-07 10:15:00 (UTC)
* 終了   : 2026-06-07 11:10:00 (UTC)
* 現象   : 2026-06-07 11:10:00 (UTC)を境に水準が 11.8から13.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→19→16→13→19→16→13→15→16
* 開始   : 2026-06-07 11:40:00 (UTC)
* 終了   : 2026-06-07 11:50:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260607-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→9→10→10→11→10
* 開始   : 2026-06-07 20:35:00 (UTC)
* 終了   : 2026-06-07 21:10:00 (UTC)
* 現象   : 2026-06-07 21:10:00 (UTC)を境に水準が 11.82から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.479, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→10→13→12
* 開始   : 2026-06-07 20:50:00 (UTC)
* 終了   : 2026-06-07 21:05:00 (UTC)
* 現象   : 2026-06-07 21:05:00 (UTC)を境に水準が 11.85から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→9→8→8→10→10→10→10→10
* 開始   : 2026-06-08 01:30:00 (UTC)
* 終了   : 2026-06-08 02:35:00 (UTC)
* 現象   : 2026-06-08 02:35:00 (UTC)を境に水準が 11.82から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.797, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→8→7→10→9→8→8→8→10
* 開始   : 2026-06-08 22:55:00 (UTC)
* 終了   : 2026-06-09 00:00:00 (UTC)
* 現象   : 2026-06-09 00:00:00 (UTC)を境に水準が 15から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→7→5→4→7→5→4→7→8
* 開始   : 2026-06-08 23:55:00 (UTC)
* 終了   : 2026-06-09 00:00:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→16→17→12→…→16→17→12→16
* 開始   : 2026-06-09 05:10:00 (UTC)
* 終了   : 2026-06-09 05:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→14→17→13→17→13→17→15
* 開始   : 2026-06-09 05:45:00 (UTC)
* 終了   : 2026-06-09 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→19→21→18
* 開始   : 2026-06-09 08:20:00 (UTC)
* 終了   : 2026-06-09 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260609-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→22→19→18→22→19→22
* 開始   : 2026-06-09 08:35:00 (UTC)
* 終了   : 2026-06-09 08:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→19→19→19→22
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 16:15:00 (UTC)
* 現象   : 2026-06-09 16:15:00 (UTC)を境に水準が 14.96から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.299, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→17→…→15→16→14→15
* 開始   : 2026-06-09 16:45:00 (UTC)
* 終了   : 2026-06-09 17:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→14→18→17→14→18→15
* 開始   : 2026-06-10 06:00:00 (UTC)
* 終了   : 2026-06-10 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→18→17→13→17→18→17
* 開始   : 2026-06-10 06:20:00 (UTC)
* 終了   : 2026-06-10 06:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→18→…→25→18→21→20
* 開始   : 2026-06-10 14:10:00 (UTC)
* 終了   : 2026-06-10 14:15:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→21→20→21→22
* 開始   : 2026-06-10 14:55:00 (UTC)
* 終了   : 2026-06-10 15:40:00 (UTC)
* 現象   : 2026-06-10 15:40:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.285, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→18→16→19→…→19→15→18→17
* 開始   : 2026-06-10 16:25:00 (UTC)
* 終了   : 2026-06-10 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→19→19→16→18→18
* 開始   : 2026-06-10 16:35:00 (UTC)
* 終了   : 2026-06-10 17:05:00 (UTC)
* 現象   : 2026-06-10 17:05:00 (UTC)を境に水準が 14.97から15.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→14→17→14→17→14→18→16
* 開始   : 2026-06-10 17:25:00 (UTC)
* 終了   : 2026-06-10 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→12→…→12→8→13→12
* 開始   : 2026-06-11 04:00:00 (UTC)
* 終了   : 2026-06-11 04:10:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→18→17→18→17→18→16
* 開始   : 2026-06-11 07:05:00 (UTC)
* 終了   : 2026-06-11 07:15:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→19→…→19→22→18→20
* 開始   : 2026-06-11 08:05:00 (UTC)
* 終了   : 2026-06-11 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 25→24→21→23→22→24→22
* 開始   : 2026-06-11 12:15:00 (UTC)
* 終了   : 2026-06-11 12:45:00 (UTC)
* 現象   : 2026-06-11 12:45:00 (UTC)を境に水準が 15.18から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→11→8→9→11→8→10
* 開始   : 2026-06-11 20:15:00 (UTC)
* 終了   : 2026-06-11 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260611-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260611-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→6→…→12→6→10→9
* 開始   : 2026-06-12 02:20:00 (UTC)
* 終了   : 2026-06-12 02:25:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→8→13→11→8→13→11→12
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 03:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→19→21→20→…→20→22→21→19
* 開始   : 2026-06-12 08:35:00 (UTC)
* 終了   : 2026-06-12 08:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→18→17→19→17→19→17→21→18
* 開始   : 2026-06-12 15:10:00 (UTC)
* 終了   : 2026-06-12 15:20:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→11→9→12→9→12→9→10
* 開始   : 2026-06-12 20:10:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→9→10→…→9→10→9→10
* 開始   : 2026-06-13 19:40:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.983, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260613-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→8→12→14→8→12→14→13
* 開始   : 2026-06-14 06:15:00 (UTC)
* 終了   : 2026-06-14 06:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260614-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260614-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→15→17→16
* 開始   : 2026-06-14 09:40:00 (UTC)
* 終了   : 2026-06-14 10:05:00 (UTC)
* 現象   : 2026-06-14 10:05:00 (UTC)を境に水準が 11.69から12.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→16→16
* 開始   : 2026-06-14 15:45:00 (UTC)
* 終了   : 2026-06-14 16:05:00 (UTC)
* 現象   : 2026-06-14 16:05:00 (UTC)を境に水準が 11.7から14.41へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→13→13→13→13→11→12→14→12
* 開始   : 2026-06-14 18:00:00 (UTC)
* 終了   : 2026-06-14 18:55:00 (UTC)
* 現象   : 2026-06-14 18:55:00 (UTC)を境に水準が 11.75から14.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→10→8→8→9→10→12→10→10
* 開始   : 2026-06-15 23:15:00 (UTC)
* 終了   : 2026-06-16 00:10:00 (UTC)
* 現象   : 2026-06-16 00:10:00 (UTC)を境に水準が 14.89から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→12→13→10
* 開始   : 2026-06-16 03:50:00 (UTC)
* 終了   : 2026-06-16 03:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260616-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 22→21→24→21→22→23→22→23→23
* 開始   : 2026-06-16 10:45:00 (UTC)
* 終了   : 2026-06-16 12:20:00 (UTC)
* 現象   : 2026-06-16 12:20:00 (UTC)を境に水準が 15から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.763, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→22→…→22→25→22→21
* 開始   : 2026-06-16 11:00:00 (UTC)
* 終了   : 2026-06-16 11:10:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260616-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→19→19→19
* 開始   : 2026-06-16 16:55:00 (UTC)
* 終了   : 2026-06-16 17:10:00 (UTC)
* 現象   : 2026-06-16 17:10:00 (UTC)を境に水準が 14.92から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.239, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→18→14→18→14
* 開始   : 2026-06-16 17:40:00 (UTC)
* 終了   : 2026-06-16 17:45:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→13→11→13→11→12
* 開始   : 2026-06-16 18:50:00 (UTC)
* 終了   : 2026-06-16 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→12→13→10→12→13
* 開始   : 2026-06-16 19:25:00 (UTC)
* 終了   : 2026-06-16 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→9→11→9→10
* 開始   : 2026-06-16 20:10:00 (UTC)
* 終了   : 2026-06-16 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→9→…→9→5→7→9
* 開始   : 2026-06-16 23:20:00 (UTC)
* 終了   : 2026-06-16 23:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-084 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→19→…→18→19→18→16
* 開始   : 2026-06-17 06:50:00 (UTC)
* 終了   : 2026-06-17 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→17→18→17→…→19→15→19→18
* 開始   : 2026-06-17 06:55:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→24→24→23→23→22→23→24
* 開始   : 2026-06-17 11:55:00 (UTC)
* 終了   : 2026-06-17 12:30:00 (UTC)
* 現象   : 2026-06-17 12:30:00 (UTC)を境に水準が 15.01から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.455, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→20→21→21→20→20→20→21
* 開始   : 2026-06-17 15:05:00 (UTC)
* 終了   : 2026-06-17 15:40:00 (UTC)
* 現象   : 2026-06-17 15:40:00 (UTC)を境に水準が 14.97から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→10→…→11→10→12→14
* 開始   : 2026-06-17 19:00:00 (UTC)
* 終了   : 2026-06-17 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→10→7→6→…→7→6→8→10
* 開始   : 2026-06-17 21:35:00 (UTC)
* 終了   : 2026-06-17 21:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→9→6→10→…→10→5→9→8
* 開始   : 2026-06-17 22:50:00 (UTC)
* 終了   : 2026-06-17 23:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-084 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260617-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-086 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→7→11→5→…→11→5→8→6
* 開始   : 2026-06-18 01:25:00 (UTC)
* 終了   : 2026-06-18 01:30:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→19→16→17→19→16→15
* 開始   : 2026-06-18 06:50:00 (UTC)
* 終了   : 2026-06-18 06:55:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→15→16→18→15→16→17
* 開始   : 2026-06-18 17:00:00 (UTC)
* 終了   : 2026-06-18 17:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→13→10→13→…→9→10→9→11
* 開始   : 2026-06-18 19:45:00 (UTC)
* 終了   : 2026-06-18 20:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260618-host05-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→8→9→9→10→11→11
* 開始   : 2026-06-18 23:00:00 (UTC)
* 終了   : 2026-06-18 23:30:00 (UTC)
* 現象   : 2026-06-18 23:30:00 (UTC)を境に水準が 15.11から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→21→23→20→…→20→17→21→22
* 開始   : 2026-06-19 09:15:00 (UTC)
* 終了   : 2026-06-19 09:25:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→14→…→14→11→15→13
* 開始   : 2026-06-19 18:30:00 (UTC)
* 終了   : 2026-06-19 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→9→12→9→12→9
* 開始   : 2026-06-20 02:05:00 (UTC)
* 終了   : 2026-06-20 02:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→9→…→10→13→14→12
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 05:45:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260620-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 40 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分

![EVT-20260620-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→8→10→6→8→7
* 開始   : 2026-06-20 21:00:00 (UTC)
* 終了   : 2026-06-20 21:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→14→12→14→14
* 開始   : 2026-06-21 16:35:00 (UTC)
* 終了   : 2026-06-21 17:05:00 (UTC)
* 現象   : 2026-06-21 17:05:00 (UTC)を境に水準が 11.74から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→11→11→12→14→13
* 開始   : 2026-06-21 17:55:00 (UTC)
* 終了   : 2026-06-21 18:20:00 (UTC)
* 現象   : 2026-06-21 18:20:00 (UTC)を境に水準が 11.88から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.829, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→13→8→10→8→10→8→11→9
* 開始   : 2026-06-21 19:10:00 (UTC)
* 終了   : 2026-06-21 19:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→10→11→13→10→11→9→11
* 開始   : 2026-06-22 20:20:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 14.84から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.105, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→13→13→12→15→14→12→15→16
* 開始   : 2026-06-23 04:20:00 (UTC)
* 終了   : 2026-06-23 05:00:00 (UTC)
* 現象   : 2026-06-23 05:00:00 (UTC)を境に水準が 14.97から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→17→15
* 開始   : 2026-06-23 06:15:00 (UTC)
* 終了   : 2026-06-23 06:20:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→18→16→20→18
* 開始   : 2026-06-23 07:50:00 (UTC)
* 終了   : 2026-06-23 07:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 23→22→23→24→22→23
* 開始   : 2026-06-23 11:20:00 (UTC)
* 終了   : 2026-06-23 11:45:00 (UTC)
* 現象   : 2026-06-23 11:45:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→18→…→18→16→18→19
* 開始   : 2026-06-23 15:40:00 (UTC)
* 終了   : 2026-06-23 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→15→13→15→13→15→16
* 開始   : 2026-06-23 17:45:00 (UTC)
* 終了   : 2026-06-23 17:50:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7761(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→10→12→10→13
* 開始   : 2026-06-23 19:45:00 (UTC)
* 終了   : 2026-06-23 19:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260623-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→9→11→7→9→8
* 開始   : 2026-06-23 21:10:00 (UTC)
* 終了   : 2026-06-23 21:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.6316(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→7→8→7→8→7→10→7
* 開始   : 2026-06-23 21:25:00 (UTC)
* 終了   : 2026-06-23 21:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→5→7→11→5→7→11→6→8
* 開始   : 2026-06-24 00:25:00 (UTC)
* 終了   : 2026-06-24 00:35:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 7→8→12→9→8→12→9→10
* 開始   : 2026-06-24 02:55:00 (UTC)
* 終了   : 2026-06-24 03:00:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260624-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→14→13→15→14→13→15→14→12
* 開始   : 2026-06-24 04:35:00 (UTC)
* 終了   : 2026-06-24 04:45:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→20→21→16→22→21→16→22→19
* 開始   : 2026-06-24 08:25:00 (UTC)
* 終了   : 2026-06-24 09:00:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260624-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260624-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→21→…→21→24→20→22
* 開始   : 2026-06-24 09:55:00 (UTC)
* 終了   : 2026-06-24 10:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→21→18→24→…→18→24→22→20
* 開始   : 2026-06-24 13:55:00 (UTC)
* 終了   : 2026-06-24 14:00:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→21→17→20→17→20→17→19
* 開始   : 2026-06-24 15:25:00 (UTC)
* 終了   : 2026-06-24 15:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→14→11→17→14→11→13
* 開始   : 2026-06-24 19:05:00 (UTC)
* 終了   : 2026-06-24 19:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→14→…→14→10→13→11
* 開始   : 2026-06-24 19:05:00 (UTC)
* 終了   : 2026-06-24 19:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→12→9→10→12→9→10
* 開始   : 2026-06-24 19:40:00 (UTC)
* 終了   : 2026-06-24 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→13→8→11→7→8→11→7→10
* 開始   : 2026-06-24 20:55:00 (UTC)
* 終了   : 2026-06-24 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→8→11→8→12→11→8→12→9
* 開始   : 2026-06-25 01:50:00 (UTC)
* 終了   : 2026-06-25 02:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→15→16→14→12→15→16→14→13
* 開始   : 2026-06-25 04:50:00 (UTC)
* 終了   : 2026-06-25 04:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→16→17→13→15
* 開始   : 2026-06-25 05:35:00 (UTC)
* 終了   : 2026-06-25 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→16→18→16
* 開始   : 2026-06-25 06:30:00 (UTC)
* 終了   : 2026-06-25 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→22→19→20→20→21→21
* 開始   : 2026-06-25 08:15:00 (UTC)
* 終了   : 2026-06-25 09:10:00 (UTC)
* 現象   : 2026-06-25 09:10:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.683, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→23→21→23→21→20
* 開始   : 2026-06-25 09:45:00 (UTC)
* 終了   : 2026-06-25 09:50:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 21→22→18→24→22→18→24→22
* 開始   : 2026-06-25 11:30:00 (UTC)
* 終了   : 2026-06-25 11:35:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 24→22→22→21→22→23→21→21→23
* 開始   : 2026-06-25 12:40:00 (UTC)
* 終了   : 2026-06-25 13:35:00 (UTC)
* 現象   : 2026-06-25 13:35:00 (UTC)を境に水準が 14.96から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.658, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→15→12→14→15→12→14→12
* 開始   : 2026-06-25 18:30:00 (UTC)
* 終了   : 2026-06-25 18:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→13→11→13→11→14
* 開始   : 2026-06-25 19:00:00 (UTC)
* 終了   : 2026-06-25 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→18→14→16→18→14→15
* 開始   : 2026-06-26 06:30:00 (UTC)
* 終了   : 2026-06-26 06:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→21→24→21→…→24→18→23→21
* 開始   : 2026-06-26 10:00:00 (UTC)
* 終了   : 2026-06-26 10:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260626-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→22→21→21→23→23→22→20→25
* 開始   : 2026-06-26 12:20:00 (UTC)
* 終了   : 2026-06-26 13:35:00 (UTC)
* 現象   : 2026-06-26 13:35:00 (UTC)を境に水準が 14.91から13.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→14→10→16→12→14→10→16→12
* 開始   : 2026-06-26 19:35:00 (UTC)
* 終了   : 2026-06-26 19:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→9→8→9→…→7→10→7→10
* 開始   : 2026-06-26 21:00:00 (UTC)
* 終了   : 2026-06-26 21:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→10→9→11→…→11→12→13→12
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 05:30:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.972, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 50 分
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 45 分
  - EVT-20260627-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分

![EVT-20260627-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→11→…→10→11→9→12
* 開始   : 2026-06-27 05:00:00 (UTC)
* 終了   : 2026-06-27 05:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.966, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host10-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260627-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→6→11→12→6→11→12→10→12
* 開始   : 2026-06-28 03:30:00 (UTC)
* 終了   : 2026-06-28 03:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260628-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→15→16→17→14→15→15→18
* 開始   : 2026-06-28 13:35:00 (UTC)
* 終了   : 2026-06-28 14:10:00 (UTC)
* 現象   : 2026-06-28 14:10:00 (UTC)を境に水準が 11.82から14.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→16→16
* 開始   : 2026-06-28 15:20:00 (UTC)
* 終了   : 2026-06-28 15:45:00 (UTC)
* 現象   : 2026-06-28 15:45:00 (UTC)を境に水準が 11.87から14.48へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→13→15→12→13→10→14→13→14
* 開始   : 2026-06-28 17:40:00 (UTC)
* 終了   : 2026-06-28 18:35:00 (UTC)
* 現象   : 2026-06-28 18:35:00 (UTC)を境に水準が 11.91から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.785, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→11→9→8→9→8→11→13
* 開始   : 2026-06-28 18:40:00 (UTC)
* 終了   : 2026-06-28 18:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260628-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→10→10→9→8→8→9→9
* 開始   : 2026-06-28 21:20:00 (UTC)
* 終了   : 2026-06-28 22:15:00 (UTC)
* 現象   : 2026-06-28 22:15:00 (UTC)を境に水準が 11.9から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.683, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→8→6→8→6→9→8
* 開始   : 2026-06-28 21:40:00 (UTC)
* 終了   : 2026-06-28 21:50:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→9→14→13→9→14→13→10
* 開始   : 2026-06-30 04:10:00 (UTC)
* 終了   : 2026-06-30 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→22→23→20→23→20→23→21→20
* 開始   : 2026-06-30 09:05:00 (UTC)
* 終了   : 2026-06-30 09:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260630-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→17→13→17→13→16→15
* 開始   : 2026-06-30 17:25:00 (UTC)
* 終了   : 2026-06-30 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.7536(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.979σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host10-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→10→11→8→9
* 開始   : 2026-06-30 23:50:00 (UTC)
* 終了   : 2026-07-01 00:10:00 (UTC)
* 現象   : 2026-07-01 00:10:00 (UTC)を境に水準が 14.98から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host10-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
