# host03 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host03 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 333 (SEVERE: 26, FATAL: 139, WARN: 168, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 26 | 139 | 168 | 333 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260701-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 22→21→19→21→21
* 開始   : 2026-07-01 08:35:00 (UTC)
* 終了   : 2026-07-01 08:55:00 (UTC)
* 現象   : 2026-07-01 08:55:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.979, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host03-006 active_connections の推移](charts/EVT-20260701-host03-006.svg)

# イベントID( EVT-20260706-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→14→…→15→14→15→14
* 開始   : 2026-07-06 02:20:00 (UTC)
* 終了   : 2026-07-06 21:20:00 (UTC)
* 現象   : 2026-07-06 21:20:00 (UTC)を境に水準が 11.73から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.895, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-001 active_connections の推移](charts/EVT-20260706-host03-001.svg)

# イベントID( EVT-20260706-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→15→16→14→15
* 開始   : 2026-07-06 02:50:00 (UTC)
* 終了   : 2026-07-06 20:35:00 (UTC)
* 現象   : 2026-07-06 20:35:00 (UTC)を境に水準が 11.75から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.84, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.888, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-002 active_connections の推移](charts/EVT-20260706-host03-002.svg)

# イベントID( EVT-20260706-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→15→14→15→…→11→15→13→11
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:30:00 (UTC)
* 現象   : 2026-07-06 20:30:00 (UTC)を境に水準が 11.86から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.783, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-004 active_connections の推移](charts/EVT-20260706-host03-004.svg)

# イベントID( EVT-20260706-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→12→13→13
* 開始   : 2026-07-06 03:30:00 (UTC)
* 終了   : 2026-07-06 03:55:00 (UTC)
* 現象   : 2026-07-06 03:55:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-005 active_connections の推移](charts/EVT-20260706-host03-005.svg)

# イベントID( EVT-20260706-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→16→…→15→14→13→15
* 開始   : 2026-07-06 03:30:00 (UTC)
* 終了   : 2026-07-06 20:10:00 (UTC)
* 現象   : 2026-07-06 20:10:00 (UTC)を境に水準が 11.9から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.119, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-006 active_connections の推移](charts/EVT-20260706-host03-006.svg)

# イベントID( EVT-20260706-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→17→15→14→…→16→13→14→13
* 開始   : 2026-07-06 05:00:00 (UTC)
* 終了   : 2026-07-06 22:05:00 (UTC)
* 現象   : 2026-07-06 22:05:00 (UTC)を境に水準が 12.07から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-007 active_connections の推移](charts/EVT-20260706-host03-007.svg)

# イベントID( EVT-20260708-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 22→23→21→22→23→21
* 開始   : 2026-07-08 13:45:00 (UTC)
* 終了   : 2026-07-08 14:10:00 (UTC)
* 現象   : 2026-07-08 14:10:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-007 active_connections の推移](charts/EVT-20260708-host03-007.svg)

# イベントID( EVT-20260713-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→18→…→13→15→14→13
* 開始   : 2026-07-13 02:05:00 (UTC)
* 終了   : 2026-07-13 21:15:00 (UTC)
* 現象   : 2026-07-13 21:15:00 (UTC)を境に水準が 11.79から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-002 active_connections の推移](charts/EVT-20260713-host03-002.svg)

# イベントID( EVT-20260713-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→16→15→16→…→11→15→13→14
* 開始   : 2026-07-13 02:40:00 (UTC)
* 終了   : 2026-07-13 21:20:00 (UTC)
* 現象   : 2026-07-13 21:20:00 (UTC)を境に水準が 11.95から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.836, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-004 active_connections の推移](charts/EVT-20260713-host03-004.svg)

# イベントID( EVT-20260713-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→17→18→19→…→13→16→12→14
* 開始   : 2026-07-13 04:15:00 (UTC)
* 終了   : 2026-07-13 20:10:00 (UTC)
* 現象   : 2026-07-13 20:10:00 (UTC)を境に水準が 11.87から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.746, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.979, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-005 active_connections の推移](charts/EVT-20260713-host03-005.svg)

# イベントID( EVT-20260713-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→13→17→16→…→16→14→16→14
* 開始   : 2026-07-13 04:30:00 (UTC)
* 終了   : 2026-07-13 21:20:00 (UTC)
* 現象   : 2026-07-13 21:20:00 (UTC)を境に水準が 11.88から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.164, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-006 active_connections の推移](charts/EVT-20260713-host03-006.svg)

# イベントID( EVT-20260713-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→16→13→14→…→13→14→13→15
* 開始   : 2026-07-13 04:50:00 (UTC)
* 終了   : 2026-07-13 20:55:00 (UTC)
* 現象   : 2026-07-13 20:55:00 (UTC)を境に水準が 12.07から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.139, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-007 active_connections の推移](charts/EVT-20260713-host03-007.svg)

# イベントID( EVT-20260720-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→15→…→12→13→14→12
* 開始   : 2026-07-20 00:45:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.72から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.686, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.596, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-001 active_connections の推移](charts/EVT-20260720-host03-001.svg)

# イベントID( EVT-20260720-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→16→…→13→16→13→14
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 20:05:00 (UTC)
* 現象   : 2026-07-20 20:05:00 (UTC)を境に水準が 11.79から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.788, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-002 active_connections の推移](charts/EVT-20260720-host03-002.svg)

# イベントID( EVT-20260720-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→16→12→15→…→16→14→13→14
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.827, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-003 active_connections の推移](charts/EVT-20260720-host03-003.svg)

# イベントID( EVT-20260720-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→15→14→15→…→13→15→14→13
* 開始   : 2026-07-20 03:10:00 (UTC)
* 終了   : 2026-07-20 19:40:00 (UTC)
* 現象   : 2026-07-20 19:40:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.324, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-004 active_connections の推移](charts/EVT-20260720-host03-004.svg)

# イベントID( EVT-20260720-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→14→13→15→…→11→15→12→15
* 開始   : 2026-07-20 04:10:00 (UTC)
* 終了   : 2026-07-20 20:45:00 (UTC)
* 現象   : 2026-07-20 20:45:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.799, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-005 active_connections の推移](charts/EVT-20260720-host03-005.svg)

# イベントID( EVT-20260720-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→18→…→14→13→12→13
* 開始   : 2026-07-20 04:55:00 (UTC)
* 終了   : 2026-07-20 20:00:00 (UTC)
* 現象   : 2026-07-20 20:00:00 (UTC)を境に水準が 11.9から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-006 active_connections の推移](charts/EVT-20260720-host03-006.svg)

# イベントID( EVT-20260723-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→18→18
* 開始   : 2026-07-23 17:15:00 (UTC)
* 終了   : 2026-07-23 17:25:00 (UTC)
* 現象   : 2026-07-23 17:25:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.987, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host03-009 active_connections の推移](charts/EVT-20260723-host03-009.svg)

# イベントID( EVT-20260727-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→16→15→16→…→12→14→10→8
* 開始   : 2026-07-27 01:15:00 (UTC)
* 終了   : 2026-07-27 19:55:00 (UTC)
* 現象   : 2026-07-27 19:55:00 (UTC)を境に水準が 11.76から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.693, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-001 active_connections の推移](charts/EVT-20260727-host03-001.svg)

# イベントID( EVT-20260727-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→13→16→17→…→15→13→15→13
* 開始   : 2026-07-27 01:50:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.798, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.645, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-003 active_connections の推移](charts/EVT-20260727-host03-003.svg)

# イベントID( EVT-20260727-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→15→…→14→13→10→12
* 開始   : 2026-07-27 02:50:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.93から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-004 active_connections の推移](charts/EVT-20260727-host03-004.svg)

# イベントID( EVT-20260727-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→17→15→17→…→14→13→14→13
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 20:55:00 (UTC)
* 現象   : 2026-07-27 20:55:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.307, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-005 active_connections の推移](charts/EVT-20260727-host03-005.svg)

# イベントID( EVT-20260727-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→16→…→14→15→12→14
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 20:55:00 (UTC)
* 現象   : 2026-07-27 20:55:00 (UTC)を境に水準が 11.75から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.705, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.68, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-006 active_connections の推移](charts/EVT-20260727-host03-006.svg)

# イベントID( EVT-20260727-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→15→…→15→13→12→15
* 開始   : 2026-07-27 03:50:00 (UTC)
* 終了   : 2026-07-27 19:35:00 (UTC)
* 現象   : 2026-07-27 19:35:00 (UTC)を境に水準が 12.01から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.808, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host03-007 active_connections の推移](charts/EVT-20260727-host03-007.svg)

# イベントID( EVT-20260701-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→7→13→11→9
* 開始   : 2026-07-01 02:15:00 (UTC)
* 終了   : 2026-07-01 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→11→18→15→13
* 開始   : 2026-07-01 05:15:00 (UTC)
* 終了   : 2026-07-01 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.49倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260701-host03-003 active_connections の推移](charts/EVT-20260701-host03-003.svg)

# イベントID( EVT-20260701-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→12→16→18→12→16→18→16→14
* 開始   : 2026-07-01 06:30:00 (UTC)
* 終了   : 2026-07-01 07:20:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260701-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260701-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→17→21→16→17
* 開始   : 2026-07-01 07:35:00 (UTC)
* 終了   : 2026-07-01 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260701-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→16→11→14→12
* 開始   : 2026-07-01 18:45:00 (UTC)
* 終了   : 2026-07-01 18:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→12→10→12→10→15→14
* 開始   : 2026-07-01 19:00:00 (UTC)
* 終了   : 2026-07-01 19:10:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→8→3→9→7
* 開始   : 2026-07-02 00:35:00 (UTC)
* 終了   : 2026-07-02 00:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.3636(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.658σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→16→19→15→15
* 開始   : 2026-07-02 06:30:00 (UTC)
* 終了   : 2026-07-02 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→19→21→20→…→21→20→19→17
* 開始   : 2026-07-02 07:30:00 (UTC)
* 終了   : 2026-07-02 07:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→20→21→20→21→19→18
* 開始   : 2026-07-02 07:45:00 (UTC)
* 終了   : 2026-07-02 08:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260702-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→25→…→18→25→20→19
* 開始   : 2026-07-02 14:50:00 (UTC)
* 終了   : 2026-07-02 15:40:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260702-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→16→15→18→…→18→14→17→15
* 開始   : 2026-07-02 16:45:00 (UTC)
* 終了   : 2026-07-02 18:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7965(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分

![EVT-20260702-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→15→11→18→16
* 開始   : 2026-07-02 17:40:00 (UTC)
* 終了   : 2026-07-02 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.6701(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.808σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host03-012 active_connections の推移](charts/EVT-20260702-host03-012.svg)

# イベントID( EVT-20260702-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→15→10→15→12
* 開始   : 2026-07-02 18:55:00 (UTC)
* 終了   : 2026-07-02 18:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.592σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host03-013 active_connections の推移](charts/EVT-20260702-host03-013.svg)

# イベントID( EVT-20260702-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→9→9→10→9→7→9
* 開始   : 2026-07-02 23:25:00 (UTC)
* 終了   : 2026-07-03 00:15:00 (UTC)
* 現象   : 2026-07-03 00:15:00 (UTC)を境に水準が 14.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→12→13→16→12→13→16
* 開始   : 2026-07-03 17:30:00 (UTC)
* 終了   : 2026-07-03 17:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→14→10→14→12
* 開始   : 2026-07-03 18:40:00 (UTC)
* 終了   : 2026-07-03 18:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.542σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host03-016 active_connections の推移](charts/EVT-20260703-host03-016.svg)

# イベントID( EVT-20260703-host03-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→10→12
* 開始   : 2026-07-03 21:20:00 (UTC)
* 終了   : 2026-07-03 21:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host03-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→9→15→11→10
* 開始   : 2026-07-04 04:35:00 (UTC)
* 終了   : 2026-07-04 04:35:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260704-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→12→…→13→10→13→11
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 18:55:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.36, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host03-002 active_connections の推移](charts/EVT-20260704-host03-002.svg)

# イベントID( EVT-20260704-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→11→14→13→…→10→11→10→11
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.482σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.296, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間

![EVT-20260704-host03-003 active_connections の推移](charts/EVT-20260704-host03-003.svg)

# イベントID( EVT-20260704-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→14→12→13→…→13→11→13→9
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 19:30:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.919, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260704-host03-004 active_connections の推移](charts/EVT-20260704-host03-004.svg)

# イベントID( EVT-20260704-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→…→10→11→10→12
* 開始   : 2026-07-04 05:50:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260704-host03-005 active_connections の推移](charts/EVT-20260704-host03-005.svg)

# イベントID( EVT-20260704-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→11→…→15→11→12→11
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host03-006 active_connections の推移](charts/EVT-20260704-host03-006.svg)

# イベントID( EVT-20260704-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→12→13→12
* 開始   : 2026-07-04 06:20:00 (UTC)
* 終了   : 2026-07-04 19:15:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260704-host03-007 active_connections の推移](charts/EVT-20260704-host03-007.svg)

# イベントID( EVT-20260706-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→14→15→16→…→12→14→12→13
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:35:00 (UTC)
* 現象   : 2026-07-06 20:35:00 (UTC)を境に水準が 11.85から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.922, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 8→9→13→8→8
* 開始   : 2026-07-07 02:20:00 (UTC)
* 終了   : 2026-07-07 02:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→14→17→13→15
* 開始   : 2026-07-07 05:15:00 (UTC)
* 終了   : 2026-07-07 05:15:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→14→16→18→…→16→18→15→14
* 開始   : 2026-07-07 05:45:00 (UTC)
* 終了   : 2026-07-07 05:50:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host03-004 active_connections の推移](charts/EVT-20260707-host03-004.svg)

# イベントID( EVT-20260707-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→16→19→17→15
* 開始   : 2026-07-07 06:45:00 (UTC)
* 終了   : 2026-07-07 06:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→18→23→20→18
* 開始   : 2026-07-07 08:35:00 (UTC)
* 終了   : 2026-07-07 08:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→18→17
* 開始   : 2026-07-07 17:30:00 (UTC)
* 終了   : 2026-07-07 17:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→11→16→15
* 開始   : 2026-07-07 18:25:00 (UTC)
* 終了   : 2026-07-07 18:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→13→13→13→12→15→13→15→15
* 開始   : 2026-07-08 03:55:00 (UTC)
* 終了   : 2026-07-08 05:20:00 (UTC)
* 現象   : 2026-07-08 05:20:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→19→25→21→20
* 開始   : 2026-07-08 15:10:00 (UTC)
* 終了   : 2026-07-08 15:10:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host03-008 active_connections の推移](charts/EVT-20260708-host03-008.svg)

# イベントID( EVT-20260708-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→18→14→20→18
* 開始   : 2026-07-08 16:10:00 (UTC)
* 終了   : 2026-07-08 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7241(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host03-009 active_connections の推移](charts/EVT-20260708-host03-009.svg)

# イベントID( EVT-20260708-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→17→16→13→14→17→14
* 開始   : 2026-07-08 17:45:00 (UTC)
* 終了   : 2026-07-08 17:50:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→10→16→12
* 開始   : 2026-07-08 19:00:00 (UTC)
* 終了   : 2026-07-08 19:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host03-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→13→16
* 開始   : 2026-07-09 06:00:00 (UTC)
* 終了   : 2026-07-09 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→18→19→17→…→17→21→18→19
* 開始   : 2026-07-09 07:25:00 (UTC)
* 終了   : 2026-07-09 07:35:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→22→18→19
* 開始   : 2026-07-09 07:50:00 (UTC)
* 終了   : 2026-07-09 07:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→20→19
* 開始   : 2026-07-09 16:05:00 (UTC)
* 終了   : 2026-07-09 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260709-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→19→13→14→…→13→14→17→16
* 開始   : 2026-07-09 17:20:00 (UTC)
* 終了   : 2026-07-09 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→15→10→13→14
* 開始   : 2026-07-09 18:50:00 (UTC)
* 終了   : 2026-07-09 18:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→8→11→12
* 開始   : 2026-07-09 19:55:00 (UTC)
* 終了   : 2026-07-09 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6076(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260709-host03-010 active_connections の推移](charts/EVT-20260709-host03-010.svg)

# イベントID( EVT-20260709-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→11→10
* 開始   : 2026-07-09 21:20:00 (UTC)
* 終了   : 2026-07-09 21:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-079 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→21→25→23→21
* 開始   : 2026-07-10 10:10:00 (UTC)
* 終了   : 2026-07-10 10:10:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→21→15→19→18
* 開始   : 2026-07-10 15:45:00 (UTC)
* 終了   : 2026-07-10 15:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260710-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→17→14→19→19
* 開始   : 2026-07-10 16:20:00 (UTC)
* 終了   : 2026-07-10 16:20:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→15→9→12→12
* 開始   : 2026-07-10 19:15:00 (UTC)
* 終了   : 2026-07-10 19:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260710-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→13→…→10→8→13→11
* 開始   : 2026-07-11 04:55:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.164, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260711-host03-003 active_connections の推移](charts/EVT-20260711-host03-003.svg)

# イベントID( EVT-20260711-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→9→…→14→13→12→11
* 開始   : 2026-07-11 05:05:00 (UTC)
* 終了   : 2026-07-11 18:05:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260711-host03-004 active_connections の推移](charts/EVT-20260711-host03-004.svg)

# イベントID( EVT-20260711-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→13→11→13→…→12→11→12→10
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 19:15:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260711-host03-005 active_connections の推移](charts/EVT-20260711-host03-005.svg)

# イベントID( EVT-20260711-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→12→10→12→…→13→12→13→10
* 開始   : 2026-07-11 05:20:00 (UTC)
* 終了   : 2026-07-11 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.706, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host03-006 active_connections の推移](charts/EVT-20260711-host03-006.svg)

# イベントID( EVT-20260711-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→13→…→15→13→14→12
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 18:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.941, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260711-host03-007 active_connections の推移](charts/EVT-20260711-host03-007.svg)

# イベントID( EVT-20260711-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→11→10→…→8→10→12→11
* 開始   : 2026-07-11 05:35:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.05, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host03-008 active_connections の推移](charts/EVT-20260711-host03-008.svg)

# イベントID( EVT-20260712-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→8→11
* 開始   : 2026-07-12 01:40:00 (UTC)
* 終了   : 2026-07-12 01:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→9→5→12→9
* 開始   : 2026-07-12 02:45:00 (UTC)
* 終了   : 2026-07-12 02:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→16→19→13→14
* 開始   : 2026-07-12 09:15:00 (UTC)
* 終了   : 2026-07-12 09:15:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分

![EVT-20260712-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→10→7→11→10
* 開始   : 2026-07-12 19:40:00 (UTC)
* 終了   : 2026-07-12 19:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→7→10
* 開始   : 2026-07-12 23:20:00 (UTC)
* 終了   : 2026-07-12 23:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→13→14→13→14
* 開始   : 2026-07-13 01:35:00 (UTC)
* 終了   : 2026-07-13 20:50:00 (UTC)
* 現象   : 2026-07-13 20:50:00 (UTC)を境に水準が 11.75から15.09へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.894, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.406, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-001 active_connections の推移](charts/EVT-20260713-host03-001.svg)

# イベントID( EVT-20260714-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→11→15→11→13
* 開始   : 2026-07-14 04:00:00 (UTC)
* 終了   : 2026-07-14 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→16→22→17→18
* 開始   : 2026-07-14 07:15:00 (UTC)
* 終了   : 2026-07-14 07:15:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.34倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.889σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-003 active_connections の推移](charts/EVT-20260714-host03-003.svg)

# イベントID( EVT-20260714-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→16→11→15→…→15→10→14→12
* 開始   : 2026-07-14 18:15:00 (UTC)
* 終了   : 2026-07-14 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→13→14→12→12→12→13→12
* 開始   : 2026-07-14 18:45:00 (UTC)
* 終了   : 2026-07-14 20:00:00 (UTC)
* 現象   : 2026-07-14 20:00:00 (UTC)を境に水準が 14.97から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.368σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→15→11→13→13
* 開始   : 2026-07-14 18:50:00 (UTC)
* 終了   : 2026-07-14 18:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→11→12
* 開始   : 2026-07-14 20:45:00 (UTC)
* 終了   : 2026-07-14 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→9→17→…→9→17→12→14
* 開始   : 2026-07-15 04:55:00 (UTC)
* 終了   : 2026-07-15 05:00:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host03-002 active_connections の推移](charts/EVT-20260715-host03-002.svg)

# イベントID( EVT-20260715-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→20→23→19→18
* 開始   : 2026-07-15 08:10:00 (UTC)
* 終了   : 2026-07-15 08:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→18→23→19→21
* 開始   : 2026-07-15 08:55:00 (UTC)
* 終了   : 2026-07-15 08:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→22→16→19→19
* 開始   : 2026-07-15 14:55:00 (UTC)
* 終了   : 2026-07-15 15:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260715-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260715-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→20→15→19→18
* 開始   : 2026-07-15 15:25:00 (UTC)
* 終了   : 2026-07-15 15:25:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.7469(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host03-009 active_connections の推移](charts/EVT-20260715-host03-009.svg)

# イベントID( EVT-20260715-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→19→15→18→18
* 開始   : 2026-07-15 15:50:00 (UTC)
* 終了   : 2026-07-15 16:05:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.6σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host03-010 active_connections の推移](charts/EVT-20260715-host03-010.svg)

# イベントID( EVT-20260715-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→16→12→16→18
* 開始   : 2026-07-15 17:25:00 (UTC)
* 終了   : 2026-07-15 17:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→14→13→11→…→13→11→16→13
* 開始   : 2026-07-15 18:20:00 (UTC)
* 終了   : 2026-07-15 18:25:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→12→12→14
* 開始   : 2026-07-15 20:30:00 (UTC)
* 終了   : 2026-07-15 21:05:00 (UTC)
* 現象   : 2026-07-15 21:05:00 (UTC)を境に水準が 15.02から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→15→17→15→11→17→15→11→16
* 開始   : 2026-07-16 05:10:00 (UTC)
* 終了   : 2026-07-16 06:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260716-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host03-003 active_connections の推移](charts/EVT-20260716-host03-003.svg)

# イベントID( EVT-20260716-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→16→20→15→16
* 開始   : 2026-07-16 06:45:00 (UTC)
* 終了   : 2026-07-16 06:45:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→15→11→15→16
* 開始   : 2026-07-16 18:10:00 (UTC)
* 終了   : 2026-07-16 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.716σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host03-013 active_connections の推移](charts/EVT-20260716-host03-013.svg)

# イベントID( EVT-20260716-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→8→4→9→8
* 開始   : 2026-07-16 23:50:00 (UTC)
* 終了   : 2026-07-16 23:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 7→6→13→9→9
* 開始   : 2026-07-17 01:40:00 (UTC)
* 終了   : 2026-07-17 01:40:00 (UTC)
* 現象   : 平常時(8)に対し 1.625倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→12→16→10→13
* 開始   : 2026-07-17 04:25:00 (UTC)
* 終了   : 2026-07-17 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.745σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host03-003 active_connections の推移](charts/EVT-20260717-host03-003.svg)

# イベントID( EVT-20260717-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→13→…→12→9→16→12
* 開始   : 2026-07-17 04:30:00 (UTC)
* 終了   : 2026-07-17 04:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260717-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260717-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 18→19→23→20→21
* 開始   : 2026-07-17 08:30:00 (UTC)
* 終了   : 2026-07-17 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.284倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.534σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host03-007 active_connections の推移](charts/EVT-20260717-host03-007.svg)

# イベントID( EVT-20260717-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→21→16→18→18
* 開始   : 2026-07-17 15:30:00 (UTC)
* 終了   : 2026-07-17 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→12→15→16
* 開始   : 2026-07-17 17:50:00 (UTC)
* 終了   : 2026-07-17 17:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260717-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→11→…→11→12→14→11
* 開始   : 2026-07-18 04:00:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.782, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 15.0 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260718-host03-001 active_connections の推移](charts/EVT-20260718-host03-001.svg)

# イベントID( EVT-20260718-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→9→…→14→15→14→12
* 開始   : 2026-07-18 04:30:00 (UTC)
* 終了   : 2026-07-18 19:50:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260718-host03-002 active_connections の推移](charts/EVT-20260718-host03-002.svg)

# イベントID( EVT-20260718-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→12→14→12→…→13→12→14→12
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 18:45:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.799, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260718-host03-003 active_connections の推移](charts/EVT-20260718-host03-003.svg)

# イベントID( EVT-20260718-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→10→11→…→11→12→11→13
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260718-host03-004 active_connections の推移](charts/EVT-20260718-host03-004.svg)

# イベントID( EVT-20260718-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→12→…→11→12→11→10
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.862, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260718-host03-005 active_connections の推移](charts/EVT-20260718-host03-005.svg)

# イベントID( EVT-20260718-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→14→…→11→12→11→12
* 開始   : 2026-07-18 06:15:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host03-006 active_connections の推移](charts/EVT-20260718-host03-006.svg)

# イベントID( EVT-20260718-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→8→4→7→6
* 開始   : 2026-07-18 23:10:00 (UTC)
* 終了   : 2026-07-18 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260718-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→15→19→16→19→16
* 開始   : 2026-07-19 13:20:00 (UTC)
* 終了   : 2026-07-19 13:45:00 (UTC)
* 現象   : 2026-07-19 13:45:00 (UTC)を境に水準が 11.81から13.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.019σ 外れた (平常値=15.25)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→18→23→19→22→23→19→22→20
* 開始   : 2026-07-21 07:40:00 (UTC)
* 終了   : 2026-07-21 08:55:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 30 分
  - EVT-20260721-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260721-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→22→25→20→22
* 開始   : 2026-07-21 10:40:00 (UTC)
* 終了   : 2026-07-21 10:40:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→20→16→18→21
* 開始   : 2026-07-21 15:00:00 (UTC)
* 終了   : 2026-07-21 15:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→15→15
* 開始   : 2026-07-22 06:05:00 (UTC)
* 終了   : 2026-07-22 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host03-002 active_connections の推移](charts/EVT-20260722-host03-002.svg)

# イベントID( EVT-20260722-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→14→18→17→…→18→17→16→14
* 開始   : 2026-07-22 06:10:00 (UTC)
* 終了   : 2026-07-22 06:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→16→20→16→17
* 開始   : 2026-07-22 06:55:00 (UTC)
* 終了   : 2026-07-22 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host03-004 active_connections の推移](charts/EVT-20260722-host03-004.svg)

# イベントID( EVT-20260722-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→22→17→22→23
* 開始   : 2026-07-22 13:45:00 (UTC)
* 終了   : 2026-07-22 13:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→…→12→9→12→11
* 開始   : 2026-07-22 19:15:00 (UTC)
* 終了   : 2026-07-22 19:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260722-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260722-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260722-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→9→6→10→…→10→13→12→10
* 開始   : 2026-07-22 20:00:00 (UTC)
* 終了   : 2026-07-22 21:10:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260722-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→8→13→9→10
* 開始   : 2026-07-23 01:30:00 (UTC)
* 終了   : 2026-07-23 01:30:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.677倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→20→18→18
* 開始   : 2026-07-23 06:55:00 (UTC)
* 終了   : 2026-07-23 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→19→23→20→21
* 開始   : 2026-07-24 08:50:00 (UTC)
* 終了   : 2026-07-24 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→20→25→22→21
* 開始   : 2026-07-24 09:40:00 (UTC)
* 終了   : 2026-07-24 09:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260724-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→22→20
* 開始   : 2026-07-24 14:30:00 (UTC)
* 終了   : 2026-07-24 14:30:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→21→17→20→19
* 開始   : 2026-07-24 14:40:00 (UTC)
* 終了   : 2026-07-24 14:40:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→13→11→13→16
* 開始   : 2026-07-24 18:00:00 (UTC)
* 終了   : 2026-07-24 18:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→13→…→12→9→7→11
* 開始   : 2026-07-25 05:00:00 (UTC)
* 終了   : 2026-07-25 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.939, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260725-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260725-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→11→…→11→12→15→14
* 開始   : 2026-07-25 05:15:00 (UTC)
* 終了   : 2026-07-25 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260725-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→12→…→13→14→10→14
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 18:05:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.95, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260725-host03-004 active_connections の推移](charts/EVT-20260725-host03-004.svg)

# イベントID( EVT-20260725-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→11→…→10→11→12→13
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.344, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host03-005 active_connections の推移](charts/EVT-20260725-host03-005.svg)

# イベントID( EVT-20260725-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→14→12→…→10→12→10→11
* 開始   : 2026-07-25 05:55:00 (UTC)
* 終了   : 2026-07-25 19:25:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.842, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260725-host03-006 active_connections の推移](charts/EVT-20260725-host03-006.svg)

# イベントID( EVT-20260725-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→10→11→12→…→13→10→14→9
* 開始   : 2026-07-25 06:05:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.331, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260725-host03-007 active_connections の推移](charts/EVT-20260725-host03-007.svg)

# イベントID( EVT-20260725-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→9→5→9→9
* 開始   : 2026-07-25 22:00:00 (UTC)
* 終了   : 2026-07-25 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260725-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→9→12
* 開始   : 2026-07-26 04:55:00 (UTC)
* 終了   : 2026-07-26 04:55:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.514倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→9→13→10→9
* 開始   : 2026-07-27 01:40:00 (UTC)
* 終了   : 2026-07-27 01:40:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.733倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.832σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→8→15→8→9
* 開始   : 2026-07-27 21:15:00 (UTC)
* 終了   : 2026-07-27 21:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→14→18→15→16
* 開始   : 2026-07-28 05:40:00 (UTC)
* 終了   : 2026-07-28 05:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→8→…→8→12→11→10
* 開始   : 2026-07-29 02:30:00 (UTC)
* 終了   : 2026-07-29 02:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→13→17→15→14
* 開始   : 2026-07-29 05:15:00 (UTC)
* 終了   : 2026-07-29 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host03-003 active_connections の推移](charts/EVT-20260729-host03-003.svg)

# イベントID( EVT-20260729-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→12→16→15→18→16→15→18→16
* 開始   : 2026-07-29 05:40:00 (UTC)
* 終了   : 2026-07-29 05:50:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→14→15
* 開始   : 2026-07-29 06:00:00 (UTC)
* 終了   : 2026-07-29 06:00:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→16→11→12→16→11→12→13
* 開始   : 2026-07-29 18:25:00 (UTC)
* 終了   : 2026-07-29 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→14→10→14→13
* 開始   : 2026-07-29 18:45:00 (UTC)
* 終了   : 2026-07-29 18:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→12→16→14→12
* 開始   : 2026-07-30 04:50:00 (UTC)
* 終了   : 2026-07-30 04:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-029 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→18→16
* 開始   : 2026-07-30 06:50:00 (UTC)
* 終了   : 2026-07-30 06:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→21→24→21→21
* 開始   : 2026-07-30 09:00:00 (UTC)
* 終了   : 2026-07-30 09:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→17→17
* 開始   : 2026-07-30 17:20:00 (UTC)
* 終了   : 2026-07-30 17:20:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.592σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→15→12→16→14
* 開始   : 2026-07-30 17:50:00 (UTC)
* 終了   : 2026-07-30 17:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.368σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→14→18→14→…→14→11→12→14
* 開始   : 2026-07-30 18:50:00 (UTC)
* 終了   : 2026-07-30 20:40:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host03-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→11→11
* 開始   : 2026-07-30 20:10:00 (UTC)
* 終了   : 2026-07-30 20:10:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6115(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.542σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-081 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-015 active_connections の推移](charts/EVT-20260730-host03-015.svg)

# イベントID( EVT-20260731-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→15→20→18→17
* 開始   : 2026-07-31 06:55:00 (UTC)
* 終了   : 2026-07-31 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→19→15→20→18
* 開始   : 2026-07-31 16:00:00 (UTC)
* 終了   : 2026-07-31 16:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→14→15
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 18:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→8→10→11
* 開始   : 2026-07-31 19:55:00 (UTC)
* 終了   : 2026-07-31 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→18→…→19→21→18→17
* 開始   : 2026-07-01 05:15:00 (UTC)
* 終了   : 2026-07-01 07:45:00 (UTC)
* 現象   : 2.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260701-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 45 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 40 分
  - EVT-20260701-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260701-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→22→16→20→…→20→23→20→19
* 開始   : 2026-07-01 09:15:00 (UTC)
* 終了   : 2026-07-01 09:25:00 (UTC)
* 現象   : 平常時(20)に対し 0.8(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.812σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→23→21→23→19→22→23→21→22
* 開始   : 2026-07-01 13:05:00 (UTC)
* 終了   : 2026-07-01 15:10:00 (UTC)
* 現象   : 2026-07-01 15:10:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→15→17
* 開始   : 2026-07-01 16:35:00 (UTC)
* 終了   : 2026-07-01 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→10→9→10→9→11→9
* 開始   : 2026-07-01 20:15:00 (UTC)
* 終了   : 2026-07-01 20:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260701-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260701-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→13→16→13→16→15
* 開始   : 2026-07-02 05:30:00 (UTC)
* 終了   : 2026-07-02 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 23→23→24→25→23→23→22→23→24
* 開始   : 2026-07-02 12:20:00 (UTC)
* 終了   : 2026-07-02 13:55:00 (UTC)
* 現象   : 2026-07-02 13:55:00 (UTC)を境に水準が 14.88から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→22→17→24→22→17→24→22→19
* 開始   : 2026-07-02 14:20:00 (UTC)
* 終了   : 2026-07-02 14:25:00 (UTC)
* 現象   : 平常時(21)に対し 0.8095(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.812σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260702-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→18→17→20→17→20→17→19→17
* 開始   : 2026-07-02 16:00:00 (UTC)
* 終了   : 2026-07-02 16:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260702-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→15→14→16→18→15→14→16→17
* 開始   : 2026-07-02 16:50:00 (UTC)
* 終了   : 2026-07-02 16:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→12→8→11→8→11→8→10→11
* 開始   : 2026-07-02 20:20:00 (UTC)
* 終了   : 2026-07-02 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.852σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→9→12→13→9→12→11
* 開始   : 2026-07-03 02:20:00 (UTC)
* 終了   : 2026-07-03 02:30:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.903σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→14→13→12→14→14→14→16→16
* 開始   : 2026-07-03 04:10:00 (UTC)
* 終了   : 2026-07-03 05:15:00 (UTC)
* 現象   : 2026-07-03 05:15:00 (UTC)を境に水準が 14.85から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→17→…→16→17→12→14
* 開始   : 2026-07-03 05:25:00 (UTC)
* 終了   : 2026-07-03 05:30:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→13→17→13→…→17→13→17→16
* 開始   : 2026-07-03 05:50:00 (UTC)
* 終了   : 2026-07-03 06:30:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260703-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→17→18→18→18→19→18→19→19
* 開始   : 2026-07-03 06:55:00 (UTC)
* 終了   : 2026-07-03 07:50:00 (UTC)
* 現象   : 2026-07-03 07:50:00 (UTC)を境に水準が 14.87から14.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→14→19→20→…→20→19→20→18
* 開始   : 2026-07-03 07:20:00 (UTC)
* 終了   : 2026-07-03 07:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→18→21→18→21→18→21
* 開始   : 2026-07-03 08:05:00 (UTC)
* 終了   : 2026-07-03 08:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→20→22→21→22→21→22→21
* 開始   : 2026-07-03 08:55:00 (UTC)
* 終了   : 2026-07-03 09:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→19→22→18→19→22→18→20
* 開始   : 2026-07-03 09:00:00 (UTC)
* 終了   : 2026-07-03 09:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→19→23→20→23→20→23→20→21
* 開始   : 2026-07-03 09:25:00 (UTC)
* 終了   : 2026-07-03 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260703-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 23→23→21→22→21→22→23→23→24
* 開始   : 2026-07-03 11:25:00 (UTC)
* 終了   : 2026-07-03 12:15:00 (UTC)
* 現象   : 2026-07-03 12:15:00 (UTC)を境に水準が 15.01から13.31へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→18→21→17→18→21→17→19→21
* 開始   : 2026-07-03 14:55:00 (UTC)
* 終了   : 2026-07-03 15:05:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260703-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260703-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 20→16→17→20→16→17
* 開始   : 2026-07-03 15:45:00 (UTC)
* 終了   : 2026-07-03 15:50:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260703-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→19→19→17→18→18→17→17→18
* 開始   : 2026-07-03 16:15:00 (UTC)
* 終了   : 2026-07-03 17:15:00 (UTC)
* 現象   : 2026-07-03 17:15:00 (UTC)を境に水準が 14.94から12.28へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host03-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→12→11→10→7→10→9→10→11
* 開始   : 2026-07-03 21:15:00 (UTC)
* 終了   : 2026-07-03 22:05:00 (UTC)
* 現象   : 2026-07-03 22:05:00 (UTC)を境に水準が 14.96から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.019, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host03-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→16→19→15→…→15→12→15→16
* 開始   : 2026-07-05 15:05:00 (UTC)
* 終了   : 2026-07-05 15:15:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.692σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→9→12→9→12→9→11→9
* 開始   : 2026-07-05 18:25:00 (UTC)
* 終了   : 2026-07-05 18:35:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→9→…→15→9→10→12
* 開始   : 2026-07-05 18:35:00 (UTC)
* 終了   : 2026-07-05 18:40:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→9→10→11→9
* 開始   : 2026-07-05 22:50:00 (UTC)
* 終了   : 2026-07-05 23:10:00 (UTC)
* 現象   : 2026-07-05 23:10:00 (UTC)を境に水準が 11.8から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→9→5→9→5→8→7
* 開始   : 2026-07-06 23:25:00 (UTC)
* 終了   : 2026-07-06 23:35:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260706-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260706-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260706-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→7→11→8→5→11→8→5→8
* 開始   : 2026-07-07 00:25:00 (UTC)
* 終了   : 2026-07-07 00:35:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-002 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260707-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 23→25→22→24→24
* 開始   : 2026-07-07 10:10:00 (UTC)
* 終了   : 2026-07-07 10:30:00 (UTC)
* 現象   : 2026-07-07 10:30:00 (UTC)を境に水準が 15.03から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→23→23→24→24
* 開始   : 2026-07-07 11:55:00 (UTC)
* 終了   : 2026-07-07 12:25:00 (UTC)
* 現象   : 2026-07-07 12:25:00 (UTC)を境に水準が 15.02から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→18→16→20→…→20→17→20→18
* 開始   : 2026-07-07 15:40:00 (UTC)
* 終了   : 2026-07-07 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7934(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→9→10→12→…→10→8→10→11
* 開始   : 2026-07-07 20:20:00 (UTC)
* 終了   : 2026-07-07 20:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260707-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→11→8→7→…→8→7→9→11
* 開始   : 2026-07-07 21:15:00 (UTC)
* 終了   : 2026-07-07 21:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260707-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 6→8→11→9→8→11→9→8
* 開始   : 2026-07-08 01:05:00 (UTC)
* 終了   : 2026-07-08 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→11
* 開始   : 2026-07-08 02:35:00 (UTC)
* 終了   : 2026-07-08 02:40:00 (UTC)
* 現象   : 2026-07-08 02:40:00 (UTC)を境に水準が 14.99から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.109, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→15→15→16→16→16→17→15→17
* 開始   : 2026-07-08 05:15:00 (UTC)
* 終了   : 2026-07-08 06:30:00 (UTC)
* 現象   : 2026-07-08 06:30:00 (UTC)を境に水準が 14.93から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→16→18→14→18→14→18→15
* 開始   : 2026-07-08 06:10:00 (UTC)
* 終了   : 2026-07-08 06:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→19→20→16→17→19→20→16→17
* 開始   : 2026-07-08 07:05:00 (UTC)
* 終了   : 2026-07-08 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→15→16→16→17→16→16→16→15
* 開始   : 2026-07-08 17:00:00 (UTC)
* 終了   : 2026-07-08 18:20:00 (UTC)
* 現象   : 2026-07-08 18:20:00 (UTC)を境に水準が 15.03から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→14→15→10→13→12→13
* 開始   : 2026-07-08 18:40:00 (UTC)
* 終了   : 2026-07-08 20:05:00 (UTC)
* 現象   : 2026-07-08 20:05:00 (UTC)を境に水準が 14.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→13→11→14→13
* 開始   : 2026-07-08 19:00:00 (UTC)
* 終了   : 2026-07-08 19:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host03-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→18→14→18→14→18→16→17
* 開始   : 2026-07-09 06:35:00 (UTC)
* 終了   : 2026-07-09 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→20→…→17→20→14→16
* 開始   : 2026-07-09 17:15:00 (UTC)
* 終了   : 2026-07-09 17:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→13→12→13→12→13→14
* 開始   : 2026-07-09 18:25:00 (UTC)
* 終了   : 2026-07-09 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260709-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→7→6→7→9→7→6→7→9
* 開始   : 2026-07-09 21:40:00 (UTC)
* 終了   : 2026-07-09 21:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→12→11→11→12→14→11→14
* 開始   : 2026-07-10 03:25:00 (UTC)
* 終了   : 2026-07-10 04:00:00 (UTC)
* 現象   : 2026-07-10 04:00:00 (UTC)を境に水準が 14.94から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→18→19→20→19→18→19→20→19
* 開始   : 2026-07-10 07:20:00 (UTC)
* 終了   : 2026-07-10 07:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→20→21→20
* 開始   : 2026-07-10 08:35:00 (UTC)
* 終了   : 2026-07-10 08:40:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→19→15→14→15→14→17→16
* 開始   : 2026-07-10 16:50:00 (UTC)
* 終了   : 2026-07-10 17:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260710-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→12→11→13→14→12→11→13→15
* 開始   : 2026-07-10 18:45:00 (UTC)
* 終了   : 2026-07-10 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→8→7→11→9→9→11→10
* 開始   : 2026-07-11 00:35:00 (UTC)
* 終了   : 2026-07-11 01:10:00 (UTC)
* 現象   : 2026-07-11 01:10:00 (UTC)を境に水準が 14.78から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260711-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→10→7→9→…→9→13→10→8
* 開始   : 2026-07-11 03:00:00 (UTC)
* 終了   : 2026-07-11 04:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-lsfhost01-003 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260711-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260711-lsfhost01-007 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260711-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260711-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260711-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→7→9→6→7
* 開始   : 2026-07-11 21:55:00 (UTC)
* 終了   : 2026-07-11 22:00:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260711-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→13→7→10→13→7→10
* 開始   : 2026-07-12 04:10:00 (UTC)
* 終了   : 2026-07-12 04:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260712-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260712-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→12→12→12→11→13→11→11→12
* 開始   : 2026-07-12 04:55:00 (UTC)
* 終了   : 2026-07-12 06:05:00 (UTC)
* 現象   : 2026-07-12 06:05:00 (UTC)を境に水準が 11.96から12.24へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→13→15→14→13→17→14→14→16
* 開始   : 2026-07-12 07:20:00 (UTC)
* 終了   : 2026-07-12 08:05:00 (UTC)
* 現象   : 2026-07-12 08:05:00 (UTC)を境に水準が 11.91から12.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.175, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→15→16→16→16→14→16
* 開始   : 2026-07-12 13:00:00 (UTC)
* 終了   : 2026-07-12 14:50:00 (UTC)
* 現象   : 2026-07-12 14:50:00 (UTC)を境に水準が 12.02から14.2へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→18→16→15→12→18→16
* 開始   : 2026-07-12 14:05:00 (UTC)
* 終了   : 2026-07-12 14:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→13→15→13→12→14→13
* 開始   : 2026-07-12 17:55:00 (UTC)
* 終了   : 2026-07-12 18:40:00 (UTC)
* 現象   : 2026-07-12 18:40:00 (UTC)を境に水準が 11.76から14.62へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→10→7→10→9→7→8→12→10
* 開始   : 2026-07-12 21:50:00 (UTC)
* 終了   : 2026-07-12 22:35:00 (UTC)
* 現象   : 2026-07-12 22:35:00 (UTC)を境に水準が 11.71から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→6→11→5→…→5→10→11→7
* 開始   : 2026-07-12 23:45:00 (UTC)
* 終了   : 2026-07-13 00:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260712-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 7→11→11→12→10→7→12→10
* 開始   : 2026-07-13 02:30:00 (UTC)
* 終了   : 2026-07-13 03:05:00 (UTC)
* 現象   : 2026-07-13 03:05:00 (UTC)を境に水準が 11.97から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→16→18→15→16→18→15→16
* 開始   : 2026-07-14 06:30:00 (UTC)
* 終了   : 2026-07-14 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 23→18→18→21→21→19→18→20
* 開始   : 2026-07-14 15:35:00 (UTC)
* 終了   : 2026-07-14 16:10:00 (UTC)
* 現象   : 2026-07-14 16:10:00 (UTC)を境に水準が 14.93から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→17→14→16→17→14→16
* 開始   : 2026-07-14 17:05:00 (UTC)
* 終了   : 2026-07-14 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.75σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260714-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→13→15→8→9→13→15→8→9
* 開始   : 2026-07-14 20:45:00 (UTC)
* 終了   : 2026-07-14 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260714-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→8→10→10→9→10→9
* 開始   : 2026-07-14 21:25:00 (UTC)
* 終了   : 2026-07-14 22:25:00 (UTC)
* 現象   : 2026-07-14 22:25:00 (UTC)を境に水準が 15から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→5→8→9→…→5→8→5→8
* 開始   : 2026-07-15 00:20:00 (UTC)
* 終了   : 2026-07-15 00:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→19→20→17→19→20→17→19
* 開始   : 2026-07-15 07:25:00 (UTC)
* 終了   : 2026-07-15 07:30:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→19→19→19→20→19→20→21
* 開始   : 2026-07-15 07:30:00 (UTC)
* 終了   : 2026-07-15 08:15:00 (UTC)
* 現象   : 2026-07-15 08:15:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→23→22→22
* 開始   : 2026-07-15 14:15:00 (UTC)
* 終了   : 2026-07-15 14:30:00 (UTC)
* 現象   : 2026-07-15 14:30:00 (UTC)を境に水準が 15.09から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→17→…→15→18→15→16
* 開始   : 2026-07-15 16:45:00 (UTC)
* 終了   : 2026-07-15 17:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→15→11→13→10→11→13→10→13
* 開始   : 2026-07-15 18:45:00 (UTC)
* 終了   : 2026-07-15 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→8→9→11→8→9
* 開始   : 2026-07-15 20:30:00 (UTC)
* 終了   : 2026-07-15 20:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→11→…→11→7→12→10
* 開始   : 2026-07-15 20:50:00 (UTC)
* 終了   : 2026-07-15 21:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host03-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host03-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→11→9→9→7→9→11
* 開始   : 2026-07-15 22:35:00 (UTC)
* 終了   : 2026-07-15 23:15:00 (UTC)
* 現象   : 2026-07-15 23:15:00 (UTC)を境に水準が 15.05から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host03-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 6→9→9→9→9→8→9→9→11
* 開始   : 2026-07-16 00:20:00 (UTC)
* 終了   : 2026-07-16 01:05:00 (UTC)
* 現象   : 2026-07-16 01:05:00 (UTC)を境に水準が 15.01から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→10→13→12→13→12→13→11
* 開始   : 2026-07-16 03:30:00 (UTC)
* 終了   : 2026-07-16 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260716-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260716-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→19→16→17→19→16→17
* 開始   : 2026-07-16 06:55:00 (UTC)
* 終了   : 2026-07-16 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→17→16→19→17
* 開始   : 2026-07-16 07:05:00 (UTC)
* 終了   : 2026-07-16 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→16→20→17→21→20→17→21→18
* 開始   : 2026-07-16 07:40:00 (UTC)
* 終了   : 2026-07-16 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→23→24→22→24→23
* 開始   : 2026-07-16 11:40:00 (UTC)
* 終了   : 2026-07-16 12:05:00 (UTC)
* 現象   : 2026-07-16 12:05:00 (UTC)を境に水準が 14.99から15.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→17→21→17→21→17→19→18
* 開始   : 2026-07-16 15:35:00 (UTC)
* 終了   : 2026-07-16 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260716-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→18→17→16→…→17→16→17→18
* 開始   : 2026-07-16 15:50:00 (UTC)
* 終了   : 2026-07-16 15:55:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260716-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→14→13→…→14→13→15→16
* 開始   : 2026-07-16 17:40:00 (UTC)
* 終了   : 2026-07-16 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→15→16→17→15→15→16→16
* 開始   : 2026-07-16 17:55:00 (UTC)
* 終了   : 2026-07-16 19:00:00 (UTC)
* 現象   : 2026-07-16 19:00:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→10→11→10→11→10→12→11
* 開始   : 2026-07-16 19:40:00 (UTC)
* 終了   : 2026-07-16 19:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host03-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→8→9→9→8→9→9→8→8
* 開始   : 2026-07-16 22:35:00 (UTC)
* 終了   : 2026-07-16 23:40:00 (UTC)
* 現象   : 2026-07-16 23:40:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→10→9→12→10
* 開始   : 2026-07-17 02:25:00 (UTC)
* 終了   : 2026-07-17 02:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260717-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→13→16→13→16
* 開始   : 2026-07-17 05:30:00 (UTC)
* 終了   : 2026-07-17 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→18→17→19→18→17→19→18→14
* 開始   : 2026-07-17 06:45:00 (UTC)
* 終了   : 2026-07-17 06:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→24→20→…→20→18→19→22
* 開始   : 2026-07-17 10:20:00 (UTC)
* 終了   : 2026-07-17 10:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260717-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 23→24→21→22→23→20→22→22→23
* 開始   : 2026-07-17 12:10:00 (UTC)
* 終了   : 2026-07-17 13:25:00 (UTC)
* 現象   : 2026-07-17 13:25:00 (UTC)を境に水準が 14.96から13.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.874, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 22→20→18→17→19→20→18→17→19
* 開始   : 2026-07-17 14:35:00 (UTC)
* 終了   : 2026-07-17 14:40:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→18→21→20→18→21→20
* 開始   : 2026-07-17 14:35:00 (UTC)
* 終了   : 2026-07-17 14:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→11→9→13
* 開始   : 2026-07-17 20:15:00 (UTC)
* 終了   : 2026-07-17 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260717-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→6→7→9→…→7→9→8→10
* 開始   : 2026-07-18 21:05:00 (UTC)
* 終了   : 2026-07-18 21:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.73, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260718-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→12→14→13→18→12→14
* 開始   : 2026-07-19 14:25:00 (UTC)
* 終了   : 2026-07-19 14:30:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→10→11→10→9
* 開始   : 2026-07-19 20:30:00 (UTC)
* 終了   : 2026-07-19 21:25:00 (UTC)
* 現象   : 2026-07-19 21:25:00 (UTC)を境に水準が 11.88から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→9→8→7→9→8→7→9→12
* 開始   : 2026-07-20 21:10:00 (UTC)
* 終了   : 2026-07-20 21:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260720-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→8→9→8→9→9→8→10→9
* 開始   : 2026-07-20 23:20:00 (UTC)
* 終了   : 2026-07-21 00:15:00 (UTC)
* 現象   : 2026-07-21 00:15:00 (UTC)を境に水準が 14.96から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→12→11→11→12→12→14
* 開始   : 2026-07-21 03:15:00 (UTC)
* 終了   : 2026-07-21 04:10:00 (UTC)
* 現象   : 2026-07-21 04:10:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→13→15→12
* 開始   : 2026-07-21 04:45:00 (UTC)
* 終了   : 2026-07-21 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→14→14→16→13→17→15→15→16
* 開始   : 2026-07-21 05:10:00 (UTC)
* 終了   : 2026-07-21 06:00:00 (UTC)
* 現象   : 2026-07-21 06:00:00 (UTC)を境に水準が 14.88から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→16→19→16→20→19→16→20→17
* 開始   : 2026-07-21 06:40:00 (UTC)
* 終了   : 2026-07-21 06:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→15→19→15→19→18→19
* 開始   : 2026-07-21 07:20:00 (UTC)
* 終了   : 2026-07-21 07:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260721-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→20→23→20→22
* 開始   : 2026-07-21 10:05:00 (UTC)
* 終了   : 2026-07-21 10:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→18→17→24→…→17→24→17→19
* 開始   : 2026-07-21 15:00:00 (UTC)
* 終了   : 2026-07-21 15:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→19→19→18→16→17→18
* 開始   : 2026-07-21 16:40:00 (UTC)
* 終了   : 2026-07-21 17:10:00 (UTC)
* 現象   : 2026-07-21 17:10:00 (UTC)を境に水準が 14.88から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→14→12→14→12→14→13
* 開始   : 2026-07-21 18:15:00 (UTC)
* 終了   : 2026-07-21 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.75σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→12→9→12→9→11→10
* 開始   : 2026-07-21 20:10:00 (UTC)
* 終了   : 2026-07-21 20:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260721-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→9→8→10→8→10→8→11
* 開始   : 2026-07-21 20:55:00 (UTC)
* 終了   : 2026-07-21 21:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260721-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260721-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→13
* 開始   : 2026-07-22 03:00:00 (UTC)
* 終了   : 2026-07-22 03:15:00 (UTC)
* 現象   : 2026-07-22 03:15:00 (UTC)を境に水準が 14.91から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→15→20→15→20→17→18
* 開始   : 2026-07-22 07:30:00 (UTC)
* 終了   : 2026-07-22 07:40:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260722-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 22→24→20→24→20→24→23→22
* 開始   : 2026-07-22 10:35:00 (UTC)
* 終了   : 2026-07-22 10:45:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260722-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260722-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→23→19→22→…→22→19→22→23
* 開始   : 2026-07-22 11:35:00 (UTC)
* 終了   : 2026-07-22 12:40:00 (UTC)
* 現象   : 2026-07-22 12:40:00 (UTC)を境に水準が 14.93から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→20→24→22→…→22→18→20→21
* 開始   : 2026-07-22 14:55:00 (UTC)
* 終了   : 2026-07-22 15:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260722-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→15→12→15→12→15→12→13→12
* 開始   : 2026-07-22 18:20:00 (UTC)
* 終了   : 2026-07-22 18:30:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260722-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→11→…→11→9→11→12
* 開始   : 2026-07-22 19:40:00 (UTC)
* 終了   : 2026-07-22 19:50:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→8→7→10→11→8→7→10
* 開始   : 2026-07-22 20:55:00 (UTC)
* 終了   : 2026-07-22 21:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 6→10→5→10→…→10→11→8→9
* 開始   : 2026-07-23 01:45:00 (UTC)
* 終了   : 2026-07-23 01:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→15→16→15→16→14→15
* 開始   : 2026-07-23 04:30:00 (UTC)
* 終了   : 2026-07-23 05:30:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260723-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260723-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260723-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→14→16→16
* 開始   : 2026-07-23 05:45:00 (UTC)
* 終了   : 2026-07-23 06:00:00 (UTC)
* 現象   : 2026-07-23 06:00:00 (UTC)を境に水準が 14.88から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→20→22→23→…→22→23→19→22
* 開始   : 2026-07-23 09:20:00 (UTC)
* 終了   : 2026-07-23 09:25:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260723-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→22→25→23→23
* 開始   : 2026-07-23 10:55:00 (UTC)
* 終了   : 2026-07-23 11:15:00 (UTC)
* 現象   : 2026-07-23 11:15:00 (UTC)を境に水準が 14.97から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→20→22→21→24→20→22→21
* 開始   : 2026-07-23 13:25:00 (UTC)
* 終了   : 2026-07-23 14:00:00 (UTC)
* 現象   : 2026-07-23 14:00:00 (UTC)を境に水準が 14.87から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→11→14→11→…→15→10→14→13
* 開始   : 2026-07-23 18:45:00 (UTC)
* 終了   : 2026-07-23 19:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.75σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host03-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260723-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260723-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→13→11→13→11→13→11→13→11
* 開始   : 2026-07-23 18:50:00 (UTC)
* 終了   : 2026-07-23 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分

![EVT-20260723-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→12→12→14→12→13→13→12→12
* 開始   : 2026-07-23 19:15:00 (UTC)
* 終了   : 2026-07-23 20:10:00 (UTC)
* 現象   : 2026-07-23 20:10:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→5→8→5→8→5→8→6
* 開始   : 2026-07-24 00:00:00 (UTC)
* 終了   : 2026-07-24 00:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.5769(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-086 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260724-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→17→15→…→16→17→15→16
* 開始   : 2026-07-24 05:45:00 (UTC)
* 終了   : 2026-07-24 06:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.809σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260724-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260724-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→18→16→14→18→16
* 開始   : 2026-07-24 17:20:00 (UTC)
* 終了   : 2026-07-24 17:25:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→16→…→16→12→15→16
* 開始   : 2026-07-24 17:35:00 (UTC)
* 終了   : 2026-07-24 17:45:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260724-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→12
* 開始   : 2026-07-24 20:30:00 (UTC)
* 終了   : 2026-07-24 20:45:00 (UTC)
* 現象   : 2026-07-24 20:45:00 (UTC)を境に水準が 14.94から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→9→9→9→9
* 開始   : 2026-07-25 00:00:00 (UTC)
* 終了   : 2026-07-25 00:20:00 (UTC)
* 現象   : 2026-07-25 00:20:00 (UTC)を境に水準が 14.92から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260725-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→16→17→17→16→15→16→16→18
* 開始   : 2026-07-26 10:45:00 (UTC)
* 終了   : 2026-07-26 11:25:00 (UTC)
* 現象   : 2026-07-26 11:25:00 (UTC)を境に水準が 11.79から13.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→17→15→17→15→17→18→17→17
* 開始   : 2026-07-26 11:30:00 (UTC)
* 終了   : 2026-07-26 12:10:00 (UTC)
* 現象   : 2026-07-26 12:10:00 (UTC)を境に水準が 11.88から13.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.288, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→16→14→15
* 開始   : 2026-07-26 14:20:00 (UTC)
* 終了   : 2026-07-26 14:45:00 (UTC)
* 現象   : 2026-07-26 14:45:00 (UTC)を境に水準が 11.91から14.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→14→16
* 開始   : 2026-07-26 16:55:00 (UTC)
* 終了   : 2026-07-26 17:15:00 (UTC)
* 現象   : 2026-07-26 17:15:00 (UTC)を境に水準が 11.91から14.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→10→13→12→…→13→12→11→8
* 開始   : 2026-07-28 03:00:00 (UTC)
* 終了   : 2026-07-28 03:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.954σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260728-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→18→20→19→18→20→18
* 開始   : 2026-07-28 07:05:00 (UTC)
* 終了   : 2026-07-28 07:15:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→22→18→21→…→21→17→21→20
* 開始   : 2026-07-28 15:15:00 (UTC)
* 終了   : 2026-07-28 15:25:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→15→15→13→16→14→14→14→14
* 開始   : 2026-07-28 18:10:00 (UTC)
* 終了   : 2026-07-28 19:05:00 (UTC)
* 現象   : 2026-07-28 19:05:00 (UTC)を境に水準が 14.99から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.888, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→11→15→11→15→11→15→12→14
* 開始   : 2026-07-29 04:45:00 (UTC)
* 終了   : 2026-07-29 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→14→18→17→14→18→16
* 開始   : 2026-07-29 06:10:00 (UTC)
* 終了   : 2026-07-29 06:20:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→20→21→22→…→21→22→21→18
* 開始   : 2026-07-29 08:20:00 (UTC)
* 終了   : 2026-07-29 08:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→22→…→21→22→20→21
* 開始   : 2026-07-29 08:35:00 (UTC)
* 終了   : 2026-07-29 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→16→16→16→15→15→15→17→15
* 開始   : 2026-07-29 17:45:00 (UTC)
* 終了   : 2026-07-29 18:30:00 (UTC)
* 現象   : 2026-07-29 18:30:00 (UTC)を境に水準が 15.05から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 8→9→9→9→8→9→9→7
* 開始   : 2026-07-29 22:50:00 (UTC)
* 終了   : 2026-07-29 23:25:00 (UTC)
* 現象   : 2026-07-29 23:25:00 (UTC)を境に水準が 15.15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→8→10→10→11→8→11→13→9
* 開始   : 2026-07-30 01:40:00 (UTC)
* 終了   : 2026-07-30 02:35:00 (UTC)
* 現象   : 2026-07-30 02:35:00 (UTC)を境に水準が 14.92から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.888, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→12→8→6→12→8→6→9→10
* 開始   : 2026-07-30 02:25:00 (UTC)
* 終了   : 2026-07-30 02:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260730-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→15→18→17→15→18→17
* 開始   : 2026-07-30 06:00:00 (UTC)
* 終了   : 2026-07-30 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→17→13→17→15→13
* 開始   : 2026-07-30 06:05:00 (UTC)
* 終了   : 2026-07-30 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 22→20→24→18→24→20→24→18→24
* 開始   : 2026-07-30 10:55:00 (UTC)
* 終了   : 2026-07-30 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→20→15→18→20→15→18
* 開始   : 2026-07-30 16:20:00 (UTC)
* 終了   : 2026-07-30 16:25:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.808σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→14→11→14→11→14→11→13
* 開始   : 2026-07-30 19:10:00 (UTC)
* 終了   : 2026-07-30 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→14→15→10→14→13
* 開始   : 2026-07-30 19:20:00 (UTC)
* 終了   : 2026-07-30 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host03-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260730-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host03-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→11→9→12→12
* 開始   : 2026-07-30 21:05:00 (UTC)
* 終了   : 2026-07-30 21:35:00 (UTC)
* 現象   : 2026-07-30 21:35:00 (UTC)を境に水準が 15.07から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→8→9→10→8→10→9→9→10
* 開始   : 2026-07-31 00:10:00 (UTC)
* 終了   : 2026-07-31 00:55:00 (UTC)
* 現象   : 2026-07-31 00:55:00 (UTC)を境に水準が 15.09から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→10→12→11→10→12→11→9
* 開始   : 2026-07-31 02:15:00 (UTC)
* 終了   : 2026-07-31 02:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→23→21→23→21→23→21→19
* 開始   : 2026-07-31 09:10:00 (UTC)
* 終了   : 2026-07-31 09:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260731-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→15→16→12→15→14
* 開始   : 2026-07-31 18:20:00 (UTC)
* 終了   : 2026-07-31 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260731-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→13→12→14→12→14→15
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 18:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→11→13→11→…→11→10→13→11
* 開始   : 2026-07-31 19:10:00 (UTC)
* 終了   : 2026-07-31 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host03-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
