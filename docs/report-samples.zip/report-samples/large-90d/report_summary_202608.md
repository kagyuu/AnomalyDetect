# 異常検知サマリ 2026-08

## 1. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| ホスト数 | 17 |
| 系列数 | 156 |
| 検知イベント数 | 6782 (SEVERE: 420, FATAL: 2727, WARN: 3635, INFO: 0) |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 2. ホスト別の集計

| ホスト | SEVERE | FATAL | WARN | 計 | 主なメトリクス | レポート |
| --- | --- | --- | --- | --- | --- | --- |
| lsfhost01 | 52 | 768 | 1204 | 2024 | pend, run, njobs | report_lsfhost01_202608.md |
| host12 | 34 | 123 | 138 | 295 | active_connections | report_host12_202608.md |
| host08 | 33 | 131 | 153 | 317 | active_connections | report_host08_202608.md |
| host11 | 28 | 114 | 157 | 299 | active_connections | report_host11_202608.md |
| host03 | 28 | 105 | 146 | 279 | active_connections | report_host03_202608.md |
| host02 | 26 | 128 | 196 | 350 | active_connections, ou, mu | report_host02_202608.md |
| host16 | 24 | 123 | 155 | 302 | active_connections | report_host16_202608.md |
| host15 | 22 | 124 | 129 | 275 | active_connections | report_host15_202608.md |
| host07 | 21 | 124 | 160 | 305 | active_connections | report_host07_202608.md |
| host05 | 21 | 118 | 160 | 299 | active_connections | report_host05_202608.md |

(ほか 7 ホスト。脅威度の高い順に上位 10 件のみ表示。全ホストのファイルは report_*_202608.md にある)

## 3. 日別のイベント数

| 日 | SEVERE | FATAL | WARN | 計 |
| --- | --- | --- | --- | --- |
| 08-05 | 4 | 113 | 165 | 282 |
| 08-07 | 4 | 111 | 162 | 277 |
| 08-12 | 5 | 100 | 171 | 276 |
| 08-14 | 6 | 104 | 176 | 286 |
| 08-19 | 4 | 106 | 171 | 281 |
| 08-20 | 4 | 110 | 175 | 289 |
| 08-21 | 4 | 122 | 160 | 286 |
| 08-26 | 1 | 101 | 174 | 276 |
| 08-27 | 3 | 98 | 184 | 285 |
| 08-28 | 3 | 108 | 160 | 271 |

(全 29 日中、イベント数の多い上位 10 日のみ表示)

## 4. 複数ホストで同時に発生したアノマリー

| 時間帯 | ホスト数 | イベント数 | 関与したホスト | 主なメトリクス |
| --- | --- | --- | --- | --- |
| 2026-08-22 05:05 | 15 | 10 | host01, host03, host04 ほか 12 件 | active_connections, eu, run |
| 2026-08-08 05:25 | 13 | 10 | host01, host02, host03 ほか 10 件 | active_connections, njobs, ou |
| 2026-08-22 06:00 | 13 | 10 | host01, host02, host03 ほか 10 件 | active_connections, eu |
| 2026-08-29 05:05 | 13 | 10 | host01, host02, host03 ほか 10 件 | active_connections, njobs |
| 2026-08-08 05:40 | 12 | 8 | host02, host03, host04 ほか 9 件 | active_connections, njobs |
| 2026-08-15 05:35 | 12 | 8 | host01, host02, host03 ほか 9 件 | active_connections |
| 2026-08-01 05:35 | 11 | 8 | host01, host02, host03 ほか 8 件 | active_connections, run |
| 2026-08-08 05:55 | 11 | 8 | host01, host02, host03 ほか 8 件 | active_connections, eu, njobs |

(ほか 2513 件。件数の多い順に上位 8 件のみ表示)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
