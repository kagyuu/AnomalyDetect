# host14 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host14 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 328 (SEVERE: 16, FATAL: 136, WARN: 176, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 16 | 136 | 176 | 328 | ALG-A1, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→15→…→16→14→13→15
* 開始   : 2026-07-06 02:20:00 (UTC)
* 終了   : 2026-07-06 20:30:00 (UTC)
* 現象   : 2026-07-06 20:30:00 (UTC)を境に水準が 11.92から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.545σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.712, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-002 active_connections の推移](charts/EVT-20260706-host14-002.svg)

# イベントID( EVT-20260706-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→16→…→15→16→14→15
* 開始   : 2026-07-06 02:45:00 (UTC)
* 終了   : 2026-07-06 19:55:00 (UTC)
* 現象   : 2026-07-06 19:55:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.026, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.593, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-003 active_connections の推移](charts/EVT-20260706-host14-003.svg)

# イベントID( EVT-20260706-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→19→16→18→…→15→13→15→14
* 開始   : 2026-07-06 03:00:00 (UTC)
* 終了   : 2026-07-06 20:05:00 (UTC)
* 現象   : 2026-07-06 20:05:00 (UTC)を境に水準が 11.99から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.508σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.842, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-005 active_connections の推移](charts/EVT-20260706-host14-005.svg)

# イベントID( EVT-20260706-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→19→…→14→10→12→11
* 開始   : 2026-07-06 03:20:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.81から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.922, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.617, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-006 active_connections の推移](charts/EVT-20260706-host14-006.svg)

# イベントID( EVT-20260713-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→16→…→12→16→13→12
* 開始   : 2026-07-13 03:10:00 (UTC)
* 終了   : 2026-07-13 21:50:00 (UTC)
* 現象   : 2026-07-13 21:50:00 (UTC)を境に水準が 11.93から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.91, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-004 active_connections の推移](charts/EVT-20260713-host14-004.svg)

# イベントID( EVT-20260713-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→19→18→15→…→13→12→13→14
* 開始   : 2026-07-13 03:35:00 (UTC)
* 終了   : 2026-07-13 19:55:00 (UTC)
* 現象   : 2026-07-13 19:55:00 (UTC)を境に水準が 11.9から14.78へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.964σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.958, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-006 active_connections の推移](charts/EVT-20260713-host14-006.svg)

# イベントID( EVT-20260713-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→16→…→14→15→13→14
* 開始   : 2026-07-13 04:20:00 (UTC)
* 終了   : 2026-07-13 21:00:00 (UTC)
* 現象   : 2026-07-13 21:00:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.468σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.05, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-007 active_connections の推移](charts/EVT-20260713-host14-007.svg)

# イベントID( EVT-20260713-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→13→15→14→…→14→15→13→16
* 開始   : 2026-07-13 05:05:00 (UTC)
* 終了   : 2026-07-13 21:10:00 (UTC)
* 現象   : 2026-07-13 21:10:00 (UTC)を境に水準が 11.98から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.919σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.971, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-008 active_connections の推移](charts/EVT-20260713-host14-008.svg)

# イベントID( EVT-20260720-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→18→16→17→…→14→16→13→12
* 開始   : 2026-07-20 00:25:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.81から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-001 active_connections の推移](charts/EVT-20260720-host14-001.svg)

# イベントID( EVT-20260720-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→16→…→14→15→14→13
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 19:40:00 (UTC)
* 現象   : 2026-07-20 19:40:00 (UTC)を境に水準が 11.92から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.907, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.548, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-003 active_connections の推移](charts/EVT-20260720-host14-003.svg)

# イベントID( EVT-20260720-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→16→…→16→14→13→12
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 11.84から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.874σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-004 active_connections の推移](charts/EVT-20260720-host14-004.svg)

# イベントID( EVT-20260720-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→16→17→18→…→12→13→12→14
* 開始   : 2026-07-20 03:25:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.94から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-005 active_connections の推移](charts/EVT-20260720-host14-005.svg)

# イベントID( EVT-20260720-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→13→14→12→…→10→15→13→11
* 開始   : 2026-07-20 04:10:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.733, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-006 active_connections の推移](charts/EVT-20260720-host14-006.svg)

# イベントID( EVT-20260727-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→19→16→15→…→17→14→12→16
* 開始   : 2026-07-27 00:40:00 (UTC)
* 終了   : 2026-07-27 21:40:00 (UTC)
* 現象   : 2026-07-27 21:40:00 (UTC)を境に水準が 12から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.58, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-001 active_connections の推移](charts/EVT-20260727-host14-001.svg)

# イベントID( EVT-20260727-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→16→…→14→12→13→14
* 開始   : 2026-07-27 03:00:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.84から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.736σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.924, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.824, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-003 active_connections の推移](charts/EVT-20260727-host14-003.svg)

# イベントID( EVT-20260727-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→17→…→11→17→14→13
* 開始   : 2026-07-27 04:05:00 (UTC)
* 終了   : 2026-07-27 21:20:00 (UTC)
* 現象   : 2026-07-27 21:20:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.818, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-006 active_connections の推移](charts/EVT-20260727-host14-006.svg)

# イベントID( EVT-20260701-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→11→11
* 開始   : 2026-07-01 19:55:00 (UTC)
* 終了   : 2026-07-01 19:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→9→6→10→9
* 開始   : 2026-07-01 21:35:00 (UTC)
* 終了   : 2026-07-01 21:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→21→23→20→…→20→25→20→21
* 開始   : 2026-07-02 09:50:00 (UTC)
* 終了   : 2026-07-02 10:00:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260702-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→21→16→22→20
* 開始   : 2026-07-02 15:05:00 (UTC)
* 終了   : 2026-07-02 15:05:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→9→13→9→9
* 開始   : 2026-07-03 02:10:00 (UTC)
* 終了   : 2026-07-03 02:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→22→21→19→17→22→21→19
* 開始   : 2026-07-03 08:05:00 (UTC)
* 終了   : 2026-07-03 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→15→20→20
* 開始   : 2026-07-03 15:05:00 (UTC)
* 終了   : 2026-07-03 15:05:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7317(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host14-009 active_connections の推移](charts/EVT-20260703-host14-009.svg)

# イベントID( EVT-20260703-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→14→13
* 開始   : 2026-07-03 18:55:00 (UTC)
* 終了   : 2026-07-03 18:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-013 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→13→8→12→11
* 開始   : 2026-07-03 20:05:00 (UTC)
* 終了   : 2026-07-03 20:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→9→5→8→9
* 開始   : 2026-07-03 22:10:00 (UTC)
* 終了   : 2026-07-03 22:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 7→6→12→9→9
* 開始   : 2026-07-04 00:50:00 (UTC)
* 終了   : 2026-07-04 00:50:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260704-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→7→4→8→9
* 開始   : 2026-07-04 01:35:00 (UTC)
* 終了   : 2026-07-04 01:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260704-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→11→…→11→10→12→11
* 開始   : 2026-07-04 04:00:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.204, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 1.1 時間
  - EVT-20260704-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260704-host14-005 active_connections の推移](charts/EVT-20260704-host14-005.svg)

# イベントID( EVT-20260704-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→14→9→13→12
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 18:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.154, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260704-host14-007 active_connections の推移](charts/EVT-20260704-host14-007.svg)

# イベントID( EVT-20260704-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→12→…→13→9→12→10
* 開始   : 2026-07-04 05:55:00 (UTC)
* 終了   : 2026-07-04 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260704-host14-008 active_connections の推移](charts/EVT-20260704-host14-008.svg)

# イベントID( EVT-20260704-host14-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→…→13→12→13→8
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.926, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260704-host14-009 active_connections の推移](charts/EVT-20260704-host14-009.svg)

# イベントID( EVT-20260704-host14-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→12→10→12→…→13→12→13→11
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260704-host14-010 active_connections の推移](charts/EVT-20260704-host14-010.svg)

# イベントID( EVT-20260704-host14-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→10→12→13→…→14→11→14→12
* 開始   : 2026-07-04 06:20:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host14-011 active_connections の推移](charts/EVT-20260704-host14-011.svg)

# イベントID( EVT-20260705-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→12→7→11→10
* 開始   : 2026-07-05 19:20:00 (UTC)
* 終了   : 2026-07-05 19:20:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→12→18→14→…→14→12→13→12
* 開始   : 2026-07-06 01:35:00 (UTC)
* 終了   : 2026-07-06 21:05:00 (UTC)
* 現象   : 2026-07-06 21:05:00 (UTC)を境に水準が 11.87から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.163, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.839, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-001 active_connections の推移](charts/EVT-20260706-host14-001.svg)

# イベントID( EVT-20260706-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→13→15→14→…→12→13→12→13
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:50:00 (UTC)
* 現象   : 2026-07-06 20:50:00 (UTC)を境に水準が 11.71から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→17→20→18→17→20→18
* 開始   : 2026-07-07 06:35:00 (UTC)
* 終了   : 2026-07-07 07:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260707-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→16→20→16→16
* 開始   : 2026-07-07 06:50:00 (UTC)
* 終了   : 2026-07-07 06:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 23→21→18→19→18→22→22→23→23
* 開始   : 2026-07-07 08:05:00 (UTC)
* 終了   : 2026-07-07 09:00:00 (UTC)
* 現象   : 2026-07-07 09:00:00 (UTC)を境に水準が 14.92から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 21→19→17→18→17→18→17→18
* 開始   : 2026-07-07 14:40:00 (UTC)
* 終了   : 2026-07-07 15:45:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260707-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260707-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→11→8→11→12
* 開始   : 2026-07-07 20:05:00 (UTC)
* 終了   : 2026-07-07 20:05:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→10→8→10→10
* 開始   : 2026-07-07 20:20:00 (UTC)
* 終了   : 2026-07-07 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→16→19→16→18→19→16→18→15
* 開始   : 2026-07-08 06:10:00 (UTC)
* 終了   : 2026-07-08 06:20:00 (UTC)
* 現象   : 平常時(14)に対し 1.357倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host14-003 active_connections の推移](charts/EVT-20260708-host14-003.svg)

# イベントID( EVT-20260708-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→18→…→18→24→19→18
* 開始   : 2026-07-08 08:45:00 (UTC)
* 終了   : 2026-07-08 09:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→19→16→21→22
* 開始   : 2026-07-08 14:30:00 (UTC)
* 終了   : 2026-07-08 14:30:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→18→14→17→18
* 開始   : 2026-07-08 16:45:00 (UTC)
* 終了   : 2026-07-08 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→19→13→17→16
* 開始   : 2026-07-08 17:10:00 (UTC)
* 終了   : 2026-07-08 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.527σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host14-010 active_connections の推移](charts/EVT-20260708-host14-010.svg)

# イベントID( EVT-20260708-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→14→10→14→12
* 開始   : 2026-07-08 19:05:00 (UTC)
* 終了   : 2026-07-08 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→13→6→10→12
* 開始   : 2026-07-08 21:00:00 (UTC)
* 終了   : 2026-07-08 21:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-015 active_connections の推移](charts/EVT-20260708-host14-015.svg)

# イベントID( EVT-20260710-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→15→14
* 開始   : 2026-07-10 05:50:00 (UTC)
* 終了   : 2026-07-10 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.123σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→14→19→15→15
* 開始   : 2026-07-10 05:55:00 (UTC)
* 終了   : 2026-07-10 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.407倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host14-004 active_connections の推移](charts/EVT-20260710-host14-004.svg)

# イベントID( EVT-20260710-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→21→18→17→21→18→19
* 開始   : 2026-07-10 07:45:00 (UTC)
* 終了   : 2026-07-10 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→15→12→16→16
* 開始   : 2026-07-10 17:35:00 (UTC)
* 終了   : 2026-07-10 17:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→12→5→8→8
* 開始   : 2026-07-10 22:15:00 (UTC)
* 終了   : 2026-07-10 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260710-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→10→7
* 開始   : 2026-07-11 03:10:00 (UTC)
* 終了   : 2026-07-11 03:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→11→10→11→…→12→13→11→12
* 開始   : 2026-07-11 04:35:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260711-host14-002 active_connections の推移](charts/EVT-20260711-host14-002.svg)

# イベントID( EVT-20260711-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→12→…→12→11→12→13
* 開始   : 2026-07-11 04:40:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260711-host14-003 active_connections の推移](charts/EVT-20260711-host14-003.svg)

# イベントID( EVT-20260711-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→10→…→11→10→12→11
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.149, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host14-004 active_connections の推移](charts/EVT-20260711-host14-004.svg)

# イベントID( EVT-20260711-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10→…→12→11→12→11
* 開始   : 2026-07-11 05:20:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.951, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host14-005 active_connections の推移](charts/EVT-20260711-host14-005.svg)

# イベントID( EVT-20260711-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→14→…→13→12→11→13
* 開始   : 2026-07-11 05:35:00 (UTC)
* 終了   : 2026-07-11 17:55:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.816, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260711-host14-006 active_connections の推移](charts/EVT-20260711-host14-006.svg)

# イベントID( EVT-20260711-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→12→…→13→11→14→12
* 開始   : 2026-07-11 06:20:00 (UTC)
* 終了   : 2026-07-11 19:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260711-host14-007 active_connections の推移](charts/EVT-20260711-host14-007.svg)

# イベントID( EVT-20260712-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→11→10
* 開始   : 2026-07-12 04:10:00 (UTC)
* 終了   : 2026-07-12 04:10:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.622倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260712-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260712-host14-002 active_connections の推移](charts/EVT-20260712-host14-002.svg)

# イベントID( EVT-20260712-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→12→15→12→10
* 開始   : 2026-07-12 05:40:00 (UTC)
* 終了   : 2026-07-12 05:40:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→14→13
* 開始   : 2026-07-12 07:35:00 (UTC)
* 終了   : 2026-07-12 07:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→8→4→8→8
* 開始   : 2026-07-13 00:20:00 (UTC)
* 終了   : 2026-07-13 00:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260713-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→16→…→14→13→12→13
* 開始   : 2026-07-13 02:25:00 (UTC)
* 終了   : 2026-07-13 20:35:00 (UTC)
* 現象   : 2026-07-13 20:35:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.658, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→13→15→14→…→13→12→13→12
* 開始   : 2026-07-13 03:20:00 (UTC)
* 終了   : 2026-07-13 19:25:00 (UTC)
* 現象   : 2026-07-13 19:25:00 (UTC)を境に水準が 11.96から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.02, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→10→14→10→8
* 開始   : 2026-07-14 02:55:00 (UTC)
* 終了   : 2026-07-14 02:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→16→12→11
* 開始   : 2026-07-14 04:40:00 (UTC)
* 終了   : 2026-07-14 04:40:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host14-002 active_connections の推移](charts/EVT-20260714-host14-002.svg)

# イベントID( EVT-20260714-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→13→…→13→17→16→15
* 開始   : 2026-07-14 05:25:00 (UTC)
* 終了   : 2026-07-14 05:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260714-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host14-003 active_connections の推移](charts/EVT-20260714-host14-003.svg)

# イベントID( EVT-20260714-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→21→24→19→18
* 開始   : 2026-07-14 09:25:00 (UTC)
* 終了   : 2026-07-14 09:50:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260714-host14-004 active_connections の推移](charts/EVT-20260714-host14-004.svg)

# イベントID( EVT-20260714-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→14
* 開始   : 2026-07-14 20:00:00 (UTC)
* 終了   : 2026-07-14 20:30:00 (UTC)
* 現象   : 2026-07-14 20:30:00 (UTC)を境に水準が 14.91から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.046σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.769, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host14-009 active_connections の推移](charts/EVT-20260714-host14-009.svg)

# イベントID( EVT-20260715-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→13→18→14→13
* 開始   : 2026-07-15 05:50:00 (UTC)
* 終了   : 2026-07-15 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→25→20→22→17→22→21→22→23
* 開始   : 2026-07-15 09:00:00 (UTC)
* 終了   : 2026-07-15 10:00:00 (UTC)
* 現象   : 2026-07-15 10:00:00 (UTC)を境に水準が 14.93から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→26→22→22→24→23
* 開始   : 2026-07-15 12:10:00 (UTC)
* 終了   : 2026-07-15 12:35:00 (UTC)
* 現象   : 2026-07-15 12:35:00 (UTC)を境に水準が 14.98から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.728, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→18→15→19→17
* 開始   : 2026-07-15 15:40:00 (UTC)
* 終了   : 2026-07-15 15:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.7531(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-010 active_connections の推移](charts/EVT-20260715-host14-010.svg)

# イベントID( EVT-20260715-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→15→14→15→18→15→14→15→17
* 開始   : 2026-07-15 17:30:00 (UTC)
* 終了   : 2026-07-15 18:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260715-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→14→…→14→11→15→14
* 開始   : 2026-07-15 18:10:00 (UTC)
* 終了   : 2026-07-15 18:20:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→18→18
* 開始   : 2026-07-16 07:30:00 (UTC)
* 終了   : 2026-07-16 07:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host14-005 active_connections の推移](charts/EVT-20260716-host14-005.svg)

# イベントID( EVT-20260716-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→19→24→22→20
* 開始   : 2026-07-16 09:05:00 (UTC)
* 終了   : 2026-07-16 09:05:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→21→26→22→21
* 開始   : 2026-07-16 10:55:00 (UTC)
* 終了   : 2026-07-16 10:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 24→20→17→21→19
* 開始   : 2026-07-16 14:15:00 (UTC)
* 終了   : 2026-07-16 14:15:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→13→10→13→10→12→11
* 開始   : 2026-07-16 19:20:00 (UTC)
* 終了   : 2026-07-16 19:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260716-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→10→5→10→9
* 開始   : 2026-07-16 22:25:00 (UTC)
* 終了   : 2026-07-16 22:25:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→17→13→16→15
* 開始   : 2026-07-17 17:10:00 (UTC)
* 終了   : 2026-07-17 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.544σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host14-008 active_connections の推移](charts/EVT-20260717-host14-008.svg)

# イベントID( EVT-20260717-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→11→6→7→9→11→6→7→9
* 開始   : 2026-07-17 21:10:00 (UTC)
* 終了   : 2026-07-17 21:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-087 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→12→13→12→…→11→13→10→11
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.013, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host14-001 active_connections の推移](charts/EVT-20260718-host14-001.svg)

# イベントID( EVT-20260718-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→…→11→8→11→10
* 開始   : 2026-07-18 05:10:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260718-host14-002 active_connections の推移](charts/EVT-20260718-host14-002.svg)

# イベントID( EVT-20260718-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→10→…→12→14→11→13
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 20:10:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.158, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260718-host14-003 active_connections の推移](charts/EVT-20260718-host14-003.svg)

# イベントID( EVT-20260718-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→12→8→12→…→11→12→11→14
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.771, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host14-004 active_connections の推移](charts/EVT-20260718-host14-004.svg)

# イベントID( EVT-20260718-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→10→13→14→…→11→12→11→13
* 開始   : 2026-07-18 06:20:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.928, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260718-host14-005 active_connections の推移](charts/EVT-20260718-host14-005.svg)

# イベントID( EVT-20260718-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→12→…→12→10→13→11
* 開始   : 2026-07-18 06:50:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.939, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260718-host14-006 active_connections の推移](charts/EVT-20260718-host14-006.svg)

# イベントID( EVT-20260718-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→10→4→8→8
* 開始   : 2026-07-18 23:50:00 (UTC)
* 終了   : 2026-07-18 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260718-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→13→12→15→14→14
* 開始   : 2026-07-19 06:50:00 (UTC)
* 終了   : 2026-07-19 07:15:00 (UTC)
* 現象   : 2026-07-19 07:15:00 (UTC)を境に水準が 11.75から12.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.502σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→10→10
* 開始   : 2026-07-19 21:15:00 (UTC)
* 終了   : 2026-07-19 21:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→16→…→13→14→13→15
* 開始   : 2026-07-20 02:25:00 (UTC)
* 終了   : 2026-07-20 21:05:00 (UTC)
* 現象   : 2026-07-20 21:05:00 (UTC)を境に水準が 11.8から14.87へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.667, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→8→12→9→9
* 開始   : 2026-07-21 01:00:00 (UTC)
* 終了   : 2026-07-21 01:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→10→8→12→10→9
* 開始   : 2026-07-21 03:15:00 (UTC)
* 終了   : 2026-07-21 03:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260721-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→14→19→16→14
* 開始   : 2026-07-21 06:25:00 (UTC)
* 終了   : 2026-07-21 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→8→…→8→4→11→8
* 開始   : 2026-07-21 22:55:00 (UTC)
* 終了   : 2026-07-21 23:05:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→9→4→9→7
* 開始   : 2026-07-21 23:25:00 (UTC)
* 終了   : 2026-07-21 23:25:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→16→22→21→19
* 開始   : 2026-07-22 08:20:00 (UTC)
* 終了   : 2026-07-22 08:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→24→20→19
* 開始   : 2026-07-22 08:40:00 (UTC)
* 終了   : 2026-07-22 08:40:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.286倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.699σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host14-004 active_connections の推移](charts/EVT-20260722-host14-004.svg)

# イベントID( EVT-20260722-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→21→17→21→21
* 開始   : 2026-07-22 13:50:00 (UTC)
* 終了   : 2026-07-22 13:50:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→12→15→17
* 開始   : 2026-07-22 18:00:00 (UTC)
* 終了   : 2026-07-22 18:00:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260722-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→10→7→10→10
* 開始   : 2026-07-22 21:05:00 (UTC)
* 終了   : 2026-07-22 21:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→13→18→13→13
* 開始   : 2026-07-23 05:25:00 (UTC)
* 終了   : 2026-07-23 05:25:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→17→19→14→15→17→19→14→15
* 開始   : 2026-07-23 06:00:00 (UTC)
* 終了   : 2026-07-23 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260723-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host14-003 active_connections の推移](charts/EVT-20260723-host14-003.svg)

# イベントID( EVT-20260723-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→17→…→18→17→16→17
* 開始   : 2026-07-23 06:05:00 (UTC)
* 終了   : 2026-07-23 06:10:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260723-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→16→22→17→18
* 開始   : 2026-07-23 07:45:00 (UTC)
* 終了   : 2026-07-23 07:45:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-005 active_connections の推移](charts/EVT-20260723-host14-005.svg)

# イベントID( EVT-20260723-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→19→19→20→19→20→23→20→20
* 開始   : 2026-07-23 07:55:00 (UTC)
* 終了   : 2026-07-23 08:45:00 (UTC)
* 現象   : 2026-07-23 08:45:00 (UTC)を境に水準が 14.84から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→19→22→16→18
* 開始   : 2026-07-23 08:00:00 (UTC)
* 終了   : 2026-07-23 08:00:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→22→25→22→23
* 開始   : 2026-07-23 10:25:00 (UTC)
* 終了   : 2026-07-23 10:25:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.235倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→19→…→19→14→19→20
* 開始   : 2026-07-23 15:45:00 (UTC)
* 終了   : 2026-07-23 15:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-012 active_connections の推移](charts/EVT-20260723-host14-012.svg)

# イベントID( EVT-20260723-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→16→13→17→16
* 開始   : 2026-07-23 17:45:00 (UTC)
* 終了   : 2026-07-23 17:45:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260723-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→18→17→15→14→13→13→14→18
* 開始   : 2026-07-23 17:45:00 (UTC)
* 終了   : 2026-07-23 19:25:00 (UTC)
* 現象   : 2026-07-23 19:25:00 (UTC)を境に水準が 14.98から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→12→15→12→15→11→13
* 開始   : 2026-07-24 03:35:00 (UTC)
* 終了   : 2026-07-24 04:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.431倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260724-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260724-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→14→15→14→15→14
* 開始   : 2026-07-24 04:55:00 (UTC)
* 終了   : 2026-07-24 05:35:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 35 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260724-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→16
* 開始   : 2026-07-24 06:15:00 (UTC)
* 終了   : 2026-07-24 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.39倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.699σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-007 active_connections の推移](charts/EVT-20260724-host14-007.svg)

# イベントID( EVT-20260724-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→9→9
* 開始   : 2026-07-24 21:55:00 (UTC)
* 終了   : 2026-07-24 21:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→8→4→6→9
* 開始   : 2026-07-25 01:05:00 (UTC)
* 終了   : 2026-07-25 01:05:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→13→12→13→12
* 開始   : 2026-07-25 04:40:00 (UTC)
* 終了   : 2026-07-25 18:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.008, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 13.4 時間

![EVT-20260725-host14-002 active_connections の推移](charts/EVT-20260725-host14-002.svg)

# イベントID( EVT-20260725-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→10→…→10→8→10→9
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 19:40:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260725-host14-003 active_connections の推移](charts/EVT-20260725-host14-003.svg)

# イベントID( EVT-20260725-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→13→…→14→13→11→12
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 18:30:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260725-host14-004 active_connections の推移](charts/EVT-20260725-host14-004.svg)

# イベントID( EVT-20260725-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→10→11→14→11
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host14-005 active_connections の推移](charts/EVT-20260725-host14-005.svg)

# イベントID( EVT-20260725-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→12→…→12→11→12→11
* 開始   : 2026-07-25 06:15:00 (UTC)
* 終了   : 2026-07-25 19:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.027, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260725-host14-006 active_connections の推移](charts/EVT-20260725-host14-006.svg)

# イベントID( EVT-20260725-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→14→…→11→13→12→11
* 開始   : 2026-07-25 06:20:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.063, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host14-007 active_connections の推移](charts/EVT-20260725-host14-007.svg)

# イベントID( EVT-20260725-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→8→5→7→9
* 開始   : 2026-07-25 21:15:00 (UTC)
* 終了   : 2026-07-25 21:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→8→6→9→8
* 開始   : 2026-07-26 04:10:00 (UTC)
* 終了   : 2026-07-26 04:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260726-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→21→15→15
* 開始   : 2026-07-26 10:55:00 (UTC)
* 終了   : 2026-07-26 10:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.416倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260726-host14-003 active_connections の推移](charts/EVT-20260726-host14-003.svg)

# イベントID( EVT-20260726-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→12→8→12→12
* 開始   : 2026-07-26 18:15:00 (UTC)
* 終了   : 2026-07-26 18:15:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→16→…→16→14→12→14
* 開始   : 2026-07-27 01:45:00 (UTC)
* 終了   : 2026-07-27 20:45:00 (UTC)
* 現象   : 2026-07-27 20:45:00 (UTC)を境に水準が 11.77から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.145, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→16→15→16→…→15→14→16→14
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 19:05:00 (UTC)
* 現象   : 2026-07-27 19:05:00 (UTC)を境に水準が 11.96から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.098, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.625, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-004 active_connections の推移](charts/EVT-20260727-host14-004.svg)

# イベントID( EVT-20260727-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→14→15→13→14
* 開始   : 2026-07-27 03:40:00 (UTC)
* 終了   : 2026-07-27 19:25:00 (UTC)
* 現象   : 2026-07-27 19:25:00 (UTC)を境に水準が 11.91から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.689, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.648, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-005 active_connections の推移](charts/EVT-20260727-host14-005.svg)

# イベントID( EVT-20260728-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→11→16→13→13
* 開始   : 2026-07-28 04:45:00 (UTC)
* 終了   : 2026-07-28 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→14→16→18
* 開始   : 2026-07-28 16:45:00 (UTC)
* 終了   : 2026-07-28 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→12→9
* 開始   : 2026-07-28 20:50:00 (UTC)
* 終了   : 2026-07-28 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-066 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260728-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→22→16→22→23
* 開始   : 2026-07-29 14:15:00 (UTC)
* 終了   : 2026-07-29 14:15:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host14-008 active_connections の推移](charts/EVT-20260729-host14-008.svg)

# イベントID( EVT-20260729-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→22→16→20→19
* 開始   : 2026-07-29 15:25:00 (UTC)
* 終了   : 2026-07-29 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→14→12→16→…→16→13→15→17
* 開始   : 2026-07-29 17:45:00 (UTC)
* 終了   : 2026-07-29 18:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260729-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→15→13→11→15→13
* 開始   : 2026-07-29 18:15:00 (UTC)
* 終了   : 2026-07-29 19:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 40 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260729-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260729-host14-011 active_connections の推移](charts/EVT-20260729-host14-011.svg)

# イベントID( EVT-20260729-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→8→5→8→10
* 開始   : 2026-07-29 22:00:00 (UTC)
* 終了   : 2026-07-29 22:00:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→9→9→9→9→9→11
* 開始   : 2026-07-30 01:25:00 (UTC)
* 終了   : 2026-07-30 02:10:00 (UTC)
* 現象   : 2026-07-30 02:10:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.583σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 23→23→26→22→22
* 開始   : 2026-07-30 13:20:00 (UTC)
* 終了   : 2026-07-30 13:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→11→12
* 開始   : 2026-07-30 20:10:00 (UTC)
* 終了   : 2026-07-30 20:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-081 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→6→12→9→7
* 開始   : 2026-07-31 00:40:00 (UTC)
* 終了   : 2026-07-31 00:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→10→14→11→13
* 開始   : 2026-07-31 03:45:00 (UTC)
* 終了   : 2026-07-31 03:45:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→11→16→12→11
* 開始   : 2026-07-31 04:45:00 (UTC)
* 終了   : 2026-07-31 04:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→11→16→14→13→14→18
* 開始   : 2026-07-31 04:50:00 (UTC)
* 終了   : 2026-07-31 05:25:00 (UTC)
* 現象   : 2026-07-31 05:25:00 (UTC)を境に水準が 14.86から14.76へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.567σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→12→15→12→15→12→14
* 開始   : 2026-07-31 17:20:00 (UTC)
* 終了   : 2026-07-31 18:30:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.353σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260731-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→11→9→12→12
* 開始   : 2026-07-31 19:25:00 (UTC)
* 終了   : 2026-07-31 19:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→9→8→8→9→10
* 開始   : 2026-07-01 00:45:00 (UTC)
* 終了   : 2026-07-01 01:10:00 (UTC)
* 現象   : 2026-07-01 01:10:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.728, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→12→16→15→16→15→16→14→16
* 開始   : 2026-07-01 05:40:00 (UTC)
* 終了   : 2026-07-01 05:50:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→15→18→16→12→18→16→12→17
* 開始   : 2026-07-01 06:20:00 (UTC)
* 終了   : 2026-07-01 06:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→17→19→17→19→18
* 開始   : 2026-07-01 07:10:00 (UTC)
* 終了   : 2026-07-01 07:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→9→9→10→9→10
* 開始   : 2026-07-01 22:25:00 (UTC)
* 終了   : 2026-07-01 22:50:00 (UTC)
* 現象   : 2026-07-01 22:50:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.463, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→13→17→18→…→17→18→15→14
* 開始   : 2026-07-02 05:45:00 (UTC)
* 終了   : 2026-07-02 05:50:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→17→19→17→19→16→17
* 開始   : 2026-07-02 06:45:00 (UTC)
* 終了   : 2026-07-02 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.774σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→18→17→19→18→17→19→16
* 開始   : 2026-07-02 06:50:00 (UTC)
* 終了   : 2026-07-02 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→20→20→20→19→21→20
* 開始   : 2026-07-02 07:00:00 (UTC)
* 終了   : 2026-07-02 08:40:00 (UTC)
* 現象   : 2026-07-02 08:40:00 (UTC)を境に水準が 14.94から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.932, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→17→19→17→18
* 開始   : 2026-07-02 07:10:00 (UTC)
* 終了   : 2026-07-02 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→17→22→18→…→18→16→21→20
* 開始   : 2026-07-02 08:40:00 (UTC)
* 終了   : 2026-07-02 08:50:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→21→24→22→…→22→25→23→22
* 開始   : 2026-07-02 10:40:00 (UTC)
* 終了   : 2026-07-02 10:50:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→23→21→21→22→20→20→23→24
* 開始   : 2026-07-02 13:20:00 (UTC)
* 終了   : 2026-07-02 14:55:00 (UTC)
* 現象   : 2026-07-02 14:55:00 (UTC)を境に水準が 14.95から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.883, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→13→15→13→15→13→16→13
* 開始   : 2026-07-02 17:50:00 (UTC)
* 終了   : 2026-07-02 18:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260702-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260702-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→15→13→16→…→14→12→15→14
* 開始   : 2026-07-02 18:00:00 (UTC)
* 終了   : 2026-07-02 19:15:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260702-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→16→12→11→…→13→10→13→14
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 19:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260702-host14-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 7→10→13→10→13→10→13→9→12
* 開始   : 2026-07-03 02:50:00 (UTC)
* 終了   : 2026-07-03 03:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.431倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.718σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→11→12
* 開始   : 2026-07-03 02:55:00 (UTC)
* 終了   : 2026-07-03 04:20:00 (UTC)
* 現象   : 2026-07-03 04:20:00 (UTC)を境に水準が 14.81から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.537, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→16→12→16→12→16→13
* 開始   : 2026-07-03 04:50:00 (UTC)
* 終了   : 2026-07-03 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→14→18→14→18→16
* 開始   : 2026-07-03 06:30:00 (UTC)
* 終了   : 2026-07-03 06:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→18→17→17→19→19
* 開始   : 2026-07-03 07:00:00 (UTC)
* 終了   : 2026-07-03 07:25:00 (UTC)
* 現象   : 2026-07-03 07:25:00 (UTC)を境に水準が 14.89から14.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→20→22→20→21→23→24
* 開始   : 2026-07-03 09:45:00 (UTC)
* 終了   : 2026-07-03 11:15:00 (UTC)
* 現象   : 2026-07-03 11:15:00 (UTC)を境に水準が 14.97から13.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→15→17→15→17→15→17
* 開始   : 2026-07-03 16:45:00 (UTC)
* 終了   : 2026-07-03 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→7→10→7→10→8
* 開始   : 2026-07-03 21:40:00 (UTC)
* 終了   : 2026-07-03 21:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260703-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 7→9→12→10→9→12→10
* 開始   : 2026-07-04 03:45:00 (UTC)
* 終了   : 2026-07-04 03:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→10→…→13→10→11→13
* 開始   : 2026-07-04 03:50:00 (UTC)
* 終了   : 2026-07-04 05:05:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.723, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.1 時間
  - EVT-20260704-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 35 分
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260704-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→8→13→11→8→13→11
* 開始   : 2026-07-04 04:15:00 (UTC)
* 終了   : 2026-07-04 04:20:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.418倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260704-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host14-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→11→8→9→11→8→9→10
* 開始   : 2026-07-04 19:50:00 (UTC)
* 終了   : 2026-07-04 19:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260704-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→11→12→12→10→11→14
* 開始   : 2026-07-05 03:55:00 (UTC)
* 終了   : 2026-07-05 05:20:00 (UTC)
* 現象   : 2026-07-05 05:20:00 (UTC)を境に水準が 11.89から12.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→12→11→14→12→13
* 開始   : 2026-07-05 06:00:00 (UTC)
* 終了   : 2026-07-05 06:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260705-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→14→16→15→13
* 開始   : 2026-07-05 07:15:00 (UTC)
* 終了   : 2026-07-05 07:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→15→16→15→16→16→14
* 開始   : 2026-07-05 08:45:00 (UTC)
* 終了   : 2026-07-05 09:15:00 (UTC)
* 現象   : 2026-07-05 09:15:00 (UTC)を境に水準が 11.93から12.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→16
* 開始   : 2026-07-05 17:30:00 (UTC)
* 終了   : 2026-07-05 17:45:00 (UTC)
* 現象   : 2026-07-05 17:45:00 (UTC)を境に水準が 11.97から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.799, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→12→…→12→8→12→14
* 開始   : 2026-07-05 18:10:00 (UTC)
* 終了   : 2026-07-05 18:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260705-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260705-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260705-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→8→11→10→9→7→11→11→10
* 開始   : 2026-07-05 20:30:00 (UTC)
* 終了   : 2026-07-05 22:45:00 (UTC)
* 現象   : 2026-07-05 22:45:00 (UTC)を境に水準が 11.83から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→9→6→12→…→12→7→8→10
* 開始   : 2026-07-05 20:45:00 (UTC)
* 終了   : 2026-07-05 20:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-040 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260705-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260705-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→8→8→9→11→8→11→8→11
* 開始   : 2026-07-06 22:20:00 (UTC)
* 終了   : 2026-07-06 23:00:00 (UTC)
* 現象   : 2026-07-06 23:00:00 (UTC)を境に水準が 15.05から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→12→5→8→9→12→5→8→7
* 開始   : 2026-07-06 23:20:00 (UTC)
* 終了   : 2026-07-06 23:25:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260706-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260706-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→12→…→12→14→13→9
* 開始   : 2026-07-07 03:40:00 (UTC)
* 終了   : 2026-07-07 03:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260707-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→13→12→15→13→14
* 開始   : 2026-07-07 05:00:00 (UTC)
* 終了   : 2026-07-07 05:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→17→21→17→21→17
* 開始   : 2026-07-07 08:10:00 (UTC)
* 終了   : 2026-07-07 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260707-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→20→19→17→20→19
* 開始   : 2026-07-07 15:10:00 (UTC)
* 終了   : 2026-07-07 15:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→11→14→15→…→14→15→12→13
* 開始   : 2026-07-08 04:50:00 (UTC)
* 終了   : 2026-07-08 05:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 15 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→16→18→16→18→16→15
* 開始   : 2026-07-08 06:10:00 (UTC)
* 終了   : 2026-07-08 06:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→22→18→22→19→22→19→21
* 開始   : 2026-07-08 08:40:00 (UTC)
* 終了   : 2026-07-08 08:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→17→24→22→21→17→24→22→19
* 開始   : 2026-07-08 09:50:00 (UTC)
* 終了   : 2026-07-08 09:55:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260708-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→17→15→17→15→17
* 開始   : 2026-07-08 17:10:00 (UTC)
* 終了   : 2026-07-08 17:20:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260708-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→16→14→17→14→17→14→15→14
* 開始   : 2026-07-08 17:30:00 (UTC)
* 終了   : 2026-07-08 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→15→12→15→12→14
* 開始   : 2026-07-08 18:45:00 (UTC)
* 終了   : 2026-07-08 18:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→10→…→13→10→12→14
* 開始   : 2026-07-08 19:20:00 (UTC)
* 終了   : 2026-07-08 19:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260708-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→7→9→11→6→9→9→9→11
* 開始   : 2026-07-09 00:40:00 (UTC)
* 終了   : 2026-07-09 02:10:00 (UTC)
* 現象   : 2026-07-09 02:10:00 (UTC)を境に水準が 15.09から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→8→10→9→10→10→9→12→11
* 開始   : 2026-07-09 01:40:00 (UTC)
* 終了   : 2026-07-09 03:00:00 (UTC)
* 現象   : 2026-07-09 03:00:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→9→12→9→12→9
* 開始   : 2026-07-09 02:05:00 (UTC)
* 終了   : 2026-07-09 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→11→12→11→12→13→13
* 開始   : 2026-07-09 03:15:00 (UTC)
* 終了   : 2026-07-09 03:50:00 (UTC)
* 現象   : 2026-07-09 03:50:00 (UTC)を境に水準が 15.19から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→14→14
* 開始   : 2026-07-09 04:25:00 (UTC)
* 終了   : 2026-07-09 04:45:00 (UTC)
* 現象   : 2026-07-09 04:45:00 (UTC)を境に水準が 15.07から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→16→18→16→18→16→18→17→14
* 開始   : 2026-07-09 06:25:00 (UTC)
* 終了   : 2026-07-09 06:35:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→19→20→16→17→19→20→16→17
* 開始   : 2026-07-09 07:15:00 (UTC)
* 終了   : 2026-07-09 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260709-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→15→19→17→15→19→17→16
* 開始   : 2026-07-09 07:15:00 (UTC)
* 終了   : 2026-07-09 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260709-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→23→19→18→…→19→18→21→24
* 開始   : 2026-07-09 13:55:00 (UTC)
* 終了   : 2026-07-09 14:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→14→17→13→14→17→13→14→16
* 開始   : 2026-07-09 17:25:00 (UTC)
* 終了   : 2026-07-09 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260709-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→10→8→9→10→9→9→10→9
* 開始   : 2026-07-09 22:05:00 (UTC)
* 終了   : 2026-07-09 23:00:00 (UTC)
* 現象   : 2026-07-09 23:00:00 (UTC)を境に水準が 14.87から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.397, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→11→5→9→8→11→5→9→8
* 開始   : 2026-07-10 01:10:00 (UTC)
* 終了   : 2026-07-10 01:15:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→15→13→12→15→14→14→15→14
* 開始   : 2026-07-10 04:25:00 (UTC)
* 終了   : 2026-07-10 05:35:00 (UTC)
* 現象   : 2026-07-10 05:35:00 (UTC)を境に水準が 15.09から14.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→18→20→18→19→21
* 開始   : 2026-07-10 07:15:00 (UTC)
* 終了   : 2026-07-10 07:40:00 (UTC)
* 現象   : 2026-07-10 07:40:00 (UTC)を境に水準が 14.9から14.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.463, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→23→24→23→24→22→21
* 開始   : 2026-07-10 10:45:00 (UTC)
* 終了   : 2026-07-10 10:55:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→18→20→18→20→18
* 開始   : 2026-07-10 14:40:00 (UTC)
* 終了   : 2026-07-10 14:45:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260710-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→20→18→20→18→22
* 開始   : 2026-07-10 14:55:00 (UTC)
* 終了   : 2026-07-10 15:20:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260710-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→12→15→11→12→11
* 開始   : 2026-07-10 19:05:00 (UTC)
* 終了   : 2026-07-10 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host14-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→13→11→13→11
* 開始   : 2026-07-10 19:10:00 (UTC)
* 終了   : 2026-07-10 19:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host14-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260710-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→9→11→10→9→11
* 開始   : 2026-07-10 20:00:00 (UTC)
* 終了   : 2026-07-10 20:05:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→10→8→10→8→9→10
* 開始   : 2026-07-10 20:40:00 (UTC)
* 終了   : 2026-07-10 20:50:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260710-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260710-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→10→8→6→7→10→9→8→11
* 開始   : 2026-07-11 23:15:00 (UTC)
* 終了   : 2026-07-11 23:55:00 (UTC)
* 現象   : 2026-07-11 23:55:00 (UTC)を境に水準が 11.73から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260711-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 8→11→9→11→9→11→7→9
* 開始   : 2026-07-12 00:40:00 (UTC)
* 終了   : 2026-07-12 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→13→17→11→13→17→14
* 開始   : 2026-07-12 08:20:00 (UTC)
* 終了   : 2026-07-12 08:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→12→17→13→…→17→11→13→15
* 開始   : 2026-07-12 08:30:00 (UTC)
* 終了   : 2026-07-12 08:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260712-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→18→17→16
* 開始   : 2026-07-12 13:00:00 (UTC)
* 終了   : 2026-07-12 13:15:00 (UTC)
* 現象   : 2026-07-12 13:15:00 (UTC)を境に水準が 11.85から13.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→12→10→12→11→12→12
* 開始   : 2026-07-12 18:40:00 (UTC)
* 終了   : 2026-07-12 19:25:00 (UTC)
* 現象   : 2026-07-12 19:25:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host14-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→10→11→10→9→11→14
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 03:50:00 (UTC)
* 現象   : 2026-07-13 03:50:00 (UTC)を境に水準が 11.86から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.893, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 24→23→19→24→19→24→19→21
* 開始   : 2026-07-14 12:00:00 (UTC)
* 終了   : 2026-07-14 12:10:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.8413(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→14→15→17→14→16→17
* 開始   : 2026-07-14 17:00:00 (UTC)
* 終了   : 2026-07-14 17:10:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260714-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→16→14→19→14→19→14→16→15
* 開始   : 2026-07-14 17:10:00 (UTC)
* 終了   : 2026-07-14 17:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→9→10→9→11→10
* 開始   : 2026-07-14 19:50:00 (UTC)
* 終了   : 2026-07-14 20:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260714-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→8→9→8→9→8→11
* 開始   : 2026-07-14 20:25:00 (UTC)
* 終了   : 2026-07-14 20:35:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 7→5→8→11→5→8→11→6→8
* 開始   : 2026-07-14 23:40:00 (UTC)
* 終了   : 2026-07-14 23:50:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→13→9→13→11
* 開始   : 2026-07-15 03:45:00 (UTC)
* 終了   : 2026-07-15 03:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→10→14→12→14→12→14→13→14
* 開始   : 2026-07-15 04:10:00 (UTC)
* 終了   : 2026-07-15 04:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→14→12→16→14→13
* 開始   : 2026-07-15 05:20:00 (UTC)
* 終了   : 2026-07-15 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260715-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→15→14→16→17→15→12
* 開始   : 2026-07-15 05:25:00 (UTC)
* 終了   : 2026-07-15 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260715-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 24→23→19→23→19→23→19→23
* 開始   : 2026-07-15 13:15:00 (UTC)
* 終了   : 2026-07-15 13:25:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→22→18→22→18→22
* 開始   : 2026-07-15 14:30:00 (UTC)
* 終了   : 2026-07-15 14:35:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→15→17→14→15→17→14→16
* 開始   : 2026-07-15 16:45:00 (UTC)
* 終了   : 2026-07-15 16:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→19→20→18→17→18→19→15→17
* 開始   : 2026-07-15 17:00:00 (UTC)
* 終了   : 2026-07-15 19:00:00 (UTC)
* 現象   : 2026-07-15 19:00:00 (UTC)を境に水準が 15から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→12→13→12→13→12→14→12
* 開始   : 2026-07-15 18:40:00 (UTC)
* 終了   : 2026-07-15 18:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→11→12→13→11→12→13→11→10
* 開始   : 2026-07-16 03:10:00 (UTC)
* 終了   : 2026-07-16 03:15:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260716-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→13→12→14→13
* 開始   : 2026-07-16 04:20:00 (UTC)
* 終了   : 2026-07-16 04:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→16→19→18→19→18→19→15→17
* 開始   : 2026-07-16 06:50:00 (UTC)
* 終了   : 2026-07-16 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→18→19→16→19→16→19→17→18
* 開始   : 2026-07-16 07:00:00 (UTC)
* 終了   : 2026-07-16 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→18→23→16→19→18→23→16→19
* 開始   : 2026-07-16 15:15:00 (UTC)
* 終了   : 2026-07-16 15:20:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→7→8→11→8→11→10→8
* 開始   : 2026-07-17 00:50:00 (UTC)
* 終了   : 2026-07-17 01:25:00 (UTC)
* 現象   : 2026-07-17 01:25:00 (UTC)を境に水準が 14.89から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→16→18→17→16→18→16
* 開始   : 2026-07-17 06:15:00 (UTC)
* 終了   : 2026-07-17 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→19→17→15
* 開始   : 2026-07-17 06:55:00 (UTC)
* 終了   : 2026-07-17 07:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→19→17→19→17→19→15→17
* 開始   : 2026-07-17 07:00:00 (UTC)
* 終了   : 2026-07-17 07:10:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→17→18→20→21→17→19
* 開始   : 2026-07-17 07:45:00 (UTC)
* 終了   : 2026-07-17 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→23
* 開始   : 2026-07-17 15:20:00 (UTC)
* 終了   : 2026-07-17 15:25:00 (UTC)
* 現象   : 2026-07-17 15:25:00 (UTC)を境に水準が 15.02から12.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.769, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→22→21→20→17→19→19→19→21
* 開始   : 2026-07-17 15:25:00 (UTC)
* 終了   : 2026-07-17 16:10:00 (UTC)
* 現象   : 2026-07-17 16:10:00 (UTC)を境に水準が 14.93から12.51へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→11→14→11→14→11→13
* 開始   : 2026-07-17 19:15:00 (UTC)
* 終了   : 2026-07-17 20:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分

![EVT-20260717-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→10→10→10
* 開始   : 2026-07-17 22:10:00 (UTC)
* 終了   : 2026-07-17 22:25:00 (UTC)
* 現象   : 2026-07-17 22:25:00 (UTC)を境に水準が 14.89から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→11→10
* 開始   : 2026-07-17 23:20:00 (UTC)
* 終了   : 2026-07-17 23:40:00 (UTC)
* 現象   : 2026-07-17 23:40:00 (UTC)を境に水準が 14.97から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 6→8→11→8→11→8→11→6→9
* 開始   : 2026-07-17 23:45:00 (UTC)
* 終了   : 2026-07-17 23:55:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→10→…→16→10→13→14
* 開始   : 2026-07-19 07:35:00 (UTC)
* 終了   : 2026-07-19 07:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→11→12→10→13→12→12→11→14
* 開始   : 2026-07-21 03:15:00 (UTC)
* 終了   : 2026-07-21 04:05:00 (UTC)
* 現象   : 2026-07-21 04:05:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.227, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→13→14→15→15→15→17
* 開始   : 2026-07-21 05:00:00 (UTC)
* 終了   : 2026-07-21 05:30:00 (UTC)
* 現象   : 2026-07-21 05:30:00 (UTC)を境に水準が 14.84から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.932, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→17→14→17→14→16
* 開始   : 2026-07-21 05:55:00 (UTC)
* 終了   : 2026-07-21 06:00:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260721-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→16→13→19→…→13→19→20→17
* 開始   : 2026-07-21 07:00:00 (UTC)
* 終了   : 2026-07-21 07:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→19→21→19→21→19→21→19→18
* 開始   : 2026-07-21 08:10:00 (UTC)
* 終了   : 2026-07-21 08:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→22→22→22→20→24→20→24→24
* 開始   : 2026-07-21 10:05:00 (UTC)
* 終了   : 2026-07-21 11:05:00 (UTC)
* 現象   : 2026-07-21 11:05:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→16→17→16→20→19
* 開始   : 2026-07-21 15:45:00 (UTC)
* 終了   : 2026-07-21 15:55:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260721-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→10→8→10→8→9
* 開始   : 2026-07-21 21:05:00 (UTC)
* 終了   : 2026-07-21 21:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→10→9→10→11→9→10
* 開始   : 2026-07-22 00:30:00 (UTC)
* 終了   : 2026-07-22 01:10:00 (UTC)
* 現象   : 2026-07-22 01:10:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→15→12→15→12→15→14
* 開始   : 2026-07-22 04:30:00 (UTC)
* 終了   : 2026-07-22 04:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→22→24→22→…→22→18→20→23
* 開始   : 2026-07-22 09:50:00 (UTC)
* 終了   : 2026-07-22 10:00:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260722-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 23→25→23→23→24
* 開始   : 2026-07-22 10:20:00 (UTC)
* 終了   : 2026-07-22 10:40:00 (UTC)
* 現象   : 2026-07-22 10:40:00 (UTC)を境に水準が 15.09から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.951, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→17→21→18→17→15→17→18→16
* 開始   : 2026-07-22 15:45:00 (UTC)
* 終了   : 2026-07-22 17:10:00 (UTC)
* 現象   : 2026-07-22 17:10:00 (UTC)を境に水準が 14.9から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→15→12→14→15→12→14→12
* 開始   : 2026-07-22 18:30:00 (UTC)
* 終了   : 2026-07-22 18:35:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host14-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→16→12→11→…→12→11→14→15
* 開始   : 2026-07-22 18:35:00 (UTC)
* 終了   : 2026-07-22 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host14-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→9→8→10→9→11→12→10→10
* 開始   : 2026-07-23 00:50:00 (UTC)
* 終了   : 2026-07-23 03:10:00 (UTC)
* 現象   : 2026-07-23 03:10:00 (UTC)を境に水準が 14.93から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.144, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→21→24→22→21→24→22
* 開始   : 2026-07-23 10:25:00 (UTC)
* 終了   : 2026-07-23 10:30:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→18→…→24→18→19→21
* 開始   : 2026-07-23 14:40:00 (UTC)
* 終了   : 2026-07-23 14:45:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→16→20→23→16→20
* 開始   : 2026-07-23 15:20:00 (UTC)
* 終了   : 2026-07-23 15:25:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260723-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→16→20→16→20→16→18→17
* 開始   : 2026-07-23 15:55:00 (UTC)
* 終了   : 2026-07-23 16:05:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→13→15→12→13→12
* 開始   : 2026-07-23 18:25:00 (UTC)
* 終了   : 2026-07-23 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host14-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→11→10→12→9→10→12→9→11
* 開始   : 2026-07-23 19:55:00 (UTC)
* 終了   : 2026-07-23 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260723-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host14-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host14-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→10→5→10→…→10→12→9→10
* 開始   : 2026-07-23 22:35:00 (UTC)
* 終了   : 2026-07-23 22:45:00 (UTC)
* 現象   : 平常時(9)に対し 0.5556(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-082 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260723-host14-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→11→8
* 開始   : 2026-07-24 00:05:00 (UTC)
* 終了   : 2026-07-24 00:35:00 (UTC)
* 現象   : 2026-07-24 00:35:00 (UTC)を境に水準が 14.83から14.78へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→12→11→11→11→13→12
* 開始   : 2026-07-24 03:10:00 (UTC)
* 終了   : 2026-07-24 04:20:00 (UTC)
* 現象   : 2026-07-24 04:20:00 (UTC)を境に水準が 14.9から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→16→15→16→12→15
* 開始   : 2026-07-24 05:10:00 (UTC)
* 終了   : 2026-07-24 05:20:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→12→16→12→16→13→14
* 開始   : 2026-07-24 05:20:00 (UTC)
* 終了   : 2026-07-24 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→21→…→20→21→19→18
* 開始   : 2026-07-24 08:00:00 (UTC)
* 終了   : 2026-07-24 08:05:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260724-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→17→23→19→21→17→23→19
* 開始   : 2026-07-24 14:45:00 (UTC)
* 終了   : 2026-07-24 14:50:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→16→17→14→16
* 開始   : 2026-07-24 17:15:00 (UTC)
* 終了   : 2026-07-24 17:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→14→13
* 開始   : 2026-07-24 18:05:00 (UTC)
* 終了   : 2026-07-24 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→11→10→12→9→10→12→9→12
* 開始   : 2026-07-24 19:45:00 (UTC)
* 終了   : 2026-07-24 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260724-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host14-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→9→10→8→9→10→8→9→12
* 開始   : 2026-07-25 19:45:00 (UTC)
* 終了   : 2026-07-25 19:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.952, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260725-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→11→14
* 開始   : 2026-07-26 05:00:00 (UTC)
* 終了   : 2026-07-26 05:20:00 (UTC)
* 現象   : 2026-07-26 05:20:00 (UTC)を境に水準が 11.88から12.29へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→10→9→10→9→10→11
* 開始   : 2026-07-26 18:30:00 (UTC)
* 終了   : 2026-07-26 18:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→10→13
* 開始   : 2026-07-26 19:00:00 (UTC)
* 終了   : 2026-07-26 19:20:00 (UTC)
* 現象   : 2026-07-26 19:20:00 (UTC)を境に水準が 11.78から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 6→10→5→8→5→8→5→10→8
* 開始   : 2026-07-26 23:40:00 (UTC)
* 終了   : 2026-07-27 00:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260727-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260727-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260727-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260726-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260727-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260727-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260726-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→10→10→11→11→8→10
* 開始   : 2026-07-27 20:20:00 (UTC)
* 終了   : 2026-07-27 21:50:00 (UTC)
* 現象   : 2026-07-27 21:50:00 (UTC)を境に水準が 14.85から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→11→9→12→8→11→12→10
* 開始   : 2026-07-27 20:50:00 (UTC)
* 終了   : 2026-07-27 21:25:00 (UTC)
* 現象   : 2026-07-27 21:25:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→18→…→17→18→16→17
* 開始   : 2026-07-28 06:25:00 (UTC)
* 終了   : 2026-07-28 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→19→20→19→15→19→20→19→17
* 開始   : 2026-07-28 07:15:00 (UTC)
* 終了   : 2026-07-28 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→20→22→17→22→17→22→20
* 開始   : 2026-07-28 08:30:00 (UTC)
* 終了   : 2026-07-28 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260728-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→11→9→12→13
* 開始   : 2026-07-28 20:05:00 (UTC)
* 終了   : 2026-07-28 20:10:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→8→8→9→8→8→12
* 開始   : 2026-07-28 22:10:00 (UTC)
* 終了   : 2026-07-28 23:45:00 (UTC)
* 現象   : 2026-07-28 23:45:00 (UTC)を境に水準が 14.74から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→9→13→9→13→12
* 開始   : 2026-07-29 03:55:00 (UTC)
* 終了   : 2026-07-29 04:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→11→15→13→15→13→15→12
* 開始   : 2026-07-29 04:40:00 (UTC)
* 終了   : 2026-07-29 04:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→17→…→16→17→13→16
* 開始   : 2026-07-29 05:35:00 (UTC)
* 終了   : 2026-07-29 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→18→18→18→16→19→17→19→19
* 開始   : 2026-07-29 05:40:00 (UTC)
* 終了   : 2026-07-29 07:35:00 (UTC)
* 現象   : 2026-07-29 07:35:00 (UTC)を境に水準が 14.89から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→17→14→17→14→17→16
* 開始   : 2026-07-29 05:55:00 (UTC)
* 終了   : 2026-07-29 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→21→22→23→21→22→23→21→22
* 開始   : 2026-07-29 09:10:00 (UTC)
* 終了   : 2026-07-29 09:15:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 23→24→25→19→24→25→19→24→21
* 開始   : 2026-07-29 12:05:00 (UTC)
* 終了   : 2026-07-29 12:10:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→6→8→11→6→8
* 開始   : 2026-07-29 23:45:00 (UTC)
* 終了   : 2026-07-29 23:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→12→9→12→9→12→10→11
* 開始   : 2026-07-30 02:35:00 (UTC)
* 終了   : 2026-07-30 02:45:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.545σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→15→13→14
* 開始   : 2026-07-30 04:45:00 (UTC)
* 終了   : 2026-07-30 05:10:00 (UTC)
* 現象   : 2026-07-30 05:10:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→12→15→16→12→15
* 開始   : 2026-07-30 05:05:00 (UTC)
* 終了   : 2026-07-30 05:10:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→18→16→18→16→14
* 開始   : 2026-07-30 06:40:00 (UTC)
* 終了   : 2026-07-30 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→17→20→18→…→18→21→19→17
* 開始   : 2026-07-30 07:35:00 (UTC)
* 終了   : 2026-07-30 07:45:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→24→24→22→22→24→23→22→23
* 開始   : 2026-07-30 12:25:00 (UTC)
* 終了   : 2026-07-30 13:05:00 (UTC)
* 現象   : 2026-07-30 13:05:00 (UTC)を境に水準が 15.02から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.593, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→21→18→20→21→18→20→19
* 開始   : 2026-07-30 14:30:00 (UTC)
* 終了   : 2026-07-30 14:35:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→11→12→11→12→10→11
* 開始   : 2026-07-31 03:00:00 (UTC)
* 終了   : 2026-07-31 03:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→13→14→13→14→13
* 開始   : 2026-07-31 04:20:00 (UTC)
* 終了   : 2026-07-31 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→15→14→17→15
* 開始   : 2026-07-31 05:45:00 (UTC)
* 終了   : 2026-07-31 05:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260731-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→20→22→20→22→22→22→22→23
* 開始   : 2026-07-31 09:05:00 (UTC)
* 終了   : 2026-07-31 09:50:00 (UTC)
* 現象   : 2026-07-31 09:50:00 (UTC)を境に水準が 14.89から14.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→16→19→18→16→19→17
* 開始   : 2026-07-31 16:05:00 (UTC)
* 終了   : 2026-07-31 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→21→17→19→20
* 開始   : 2026-07-31 16:10:00 (UTC)
* 終了   : 2026-07-31 16:30:00 (UTC)
* 現象   : 2026-07-31 16:30:00 (UTC)を境に水準が 14.89から12.41へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host14-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→11→10→8→11→11→11
* 開始   : 2026-07-31 20:35:00 (UTC)
* 終了   : 2026-07-31 21:20:00 (UTC)
* 現象   : 2026-07-31 21:20:00 (UTC)を境に水準が 14.96から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host14-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
