# 異常検知サマリ 2026-07

## 1. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| ホスト数 | 17 |
| 系列数 | 156 |
| 検知イベント数 | 7368 (SEVERE: 427, FATAL: 2902, WARN: 4039, INFO: 0) |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 2. ホスト別の集計

| ホスト | SEVERE | FATAL | WARN | 計 | 主なメトリクス | レポート |
| --- | --- | --- | --- | --- | --- | --- |
| lsfhost01 | 54 | 859 | 1323 | 2236 | pend, run, njobs | report_lsfhost01_202607.md |
| host08 | 38 | 123 | 162 | 323 | active_connections | report_host08_202607.md |
| host12 | 35 | 124 | 158 | 317 | active_connections | report_host12_202607.md |
| host11 | 28 | 128 | 177 | 333 | active_connections | report_host11_202607.md |
| host03 | 26 | 139 | 168 | 333 | active_connections | report_host03_202607.md |
| host02 | 25 | 136 | 222 | 383 | active_connections, ou, mu | report_host02_202607.md |
| host07 | 22 | 134 | 192 | 348 | active_connections | report_host07_202607.md |
| host06 | 22 | 130 | 155 | 307 | active_connections | report_host06_202607.md |
| host16 | 22 | 115 | 176 | 313 | active_connections | report_host16_202607.md |
| host13 | 21 | 140 | 164 | 325 | active_connections | report_host13_202607.md |

(ほか 7 ホスト。脅威度の高い順に上位 10 件のみ表示。全ホストのファイルは report_*_202607.md にある)

## 3. 日別のイベント数

| 日 | SEVERE | FATAL | WARN | 計 |
| --- | --- | --- | --- | --- |
| 07-01 | 3 | 93 | 181 | 277 |
| 07-02 | 3 | 115 | 186 | 304 |
| 07-03 | 4 | 98 | 179 | 281 |
| 07-08 | 6 | 96 | 185 | 287 |
| 07-16 | 2 | 110 | 165 | 277 |
| 07-17 | 4 | 104 | 170 | 278 |
| 07-22 | 3 | 122 | 173 | 298 |
| 07-23 | 4 | 97 | 170 | 271 |
| 07-30 | 1 | 111 | 164 | 276 |
| 07-31 | 4 | 108 | 173 | 285 |

(全 31 日中、イベント数の多い上位 10 日のみ表示)

## 4. 複数ホストで同時に発生したアノマリー

| 時間帯 | ホスト数 | イベント数 | 関与したホスト | 主なメトリクス |
| --- | --- | --- | --- | --- |
| 2026-07-25 05:30 | 12 | 13 | host01, host02, host03 ほか 9 件 | active_connections, eu, njobs ほか 1 件 |
| 2026-07-04 05:40 | 12 | 10 | host01, host02, host03 ほか 9 件 | active_connections, njobs |
| 2026-07-04 05:35 | 11 | 10 | host01, host02, host03 ほか 8 件 | active_connections |
| 2026-07-18 05:45 | 10 | 9 | host01, host02, host03 ほか 7 件 | active_connections, eu |
| 2026-07-25 05:50 | 10 | 9 | host01, host02, host03 ほか 7 件 | active_connections, eu |
| 2026-07-18 05:40 | 11 | 8 | host01, host02, host03 ほか 8 件 | active_connections, eu |
| 2026-07-18 05:50 | 11 | 8 | host01, host02, host03 ほか 8 件 | active_connections, eu |
| 2026-07-11 05:45 | 9 | 8 | host01, host02, host04 ほか 6 件 | active_connections, eu, njobs |

(ほか 2748 件。件数の多い順に上位 8 件のみ表示)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
