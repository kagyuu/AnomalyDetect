# host11 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host11 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 299 (SEVERE: 28, FATAL: 114, WARN: 157, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 28 | 114 | 157 | 299 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→17→…→14→13→14→13
* 開始   : 2026-08-03 01:00:00 (UTC)
* 終了   : 2026-08-03 22:10:00 (UTC)
* 現象   : 2026-08-03 22:10:00 (UTC)を境に水準が 11.81から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.541, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-001 active_connections の推移](charts/EVT-20260803-host11-001.svg)

# イベントID( EVT-20260803-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→18→14→15→…→14→15→14→13
* 開始   : 2026-08-03 01:10:00 (UTC)
* 終了   : 2026-08-03 19:45:00 (UTC)
* 現象   : 2026-08-03 19:45:00 (UTC)を境に水準が 11.72から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.94, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-002 active_connections の推移](charts/EVT-20260803-host11-002.svg)

# イベントID( EVT-20260803-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→16→…→14→15→14→13
* 開始   : 2026-08-03 02:50:00 (UTC)
* 終了   : 2026-08-03 21:05:00 (UTC)
* 現象   : 2026-08-03 21:05:00 (UTC)を境に水準が 11.91から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.029, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-003 active_connections の推移](charts/EVT-20260803-host11-003.svg)

# イベントID( EVT-20260803-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→15→…→15→14→15→14
* 開始   : 2026-08-03 03:05:00 (UTC)
* 終了   : 2026-08-03 22:00:00 (UTC)
* 現象   : 2026-08-03 22:00:00 (UTC)を境に水準が 11.78から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.095, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.374, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-004 active_connections の推移](charts/EVT-20260803-host11-004.svg)

# イベントID( EVT-20260803-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→13→…→15→12→14→13
* 開始   : 2026-08-03 03:30:00 (UTC)
* 終了   : 2026-08-03 21:00:00 (UTC)
* 現象   : 2026-08-03 21:00:00 (UTC)を境に水準が 11.83から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.902, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-005 active_connections の推移](charts/EVT-20260803-host11-005.svg)

# イベントID( EVT-20260803-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→13→…→13→15→13→12
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 20:30:00 (UTC)
* 現象   : 2026-08-03 20:30:00 (UTC)を境に水準が 11.75から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.725, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host11-006 active_connections の推移](charts/EVT-20260803-host11-006.svg)

# イベントID( EVT-20260805-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→16→19→17→17→19→19→19→19
* 開始   : 2026-08-05 06:40:00 (UTC)
* 終了   : 2026-08-05 07:50:00 (UTC)
* 現象   : 2026-08-05 07:50:00 (UTC)を境に水準が 15.03から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.062, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host11-003 active_connections の推移](charts/EVT-20260805-host11-003.svg)

# イベントID( EVT-20260809-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→17→17→16→15→16→15→16→17
* 開始   : 2026-08-09 12:40:00 (UTC)
* 終了   : 2026-08-09 15:00:00 (UTC)
* 現象   : 2026-08-09 15:00:00 (UTC)を境に水準が 11.79から14.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host11-005 active_connections の推移](charts/EVT-20260809-host11-005.svg)

# イベントID( EVT-20260810-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→15→17→16→…→16→14→13→14
* 開始   : 2026-08-10 01:40:00 (UTC)
* 終了   : 2026-08-10 21:35:00 (UTC)
* 現象   : 2026-08-10 21:35:00 (UTC)を境に水準が 11.89から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.913, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.619, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-001 active_connections の推移](charts/EVT-20260810-host11-001.svg)

# イベントID( EVT-20260810-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→…→13→14→11→13
* 開始   : 2026-08-10 02:25:00 (UTC)
* 終了   : 2026-08-10 20:35:00 (UTC)
* 現象   : 2026-08-10 20:35:00 (UTC)を境に水準が 11.83から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.981, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.252, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-002 active_connections の推移](charts/EVT-20260810-host11-002.svg)

# イベントID( EVT-20260810-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→16→…→13→16→17→12
* 開始   : 2026-08-10 02:35:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.026, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-003 active_connections の推移](charts/EVT-20260810-host11-003.svg)

# イベントID( EVT-20260810-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→15→…→11→12→11→12
* 開始   : 2026-08-10 03:15:00 (UTC)
* 終了   : 2026-08-10 20:20:00 (UTC)
* 現象   : 2026-08-10 20:20:00 (UTC)を境に水準が 11.9から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.174, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-004 active_connections の推移](charts/EVT-20260810-host11-004.svg)

# イベントID( EVT-20260810-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→15→…→13→14→10→11
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 22:20:00 (UTC)
* 現象   : 2026-08-10 22:20:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.238, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-005 active_connections の推移](charts/EVT-20260810-host11-005.svg)

# イベントID( EVT-20260810-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→15→14→15→…→13→12→13→12
* 開始   : 2026-08-10 03:50:00 (UTC)
* 終了   : 2026-08-10 19:45:00 (UTC)
* 現象   : 2026-08-10 19:45:00 (UTC)を境に水準が 11.99から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.845, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host11-006 active_connections の推移](charts/EVT-20260810-host11-006.svg)

# イベントID( EVT-20260814-host11-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→10→10→10→10
* 開始   : 2026-08-14 23:50:00 (UTC)
* 終了   : 2026-08-15 00:10:00 (UTC)
* 現象   : 2026-08-15 00:10:00 (UTC)を境に水準が 14.99から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host11-016 active_connections の推移](charts/EVT-20260814-host11-016.svg)

# イベントID( EVT-20260816-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→11→13
* 開始   : 2026-08-16 03:00:00 (UTC)
* 終了   : 2026-08-16 03:10:00 (UTC)
* 現象   : 2026-08-16 03:10:00 (UTC)を境に水準が 11.95から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.412, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host11-001 active_connections の推移](charts/EVT-20260816-host11-001.svg)

# イベントID( EVT-20260817-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→15→14→15→…→13→14→10→12
* 開始   : 2026-08-17 02:00:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.75から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.121, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-001 active_connections の推移](charts/EVT-20260817-host11-001.svg)

# イベントID( EVT-20260817-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→17→14→18→…→12→17→14→12
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 21:40:00 (UTC)
* 現象   : 2026-08-17 21:40:00 (UTC)を境に水準が 11.86から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.237, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-002 active_connections の推移](charts/EVT-20260817-host11-002.svg)

# イベントID( EVT-20260817-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→13→15→14→…→15→14→15→14
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 20:20:00 (UTC)
* 現象   : 2026-08-17 20:20:00 (UTC)を境に水準が 12.02から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.785, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-003 active_connections の推移](charts/EVT-20260817-host11-003.svg)

# イベントID( EVT-20260817-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→16→15→14→…→16→11→12→14
* 開始   : 2026-08-17 03:35:00 (UTC)
* 終了   : 2026-08-17 22:35:00 (UTC)
* 現象   : 2026-08-17 22:35:00 (UTC)を境に水準が 11.91から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.678, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-004 active_connections の推移](charts/EVT-20260817-host11-004.svg)

# イベントID( EVT-20260817-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→18→…→17→13→15→14
* 開始   : 2026-08-17 03:50:00 (UTC)
* 終了   : 2026-08-17 21:40:00 (UTC)
* 現象   : 2026-08-17 21:40:00 (UTC)を境に水準が 11.99から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-005 active_connections の推移](charts/EVT-20260817-host11-005.svg)

# イベントID( EVT-20260817-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→15→…→13→16→15→13
* 開始   : 2026-08-17 03:55:00 (UTC)
* 終了   : 2026-08-17 20:05:00 (UTC)
* 現象   : 2026-08-17 20:05:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.716, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-006 active_connections の推移](charts/EVT-20260817-host11-006.svg)

# イベントID( EVT-20260821-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→17→16→17→20→19→18
* 開始   : 2026-08-21 06:35:00 (UTC)
* 終了   : 2026-08-21 07:05:00 (UTC)
* 現象   : 2026-08-21 07:05:00 (UTC)を境に水準が 14.82から14.57へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-005 active_connections の推移](charts/EVT-20260821-host11-005.svg)

# イベントID( EVT-20260823-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→20→19→…→14→16→12→14
* 開始   : 2026-08-23 23:50:00 (UTC)
* 終了   : 2026-08-24 21:05:00 (UTC)
* 現象   : 2026-08-24 21:05:00 (UTC)を境に水準が 11.91から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.678, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host11-010 active_connections の推移](charts/EVT-20260823-host11-010.svg)

# イベントID( EVT-20260824-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→16→13→15→…→16→14→11→15
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 21:10:00 (UTC)
* 現象   : 2026-08-24 21:10:00 (UTC)を境に水準が 11.75から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.484, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host11-001 active_connections の推移](charts/EVT-20260824-host11-001.svg)

# イベントID( EVT-20260824-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→13→12→14→10
* 開始   : 2026-08-24 02:45:00 (UTC)
* 終了   : 2026-08-24 21:45:00 (UTC)
* 現象   : 2026-08-24 21:45:00 (UTC)を境に水準が 11.81から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.713, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host11-002 active_connections の推移](charts/EVT-20260824-host11-002.svg)

# イベントID( EVT-20260824-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→14→16→12→14
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 18:45:00 (UTC)
* 現象   : 2026-08-24 18:45:00 (UTC)を境に水準が 11.89から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.812, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.802, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host11-003 active_connections の推移](charts/EVT-20260824-host11-003.svg)

# イベントID( EVT-20260824-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→16→…→15→13→12→13
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 20:10:00 (UTC)
* 現象   : 2026-08-24 20:10:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.763, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host11-004 active_connections の推移](charts/EVT-20260824-host11-004.svg)

# イベントID( EVT-20260801-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→10→14→12→8
* 開始   : 2026-08-01 04:20:00 (UTC)
* 終了   : 2026-08-01 04:20:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260801-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→13→…→12→11→10→12
* 開始   : 2026-08-01 04:40:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.918σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.949, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host11-002 active_connections の推移](charts/EVT-20260801-host11-002.svg)

# イベントID( EVT-20260801-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→9→10→13→…→12→13→12→10
* 開始   : 2026-08-01 05:05:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host11-003 active_connections の推移](charts/EVT-20260801-host11-003.svg)

# イベントID( EVT-20260801-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→12→10→12→…→9→10→13→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.972, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260801-host11-004 active_connections の推移](charts/EVT-20260801-host11-004.svg)

# イベントID( EVT-20260801-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→10→…→13→12→13→14
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 18:10:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.247, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260801-host11-005 active_connections の推移](charts/EVT-20260801-host11-005.svg)

# イベントID( EVT-20260801-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→13→…→12→11→12→11
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:15:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.135, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260801-host11-006 active_connections の推移](charts/EVT-20260801-host11-006.svg)

# イベントID( EVT-20260801-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→12→…→11→12→10→11
* 開始   : 2026-08-01 05:55:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.167, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260801-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→17→15→14
* 開始   : 2026-08-02 07:30:00 (UTC)
* 終了   : 2026-08-02 07:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260802-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→13→9→11→…→5→11→8→9
* 開始   : 2026-08-02 19:00:00 (UTC)
* 終了   : 2026-08-02 19:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260802-host11-008 active_connections の推移](charts/EVT-20260802-host11-008.svg)

# イベントID( EVT-20260803-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→8→9
* 開始   : 2026-08-03 22:10:00 (UTC)
* 終了   : 2026-08-03 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→10→13→7→9
* 開始   : 2026-08-04 01:35:00 (UTC)
* 終了   : 2026-08-04 01:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→8→9→9→11→8→14→12→12
* 開始   : 2026-08-04 01:45:00 (UTC)
* 終了   : 2026-08-04 03:10:00 (UTC)
* 現象   : 2026-08-04 03:10:00 (UTC)を境に水準が 15.05から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.515, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→19→22→16→21→22→16→21→19
* 開始   : 2026-08-04 08:05:00 (UTC)
* 終了   : 2026-08-04 08:15:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host11-003 active_connections の推移](charts/EVT-20260804-host11-003.svg)

# イベントID( EVT-20260804-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→20→23→21→20
* 開始   : 2026-08-04 08:50:00 (UTC)
* 終了   : 2026-08-04 09:10:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→17→13→15→17
* 開始   : 2026-08-04 17:10:00 (UTC)
* 終了   : 2026-08-04 17:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260804-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→9→…→12→8→10→11
* 開始   : 2026-08-04 20:15:00 (UTC)
* 終了   : 2026-08-04 21:20:00 (UTC)
* 現象   : 1.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260804-host11-011 active_connections の推移](charts/EVT-20260804-host11-011.svg)

# イベントID( EVT-20260804-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→12→7→9→9
* 開始   : 2026-08-04 20:55:00 (UTC)
* 終了   : 2026-08-04 20:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 7→10→4→10→8
* 開始   : 2026-08-05 01:00:00 (UTC)
* 終了   : 2026-08-05 01:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→18→…→17→18→16→15
* 開始   : 2026-08-05 05:50:00 (UTC)
* 終了   : 2026-08-05 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→16→20→18→17
* 開始   : 2026-08-05 07:10:00 (UTC)
* 終了   : 2026-08-05 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→18→24→18→20
* 開始   : 2026-08-05 09:25:00 (UTC)
* 終了   : 2026-08-05 09:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 23→21→26→20→22
* 開始   : 2026-08-05 10:30:00 (UTC)
* 終了   : 2026-08-05 10:30:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→24→25→21→…→21→17→21→22
* 開始   : 2026-08-05 12:15:00 (UTC)
* 終了   : 2026-08-05 12:25:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→14→12→16→18
* 開始   : 2026-08-05 18:00:00 (UTC)
* 終了   : 2026-08-05 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→11→13→10→10
* 開始   : 2026-08-06 02:45:00 (UTC)
* 終了   : 2026-08-06 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→18→16→15→19→18→16
* 開始   : 2026-08-06 06:30:00 (UTC)
* 終了   : 2026-08-06 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→21→16→19→17
* 開始   : 2026-08-06 15:15:00 (UTC)
* 終了   : 2026-08-06 15:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→15→…→15→19→16→17
* 開始   : 2026-08-07 06:15:00 (UTC)
* 終了   : 2026-08-07 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→13→12→12→11→13→10→13→12
* 開始   : 2026-08-07 20:05:00 (UTC)
* 終了   : 2026-08-07 21:20:00 (UTC)
* 現象   : 2026-08-07 21:20:00 (UTC)を境に水準が 14.87から11.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→11→11
* 開始   : 2026-08-07 20:10:00 (UTC)
* 終了   : 2026-08-07 20:10:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→14→13→12→…→13→11→14→12
* 開始   : 2026-08-08 04:50:00 (UTC)
* 終了   : 2026-08-08 18:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.853, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host11-003 active_connections の推移](charts/EVT-20260808-host11-003.svg)

# イベントID( EVT-20260808-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→13→…→14→12→14→12
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 18:10:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260808-host11-004 active_connections の推移](charts/EVT-20260808-host11-004.svg)

# イベントID( EVT-20260808-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→11→…→8→12→13→12
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.89, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260808-host11-005 active_connections の推移](charts/EVT-20260808-host11-005.svg)

# イベントID( EVT-20260808-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→10→11→12→…→12→10→12→13
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 18:40:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.994, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260808-host11-006 active_connections の推移](charts/EVT-20260808-host11-006.svg)

# イベントID( EVT-20260808-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→11→13→11→…→13→11→12→11
* 開始   : 2026-08-08 05:45:00 (UTC)
* 終了   : 2026-08-08 19:50:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.718, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.1 時間

![EVT-20260808-host11-007 active_connections の推移](charts/EVT-20260808-host11-007.svg)

# イベントID( EVT-20260808-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→14→…→13→11→13→10
* 開始   : 2026-08-08 06:20:00 (UTC)
* 終了   : 2026-08-08 18:30:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.85, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260808-host11-008 active_connections の推移](charts/EVT-20260808-host11-008.svg)

# イベントID( EVT-20260809-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→10→15→10→…→10→8→11→9
* 開始   : 2026-08-09 05:25:00 (UTC)
* 終了   : 2026-08-09 06:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260809-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260809-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260809-host11-003 active_connections の推移](charts/EVT-20260809-host11-003.svg)

# イベントID( EVT-20260809-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→12→12
* 開始   : 2026-08-09 16:55:00 (UTC)
* 終了   : 2026-08-09 16:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 8→8→4→8→8
* 開始   : 2026-08-09 23:30:00 (UTC)
* 終了   : 2026-08-09 23:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 7→8→14→9→9
* 開始   : 2026-08-11 02:45:00 (UTC)
* 終了   : 2026-08-11 02:45:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.696σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host11-001 active_connections の推移](charts/EVT-20260811-host11-001.svg)

# イベントID( EVT-20260811-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→17→17
* 開始   : 2026-08-11 17:20:00 (UTC)
* 終了   : 2026-08-11 18:05:00 (UTC)
* 現象   : 2026-08-11 18:05:00 (UTC)を境に水準が 14.95から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→19→15→19→17
* 開始   : 2026-08-12 16:10:00 (UTC)
* 終了   : 2026-08-12 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260812-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→18→13→18→18
* 開始   : 2026-08-12 16:50:00 (UTC)
* 終了   : 2026-08-12 16:50:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→15→12→17→15
* 開始   : 2026-08-12 17:50:00 (UTC)
* 終了   : 2026-08-12 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→10→5→10→8
* 開始   : 2026-08-12 22:25:00 (UTC)
* 終了   : 2026-08-12 22:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260812-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→6→4→9→6→4→9→8
* 開始   : 2026-08-12 22:55:00 (UTC)
* 終了   : 2026-08-12 23:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→16→…→14→16→13→14
* 開始   : 2026-08-13 04:35:00 (UTC)
* 終了   : 2026-08-13 04:40:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→17→18
* 開始   : 2026-08-13 06:55:00 (UTC)
* 終了   : 2026-08-13 06:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→19→15→17→19
* 開始   : 2026-08-13 15:35:00 (UTC)
* 終了   : 2026-08-13 15:35:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→19→14→18→19
* 開始   : 2026-08-13 16:30:00 (UTC)
* 終了   : 2026-08-13 16:30:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→13→15
* 開始   : 2026-08-13 18:35:00 (UTC)
* 終了   : 2026-08-13 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→8→…→10→8→11→12
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 19:30:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→16→21→19→16
* 開始   : 2026-08-14 07:25:00 (UTC)
* 終了   : 2026-08-14 07:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→18→22→17→19
* 開始   : 2026-08-14 08:00:00 (UTC)
* 終了   : 2026-08-14 08:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→21→16→21→21
* 開始   : 2026-08-14 10:00:00 (UTC)
* 終了   : 2026-08-14 10:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→16→18→14→16→18→14→18→16
* 開始   : 2026-08-14 16:35:00 (UTC)
* 終了   : 2026-08-14 16:45:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260814-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260814-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→14→10→11→…→11→9→10→11
* 開始   : 2026-08-14 19:00:00 (UTC)
* 終了   : 2026-08-14 19:55:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 55 分
  - EVT-20260814-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→7→13→7→9
* 開始   : 2026-08-15 03:05:00 (UTC)
* 終了   : 2026-08-15 03:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260815-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→12→…→13→12→14→11
* 開始   : 2026-08-15 05:00:00 (UTC)
* 終了   : 2026-08-15 19:35:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host11-002 active_connections の推移](charts/EVT-20260815-host11-002.svg)

# イベントID( EVT-20260815-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→12→11→12→…→11→13→10→11
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 19:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host11-003 active_connections の推移](charts/EVT-20260815-host11-003.svg)

# イベントID( EVT-20260815-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→13→…→7→10→13→9
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260815-host11-004 active_connections の推移](charts/EVT-20260815-host11-004.svg)

# イベントID( EVT-20260815-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→10→…→12→13→14→13
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 18:10:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.745, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260815-host11-005 active_connections の推移](charts/EVT-20260815-host11-005.svg)

# イベントID( EVT-20260815-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→10→…→12→11→14→13
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 19:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.882, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260815-host11-006 active_connections の推移](charts/EVT-20260815-host11-006.svg)

# イベントID( EVT-20260815-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→14→13→15→13
* 開始   : 2026-08-15 06:00:00 (UTC)
* 終了   : 2026-08-15 17:40:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260815-host11-007 active_connections の推移](charts/EVT-20260815-host11-007.svg)

# イベントID( EVT-20260816-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→8→12→13
* 開始   : 2026-08-16 18:05:00 (UTC)
* 終了   : 2026-08-16 18:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→10→16→12→…→12→15→11→12
* 開始   : 2026-08-19 04:45:00 (UTC)
* 終了   : 2026-08-19 04:55:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→20→16→17→20→16→18
* 開始   : 2026-08-19 07:35:00 (UTC)
* 終了   : 2026-08-19 08:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.257倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260819-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→21→17→19→20
* 開始   : 2026-08-19 14:05:00 (UTC)
* 終了   : 2026-08-19 14:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 24→20→17→21→23
* 開始   : 2026-08-19 14:05:00 (UTC)
* 終了   : 2026-08-19 14:05:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→8→6→10→9
* 開始   : 2026-08-19 21:30:00 (UTC)
* 終了   : 2026-08-19 21:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→17→17
* 開始   : 2026-08-20 06:20:00 (UTC)
* 終了   : 2026-08-20 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→21→13→16→16
* 開始   : 2026-08-20 16:45:00 (UTC)
* 終了   : 2026-08-20 16:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.6964(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.964σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host11-006 active_connections の推移](charts/EVT-20260820-host11-006.svg)

# イベントID( EVT-20260820-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→17→12→15→12→15→12→13→14
* 開始   : 2026-08-20 17:20:00 (UTC)
* 終了   : 2026-08-20 18:00:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→17→12→14→14
* 開始   : 2026-08-20 17:50:00 (UTC)
* 終了   : 2026-08-20 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→13→15
* 開始   : 2026-08-21 05:05:00 (UTC)
* 終了   : 2026-08-21 05:05:00 (UTC)
* 現象   : 平常時(12)に対し 1.417倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→22→21
* 開始   : 2026-08-21 12:20:00 (UTC)
* 終了   : 2026-08-21 12:20:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→20→26→20→20
* 開始   : 2026-08-21 13:50:00 (UTC)
* 終了   : 2026-08-21 13:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→11→14→15
* 開始   : 2026-08-21 18:25:00 (UTC)
* 終了   : 2026-08-21 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→14→9→14→12
* 開始   : 2026-08-21 19:30:00 (UTC)
* 終了   : 2026-08-21 19:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→8→14→10→8
* 開始   : 2026-08-22 02:55:00 (UTC)
* 終了   : 2026-08-22 02:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.68倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.978σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260822-host11-003 active_connections の推移](charts/EVT-20260822-host11-003.svg)

# イベントID( EVT-20260822-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→14→11→14→…→9→10→11→12
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.87, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host11-004 active_connections の推移](charts/EVT-20260822-host11-004.svg)

# イベントID( EVT-20260822-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→13→…→12→13→14→11
* 開始   : 2026-08-22 05:15:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260822-host11-005 active_connections の推移](charts/EVT-20260822-host11-005.svg)

# イベントID( EVT-20260822-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→9→14→10→…→12→10→15→10
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.822, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host11-006 active_connections の推移](charts/EVT-20260822-host11-006.svg)

# イベントID( EVT-20260822-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→12→…→14→10→12→10
* 開始   : 2026-08-22 05:45:00 (UTC)
* 終了   : 2026-08-22 20:10:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.632σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host11-007 active_connections の推移](charts/EVT-20260822-host11-007.svg)

# イベントID( EVT-20260822-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→13→…→13→10→12→10
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.883, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host11-008 active_connections の推移](charts/EVT-20260822-host11-008.svg)

# イベントID( EVT-20260822-host11-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→12→13→11→…→12→11→10→12
* 開始   : 2026-08-22 06:05:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.966, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260822-host11-009 active_connections の推移](charts/EVT-20260822-host11-009.svg)

# イベントID( EVT-20260823-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→9→15→11→12
* 開始   : 2026-08-23 05:55:00 (UTC)
* 終了   : 2026-08-23 05:55:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→14→…→14→19→16→17
* 開始   : 2026-08-23 10:30:00 (UTC)
* 終了   : 2026-08-23 10:40:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12
* 開始   : 2026-08-23 19:15:00 (UTC)
* 終了   : 2026-08-23 19:45:00 (UTC)
* 現象   : 2026-08-23 19:45:00 (UTC)を境に水準が 11.85から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→17→…→14→15→13→14
* 開始   : 2026-08-24 03:05:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.99から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→11→10
* 開始   : 2026-08-25 03:15:00 (UTC)
* 終了   : 2026-08-25 03:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260825-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→13→17→14→12
* 開始   : 2026-08-25 05:30:00 (UTC)
* 終了   : 2026-08-25 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→20→24→19→21
* 開始   : 2026-08-25 08:55:00 (UTC)
* 終了   : 2026-08-25 08:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.297倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host11-006 active_connections の推移](charts/EVT-20260825-host11-006.svg)

# イベントID( EVT-20260825-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→11→15→15
* 開始   : 2026-08-25 18:05:00 (UTC)
* 終了   : 2026-08-25 18:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→13→9→12→14
* 開始   : 2026-08-25 19:00:00 (UTC)
* 終了   : 2026-08-25 19:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→10→…→10→5→9→10
* 開始   : 2026-08-25 20:55:00 (UTC)
* 終了   : 2026-08-25 21:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260825-host11-013 active_connections の推移](charts/EVT-20260825-host11-013.svg)

# イベントID( EVT-20260826-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→8→7
* 開始   : 2026-08-26 00:50:00 (UTC)
* 終了   : 2026-08-26 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→11→15→10→10
* 開始   : 2026-08-26 03:35:00 (UTC)
* 終了   : 2026-08-26 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.565倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host11-002 active_connections の推移](charts/EVT-20260826-host11-002.svg)

# イベントID( EVT-20260826-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→18→18
* 開始   : 2026-08-26 07:50:00 (UTC)
* 終了   : 2026-08-26 07:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→9→14→14
* 開始   : 2026-08-26 19:10:00 (UTC)
* 終了   : 2026-08-26 19:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→13→…→13→18→15→14
* 開始   : 2026-08-27 05:10:00 (UTC)
* 終了   : 2026-08-27 06:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260827-host11-004 active_connections の推移](charts/EVT-20260827-host11-004.svg)

# イベントID( EVT-20260827-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 19→18→14→16→17
* 開始   : 2026-08-27 16:25:00 (UTC)
* 終了   : 2026-08-27 16:25:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7434(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→8→4→6→11→4→6→11→9
* 開始   : 2026-08-28 01:05:00 (UTC)
* 終了   : 2026-08-28 01:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260828-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→7→12→7→7
* 開始   : 2026-08-28 01:05:00 (UTC)
* 終了   : 2026-08-28 01:05:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260828-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→22→21→24→22→21→24→21
* 開始   : 2026-08-28 09:10:00 (UTC)
* 終了   : 2026-08-28 09:20:00 (UTC)
* 現象   : 2026-08-28 09:20:00 (UTC)を境に水準が 15.06から14.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→20→26→22→22
* 開始   : 2026-08-28 11:45:00 (UTC)
* 終了   : 2026-08-28 11:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.233倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→12→8→13→12
* 開始   : 2026-08-28 20:10:00 (UTC)
* 終了   : 2026-08-28 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→12→12→11
* 開始   : 2026-08-28 20:40:00 (UTC)
* 終了   : 2026-08-28 21:35:00 (UTC)
* 現象   : 2026-08-28 21:35:00 (UTC)を境に水準が 15.04から11.7へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→13→…→12→11→12→11
* 開始   : 2026-08-29 04:55:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.076, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260829-host11-002 active_connections の推移](charts/EVT-20260829-host11-002.svg)

# イベントID( EVT-20260829-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→9→13→12→11
* 開始   : 2026-08-29 05:00:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260829-host11-003 active_connections の推移](charts/EVT-20260829-host11-003.svg)

# イベントID( EVT-20260829-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→10→…→14→12→11→13
* 開始   : 2026-08-29 05:00:00 (UTC)
* 終了   : 2026-08-29 19:55:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260829-host11-004 active_connections の推移](charts/EVT-20260829-host11-004.svg)

# イベントID( EVT-20260829-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→12→…→10→12→13→11
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.083, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260829-host11-005 active_connections の推移](charts/EVT-20260829-host11-005.svg)

# イベントID( EVT-20260829-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→12→…→11→12→13→11
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 18:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260829-host11-006 active_connections の推移](charts/EVT-20260829-host11-006.svg)

# イベントID( EVT-20260829-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→15→…→13→11→12→11
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.991, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260829-host11-007 active_connections の推移](charts/EVT-20260829-host11-007.svg)

# イベントID( EVT-20260802-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 7→8→11→5→…→11→5→9→7
* 開始   : 2026-08-02 01:15:00 (UTC)
* 終了   : 2026-08-02 01:20:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→14→11→14→11→12
* 開始   : 2026-08-02 05:30:00 (UTC)
* 終了   : 2026-08-02 05:35:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260802-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260802-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→15→14
* 開始   : 2026-08-02 07:40:00 (UTC)
* 終了   : 2026-08-02 07:50:00 (UTC)
* 現象   : 2026-08-02 07:50:00 (UTC)を境に水準が 11.79から12.37へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→16→15→14→15→16→15→17→16
* 開始   : 2026-08-02 09:00:00 (UTC)
* 終了   : 2026-08-02 09:40:00 (UTC)
* 現象   : 2026-08-02 09:40:00 (UTC)を境に水準が 11.67から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→18→14→18→15
* 開始   : 2026-08-02 10:05:00 (UTC)
* 終了   : 2026-08-02 10:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→11→8→9→11→8→10
* 開始   : 2026-08-02 18:50:00 (UTC)
* 終了   : 2026-08-02 19:00:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260802-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→8→9
* 開始   : 2026-08-02 23:15:00 (UTC)
* 終了   : 2026-08-02 23:35:00 (UTC)
* 現象   : 2026-08-02 23:35:00 (UTC)を境に水準が 11.75から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→21→22→21→22→18
* 開始   : 2026-08-04 08:45:00 (UTC)
* 終了   : 2026-08-04 08:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→21→19→21→19→21→19→21
* 開始   : 2026-08-04 13:10:00 (UTC)
* 終了   : 2026-08-04 13:20:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→21→21
* 開始   : 2026-08-04 14:45:00 (UTC)
* 終了   : 2026-08-04 14:55:00 (UTC)
* 現象   : 2026-08-04 14:55:00 (UTC)を境に水準が 14.97から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→14→19→…→17→14→17→14
* 開始   : 2026-08-04 17:05:00 (UTC)
* 終了   : 2026-08-04 17:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.874σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260804-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260804-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→13→14→10→13→12
* 開始   : 2026-08-04 19:20:00 (UTC)
* 終了   : 2026-08-04 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→15→19→15→19→17→19
* 開始   : 2026-08-05 06:45:00 (UTC)
* 終了   : 2026-08-05 06:55:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 23→23→23→21→24→24→22→25
* 開始   : 2026-08-05 11:20:00 (UTC)
* 終了   : 2026-08-05 11:55:00 (UTC)
* 現象   : 2026-08-05 11:55:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.602, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→22→22→23→22→20→22→22→24
* 開始   : 2026-08-05 13:05:00 (UTC)
* 終了   : 2026-08-05 13:50:00 (UTC)
* 現象   : 2026-08-05 13:50:00 (UTC)を境に水準が 14.97から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→20→20→20→19→19→20→20→20
* 開始   : 2026-08-05 15:10:00 (UTC)
* 終了   : 2026-08-05 16:00:00 (UTC)
* 現象   : 2026-08-05 16:00:00 (UTC)を境に水準が 15.01から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→7→…→7→5→7→6
* 開始   : 2026-08-05 23:05:00 (UTC)
* 終了   : 2026-08-05 23:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→11→5→7→11→5→7
* 開始   : 2026-08-06 00:20:00 (UTC)
* 終了   : 2026-08-06 00:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→13→16→13→16→14
* 開始   : 2026-08-06 05:10:00 (UTC)
* 終了   : 2026-08-06 05:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260806-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→20→23→20→…→20→24→20→21
* 開始   : 2026-08-06 09:45:00 (UTC)
* 終了   : 2026-08-06 09:55:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 24→23→23→21→22→22→24→23→23
* 開始   : 2026-08-06 11:00:00 (UTC)
* 終了   : 2026-08-06 11:40:00 (UTC)
* 現象   : 2026-08-06 11:40:00 (UTC)を境に水準が 14.88から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→11→9→13→9→13→9→12→10
* 開始   : 2026-08-06 19:55:00 (UTC)
* 終了   : 2026-08-06 20:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→11
* 開始   : 2026-08-06 21:35:00 (UTC)
* 終了   : 2026-08-06 21:50:00 (UTC)
* 現象   : 2026-08-06 21:50:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.801, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→9→11→11
* 開始   : 2026-08-07 02:45:00 (UTC)
* 終了   : 2026-08-07 03:10:00 (UTC)
* 現象   : 2026-08-07 03:10:00 (UTC)を境に水準が 14.9から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→13→11→13→11→13→11→13
* 開始   : 2026-08-07 03:40:00 (UTC)
* 終了   : 2026-08-07 03:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→16→19→16→19→18→19
* 開始   : 2026-08-07 07:00:00 (UTC)
* 終了   : 2026-08-07 07:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→19→22→19→22→19→18
* 開始   : 2026-08-07 08:20:00 (UTC)
* 終了   : 2026-08-07 08:25:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→22→…→21→22→19→21
* 開始   : 2026-08-07 08:20:00 (UTC)
* 終了   : 2026-08-07 08:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→19→22→16→…→20→15→20→16
* 開始   : 2026-08-07 15:15:00 (UTC)
* 終了   : 2026-08-07 16:30:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260807-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→22→22→20→18
* 開始   : 2026-08-07 15:20:00 (UTC)
* 終了   : 2026-08-07 15:40:00 (UTC)
* 現象   : 2026-08-07 15:40:00 (UTC)を境に水準が 15.04から12.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→16→15→21→…→15→21→17→15
* 開始   : 2026-08-07 16:55:00 (UTC)
* 終了   : 2026-08-07 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260807-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→15→13→19→…→13→12→16→15
* 開始   : 2026-08-07 17:50:00 (UTC)
* 終了   : 2026-08-07 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260807-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→17→13→10→17→13→10→12→11
* 開始   : 2026-08-07 19:15:00 (UTC)
* 終了   : 2026-08-07 19:25:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→11→13→10→11→9→11→10
* 開始   : 2026-08-07 20:40:00 (UTC)
* 終了   : 2026-08-07 21:55:00 (UTC)
* 現象   : 2026-08-07 21:55:00 (UTC)を境に水準が 14.96から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→10→6→10→6→7→8
* 開始   : 2026-08-07 23:00:00 (UTC)
* 終了   : 2026-08-07 23:10:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-086 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host02-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→8→10→10→9→9→10→11
* 開始   : 2026-08-08 00:25:00 (UTC)
* 終了   : 2026-08-08 01:00:00 (UTC)
* 現象   : 2026-08-08 01:00:00 (UTC)を境に水準が 15.02から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260808-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→7→…→7→13→7→10
* 開始   : 2026-08-08 02:20:00 (UTC)
* 終了   : 2026-08-08 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host11-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→9→8→11→9→8→11→10
* 開始   : 2026-08-08 19:15:00 (UTC)
* 終了   : 2026-08-08 19:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.255, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260808-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host11-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→8→10→9→8→10→11
* 開始   : 2026-08-08 20:10:00 (UTC)
* 終了   : 2026-08-08 20:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.842, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260808-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→12→8→8→7→8→7→10→9
* 開始   : 2026-08-09 00:35:00 (UTC)
* 終了   : 2026-08-09 01:20:00 (UTC)
* 現象   : 2026-08-09 01:20:00 (UTC)を境に水準が 11.91から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.619, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→9→8→10→…→10→14→10→13
* 開始   : 2026-08-09 05:15:00 (UTC)
* 終了   : 2026-08-09 05:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→14→16→14→16→14
* 開始   : 2026-08-09 08:00:00 (UTC)
* 終了   : 2026-08-09 08:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260809-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→14→12→11→12→15→14
* 開始   : 2026-08-11 03:45:00 (UTC)
* 終了   : 2026-08-11 04:40:00 (UTC)
* 現象   : 2026-08-11 04:40:00 (UTC)を境に水準が 14.88から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→16→14
* 開始   : 2026-08-11 05:25:00 (UTC)
* 終了   : 2026-08-11 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→20→17→16→…→16→15→17→18
* 開始   : 2026-08-11 15:55:00 (UTC)
* 終了   : 2026-08-11 16:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260811-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→10→…→10→15→10→12
* 開始   : 2026-08-11 19:55:00 (UTC)
* 終了   : 2026-08-11 20:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→8→11→8→11→8
* 開始   : 2026-08-12 01:50:00 (UTC)
* 終了   : 2026-08-12 01:55:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→9→13→9→13
* 開始   : 2026-08-12 03:55:00 (UTC)
* 終了   : 2026-08-12 04:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→15→11→15→11→15
* 開始   : 2026-08-12 05:05:00 (UTC)
* 終了   : 2026-08-12 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→20→21→17→18→20→21→17→19
* 開始   : 2026-08-12 07:45:00 (UTC)
* 終了   : 2026-08-12 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→21→18→25→22→21→18→25→22
* 開始   : 2026-08-12 12:25:00 (UTC)
* 終了   : 2026-08-12 12:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8151(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 23→24→22→23→23→23→21
* 開始   : 2026-08-12 12:50:00 (UTC)
* 終了   : 2026-08-12 13:20:00 (UTC)
* 現象   : 2026-08-12 13:20:00 (UTC)を境に水準が 14.92から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.402, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→16→20→19→16→20→17
* 開始   : 2026-08-12 16:25:00 (UTC)
* 終了   : 2026-08-12 16:50:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260812-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→13→11→13→11→13→12
* 開始   : 2026-08-12 19:00:00 (UTC)
* 終了   : 2026-08-12 19:05:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→12→11→10→12
* 開始   : 2026-08-12 19:30:00 (UTC)
* 終了   : 2026-08-12 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→12→13→13→11→14→12→16→15
* 開始   : 2026-08-13 04:20:00 (UTC)
* 終了   : 2026-08-13 05:10:00 (UTC)
* 現象   : 2026-08-13 05:10:00 (UTC)を境に水準が 14.89から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→19→18→18→17→17→17→18→19
* 開始   : 2026-08-13 06:05:00 (UTC)
* 終了   : 2026-08-13 07:15:00 (UTC)
* 現象   : 2026-08-13 07:15:00 (UTC)を境に水準が 15.04から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→19→18→19→18→19→18
* 開始   : 2026-08-13 07:15:00 (UTC)
* 終了   : 2026-08-13 07:25:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→18→18→17→16→17→16→15→16
* 開始   : 2026-08-13 16:50:00 (UTC)
* 終了   : 2026-08-13 18:00:00 (UTC)
* 現象   : 2026-08-13 18:00:00 (UTC)を境に水準が 14.85から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→13→14
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 19:35:00 (UTC)
* 現象   : 2026-08-13 19:35:00 (UTC)を境に水準が 14.89から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→9→7→8→7→8→7→11→12
* 開始   : 2026-08-13 21:20:00 (UTC)
* 終了   : 2026-08-13 21:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→9→9→7→8→8
* 開始   : 2026-08-14 00:20:00 (UTC)
* 終了   : 2026-08-14 00:45:00 (UTC)
* 現象   : 2026-08-14 00:45:00 (UTC)を境に水準が 14.91から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→10→14→10→14→12→13
* 開始   : 2026-08-14 03:55:00 (UTC)
* 終了   : 2026-08-14 04:05:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→16→17→16→17→16→15
* 開始   : 2026-08-14 05:45:00 (UTC)
* 終了   : 2026-08-14 05:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→15→15→17→18→15→16→17
* 開始   : 2026-08-14 06:05:00 (UTC)
* 終了   : 2026-08-14 06:50:00 (UTC)
* 現象   : 2026-08-14 06:50:00 (UTC)を境に水準が 14.92から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→21→21→21→21→23→23
* 開始   : 2026-08-14 09:35:00 (UTC)
* 終了   : 2026-08-14 10:05:00 (UTC)
* 現象   : 2026-08-14 10:05:00 (UTC)を境に水準が 15.08から13.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→16→15→16→18→16→15→16→19
* 開始   : 2026-08-14 16:25:00 (UTC)
* 終了   : 2026-08-14 16:30:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→12→14→11→12
* 開始   : 2026-08-14 19:20:00 (UTC)
* 終了   : 2026-08-14 19:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→8→…→9→8→9→11
* 開始   : 2026-08-14 20:25:00 (UTC)
* 終了   : 2026-08-14 20:30:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→8→7→10→…→10→6→9→11
* 開始   : 2026-08-14 21:10:00 (UTC)
* 終了   : 2026-08-14 21:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-079 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260814-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→9→6→8→6→8→6→8→7
* 開始   : 2026-08-14 22:05:00 (UTC)
* 終了   : 2026-08-14 22:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260814-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→12→17→18→…→16→18→15→17
* 開始   : 2026-08-16 09:30:00 (UTC)
* 終了   : 2026-08-16 09:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260816-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→11→17→15→14→11→17→15→14
* 開始   : 2026-08-16 15:50:00 (UTC)
* 終了   : 2026-08-16 15:55:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→12→11→9→12→12
* 開始   : 2026-08-16 19:10:00 (UTC)
* 終了   : 2026-08-16 19:35:00 (UTC)
* 現象   : 2026-08-16 19:35:00 (UTC)を境に水準が 11.83から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→8→9→9→8→10→11
* 開始   : 2026-08-17 22:00:00 (UTC)
* 終了   : 2026-08-17 23:00:00 (UTC)
* 現象   : 2026-08-17 23:00:00 (UTC)を境に水準が 14.91から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→16→16→16→16
* 開始   : 2026-08-18 05:20:00 (UTC)
* 終了   : 2026-08-18 05:50:00 (UTC)
* 現象   : 2026-08-18 05:50:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→17→20→17→20→18→17
* 開始   : 2026-08-18 07:50:00 (UTC)
* 終了   : 2026-08-18 08:00:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→15→20→15→20→18
* 開始   : 2026-08-18 07:50:00 (UTC)
* 終了   : 2026-08-18 07:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→22→20→21→24→22→23→22→24
* 開始   : 2026-08-18 09:15:00 (UTC)
* 終了   : 2026-08-18 10:05:00 (UTC)
* 現象   : 2026-08-18 10:05:00 (UTC)を境に水準が 15.03から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.716, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 23→21→23→24→22
* 開始   : 2026-08-18 10:40:00 (UTC)
* 終了   : 2026-08-18 11:00:00 (UTC)
* 現象   : 2026-08-18 11:00:00 (UTC)を境に水準が 15から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→14→19→14→…→19→14→15→16
* 開始   : 2026-08-18 17:00:00 (UTC)
* 終了   : 2026-08-18 17:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→16→15→16→15→16→15
* 開始   : 2026-08-18 17:05:00 (UTC)
* 終了   : 2026-08-18 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260818-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→10→…→11→10→12→13
* 開始   : 2026-08-18 19:15:00 (UTC)
* 終了   : 2026-08-18 19:20:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→11→12→13→11→14
* 開始   : 2026-08-18 19:45:00 (UTC)
* 終了   : 2026-08-18 20:10:00 (UTC)
* 現象   : 2026-08-18 20:10:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→11→8→7→9→11→8→7→9
* 開始   : 2026-08-18 21:15:00 (UTC)
* 終了   : 2026-08-18 21:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260818-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→14→…→14→17→16→14
* 開始   : 2026-08-19 05:00:00 (UTC)
* 終了   : 2026-08-19 06:10:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260819-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→16→16
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 06:15:00 (UTC)
* 現象   : 2026-08-19 06:15:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.001, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→15→18→15→16→15→16→17
* 開始   : 2026-08-19 16:45:00 (UTC)
* 終了   : 2026-08-19 16:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→14→16→17→14→16→15
* 開始   : 2026-08-19 17:15:00 (UTC)
* 終了   : 2026-08-19 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→12→14→12→14→12→13
* 開始   : 2026-08-19 18:25:00 (UTC)
* 終了   : 2026-08-19 18:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→9→12→9→12→9→12→11
* 開始   : 2026-08-19 20:10:00 (UTC)
* 終了   : 2026-08-19 20:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260819-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260819-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→11→…→11→7→10→9
* 開始   : 2026-08-19 20:30:00 (UTC)
* 終了   : 2026-08-19 20:40:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260819-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→11→12→9→10→12
* 開始   : 2026-08-19 21:35:00 (UTC)
* 終了   : 2026-08-19 22:00:00 (UTC)
* 現象   : 2026-08-19 22:00:00 (UTC)を境に水準が 14.9から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→5→11→8→…→5→11→8→7
* 開始   : 2026-08-19 23:30:00 (UTC)
* 終了   : 2026-08-19 23:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→13→17→13→17→15
* 開始   : 2026-08-20 06:00:00 (UTC)
* 終了   : 2026-08-20 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260820-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→12→15→18→12→15→18→17→16
* 開始   : 2026-08-20 06:40:00 (UTC)
* 終了   : 2026-08-20 06:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 24→22→23→23→22→24
* 開始   : 2026-08-20 10:10:00 (UTC)
* 終了   : 2026-08-20 10:35:00 (UTC)
* 現象   : 2026-08-20 10:35:00 (UTC)を境に水準が 14.91から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 22→23→21→21→21→21→22→22→24
* 開始   : 2026-08-20 11:05:00 (UTC)
* 終了   : 2026-08-20 11:50:00 (UTC)
* 現象   : 2026-08-20 11:50:00 (UTC)を境に水準が 15から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→9→8→10→9→8→10→9
* 開始   : 2026-08-20 20:40:00 (UTC)
* 終了   : 2026-08-20 20:45:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→12→10→9→10
* 開始   : 2026-08-20 21:05:00 (UTC)
* 終了   : 2026-08-20 21:30:00 (UTC)
* 現象   : 2026-08-20 21:30:00 (UTC)を境に水準が 15から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→8→8→8→11→8→9
* 開始   : 2026-08-20 22:45:00 (UTC)
* 終了   : 2026-08-20 23:35:00 (UTC)
* 現象   : 2026-08-20 23:35:00 (UTC)を境に水準が 14.81から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→6→5→6→5→8→9
* 開始   : 2026-08-20 23:00:00 (UTC)
* 終了   : 2026-08-20 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260820-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→6→…→12→6→10→9
* 開始   : 2026-08-21 02:00:00 (UTC)
* 終了   : 2026-08-21 02:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→10→12→9→12→9→12→10
* 開始   : 2026-08-21 02:40:00 (UTC)
* 終了   : 2026-08-21 02:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→17→17→18→19
* 開始   : 2026-08-21 06:25:00 (UTC)
* 終了   : 2026-08-21 06:45:00 (UTC)
* 現象   : 2026-08-21 06:45:00 (UTC)を境に水準が 14.92から14.67へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→21→19→16→21→19→17
* 開始   : 2026-08-21 08:05:00 (UTC)
* 終了   : 2026-08-21 08:10:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→20→16→22→…→16→22→19→20
* 開始   : 2026-08-21 09:05:00 (UTC)
* 終了   : 2026-08-21 09:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→20→23→20→23→17→21
* 開始   : 2026-08-21 09:10:00 (UTC)
* 終了   : 2026-08-21 09:20:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 21→23→23→25→22→22→23→23→21
* 開始   : 2026-08-21 10:30:00 (UTC)
* 終了   : 2026-08-21 11:15:00 (UTC)
* 現象   : 2026-08-21 11:15:00 (UTC)を境に水準が 15.03から13.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→17→14→13→16→18
* 開始   : 2026-08-21 17:50:00 (UTC)
* 終了   : 2026-08-21 18:15:00 (UTC)
* 現象   : 2026-08-21 18:15:00 (UTC)を境に水準が 15.08から12.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→8→9→…→8→9→11→10
* 開始   : 2026-08-21 20:35:00 (UTC)
* 終了   : 2026-08-21 20:40:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.6531(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→8→6→8→6→9
* 開始   : 2026-08-21 21:45:00 (UTC)
* 終了   : 2026-08-21 21:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→9→9→9→9→8→9
* 開始   : 2026-08-21 23:05:00 (UTC)
* 終了   : 2026-08-21 23:35:00 (UTC)
* 現象   : 2026-08-21 23:35:00 (UTC)を境に水準が 14.99から11.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host11-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→8→10→10→8→8→8
* 開始   : 2026-08-21 23:35:00 (UTC)
* 終了   : 2026-08-22 00:55:00 (UTC)
* 現象   : 2026-08-22 00:55:00 (UTC)を境に水準が 14.99から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.153, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host11-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→10→10→9
* 開始   : 2026-08-22 00:50:00 (UTC)
* 終了   : 2026-08-22 01:15:00 (UTC)
* 現象   : 2026-08-22 01:15:00 (UTC)を境に水準が 15.03から11.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260822-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 7→8→11→9→11→9→11→9
* 開始   : 2026-08-22 02:10:00 (UTC)
* 終了   : 2026-08-22 02:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260822-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→7→13→10→9→7→13→10→9
* 開始   : 2026-08-22 20:25:00 (UTC)
* 終了   : 2026-08-22 20:30:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260822-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→8→6→12→9→8→6→12→9
* 開始   : 2026-08-22 22:10:00 (UTC)
* 終了   : 2026-08-22 22:15:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260822-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→11→12→10→8→11→12→10→8
* 開始   : 2026-08-23 02:10:00 (UTC)
* 終了   : 2026-08-23 02:15:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260823-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→15→16→11→15→14→16→14→15
* 開始   : 2026-08-23 08:05:00 (UTC)
* 終了   : 2026-08-23 08:45:00 (UTC)
* 現象   : 2026-08-23 08:45:00 (UTC)を境に水準が 11.82から12.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→16→14→16→15→17
* 開始   : 2026-08-23 08:25:00 (UTC)
* 終了   : 2026-08-23 09:15:00 (UTC)
* 現象   : 2026-08-23 09:15:00 (UTC)を境に水準が 11.85から12.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→12→…→11→9→12→11
* 開始   : 2026-08-23 17:35:00 (UTC)
* 終了   : 2026-08-23 17:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260823-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→8→12→13→8→12→9
* 開始   : 2026-08-23 19:25:00 (UTC)
* 終了   : 2026-08-23 19:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260823-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→10→10→10→12→11→8
* 開始   : 2026-08-23 19:25:00 (UTC)
* 終了   : 2026-08-23 21:10:00 (UTC)
* 現象   : 2026-08-23 21:10:00 (UTC)を境に水準が 11.8から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.406, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→9→…→9→12→7→9
* 開始   : 2026-08-25 02:30:00 (UTC)
* 終了   : 2026-08-25 02:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260825-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→13→14→17→13→17
* 開始   : 2026-08-25 05:50:00 (UTC)
* 終了   : 2026-08-25 05:55:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→18→19→13→15→18→19→13→16
* 開始   : 2026-08-25 06:15:00 (UTC)
* 終了   : 2026-08-25 06:20:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→23→22→24→23→22→24→21
* 開始   : 2026-08-25 09:25:00 (UTC)
* 終了   : 2026-08-25 09:35:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→16→15→17→18→16→15→17→18
* 開始   : 2026-08-25 16:30:00 (UTC)
* 終了   : 2026-08-25 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→16→14→18→14→18→14→17→16
* 開始   : 2026-08-25 17:05:00 (UTC)
* 終了   : 2026-08-25 17:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→11→8→10→11→8→10→12
* 開始   : 2026-08-25 20:40:00 (UTC)
* 終了   : 2026-08-25 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→19→16→19→16→19→15→17
* 開始   : 2026-08-26 06:40:00 (UTC)
* 終了   : 2026-08-26 06:50:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→17→20
* 開始   : 2026-08-26 07:00:00 (UTC)
* 終了   : 2026-08-26 07:10:00 (UTC)
* 現象   : 2026-08-26 07:10:00 (UTC)を境に水準が 14.91から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→21→21→20→20→20→21→21→21
* 開始   : 2026-08-26 08:25:00 (UTC)
* 終了   : 2026-08-26 09:10:00 (UTC)
* 現象   : 2026-08-26 09:10:00 (UTC)を境に水準が 15.06から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.003, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→19→18→16→15→19→18
* 開始   : 2026-08-26 16:10:00 (UTC)
* 終了   : 2026-08-26 16:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→8→7→7→11→9→10
* 開始   : 2026-08-27 00:15:00 (UTC)
* 終了   : 2026-08-27 00:55:00 (UTC)
* 現象   : 2026-08-27 00:55:00 (UTC)を境に水準が 14.88から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→7→…→7→5→9→7
* 開始   : 2026-08-27 00:15:00 (UTC)
* 終了   : 2026-08-27 00:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→10→…→16→10→11→13
* 開始   : 2026-08-27 05:00:00 (UTC)
* 終了   : 2026-08-27 05:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→17→19→15→19→15→19→17→18
* 開始   : 2026-08-27 06:55:00 (UTC)
* 終了   : 2026-08-27 07:05:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→19→17→19→17→19→18→17
* 開始   : 2026-08-27 07:00:00 (UTC)
* 終了   : 2026-08-27 07:10:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260827-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→22→19→26→…→19→26→23→22
* 開始   : 2026-08-27 12:25:00 (UTC)
* 終了   : 2026-08-27 12:30:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 24→22→22→22→21→24→21→23→21
* 開始   : 2026-08-27 12:50:00 (UTC)
* 終了   : 2026-08-27 14:05:00 (UTC)
* 現象   : 2026-08-27 14:05:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 22→23→18→19→…→18→19→21→23
* 開始   : 2026-08-27 13:10:00 (UTC)
* 終了   : 2026-08-27 13:15:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.812(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.925σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→15→17→19→16→15→17
* 開始   : 2026-08-27 16:05:00 (UTC)
* 終了   : 2026-08-27 16:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→14→…→17→14→18→15
* 開始   : 2026-08-27 17:05:00 (UTC)
* 終了   : 2026-08-27 17:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260827-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→18→14→16→14→16→14→16
* 開始   : 2026-08-27 17:30:00 (UTC)
* 終了   : 2026-08-27 17:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→16→…→12→16→19→14
* 開始   : 2026-08-27 17:50:00 (UTC)
* 終了   : 2026-08-27 18:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260827-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→11→12→12→13→11→11
* 開始   : 2026-08-27 20:30:00 (UTC)
* 終了   : 2026-08-27 21:25:00 (UTC)
* 現象   : 2026-08-27 21:25:00 (UTC)を境に水準が 15.08から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.403, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host11-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→8→7→8→11→8→10→8→11
* 開始   : 2026-08-27 22:05:00 (UTC)
* 終了   : 2026-08-27 22:50:00 (UTC)
* 現象   : 2026-08-27 22:50:00 (UTC)を境に水準が 14.95から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→15→…→14→15→13→11
* 開始   : 2026-08-28 04:00:00 (UTC)
* 終了   : 2026-08-28 04:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→16→13→12→15→16→13
* 開始   : 2026-08-28 04:55:00 (UTC)
* 終了   : 2026-08-28 05:00:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260828-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→15→15→14→15→13→15→16
* 開始   : 2026-08-28 05:05:00 (UTC)
* 終了   : 2026-08-28 05:40:00 (UTC)
* 現象   : 2026-08-28 05:40:00 (UTC)を境に水準が 15.02から14.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→20→20→20→19→19→19→19→20
* 開始   : 2026-08-28 07:35:00 (UTC)
* 終了   : 2026-08-28 08:20:00 (UTC)
* 現象   : 2026-08-28 08:20:00 (UTC)を境に水準が 15.19から14.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→13→…→14→13→15→16
* 開始   : 2026-08-28 17:35:00 (UTC)
* 終了   : 2026-08-28 17:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→12→9→8→12→9→10
* 開始   : 2026-08-29 03:00:00 (UTC)
* 終了   : 2026-08-29 03:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 20 分
  - EVT-20260829-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 15 分
  - EVT-20260829-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 15 分
  - EVT-20260829-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-lsfhost01-007 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260829-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→10→9→8→10→9→8→10
* 開始   : 2026-08-29 19:45:00 (UTC)
* 終了   : 2026-08-29 19:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→9→5→11→10→9→5→11→10
* 開始   : 2026-08-29 22:15:00 (UTC)
* 終了   : 2026-08-29 22:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260829-host11-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
