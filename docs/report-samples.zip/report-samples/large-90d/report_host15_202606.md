# host15 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host15 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 299 (SEVERE: 19, FATAL: 120, WARN: 160, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 120 | 160 | 299 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→12→14→11→12
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 19:25:00 (UTC)
* 現象   : 2026-06-08 19:25:00 (UTC)を境に水準が 11.8から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.636, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-001 active_connections の推移](charts/EVT-20260608-host15-001.svg)

# イベントID( EVT-20260608-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→17→…→15→14→13→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.98から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.903, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.053, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-002 active_connections の推移](charts/EVT-20260608-host15-002.svg)

# イベントID( EVT-20260608-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→17→…→15→12→13→11
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 21:25:00 (UTC)
* 現象   : 2026-06-08 21:25:00 (UTC)を境に水準が 11.84から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.925, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-003 active_connections の推移](charts/EVT-20260608-host15-003.svg)

# イベントID( EVT-20260608-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→17→…→15→12→14→15
* 開始   : 2026-06-08 03:05:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.86から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.778σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.002, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-004 active_connections の推移](charts/EVT-20260608-host15-004.svg)

# イベントID( EVT-20260608-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→17→16→14→…→16→13→14→13
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 20:45:00 (UTC)
* 現象   : 2026-06-08 20:45:00 (UTC)を境に水準が 11.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.689, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-005 active_connections の推移](charts/EVT-20260608-host15-005.svg)

# イベントID( EVT-20260608-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→15→…→14→13→12→10
* 開始   : 2026-06-08 04:20:00 (UTC)
* 終了   : 2026-06-08 19:50:00 (UTC)
* 現象   : 2026-06-08 19:50:00 (UTC)を境に水準が 12.01から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.83, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host15-006 active_connections の推移](charts/EVT-20260608-host15-006.svg)

# イベントID( EVT-20260615-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→16→…→16→15→14→13
* 開始   : 2026-06-15 02:50:00 (UTC)
* 終了   : 2026-06-15 22:30:00 (UTC)
* 現象   : 2026-06-15 22:30:00 (UTC)を境に水準が 11.82から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.806, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-002 active_connections の推移](charts/EVT-20260615-host15-002.svg)

# イベントID( EVT-20260615-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→17→15→14→…→17→15→14→18
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 11.84から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.836, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-003 active_connections の推移](charts/EVT-20260615-host15-003.svg)

# イベントID( EVT-20260615-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→13→10→11→9
* 開始   : 2026-06-15 03:00:00 (UTC)
* 終了   : 2026-06-15 22:00:00 (UTC)
* 現象   : 2026-06-15 22:00:00 (UTC)を境に水準が 11.66から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.802, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.675, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-004 active_connections の推移](charts/EVT-20260615-host15-004.svg)

# イベントID( EVT-20260615-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→15→…→14→13→15→14
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.069, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-006 active_connections の推移](charts/EVT-20260615-host15-006.svg)

# イベントID( EVT-20260622-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→16→…→14→13→14→12
* 開始   : 2026-06-22 00:10:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.78から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.101, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.113, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-001 active_connections の推移](charts/EVT-20260622-host15-001.svg)

# イベントID( EVT-20260622-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→12→14→15→…→12→13→12→13
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.86から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-004 active_connections の推移](charts/EVT-20260622-host15-004.svg)

# イベントID( EVT-20260622-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→21→16→…→14→15→13→12
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.86から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.847σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.791, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.893, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-005 active_connections の推移](charts/EVT-20260622-host15-005.svg)

# イベントID( EVT-20260629-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→15→14→13→…→11→14→11→12
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-002 active_connections の推移](charts/EVT-20260629-host15-002.svg)

# イベントID( EVT-20260629-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→11→18→14→…→17→14→11→12
* 開始   : 2026-06-29 02:50:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.88から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.093, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.133, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-003 active_connections の推移](charts/EVT-20260629-host15-003.svg)

# イベントID( EVT-20260629-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→16→17→…→15→11→12→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.71から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-004 active_connections の推移](charts/EVT-20260629-host15-004.svg)

# イベントID( EVT-20260629-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→…→13→15→13→14
* 開始   : 2026-06-29 03:05:00 (UTC)
* 終了   : 2026-06-29 19:15:00 (UTC)
* 現象   : 2026-06-29 19:15:00 (UTC)を境に水準が 11.79から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-005 active_connections の推移](charts/EVT-20260629-host15-005.svg)

# イベントID( EVT-20260629-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→15→14→15→…→16→11→14→12
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.417, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-006 active_connections の推移](charts/EVT-20260629-host15-006.svg)

# イベントID( EVT-20260629-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→18→15→18→…→13→15→12→14
* 開始   : 2026-06-29 03:40:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.99から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.55, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-007 active_connections の推移](charts/EVT-20260629-host15-007.svg)

# イベントID( EVT-20260601-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→19→15→18→18
* 開始   : 2026-06-01 16:00:00 (UTC)
* 終了   : 2026-06-01 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→15→11→14→12
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→13→14→9→…→9→13→12→10
* 開始   : 2026-06-02 03:15:00 (UTC)
* 終了   : 2026-06-02 03:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260602-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→12→15→11→11
* 開始   : 2026-06-02 03:50:00 (UTC)
* 終了   : 2026-06-02 03:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host15-003 active_connections の推移](charts/EVT-20260602-host15-003.svg)

# イベントID( EVT-20260602-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→12→16→13→13
* 開始   : 2026-06-02 04:25:00 (UTC)
* 終了   : 2026-06-02 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.524倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host15-004 active_connections の推移](charts/EVT-20260602-host15-004.svg)

# イベントID( EVT-20260602-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→18→22→20→…→17→20→19→17
* 開始   : 2026-06-02 07:20:00 (UTC)
* 終了   : 2026-06-02 07:40:00 (UTC)
* 現象   : 2026-06-02 07:40:00 (UTC)を境に水準が 15.01から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.185σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host15-007 active_connections の推移](charts/EVT-20260602-host15-007.svg)

# イベントID( EVT-20260602-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→15→21→18→16
* 開始   : 2026-06-02 07:25:00 (UTC)
* 終了   : 2026-06-02 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→20→24→22→22
* 開始   : 2026-06-02 09:10:00 (UTC)
* 終了   : 2026-06-02 09:10:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→14→18→15→14→18→19
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260602-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→17→18
* 開始   : 2026-06-02 16:50:00 (UTC)
* 終了   : 2026-06-02 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7059(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host15-016 active_connections の推移](charts/EVT-20260602-host15-016.svg)

# イベントID( EVT-20260602-host15-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→10→5→11→11
* 開始   : 2026-06-02 21:05:00 (UTC)
* 終了   : 2026-06-02 21:05:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.4615(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host15-017 active_connections の推移](charts/EVT-20260602-host15-017.svg)

# イベントID( EVT-20260603-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→21→23→19→19
* 開始   : 2026-06-03 08:40:00 (UTC)
* 終了   : 2026-06-03 08:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→15→20→22→15→20→22→17→18
* 開始   : 2026-06-03 16:20:00 (UTC)
* 終了   : 2026-06-03 17:25:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 20 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260603-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 7→9→12→8→…→8→5→7→10
* 開始   : 2026-06-04 01:15:00 (UTC)
* 終了   : 2026-06-04 01:25:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→12→16→12→13
* 開始   : 2026-06-04 04:35:00 (UTC)
* 終了   : 2026-06-04 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→19→23→21→22→23→21→22→21
* 開始   : 2026-06-04 08:45:00 (UTC)
* 終了   : 2026-06-04 08:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 24→22→21→21→23→22→22→23→24
* 開始   : 2026-06-05 08:20:00 (UTC)
* 終了   : 2026-06-05 11:05:00 (UTC)
* 現象   : 2026-06-05 11:05:00 (UTC)を境に水準が 15.07から13.57へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→15→12→15→14
* 開始   : 2026-06-05 18:00:00 (UTC)
* 終了   : 2026-06-05 18:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host15-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260605-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→7→10→12
* 開始   : 2026-06-05 20:35:00 (UTC)
* 終了   : 2026-06-05 20:35:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→12→…→12→13→14→11
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.93, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host15-001 active_connections の推移](charts/EVT-20260606-host15-001.svg)

# イベントID( EVT-20260606-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→8→11→12→…→11→14→12→14
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 17:45:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.921, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host15-002 active_connections の推移](charts/EVT-20260606-host15-002.svg)

# イベントID( EVT-20260606-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→12→8→12→…→13→11→10→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.991, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host15-003 active_connections の推移](charts/EVT-20260606-host15-003.svg)

# イベントID( EVT-20260606-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→10→16→13→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.031, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host15-004 active_connections の推移](charts/EVT-20260606-host15-004.svg)

# イベントID( EVT-20260606-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→11→12→14→…→12→10→12→13
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.94, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host15-005 active_connections の推移](charts/EVT-20260606-host15-005.svg)

# イベントID( EVT-20260606-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→14→10→12→…→10→12→10→12
* 開始   : 2026-06-06 06:05:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.925, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host15-006 active_connections の推移](charts/EVT-20260606-host15-006.svg)

# イベントID( EVT-20260607-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→9→4→8→8
* 開始   : 2026-06-07 01:20:00 (UTC)
* 終了   : 2026-06-07 01:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→15→14
* 開始   : 2026-06-07 08:20:00 (UTC)
* 終了   : 2026-06-07 08:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→8→4→7→7
* 開始   : 2026-06-07 23:30:00 (UTC)
* 終了   : 2026-06-07 23:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→14→19→17→13
* 開始   : 2026-06-09 05:55:00 (UTC)
* 終了   : 2026-06-09 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.39倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host15-004 active_connections の推移](charts/EVT-20260609-host15-004.svg)

# イベントID( EVT-20260609-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→15→15
* 開始   : 2026-06-09 05:55:00 (UTC)
* 終了   : 2026-06-09 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→15→18→15→15
* 開始   : 2026-06-09 06:10:00 (UTC)
* 終了   : 2026-06-09 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→21→19→21→19→21→18→19
* 開始   : 2026-06-09 08:05:00 (UTC)
* 終了   : 2026-06-09 09:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260609-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260609-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host15-008 active_connections の推移](charts/EVT-20260609-host15-008.svg)

# イベントID( EVT-20260609-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 19→15→20→17→22→20→17→22→18
* 開始   : 2026-06-09 08:05:00 (UTC)
* 終了   : 2026-06-09 08:15:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 22→20→25→20→22
* 開始   : 2026-06-09 09:45:00 (UTC)
* 終了   : 2026-06-09 09:45:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→13→16→14→13→16→14→17
* 開始   : 2026-06-09 17:05:00 (UTC)
* 終了   : 2026-06-09 17:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→16→12→10
* 開始   : 2026-06-10 04:00:00 (UTC)
* 終了   : 2026-06-10 04:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.466倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-002 active_connections の推移](charts/EVT-20260610-host15-002.svg)

# イベントID( EVT-20260610-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→16→17
* 開始   : 2026-06-10 07:00:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→15→…→15→12→16→15
* 開始   : 2026-06-10 17:40:00 (UTC)
* 終了   : 2026-06-10 18:55:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260610-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260610-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→12→13
* 開始   : 2026-06-11 04:50:00 (UTC)
* 終了   : 2026-06-11 04:50:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host15-003 active_connections の推移](charts/EVT-20260611-host15-003.svg)

# イベントID( EVT-20260611-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→21→17→22→18→17→22→18→22
* 開始   : 2026-06-11 14:20:00 (UTC)
* 終了   : 2026-06-11 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 19→20→15→19→21
* 開始   : 2026-06-11 15:50:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→18→12→16→16
* 開始   : 2026-06-11 17:15:00 (UTC)
* 終了   : 2026-06-11 17:15:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260611-host15-009 active_connections の推移](charts/EVT-20260611-host15-009.svg)

# イベントID( EVT-20260611-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→9→4→9→8
* 開始   : 2026-06-11 22:40:00 (UTC)
* 終了   : 2026-06-11 22:40:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.4324(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-082 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host15-012 active_connections の推移](charts/EVT-20260611-host15-012.svg)

# イベントID( EVT-20260612-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→13→17→15→12
* 開始   : 2026-06-12 05:10:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 平常時(12)に対し 1.417倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host15-002 active_connections の推移](charts/EVT-20260612-host15-002.svg)

# イベントID( EVT-20260612-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→12→18→15→14
* 開始   : 2026-06-12 05:40:00 (UTC)
* 終了   : 2026-06-12 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host15-004 active_connections の推移](charts/EVT-20260612-host15-004.svg)

# イベントID( EVT-20260612-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→11→5→10→8
* 開始   : 2026-06-12 22:15:00 (UTC)
* 終了   : 2026-06-12 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→9→11→12→10
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.148, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host15-002 active_connections の推移](charts/EVT-20260613-host15-002.svg)

# イベントID( EVT-20260613-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→10→13→12→…→12→9→13→11
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:05:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260613-host15-003 active_connections の推移](charts/EVT-20260613-host15-003.svg)

# イベントID( EVT-20260613-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→14→…→11→10→11→10
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.014, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host15-004 active_connections の推移](charts/EVT-20260613-host15-004.svg)

# イベントID( EVT-20260613-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→12→11→12→13
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 18:20:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.975, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host15-005 active_connections の推移](charts/EVT-20260613-host15-005.svg)

# イベントID( EVT-20260613-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→13→11→12→13
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.866, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host15-006 active_connections の推移](charts/EVT-20260613-host15-006.svg)

# イベントID( EVT-20260613-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→14→11→14→…→12→11→13→12
* 開始   : 2026-06-13 06:35:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.928, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260613-host15-007 active_connections の推移](charts/EVT-20260613-host15-007.svg)

# イベントID( EVT-20260614-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→16→19→16→16
* 開始   : 2026-06-14 09:50:00 (UTC)
* 終了   : 2026-06-14 09:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260614-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→16→15→14→…→14→17→14→15
* 開始   : 2026-06-15 03:15:00 (UTC)
* 終了   : 2026-06-15 19:30:00 (UTC)
* 現象   : 2026-06-15 19:30:00 (UTC)を境に水準が 11.85から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.194, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-005 active_connections の推移](charts/EVT-20260615-host15-005.svg)

# イベントID( EVT-20260615-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→13→…→15→12→13→12
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.78から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.66, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.019, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host15-007 active_connections の推移](charts/EVT-20260615-host15-007.svg)

# イベントID( EVT-20260616-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→8→13→9→10
* 開始   : 2026-06-16 02:00:00 (UTC)
* 終了   : 2026-06-16 02:00:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260616-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→15→12→17→15→12→17→15→13
* 開始   : 2026-06-16 04:40:00 (UTC)
* 終了   : 2026-06-16 04:50:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-003 active_connections の推移](charts/EVT-20260616-host15-003.svg)

# イベントID( EVT-20260616-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→20→23→19→23→19→23→20→22
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→21→17→23→22
* 開始   : 2026-06-17 13:05:00 (UTC)
* 終了   : 2026-06-17 13:05:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→15→13→16→16
* 開始   : 2026-06-17 17:00:00 (UTC)
* 終了   : 2026-06-17 17:00:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→6→9→14→6→9→14→8→12
* 開始   : 2026-06-18 03:20:00 (UTC)
* 終了   : 2026-06-18 03:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→17→18→13→…→13→19→15→17
* 開始   : 2026-06-18 06:05:00 (UTC)
* 終了   : 2026-06-18 06:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260618-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→18→22→19→19
* 開始   : 2026-06-18 08:00:00 (UTC)
* 終了   : 2026-06-18 08:00:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→13→16→13→16→13→15→17
* 開始   : 2026-06-18 17:00:00 (UTC)
* 終了   : 2026-06-18 17:10:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→11→12→15→…→15→12→13→14
* 開始   : 2026-06-18 18:05:00 (UTC)
* 終了   : 2026-06-18 18:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-009 active_connections の推移](charts/EVT-20260618-host15-009.svg)

# イベントID( EVT-20260618-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→10→13→13
* 開始   : 2026-06-18 19:05:00 (UTC)
* 終了   : 2026-06-18 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→11→15→13→11
* 開始   : 2026-06-19 03:55:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→15→18
* 開始   : 2026-06-19 05:25:00 (UTC)
* 終了   : 2026-06-19 06:50:00 (UTC)
* 現象   : 2026-06-19 06:50:00 (UTC)を境に水準が 14.94から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→16→17
* 開始   : 2026-06-19 07:00:00 (UTC)
* 終了   : 2026-06-19 07:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→21→17→22→19
* 開始   : 2026-06-19 12:05:00 (UTC)
* 終了   : 2026-06-19 12:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→15→10→13→13
* 開始   : 2026-06-19 18:55:00 (UTC)
* 終了   : 2026-06-19 18:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→12→8→12→11
* 開始   : 2026-06-19 19:35:00 (UTC)
* 終了   : 2026-06-19 19:35:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6076(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-015 active_connections の推移](charts/EVT-20260619-host15-015.svg)

# イベントID( EVT-20260619-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→13→8→11→10
* 開始   : 2026-06-19 20:05:00 (UTC)
* 終了   : 2026-06-19 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host15-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→10→…→13→11→13→12
* 開始   : 2026-06-20 04:10:00 (UTC)
* 終了   : 2026-06-20 20:00:00 (UTC)
* 現象   : 15.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260620-host15-002 active_connections の推移](charts/EVT-20260620-host15-002.svg)

# イベントID( EVT-20260620-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→14→…→10→12→10→12
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host15-003 active_connections の推移](charts/EVT-20260620-host15-003.svg)

# イベントID( EVT-20260620-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→8→11→12→10
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:25:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host15-005 active_connections の推移](charts/EVT-20260620-host15-005.svg)

# イベントID( EVT-20260620-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→15→…→10→14→11→12
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host15-006 active_connections の推移](charts/EVT-20260620-host15-006.svg)

# イベントID( EVT-20260620-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→13→…→13→12→13→12
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.325, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260620-host15-007 active_connections の推移](charts/EVT-20260620-host15-007.svg)

# イベントID( EVT-20260620-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→13→…→11→10→11→10
* 開始   : 2026-06-20 06:25:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.565σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host15-008 active_connections の推移](charts/EVT-20260620-host15-008.svg)

# イベントID( EVT-20260620-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→9→6→11→9
* 開始   : 2026-06-20 20:10:00 (UTC)
* 終了   : 2026-06-20 20:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260620-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260620-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→15→18→14→14
* 開始   : 2026-06-21 08:20:00 (UTC)
* 終了   : 2026-06-21 08:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→14→10→13→14
* 開始   : 2026-06-21 15:40:00 (UTC)
* 終了   : 2026-06-21 15:40:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→14→9→11→14→9→12
* 開始   : 2026-06-21 17:00:00 (UTC)
* 終了   : 2026-06-21 17:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→12→5→7→9
* 開始   : 2026-06-21 22:15:00 (UTC)
* 終了   : 2026-06-21 22:15:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→15→13→14→…→17→14→16→13
* 開始   : 2026-06-22 02:20:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.871, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→16→…→14→16→13→15
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.912, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→15→…→15→14→13→14
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 12.05から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.678, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.608, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 9→8→14→9→9
* 開始   : 2026-06-23 01:05:00 (UTC)
* 終了   : 2026-06-23 01:05:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.846倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.489σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-001 active_connections の推移](charts/EVT-20260623-host15-001.svg)

# イベントID( EVT-20260623-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→12→10
* 開始   : 2026-06-23 03:50:00 (UTC)
* 終了   : 2026-06-23 03:50:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→17→18→20→17
* 開始   : 2026-06-23 07:40:00 (UTC)
* 終了   : 2026-06-23 08:00:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 20 分
  - EVT-20260623-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→20→17→20→20
* 開始   : 2026-06-23 13:25:00 (UTC)
* 終了   : 2026-06-23 13:25:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→20→22
* 開始   : 2026-06-23 14:45:00 (UTC)
* 終了   : 2026-06-23 14:45:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→16→21→17→18
* 開始   : 2026-06-24 07:20:00 (UTC)
* 終了   : 2026-06-24 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.319倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host15-004 active_connections の推移](charts/EVT-20260624-host15-004.svg)

# イベントID( EVT-20260624-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→20→20
* 開始   : 2026-06-24 08:35:00 (UTC)
* 終了   : 2026-06-24 08:35:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→17→13→18→15
* 開始   : 2026-06-24 17:10:00 (UTC)
* 終了   : 2026-06-24 17:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→17→21→16→14
* 開始   : 2026-06-24 17:25:00 (UTC)
* 終了   : 2026-06-24 17:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→17→12→16→15
* 開始   : 2026-06-24 17:30:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.7024(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-013 active_connections の推移](charts/EVT-20260624-host15-013.svg)

# イベントID( EVT-20260624-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→17→13→16→15
* 開始   : 2026-06-24 17:30:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→13→12
* 開始   : 2026-06-24 19:25:00 (UTC)
* 終了   : 2026-06-24 19:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→11→9
* 開始   : 2026-06-25 03:45:00 (UTC)
* 終了   : 2026-06-25 03:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→16→…→17→16→15→14
* 開始   : 2026-06-25 05:20:00 (UTC)
* 終了   : 2026-06-25 05:25:00 (UTC)
* 現象   : 2026-06-25 05:25:00 (UTC)を境に水準が 14.99から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.473, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→16→16
* 開始   : 2026-06-25 17:10:00 (UTC)
* 終了   : 2026-06-25 17:10:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→15→11→15→15
* 開始   : 2026-06-25 18:20:00 (UTC)
* 終了   : 2026-06-25 18:20:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→8→9→9→10→8→9→9
* 開始   : 2026-06-25 23:10:00 (UTC)
* 終了   : 2026-06-26 00:40:00 (UTC)
* 現象   : 2026-06-26 00:40:00 (UTC)を境に水準が 14.99から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.906, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→10→14→9→…→9→13→11→12
* 開始   : 2026-06-26 03:10:00 (UTC)
* 終了   : 2026-06-26 03:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→13→12→11→12→16
* 開始   : 2026-06-26 03:50:00 (UTC)
* 終了   : 2026-06-26 04:25:00 (UTC)
* 現象   : 2026-06-26 04:25:00 (UTC)を境に水準が 14.89から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→17→24→19→22
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→8→5→9→7
* 開始   : 2026-06-26 21:55:00 (UTC)
* 終了   : 2026-06-26 21:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→12→…→10→11→12→13
* 開始   : 2026-06-27 04:10:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.816, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host15-003 active_connections の推移](charts/EVT-20260627-host15-003.svg)

# イベントID( EVT-20260627-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→14→…→14→10→13→11
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.842, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host15-004 active_connections の推移](charts/EVT-20260627-host15-004.svg)

# イベントID( EVT-20260627-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→13→…→12→11→10→12
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.559, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host15-005 active_connections の推移](charts/EVT-20260627-host15-005.svg)

# イベントID( EVT-20260627-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→12→13→12→13
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.177, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host15-006 active_connections の推移](charts/EVT-20260627-host15-006.svg)

# イベントID( EVT-20260627-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→13→11→10→…→10→11→13→9
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 20:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.457, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 13.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260627-host15-007 active_connections の推移](charts/EVT-20260627-host15-007.svg)

# イベントID( EVT-20260627-host15-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→13→…→13→11→14→12
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.3, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host15-008 active_connections の推移](charts/EVT-20260627-host15-008.svg)

# イベントID( EVT-20260630-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→21→24→20→19
* 開始   : 2026-06-30 09:20:00 (UTC)
* 終了   : 2026-06-30 09:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→21→25→19→22
* 開始   : 2026-06-30 09:40:00 (UTC)
* 終了   : 2026-06-30 09:40:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→22→18→22→22
* 開始   : 2026-06-30 12:00:00 (UTC)
* 終了   : 2026-06-30 12:00:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→19→18→19→…→15→16→19→17
* 開始   : 2026-06-30 15:20:00 (UTC)
* 終了   : 2026-06-30 15:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.047 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host15-006 active_connections の推移](charts/EVT-20260630-host15-006.svg)

# イベントID( EVT-20260630-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→18→15→19→18
* 開始   : 2026-06-30 16:05:00 (UTC)
* 終了   : 2026-06-30 16:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.766(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→10→9→13→14→10→9→13→11
* 開始   : 2026-06-30 19:15:00 (UTC)
* 終了   : 2026-06-30 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→11→10→5→11→10→5→7→9
* 開始   : 2026-06-01 00:35:00 (UTC)
* 終了   : 2026-06-01 00:45:00 (UTC)
* 現象   : 平常時(7.429)に対し 1.481倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→18→16→18→17
* 開始   : 2026-06-01 06:30:00 (UTC)
* 終了   : 2026-06-01 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→17→19→16→…→16→20→17→18
* 開始   : 2026-06-01 07:20:00 (UTC)
* 終了   : 2026-06-01 07:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→20→19→17→20→19→18
* 開始   : 2026-06-01 07:45:00 (UTC)
* 終了   : 2026-06-01 07:50:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→14→18→15→14→18→16
* 開始   : 2026-06-01 17:05:00 (UTC)
* 終了   : 2026-06-01 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→15→14→18→15→14→18→19
* 開始   : 2026-06-01 17:15:00 (UTC)
* 終了   : 2026-06-01 17:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→13→15→16→13→15→17
* 開始   : 2026-06-01 17:45:00 (UTC)
* 終了   : 2026-06-01 17:50:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→10→7→13→…→13→7→13→11
* 開始   : 2026-06-02 03:20:00 (UTC)
* 終了   : 2026-06-02 03:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260602-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→13→8→10→15→8→10→15→13
* 開始   : 2026-06-02 04:35:00 (UTC)
* 終了   : 2026-06-02 04:45:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.864σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→12→15→16→…→15→16→15→14
* 開始   : 2026-06-02 04:55:00 (UTC)
* 終了   : 2026-06-02 05:00:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→20→19→19→19→20→20→19→22
* 開始   : 2026-06-02 07:55:00 (UTC)
* 終了   : 2026-06-02 08:35:00 (UTC)
* 現象   : 2026-06-02 08:35:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→21→18→23→…→23→25→20→21
* 開始   : 2026-06-02 10:20:00 (UTC)
* 終了   : 2026-06-02 10:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 19→22→24→21→…→21→25→21→22
* 開始   : 2026-06-02 11:15:00 (UTC)
* 終了   : 2026-06-02 11:25:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→19→18→19→18→19→20
* 開始   : 2026-06-02 14:25:00 (UTC)
* 終了   : 2026-06-02 14:35:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.8244(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→21→21→22→19→21→19→19→21
* 開始   : 2026-06-02 14:45:00 (UTC)
* 終了   : 2026-06-02 15:45:00 (UTC)
* 現象   : 2026-06-02 15:45:00 (UTC)を境に水準が 14.98から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.977, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host15-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→10→…→10→7→10→9
* 開始   : 2026-06-02 21:10:00 (UTC)
* 終了   : 2026-06-02 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-078 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host15-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→15→18→17→15→18→16
* 開始   : 2026-06-03 06:15:00 (UTC)
* 終了   : 2026-06-03 07:35:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→21→22→21→23→21→22→22→23
* 開始   : 2026-06-03 12:50:00 (UTC)
* 終了   : 2026-06-03 14:30:00 (UTC)
* 現象   : 2026-06-03 14:30:00 (UTC)を境に水準が 15.02から15.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.579, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→23→21→21
* 開始   : 2026-06-03 14:20:00 (UTC)
* 終了   : 2026-06-03 14:35:00 (UTC)
* 現象   : 2026-06-03 14:35:00 (UTC)を境に水準が 14.91から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→11→10→11→12
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260603-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→13
* 開始   : 2026-06-03 19:40:00 (UTC)
* 終了   : 2026-06-03 20:10:00 (UTC)
* 現象   : 2026-06-03 20:10:00 (UTC)を境に水準が 14.89から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→9→9→8→9→6→8→10→10
* 開始   : 2026-06-03 23:05:00 (UTC)
* 終了   : 2026-06-03 23:45:00 (UTC)
* 現象   : 2026-06-03 23:45:00 (UTC)を境に水準が 15.06から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.677, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→16→17→14→13→16→17→14→15
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→18→15→14→17→18→15
* 開始   : 2026-06-04 06:05:00 (UTC)
* 終了   : 2026-06-04 06:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260604-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→23→17→24→…→17→24→22→23
* 開始   : 2026-06-04 09:40:00 (UTC)
* 終了   : 2026-06-04 09:45:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 23→21→22→24→23→23→23→22→24
* 開始   : 2026-06-04 12:40:00 (UTC)
* 終了   : 2026-06-04 13:20:00 (UTC)
* 現象   : 2026-06-04 13:20:00 (UTC)を境に水準が 14.89から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→21→17→18→…→18→23→19→18
* 開始   : 2026-06-04 15:10:00 (UTC)
* 終了   : 2026-06-04 15:20:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260604-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 19→21→17→19→…→19→16→20→19
* 開始   : 2026-06-04 15:40:00 (UTC)
* 終了   : 2026-06-04 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→14→…→14→11→16→12
* 開始   : 2026-06-04 18:55:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→12
* 開始   : 2026-06-04 20:00:00 (UTC)
* 終了   : 2026-06-04 20:15:00 (UTC)
* 現象   : 2026-06-04 20:15:00 (UTC)を境に水準が 14.92から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→16→17→16→17→14→16
* 開始   : 2026-06-05 05:35:00 (UTC)
* 終了   : 2026-06-05 05:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260605-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→15→17→15→17→14→17
* 開始   : 2026-06-05 05:50:00 (UTC)
* 終了   : 2026-06-05 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→16→14→16→…→16→13→17→14
* 開始   : 2026-06-05 17:15:00 (UTC)
* 終了   : 2026-06-05 17:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260605-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→15→12→13→…→13→11→15→14
* 開始   : 2026-06-05 18:10:00 (UTC)
* 終了   : 2026-06-05 18:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→14→12→11→13→14→12→11→13
* 開始   : 2026-06-05 18:45:00 (UTC)
* 終了   : 2026-06-05 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→10→13→11→10→13→14
* 開始   : 2026-06-05 19:15:00 (UTC)
* 終了   : 2026-06-05 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→9→12→9→11
* 開始   : 2026-06-05 20:05:00 (UTC)
* 終了   : 2026-06-05 20:15:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260605-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→6→12→6→12→6→12→9
* 開始   : 2026-06-05 23:45:00 (UTC)
* 終了   : 2026-06-05 23:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.5倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.805σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host15-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→10→8→10→7→11→9→11→10
* 開始   : 2026-06-05 23:45:00 (UTC)
* 終了   : 2026-06-06 00:30:00 (UTC)
* 現象   : 2026-06-06 00:30:00 (UTC)を境に水準が 14.91から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→11→13→14→14→12→12→14→12
* 開始   : 2026-06-07 05:20:00 (UTC)
* 終了   : 2026-06-07 06:25:00 (UTC)
* 現象   : 2026-06-07 06:25:00 (UTC)を境に水準が 11.87から12.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→13→15→13
* 開始   : 2026-06-07 06:05:00 (UTC)
* 終了   : 2026-06-07 06:20:00 (UTC)
* 現象   : 2026-06-07 06:20:00 (UTC)を境に水準が 11.79から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→9→9→9→11→10→12→9→11
* 開始   : 2026-06-09 01:15:00 (UTC)
* 終了   : 2026-06-09 02:20:00 (UTC)
* 現象   : 2026-06-09 02:20:00 (UTC)を境に水準が 15.01から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→12→…→13→17→14→16
* 開始   : 2026-06-09 05:20:00 (UTC)
* 終了   : 2026-06-09 05:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260609-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260609-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→16→16→18→18→17→18→19
* 開始   : 2026-06-09 05:35:00 (UTC)
* 終了   : 2026-06-09 07:10:00 (UTC)
* 現象   : 2026-06-09 07:10:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→19→16→19→16→19
* 開始   : 2026-06-09 07:15:00 (UTC)
* 終了   : 2026-06-09 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 24→24→21→23→24→22→24→22→22
* 開始   : 2026-06-09 12:35:00 (UTC)
* 終了   : 2026-06-09 13:25:00 (UTC)
* 現象   : 2026-06-09 13:25:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.603, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→16→11→13→16→11→13
* 開始   : 2026-06-09 19:00:00 (UTC)
* 終了   : 2026-06-09 19:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→14→10→14→10→12
* 開始   : 2026-06-09 19:30:00 (UTC)
* 終了   : 2026-06-09 19:40:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→11→13→14→…→13→14→12→13
* 開始   : 2026-06-10 04:00:00 (UTC)
* 終了   : 2026-06-10 04:05:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→20→17→20→17→20→17→18
* 開始   : 2026-06-10 07:25:00 (UTC)
* 終了   : 2026-06-10 07:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 24→23→22→22→23→23→24
* 開始   : 2026-06-10 10:35:00 (UTC)
* 終了   : 2026-06-10 11:05:00 (UTC)
* 現象   : 2026-06-10 11:05:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→13→14→11→13→12
* 開始   : 2026-06-10 18:50:00 (UTC)
* 終了   : 2026-06-10 18:55:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→12→10→10→10→11→12
* 開始   : 2026-06-10 20:05:00 (UTC)
* 終了   : 2026-06-10 21:05:00 (UTC)
* 現象   : 2026-06-10 21:05:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→10→5→8→10→5→8→7
* 開始   : 2026-06-11 00:15:00 (UTC)
* 終了   : 2026-06-11 00:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-001 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260611-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→15→13→15→13→15→13→12
* 開始   : 2026-06-11 04:45:00 (UTC)
* 終了   : 2026-06-11 04:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→17→18→17→18
* 開始   : 2026-06-11 06:35:00 (UTC)
* 終了   : 2026-06-11 07:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260611-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→18→19→17→15→18→19→17→18
* 開始   : 2026-06-11 06:45:00 (UTC)
* 終了   : 2026-06-11 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→21→21→21→20
* 開始   : 2026-06-11 15:05:00 (UTC)
* 終了   : 2026-06-11 15:25:00 (UTC)
* 現象   : 2026-06-11 15:25:00 (UTC)を境に水準が 15.05から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.566, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→19→15→…→15→12→15→13
* 開始   : 2026-06-11 18:25:00 (UTC)
* 終了   : 2026-06-11 19:15:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260611-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→12→6→11→8→10→10
* 開始   : 2026-06-11 21:30:00 (UTC)
* 終了   : 2026-06-11 22:55:00 (UTC)
* 現象   : 2026-06-11 22:55:00 (UTC)を境に水準が 14.98から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→11→10→9→11→10
* 開始   : 2026-06-12 02:35:00 (UTC)
* 終了   : 2026-06-12 02:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→10→14→16→10→14→12
* 開始   : 2026-06-12 05:40:00 (UTC)
* 終了   : 2026-06-12 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→18→23→19→23→19→23→22→21
* 開始   : 2026-06-12 09:20:00 (UTC)
* 終了   : 2026-06-12 09:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→21→24→23→24→23→24→22→21
* 開始   : 2026-06-12 09:55:00 (UTC)
* 終了   : 2026-06-12 10:05:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.21倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260612-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→21→17→19→17→19→17→18→20
* 開始   : 2026-06-12 15:30:00 (UTC)
* 終了   : 2026-06-12 15:40:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→20→15→17→15→17→15→16→18
* 開始   : 2026-06-12 16:55:00 (UTC)
* 終了   : 2026-06-12 17:05:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→18→14→18→…→16→13→16→15
* 開始   : 2026-06-12 17:20:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→13→14→10→13→12
* 開始   : 2026-06-12 18:50:00 (UTC)
* 終了   : 2026-06-12 18:55:00 (UTC)
* 現象   : 金曜18時台の平常値(14.14)に対し 10であった
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.17σ 外れた (平常値=14.14)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→11→…→11→6→8→9
* 開始   : 2026-06-13 03:10:00 (UTC)
* 終了   : 2026-06-13 03:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host15-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→8→…→10→11→13→9
* 開始   : 2026-06-13 19:25:00 (UTC)
* 終了   : 2026-06-13 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.97, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260613-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→9→11→12→…→11→12→10→7
* 開始   : 2026-06-14 00:40:00 (UTC)
* 終了   : 2026-06-14 00:45:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260614-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→10→15→14→10→15→14→13
* 開始   : 2026-06-14 06:50:00 (UTC)
* 終了   : 2026-06-14 06:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260614-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→16→16→16→17
* 開始   : 2026-06-14 09:05:00 (UTC)
* 終了   : 2026-06-14 09:25:00 (UTC)
* 現象   : 2026-06-14 09:25:00 (UTC)を境に水準が 11.87から12.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.486, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→18→14→19→18→14→19→15→14
* 開始   : 2026-06-14 10:20:00 (UTC)
* 終了   : 2026-06-14 10:30:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260614-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→19→16→19→16→19→16
* 開始   : 2026-06-14 11:20:00 (UTC)
* 終了   : 2026-06-14 11:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→15
* 開始   : 2026-06-14 16:30:00 (UTC)
* 終了   : 2026-06-14 16:40:00 (UTC)
* 現象   : 2026-06-14 16:40:00 (UTC)を境に水準が 11.87から14.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→13→…→13→9→13→12
* 開始   : 2026-06-14 17:50:00 (UTC)
* 終了   : 2026-06-14 18:00:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260614-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→7→5→9→…→9→11→8→7
* 開始   : 2026-06-15 00:00:00 (UTC)
* 終了   : 2026-06-15 00:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260615-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→13→12→13→14→13→15→14
* 開始   : 2026-06-16 04:20:00 (UTC)
* 終了   : 2026-06-16 05:00:00 (UTC)
* 現象   : 2026-06-16 05:00:00 (UTC)を境に水準が 14.92から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→18→16→18→16→18→17
* 開始   : 2026-06-16 06:35:00 (UTC)
* 終了   : 2026-06-16 06:45:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→19→17→16
* 開始   : 2026-06-16 06:40:00 (UTC)
* 終了   : 2026-06-16 06:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→19→22→25→19→22→21
* 開始   : 2026-06-16 12:55:00 (UTC)
* 終了   : 2026-06-16 13:00:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→14→15→17→15→14→15
* 開始   : 2026-06-16 17:05:00 (UTC)
* 終了   : 2026-06-16 17:10:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→15→12→13→15→12→13→14
* 開始   : 2026-06-16 18:20:00 (UTC)
* 終了   : 2026-06-16 18:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→11→10→…→11→10→13→11
* 開始   : 2026-06-16 19:15:00 (UTC)
* 終了   : 2026-06-16 19:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→11→8→11→10
* 開始   : 2026-06-16 21:05:00 (UTC)
* 終了   : 2026-06-16 21:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→14→10→11→13→14→10
* 開始   : 2026-06-17 03:50:00 (UTC)
* 終了   : 2026-06-17 03:55:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→17→15→17→16
* 開始   : 2026-06-17 06:00:00 (UTC)
* 終了   : 2026-06-17 06:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→18→14→17→17→20→19
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 07:10:00 (UTC)
* 現象   : 2026-06-17 07:10:00 (UTC)を境に水準が 14.94から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→14→17→15→…→15→18→15→16
* 開始   : 2026-06-17 06:20:00 (UTC)
* 終了   : 2026-06-17 06:30:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→23→20→23→21
* 開始   : 2026-06-17 10:00:00 (UTC)
* 終了   : 2026-06-17 10:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→25→24→23→22
* 開始   : 2026-06-17 11:25:00 (UTC)
* 終了   : 2026-06-17 12:05:00 (UTC)
* 現象   : 2026-06-17 12:05:00 (UTC)を境に水準が 14.94から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 23→22→23
* 開始   : 2026-06-17 14:40:00 (UTC)
* 終了   : 2026-06-17 14:50:00 (UTC)
* 現象   : 2026-06-17 14:50:00 (UTC)を境に水準が 15.01から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.203, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→12→…→13→12→14→13
* 開始   : 2026-06-17 18:10:00 (UTC)
* 終了   : 2026-06-17 18:15:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→13→…→13→18→15→14
* 開始   : 2026-06-17 18:25:00 (UTC)
* 終了   : 2026-06-17 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→9→10→11→9→13→11
* 開始   : 2026-06-17 19:45:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 7→8→11→8→…→8→5→6→10
* 開始   : 2026-06-17 22:50:00 (UTC)
* 終了   : 2026-06-17 23:50:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-084 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260617-host11-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-086 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-087 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→16→19→16→18
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:35:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→16→…→17→19→20→18
* 開始   : 2026-06-18 07:05:00 (UTC)
* 終了   : 2026-06-18 07:30:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→14→20→18→19→14→20→18→19
* 開始   : 2026-06-18 07:45:00 (UTC)
* 終了   : 2026-06-18 07:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→19→22→19→20
* 開始   : 2026-06-18 14:05:00 (UTC)
* 終了   : 2026-06-18 14:10:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→13→16→13→16→14
* 開始   : 2026-06-18 18:15:00 (UTC)
* 終了   : 2026-06-18 18:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→7→6→…→7→6→8→7
* 開始   : 2026-06-18 21:55:00 (UTC)
* 終了   : 2026-06-18 22:00:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 8→7→5→8→5→8→5→10→7
* 開始   : 2026-06-19 01:25:00 (UTC)
* 終了   : 2026-06-19 01:35:00 (UTC)
* 現象   : 金曜1時台の平常値(8.665)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.076σ 外れた (平常値=8.665)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→11→10→12
* 開始   : 2026-06-19 01:50:00 (UTC)
* 終了   : 2026-06-19 02:15:00 (UTC)
* 現象   : 2026-06-19 02:15:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.167, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→9→13→12→9→13→12
* 開始   : 2026-06-19 03:40:00 (UTC)
* 終了   : 2026-06-19 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→13→19→18→…→18→19→17→16
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 06:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→16→19→18→16→19→18→17
* 開始   : 2026-06-19 07:10:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260619-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→22→18→23→22→18→23→22→18
* 開始   : 2026-06-19 08:40:00 (UTC)
* 終了   : 2026-06-19 08:50:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→22→24→25→…→24→25→21→22
* 開始   : 2026-06-19 11:15:00 (UTC)
* 終了   : 2026-06-19 11:20:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→14→…→14→11→13→15
* 開始   : 2026-06-19 18:20:00 (UTC)
* 終了   : 2026-06-19 18:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→13→11→13→11→15→13
* 開始   : 2026-06-19 18:50:00 (UTC)
* 終了   : 2026-06-19 19:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→9→11→9
* 開始   : 2026-06-20 01:20:00 (UTC)
* 終了   : 2026-06-20 01:35:00 (UTC)
* 現象   : 2026-06-20 01:35:00 (UTC)を境に水準が 14.97から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→11→10→12→…→10→12→13→11
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 05:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.895, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分

![EVT-20260620-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→6→4→11→…→4→11→7→10
* 開始   : 2026-06-21 00:45:00 (UTC)
* 終了   : 2026-06-21 00:50:00 (UTC)
* 現象   : 平常時(7.833)に対し 0.5106(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→10→13→7→…→13→7→11→9
* 開始   : 2026-06-21 03:50:00 (UTC)
* 終了   : 2026-06-21 03:55:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260621-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→10→8→9→11→12→9→12→11
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 02:35:00 (UTC)
* 現象   : 2026-06-22 02:35:00 (UTC)を境に水準が 11.82から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.751, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 7→9→12→9→…→6→13→10→7
* 開始   : 2026-06-23 02:00:00 (UTC)
* 終了   : 2026-06-23 02:25:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-004 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260623-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→17→…→16→17→13→14
* 開始   : 2026-06-23 05:35:00 (UTC)
* 終了   : 2026-06-23 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→18→22→17→22→17→22→21→20
* 開始   : 2026-06-23 08:40:00 (UTC)
* 終了   : 2026-06-23 08:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→25→22→18→25→22→18→19→20
* 開始   : 2026-06-23 13:55:00 (UTC)
* 終了   : 2026-06-23 14:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.186倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 19→16→18→15→16→18→15→19
* 開始   : 2026-06-23 16:05:00 (UTC)
* 終了   : 2026-06-23 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→9→7→8→9→9→9→8→10
* 開始   : 2026-06-23 22:50:00 (UTC)
* 終了   : 2026-06-24 01:30:00 (UTC)
* 現象   : 2026-06-24 01:30:00 (UTC)を境に水準が 14.95から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.809, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 7→9→11→12→9→11→12→9→10
* 開始   : 2026-06-24 01:45:00 (UTC)
* 終了   : 2026-06-24 01:50:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→10→10→11→11→12→12
* 開始   : 2026-06-24 02:35:00 (UTC)
* 終了   : 2026-06-24 03:05:00 (UTC)
* 現象   : 2026-06-24 03:05:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.362, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→12→…→12→10→15→14
* 開始   : 2026-06-24 05:15:00 (UTC)
* 終了   : 2026-06-24 06:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260624-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→19→21→19→21→19
* 開始   : 2026-06-24 07:55:00 (UTC)
* 終了   : 2026-06-24 08:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→21→22→20→21→22→20→19
* 開始   : 2026-06-24 08:30:00 (UTC)
* 終了   : 2026-06-24 08:35:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 22→24→21→18→…→18→25→23→19
* 開始   : 2026-06-24 10:30:00 (UTC)
* 終了   : 2026-06-24 10:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→22→23→21→21→21
* 開始   : 2026-06-24 13:15:00 (UTC)
* 終了   : 2026-06-24 13:40:00 (UTC)
* 現象   : 2026-06-24 13:40:00 (UTC)を境に水準が 15.02から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→20→22→22→20→22→24→22→20
* 開始   : 2026-06-24 14:05:00 (UTC)
* 終了   : 2026-06-24 15:05:00 (UTC)
* 現象   : 2026-06-24 15:05:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→10→16→14→10→16→14→13
* 開始   : 2026-06-25 05:10:00 (UTC)
* 終了   : 2026-06-25 05:15:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→19→17→14→19→17→19
* 開始   : 2026-06-25 07:00:00 (UTC)
* 終了   : 2026-06-25 07:05:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→21→20→24→21
* 開始   : 2026-06-25 12:40:00 (UTC)
* 終了   : 2026-06-25 12:45:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→22→17→18→17→18→17→20→19
* 開始   : 2026-06-25 15:30:00 (UTC)
* 終了   : 2026-06-25 15:40:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→12→16→12→16→12→13
* 開始   : 2026-06-25 18:10:00 (UTC)
* 終了   : 2026-06-25 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→17→12→11→…→12→11→13→12
* 開始   : 2026-06-25 18:55:00 (UTC)
* 終了   : 2026-06-25 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→10→9→11→10→9→11→13
* 開始   : 2026-06-25 20:20:00 (UTC)
* 終了   : 2026-06-25 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→11→12→11→8→11→12→11→9
* 開始   : 2026-06-26 02:30:00 (UTC)
* 終了   : 2026-06-26 02:35:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→15→15→15
* 開始   : 2026-06-26 05:15:00 (UTC)
* 終了   : 2026-06-26 05:30:00 (UTC)
* 現象   : 2026-06-26 05:30:00 (UTC)を境に水準が 14.95から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→21→18→20→18→20→18→23→20
* 開始   : 2026-06-26 14:00:00 (UTC)
* 終了   : 2026-06-26 14:10:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.8308(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→19→15→17→…→19→13→15→17
* 開始   : 2026-06-26 17:10:00 (UTC)
* 終了   : 2026-06-26 17:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→13→11→13→11→13→15
* 開始   : 2026-06-26 18:35:00 (UTC)
* 終了   : 2026-06-26 19:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→12→11→17→12→11→17→12→13
* 開始   : 2026-06-26 19:05:00 (UTC)
* 終了   : 2026-06-26 19:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→7→5→7→5→9→7
* 開始   : 2026-06-27 00:40:00 (UTC)
* 終了   : 2026-06-27 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260627-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→9→5→11→9→5→11→9
* 開始   : 2026-06-27 02:15:00 (UTC)
* 終了   : 2026-06-27 02:20:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→11→8→12→14→8→12→14→13
* 開始   : 2026-06-28 05:45:00 (UTC)
* 終了   : 2026-06-28 05:55:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→13→15→11→13→15→11
* 開始   : 2026-06-28 06:40:00 (UTC)
* 終了   : 2026-06-28 06:45:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→12→…→12→18→12→15
* 開始   : 2026-06-28 08:40:00 (UTC)
* 終了   : 2026-06-28 08:50:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→15→12→11→15→12→11→15→14
* 開始   : 2026-06-28 15:15:00 (UTC)
* 終了   : 2026-06-28 15:20:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→10→9→9→11→11→11
* 開始   : 2026-06-28 19:25:00 (UTC)
* 終了   : 2026-06-28 20:15:00 (UTC)
* 現象   : 2026-06-28 20:15:00 (UTC)を境に水準が 11.69から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.603, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→11→7→9→11→7→9→8
* 開始   : 2026-06-28 20:00:00 (UTC)
* 終了   : 2026-06-28 20:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260628-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→8→7→11→9→11→9→7→9
* 開始   : 2026-06-29 00:10:00 (UTC)
* 終了   : 2026-06-29 01:40:00 (UTC)
* 現象   : 2026-06-29 01:40:00 (UTC)を境に水準が 11.78から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→11→11
* 開始   : 2026-06-29 20:25:00 (UTC)
* 終了   : 2026-06-29 21:40:00 (UTC)
* 現象   : 2026-06-29 21:40:00 (UTC)を境に水準が 14.73から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→16→12→15→16→12→11
* 開始   : 2026-06-30 04:55:00 (UTC)
* 終了   : 2026-06-30 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→20→22→19→22→19→22→21
* 開始   : 2026-06-30 08:40:00 (UTC)
* 終了   : 2026-06-30 08:50:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→13→15→13→15→13→15→14
* 開始   : 2026-06-30 18:00:00 (UTC)
* 終了   : 2026-06-30 18:10:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→11→…→12→11→14→13
* 開始   : 2026-06-30 18:30:00 (UTC)
* 終了   : 2026-06-30 18:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→8→11→8→11→8→10
* 開始   : 2026-06-30 20:35:00 (UTC)
* 終了   : 2026-06-30 20:45:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host15-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→11→11→11→11→10→11→10→10
* 開始   : 2026-06-30 21:00:00 (UTC)
* 終了   : 2026-06-30 21:50:00 (UTC)
* 現象   : 2026-06-30 21:50:00 (UTC)を境に水準が 14.82から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host15-012 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
