# host09 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host09 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 281 (SEVERE: 19, FATAL: 115, WARN: 147, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 115 | 147 | 281 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→18→…→15→12→11→10
* 開始   : 2026-07-06 02:30:00 (UTC)
* 終了   : 2026-07-06 22:00:00 (UTC)
* 現象   : 2026-07-06 22:00:00 (UTC)を境に水準が 11.91から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.926, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-001 active_connections の推移](charts/EVT-20260706-host09-001.svg)

# イベントID( EVT-20260706-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→19→…→17→13→15→16
* 開始   : 2026-07-06 03:25:00 (UTC)
* 終了   : 2026-07-06 20:25:00 (UTC)
* 現象   : 2026-07-06 20:25:00 (UTC)を境に水準が 11.88から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.697, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-003 active_connections の推移](charts/EVT-20260706-host09-003.svg)

# イベントID( EVT-20260706-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→…→13→14→12→13
* 開始   : 2026-07-06 03:50:00 (UTC)
* 終了   : 2026-07-06 21:15:00 (UTC)
* 現象   : 2026-07-06 21:15:00 (UTC)を境に水準が 11.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.166, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-005 active_connections の推移](charts/EVT-20260706-host09-005.svg)

# イベントID( EVT-20260706-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→16→…→11→13→11→12
* 開始   : 2026-07-06 03:55:00 (UTC)
* 終了   : 2026-07-06 19:25:00 (UTC)
* 現象   : 2026-07-06 19:25:00 (UTC)を境に水準が 11.95から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.768, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-006 active_connections の推移](charts/EVT-20260706-host09-006.svg)

# イベントID( EVT-20260706-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→14→…→11→13→12→11
* 開始   : 2026-07-06 04:45:00 (UTC)
* 終了   : 2026-07-06 20:25:00 (UTC)
* 現象   : 2026-07-06 20:25:00 (UTC)を境に水準が 12.03から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.674, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.488, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-007 active_connections の推移](charts/EVT-20260706-host09-007.svg)

# イベントID( EVT-20260713-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→15→…→16→14→16→15
* 開始   : 2026-07-13 01:25:00 (UTC)
* 終了   : 2026-07-13 19:55:00 (UTC)
* 現象   : 2026-07-13 19:55:00 (UTC)を境に水準が 11.81から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.785, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-001 active_connections の推移](charts/EVT-20260713-host09-001.svg)

# イベントID( EVT-20260713-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→17→…→15→13→10→14
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 19:30:00 (UTC)
* 現象   : 2026-07-13 19:30:00 (UTC)を境に水準が 11.87から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.926, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-003 active_connections の推移](charts/EVT-20260713-host09-003.svg)

# イベントID( EVT-20260713-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→14→…→14→12→14→12
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 20:10:00 (UTC)
* 現象   : 2026-07-13 20:10:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.191, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-004 active_connections の推移](charts/EVT-20260713-host09-004.svg)

# イベントID( EVT-20260713-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→14→17→14→…→15→14→11→13
* 開始   : 2026-07-13 03:15:00 (UTC)
* 終了   : 2026-07-13 20:00:00 (UTC)
* 現象   : 2026-07-13 20:00:00 (UTC)を境に水準が 11.96から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-005 active_connections の推移](charts/EVT-20260713-host09-005.svg)

# イベントID( EVT-20260713-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→14→18→15→…→16→14→13→12
* 開始   : 2026-07-13 03:20:00 (UTC)
* 終了   : 2026-07-13 22:15:00 (UTC)
* 現象   : 2026-07-13 22:15:00 (UTC)を境に水準が 11.85から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.02, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-006 active_connections の推移](charts/EVT-20260713-host09-006.svg)

# イベントID( EVT-20260720-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→17→16→17→…→15→13→12→13
* 開始   : 2026-07-20 03:35:00 (UTC)
* 終了   : 2026-07-20 20:55:00 (UTC)
* 現象   : 2026-07-20 20:55:00 (UTC)を境に水準が 11.81から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.912, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.252, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-004 active_connections の推移](charts/EVT-20260720-host09-004.svg)

# イベントID( EVT-20260720-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→13→16→14→…→11→13→12→11
* 開始   : 2026-07-20 04:00:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 2026-07-20 20:40:00 (UTC)を境に水準が 11.93から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.739, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-005 active_connections の推移](charts/EVT-20260720-host09-005.svg)

# イベントID( EVT-20260720-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→15→18→…→15→13→12→13
* 開始   : 2026-07-20 04:05:00 (UTC)
* 終了   : 2026-07-20 21:15:00 (UTC)
* 現象   : 2026-07-20 21:15:00 (UTC)を境に水準が 11.76から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.062, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-006 active_connections の推移](charts/EVT-20260720-host09-006.svg)

# イベントID( EVT-20260727-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→16→…→14→15→12→13
* 開始   : 2026-07-27 01:50:00 (UTC)
* 終了   : 2026-07-27 19:20:00 (UTC)
* 現象   : 2026-07-27 19:20:00 (UTC)を境に水準が 11.9から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.435σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.044, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-001 active_connections の推移](charts/EVT-20260727-host09-001.svg)

# イベントID( EVT-20260727-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→15→…→15→16→14→15
* 開始   : 2026-07-27 02:25:00 (UTC)
* 終了   : 2026-07-27 20:05:00 (UTC)
* 現象   : 2026-07-27 20:05:00 (UTC)を境に水準が 11.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.131, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.336, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-002 active_connections の推移](charts/EVT-20260727-host09-002.svg)

# イベントID( EVT-20260727-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→18→…→15→13→14→13
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 20:40:00 (UTC)
* 現象   : 2026-07-27 20:40:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.687σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.725, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-003 active_connections の推移](charts/EVT-20260727-host09-003.svg)

# イベントID( EVT-20260727-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→15→…→15→16→10→14
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 22:10:00 (UTC)
* 現象   : 2026-07-27 22:10:00 (UTC)を境に水準が 11.76から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.743, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-004 active_connections の推移](charts/EVT-20260727-host09-004.svg)

# イベントID( EVT-20260727-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→15→14→15→…→12→11→12→11
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.361σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.976, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-005 active_connections の推移](charts/EVT-20260727-host09-005.svg)

# イベントID( EVT-20260727-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→16→…→14→15→10→15
* 開始   : 2026-07-27 04:40:00 (UTC)
* 終了   : 2026-07-27 20:20:00 (UTC)
* 現象   : 2026-07-27 20:20:00 (UTC)を境に水準が 12.11から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.664σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.919, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host09-006 active_connections の推移](charts/EVT-20260727-host09-006.svg)

# イベントID( EVT-20260701-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→16→18→19→16→17
* 開始   : 2026-07-01 06:30:00 (UTC)
* 終了   : 2026-07-01 06:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 22→21→25
* 開始   : 2026-07-01 09:10:00 (UTC)
* 終了   : 2026-07-01 09:20:00 (UTC)
* 現象   : 2026-07-01 09:20:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.605σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→21→20
* 開始   : 2026-07-01 10:10:00 (UTC)
* 終了   : 2026-07-01 10:10:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→20→16→22→19
* 開始   : 2026-07-01 14:50:00 (UTC)
* 終了   : 2026-07-01 14:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host09-011 active_connections の推移](charts/EVT-20260701-host09-011.svg)

# イベントID( EVT-20260701-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→11→10→11→…→11→8→13→11
* 開始   : 2026-07-01 19:50:00 (UTC)
* 終了   : 2026-07-01 20:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→8→6→9→3→6→9→3→10
* 開始   : 2026-07-01 22:35:00 (UTC)
* 終了   : 2026-07-01 22:45:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host09-015 active_connections の推移](charts/EVT-20260701-host09-015.svg)

# イベントID( EVT-20260702-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→5→13→8→8
* 開始   : 2026-07-02 01:40:00 (UTC)
* 終了   : 2026-07-02 01:40:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.753倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host09-001 active_connections の推移](charts/EVT-20260702-host09-001.svg)

# イベントID( EVT-20260702-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→14→18→14→15
* 開始   : 2026-07-02 05:55:00 (UTC)
* 終了   : 2026-07-02 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 22→20→21→21→21
* 開始   : 2026-07-02 15:20:00 (UTC)
* 終了   : 2026-07-02 16:15:00 (UTC)
* 現象   : 2026-07-02 16:15:00 (UTC)を境に水準が 14.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.834, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→13→14
* 開始   : 2026-07-02 18:45:00 (UTC)
* 終了   : 2026-07-02 18:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.6667(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host09-012 active_connections の推移](charts/EVT-20260702-host09-012.svg)

# イベントID( EVT-20260703-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→17→21→18→20→21→18→20→17
* 開始   : 2026-07-03 07:30:00 (UTC)
* 終了   : 2026-07-03 07:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→17→…→19→17→19→17
* 開始   : 2026-07-03 15:30:00 (UTC)
* 終了   : 2026-07-03 15:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260703-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→17→13→17→18
* 開始   : 2026-07-03 17:00:00 (UTC)
* 終了   : 2026-07-03 17:00:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.7156(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host09-007 active_connections の推移](charts/EVT-20260703-host09-007.svg)

# イベントID( EVT-20260703-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→10→6→9→9
* 開始   : 2026-07-03 21:40:00 (UTC)
* 終了   : 2026-07-03 21:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→11→…→13→12→13→10
* 開始   : 2026-07-04 05:20:00 (UTC)
* 終了   : 2026-07-04 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260704-host09-001 active_connections の推移](charts/EVT-20260704-host09-001.svg)

# イベントID( EVT-20260704-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→14→…→13→12→11→13
* 開始   : 2026-07-04 05:30:00 (UTC)
* 終了   : 2026-07-04 18:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.839, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260704-host09-002 active_connections の推移](charts/EVT-20260704-host09-002.svg)

# イベントID( EVT-20260704-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→13→…→10→9→12→11
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:35:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host09-003 active_connections の推移](charts/EVT-20260704-host09-003.svg)

# イベントID( EVT-20260704-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→12→11→13→…→13→11→14→13
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.184, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host09-004 active_connections の推移](charts/EVT-20260704-host09-004.svg)

# イベントID( EVT-20260704-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→13→…→14→12→15→14
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 20:50:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.78, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260704-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host09-005 active_connections の推移](charts/EVT-20260704-host09-005.svg)

# イベントID( EVT-20260704-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→13→12→13→12
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 18:50:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.939, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260704-host09-006 active_connections の推移](charts/EVT-20260704-host09-006.svg)

# イベントID( EVT-20260705-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→13→15
* 開始   : 2026-07-05 16:30:00 (UTC)
* 終了   : 2026-07-05 16:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→15→…→12→11→13→15
* 開始   : 2026-07-06 03:25:00 (UTC)
* 終了   : 2026-07-06 21:05:00 (UTC)
* 現象   : 2026-07-06 21:05:00 (UTC)を境に水準が 11.76から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.772, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.588, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→20→16→21→20→18
* 開始   : 2026-07-07 07:55:00 (UTC)
* 終了   : 2026-07-07 08:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→12→18→15
* 開始   : 2026-07-07 18:00:00 (UTC)
* 終了   : 2026-07-07 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→19→24→23→…→24→23→22→23
* 開始   : 2026-07-08 08:40:00 (UTC)
* 終了   : 2026-07-08 09:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260708-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→19→13→16→16
* 開始   : 2026-07-08 17:05:00 (UTC)
* 終了   : 2026-07-08 17:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→17→20→16→16
* 開始   : 2026-07-09 06:45:00 (UTC)
* 終了   : 2026-07-09 06:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→16→21→19→19
* 開始   : 2026-07-09 08:05:00 (UTC)
* 終了   : 2026-07-09 08:05:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→18→23→20→20
* 開始   : 2026-07-09 08:50:00 (UTC)
* 終了   : 2026-07-09 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 24→23→23→23→22→21→21→23→23
* 開始   : 2026-07-09 12:15:00 (UTC)
* 終了   : 2026-07-09 13:50:00 (UTC)
* 現象   : 2026-07-09 13:50:00 (UTC)を境に水準が 14.88から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 21→19→17→21→…→21→18→19→20
* 開始   : 2026-07-09 15:00:00 (UTC)
* 終了   : 2026-07-09 15:10:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260709-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→18→18
* 開始   : 2026-07-09 16:30:00 (UTC)
* 終了   : 2026-07-09 16:30:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→18→14→17→15
* 開始   : 2026-07-09 16:55:00 (UTC)
* 終了   : 2026-07-09 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→21→16→21→19
* 開始   : 2026-07-10 14:40:00 (UTC)
* 終了   : 2026-07-10 14:40:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host09-007 active_connections の推移](charts/EVT-20260710-host09-007.svg)

# イベントID( EVT-20260711-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→13→…→8→9→13→12
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.737, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260711-host09-001 active_connections の推移](charts/EVT-20260711-host09-001.svg)

# イベントID( EVT-20260711-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 9→12→10→12→…→13→12→13→12
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.262, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260711-host09-002 active_connections の推移](charts/EVT-20260711-host09-002.svg)

# イベントID( EVT-20260711-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→13→…→12→14→12→13
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 18:00:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.871, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260711-host09-003 active_connections の推移](charts/EVT-20260711-host09-003.svg)

# イベントID( EVT-20260711-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→10→…→12→10→11→12
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.945, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host09-004 active_connections の推移](charts/EVT-20260711-host09-004.svg)

# イベントID( EVT-20260711-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→12→…→13→11→12→13
* 開始   : 2026-07-11 05:50:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.923, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host09-005 active_connections の推移](charts/EVT-20260711-host09-005.svg)

# イベントID( EVT-20260711-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→12→11→12→…→10→9→13→11
* 開始   : 2026-07-11 06:20:00 (UTC)
* 終了   : 2026-07-11 18:40:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260711-host09-006 active_connections の推移](charts/EVT-20260711-host09-006.svg)

# イベントID( EVT-20260712-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→9→13→9→8
* 開始   : 2026-07-12 22:00:00 (UTC)
* 終了   : 2026-07-12 22:00:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260712-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→12→…→15→11→12→13
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 18:45:00 (UTC)
* 現象   : 2026-07-13 18:45:00 (UTC)を境に水準が 11.91から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.903, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.975, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host09-002 active_connections の推移](charts/EVT-20260713-host09-002.svg)

# イベントID( EVT-20260714-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→15→10→11→14→14→13→13
* 開始   : 2026-07-14 03:55:00 (UTC)
* 終了   : 2026-07-14 04:40:00 (UTC)
* 現象   : 2026-07-14 04:40:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→20→22→18→…→18→21→18→19
* 開始   : 2026-07-14 08:25:00 (UTC)
* 終了   : 2026-07-14 08:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→18→15→18→18
* 開始   : 2026-07-14 16:10:00 (UTC)
* 終了   : 2026-07-14 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→18→11→15→14
* 開始   : 2026-07-14 18:00:00 (UTC)
* 終了   : 2026-07-14 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.6769(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host09-007 active_connections の推移](charts/EVT-20260714-host09-007.svg)

# イベントID( EVT-20260714-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→10→6→11→10
* 開始   : 2026-07-14 21:05:00 (UTC)
* 終了   : 2026-07-14 21:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host09-011 active_connections の推移](charts/EVT-20260714-host09-011.svg)

# イベントID( EVT-20260714-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→6→…→7→6→12→10
* 開始   : 2026-07-14 21:10:00 (UTC)
* 終了   : 2026-07-14 21:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host09-012 active_connections の推移](charts/EVT-20260714-host09-012.svg)

# イベントID( EVT-20260715-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 7→7→14→7→7
* 開始   : 2026-07-15 01:05:00 (UTC)
* 終了   : 2026-07-15 01:05:00 (UTC)
* 現象   : 平常時(8)に対し 1.75倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host09-002 active_connections の推移](charts/EVT-20260715-host09-002.svg)

# イベントID( EVT-20260715-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→10→14→16→…→14→16→14→12
* 開始   : 2026-07-15 04:30:00 (UTC)
* 終了   : 2026-07-15 04:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→13→10→15→15
* 開始   : 2026-07-15 18:45:00 (UTC)
* 終了   : 2026-07-15 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host09-007 active_connections の推移](charts/EVT-20260715-host09-007.svg)

# イベントID( EVT-20260715-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→11→16→11→10
* 開始   : 2026-07-15 20:25:00 (UTC)
* 終了   : 2026-07-15 20:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.314σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host06-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→12→15→11→12
* 開始   : 2026-07-16 04:05:00 (UTC)
* 終了   : 2026-07-16 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→14→17→14→13
* 開始   : 2026-07-16 05:15:00 (UTC)
* 終了   : 2026-07-16 05:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260716-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→13→15
* 開始   : 2026-07-16 05:25:00 (UTC)
* 終了   : 2026-07-16 05:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→16→21→18→18
* 開始   : 2026-07-16 07:20:00 (UTC)
* 終了   : 2026-07-16 07:20:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 20→21→26→22→21
* 開始   : 2026-07-16 10:45:00 (UTC)
* 終了   : 2026-07-16 10:45:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→15→13
* 開始   : 2026-07-16 18:35:00 (UTC)
* 終了   : 2026-07-16 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→14→9→12→15
* 開始   : 2026-07-16 18:45:00 (UTC)
* 終了   : 2026-07-16 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.5902(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host09-009 active_connections の推移](charts/EVT-20260716-host09-009.svg)

# イベントID( EVT-20260717-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→19→18→…→19→18→17→16
* 開始   : 2026-07-17 06:40:00 (UTC)
* 終了   : 2026-07-17 06:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→20→24→20→20
* 開始   : 2026-07-17 09:00:00 (UTC)
* 終了   : 2026-07-17 09:00:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→20→18→22→20
* 開始   : 2026-07-17 11:00:00 (UTC)
* 終了   : 2026-07-17 11:00:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260717-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 23→20→25→21→26→25→21→26→21
* 開始   : 2026-07-17 12:40:00 (UTC)
* 終了   : 2026-07-17 12:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→15→18→18
* 開始   : 2026-07-17 16:15:00 (UTC)
* 終了   : 2026-07-17 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→18→13→18→16
* 開始   : 2026-07-17 17:15:00 (UTC)
* 終了   : 2026-07-17 17:15:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→15→8→12→10
* 開始   : 2026-07-17 19:45:00 (UTC)
* 終了   : 2026-07-17 19:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.589(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.909σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host09-012 active_connections の推移](charts/EVT-20260717-host09-012.svg)

# イベントID( EVT-20260717-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→7→5→7→11
* 開始   : 2026-07-17 22:25:00 (UTC)
* 終了   : 2026-07-17 22:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-091 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→12→…→12→11→13→12
* 開始   : 2026-07-18 04:50:00 (UTC)
* 終了   : 2026-07-18 18:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260718-host09-002 active_connections の推移](charts/EVT-20260718-host09-002.svg)

# イベントID( EVT-20260718-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→14→11→12→…→13→10→12→14
* 開始   : 2026-07-18 05:10:00 (UTC)
* 終了   : 2026-07-18 18:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.099, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host09-003 active_connections の推移](charts/EVT-20260718-host09-003.svg)

# イベントID( EVT-20260718-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→11→12→14→13
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.107, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260718-host09-004 active_connections の推移](charts/EVT-20260718-host09-004.svg)

# イベントID( EVT-20260718-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→13→…→13→12→13→12
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 18:30:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.99, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260718-host09-005 active_connections の推移](charts/EVT-20260718-host09-005.svg)

# イベントID( EVT-20260718-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→13→10→12→…→12→10→11→13
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 18:35:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260718-host09-006 active_connections の推移](charts/EVT-20260718-host09-006.svg)

# イベントID( EVT-20260718-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→13→12→14→…→9→10→9→13
* 開始   : 2026-07-18 06:25:00 (UTC)
* 終了   : 2026-07-18 19:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.173, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host09-007 active_connections の推移](charts/EVT-20260718-host09-007.svg)

# イベントID( EVT-20260718-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→10→5→11→11
* 開始   : 2026-07-18 20:15:00 (UTC)
* 終了   : 2026-07-18 20:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.48(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.791σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260718-host09-008 active_connections の推移](charts/EVT-20260718-host09-008.svg)

# イベントID( EVT-20260719-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 6→10→4→8→9
* 開始   : 2026-07-19 01:00:00 (UTC)
* 終了   : 2026-07-19 01:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→13→7→9
* 開始   : 2026-07-19 03:10:00 (UTC)
* 終了   : 2026-07-19 03:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→…→14→16→14→13
* 開始   : 2026-07-20 01:10:00 (UTC)
* 終了   : 2026-07-20 20:10:00 (UTC)
* 現象   : 2026-07-20 20:10:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.874, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→13→15→17→…→14→10→14→12
* 開始   : 2026-07-20 01:50:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.877, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.117, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-002 active_connections の推移](charts/EVT-20260720-host09-002.svg)

# イベントID( EVT-20260720-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→15→…→16→14→15→14
* 開始   : 2026-07-20 02:30:00 (UTC)
* 終了   : 2026-07-20 20:00:00 (UTC)
* 現象   : 2026-07-20 20:00:00 (UTC)を境に水準が 11.96から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.194, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.271, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 6→8→12→9→7
* 開始   : 2026-07-21 00:30:00 (UTC)
* 終了   : 2026-07-21 00:30:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→20→25→21→20
* 開始   : 2026-07-21 09:35:00 (UTC)
* 終了   : 2026-07-21 09:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→17→12→14→16
* 開始   : 2026-07-21 17:40:00 (UTC)
* 終了   : 2026-07-21 17:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→14→11→16→18
* 開始   : 2026-07-21 18:00:00 (UTC)
* 終了   : 2026-07-21 18:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→14
* 開始   : 2026-07-21 18:55:00 (UTC)
* 終了   : 2026-07-21 18:55:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→13→13→10→11→9→9→11→11
* 開始   : 2026-07-21 20:30:00 (UTC)
* 終了   : 2026-07-21 21:45:00 (UTC)
* 現象   : 2026-07-21 21:45:00 (UTC)を境に水準が 14.84から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→10→6→9→10
* 開始   : 2026-07-21 21:10:00 (UTC)
* 終了   : 2026-07-21 21:10:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→7→6→9→…→9→4→10→9
* 開始   : 2026-07-21 22:15:00 (UTC)
* 終了   : 2026-07-21 22:25:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→10→4→7→9
* 開始   : 2026-07-21 23:20:00 (UTC)
* 終了   : 2026-07-21 23:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host09-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→10→4→6→8
* 開始   : 2026-07-22 01:40:00 (UTC)
* 終了   : 2026-07-22 01:40:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→15→17→15→17→15→16→15
* 開始   : 2026-07-22 15:35:00 (UTC)
* 終了   : 2026-07-22 16:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.7407(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.651σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260722-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host09-006 active_connections の推移](charts/EVT-20260722-host09-006.svg)

# イベントID( EVT-20260722-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→15→…→15→11→12→14
* 開始   : 2026-07-22 18:20:00 (UTC)
* 終了   : 2026-07-22 19:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260722-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分

![EVT-20260722-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→15→11→13→12
* 開始   : 2026-07-22 18:40:00 (UTC)
* 終了   : 2026-07-22 18:40:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→8→4→8→8
* 開始   : 2026-07-23 00:15:00 (UTC)
* 終了   : 2026-07-23 00:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→18→21→18→21→18
* 開始   : 2026-07-23 07:40:00 (UTC)
* 終了   : 2026-07-23 07:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260723-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→11→8→13→11
* 開始   : 2026-07-23 20:00:00 (UTC)
* 終了   : 2026-07-23 20:00:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→15→13→9→15→13→9→12→10
* 開始   : 2026-07-23 20:25:00 (UTC)
* 終了   : 2026-07-23 21:05:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260723-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-072 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-073 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260723-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→10→7
* 開始   : 2026-07-25 01:05:00 (UTC)
* 終了   : 2026-07-25 01:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→13→…→15→13→14→13
* 開始   : 2026-07-25 04:15:00 (UTC)
* 終了   : 2026-07-25 17:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.973, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260725-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 13.4 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host09-002 active_connections の推移](charts/EVT-20260725-host09-002.svg)

# イベントID( EVT-20260725-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→8→10→9→11
* 開始   : 2026-07-25 05:05:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260725-host09-003 active_connections の推移](charts/EVT-20260725-host09-003.svg)

# イベントID( EVT-20260725-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→10→…→11→9→12→11
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host09-004 active_connections の推移](charts/EVT-20260725-host09-004.svg)

# イベントID( EVT-20260725-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→12→11→12→10
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host09-005 active_connections の推移](charts/EVT-20260725-host09-005.svg)

# イベントID( EVT-20260725-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→11→…→11→13→14→12
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:20:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260725-host09-006 active_connections の推移](charts/EVT-20260725-host09-006.svg)

# イベントID( EVT-20260725-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→12→13→12→…→11→12→10→12
* 開始   : 2026-07-25 05:55:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.753, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host09-007 active_connections の推移](charts/EVT-20260725-host09-007.svg)

# イベントID( EVT-20260726-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 7→8→13→9→11
* 開始   : 2026-07-26 02:20:00 (UTC)
* 終了   : 2026-07-26 02:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→9→11
* 開始   : 2026-07-26 19:30:00 (UTC)
* 終了   : 2026-07-26 19:30:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→16
* 開始   : 2026-07-29 06:30:00 (UTC)
* 終了   : 2026-07-29 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→18→22→20→20
* 開始   : 2026-07-29 07:50:00 (UTC)
* 終了   : 2026-07-29 07:50:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.256σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→16→12→15→15
* 開始   : 2026-07-29 17:35:00 (UTC)
* 終了   : 2026-07-29 17:35:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host09-008 active_connections の推移](charts/EVT-20260729-host09-008.svg)

# イベントID( EVT-20260730-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→11→…→17→16→13→15
* 開始   : 2026-07-30 04:15:00 (UTC)
* 終了   : 2026-07-30 05:30:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260730-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→15→20→14→17
* 開始   : 2026-07-31 06:25:00 (UTC)
* 終了   : 2026-07-31 06:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host09-001 active_connections の推移](charts/EVT-20260731-host09-001.svg)

# イベントID( EVT-20260731-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→18→23→20→20
* 開始   : 2026-07-31 08:40:00 (UTC)
* 終了   : 2026-07-31 08:40:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→13→19→13→…→19→15→11→13
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 18:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260731-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→13→10→14→14
* 開始   : 2026-07-31 18:55:00 (UTC)
* 終了   : 2026-07-31 18:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→8→9→13→14→8→9→13
* 開始   : 2026-07-31 20:05:00 (UTC)
* 終了   : 2026-07-31 20:50:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-host02-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host15-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→13→8→11→11
* 開始   : 2026-07-31 20:15:00 (UTC)
* 終了   : 2026-07-31 20:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 8→11→6→13→…→6→13→12→9
* 開始   : 2026-07-01 02:45:00 (UTC)
* 終了   : 2026-07-01 02:50:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→12→14→10→14→10→14→10
* 開始   : 2026-07-01 03:50:00 (UTC)
* 終了   : 2026-07-01 04:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→18→14→15→18→14→18
* 開始   : 2026-07-01 06:20:00 (UTC)
* 終了   : 2026-07-01 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→19→22→21→19→22→21→20
* 開始   : 2026-07-01 08:40:00 (UTC)
* 終了   : 2026-07-01 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→20→24→25→…→24→25→21→22
* 開始   : 2026-07-01 11:25:00 (UTC)
* 終了   : 2026-07-01 11:30:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 23→24→24→23
* 開始   : 2026-07-01 12:15:00 (UTC)
* 終了   : 2026-07-01 12:30:00 (UTC)
* 現象   : 2026-07-01 12:30:00 (UTC)を境に水準が 14.97から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.221, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→24→21→23→21→21→23
* 開始   : 2026-07-01 13:30:00 (UTC)
* 終了   : 2026-07-01 14:40:00 (UTC)
* 現象   : 2026-07-01 14:40:00 (UTC)を境に水準が 15.09から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→18→16→19→16→19→16
* 開始   : 2026-07-01 16:35:00 (UTC)
* 終了   : 2026-07-01 16:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→14→16→18→14→16
* 開始   : 2026-07-01 17:25:00 (UTC)
* 終了   : 2026-07-01 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→13→12→14→13→12
* 開始   : 2026-07-02 04:15:00 (UTC)
* 終了   : 2026-07-02 04:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→11→14→11→14→13
* 開始   : 2026-07-02 04:25:00 (UTC)
* 終了   : 2026-07-02 04:35:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→14→11→14→11→14→13
* 開始   : 2026-07-02 04:25:00 (UTC)
* 終了   : 2026-07-02 04:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→16→18→16→18→15→18
* 開始   : 2026-07-02 06:30:00 (UTC)
* 終了   : 2026-07-02 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→17→19→17→18
* 開始   : 2026-07-02 07:15:00 (UTC)
* 終了   : 2026-07-02 07:20:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→23→20→22→22→24→23
* 開始   : 2026-07-02 09:50:00 (UTC)
* 終了   : 2026-07-02 10:20:00 (UTC)
* 現象   : 2026-07-02 10:20:00 (UTC)を境に水準が 14.97から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→15→…→15→13→16→17
* 開始   : 2026-07-02 17:30:00 (UTC)
* 終了   : 2026-07-02 17:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260702-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→13→12→13→12→15→13
* 開始   : 2026-07-02 18:25:00 (UTC)
* 終了   : 2026-07-02 18:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→10→10→10→9
* 開始   : 2026-07-03 00:00:00 (UTC)
* 終了   : 2026-07-03 00:30:00 (UTC)
* 現象   : 2026-07-03 00:30:00 (UTC)を境に水準が 14.94から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.386, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→10→10→10→10→10→8→9→11
* 開始   : 2026-07-03 01:50:00 (UTC)
* 終了   : 2026-07-03 03:00:00 (UTC)
* 現象   : 2026-07-03 03:00:00 (UTC)を境に水準が 14.96から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.65, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→12→9→11→…→11→15→12→13
* 開始   : 2026-07-03 04:45:00 (UTC)
* 終了   : 2026-07-03 04:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→18→17→18→17→18
* 開始   : 2026-07-03 06:15:00 (UTC)
* 終了   : 2026-07-03 06:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→14→12→16→…→12→15→12→14
* 開始   : 2026-07-03 18:00:00 (UTC)
* 終了   : 2026-07-03 18:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260703-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→11→8→9→8→9→8→11
* 開始   : 2026-07-03 20:55:00 (UTC)
* 終了   : 2026-07-03 21:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-080 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→7→11→7→11→7→10
* 開始   : 2026-07-03 21:35:00 (UTC)
* 終了   : 2026-07-03 21:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260703-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→10→13→9→10→13→9
* 開始   : 2026-07-05 04:50:00 (UTC)
* 終了   : 2026-07-05 04:55:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→13→14→10→13→11
* 開始   : 2026-07-05 17:15:00 (UTC)
* 終了   : 2026-07-05 17:20:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→10→9
* 開始   : 2026-07-05 18:15:00 (UTC)
* 終了   : 2026-07-05 18:20:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260705-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→10→13→11→10→11→9
* 開始   : 2026-07-06 02:50:00 (UTC)
* 終了   : 2026-07-06 03:30:00 (UTC)
* 現象   : 2026-07-06 03:30:00 (UTC)を境に水準が 11.91から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.424, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→12→17→14→17→14→17→15→17
* 開始   : 2026-07-07 06:05:00 (UTC)
* 終了   : 2026-07-07 06:15:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→18→23→20→24→18→23
* 開始   : 2026-07-07 10:35:00 (UTC)
* 終了   : 2026-07-07 10:40:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→25→22
* 開始   : 2026-07-07 10:50:00 (UTC)
* 終了   : 2026-07-07 11:00:00 (UTC)
* 現象   : 2026-07-07 11:00:00 (UTC)を境に水準が 14.92から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.126, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→15→19→16→15→19→18
* 開始   : 2026-07-07 16:25:00 (UTC)
* 終了   : 2026-07-07 16:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→10→13→14→11→10→13
* 開始   : 2026-07-07 19:35:00 (UTC)
* 終了   : 2026-07-07 19:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→12→8→12→8→10
* 開始   : 2026-07-07 20:45:00 (UTC)
* 終了   : 2026-07-07 20:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→8→10→10
* 開始   : 2026-07-07 23:15:00 (UTC)
* 終了   : 2026-07-07 23:40:00 (UTC)
* 現象   : 2026-07-07 23:40:00 (UTC)を境に水準が 14.9から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.331, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→10→10→11→10
* 開始   : 2026-07-08 01:50:00 (UTC)
* 終了   : 2026-07-08 02:20:00 (UTC)
* 現象   : 2026-07-08 02:20:00 (UTC)を境に水準が 14.97から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.436, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→21→22→18→19→21→22→18→20
* 開始   : 2026-07-08 08:30:00 (UTC)
* 終了   : 2026-07-08 08:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→18→17→21→18→17→21→20
* 開始   : 2026-07-08 14:40:00 (UTC)
* 終了   : 2026-07-08 14:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→20→17→16→…→17→16→18→19
* 開始   : 2026-07-08 15:45:00 (UTC)
* 終了   : 2026-07-08 15:50:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→10→…→11→10→12→11
* 開始   : 2026-07-08 19:10:00 (UTC)
* 終了   : 2026-07-08 19:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→12→14→15→12→14→15→12→13
* 開始   : 2026-07-09 04:20:00 (UTC)
* 終了   : 2026-07-09 04:25:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→14→15→13→…→13→16→14→15
* 開始   : 2026-07-09 04:45:00 (UTC)
* 終了   : 2026-07-09 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→15→13→17→15→16
* 開始   : 2026-07-09 05:55:00 (UTC)
* 終了   : 2026-07-09 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→21→25→22→25→22→25→23→21
* 開始   : 2026-07-09 10:20:00 (UTC)
* 終了   : 2026-07-09 10:30:00 (UTC)
* 現象   : 木曜10時台の平常値(21.33)に対し 25であった
* 説明   : ALG-A1: 移動平均からの残差が 2.724σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.056σ 外れた (平常値=21.33)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→19→18→22→19→18→22→20
* 開始   : 2026-07-09 14:50:00 (UTC)
* 終了   : 2026-07-09 14:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260709-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→13→15→16→13→15→14
* 開始   : 2026-07-09 17:55:00 (UTC)
* 終了   : 2026-07-09 18:00:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→6→12→8→12→8→12→10
* 開始   : 2026-07-10 02:10:00 (UTC)
* 終了   : 2026-07-10 02:20:00 (UTC)
* 現象   : 平常時(8)に対し 1.5倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.782σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→11→12→10→11→12→10→11
* 開始   : 2026-07-10 02:25:00 (UTC)
* 終了   : 2026-07-10 02:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→13→11→13→11→13→10→12
* 開始   : 2026-07-10 03:30:00 (UTC)
* 終了   : 2026-07-10 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→15→16→18→15→16
* 開始   : 2026-07-10 06:40:00 (UTC)
* 終了   : 2026-07-10 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→19→18→19→17→20→20
* 開始   : 2026-07-10 07:05:00 (UTC)
* 終了   : 2026-07-10 08:00:00 (UTC)
* 現象   : 2026-07-10 08:00:00 (UTC)を境に水準が 14.96から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.232, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→16→20→18→20→18→21→22
* 開始   : 2026-07-10 07:30:00 (UTC)
* 終了   : 2026-07-10 08:05:00 (UTC)
* 現象   : 2026-07-10 08:05:00 (UTC)を境に水準が 14.91から14.5へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→15→…→15→13→15→18
* 開始   : 2026-07-10 17:45:00 (UTC)
* 終了   : 2026-07-10 17:55:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→10→7→9
* 開始   : 2026-07-10 21:20:00 (UTC)
* 終了   : 2026-07-10 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→9→8→9→10→9→8→7→10
* 開始   : 2026-07-10 22:05:00 (UTC)
* 終了   : 2026-07-10 23:15:00 (UTC)
* 現象   : 2026-07-10 23:15:00 (UTC)を境に水準が 15.03から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→8→9→10→10→9→10→10
* 開始   : 2026-07-10 22:10:00 (UTC)
* 終了   : 2026-07-10 22:45:00 (UTC)
* 現象   : 2026-07-10 22:45:00 (UTC)を境に水準が 14.95から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.488, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→12→10→12→13→12→12→11→14
* 開始   : 2026-07-14 03:50:00 (UTC)
* 終了   : 2026-07-14 04:45:00 (UTC)
* 現象   : 2026-07-14 04:45:00 (UTC)を境に水準が 14.84から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→12→…→12→17→14→16
* 開始   : 2026-07-14 05:45:00 (UTC)
* 終了   : 2026-07-14 05:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→18→16→18→16→18→16
* 開始   : 2026-07-14 16:00:00 (UTC)
* 終了   : 2026-07-14 16:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→10→13→10→12
* 開始   : 2026-07-14 19:50:00 (UTC)
* 終了   : 2026-07-14 19:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260714-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→12→10→11→12→10→11
* 開始   : 2026-07-14 19:55:00 (UTC)
* 終了   : 2026-07-14 20:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→10→8→11→10→8→11→8
* 開始   : 2026-07-14 20:05:00 (UTC)
* 終了   : 2026-07-14 20:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 7→5→11→10→7→5→11→10→9
* 開始   : 2026-07-15 00:10:00 (UTC)
* 終了   : 2026-07-15 00:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→14→11→14→11→10
* 開始   : 2026-07-15 04:05:00 (UTC)
* 終了   : 2026-07-15 04:10:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 22→19→18→19→18→19→20
* 開始   : 2026-07-15 15:05:00 (UTC)
* 終了   : 2026-07-15 15:10:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 20→18→16→15→…→16→15→20→18
* 開始   : 2026-07-15 16:15:00 (UTC)
* 終了   : 2026-07-15 16:20:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→8→9→6→8→10
* 開始   : 2026-07-15 22:25:00 (UTC)
* 終了   : 2026-07-15 22:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→12→11→14→12→11
* 開始   : 2026-07-16 03:55:00 (UTC)
* 終了   : 2026-07-16 05:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260716-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260716-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260716-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 20→17→23→20→…→20→24→19→21
* 開始   : 2026-07-16 09:30:00 (UTC)
* 終了   : 2026-07-16 09:40:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260716-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260716-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→11→9→10→11→9→10→11
* 開始   : 2026-07-16 20:20:00 (UTC)
* 終了   : 2026-07-16 20:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-079 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→11→7→6→…→7→6→8→10
* 開始   : 2026-07-16 21:30:00 (UTC)
* 終了   : 2026-07-16 21:35:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→11→9→10→11→11→12
* 開始   : 2026-07-17 01:20:00 (UTC)
* 終了   : 2026-07-17 02:10:00 (UTC)
* 現象   : 2026-07-17 02:10:00 (UTC)を境に水準が 14.99から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.296, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→19→17→19→17→19→17→18
* 開始   : 2026-07-17 07:10:00 (UTC)
* 終了   : 2026-07-17 07:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→18→17→20→18→17→20→21
* 開始   : 2026-07-17 15:15:00 (UTC)
* 終了   : 2026-07-17 15:20:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→13→…→14→13→17→16
* 開始   : 2026-07-17 17:30:00 (UTC)
* 終了   : 2026-07-17 17:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260717-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→12→10→13→12→10→13→12
* 開始   : 2026-07-17 19:35:00 (UTC)
* 終了   : 2026-07-17 19:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260717-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→7→6→9→8→7→6→9→8
* 開始   : 2026-07-17 21:50:00 (UTC)
* 終了   : 2026-07-17 21:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→7→11→12→7→11→12→7→9
* 開始   : 2026-07-18 00:15:00 (UTC)
* 終了   : 2026-07-18 00:20:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260718-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→7→9→6→7→9→6→9→8
* 開始   : 2026-07-18 20:50:00 (UTC)
* 終了   : 2026-07-18 21:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分

![EVT-20260718-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→11→5→10→8→11→5→10
* 開始   : 2026-07-19 00:50:00 (UTC)
* 終了   : 2026-07-19 00:55:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→17→13→17→13→17→13
* 開始   : 2026-07-19 08:10:00 (UTC)
* 終了   : 2026-07-19 08:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→15→16→15→15→15→15→16→17
* 開始   : 2026-07-19 14:45:00 (UTC)
* 終了   : 2026-07-19 15:40:00 (UTC)
* 現象   : 2026-07-19 15:40:00 (UTC)を境に水準が 11.77から14.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→11→9→11→9→12→10
* 開始   : 2026-07-19 18:20:00 (UTC)
* 終了   : 2026-07-19 18:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→10→11→9→10→8→10
* 開始   : 2026-07-19 22:40:00 (UTC)
* 終了   : 2026-07-19 23:35:00 (UTC)
* 現象   : 2026-07-19 23:35:00 (UTC)を境に水準が 11.8から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→7→12→6→…→12→6→9→7
* 開始   : 2026-07-20 22:20:00 (UTC)
* 終了   : 2026-07-20 22:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260720-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→8→10→8→10→10
* 開始   : 2026-07-20 23:00:00 (UTC)
* 終了   : 2026-07-20 23:25:00 (UTC)
* 現象   : 2026-07-20 23:25:00 (UTC)を境に水準が 14.92から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→15→…→9→15→14→15
* 開始   : 2026-07-21 05:05:00 (UTC)
* 終了   : 2026-07-21 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→15→…→15→17→13→14
* 開始   : 2026-07-21 05:10:00 (UTC)
* 終了   : 2026-07-21 05:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→14→18→17→14→18→17→14
* 開始   : 2026-07-21 06:35:00 (UTC)
* 終了   : 2026-07-21 06:40:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→22→19→22→19
* 開始   : 2026-07-21 09:05:00 (UTC)
* 終了   : 2026-07-21 09:10:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 23→22→25→22→25→22
* 開始   : 2026-07-21 11:35:00 (UTC)
* 終了   : 2026-07-21 11:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→16→11→12→16→11→12→13
* 開始   : 2026-07-21 19:00:00 (UTC)
* 終了   : 2026-07-21 19:05:00 (UTC)
* 現象   : 平常時(15)に対し 0.7333(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.787σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→11→9→11→9→12
* 開始   : 2026-07-21 20:10:00 (UTC)
* 終了   : 2026-07-21 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260721-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 9→10→15→13→…→13→8→10→13
* 開始   : 2026-07-21 20:25:00 (UTC)
* 終了   : 2026-07-21 20:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260721-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→9→11→9→11→10
* 開始   : 2026-07-22 02:20:00 (UTC)
* 終了   : 2026-07-22 02:25:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→19→15→18→19→15→16
* 開始   : 2026-07-22 06:20:00 (UTC)
* 終了   : 2026-07-22 06:25:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→14→19→17→14→19→17
* 開始   : 2026-07-22 06:20:00 (UTC)
* 終了   : 2026-07-22 06:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.961σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→22→21→19→21→22→21
* 開始   : 2026-07-22 08:15:00 (UTC)
* 終了   : 2026-07-22 08:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260722-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→19→17→23→18→19→17→23→18
* 開始   : 2026-07-22 15:40:00 (UTC)
* 終了   : 2026-07-22 15:45:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260722-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→14→10→14→13
* 開始   : 2026-07-22 19:25:00 (UTC)
* 終了   : 2026-07-22 19:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260722-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 6→9→12→9→12→9→12→9→11
* 開始   : 2026-07-23 02:05:00 (UTC)
* 終了   : 2026-07-23 02:15:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.469倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→18→…→17→18→17→15
* 開始   : 2026-07-23 06:20:00 (UTC)
* 終了   : 2026-07-23 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 23→21→18→23→21→18→23→19
* 開始   : 2026-07-23 14:30:00 (UTC)
* 終了   : 2026-07-23 14:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→21→17→21→17→20
* 開始   : 2026-07-23 15:30:00 (UTC)
* 終了   : 2026-07-23 15:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→16→18→16→18→16→17→18
* 開始   : 2026-07-23 15:55:00 (UTC)
* 終了   : 2026-07-23 16:05:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→11→7→9→7→9→7→9→10
* 開始   : 2026-07-23 21:15:00 (UTC)
* 終了   : 2026-07-23 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260723-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260723-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→9→8→9→9→10→11→10
* 開始   : 2026-07-23 23:25:00 (UTC)
* 終了   : 2026-07-24 00:00:00 (UTC)
* 現象   : 2026-07-24 00:00:00 (UTC)を境に水準が 14.98から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→16→13→14→16→13→16
* 開始   : 2026-07-24 05:05:00 (UTC)
* 終了   : 2026-07-24 05:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→14→15→13→15
* 開始   : 2026-07-24 05:10:00 (UTC)
* 終了   : 2026-07-24 05:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host09-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→17→15→18→17→15→17
* 開始   : 2026-07-24 06:05:00 (UTC)
* 終了   : 2026-07-24 06:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.301倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 22→19→25→22→…→22→25→22→24
* 開始   : 2026-07-24 12:55:00 (UTC)
* 終了   : 2026-07-24 14:10:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260724-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260724-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→13→11→13→11→13→14
* 開始   : 2026-07-24 18:30:00 (UTC)
* 終了   : 2026-07-24 18:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.858σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→8→5→4→…→8→11→12→8
* 開始   : 2026-07-26 00:40:00 (UTC)
* 終了   : 2026-07-26 01:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→8→10→9→11→9→10
* 開始   : 2026-07-26 01:50:00 (UTC)
* 終了   : 2026-07-26 02:35:00 (UTC)
* 現象   : 2026-07-26 02:35:00 (UTC)を境に水準が 11.66から11.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→10→13→8→10→13→8→9
* 開始   : 2026-07-26 05:25:00 (UTC)
* 終了   : 2026-07-26 05:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260726-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260726-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→16→13→16→15→13
* 開始   : 2026-07-26 07:50:00 (UTC)
* 終了   : 2026-07-26 08:00:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260726-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→17→13→19→15→17→13→19→15
* 開始   : 2026-07-26 11:40:00 (UTC)
* 終了   : 2026-07-26 11:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260726-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→10→…→16→10→15→14
* 開始   : 2026-07-26 17:10:00 (UTC)
* 終了   : 2026-07-26 17:15:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260726-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→8→6→9→6→9→6→9
* 開始   : 2026-07-26 21:20:00 (UTC)
* 終了   : 2026-07-26 21:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.849σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 23→21→22→22→21→21→21→22→25
* 開始   : 2026-07-28 08:45:00 (UTC)
* 終了   : 2026-07-28 10:15:00 (UTC)
* 現象   : 2026-07-28 10:15:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→24→19→21→24→19→21→22
* 開始   : 2026-07-28 13:25:00 (UTC)
* 終了   : 2026-07-28 13:30:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260728-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→19→20→21→22→23→22
* 開始   : 2026-07-28 14:50:00 (UTC)
* 終了   : 2026-07-28 16:00:00 (UTC)
* 現象   : 2026-07-28 16:00:00 (UTC)を境に水準が 14.95から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→18→17→14→18→16
* 開始   : 2026-07-28 17:15:00 (UTC)
* 終了   : 2026-07-28 17:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→10→12→10→12→10→13→11
* 開始   : 2026-07-28 19:25:00 (UTC)
* 終了   : 2026-07-28 19:35:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→10→8→11→10→8→11→12
* 開始   : 2026-07-28 20:20:00 (UTC)
* 終了   : 2026-07-28 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.6531(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→8→13→8→13→8→10→12
* 開始   : 2026-07-28 20:30:00 (UTC)
* 終了   : 2026-07-28 20:40:00 (UTC)
* 現象   : 平常時(12)に対し 0.6667(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-066 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260728-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→11→7→13→…→7→13→9→8
* 開始   : 2026-07-28 21:35:00 (UTC)
* 終了   : 2026-07-28 21:40:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260728-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→11→…→5→11→7→8
* 開始   : 2026-07-28 23:45:00 (UTC)
* 終了   : 2026-07-28 23:50:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→5→8→5→8→5→9
* 開始   : 2026-07-29 00:35:00 (UTC)
* 終了   : 2026-07-29 00:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 20→19→23→21→23→21→23→21
* 開始   : 2026-07-29 09:10:00 (UTC)
* 終了   : 2026-07-29 09:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.205倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 21→18→22→24→18→22→24→23→22
* 開始   : 2026-07-29 10:50:00 (UTC)
* 終了   : 2026-07-29 11:00:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260729-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 20→22→18→17→…→18→17→18→19
* 開始   : 2026-07-29 15:10:00 (UTC)
* 終了   : 2026-07-29 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→16→17→15→14→16
* 開始   : 2026-07-29 16:50:00 (UTC)
* 終了   : 2026-07-29 16:55:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→11→…→11→9→11→15
* 開始   : 2026-07-29 19:20:00 (UTC)
* 終了   : 2026-07-29 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→10→…→10→8→10→11
* 開始   : 2026-07-29 20:40:00 (UTC)
* 終了   : 2026-07-29 20:50:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→7→10→11→8→7→10
* 開始   : 2026-07-29 21:25:00 (UTC)
* 終了   : 2026-07-29 21:30:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→11→6→11→6→9→8
* 開始   : 2026-07-29 22:50:00 (UTC)
* 終了   : 2026-07-29 23:00:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→8→5→11→…→5→11→7→8
* 開始   : 2026-07-30 00:50:00 (UTC)
* 終了   : 2026-07-30 00:55:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 7→8→12→10→12→10→12→8
* 開始   : 2026-07-30 02:35:00 (UTC)
* 終了   : 2026-07-30 02:45:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→16→21→20→16→21→20→18
* 開始   : 2026-07-30 07:55:00 (UTC)
* 終了   : 2026-07-30 08:00:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→17→19→19→18→20
* 開始   : 2026-07-30 16:40:00 (UTC)
* 終了   : 2026-07-30 17:40:00 (UTC)
* 現象   : 2026-07-30 17:40:00 (UTC)を境に水準が 15.1から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.374, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→15→13→15→13→16
* 開始   : 2026-07-30 17:50:00 (UTC)
* 終了   : 2026-07-30 17:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→13→10→14→…→14→9→12→11
* 開始   : 2026-07-30 19:35:00 (UTC)
* 終了   : 2026-07-30 19:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260730-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→16→18→16→18→17→16
* 開始   : 2026-07-31 06:25:00 (UTC)
* 終了   : 2026-07-31 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→17→19→17→19→17→19
* 開始   : 2026-07-31 07:10:00 (UTC)
* 終了   : 2026-07-31 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→18→21→17→21→17→21→17→20
* 開始   : 2026-07-31 07:50:00 (UTC)
* 終了   : 2026-07-31 08:00:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.223倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 24→20→20→20→18→21→19→19→18
* 開始   : 2026-07-31 14:45:00 (UTC)
* 終了   : 2026-07-31 16:50:00 (UTC)
* 現象   : 2026-07-31 16:50:00 (UTC)を境に水準が 14.94から12.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.091, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host09-006 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
