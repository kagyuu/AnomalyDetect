# host09 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host09 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 288 (SEVERE: 18, FATAL: 129, WARN: 141, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 18 | 129 | 141 | 288 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→12→…→12→13→11→12
* 開始   : 2026-08-03 00:55:00 (UTC)
* 終了   : 2026-08-03 20:25:00 (UTC)
* 現象   : 2026-08-03 20:25:00 (UTC)を境に水準が 11.73から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.691, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-001 active_connections の推移](charts/EVT-20260803-host09-001.svg)

# イベントID( EVT-20260803-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→14→13→14→…→14→12→14→12
* 開始   : 2026-08-03 01:55:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.73から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-002 active_connections の推移](charts/EVT-20260803-host09-002.svg)

# イベントID( EVT-20260803-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→17→15→14→…→13→15→13→12
* 開始   : 2026-08-03 02:30:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.85から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.863, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-003 active_connections の推移](charts/EVT-20260803-host09-003.svg)

# イベントID( EVT-20260803-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→16→…→13→12→14→10
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.72から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.788, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-004 active_connections の推移](charts/EVT-20260803-host09-004.svg)

# イベントID( EVT-20260803-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→14→16→14→15
* 開始   : 2026-08-03 03:40:00 (UTC)
* 終了   : 2026-08-03 20:30:00 (UTC)
* 現象   : 2026-08-03 20:30:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.767σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.88, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.249, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-005 active_connections の推移](charts/EVT-20260803-host09-005.svg)

# イベントID( EVT-20260803-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→18→…→13→14→13→14
* 開始   : 2026-08-03 04:20:00 (UTC)
* 終了   : 2026-08-03 19:15:00 (UTC)
* 現象   : 2026-08-03 19:15:00 (UTC)を境に水準が 12から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.895, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.488, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-006 active_connections の推移](charts/EVT-20260803-host09-006.svg)

# イベントID( EVT-20260810-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→18→19→16→…→16→15→14→15
* 開始   : 2026-08-10 03:30:00 (UTC)
* 終了   : 2026-08-10 20:10:00 (UTC)
* 現象   : 2026-08-10 20:10:00 (UTC)を境に水準が 11.89から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.909σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.735, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.911, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-005 active_connections の推移](charts/EVT-20260810-host09-005.svg)

# イベントID( EVT-20260810-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→16→15→17→…→13→14→13→15
* 開始   : 2026-08-10 03:55:00 (UTC)
* 終了   : 2026-08-10 20:55:00 (UTC)
* 現象   : 2026-08-10 20:55:00 (UTC)を境に水準が 11.92から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.261, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-006 active_connections の推移](charts/EVT-20260810-host09-006.svg)

# イベントID( EVT-20260810-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→14→…→17→15→13→14
* 開始   : 2026-08-10 04:00:00 (UTC)
* 終了   : 2026-08-10 20:00:00 (UTC)
* 現象   : 2026-08-10 20:00:00 (UTC)を境に水準が 11.92から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-007 active_connections の推移](charts/EVT-20260810-host09-007.svg)

# イベントID( EVT-20260817-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→17→18→17→…→14→13→14→13
* 開始   : 2026-08-17 02:50:00 (UTC)
* 終了   : 2026-08-17 22:00:00 (UTC)
* 現象   : 2026-08-17 22:00:00 (UTC)を境に水準が 11.76から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.079, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.168, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-004 active_connections の推移](charts/EVT-20260817-host09-004.svg)

# イベントID( EVT-20260817-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→16→19→16→…→13→11→12→13
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 20:10:00 (UTC)
* 現象   : 2026-08-17 20:10:00 (UTC)を境に水準が 11.87から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.695, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-005 active_connections の推移](charts/EVT-20260817-host09-005.svg)

# イベントID( EVT-20260817-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→14→…→12→13→10→12
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 20:35:00 (UTC)
* 現象   : 2026-08-17 20:35:00 (UTC)を境に水準が 11.75から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.426, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-006 active_connections の推移](charts/EVT-20260817-host09-006.svg)

# イベントID( EVT-20260817-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→16→20→17→…→15→14→13→12
* 開始   : 2026-08-17 03:45:00 (UTC)
* 終了   : 2026-08-17 20:20:00 (UTC)
* 現象   : 2026-08-17 20:20:00 (UTC)を境に水準が 11.94から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.743, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.311, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-007 active_connections の推移](charts/EVT-20260817-host09-007.svg)

# イベントID( EVT-20260817-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→16→15→16→…→14→11→10→13
* 開始   : 2026-08-17 04:30:00 (UTC)
* 終了   : 2026-08-17 19:50:00 (UTC)
* 現象   : 2026-08-17 19:50:00 (UTC)を境に水準が 11.94から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.801, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-008 active_connections の推移](charts/EVT-20260817-host09-008.svg)

# イベントID( EVT-20260824-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→13→18→17→…→14→13→14→13
* 開始   : 2026-08-24 00:55:00 (UTC)
* 終了   : 2026-08-24 20:40:00 (UTC)
* 現象   : 2026-08-24 20:40:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.257, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-001 active_connections の推移](charts/EVT-20260824-host09-001.svg)

# イベントID( EVT-20260824-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→17→…→13→14→12→13
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.83から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.852, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-003 active_connections の推移](charts/EVT-20260824-host09-003.svg)

# イベントID( EVT-20260824-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→14→17→15→…→13→12→13→15
* 開始   : 2026-08-24 04:05:00 (UTC)
* 終了   : 2026-08-24 19:40:00 (UTC)
* 現象   : 2026-08-24 19:40:00 (UTC)を境に水準が 11.91から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.88, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.488, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-005 active_connections の推移](charts/EVT-20260824-host09-005.svg)

# イベントID( EVT-20260824-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→13→…→13→12→11→12
* 開始   : 2026-08-24 04:10:00 (UTC)
* 終了   : 2026-08-24 19:25:00 (UTC)
* 現象   : 2026-08-24 19:25:00 (UTC)を境に水準が 11.88から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.668, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-006 active_connections の推移](charts/EVT-20260824-host09-006.svg)

# イベントID( EVT-20260801-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→10→14→8→8
* 開始   : 2026-08-01 03:25:00 (UTC)
* 終了   : 2026-08-01 03:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260801-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host09-002 active_connections の推移](charts/EVT-20260801-host09-002.svg)

# イベントID( EVT-20260801-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→13→9→11→…→10→11→12→10
* 開始   : 2026-08-01 04:55:00 (UTC)
* 終了   : 2026-08-01 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.819, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host09-003 active_connections の推移](charts/EVT-20260801-host09-003.svg)

# イベントID( EVT-20260801-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→14→…→8→12→10→11
* 開始   : 2026-08-01 05:30:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.85, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host09-004 active_connections の推移](charts/EVT-20260801-host09-004.svg)

# イベントID( EVT-20260801-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→…→13→11→14→12
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 17:55:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.927, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260801-host09-005 active_connections の推移](charts/EVT-20260801-host09-005.svg)

# イベントID( EVT-20260801-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→12→10→13→…→9→11→12→10
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:15:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.971, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260801-host09-006 active_connections の推移](charts/EVT-20260801-host09-006.svg)

# イベントID( EVT-20260801-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→11→…→14→12→11→12
* 開始   : 2026-08-01 06:05:00 (UTC)
* 終了   : 2026-08-01 18:40:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.865, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260801-host09-007 active_connections の推移](charts/EVT-20260801-host09-007.svg)

# イベントID( EVT-20260801-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→9→…→11→10→12→10
* 開始   : 2026-08-01 06:20:00 (UTC)
* 終了   : 2026-08-01 20:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.058, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host09-008 active_connections の推移](charts/EVT-20260801-host09-008.svg)

# イベントID( EVT-20260802-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→10→6→9→11
* 開始   : 2026-08-02 19:50:00 (UTC)
* 終了   : 2026-08-02 19:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→10→10
* 開始   : 2026-08-03 20:25:00 (UTC)
* 終了   : 2026-08-03 20:25:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→15→18→15→15
* 開始   : 2026-08-04 05:40:00 (UTC)
* 終了   : 2026-08-04 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→17→16→18→17→18
* 開始   : 2026-08-04 06:45:00 (UTC)
* 終了   : 2026-08-04 07:20:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260804-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260804-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→17→14→17→…→17→15→17→18
* 開始   : 2026-08-04 16:40:00 (UTC)
* 終了   : 2026-08-04 16:50:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.7273(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260804-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host09-005 active_connections の推移](charts/EVT-20260804-host09-005.svg)

# イベントID( EVT-20260804-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→14→…→12→11→15→13
* 開始   : 2026-08-04 18:20:00 (UTC)
* 終了   : 2026-08-04 18:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260804-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260804-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→9→9→9→10
* 開始   : 2026-08-04 23:45:00 (UTC)
* 終了   : 2026-08-05 00:10:00 (UTC)
* 現象   : 2026-08-05 00:10:00 (UTC)を境に水準が 14.98から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→14→17→18→14→17→15
* 開始   : 2026-08-05 05:25:00 (UTC)
* 終了   : 2026-08-05 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260805-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-002 active_connections の推移](charts/EVT-20260805-host09-002.svg)

# イベントID( EVT-20260805-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→18→23→18→19
* 開始   : 2026-08-05 08:25:00 (UTC)
* 終了   : 2026-08-05 08:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.296倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-004 active_connections の推移](charts/EVT-20260805-host09-004.svg)

# イベントID( EVT-20260805-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→19→15→18→16
* 開始   : 2026-08-05 16:05:00 (UTC)
* 終了   : 2026-08-05 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→13→13
* 開始   : 2026-08-05 19:15:00 (UTC)
* 終了   : 2026-08-05 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→12→12
* 開始   : 2026-08-05 19:50:00 (UTC)
* 終了   : 2026-08-05 19:50:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→9→10→12
* 開始   : 2026-08-05 19:50:00 (UTC)
* 終了   : 2026-08-05 20:10:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-012 active_connections の推移](charts/EVT-20260805-host09-012.svg)

# イベントID( EVT-20260806-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→15→18→14→15
* 開始   : 2026-08-06 05:45:00 (UTC)
* 終了   : 2026-08-06 05:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→22→19→21→22→19→21→20
* 開始   : 2026-08-06 07:30:00 (UTC)
* 終了   : 2026-08-06 08:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.348倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.779σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host09-005 active_connections の推移](charts/EVT-20260806-host09-005.svg)

# イベントID( EVT-20260806-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→7→9
* 開始   : 2026-08-06 23:15:00 (UTC)
* 終了   : 2026-08-06 23:15:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→15→14
* 開始   : 2026-08-07 05:50:00 (UTC)
* 終了   : 2026-08-07 05:50:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→20→…→18→20→15→16
* 開始   : 2026-08-07 06:30:00 (UTC)
* 終了   : 2026-08-07 06:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 20→21→25→20→20
* 開始   : 2026-08-07 09:20:00 (UTC)
* 終了   : 2026-08-07 09:20:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host09-005 active_connections の推移](charts/EVT-20260807-host09-005.svg)

# イベントID( EVT-20260807-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→22→18→22→21
* 開始   : 2026-08-07 13:40:00 (UTC)
* 終了   : 2026-08-07 13:40:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→8→7→12→11→8→7→12→10
* 開始   : 2026-08-07 19:30:00 (UTC)
* 終了   : 2026-08-07 20:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→11→13→14→…→11→12→11→13
* 開始   : 2026-08-08 05:10:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.493, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260808-host09-001 active_connections の推移](charts/EVT-20260808-host09-001.svg)

# イベントID( EVT-20260808-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→10→12→…→12→13→8→12
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host09-002 active_connections の推移](charts/EVT-20260808-host09-002.svg)

# イベントID( EVT-20260808-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→12→…→12→13→11→12
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 18:00:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.779σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-006 (他ホスト) jvm_gc / ou : FATAL / 重なり 12.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260808-host09-003 active_connections の推移](charts/EVT-20260808-host09-003.svg)

# イベントID( EVT-20260808-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→14→12→11→…→13→11→14→11
* 開始   : 2026-08-08 05:35:00 (UTC)
* 終了   : 2026-08-08 20:45:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260808-host09-004 active_connections の推移](charts/EVT-20260808-host09-004.svg)

# イベントID( EVT-20260808-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→11→…→11→10→13→14
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.751, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host09-005 active_connections の推移](charts/EVT-20260808-host09-005.svg)

# イベントID( EVT-20260808-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→11→…→12→11→10→12
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.936, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260808-host09-006 active_connections の推移](charts/EVT-20260808-host09-006.svg)

# イベントID( EVT-20260809-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→11→14→9→8
* 開始   : 2026-08-09 04:25:00 (UTC)
* 終了   : 2026-08-09 04:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→9→14→12→13
* 開始   : 2026-08-09 04:30:00 (UTC)
* 終了   : 2026-08-09 04:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→19→14→13
* 開始   : 2026-08-09 15:05:00 (UTC)
* 終了   : 2026-08-09 15:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→9→5→8→10
* 開始   : 2026-08-09 20:05:00 (UTC)
* 終了   : 2026-08-09 20:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.4839(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host09-007 active_connections の推移](charts/EVT-20260809-host09-007.svg)

# イベントID( EVT-20260810-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→15→13→12→13
* 開始   : 2026-08-10 02:10:00 (UTC)
* 終了   : 2026-08-10 20:30:00 (UTC)
* 現象   : 2026-08-10 20:30:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.494, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→16→…→12→14→12→14
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.83から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.767, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→14→…→13→15→12→15
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 19:40:00 (UTC)
* 現象   : 2026-08-10 19:40:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.735, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.561, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→21→18→19
* 開始   : 2026-08-11 07:55:00 (UTC)
* 終了   : 2026-08-11 07:55:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→19→23→19→17
* 開始   : 2026-08-11 08:40:00 (UTC)
* 終了   : 2026-08-11 08:40:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host09-003 active_connections の推移](charts/EVT-20260811-host09-003.svg)

# イベントID( EVT-20260811-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→9→11→13→8→9→11
* 開始   : 2026-08-11 20:20:00 (UTC)
* 終了   : 2026-08-11 20:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→11→6→9→10
* 開始   : 2026-08-11 21:30:00 (UTC)
* 終了   : 2026-08-11 21:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→18→23→22→18→23→22→21
* 開始   : 2026-08-12 09:15:00 (UTC)
* 終了   : 2026-08-12 09:20:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→22→25→20→22
* 開始   : 2026-08-12 09:45:00 (UTC)
* 終了   : 2026-08-12 09:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→20→15→21→18
* 開始   : 2026-08-12 15:40:00 (UTC)
* 終了   : 2026-08-12 15:40:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host09-007 active_connections の推移](charts/EVT-20260812-host09-007.svg)

# イベントID( EVT-20260812-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→14→14
* 開始   : 2026-08-12 18:35:00 (UTC)
* 終了   : 2026-08-12 18:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→10→14→12→12
* 開始   : 2026-08-13 03:30:00 (UTC)
* 終了   : 2026-08-13 03:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→17→21→20→…→21→20→18→20
* 開始   : 2026-08-13 07:40:00 (UTC)
* 終了   : 2026-08-13 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→20→15→19→19
* 開始   : 2026-08-13 16:10:00 (UTC)
* 終了   : 2026-08-13 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→18→14→16→16
* 開始   : 2026-08-13 16:30:00 (UTC)
* 終了   : 2026-08-13 16:30:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.547σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-009 active_connections の推移](charts/EVT-20260813-host09-009.svg)

# イベントID( EVT-20260813-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→16→14→15→14→16→14→15
* 開始   : 2026-08-13 18:25:00 (UTC)
* 終了   : 2026-08-13 19:10:00 (UTC)
* 現象   : 2026-08-13 19:10:00 (UTC)を境に水準が 14.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→10→6→10→9
* 開始   : 2026-08-13 21:10:00 (UTC)
* 終了   : 2026-08-13 21:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→10→8
* 開始   : 2026-08-13 21:55:00 (UTC)
* 終了   : 2026-08-13 21:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host09-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→8→4→7→6
* 開始   : 2026-08-13 23:00:00 (UTC)
* 終了   : 2026-08-13 23:00:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.477σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host09-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→19→18→…→19→18→16→17
* 開始   : 2026-08-14 06:15:00 (UTC)
* 終了   : 2026-08-14 06:20:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.314σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→9→11→9→13
* 開始   : 2026-08-14 19:10:00 (UTC)
* 終了   : 2026-08-14 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→12→9→12→…→12→7→11→9
* 開始   : 2026-08-14 20:35:00 (UTC)
* 終了   : 2026-08-14 20:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host09-013 active_connections の推移](charts/EVT-20260814-host09-013.svg)

# イベントID( EVT-20260815-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→9→13→14→…→14→10→14→10
* 開始   : 2026-08-15 04:40:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.225, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260815-host09-002 active_connections の推移](charts/EVT-20260815-host09-002.svg)

# イベントID( EVT-20260815-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→10→11→10→…→8→12→13→10
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.973, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260815-host09-003 active_connections の推移](charts/EVT-20260815-host09-003.svg)

# イベントID( EVT-20260815-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→…→12→9→11→9
* 開始   : 2026-08-15 05:45:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.408, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host09-004 active_connections の推移](charts/EVT-20260815-host09-004.svg)

# イベントID( EVT-20260815-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→13→…→11→12→11→12
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.736, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host09-005 active_connections の推移](charts/EVT-20260815-host09-005.svg)

# イベントID( EVT-20260815-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→13→…→12→13→14→12
* 開始   : 2026-08-15 05:55:00 (UTC)
* 終了   : 2026-08-15 17:45:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.81, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260815-host09-006 active_connections の推移](charts/EVT-20260815-host09-006.svg)

# イベントID( EVT-20260815-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→11→…→11→12→10→12
* 開始   : 2026-08-15 06:20:00 (UTC)
* 終了   : 2026-08-15 20:45:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.724σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.803, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host09-007 active_connections の推移](charts/EVT-20260815-host09-007.svg)

# イベントID( EVT-20260816-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→18→16
* 開始   : 2026-08-16 09:15:00 (UTC)
* 終了   : 2026-08-16 09:25:00 (UTC)
* 現象   : 2026-08-16 09:25:00 (UTC)を境に水準が 11.7から12.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.187, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→15→20→16→16
* 開始   : 2026-08-16 14:15:00 (UTC)
* 終了   : 2026-08-16 14:15:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→…→12→14→12→14
* 開始   : 2026-08-17 02:50:00 (UTC)
* 終了   : 2026-08-17 20:50:00 (UTC)
* 現象   : 2026-08-17 20:50:00 (UTC)を境に水準が 11.8から15.18へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.901, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.588, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→15→15
* 開始   : 2026-08-18 05:35:00 (UTC)
* 終了   : 2026-08-18 05:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→22→28→24→…→24→19→21→25
* 開始   : 2026-08-18 11:20:00 (UTC)
* 終了   : 2026-08-18 11:30:00 (UTC)
* 現象   : 平常時(22)に対し 1.273倍(28)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host09-005 active_connections の推移](charts/EVT-20260818-host09-005.svg)

# イベントID( EVT-20260818-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→20→15→19→20
* 開始   : 2026-08-18 15:55:00 (UTC)
* 終了   : 2026-08-18 15:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→20→15→19→17
* 開始   : 2026-08-18 16:05:00 (UTC)
* 終了   : 2026-08-18 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→15→11→16→…→16→12→15→16
* 開始   : 2026-08-18 17:20:00 (UTC)
* 終了   : 2026-08-18 18:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host09-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host09-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260818-host09-010 active_connections の推移](charts/EVT-20260818-host09-010.svg)

# イベントID( EVT-20260818-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→9→6→9→9
* 開始   : 2026-08-18 21:55:00 (UTC)
* 終了   : 2026-08-18 21:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→8→4→10→10
* 開始   : 2026-08-18 23:45:00 (UTC)
* 終了   : 2026-08-18 23:45:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→8→4→10→8
* 開始   : 2026-08-19 01:25:00 (UTC)
* 終了   : 2026-08-19 01:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→19→20→16→15→19→20→16→17
* 開始   : 2026-08-19 06:45:00 (UTC)
* 終了   : 2026-08-19 06:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.274倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.84σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→16→19→15→16
* 開始   : 2026-08-19 06:50:00 (UTC)
* 終了   : 2026-08-19 06:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→23→19→24→…→24→17→22→21
* 開始   : 2026-08-19 12:35:00 (UTC)
* 終了   : 2026-08-19 12:45:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260819-host09-007 active_connections の推移](charts/EVT-20260819-host09-007.svg)

# イベントID( EVT-20260819-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→22→16→22→21
* 開始   : 2026-08-19 15:05:00 (UTC)
* 終了   : 2026-08-19 15:05:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→22→16→20→20
* 開始   : 2026-08-19 15:30:00 (UTC)
* 終了   : 2026-08-19 15:30:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→12→13
* 開始   : 2026-08-19 19:35:00 (UTC)
* 終了   : 2026-08-19 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→13→16→11→12
* 開始   : 2026-08-20 05:00:00 (UTC)
* 終了   : 2026-08-20 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→12→14
* 開始   : 2026-08-20 05:10:00 (UTC)
* 終了   : 2026-08-20 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→15→22→19→19
* 開始   : 2026-08-20 07:45:00 (UTC)
* 終了   : 2026-08-20 07:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.333倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.849σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host09-004 active_connections の推移](charts/EVT-20260820-host09-004.svg)

# イベントID( EVT-20260820-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→19→22→23→19→22→23→19→20
* 開始   : 2026-08-20 08:15:00 (UTC)
* 終了   : 2026-08-20 09:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260820-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→19→18→16→18→16→19→20
* 開始   : 2026-08-20 15:10:00 (UTC)
* 終了   : 2026-08-20 15:20:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→14→11→13→16
* 開始   : 2026-08-20 18:05:00 (UTC)
* 終了   : 2026-08-20 18:05:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→13→10→14→12
* 開始   : 2026-08-20 18:50:00 (UTC)
* 終了   : 2026-08-20 18:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-055 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260820-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→11→5→9→9
* 開始   : 2026-08-20 21:40:00 (UTC)
* 終了   : 2026-08-20 21:40:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→12→…→12→13→11→10
* 開始   : 2026-08-21 03:20:00 (UTC)
* 終了   : 2026-08-21 03:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260821-host09-001 active_connections の推移](charts/EVT-20260821-host09-001.svg)

# イベントID( EVT-20260821-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→18→19→20→…→19→20→16→17
* 開始   : 2026-08-21 07:25:00 (UTC)
* 終了   : 2026-08-21 08:00:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260821-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 22→21→25→20→21→25→20→21
* 開始   : 2026-08-21 10:05:00 (UTC)
* 終了   : 2026-08-21 10:10:00 (UTC)
* 現象   : 金曜10時台の平常値(21.3)に対し 25であった
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.175σ 外れた (平常値=21.3)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→23→17→21→19
* 開始   : 2026-08-21 13:35:00 (UTC)
* 終了   : 2026-08-21 13:35:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.7698(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host09-007 active_connections の推移](charts/EVT-20260821-host09-007.svg)

# イベントID( EVT-20260822-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→10→9→11→…→12→11→10→12
* 開始   : 2026-08-22 04:55:00 (UTC)
* 終了   : 2026-08-22 18:50:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host09-001 active_connections の推移](charts/EVT-20260822-host09-001.svg)

# イベントID( EVT-20260822-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→13→…→10→11→8→10
* 開始   : 2026-08-22 05:20:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.83, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host09-003 active_connections の推移](charts/EVT-20260822-host09-003.svg)

# イベントID( EVT-20260822-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→13→…→12→13→11→12
* 開始   : 2026-08-22 05:25:00 (UTC)
* 終了   : 2026-08-22 18:45:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.021, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host09-004 active_connections の推移](charts/EVT-20260822-host09-004.svg)

# イベントID( EVT-20260822-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→12→…→13→12→13→12
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.975, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260822-host09-005 active_connections の推移](charts/EVT-20260822-host09-005.svg)

# イベントID( EVT-20260822-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→12→…→14→13→15→12
* 開始   : 2026-08-22 06:25:00 (UTC)
* 終了   : 2026-08-22 19:25:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.235, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260822-host09-006 active_connections の推移](charts/EVT-20260822-host09-006.svg)

# イベントID( EVT-20260822-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→15→…→10→11→12→9
* 開始   : 2026-08-22 06:40:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260822-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260822-host09-007 active_connections の推移](charts/EVT-20260822-host09-007.svg)

# イベントID( EVT-20260823-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→10→9
* 開始   : 2026-08-23 02:50:00 (UTC)
* 終了   : 2026-08-23 02:50:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→16→19→15→15
* 開始   : 2026-08-23 09:55:00 (UTC)
* 終了   : 2026-08-23 09:55:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→20→18→16
* 開始   : 2026-08-23 12:35:00 (UTC)
* 終了   : 2026-08-23 12:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→14→13→11→12
* 開始   : 2026-08-24 02:40:00 (UTC)
* 終了   : 2026-08-24 21:00:00 (UTC)
* 現象   : 2026-08-24 21:00:00 (UTC)を境に水準が 11.9から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.855, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→16→17→18→…→12→15→13→14
* 開始   : 2026-08-24 03:25:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.81から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.002, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.121, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→10→4→8→9
* 開始   : 2026-08-24 23:50:00 (UTC)
* 終了   : 2026-08-24 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260824-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→8→14→10→8
* 開始   : 2026-08-25 03:00:00 (UTC)
* 終了   : 2026-08-25 03:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host09-001 active_connections の推移](charts/EVT-20260825-host09-001.svg)

# イベントID( EVT-20260825-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→11→…→11→14→10→12
* 開始   : 2026-08-25 03:45:00 (UTC)
* 終了   : 2026-08-25 03:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.552倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host09-003 active_connections の推移](charts/EVT-20260825-host09-003.svg)

# イベントID( EVT-20260825-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→14→14→14→13→14
* 開始   : 2026-08-25 04:00:00 (UTC)
* 終了   : 2026-08-25 04:50:00 (UTC)
* 現象   : 2026-08-25 04:50:00 (UTC)を境に水準が 14.96から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.831σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.252, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host09-004 active_connections の推移](charts/EVT-20260825-host09-004.svg)

# イベントID( EVT-20260825-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→18→22→20→18
* 開始   : 2026-08-25 08:05:00 (UTC)
* 終了   : 2026-08-25 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→16→12→13→16→12
* 開始   : 2026-08-26 04:55:00 (UTC)
* 終了   : 2026-08-26 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→17→22→19→19
* 開始   : 2026-08-26 08:10:00 (UTC)
* 終了   : 2026-08-26 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→12→12
* 開始   : 2026-08-27 05:00:00 (UTC)
* 終了   : 2026-08-27 05:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→18→15→19→20
* 開始   : 2026-08-27 15:50:00 (UTC)
* 終了   : 2026-08-27 15:50:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→11→6→10→10
* 開始   : 2026-08-27 20:55:00 (UTC)
* 終了   : 2026-08-27 20:55:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→7→12→9→7→12→9→12
* 開始   : 2026-08-28 01:50:00 (UTC)
* 終了   : 2026-08-28 02:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260828-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260828-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→9→12→11→12→11→12→8→10
* 開始   : 2026-08-28 02:05:00 (UTC)
* 終了   : 2026-08-28 03:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.66倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.605σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260828-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 25 分
  - EVT-20260828-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260828-host09-002 active_connections の推移](charts/EVT-20260828-host09-002.svg)

# イベントID( EVT-20260828-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→13→15
* 開始   : 2026-08-28 05:00:00 (UTC)
* 終了   : 2026-08-28 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→13→13
* 開始   : 2026-08-28 05:05:00 (UTC)
* 終了   : 2026-08-28 05:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→14→14
* 開始   : 2026-08-28 18:10:00 (UTC)
* 終了   : 2026-08-28 18:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→11→9
* 開始   : 2026-08-29 03:15:00 (UTC)
* 終了   : 2026-08-29 03:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260829-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260829-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260829-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→11→9→10→…→11→13→12→9
* 開始   : 2026-08-29 04:50:00 (UTC)
* 終了   : 2026-08-29 18:25:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260829-host09-003 active_connections の推移](charts/EVT-20260829-host09-003.svg)

# イベントID( EVT-20260829-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→13→14→11→…→12→10→13→10
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.788, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host09-004 active_connections の推移](charts/EVT-20260829-host09-004.svg)

# イベントID( EVT-20260829-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→13→…→13→10→12→11
* 開始   : 2026-08-29 05:40:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.974, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260829-host09-005 active_connections の推移](charts/EVT-20260829-host09-005.svg)

# イベントID( EVT-20260829-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→8→12→11→…→11→14→13→11
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.94, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260829-host09-006 active_connections の推移](charts/EVT-20260829-host09-006.svg)

# イベントID( EVT-20260829-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→14→9→11→…→11→14→11→12
* 開始   : 2026-08-29 06:10:00 (UTC)
* 終了   : 2026-08-29 18:25:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.475, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260829-host09-007 active_connections の推移](charts/EVT-20260829-host09-007.svg)

# イベントID( EVT-20260829-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→13→…→12→11→13→12
* 開始   : 2026-08-29 06:15:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.212, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260829-host09-008 active_connections の推移](charts/EVT-20260829-host09-008.svg)

# イベントID( EVT-20260829-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→12→8
* 開始   : 2026-08-29 19:50:00 (UTC)
* 終了   : 2026-08-29 19:50:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260829-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 7→10→9→11→8
* 開始   : 2026-08-01 00:05:00 (UTC)
* 終了   : 2026-08-01 00:25:00 (UTC)
* 現象   : 2026-08-01 00:25:00 (UTC)を境に水準が 15.08から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260801-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 8→6→11→8→11→8→11→8
* 開始   : 2026-08-01 23:45:00 (UTC)
* 終了   : 2026-08-01 23:55:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260801-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260801-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→10→11→7→11→7→11→10→8
* 開始   : 2026-08-02 01:30:00 (UTC)
* 終了   : 2026-08-02 01:40:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→16→13→10→16→13→10→11
* 開始   : 2026-08-02 16:45:00 (UTC)
* 終了   : 2026-08-02 16:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→10→10→9→10
* 開始   : 2026-08-03 22:05:00 (UTC)
* 終了   : 2026-08-03 22:25:00 (UTC)
* 現象   : 2026-08-03 22:25:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→9→12→10→12→10→12→10→9
* 開始   : 2026-08-04 02:15:00 (UTC)
* 終了   : 2026-08-04 02:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→17→15→17→16
* 開始   : 2026-08-04 05:50:00 (UTC)
* 終了   : 2026-08-04 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260804-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 18→15→14→13→…→14→13→14→15
* 開始   : 2026-08-04 17:25:00 (UTC)
* 終了   : 2026-08-04 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→15→12→14→…→14→12→16→13
* 開始   : 2026-08-04 18:10:00 (UTC)
* 終了   : 2026-08-04 18:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260804-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→13→12→13→12→13→9→12
* 開始   : 2026-08-05 03:20:00 (UTC)
* 終了   : 2026-08-05 03:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→19→…→19→20→17→18
* 開始   : 2026-08-05 06:55:00 (UTC)
* 終了   : 2026-08-05 07:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260805-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→22→24→21→24→21→24→22
* 開始   : 2026-08-05 09:55:00 (UTC)
* 終了   : 2026-08-05 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→19→15→19→15→19
* 開始   : 2026-08-05 16:25:00 (UTC)
* 終了   : 2026-08-05 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.787σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→16→14→15→16→18
* 開始   : 2026-08-05 17:20:00 (UTC)
* 終了   : 2026-08-05 17:25:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7671(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260805-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→11→13→10→11→14
* 開始   : 2026-08-05 19:50:00 (UTC)
* 終了   : 2026-08-05 20:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260805-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→9→9→9→8→10→12→10→9
* 開始   : 2026-08-06 01:10:00 (UTC)
* 終了   : 2026-08-06 01:55:00 (UTC)
* 現象   : 2026-08-06 01:55:00 (UTC)を境に水準が 14.84から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→7→13→11→7→13→11→10
* 開始   : 2026-08-06 03:00:00 (UTC)
* 終了   : 2026-08-06 03:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→15→17→15→17→16→17
* 開始   : 2026-08-06 05:35:00 (UTC)
* 終了   : 2026-08-06 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.782σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→22→18→20→17→18→20→17→21
* 開始   : 2026-08-06 13:55:00 (UTC)
* 終了   : 2026-08-06 14:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260806-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→21→18→17→…→18→17→20→19
* 開始   : 2026-08-06 14:50:00 (UTC)
* 終了   : 2026-08-06 14:55:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260806-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→17→16→15→…→16→15→16→18
* 開始   : 2026-08-06 16:25:00 (UTC)
* 終了   : 2026-08-06 16:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260806-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→17→15→17→14→17→16
* 開始   : 2026-08-06 17:30:00 (UTC)
* 終了   : 2026-08-06 18:30:00 (UTC)
* 現象   : 2026-08-06 18:30:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→11→8→11→8→11→10
* 開始   : 2026-08-06 20:30:00 (UTC)
* 終了   : 2026-08-06 20:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→10→8→9→7→8→9→10
* 開始   : 2026-08-06 23:45:00 (UTC)
* 終了   : 2026-08-07 00:35:00 (UTC)
* 現象   : 2026-08-07 00:35:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.462, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 7→11→5→6→7→11→5→6→10
* 開始   : 2026-08-06 23:55:00 (UTC)
* 終了   : 2026-08-07 00:00:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→16→…→16→19→17→18
* 開始   : 2026-08-07 06:55:00 (UTC)
* 終了   : 2026-08-07 07:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→18→19→15→19→15→19→17→16
* 開始   : 2026-08-07 07:00:00 (UTC)
* 終了   : 2026-08-07 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 24→24→22→23→20→22→23→22→23
* 開始   : 2026-08-07 11:20:00 (UTC)
* 終了   : 2026-08-07 12:10:00 (UTC)
* 現象   : 2026-08-07 12:10:00 (UTC)を境に水準が 14.91から13.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→12→13→16→12→14→16
* 開始   : 2026-08-07 16:55:00 (UTC)
* 終了   : 2026-08-07 18:05:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260807-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 35 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260807-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→11→15→11→15→11→12→13
* 開始   : 2026-08-07 19:15:00 (UTC)
* 終了   : 2026-08-07 19:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→12→13→9
* 開始   : 2026-08-07 21:20:00 (UTC)
* 終了   : 2026-08-07 21:35:00 (UTC)
* 現象   : 2026-08-07 21:35:00 (UTC)を境に水準が 14.89から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.706, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→6→5→11→…→5→11→7→8
* 開始   : 2026-08-07 23:00:00 (UTC)
* 終了   : 2026-08-07 23:05:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host02-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→7→8→7→…→8→7→11→9
* 開始   : 2026-08-08 21:00:00 (UTC)
* 終了   : 2026-08-08 21:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.921, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260808-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→13→15→16→13→15→16→13→10
* 開始   : 2026-08-09 06:55:00 (UTC)
* 終了   : 2026-08-09 07:00:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→13→13→14→16→12→15→12→18
* 開始   : 2026-08-09 07:20:00 (UTC)
* 終了   : 2026-08-09 08:05:00 (UTC)
* 現象   : 2026-08-09 08:05:00 (UTC)を境に水準が 11.7から12.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.552, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→12→11→13→12→11→11
* 開始   : 2026-08-09 18:50:00 (UTC)
* 終了   : 2026-08-09 19:30:00 (UTC)
* 現象   : 2026-08-09 19:30:00 (UTC)を境に水準が 11.74から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.561, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→9→6→9→6→9→8
* 開始   : 2026-08-09 22:30:00 (UTC)
* 終了   : 2026-08-09 22:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260809-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→9→11→5→…→11→5→10→8
* 開始   : 2026-08-09 23:50:00 (UTC)
* 終了   : 2026-08-09 23:55:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→7→8→10→10→9→9→9→11
* 開始   : 2026-08-10 01:10:00 (UTC)
* 終了   : 2026-08-10 02:10:00 (UTC)
* 現象   : 2026-08-10 02:10:00 (UTC)を境に水準が 11.81から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.717, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→13→9→13→11→12→12→11→13
* 開始   : 2026-08-11 03:10:00 (UTC)
* 終了   : 2026-08-11 04:20:00 (UTC)
* 現象   : 2026-08-11 04:20:00 (UTC)を境に水準が 14.91から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.828, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→15→18→15→18→15→18→16
* 開始   : 2026-08-11 16:45:00 (UTC)
* 終了   : 2026-08-11 16:55:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→17→15→16→17→14→17→15→16
* 開始   : 2026-08-11 17:10:00 (UTC)
* 終了   : 2026-08-11 18:10:00 (UTC)
* 現象   : 2026-08-11 18:10:00 (UTC)を境に水準が 14.95から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→11→…→5→11→10→9
* 開始   : 2026-08-12 01:10:00 (UTC)
* 終了   : 2026-08-12 01:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→13→14→11→13→14→11→10
* 開始   : 2026-08-12 03:40:00 (UTC)
* 終了   : 2026-08-12 03:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→17→…→16→17→15→16
* 開始   : 2026-08-12 05:45:00 (UTC)
* 終了   : 2026-08-12 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→19→17→21→…→21→23→21→22
* 開始   : 2026-08-12 09:40:00 (UTC)
* 終了   : 2026-08-12 09:50:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→19→…→19→13→17→15
* 開始   : 2026-08-12 17:20:00 (UTC)
* 終了   : 2026-08-12 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→16→12→…→12→10→14→13
* 開始   : 2026-08-12 19:20:00 (UTC)
* 終了   : 2026-08-12 19:30:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→12→12→12→15→14→16
* 開始   : 2026-08-13 03:55:00 (UTC)
* 終了   : 2026-08-13 04:45:00 (UTC)
* 現象   : 2026-08-13 04:45:00 (UTC)を境に水準が 14.83から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.685, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→15→…→14→15→14→12
* 開始   : 2026-08-13 04:30:00 (UTC)
* 終了   : 2026-08-13 04:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260813-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→15→13→15→14
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→21→23→20→23→20→23→22→20
* 開始   : 2026-08-13 09:15:00 (UTC)
* 終了   : 2026-08-13 09:25:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 22→19→18→21→19→18→21→20
* 開始   : 2026-08-13 14:20:00 (UTC)
* 終了   : 2026-08-13 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260813-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→17→14→17→14→16
* 開始   : 2026-08-13 17:10:00 (UTC)
* 終了   : 2026-08-13 17:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→13→12→13→12→13
* 開始   : 2026-08-13 18:35:00 (UTC)
* 終了   : 2026-08-13 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→17→11→14→17→11→13
* 開始   : 2026-08-13 18:50:00 (UTC)
* 終了   : 2026-08-13 18:55:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→12→13→11→12
* 開始   : 2026-08-13 19:20:00 (UTC)
* 終了   : 2026-08-13 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→12→8→10→12→8→10
* 開始   : 2026-08-13 20:45:00 (UTC)
* 終了   : 2026-08-13 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260813-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260813-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→10→6→10→6→9→8
* 開始   : 2026-08-13 22:20:00 (UTC)
* 終了   : 2026-08-13 22:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-065 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260813-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host09-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host09-020 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→9→8→9→8→8→7→8→10
* 開始   : 2026-08-13 23:50:00 (UTC)
* 終了   : 2026-08-14 00:35:00 (UTC)
* 現象   : 2026-08-14 00:35:00 (UTC)を境に水準が 14.96から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.552, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host09-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→7→9→9→8→11→10→8→12
* 開始   : 2026-08-14 01:00:00 (UTC)
* 終了   : 2026-08-14 02:15:00 (UTC)
* 現象   : 2026-08-14 02:15:00 (UTC)を境に水準が 14.92から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.997, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→10→…→10→6→9→8
* 開始   : 2026-08-14 01:50:00 (UTC)
* 終了   : 2026-08-14 02:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→13→…→13→15→13→12
* 開始   : 2026-08-14 04:40:00 (UTC)
* 終了   : 2026-08-14 04:50:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→14→16→14→13
* 開始   : 2026-08-14 05:20:00 (UTC)
* 終了   : 2026-08-14 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→16→…→17→19→17→14
* 開始   : 2026-08-14 06:15:00 (UTC)
* 終了   : 2026-08-14 06:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260814-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→21→24→20→…→20→25→20→22
* 開始   : 2026-08-14 10:05:00 (UTC)
* 終了   : 2026-08-14 10:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→20→19→19→18
* 開始   : 2026-08-14 16:20:00 (UTC)
* 終了   : 2026-08-14 17:30:00 (UTC)
* 現象   : 2026-08-14 17:30:00 (UTC)を境に水準が 14.97から12.37へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→16→14→13→…→14→13→15→17
* 開始   : 2026-08-14 17:40:00 (UTC)
* 終了   : 2026-08-14 17:45:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→12→11→14→16→12→11→14→13
* 開始   : 2026-08-14 18:25:00 (UTC)
* 終了   : 2026-08-14 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→16→12→14
* 開始   : 2026-08-14 18:30:00 (UTC)
* 終了   : 2026-08-14 18:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260814-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host09-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→10→9→9→9→10→11
* 開始   : 2026-08-14 21:45:00 (UTC)
* 終了   : 2026-08-14 22:35:00 (UTC)
* 現象   : 2026-08-14 22:35:00 (UTC)を境に水準が 14.98から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→8→11→8→11→8→10→11
* 開始   : 2026-08-15 04:15:00 (UTC)
* 終了   : 2026-08-15 04:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260815-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→7→5→9→…→9→11→9→8
* 開始   : 2026-08-16 00:20:00 (UTC)
* 終了   : 2026-08-16 00:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 7→11→5→8→7→11→5→8→11
* 開始   : 2026-08-16 02:10:00 (UTC)
* 終了   : 2026-08-16 02:15:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→13→11→8→12→13→11
* 開始   : 2026-08-16 05:15:00 (UTC)
* 終了   : 2026-08-16 05:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→9→15→13→9→15→13→12
* 開始   : 2026-08-16 07:05:00 (UTC)
* 終了   : 2026-08-16 07:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260816-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260816-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→15→13→12→…→13→12→16→15
* 開始   : 2026-08-16 13:30:00 (UTC)
* 終了   : 2026-08-16 13:35:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260816-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→14→15→15→16→16
* 開始   : 2026-08-16 15:20:00 (UTC)
* 終了   : 2026-08-16 15:45:00 (UTC)
* 現象   : 2026-08-16 15:45:00 (UTC)を境に水準が 11.83から14.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→7→11→9→11→9→11→9→8
* 開始   : 2026-08-17 01:10:00 (UTC)
* 終了   : 2026-08-17 01:20:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260817-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260817-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→10→10→11→11→11→11
* 開始   : 2026-08-17 02:40:00 (UTC)
* 終了   : 2026-08-17 03:20:00 (UTC)
* 現象   : 2026-08-17 03:20:00 (UTC)を境に水準が 11.86から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.701, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 8→9→6→10→…→10→5→8→9
* 開始   : 2026-08-17 21:55:00 (UTC)
* 終了   : 2026-08-17 22:05:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260817-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260817-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 7→10→10→8→9→10→10→12
* 開始   : 2026-08-18 01:20:00 (UTC)
* 終了   : 2026-08-18 01:55:00 (UTC)
* 現象   : 2026-08-18 01:55:00 (UTC)を境に水準が 15.12から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→16→18→17→18→20
* 開始   : 2026-08-18 06:45:00 (UTC)
* 終了   : 2026-08-18 07:15:00 (UTC)
* 現象   : 2026-08-18 07:15:00 (UTC)を境に水準が 15.04から15.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.724σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→16→18→20→16
* 開始   : 2026-08-18 07:25:00 (UTC)
* 終了   : 2026-08-18 07:30:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.237倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.687σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→15→20→16→15→20→16→17
* 開始   : 2026-08-18 15:50:00 (UTC)
* 終了   : 2026-08-18 16:00:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.7792(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→14→17→14→17→14→16→15
* 開始   : 2026-08-18 17:15:00 (UTC)
* 終了   : 2026-08-18 17:25:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→14→13→12→16→14→13→12→16
* 開始   : 2026-08-18 17:30:00 (UTC)
* 終了   : 2026-08-18 17:35:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→19→16→14→13→19→17
* 開始   : 2026-08-18 17:30:00 (UTC)
* 終了   : 2026-08-18 17:35:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host09-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→12→11→12→11
* 開始   : 2026-08-18 19:15:00 (UTC)
* 終了   : 2026-08-18 19:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 8→7→11→12→…→11→12→10→9
* 開始   : 2026-08-18 22:50:00 (UTC)
* 終了   : 2026-08-18 22:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260818-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→13→11→11→10→14
* 開始   : 2026-08-19 03:05:00 (UTC)
* 終了   : 2026-08-19 03:30:00 (UTC)
* 現象   : 2026-08-19 03:30:00 (UTC)を境に水準が 14.85から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.252, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→18→20→18→20→18→17
* 開始   : 2026-08-19 07:40:00 (UTC)
* 終了   : 2026-08-19 07:45:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.237倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 21→19→22→19→22→19→20
* 開始   : 2026-08-19 08:50:00 (UTC)
* 終了   : 2026-08-19 08:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→20→18→19→…→19→24→21→23
* 開始   : 2026-08-19 13:25:00 (UTC)
* 終了   : 2026-08-19 13:35:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260819-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→13→…→12→13→12→13
* 開始   : 2026-08-19 18:00:00 (UTC)
* 終了   : 2026-08-19 18:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→11→14→7→…→14→7→9→11
* 開始   : 2026-08-19 21:35:00 (UTC)
* 終了   : 2026-08-19 21:40:00 (UTC)
* 現象   : 平常時(10)に対し 1.4倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 7→8→11→4→…→11→4→9→8
* 開始   : 2026-08-20 00:50:00 (UTC)
* 終了   : 2026-08-20 00:55:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→25→19→23→21→25→19→23
* 開始   : 2026-08-20 11:05:00 (UTC)
* 終了   : 2026-08-20 11:10:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→14→…→8→14→13→10
* 開始   : 2026-08-20 20:45:00 (UTC)
* 終了   : 2026-08-20 21:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-070 (他ホスト) lsf_queue / susp : WARN / 重なり 30 分
  - EVT-20260820-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260820-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→16→13→14→15→16→13
* 開始   : 2026-08-21 05:00:00 (UTC)
* 終了   : 2026-08-21 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→17→13→18→17→13→18→17→16
* 開始   : 2026-08-21 06:10:00 (UTC)
* 終了   : 2026-08-21 06:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 20→23→20→23→20→23→21
* 開始   : 2026-08-21 09:15:00 (UTC)
* 終了   : 2026-08-21 09:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→12→10→12→10→12→10→13→12
* 開始   : 2026-08-21 19:20:00 (UTC)
* 終了   : 2026-08-21 19:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.733σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→…→13→16→11→12
* 開始   : 2026-08-21 19:35:00 (UTC)
* 終了   : 2026-08-21 19:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→9→11→10→…→10→11→10→11
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 05:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260822-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 9→9→8→8→8→9→11→11→10
* 開始   : 2026-08-23 01:35:00 (UTC)
* 終了   : 2026-08-23 02:25:00 (UTC)
* 現象   : 2026-08-23 02:25:00 (UTC)を境に水準が 11.77から11.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→7→12→10→…→10→6→8→11
* 開始   : 2026-08-23 02:45:00 (UTC)
* 終了   : 2026-08-23 02:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260823-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→11→13→10→13→10→13→11
* 開始   : 2026-08-23 05:00:00 (UTC)
* 終了   : 2026-08-23 05:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→9→12→6→9→12→8
* 開始   : 2026-08-23 22:50:00 (UTC)
* 終了   : 2026-08-23 23:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260823-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→12
* 開始   : 2026-08-25 03:05:00 (UTC)
* 終了   : 2026-08-25 03:20:00 (UTC)
* 現象   : 2026-08-25 03:20:00 (UTC)を境に水準が 14.83から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→17→13→16→13→16→13→16→14
* 開始   : 2026-08-25 17:45:00 (UTC)
* 終了   : 2026-08-25 17:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→10→…→11→10→15→11
* 開始   : 2026-08-25 19:15:00 (UTC)
* 終了   : 2026-08-25 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→13→12→12→11→12→14→12
* 開始   : 2026-08-26 03:10:00 (UTC)
* 終了   : 2026-08-26 03:45:00 (UTC)
* 現象   : 2026-08-26 03:45:00 (UTC)を境に水準が 15.08から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.336, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→9→13→9→12
* 開始   : 2026-08-26 03:15:00 (UTC)
* 終了   : 2026-08-26 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→14→18→16→18→16→18→13→17
* 開始   : 2026-08-26 06:10:00 (UTC)
* 終了   : 2026-08-26 06:50:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→19→17→16→19→17→16
* 開始   : 2026-08-26 07:20:00 (UTC)
* 終了   : 2026-08-26 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260826-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→25→19→23→22→25→19→23→22
* 開始   : 2026-08-26 13:00:00 (UTC)
* 終了   : 2026-08-26 13:05:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260826-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→21→23→22→18→21→22→23→22
* 開始   : 2026-08-26 14:00:00 (UTC)
* 終了   : 2026-08-26 15:10:00 (UTC)
* 現象   : 2026-08-26 15:10:00 (UTC)を境に水準が 15から15.19へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→17→21→15→…→16→21→15→16
* 開始   : 2026-08-26 16:45:00 (UTC)
* 終了   : 2026-08-26 16:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260826-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→12→13→11→12→13→11→15→16
* 開始   : 2026-08-26 18:35:00 (UTC)
* 終了   : 2026-08-26 18:45:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→8→10→8→10→8→10
* 開始   : 2026-08-26 20:50:00 (UTC)
* 終了   : 2026-08-26 21:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 7→8→6→5→…→6→5→9→8
* 開始   : 2026-08-26 22:50:00 (UTC)
* 終了   : 2026-08-26 22:55:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→9→5→12→…→5→12→7→9
* 開始   : 2026-08-27 01:15:00 (UTC)
* 終了   : 2026-08-27 01:20:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→12→12→12→14→16→12
* 開始   : 2026-08-27 02:55:00 (UTC)
* 終了   : 2026-08-27 04:35:00 (UTC)
* 現象   : 2026-08-27 04:35:00 (UTC)を境に水準が 15.14から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.117, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→18→17→18→15→14
* 開始   : 2026-08-27 06:10:00 (UTC)
* 終了   : 2026-08-27 07:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260827-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260827-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260827-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 20→18→21→20→19→20→20→20→21
* 開始   : 2026-08-27 08:00:00 (UTC)
* 終了   : 2026-08-27 08:50:00 (UTC)
* 現象   : 2026-08-27 08:50:00 (UTC)を境に水準が 15.2から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→15→13→15→13→14
* 開始   : 2026-08-27 17:50:00 (UTC)
* 終了   : 2026-08-27 18:00:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→5→7→11→5→7→11→8→9
* 開始   : 2026-08-27 22:25:00 (UTC)
* 終了   : 2026-08-27 23:40:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-090 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260827-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→13→12→10→12→13→12
* 開始   : 2026-08-28 03:10:00 (UTC)
* 終了   : 2026-08-28 03:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260828-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→15→14→16→17→15→14
* 開始   : 2026-08-28 05:45:00 (UTC)
* 終了   : 2026-08-28 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→17→18→17→16→17→18→17→15
* 開始   : 2026-08-28 06:10:00 (UTC)
* 終了   : 2026-08-28 06:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→15→20→17→…→17→21→18→20
* 開始   : 2026-08-28 07:40:00 (UTC)
* 終了   : 2026-08-28 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260828-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→20→22→19→20→22→19→22
* 開始   : 2026-08-28 09:25:00 (UTC)
* 終了   : 2026-08-28 09:30:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→18→16→18→…→18→15→17→18
* 開始   : 2026-08-28 16:20:00 (UTC)
* 終了   : 2026-08-28 16:30:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→18→14→17→18→14→17→15
* 開始   : 2026-08-28 16:55:00 (UTC)
* 終了   : 2026-08-28 17:00:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→17→13→12→…→13→12→14→12
* 開始   : 2026-08-28 18:25:00 (UTC)
* 終了   : 2026-08-28 18:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→11→10→9→…→10→9→15→12
* 開始   : 2026-08-28 19:45:00 (UTC)
* 終了   : 2026-08-28 20:25:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260828-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260828-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→11→7→8
* 開始   : 2026-08-28 21:50:00 (UTC)
* 終了   : 2026-08-28 21:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host09-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→8→9→9
* 開始   : 2026-08-28 22:05:00 (UTC)
* 終了   : 2026-08-28 22:30:00 (UTC)
* 現象   : 2026-08-28 22:30:00 (UTC)を境に水準が 14.84から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.331, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host09-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→9→10→…→10→11→10→11
* 開始   : 2026-08-29 04:25:00 (UTC)
* 終了   : 2026-08-29 04:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.132, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260829-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260829-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host09-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→9→8→9→11→10
* 開始   : 2026-08-29 20:00:00 (UTC)
* 終了   : 2026-08-29 20:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-lsfhost01-037 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260829-host09-010 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
