# host10 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host10 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 273 (SEVERE: 20, FATAL: 110, WARN: 143, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 110 | 143 | 273 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→17→…→13→14→13→12
* 開始   : 2026-07-06 01:40:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.89から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.786, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-002 active_connections の推移](charts/EVT-20260706-host10-002.svg)

# イベントID( EVT-20260706-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→18→17→15→…→15→14→13→12
* 開始   : 2026-07-06 03:00:00 (UTC)
* 終了   : 2026-07-06 21:35:00 (UTC)
* 現象   : 2026-07-06 21:35:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.851, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.381, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-005 active_connections の推移](charts/EVT-20260706-host10-005.svg)

# イベントID( EVT-20260706-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→17→15→14→…→13→11→13→14
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:30:00 (UTC)
* 現象   : 2026-07-06 20:30:00 (UTC)を境に水準が 11.93から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.652, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-006 active_connections の推移](charts/EVT-20260706-host10-006.svg)

# イベントID( EVT-20260706-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→14→…→11→15→13→12
* 開始   : 2026-07-06 04:15:00 (UTC)
* 終了   : 2026-07-06 19:50:00 (UTC)
* 現象   : 2026-07-06 19:50:00 (UTC)を境に水準が 11.79から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.966, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-007 active_connections の推移](charts/EVT-20260706-host10-007.svg)

# イベントID( EVT-20260713-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→14→…→13→15→14→13
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 19:25:00 (UTC)
* 現象   : 2026-07-13 19:25:00 (UTC)を境に水準が 11.91から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.22, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-002 active_connections の推移](charts/EVT-20260713-host10-002.svg)

# イベントID( EVT-20260713-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→17→20→18→…→15→14→13→15
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 20:30:00 (UTC)
* 現象   : 2026-07-13 20:30:00 (UTC)を境に水準が 11.83から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.644, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-003 active_connections の推移](charts/EVT-20260713-host10-003.svg)

# イベントID( EVT-20260713-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→13→15→14→…→14→15→12→14
* 開始   : 2026-07-13 02:30:00 (UTC)
* 終了   : 2026-07-13 21:25:00 (UTC)
* 現象   : 2026-07-13 21:25:00 (UTC)を境に水準が 11.83から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.67, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-004 active_connections の推移](charts/EVT-20260713-host10-004.svg)

# イベントID( EVT-20260713-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→17→…→15→14→12→13
* 開始   : 2026-07-13 02:35:00 (UTC)
* 終了   : 2026-07-13 20:25:00 (UTC)
* 現象   : 2026-07-13 20:25:00 (UTC)を境に水準が 11.86から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.739σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.911, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.177, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-005 active_connections の推移](charts/EVT-20260713-host10-005.svg)

# イベントID( EVT-20260713-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→18→…→15→14→13→12
* 開始   : 2026-07-13 03:35:00 (UTC)
* 終了   : 2026-07-13 20:15:00 (UTC)
* 現象   : 2026-07-13 20:15:00 (UTC)を境に水準が 11.96から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.781, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-007 active_connections の推移](charts/EVT-20260713-host10-007.svg)

# イベントID( EVT-20260714-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→20→18→20→18→15→20
* 開始   : 2026-07-14 16:25:00 (UTC)
* 終了   : 2026-07-14 18:35:00 (UTC)
* 現象   : 2026-07-14 18:35:00 (UTC)を境に水準が 15.04から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.624, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host10-010 active_connections の推移](charts/EVT-20260714-host10-010.svg)

# イベントID( EVT-20260720-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→15→16→15→…→13→14→12→13
* 開始   : 2026-07-20 01:45:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.78から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.075, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.436, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-001 active_connections の推移](charts/EVT-20260720-host10-001.svg)

# イベントID( EVT-20260720-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→15→…→14→11→10→13
* 開始   : 2026-07-20 02:15:00 (UTC)
* 終了   : 2026-07-20 19:35:00 (UTC)
* 現象   : 2026-07-20 19:35:00 (UTC)を境に水準が 11.81から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.852σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.186, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.52, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-002 active_connections の推移](charts/EVT-20260720-host10-002.svg)

# イベントID( EVT-20260720-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→15→16→15→…→14→15→12→14
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 20:20:00 (UTC)
* 現象   : 2026-07-20 20:20:00 (UTC)を境に水準が 11.95から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.894, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.423, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-004 active_connections の推移](charts/EVT-20260720-host10-004.svg)

# イベントID( EVT-20260720-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→16→…→15→13→15→13
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 21:10:00 (UTC)
* 現象   : 2026-07-20 21:10:00 (UTC)を境に水準が 11.88から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.776, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-006 active_connections の推移](charts/EVT-20260720-host10-006.svg)

# イベントID( EVT-20260727-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→17→14→16→…→16→13→16→13
* 開始   : 2026-07-27 02:00:00 (UTC)
* 終了   : 2026-07-27 21:20:00 (UTC)
* 現象   : 2026-07-27 21:20:00 (UTC)を境に水準が 11.73から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-001 active_connections の推移](charts/EVT-20260727-host10-001.svg)

# イベントID( EVT-20260727-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→15→…→14→12→11→12
* 開始   : 2026-07-27 02:30:00 (UTC)
* 終了   : 2026-07-27 18:55:00 (UTC)
* 現象   : 2026-07-27 18:55:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.808, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-002 active_connections の推移](charts/EVT-20260727-host10-002.svg)

# イベントID( EVT-20260727-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→15→14→12→…→13→15→13→14
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 21:00:00 (UTC)
* 現象   : 2026-07-27 21:00:00 (UTC)を境に水準が 11.73から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.795, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-003 active_connections の推移](charts/EVT-20260727-host10-003.svg)

# イベントID( EVT-20260727-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→17→16→17→…→13→12→13→12
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 21:55:00 (UTC)
* 現象   : 2026-07-27 21:55:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-004 active_connections の推移](charts/EVT-20260727-host10-004.svg)

# イベントID( EVT-20260727-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→17→14→15→…→14→13→11→12
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 20:45:00 (UTC)
* 現象   : 2026-07-27 20:45:00 (UTC)を境に水準が 11.84から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.918σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.17, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-005 active_connections の推移](charts/EVT-20260727-host10-005.svg)

# イベントID( EVT-20260727-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→18→17→15→…→13→15→12→14
* 開始   : 2026-07-27 03:20:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.98から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.12, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host10-006 active_connections の推移](charts/EVT-20260727-host10-006.svg)

# イベントID( EVT-20260701-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 23→21→26→19→21→26→19→21→23
* 開始   : 2026-07-01 10:55:00 (UTC)
* 終了   : 2026-07-01 11:00:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 23→23→26→22→22
* 開始   : 2026-07-01 12:20:00 (UTC)
* 終了   : 2026-07-01 12:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→10→15→14→…→14→16→14→13
* 開始   : 2026-07-02 04:50:00 (UTC)
* 終了   : 2026-07-02 05:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260702-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→17→18
* 開始   : 2026-07-02 06:50:00 (UTC)
* 終了   : 2026-07-02 06:50:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→19→24→20→20
* 開始   : 2026-07-02 08:30:00 (UTC)
* 終了   : 2026-07-02 08:30:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.321倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host10-005 active_connections の推移](charts/EVT-20260702-host10-005.svg)

# イベントID( EVT-20260702-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→11→16→14→…→14→10→11→12
* 開始   : 2026-07-02 19:35:00 (UTC)
* 終了   : 2026-07-02 20:15:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675倍(9)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260702-host02-019 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260702-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→18→23→20→21
* 開始   : 2026-07-03 08:55:00 (UTC)
* 終了   : 2026-07-03 08:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→13→…→12→11→10→12
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 19:25:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260704-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260704-host10-001 active_connections の推移](charts/EVT-20260704-host10-001.svg)

# イベントID( EVT-20260704-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→11→…→12→11→10→12
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 20:35:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.781, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260704-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260704-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260704-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260704-host10-002 active_connections の推移](charts/EVT-20260704-host10-002.svg)

# イベントID( EVT-20260704-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→10→…→9→10→11→13
* 開始   : 2026-07-04 05:20:00 (UTC)
* 終了   : 2026-07-04 20:25:00 (UTC)
* 現象   : 15.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.053, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260704-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260704-host10-003 active_connections の推移](charts/EVT-20260704-host10-003.svg)

# イベントID( EVT-20260704-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→13→…→15→13→15→13
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.736, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260704-host10-004 active_connections の推移](charts/EVT-20260704-host10-004.svg)

# イベントID( EVT-20260704-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 9→12→11→12→…→11→13→11→13
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 20:40:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.748, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260704-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260704-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260704-host10-005 active_connections の推移](charts/EVT-20260704-host10-005.svg)

# イベントID( EVT-20260704-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→13→…→12→10→11→9
* 開始   : 2026-07-04 06:00:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260704-host10-006 active_connections の推移](charts/EVT-20260704-host10-006.svg)

# イベントID( EVT-20260705-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→11→12→10→15
* 開始   : 2026-07-05 05:10:00 (UTC)
* 終了   : 2026-07-05 05:30:00 (UTC)
* 現象   : 2026-07-05 05:30:00 (UTC)を境に水準が 11.84から12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.691, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→15→11→15→14
* 開始   : 2026-07-05 14:10:00 (UTC)
* 終了   : 2026-07-05 14:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→12→9
* 開始   : 2026-07-05 20:15:00 (UTC)
* 終了   : 2026-07-05 20:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→16→…→14→13→14→12
* 開始   : 2026-07-06 01:35:00 (UTC)
* 終了   : 2026-07-06 20:40:00 (UTC)
* 現象   : 2026-07-06 20:40:00 (UTC)を境に水準が 11.75から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.009, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.789, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→16→…→13→15→11→13
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.94から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.024, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.419, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-004 active_connections の推移](charts/EVT-20260706-host10-004.svg)

# イベントID( EVT-20260707-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 6→9→13→10→11
* 開始   : 2026-07-07 02:55:00 (UTC)
* 終了   : 2026-07-07 02:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→15→13
* 開始   : 2026-07-07 05:35:00 (UTC)
* 終了   : 2026-07-07 05:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→20→26→22→23
* 開始   : 2026-07-07 11:15:00 (UTC)
* 終了   : 2026-07-07 11:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→11→17→13→14
* 開始   : 2026-07-08 05:20:00 (UTC)
* 終了   : 2026-07-08 05:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→9→5→9→8
* 開始   : 2026-07-08 22:10:00 (UTC)
* 終了   : 2026-07-08 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 7→8→12→8→7
* 開始   : 2026-07-08 23:55:00 (UTC)
* 終了   : 2026-07-08 23:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→11→16→13→12
* 開始   : 2026-07-09 04:25:00 (UTC)
* 終了   : 2026-07-09 04:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→18→17→16→…→16→18→16→17
* 開始   : 2026-07-09 06:10:00 (UTC)
* 終了   : 2026-07-09 06:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260709-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260709-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→18→23→21→18→23→21→20
* 開始   : 2026-07-09 08:25:00 (UTC)
* 終了   : 2026-07-09 09:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.302倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.739σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260709-host10-003 active_connections の推移](charts/EVT-20260709-host10-003.svg)

# イベントID( EVT-20260709-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→22→18→23→22→18→23→18→20
* 開始   : 2026-07-09 08:35:00 (UTC)
* 終了   : 2026-07-09 08:45:00 (UTC)
* 現象   : 平常時(18)に対し 1.222倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260709-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→16→14
* 開始   : 2026-07-10 05:50:00 (UTC)
* 終了   : 2026-07-10 05:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→13→9→11→…→12→10→12→13
* 開始   : 2026-07-11 04:15:00 (UTC)
* 終了   : 2026-07-11 19:20:00 (UTC)
* 現象   : 15.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.821, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host10-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260711-host10-002 active_connections の推移](charts/EVT-20260711-host10-002.svg)

# イベントID( EVT-20260711-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→12→13→12→11
* 開始   : 2026-07-11 04:40:00 (UTC)
* 終了   : 2026-07-11 17:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.966, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260711-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host10-003 active_connections の推移](charts/EVT-20260711-host10-003.svg)

# イベントID( EVT-20260711-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→13→…→10→12→16→10
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.369, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260711-host10-005 active_connections の推移](charts/EVT-20260711-host10-005.svg)

# イベントID( EVT-20260711-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→13→…→11→13→15→12
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.822, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host10-006 active_connections の推移](charts/EVT-20260711-host10-006.svg)

# イベントID( EVT-20260711-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→12→11→12→…→12→10→12→10
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.859, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260711-host10-007 active_connections の推移](charts/EVT-20260711-host10-007.svg)

# イベントID( EVT-20260711-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→11→…→14→12→13→11
* 開始   : 2026-07-11 06:25:00 (UTC)
* 終了   : 2026-07-11 18:50:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260711-host10-008 active_connections の推移](charts/EVT-20260711-host10-008.svg)

# イベントID( EVT-20260712-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→15→14
* 開始   : 2026-07-12 07:10:00 (UTC)
* 終了   : 2026-07-12 07:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.427倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host10-002 active_connections の推移](charts/EVT-20260712-host10-002.svg)

# イベントID( EVT-20260712-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→14→19→16→14
* 開始   : 2026-07-12 10:30:00 (UTC)
* 終了   : 2026-07-12 10:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→11→4→9→7
* 開始   : 2026-07-12 22:35:00 (UTC)
* 終了   : 2026-07-12 22:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→18→17→14→…→14→13→11→12
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 19:30:00 (UTC)
* 現象   : 2026-07-13 19:30:00 (UTC)を境に水準が 11.84から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.894, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→6→13→9→9
* 開始   : 2026-07-14 01:45:00 (UTC)
* 終了   : 2026-07-14 01:45:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→8→14→9→10
* 開始   : 2026-07-14 02:40:00 (UTC)
* 終了   : 2026-07-14 02:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.745σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host10-002 active_connections の推移](charts/EVT-20260714-host10-002.svg)

# イベントID( EVT-20260714-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→12→16→12→11
* 開始   : 2026-07-14 04:30:00 (UTC)
* 終了   : 2026-07-14 04:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→15→18→14→15
* 開始   : 2026-07-14 05:35:00 (UTC)
* 終了   : 2026-07-14 05:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host10-007 active_connections の推移](charts/EVT-20260714-host10-007.svg)

# イベントID( EVT-20260714-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→15→11→12→…→12→10→14→12
* 開始   : 2026-07-14 17:10:00 (UTC)
* 終了   : 2026-07-14 19:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260714-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260714-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→11→12
* 開始   : 2026-07-14 19:50:00 (UTC)
* 終了   : 2026-07-14 19:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.5926(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.841σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host10-012 active_connections の推移](charts/EVT-20260714-host10-012.svg)

# イベントID( EVT-20260715-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→10→13→9→6→13→9→6→10
* 開始   : 2026-07-15 02:25:00 (UTC)
* 終了   : 2026-07-15 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260715-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 21→22→17→20→19
* 開始   : 2026-07-15 14:45:00 (UTC)
* 終了   : 2026-07-15 14:45:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→9→5→10→9
* 開始   : 2026-07-15 22:20:00 (UTC)
* 終了   : 2026-07-15 22:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→8→12→8→9
* 開始   : 2026-07-16 01:15:00 (UTC)
* 終了   : 2026-07-16 01:15:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→8→14→10→8
* 開始   : 2026-07-16 02:55:00 (UTC)
* 終了   : 2026-07-16 02:55:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→16→16
* 開始   : 2026-07-16 06:20:00 (UTC)
* 終了   : 2026-07-16 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→22→26→22→21
* 開始   : 2026-07-16 11:25:00 (UTC)
* 終了   : 2026-07-16 11:25:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260716-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→18→18
* 開始   : 2026-07-16 16:20:00 (UTC)
* 終了   : 2026-07-16 16:20:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→14→12→13→…→12→13→15→13
* 開始   : 2026-07-16 18:00:00 (UTC)
* 終了   : 2026-07-16 18:05:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→16→11→16→14
* 開始   : 2026-07-16 18:10:00 (UTC)
* 終了   : 2026-07-16 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→15→20→18→16
* 開始   : 2026-07-17 06:50:00 (UTC)
* 終了   : 2026-07-17 07:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→14→17→17
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→12→11→12→…→10→11→12→9
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.667σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.784, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host10-002 active_connections の推移](charts/EVT-20260718-host10-002.svg)

# イベントID( EVT-20260718-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→14→…→14→10→11→12
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.987, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260718-host10-003 active_connections の推移](charts/EVT-20260718-host10-003.svg)

# イベントID( EVT-20260718-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→12→9→11→…→12→13→12→11
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.013, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260718-host10-004 active_connections の推移](charts/EVT-20260718-host10-004.svg)

# イベントID( EVT-20260718-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→8→10→12→…→10→11→13→10
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 20:35:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260718-host10-005 active_connections の推移](charts/EVT-20260718-host10-005.svg)

# イベントID( EVT-20260718-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→12→…→9→11→13→11
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.931, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host10-006 active_connections の推移](charts/EVT-20260718-host10-006.svg)

# イベントID( EVT-20260718-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→11→14→15→…→11→12→11→12
* 開始   : 2026-07-18 06:10:00 (UTC)
* 終了   : 2026-07-18 19:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.908, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host10-007 active_connections の推移](charts/EVT-20260718-host10-007.svg)

# イベントID( EVT-20260719-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→6→13→8→8
* 開始   : 2026-07-19 02:30:00 (UTC)
* 終了   : 2026-07-19 02:30:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→5→8→9
* 開始   : 2026-07-19 03:30:00 (UTC)
* 終了   : 2026-07-19 03:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→11→10
* 開始   : 2026-07-19 06:35:00 (UTC)
* 終了   : 2026-07-19 06:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→8→4→8→9
* 開始   : 2026-07-19 23:00:00 (UTC)
* 終了   : 2026-07-19 23:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→15→13→14→…→11→14→11→12
* 開始   : 2026-07-20 02:35:00 (UTC)
* 終了   : 2026-07-20 19:30:00 (UTC)
* 現象   : 2026-07-20 19:30:00 (UTC)を境に水準が 11.84から14.84へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.794, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→16→…→14→13→14→13
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 20:20:00 (UTC)
* 現象   : 2026-07-20 20:20:00 (UTC)を境に水準が 11.91から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.948, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→13→19→17→18→19→17→18→16
* 開始   : 2026-07-21 06:20:00 (UTC)
* 終了   : 2026-07-21 06:30:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→16→20→15→17
* 開始   : 2026-07-21 06:30:00 (UTC)
* 終了   : 2026-07-21 06:30:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host10-003 active_connections の推移](charts/EVT-20260721-host10-003.svg)

# イベントID( EVT-20260721-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→19→23→18→18
* 開始   : 2026-07-21 08:05:00 (UTC)
* 終了   : 2026-07-21 08:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.321倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.899σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260721-host10-005 active_connections の推移](charts/EVT-20260721-host10-005.svg)

# イベントID( EVT-20260722-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→16→19→13→14
* 開始   : 2026-07-22 06:00:00 (UTC)
* 終了   : 2026-07-22 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.373倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host10-002 active_connections の推移](charts/EVT-20260722-host10-002.svg)

# イベントID( EVT-20260722-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→18→20→17→19
* 開始   : 2026-07-22 07:00:00 (UTC)
* 終了   : 2026-07-22 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→14→10→14→13
* 開始   : 2026-07-22 18:40:00 (UTC)
* 終了   : 2026-07-22 18:40:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host10-008 active_connections の推移](charts/EVT-20260722-host10-008.svg)

# イベントID( EVT-20260722-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→10→5→8→8
* 開始   : 2026-07-22 22:40:00 (UTC)
* 終了   : 2026-07-22 22:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→7→13→7→10
* 開始   : 2026-07-23 02:25:00 (UTC)
* 終了   : 2026-07-23 02:25:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→21→17→21→20
* 開始   : 2026-07-23 14:40:00 (UTC)
* 終了   : 2026-07-23 14:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→8→13→8→13→8→13→10→9
* 開始   : 2026-07-24 02:45:00 (UTC)
* 終了   : 2026-07-24 02:55:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→16→16
* 開始   : 2026-07-24 06:20:00 (UTC)
* 終了   : 2026-07-24 06:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→21→17→20→19
* 開始   : 2026-07-24 14:55:00 (UTC)
* 終了   : 2026-07-24 14:55:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→19→16→19→15→16→19→15→18
* 開始   : 2026-07-24 16:20:00 (UTC)
* 終了   : 2026-07-24 17:20:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260724-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→8→13→11→9
* 開始   : 2026-07-25 02:00:00 (UTC)
* 終了   : 2026-07-25 02:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→12→13→12→…→12→10→13→11
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.009, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host10-003 active_connections の推移](charts/EVT-20260725-host10-003.svg)

# イベントID( EVT-20260725-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→11→…→13→11→13→11
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260725-host10-004 active_connections の推移](charts/EVT-20260725-host10-004.svg)

# イベントID( EVT-20260725-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→11→10→11→…→13→12→13→12
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 18:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.263, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260725-host10-005 active_connections の推移](charts/EVT-20260725-host10-005.svg)

# イベントID( EVT-20260725-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→9→12→11→…→11→13→11→13
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.333, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host10-006 active_connections の推移](charts/EVT-20260725-host10-006.svg)

# イベントID( EVT-20260725-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→11→13→9→…→12→11→13→12
* 開始   : 2026-07-25 05:45:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.983, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260725-host10-007 active_connections の推移](charts/EVT-20260725-host10-007.svg)

# イベントID( EVT-20260725-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→14→12→13→…→11→12→14→13
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.126, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host10-008 active_connections の推移](charts/EVT-20260725-host10-008.svg)

# イベントID( EVT-20260725-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→11→4→8→9
* 開始   : 2026-07-25 22:10:00 (UTC)
* 終了   : 2026-07-25 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.4248(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.803σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260725-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host10-010 active_connections の推移](charts/EVT-20260725-host10-010.svg)

# イベントID( EVT-20260726-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→8→13→9→9
* 開始   : 2026-07-26 03:40:00 (UTC)
* 終了   : 2026-07-26 03:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260726-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→12→7→10→12
* 開始   : 2026-07-26 19:10:00 (UTC)
* 終了   : 2026-07-26 19:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 7→7→12→8→7
* 開始   : 2026-07-26 23:20:00 (UTC)
* 終了   : 2026-07-26 23:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→7→13→11→9
* 開始   : 2026-07-28 02:50:00 (UTC)
* 終了   : 2026-07-28 02:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→13→16→14→14
* 開始   : 2026-07-28 04:30:00 (UTC)
* 終了   : 2026-07-28 04:30:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→14→14
* 開始   : 2026-07-28 04:45:00 (UTC)
* 終了   : 2026-07-28 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→11→11→10→7→10→10
* 開始   : 2026-07-29 01:20:00 (UTC)
* 終了   : 2026-07-29 03:05:00 (UTC)
* 現象   : 2026-07-29 03:05:00 (UTC)を境に水準が 15から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→17→17
* 開始   : 2026-07-29 06:40:00 (UTC)
* 終了   : 2026-07-29 06:40:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→17→21→18→17
* 開始   : 2026-07-29 07:25:00 (UTC)
* 終了   : 2026-07-29 07:25:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→18→22→20→19
* 開始   : 2026-07-29 08:35:00 (UTC)
* 終了   : 2026-07-29 08:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→20→16→22→19
* 開始   : 2026-07-29 15:45:00 (UTC)
* 終了   : 2026-07-29 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→11→9
* 開始   : 2026-07-30 02:10:00 (UTC)
* 終了   : 2026-07-30 02:10:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→21→25→23→23
* 開始   : 2026-07-30 10:30:00 (UTC)
* 終了   : 2026-07-30 10:30:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→9→3→8→7
* 開始   : 2026-07-30 23:45:00 (UTC)
* 終了   : 2026-07-30 23:45:00 (UTC)
* 現象   : 平常時(8)に対し 0.375(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host10-010 active_connections の推移](charts/EVT-20260730-host10-010.svg)

# イベントID( EVT-20260731-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→9→14→9→10
* 開始   : 2026-07-31 03:05:00 (UTC)
* 終了   : 2026-07-31 03:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→17→21→17→15
* 開始   : 2026-07-31 07:30:00 (UTC)
* 終了   : 2026-07-31 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→18→22→20→23→22→20→23→18
* 開始   : 2026-07-31 08:10:00 (UTC)
* 終了   : 2026-07-31 08:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host10-008 active_connections の推移](charts/EVT-20260731-host10-008.svg)

# イベントID( EVT-20260731-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 21→21→17→22→22
* 開始   : 2026-07-31 14:20:00 (UTC)
* 終了   : 2026-07-31 14:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260731-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→20→16→21→20
* 開始   : 2026-07-31 14:55:00 (UTC)
* 終了   : 2026-07-31 14:55:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→12→8→13→11
* 開始   : 2026-07-31 19:45:00 (UTC)
* 終了   : 2026-07-31 19:45:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→10→13→10→13→12→10
* 開始   : 2026-07-01 03:35:00 (UTC)
* 終了   : 2026-07-01 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260701-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→…→17→20→16→15
* 開始   : 2026-07-01 06:45:00 (UTC)
* 終了   : 2026-07-01 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→22→20→19→22→20→21
* 開始   : 2026-07-01 09:05:00 (UTC)
* 終了   : 2026-07-01 09:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→20→18→19→18→19→18→22→20
* 開始   : 2026-07-01 14:20:00 (UTC)
* 終了   : 2026-07-01 14:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→21→23→18→21→23→18→21
* 開始   : 2026-07-01 14:45:00 (UTC)
* 終了   : 2026-07-01 14:50:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→18→15→18→15→15→15→14→18
* 開始   : 2026-07-01 17:05:00 (UTC)
* 終了   : 2026-07-01 18:05:00 (UTC)
* 現象   : 2026-07-01 18:05:00 (UTC)を境に水準が 15.03から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→16→14→16→14→16→15
* 開始   : 2026-07-01 17:35:00 (UTC)
* 終了   : 2026-07-01 17:40:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→10→6→9→…→9→13→10→9
* 開始   : 2026-07-02 02:15:00 (UTC)
* 終了   : 2026-07-02 02:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→18→19→19→18→19→20→21→21
* 開始   : 2026-07-02 07:30:00 (UTC)
* 終了   : 2026-07-02 08:10:00 (UTC)
* 現象   : 2026-07-02 08:10:00 (UTC)を境に水準が 15.06から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→18→14→18→…→18→13→15→18
* 開始   : 2026-07-02 16:55:00 (UTC)
* 終了   : 2026-07-02 17:05:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→11→…→11→7→8→10
* 開始   : 2026-07-02 20:35:00 (UTC)
* 終了   : 2026-07-02 20:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→8→12→11→8→12→11→9
* 開始   : 2026-07-03 02:45:00 (UTC)
* 終了   : 2026-07-03 02:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→14→12→13→12→14→12→16→12
* 開始   : 2026-07-03 04:05:00 (UTC)
* 終了   : 2026-07-03 04:45:00 (UTC)
* 現象   : 2026-07-03 04:45:00 (UTC)を境に水準が 14.96から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→16→…→16→19→15→18
* 開始   : 2026-07-03 06:35:00 (UTC)
* 終了   : 2026-07-03 06:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260703-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 20→21→21→21→20→20→20→22
* 開始   : 2026-07-03 15:00:00 (UTC)
* 終了   : 2026-07-03 16:15:00 (UTC)
* 現象   : 2026-07-03 16:15:00 (UTC)を境に水準が 14.95から12.52へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→13→…→16→18→13→16
* 開始   : 2026-07-03 17:55:00 (UTC)
* 終了   : 2026-07-03 18:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260703-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→13→12→16→…→16→12→15→14
* 開始   : 2026-07-03 17:55:00 (UTC)
* 終了   : 2026-07-03 18:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260703-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→14→12→12→10→12→12
* 開始   : 2026-07-03 19:10:00 (UTC)
* 終了   : 2026-07-03 20:20:00 (UTC)
* 現象   : 2026-07-03 20:20:00 (UTC)を境に水準が 14.83から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→10→13→16→…→16→12→10→12
* 開始   : 2026-07-03 19:50:00 (UTC)
* 終了   : 2026-07-03 20:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260703-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→13→11→11→13→12→10→11
* 開始   : 2026-07-03 20:15:00 (UTC)
* 終了   : 2026-07-03 20:50:00 (UTC)
* 現象   : 2026-07-03 20:50:00 (UTC)を境に水準が 14.91から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→7→11→8→7→11
* 開始   : 2026-07-03 20:45:00 (UTC)
* 終了   : 2026-07-03 20:50:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host10-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→9→8→10→9→10
* 開始   : 2026-07-03 23:45:00 (UTC)
* 終了   : 2026-07-04 00:10:00 (UTC)
* 現象   : 2026-07-04 00:10:00 (UTC)を境に水準が 14.87から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→8→5→11→…→5→11→9→8
* 開始   : 2026-07-05 01:00:00 (UTC)
* 終了   : 2026-07-05 01:05:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→12→9→12→9→12→8→9
* 開始   : 2026-07-05 03:00:00 (UTC)
* 終了   : 2026-07-05 03:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260705-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260705-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→9→9→9→9→10→8
* 開始   : 2026-07-05 21:00:00 (UTC)
* 終了   : 2026-07-05 22:05:00 (UTC)
* 現象   : 2026-07-05 22:05:00 (UTC)を境に水準が 11.8から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.249, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→11→11→9→12→10→12
* 開始   : 2026-07-06 02:20:00 (UTC)
* 終了   : 2026-07-06 03:10:00 (UTC)
* 現象   : 2026-07-06 03:10:00 (UTC)を境に水準が 11.67から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.626, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→13→14→10→…→10→15→12→13
* 開始   : 2026-07-07 04:10:00 (UTC)
* 終了   : 2026-07-07 04:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260707-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→17→21→19→17→21→20
* 開始   : 2026-07-07 15:20:00 (UTC)
* 終了   : 2026-07-07 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→15→13→14
* 開始   : 2026-07-07 17:55:00 (UTC)
* 終了   : 2026-07-07 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→9→…→10→9→11→10
* 開始   : 2026-07-07 19:50:00 (UTC)
* 終了   : 2026-07-07 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→12→13→13→16→14
* 開始   : 2026-07-08 04:30:00 (UTC)
* 終了   : 2026-07-08 04:55:00 (UTC)
* 現象   : 2026-07-08 04:55:00 (UTC)を境に水準が 14.83から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→17→16→15→17→14→15
* 開始   : 2026-07-08 05:15:00 (UTC)
* 終了   : 2026-07-08 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→20→18→19→21→19→21
* 開始   : 2026-07-08 07:50:00 (UTC)
* 終了   : 2026-07-08 08:20:00 (UTC)
* 現象   : 2026-07-08 08:20:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.398, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 23→19→21→23→19→21→22
* 開始   : 2026-07-08 13:15:00 (UTC)
* 終了   : 2026-07-08 13:20:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260708-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→18→20→21→18→20
* 開始   : 2026-07-08 15:10:00 (UTC)
* 終了   : 2026-07-08 15:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→16→11→12→11→12→11→13
* 開始   : 2026-07-08 18:50:00 (UTC)
* 終了   : 2026-07-08 19:00:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→11→…→11→9→14→11
* 開始   : 2026-07-08 19:35:00 (UTC)
* 終了   : 2026-07-08 19:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260708-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→19→23→19→23→19→22→20
* 開始   : 2026-07-09 11:50:00 (UTC)
* 終了   : 2026-07-09 12:00:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→22→22→22
* 開始   : 2026-07-09 14:55:00 (UTC)
* 終了   : 2026-07-09 15:10:00 (UTC)
* 現象   : 2026-07-09 15:10:00 (UTC)を境に水準が 15.1から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→19→14→13→…→14→13→17→15
* 開始   : 2026-07-09 17:25:00 (UTC)
* 終了   : 2026-07-09 17:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→13→14→13→13
* 開始   : 2026-07-09 19:50:00 (UTC)
* 終了   : 2026-07-09 20:10:00 (UTC)
* 現象   : 2026-07-09 20:10:00 (UTC)を境に水準が 14.84から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.285, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→16→18→16→18
* 開始   : 2026-07-10 06:45:00 (UTC)
* 終了   : 2026-07-10 06:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→14→18→19→…→18→19→15→16
* 開始   : 2026-07-10 06:50:00 (UTC)
* 終了   : 2026-07-10 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→16→…→16→19→18→15
* 開始   : 2026-07-10 06:50:00 (UTC)
* 終了   : 2026-07-10 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→18→20→18→20→16→19
* 開始   : 2026-07-10 07:15:00 (UTC)
* 終了   : 2026-07-10 07:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.263倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→19→19→17→20→18→19→21→19
* 開始   : 2026-07-10 07:15:00 (UTC)
* 終了   : 2026-07-10 08:10:00 (UTC)
* 現象   : 2026-07-10 08:10:00 (UTC)を境に水準が 14.99から14.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.785, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→21→17→19→17→19→17→20→19
* 開始   : 2026-07-10 15:05:00 (UTC)
* 終了   : 2026-07-10 15:15:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→15→…→15→16→15→16
* 開始   : 2026-07-10 16:40:00 (UTC)
* 終了   : 2026-07-10 16:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260710-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260710-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→19→15→18→…→18→14→17→15
* 開始   : 2026-07-10 16:45:00 (UTC)
* 終了   : 2026-07-10 16:55:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host10-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260710-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→12→…→12→8→11→9
* 開始   : 2026-07-10 20:10:00 (UTC)
* 終了   : 2026-07-10 20:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-080 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→9→7→9→12→9→7→9→12
* 開始   : 2026-07-11 04:10:00 (UTC)
* 終了   : 2026-07-11 04:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→12→13
* 開始   : 2026-07-11 05:00:00 (UTC)
* 終了   : 2026-07-11 05:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→13→10→7→13→10→7→10
* 開始   : 2026-07-11 20:05:00 (UTC)
* 終了   : 2026-07-11 20:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260711-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260711-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260711-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260711-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→11→14→8→…→14→8→12→11
* 開始   : 2026-07-12 05:25:00 (UTC)
* 終了   : 2026-07-12 05:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→16→11→16→11→16→11→15→16
* 開始   : 2026-07-12 15:10:00 (UTC)
* 終了   : 2026-07-12 15:20:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分

![EVT-20260712-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→16→16→15→16→14→16→17
* 開始   : 2026-07-12 15:15:00 (UTC)
* 終了   : 2026-07-12 15:50:00 (UTC)
* 現象   : 2026-07-12 15:50:00 (UTC)を境に水準が 11.87から14.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→12→8→12→8→12→8→9
* 開始   : 2026-07-12 19:25:00 (UTC)
* 終了   : 2026-07-12 19:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260712-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→9→10→10→8→11→7→9→9
* 開始   : 2026-07-13 00:20:00 (UTC)
* 終了   : 2026-07-13 01:05:00 (UTC)
* 現象   : 2026-07-13 01:05:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→11→13→7→…→13→7→9→10
* 開始   : 2026-07-13 21:35:00 (UTC)
* 終了   : 2026-07-13 21:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260713-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→9→11→11→12→11→11→13
* 開始   : 2026-07-14 02:45:00 (UTC)
* 終了   : 2026-07-14 03:20:00 (UTC)
* 現象   : 2026-07-14 03:20:00 (UTC)を境に水準が 14.87から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→11→11→11→12→13→13→13→14
* 開始   : 2026-07-14 03:00:00 (UTC)
* 終了   : 2026-07-14 04:10:00 (UTC)
* 現象   : 2026-07-14 04:10:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→13→14→16→13→12
* 開始   : 2026-07-14 05:00:00 (UTC)
* 終了   : 2026-07-14 05:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260714-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→20→22→20→22→20→22→19
* 開始   : 2026-07-14 08:45:00 (UTC)
* 終了   : 2026-07-14 08:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260714-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 22→21→19→26→…→19→26→20→23
* 開始   : 2026-07-14 13:10:00 (UTC)
* 終了   : 2026-07-14 13:15:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260714-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host10-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→7→10→9→8→10
* 開始   : 2026-07-14 22:05:00 (UTC)
* 終了   : 2026-07-14 22:40:00 (UTC)
* 現象   : 2026-07-14 22:40:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→12→9→12→9→12→10→11
* 開始   : 2026-07-15 03:05:00 (UTC)
* 終了   : 2026-07-15 03:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→20→19→20→19→20→18→19
* 開始   : 2026-07-15 07:30:00 (UTC)
* 終了   : 2026-07-15 07:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 23→20→25→19→22→20→25→19→22
* 開始   : 2026-07-15 11:30:00 (UTC)
* 終了   : 2026-07-15 11:35:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→15→…→16→15→17→18
* 開始   : 2026-07-15 16:25:00 (UTC)
* 終了   : 2026-07-15 16:30:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→19→14→16→19→14→16→17
* 開始   : 2026-07-15 17:25:00 (UTC)
* 終了   : 2026-07-15 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260715-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→15→16→14→14→13→12→14→14
* 開始   : 2026-07-15 17:45:00 (UTC)
* 終了   : 2026-07-15 20:05:00 (UTC)
* 現象   : 2026-07-15 20:05:00 (UTC)を境に水準が 14.91から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.641, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→14→…→14→12→15→14
* 開始   : 2026-07-15 18:05:00 (UTC)
* 終了   : 2026-07-15 18:15:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host10-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→13→15→12→13→15→12→15→13
* 開始   : 2026-07-15 18:05:00 (UTC)
* 終了   : 2026-07-15 18:15:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host10-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→12
* 開始   : 2026-07-15 20:20:00 (UTC)
* 終了   : 2026-07-15 20:35:00 (UTC)
* 現象   : 2026-07-15 20:35:00 (UTC)を境に水準が 14.94から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→16→19→17→…→17→20→16→15
* 開始   : 2026-07-16 06:50:00 (UTC)
* 終了   : 2026-07-16 07:00:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→10→11→12→14→10→11→12→11
* 開始   : 2026-07-16 19:10:00 (UTC)
* 終了   : 2026-07-16 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7059(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→12→12→10→10→11→12
* 開始   : 2026-07-16 20:00:00 (UTC)
* 終了   : 2026-07-16 20:50:00 (UTC)
* 現象   : 2026-07-16 20:50:00 (UTC)を境に水準が 14.92から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host10-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→10→11→10→9
* 開始   : 2026-07-16 22:50:00 (UTC)
* 終了   : 2026-07-16 23:20:00 (UTC)
* 現象   : 2026-07-16 23:20:00 (UTC)を境に水準が 14.84から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 6→9→11→8→9→11→8→9
* 開始   : 2026-07-17 00:10:00 (UTC)
* 終了   : 2026-07-17 00:15:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→15→13→16→15→13→16→12→14
* 開始   : 2026-07-17 04:50:00 (UTC)
* 終了   : 2026-07-17 05:00:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260717-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→23→21→24→23→21→24→22→18
* 開始   : 2026-07-17 10:20:00 (UTC)
* 終了   : 2026-07-17 10:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260717-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→7→8→10→7→8→8→9→9
* 開始   : 2026-07-18 00:00:00 (UTC)
* 終了   : 2026-07-18 01:15:00 (UTC)
* 現象   : 2026-07-18 01:15:00 (UTC)を境に水準が 14.92から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260718-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→15→13→17→13→17→13→14
* 開始   : 2026-07-19 13:10:00 (UTC)
* 終了   : 2026-07-19 13:20:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→12→12→11→11→11
* 開始   : 2026-07-19 18:35:00 (UTC)
* 終了   : 2026-07-19 20:30:00 (UTC)
* 現象   : 2026-07-19 20:30:00 (UTC)を境に水準が 11.74から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→11→11→9→9→11→11
* 開始   : 2026-07-19 20:45:00 (UTC)
* 終了   : 2026-07-19 21:15:00 (UTC)
* 現象   : 2026-07-19 21:15:00 (UTC)を境に水準が 11.73から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→8→10→10→9→10
* 開始   : 2026-07-19 23:50:00 (UTC)
* 終了   : 2026-07-20 00:15:00 (UTC)
* 現象   : 2026-07-20 00:15:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→7→6→9→6→9→6→9
* 開始   : 2026-07-20 22:55:00 (UTC)
* 終了   : 2026-07-20 23:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260720-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260720-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260720-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→8→12→8→7
* 開始   : 2026-07-21 01:55:00 (UTC)
* 終了   : 2026-07-21 02:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→20→19→21→20→19→21→18
* 開始   : 2026-07-21 07:50:00 (UTC)
* 終了   : 2026-07-21 08:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260721-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 23→22→21→24→22→20→22→22→23
* 開始   : 2026-07-21 13:10:00 (UTC)
* 終了   : 2026-07-21 14:20:00 (UTC)
* 現象   : 2026-07-21 14:20:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→13→12→15→16→13→12→15
* 開始   : 2026-07-21 18:05:00 (UTC)
* 終了   : 2026-07-21 18:10:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→15→16→18→17→15→18
* 開始   : 2026-07-22 05:40:00 (UTC)
* 終了   : 2026-07-22 06:15:00 (UTC)
* 現象   : 2026-07-22 06:15:00 (UTC)を境に水準が 14.97から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→21→20→21→22→22→20→23→23
* 開始   : 2026-07-22 08:55:00 (UTC)
* 終了   : 2026-07-22 09:45:00 (UTC)
* 現象   : 2026-07-22 09:45:00 (UTC)を境に水準が 15.08から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→20→19→24→19→24→19→20→21
* 開始   : 2026-07-22 13:45:00 (UTC)
* 終了   : 2026-07-22 13:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→17→19→20→17→19→21
* 開始   : 2026-07-22 15:10:00 (UTC)
* 終了   : 2026-07-22 15:15:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.687σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260722-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→18→14→16→14→15→13
* 開始   : 2026-07-22 18:05:00 (UTC)
* 終了   : 2026-07-22 19:30:00 (UTC)
* 現象   : 2026-07-22 19:30:00 (UTC)を境に水準が 15.06から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→13→15→16→15→14→17→16→17
* 開始   : 2026-07-23 05:00:00 (UTC)
* 終了   : 2026-07-23 06:10:00 (UTC)
* 現象   : 2026-07-23 06:10:00 (UTC)を境に水準が 14.87から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→13→17→13→17
* 開始   : 2026-07-23 05:55:00 (UTC)
* 終了   : 2026-07-23 06:05:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260723-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→23→…→23→25→21→24
* 開始   : 2026-07-23 10:35:00 (UTC)
* 終了   : 2026-07-23 10:45:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→15→16→15→16→17
* 開始   : 2026-07-23 17:35:00 (UTC)
* 終了   : 2026-07-23 18:10:00 (UTC)
* 現象   : 2026-07-23 18:10:00 (UTC)を境に水準が 15.12から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.105, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→8→9→7→8→10
* 開始   : 2026-07-23 21:20:00 (UTC)
* 終了   : 2026-07-23 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→10→9→9→9→8
* 開始   : 2026-07-23 23:50:00 (UTC)
* 終了   : 2026-07-24 00:15:00 (UTC)
* 現象   : 2026-07-24 00:15:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.342, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→9→10→10→10→10→9
* 開始   : 2026-07-24 01:50:00 (UTC)
* 終了   : 2026-07-24 02:20:00 (UTC)
* 現象   : 2026-07-24 02:20:00 (UTC)を境に水準が 14.84から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.624, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→9→10→11→9→12
* 開始   : 2026-07-24 02:00:00 (UTC)
* 終了   : 2026-07-24 02:25:00 (UTC)
* 現象   : 2026-07-24 02:25:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.359, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→16→20→16→20→18
* 開始   : 2026-07-24 07:25:00 (UTC)
* 終了   : 2026-07-24 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 7→9→12→9→9→10
* 開始   : 2026-07-24 23:35:00 (UTC)
* 終了   : 2026-07-25 00:00:00 (UTC)
* 現象   : 2026-07-25 00:00:00 (UTC)を境に水準が 14.93から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.359, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→10→8→10→10→8→9→9
* 開始   : 2026-07-25 00:30:00 (UTC)
* 終了   : 2026-07-25 01:05:00 (UTC)
* 現象   : 2026-07-25 01:05:00 (UTC)を境に水準が 14.87から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260725-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→12→8→11→7→8→11→7→9
* 開始   : 2026-07-25 20:00:00 (UTC)
* 終了   : 2026-07-25 20:10:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260725-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→11→10
* 開始   : 2026-07-26 01:50:00 (UTC)
* 終了   : 2026-07-26 02:00:00 (UTC)
* 現象   : 2026-07-26 02:00:00 (UTC)を境に水準が 11.81から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.696, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→13→…→13→18→14→15
* 開始   : 2026-07-26 09:20:00 (UTC)
* 終了   : 2026-07-26 09:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260726-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→16→16→16→16→19
* 開始   : 2026-07-26 10:00:00 (UTC)
* 終了   : 2026-07-26 10:25:00 (UTC)
* 現象   : 2026-07-26 10:25:00 (UTC)を境に水準が 11.86から13.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→6→9→10→6→9→8
* 開始   : 2026-07-28 01:20:00 (UTC)
* 終了   : 2026-07-28 01:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→9→7→14→…→7→14→10→13
* 開始   : 2026-07-28 03:50:00 (UTC)
* 終了   : 2026-07-28 03:55:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→13→17→16→13→17→16→14
* 開始   : 2026-07-28 05:55:00 (UTC)
* 終了   : 2026-07-28 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260728-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→16→19→16→19→16→19
* 開始   : 2026-07-28 06:55:00 (UTC)
* 終了   : 2026-07-28 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→20→21→22→…→18→22→19→20
* 開始   : 2026-07-28 08:10:00 (UTC)
* 終了   : 2026-07-28 08:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→16→…→13→16→13→16
* 開始   : 2026-07-28 17:40:00 (UTC)
* 終了   : 2026-07-28 17:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→13→16→15→15→14→14→15
* 開始   : 2026-07-28 18:05:00 (UTC)
* 終了   : 2026-07-28 18:40:00 (UTC)
* 現象   : 2026-07-28 18:40:00 (UTC)を境に水準が 15.04から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→12→16→15
* 開始   : 2026-07-28 18:20:00 (UTC)
* 終了   : 2026-07-28 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260728-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→14→16→13→14→16→13
* 開始   : 2026-07-29 05:00:00 (UTC)
* 終了   : 2026-07-29 05:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→13→17→13
* 開始   : 2026-07-29 05:30:00 (UTC)
* 終了   : 2026-07-29 05:35:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→19→18→16→20→19→18
* 開始   : 2026-07-29 07:10:00 (UTC)
* 終了   : 2026-07-29 07:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.27倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→20→20→19→16→21→23→21→20
* 開始   : 2026-07-29 08:00:00 (UTC)
* 終了   : 2026-07-29 08:50:00 (UTC)
* 現象   : 2026-07-29 08:50:00 (UTC)を境に水準が 14.88から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 24→23→23→23→23→23→23→22→22
* 開始   : 2026-07-29 11:30:00 (UTC)
* 終了   : 2026-07-29 12:20:00 (UTC)
* 現象   : 2026-07-29 12:20:00 (UTC)を境に水準が 14.88から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→18→20→17→17→16→18→21→18
* 開始   : 2026-07-29 16:05:00 (UTC)
* 終了   : 2026-07-29 16:55:00 (UTC)
* 現象   : 2026-07-29 16:55:00 (UTC)を境に水準が 14.99から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→16→12→16→12→14
* 開始   : 2026-07-29 18:40:00 (UTC)
* 終了   : 2026-07-29 18:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260729-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→8→6→5→…→6→5→10→9
* 開始   : 2026-07-29 22:15:00 (UTC)
* 終了   : 2026-07-29 22:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→7→11→8→11→8→11→7→9
* 開始   : 2026-07-30 01:10:00 (UTC)
* 終了   : 2026-07-30 01:20:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→19→19→18→19
* 開始   : 2026-07-30 07:30:00 (UTC)
* 終了   : 2026-07-30 07:55:00 (UTC)
* 現象   : 2026-07-30 07:55:00 (UTC)を境に水準が 14.83から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.829, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→22→21→23→22→21→23→20→22
* 開始   : 2026-07-30 09:20:00 (UTC)
* 終了   : 2026-07-30 09:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260730-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 23→25→21→21→24→21→24→22→23
* 開始   : 2026-07-30 10:45:00 (UTC)
* 終了   : 2026-07-30 11:35:00 (UTC)
* 現象   : 2026-07-30 11:35:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.658, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 22→19→18→20→22→19→18→20→22
* 開始   : 2026-07-30 13:55:00 (UTC)
* 終了   : 2026-07-30 14:00:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→15→12→14→15→12→14
* 開始   : 2026-07-30 18:40:00 (UTC)
* 終了   : 2026-07-30 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→10→…→11→10→14→11
* 開始   : 2026-07-30 18:55:00 (UTC)
* 終了   : 2026-07-30 19:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260730-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→9→12→11→9→12→10
* 開始   : 2026-07-31 01:45:00 (UTC)
* 終了   : 2026-07-31 01:55:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260731-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→12→16→17→…→16→17→15→16
* 開始   : 2026-07-31 05:50:00 (UTC)
* 終了   : 2026-07-31 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260731-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→16→15→16→18→18→16→17→20
* 開始   : 2026-07-31 06:00:00 (UTC)
* 終了   : 2026-07-31 07:10:00 (UTC)
* 現象   : 2026-07-31 07:10:00 (UTC)を境に水準が 14.89から14.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→18→20→18→20→17→19
* 開始   : 2026-07-31 07:00:00 (UTC)
* 終了   : 2026-07-31 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.257倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→16→18→20→20→20
* 開始   : 2026-07-31 07:50:00 (UTC)
* 終了   : 2026-07-31 08:15:00 (UTC)
* 現象   : 2026-07-31 08:15:00 (UTC)を境に水準が 14.92から14.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 23→23→20→20→23→21→22
* 開始   : 2026-07-31 14:00:00 (UTC)
* 終了   : 2026-07-31 14:30:00 (UTC)
* 現象   : 2026-07-31 14:30:00 (UTC)を境に水準が 14.96から12.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→14→14
* 開始   : 2026-07-31 18:55:00 (UTC)
* 終了   : 2026-07-31 19:05:00 (UTC)
* 現象   : 2026-07-31 19:05:00 (UTC)を境に水準が 15.02から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.604, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→12→12→11→10→11→9
* 開始   : 2026-07-31 21:15:00 (UTC)
* 終了   : 2026-07-31 21:55:00 (UTC)
* 現象   : 2026-07-31 21:55:00 (UTC)を境に水準が 15.01から11.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.813, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 7→11→8→11→8→11→6→8
* 開始   : 2026-07-31 23:55:00 (UTC)
* 終了   : 2026-08-01 00:05:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260731-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-lsfhost01-001 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260801-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host10-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
