# host07 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host07 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 309 (SEVERE: 18, FATAL: 131, WARN: 160, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 18 | 131 | 160 | 309 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→18→…→15→14→13→15
* 開始   : 2026-06-08 01:20:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.77から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.829, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-001 active_connections の推移](charts/EVT-20260608-host07-001.svg)

# イベントID( EVT-20260608-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→17→…→14→15→13→11
* 開始   : 2026-06-08 01:30:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.82から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.628σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.902, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-002 active_connections の推移](charts/EVT-20260608-host07-002.svg)

# イベントID( EVT-20260608-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→15→…→15→14→13→15
* 開始   : 2026-06-08 03:10:00 (UTC)
* 終了   : 2026-06-08 20:10:00 (UTC)
* 現象   : 2026-06-08 20:10:00 (UTC)を境に水準が 11.92から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.696, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-004 active_connections の推移](charts/EVT-20260608-host07-004.svg)

# イベントID( EVT-20260608-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→15→…→13→15→13→14
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 22:55:00 (UTC)
* 現象   : 2026-06-08 22:55:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.092, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.365, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-005 active_connections の推移](charts/EVT-20260608-host07-005.svg)

# イベントID( EVT-20260608-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→13→15→13→…→14→15→13→15
* 開始   : 2026-06-08 04:55:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.99から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.3σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-006 active_connections の推移](charts/EVT-20260608-host07-006.svg)

# イベントID( EVT-20260615-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→17→14→17→…→13→14→12→13
* 開始   : 2026-06-15 01:20:00 (UTC)
* 終了   : 2026-06-15 21:25:00 (UTC)
* 現象   : 2026-06-15 21:25:00 (UTC)を境に水準が 11.78から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.935, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-002 active_connections の推移](charts/EVT-20260615-host07-002.svg)

# イベントID( EVT-20260615-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→16→…→12→13→11→13
* 開始   : 2026-06-15 02:05:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.76から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-004 active_connections の推移](charts/EVT-20260615-host07-004.svg)

# イベントID( EVT-20260615-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→17→15→16→…→14→11→9→12
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.875, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-008 active_connections の推移](charts/EVT-20260615-host07-008.svg)

# イベントID( EVT-20260622-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→13→…→15→12→14→13
* 開始   : 2026-06-22 02:20:00 (UTC)
* 終了   : 2026-06-22 22:05:00 (UTC)
* 現象   : 2026-06-22 22:05:00 (UTC)を境に水準が 11.73から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.12, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-002 active_connections の推移](charts/EVT-20260622-host07-002.svg)

# イベントID( EVT-20260622-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→15→…→13→14→15→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 12から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.968, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-003 active_connections の推移](charts/EVT-20260622-host07-003.svg)

# イベントID( EVT-20260622-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→16→14→15→…→15→14→13→15
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.733, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-004 active_connections の推移](charts/EVT-20260622-host07-004.svg)

# イベントID( EVT-20260622-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→15→17→14→…→13→12→11→12
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.79から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.017, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-005 active_connections の推移](charts/EVT-20260622-host07-005.svg)

# イベントID( EVT-20260622-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→17→…→15→13→15→14
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 11.89から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.862, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-006 active_connections の推移](charts/EVT-20260622-host07-006.svg)

# イベントID( EVT-20260622-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→14→…→19→14→16→15
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 19:50:00 (UTC)
* 現象   : 2026-06-22 19:50:00 (UTC)を境に水準が 11.85から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.918, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-007 active_connections の推移](charts/EVT-20260622-host07-007.svg)

# イベントID( EVT-20260623-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→20→20→19→21→17→20→19→19
* 開始   : 2026-06-23 15:20:00 (UTC)
* 終了   : 2026-06-23 16:20:00 (UTC)
* 現象   : 2026-06-23 16:20:00 (UTC)を境に水準が 14.93から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.538σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-005 active_connections の推移](charts/EVT-20260623-host07-005.svg)

# イベントID( EVT-20260629-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→16→…→14→15→14→15
* 開始   : 2026-06-29 01:30:00 (UTC)
* 終了   : 2026-06-29 19:45:00 (UTC)
* 現象   : 2026-06-29 19:45:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.161, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-001 active_connections の推移](charts/EVT-20260629-host07-001.svg)

# イベントID( EVT-20260629-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→17→18→19→…→14→13→11→13
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:40:00 (UTC)
* 現象   : 2026-06-29 20:40:00 (UTC)を境に水準が 11.8から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.78, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-005 active_connections の推移](charts/EVT-20260629-host07-005.svg)

# イベントID( EVT-20260629-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→14→13→14→15
* 開始   : 2026-06-29 03:05:00 (UTC)
* 終了   : 2026-06-29 21:40:00 (UTC)
* 現象   : 2026-06-29 21:40:00 (UTC)を境に水準が 11.88から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.26, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.559, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-006 active_connections の推移](charts/EVT-20260629-host07-006.svg)

# イベントID( EVT-20260601-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→10→15→10→10
* 開始   : 2026-06-01 04:00:00 (UTC)
* 終了   : 2026-06-01 04:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→18→16→19→19
* 開始   : 2026-06-01 15:30:00 (UTC)
* 終了   : 2026-06-01 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→21→26→23→21
* 開始   : 2026-06-02 10:40:00 (UTC)
* 終了   : 2026-06-02 10:40:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.228倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→14→16→13→14→16
* 開始   : 2026-06-02 17:30:00 (UTC)
* 終了   : 2026-06-02 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→10→11
* 開始   : 2026-06-02 20:05:00 (UTC)
* 終了   : 2026-06-02 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-073 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→18→17
* 開始   : 2026-06-03 08:00:00 (UTC)
* 終了   : 2026-06-03 08:00:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→17→16→16→17
* 開始   : 2026-06-03 17:00:00 (UTC)
* 終了   : 2026-06-03 18:25:00 (UTC)
* 現象   : 2026-06-03 18:25:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→19→14→17→…→17→14→17→18
* 開始   : 2026-06-03 17:10:00 (UTC)
* 終了   : 2026-06-03 17:40:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.663σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 30 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→16→12→17→17
* 開始   : 2026-06-03 17:45:00 (UTC)
* 終了   : 2026-06-03 17:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260603-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→9→4→7→9
* 開始   : 2026-06-03 23:20:00 (UTC)
* 終了   : 2026-06-03 23:20:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→10→8
* 開始   : 2026-06-04 02:55:00 (UTC)
* 終了   : 2026-06-04 02:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→18→22→20→19
* 開始   : 2026-06-04 08:25:00 (UTC)
* 終了   : 2026-06-04 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→18→23→21→21
* 開始   : 2026-06-04 08:55:00 (UTC)
* 終了   : 2026-06-04 08:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→13→8→13→…→13→15→12→10
* 開始   : 2026-06-04 19:55:00 (UTC)
* 終了   : 2026-06-04 20:05:00 (UTC)
* 現象   : 木曜19時台の平常値(12.5)に対し 8であった
* 説明   : ALG-A1: 移動平均からの残差が 3.549σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.711σ 外れた (平常値=12.5)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260604-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host07-009 active_connections の推移](charts/EVT-20260604-host07-009.svg)

# イベントID( EVT-20260604-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 7→7→12→7→6
* 開始   : 2026-06-04 23:55:00 (UTC)
* 終了   : 2026-06-04 23:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→11→14→12→9
* 開始   : 2026-06-05 03:20:00 (UTC)
* 終了   : 2026-06-05 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260605-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-001 active_connections の推移](charts/EVT-20260605-host07-001.svg)

# イベントID( EVT-20260605-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→15→17
* 開始   : 2026-06-05 06:25:00 (UTC)
* 終了   : 2026-06-05 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→15→21→17→18
* 開始   : 2026-06-05 07:10:00 (UTC)
* 終了   : 2026-06-05 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.319倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-004 active_connections の推移](charts/EVT-20260605-host07-004.svg)

# イベントID( EVT-20260605-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→17→24→21→21
* 開始   : 2026-06-05 09:20:00 (UTC)
* 終了   : 2026-06-05 09:20:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→18→13→16→16
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→14→11→15→15
* 開始   : 2026-06-05 18:30:00 (UTC)
* 終了   : 2026-06-05 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→13→10→12→12
* 開始   : 2026-06-05 19:05:00 (UTC)
* 終了   : 2026-06-05 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→10→14→8→11
* 開始   : 2026-06-06 04:15:00 (UTC)
* 終了   : 2026-06-06 04:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→14→11→12→…→11→13→11→12
* 開始   : 2026-06-06 04:35:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.973, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間
  - EVT-20260606-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 14.0 時間

![EVT-20260606-host07-002 active_connections の推移](charts/EVT-20260606-host07-002.svg)

# イベントID( EVT-20260606-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→11→…→10→11→12→9
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 19:50:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.925, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host07-003 active_connections の推移](charts/EVT-20260606-host07-003.svg)

# イベントID( EVT-20260606-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→11→12→13→…→14→11→14→11
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.186, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host07-004 active_connections の推移](charts/EVT-20260606-host07-004.svg)

# イベントID( EVT-20260606-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→12→10→9→…→9→10→12→10
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.313, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host07-005 active_connections の推移](charts/EVT-20260606-host07-005.svg)

# イベントID( EVT-20260606-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→10→13→12→…→10→11→13→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.78, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host07-006 active_connections の推移](charts/EVT-20260606-host07-006.svg)

# イベントID( EVT-20260606-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→14→…→13→12→13→11
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 20:05:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.987, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host07-007 active_connections の推移](charts/EVT-20260606-host07-007.svg)

# イベントID( EVT-20260607-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→20→13→16
* 開始   : 2026-06-07 11:50:00 (UTC)
* 終了   : 2026-06-07 11:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→17→11→16→17
* 開始   : 2026-06-07 15:20:00 (UTC)
* 終了   : 2026-06-07 15:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→10→5→10→10
* 開始   : 2026-06-07 20:25:00 (UTC)
* 終了   : 2026-06-07 20:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.4839(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.73σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→13→16→14→…→15→14→15→14
* 開始   : 2026-06-08 01:35:00 (UTC)
* 終了   : 2026-06-08 20:15:00 (UTC)
* 現象   : 2026-06-08 20:15:00 (UTC)を境に水準が 11.79から15.11へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.129, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→10→7→10→10
* 開始   : 2026-06-08 20:50:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 7→10→4→10→8
* 開始   : 2026-06-09 01:55:00 (UTC)
* 終了   : 2026-06-09 01:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→16
* 開始   : 2026-06-09 03:50:00 (UTC)
* 終了   : 2026-06-09 04:05:00 (UTC)
* 現象   : 2026-06-09 04:05:00 (UTC)を境に水準が 14.94から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.832, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→13→…→18→14→16→15
* 開始   : 2026-06-09 05:10:00 (UTC)
* 終了   : 2026-06-09 05:40:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host07-004 active_connections の推移](charts/EVT-20260609-host07-004.svg)

# イベントID( EVT-20260609-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→15→19→15→13
* 開始   : 2026-06-09 06:00:00 (UTC)
* 終了   : 2026-06-09 06:00:00 (UTC)
* 現象   : 平常時(14)に対し 1.357倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-005 active_connections の推移](charts/EVT-20260609-host07-005.svg)

# イベントID( EVT-20260609-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→14→18
* 開始   : 2026-06-09 06:50:00 (UTC)
* 終了   : 2026-06-09 06:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→20→23→19→18
* 開始   : 2026-06-09 08:45:00 (UTC)
* 終了   : 2026-06-09 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→17→13→16→…→16→11→15→13
* 開始   : 2026-06-09 18:30:00 (UTC)
* 終了   : 2026-06-09 18:40:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→14→11→13→15
* 開始   : 2026-06-09 18:40:00 (UTC)
* 終了   : 2026-06-09 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 7→8→12→7→8
* 開始   : 2026-06-10 00:35:00 (UTC)
* 終了   : 2026-06-10 00:35:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→12→14
* 開始   : 2026-06-10 05:00:00 (UTC)
* 終了   : 2026-06-10 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→19→24→20→21
* 開始   : 2026-06-10 09:25:00 (UTC)
* 終了   : 2026-06-10 09:25:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→9→15→14→9→15→14→13
* 開始   : 2026-06-11 04:45:00 (UTC)
* 終了   : 2026-06-11 05:05:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.779σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260611-host07-002 active_connections の推移](charts/EVT-20260611-host07-002.svg)

# イベントID( EVT-20260611-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→13→17→13→17→13→15
* 開始   : 2026-06-11 05:50:00 (UTC)
* 終了   : 2026-06-11 06:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260611-host07-003 active_connections の推移](charts/EVT-20260611-host07-003.svg)

# イベントID( EVT-20260611-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→17→19→17→…→17→21→18→15
* 開始   : 2026-06-11 07:10:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 6→8→4→9→8
* 開始   : 2026-06-11 23:35:00 (UTC)
* 終了   : 2026-06-11 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→8→4→7→9
* 開始   : 2026-06-12 00:20:00 (UTC)
* 終了   : 2026-06-12 00:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→11→17→13→15
* 開始   : 2026-06-12 04:55:00 (UTC)
* 終了   : 2026-06-12 04:55:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 20→21→25→22→20
* 開始   : 2026-06-12 09:55:00 (UTC)
* 終了   : 2026-06-12 09:55:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→11→10→…→11→10→14→13
* 開始   : 2026-06-12 18:00:00 (UTC)
* 終了   : 2026-06-12 18:55:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260612-host07-009 active_connections の推移](charts/EVT-20260612-host07-009.svg)

# イベントID( EVT-20260613-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→10→…→12→13→11→12
* 開始   : 2026-06-13 04:55:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.314, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host07-002 active_connections の推移](charts/EVT-20260613-host07-002.svg)

# イベントID( EVT-20260613-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→10→…→12→11→14→11
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 19:45:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.113, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260613-host07-003 active_connections の推移](charts/EVT-20260613-host07-003.svg)

# イベントID( EVT-20260613-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→11→…→11→13→11→9
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.279, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host07-004 active_connections の推移](charts/EVT-20260613-host07-004.svg)

# イベントID( EVT-20260613-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→14→13→14→12
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host07-005 active_connections の推移](charts/EVT-20260613-host07-005.svg)

# イベントID( EVT-20260613-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→10→14→12→…→10→13→14→12
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 18:00:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.043, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260613-host07-006 active_connections の推移](charts/EVT-20260613-host07-006.svg)

# イベントID( EVT-20260613-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→12→…→12→11→12→13
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260613-host07-007 active_connections の推移](charts/EVT-20260613-host07-007.svg)

# イベントID( EVT-20260613-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→7→12→10→…→6→5→8→9
* 開始   : 2026-06-13 21:35:00 (UTC)
* 終了   : 2026-06-13 21:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→8→13→12→…→13→12→10→9
* 開始   : 2026-06-14 03:30:00 (UTC)
* 終了   : 2026-06-14 03:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260614-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260614-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→13→13→12→12→14→14→13→16
* 開始   : 2026-06-14 05:10:00 (UTC)
* 終了   : 2026-06-14 06:40:00 (UTC)
* 現象   : 2026-06-14 06:40:00 (UTC)を境に水準が 11.96から12.29へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→14→18→12→14
* 開始   : 2026-06-14 09:15:00 (UTC)
* 終了   : 2026-06-14 09:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→15→15
* 開始   : 2026-06-14 09:40:00 (UTC)
* 終了   : 2026-06-14 09:40:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260614-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→13→9→…→9→6→7→9
* 開始   : 2026-06-14 22:45:00 (UTC)
* 終了   : 2026-06-14 22:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→12→17→14→…→14→15→14→15
* 開始   : 2026-06-15 02:50:00 (UTC)
* 終了   : 2026-06-15 20:10:00 (UTC)
* 現象   : 2026-06-15 20:10:00 (UTC)を境に水準が 11.82から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.725, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-005 active_connections の推移](charts/EVT-20260615-host07-005.svg)

# イベントID( EVT-20260615-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→17→…→11→13→12→11
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.76から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.782, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.404, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→15→…→13→14→11→13
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 11.95から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.656, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.953, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→12→…→12→17→14→12
* 開始   : 2026-06-16 04:40:00 (UTC)
* 終了   : 2026-06-16 04:50:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-002 active_connections の推移](charts/EVT-20260616-host07-002.svg)

# イベントID( EVT-20260616-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→20→19→16→20→19→16→15
* 開始   : 2026-06-16 06:25:00 (UTC)
* 終了   : 2026-06-16 06:50:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host07-003 active_connections の推移](charts/EVT-20260616-host07-003.svg)

# イベントID( EVT-20260616-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→16→…→16→19→17→16
* 開始   : 2026-06-16 06:50:00 (UTC)
* 終了   : 2026-06-16 07:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.358σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→16→…→16→12→14→15
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 19:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 50 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 35 分
  - EVT-20260616-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host07-011 active_connections の推移](charts/EVT-20260616-host07-011.svg)

# イベントID( EVT-20260616-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→8→…→10→8→14→11
* 開始   : 2026-06-16 19:55:00 (UTC)
* 終了   : 2026-06-16 20:00:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→12→13→10→…→10→15→11→10
* 開始   : 2026-06-17 03:55:00 (UTC)
* 終了   : 2026-06-17 04:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→7→12→5→7→12→5→10→11
* 開始   : 2026-06-17 21:50:00 (UTC)
* 終了   : 2026-06-17 22:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→8→7
* 開始   : 2026-06-18 01:35:00 (UTC)
* 終了   : 2026-06-18 01:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→9→12
* 開始   : 2026-06-18 02:40:00 (UTC)
* 終了   : 2026-06-18 02:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.57倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-002 active_connections の推移](charts/EVT-20260618-host07-002.svg)

# イベントID( EVT-20260618-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→10→13
* 開始   : 2026-06-18 04:00:00 (UTC)
* 終了   : 2026-06-18 04:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.628σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host07-004 active_connections の推移](charts/EVT-20260618-host07-004.svg)

# イベントID( EVT-20260618-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→19→15→17→18
* 開始   : 2026-06-18 16:05:00 (UTC)
* 終了   : 2026-06-18 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→16→17→15→18→17→17
* 開始   : 2026-06-18 17:30:00 (UTC)
* 終了   : 2026-06-18 18:30:00 (UTC)
* 現象   : 2026-06-18 18:30:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→14→12
* 開始   : 2026-06-18 19:10:00 (UTC)
* 終了   : 2026-06-18 19:10:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→13→12→9→…→12→7→8→10
* 開始   : 2026-06-19 02:05:00 (UTC)
* 終了   : 2026-06-19 02:45:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260619-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host07-001 active_connections の推移](charts/EVT-20260619-host07-001.svg)

# イベントID( EVT-20260619-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→15→20→16→18
* 開始   : 2026-06-19 07:00:00 (UTC)
* 終了   : 2026-06-19 07:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→19→21→17→18
* 開始   : 2026-06-19 07:30:00 (UTC)
* 終了   : 2026-06-19 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→18→24→21→19
* 開始   : 2026-06-19 09:00:00 (UTC)
* 終了   : 2026-06-19 09:00:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→19→17→15→14→19→18
* 開始   : 2026-06-19 16:20:00 (UTC)
* 終了   : 2026-06-19 16:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.867σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→17→13→14→…→13→14→15→16
* 開始   : 2026-06-19 17:05:00 (UTC)
* 終了   : 2026-06-19 17:30:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→11→10→13→…→10→11→12→10
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.009, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host07-002 active_connections の推移](charts/EVT-20260620-host07-002.svg)

# イベントID( EVT-20260620-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→9→10→12→…→10→12→10→13
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.952, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host07-003 active_connections の推移](charts/EVT-20260620-host07-003.svg)

# イベントID( EVT-20260620-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→9→…→13→12→13→12
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.982, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host07-004 active_connections の推移](charts/EVT-20260620-host07-004.svg)

# イベントID( EVT-20260620-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→10→…→14→11→15→13
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.22, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host07-005 active_connections の推移](charts/EVT-20260620-host07-005.svg)

# イベントID( EVT-20260620-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→13→…→10→11→14→13
* 開始   : 2026-06-20 06:15:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.827, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260620-host07-006 active_connections の推移](charts/EVT-20260620-host07-006.svg)

# イベントID( EVT-20260620-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→11→…→12→11→12→11
* 開始   : 2026-06-20 06:35:00 (UTC)
* 終了   : 2026-06-20 20:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260620-host07-007 active_connections の推移](charts/EVT-20260620-host07-007.svg)

# イベントID( EVT-20260620-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→9→5→9→7
* 開始   : 2026-06-20 20:35:00 (UTC)
* 終了   : 2026-06-20 20:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→16→14
* 開始   : 2026-06-23 06:10:00 (UTC)
* 終了   : 2026-06-23 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.399倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.781σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host07-003 active_connections の推移](charts/EVT-20260623-host07-003.svg)

# イベントID( EVT-20260623-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→21→21→21→20→20→19→18
* 開始   : 2026-06-23 15:00:00 (UTC)
* 終了   : 2026-06-23 16:35:00 (UTC)
* 現象   : 2026-06-23 16:35:00 (UTC)を境に水準が 14.91から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.047, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→13→12
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→14→15
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→23→25→19→19
* 開始   : 2026-06-24 10:30:00 (UTC)
* 終了   : 2026-06-24 10:30:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→10→6→12→9
* 開始   : 2026-06-24 21:40:00 (UTC)
* 終了   : 2026-06-24 21:40:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→7→12→10→7
* 開始   : 2026-06-25 00:15:00 (UTC)
* 終了   : 2026-06-25 00:15:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→15→13→13
* 開始   : 2026-06-25 04:05:00 (UTC)
* 終了   : 2026-06-25 04:05:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260625-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→14→…→14→18→15→14
* 開始   : 2026-06-25 05:25:00 (UTC)
* 終了   : 2026-06-25 05:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→17→16
* 開始   : 2026-06-25 06:05:00 (UTC)
* 終了   : 2026-06-25 06:05:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→16→20→18→18
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→23→26→22→23
* 開始   : 2026-06-25 11:40:00 (UTC)
* 終了   : 2026-06-25 11:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→18→17→18→17→20→19
* 開始   : 2026-06-25 15:50:00 (UTC)
* 終了   : 2026-06-25 17:20:00 (UTC)
* 現象   : 2026-06-25 17:20:00 (UTC)を境に水準が 15.02から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.715, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→17→14→16→…→16→15→16→15
* 開始   : 2026-06-25 16:35:00 (UTC)
* 終了   : 2026-06-25 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→13→10→13→10→13
* 開始   : 2026-06-25 18:25:00 (UTC)
* 終了   : 2026-06-25 19:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.416σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→9→4→7→9
* 開始   : 2026-06-25 23:35:00 (UTC)
* 終了   : 2026-06-25 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host07-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 20→21→19→22→20→20
* 開始   : 2026-06-26 07:45:00 (UTC)
* 終了   : 2026-06-26 08:10:00 (UTC)
* 現象   : 2026-06-26 08:10:00 (UTC)を境に水準が 15.09から14.39へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.735, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 23→23→18→22→21
* 開始   : 2026-06-26 13:45:00 (UTC)
* 終了   : 2026-06-26 13:45:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→21→17→21→19
* 開始   : 2026-06-26 14:20:00 (UTC)
* 終了   : 2026-06-26 14:20:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→18→13→16→15
* 開始   : 2026-06-26 17:00:00 (UTC)
* 終了   : 2026-06-26 17:00:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→17→11→15→14
* 開始   : 2026-06-26 18:45:00 (UTC)
* 終了   : 2026-06-26 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→9→5→9→8
* 開始   : 2026-06-26 21:50:00 (UTC)
* 終了   : 2026-06-26 21:50:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.242σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→8→8
* 開始   : 2026-06-27 01:30:00 (UTC)
* 終了   : 2026-06-27 01:30:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260627-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→10→7
* 開始   : 2026-06-27 03:05:00 (UTC)
* 終了   : 2026-06-27 03:05:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.663倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.889σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host07-003 active_connections の推移](charts/EVT-20260627-host07-003.svg)

# イベントID( EVT-20260627-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→11→10→14→11
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.837, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host07-006 active_connections の推移](charts/EVT-20260627-host07-006.svg)

# イベントID( EVT-20260627-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→12→…→11→13→14→12
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 19:40:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.953σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host07-007 active_connections の推移](charts/EVT-20260627-host07-007.svg)

# イベントID( EVT-20260627-host07-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→13→…→13→11→13→12
* 開始   : 2026-06-27 06:15:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.339, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260627-host07-008 active_connections の推移](charts/EVT-20260627-host07-008.svg)

# イベントID( EVT-20260627-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→12→11→14
* 開始   : 2026-06-27 06:30:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.922, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host07-009 active_connections の推移](charts/EVT-20260627-host07-009.svg)

# イベントID( EVT-20260627-host07-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→14→…→11→13→12→11
* 開始   : 2026-06-27 06:30:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.307, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260627-host07-010 active_connections の推移](charts/EVT-20260627-host07-010.svg)

# イベントID( EVT-20260627-host07-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→14→…→11→10→12→10
* 開始   : 2026-06-27 06:40:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.441, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260627-host07-011 active_connections の推移](charts/EVT-20260627-host07-011.svg)

# イベントID( EVT-20260628-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→15→15
* 開始   : 2026-06-28 15:20:00 (UTC)
* 終了   : 2026-06-28 15:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→14→15
* 開始   : 2026-06-28 15:45:00 (UTC)
* 終了   : 2026-06-28 15:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→16→…→16→15→13→14
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.85から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.827, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→16→17→16→…→17→16→14→13
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 21:15:00 (UTC)
* 現象   : 2026-06-29 21:15:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.919, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.015, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→14→…→13→14→13→14
* 開始   : 2026-06-29 04:25:00 (UTC)
* 終了   : 2026-06-29 20:40:00 (UTC)
* 現象   : 2026-06-29 20:40:00 (UTC)を境に水準が 11.87から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.825, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 23→21→26→23→24
* 開始   : 2026-06-30 10:45:00 (UTC)
* 終了   : 2026-06-30 10:45:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.228倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→8→9→11→8→10→9
* 開始   : 2026-06-30 20:20:00 (UTC)
* 終了   : 2026-06-30 22:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448倍(9)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260630-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260630-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260630-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→16→19→18→…→18→20→17→18
* 開始   : 2026-06-01 07:00:00 (UTC)
* 終了   : 2026-06-01 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 21→22→25→18→…→25→18→20→21
* 開始   : 2026-06-01 11:20:00 (UTC)
* 終了   : 2026-06-01 11:25:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 22→21→25→22→19→25→22→19→22
* 開始   : 2026-06-01 12:10:00 (UTC)
* 終了   : 2026-06-01 12:20:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→8→7→10→7→10→7→10→9
* 開始   : 2026-06-01 21:10:00 (UTC)
* 終了   : 2026-06-01 21:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→15→13→13
* 開始   : 2026-06-02 04:20:00 (UTC)
* 終了   : 2026-06-02 04:35:00 (UTC)
* 現象   : 2026-06-02 04:35:00 (UTC)を境に水準が 14.97から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→13→16→14→…→14→17→14→15
* 開始   : 2026-06-02 05:20:00 (UTC)
* 終了   : 2026-06-02 05:30:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260602-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→18→20→17→20→17→20→16→18
* 開始   : 2026-06-02 07:15:00 (UTC)
* 終了   : 2026-06-02 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→22→19→24→22
* 開始   : 2026-06-02 10:40:00 (UTC)
* 終了   : 2026-06-02 10:45:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→19→15→17→19→15→17→16
* 開始   : 2026-06-02 16:20:00 (UTC)
* 終了   : 2026-06-02 16:25:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.793(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.721σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→16→18→16→15→16
* 開始   : 2026-06-02 16:35:00 (UTC)
* 終了   : 2026-06-02 16:40:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→15→14→17→18→15→14→17→18
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 16:50:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→16→15→13→12→16→15
* 開始   : 2026-06-02 17:55:00 (UTC)
* 終了   : 2026-06-02 18:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→16→13→10→16→13→10→11→12
* 開始   : 2026-06-02 19:40:00 (UTC)
* 終了   : 2026-06-02 19:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→9→10→9→10→9→10
* 開始   : 2026-06-03 00:50:00 (UTC)
* 終了   : 2026-06-03 01:20:00 (UTC)
* 現象   : 2026-06-03 01:20:00 (UTC)を境に水準が 14.85から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→15→16→14→16→14→16→13→14
* 開始   : 2026-06-03 05:20:00 (UTC)
* 終了   : 2026-06-03 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260603-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→19→19→18→21→17→17→20→22
* 開始   : 2026-06-03 05:55:00 (UTC)
* 終了   : 2026-06-03 08:05:00 (UTC)
* 現象   : 2026-06-03 08:05:00 (UTC)を境に水準が 14.97から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→19→…→19→22→20→18
* 開始   : 2026-06-03 08:10:00 (UTC)
* 終了   : 2026-06-03 08:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 22→20→18→19→…→18→19→21→22
* 開始   : 2026-06-03 11:40:00 (UTC)
* 終了   : 2026-06-03 11:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.809(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.972σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260603-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 25→22→24→21→21→22→23→25→23
* 開始   : 2026-06-03 13:00:00 (UTC)
* 終了   : 2026-06-03 14:20:00 (UTC)
* 現象   : 2026-06-03 14:20:00 (UTC)を境に水準が 15.02から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.351, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→20→17→19→20→17→19→20
* 開始   : 2026-06-03 14:35:00 (UTC)
* 終了   : 2026-06-03 14:40:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.953σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→11→13→9→11
* 開始   : 2026-06-03 20:20:00 (UTC)
* 終了   : 2026-06-03 20:25:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→10→8→11→10→8→11→10
* 開始   : 2026-06-03 20:25:00 (UTC)
* 終了   : 2026-06-03 21:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260603-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260603-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→7→12→9
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 03:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260604-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→15→14→12→15→12→13
* 開始   : 2026-06-04 04:30:00 (UTC)
* 終了   : 2026-06-04 04:40:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→18→…→17→18→16→17
* 開始   : 2026-06-04 06:20:00 (UTC)
* 終了   : 2026-06-04 06:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→19→24→19→24→19→23→22
* 開始   : 2026-06-04 11:35:00 (UTC)
* 終了   : 2026-06-04 11:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-037 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260604-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→10→9→11→13→10→9→11
* 開始   : 2026-06-04 19:50:00 (UTC)
* 終了   : 2026-06-04 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→14→8→12→9→8→12→9→10
* 開始   : 2026-06-04 20:25:00 (UTC)
* 終了   : 2026-06-04 21:25:00 (UTC)
* 現象   : 1.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.972σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260604-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260604-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→18→17
* 開始   : 2026-06-05 06:35:00 (UTC)
* 終了   : 2026-06-05 06:45:00 (UTC)
* 現象   : 2026-06-05 06:45:00 (UTC)を境に水準が 14.93から14.72へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.624, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→21→…→20→21→19→20
* 開始   : 2026-06-05 07:45:00 (UTC)
* 終了   : 2026-06-05 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→22→21→25→22→21→25→22
* 開始   : 2026-06-05 09:55:00 (UTC)
* 終了   : 2026-06-05 11:05:00 (UTC)
* 現象   : 2026-06-05 11:05:00 (UTC)を境に水準が 14.97から13.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→16→…→17→16→20→19
* 開始   : 2026-06-05 15:40:00 (UTC)
* 終了   : 2026-06-05 15:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→17→15→18→…→18→14→17→15
* 開始   : 2026-06-05 16:55:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→12→11→13→11
* 開始   : 2026-06-05 19:40:00 (UTC)
* 終了   : 2026-06-05 21:55:00 (UTC)
* 現象   : 2026-06-05 21:55:00 (UTC)を境に水準が 15.09から11.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→14→16→14
* 開始   : 2026-06-07 07:55:00 (UTC)
* 終了   : 2026-06-07 08:00:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→14→11→13→…→13→17→13→14
* 開始   : 2026-06-07 15:45:00 (UTC)
* 終了   : 2026-06-07 15:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260607-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→14→10→9→13→14→10→9→13
* 開始   : 2026-06-07 17:15:00 (UTC)
* 終了   : 2026-06-07 17:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→12→13→10→10→10→12
* 開始   : 2026-06-07 20:10:00 (UTC)
* 終了   : 2026-06-07 20:40:00 (UTC)
* 現象   : 2026-06-07 20:40:00 (UTC)を境に水準が 11.76から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.456, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→8→6→5→…→6→5→9→8
* 開始   : 2026-06-07 22:25:00 (UTC)
* 終了   : 2026-06-07 22:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260607-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→10→13→10→13
* 開始   : 2026-06-09 03:30:00 (UTC)
* 終了   : 2026-06-09 03:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.418倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.692σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→22→20→22→20
* 開始   : 2026-06-09 08:40:00 (UTC)
* 終了   : 2026-06-09 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260609-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→22→19→22→19→22
* 開始   : 2026-06-09 12:50:00 (UTC)
* 終了   : 2026-06-09 12:55:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→16→…→19→16→19→20
* 開始   : 2026-06-09 16:05:00 (UTC)
* 終了   : 2026-06-09 16:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→19→15→17→…→17→14→17→19
* 開始   : 2026-06-09 17:10:00 (UTC)
* 終了   : 2026-06-09 17:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→15→14→15→11→12→14→13→13
* 開始   : 2026-06-09 18:50:00 (UTC)
* 終了   : 2026-06-09 20:20:00 (UTC)
* 現象   : 2026-06-09 20:20:00 (UTC)を境に水準が 15.04から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→11→9→11→9→11→12
* 開始   : 2026-06-09 20:05:00 (UTC)
* 終了   : 2026-06-09 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→11→11
* 開始   : 2026-06-10 01:15:00 (UTC)
* 終了   : 2026-06-10 01:25:00 (UTC)
* 現象   : 2026-06-10 01:25:00 (UTC)を境に水準が 15.09から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.624, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→11→11→11→10→11
* 開始   : 2026-06-10 02:30:00 (UTC)
* 終了   : 2026-06-10 02:55:00 (UTC)
* 現象   : 2026-06-10 02:55:00 (UTC)を境に水準が 14.93から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→13→11→9→13→11→10
* 開始   : 2026-06-10 03:05:00 (UTC)
* 終了   : 2026-06-10 03:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→19→20→21→20→21→20→21
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:25:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→20→23→19→23→19→23→22→23
* 開始   : 2026-06-10 09:30:00 (UTC)
* 終了   : 2026-06-10 09:40:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→20→…→20→16→18→17
* 開始   : 2026-06-10 15:50:00 (UTC)
* 終了   : 2026-06-10 16:00:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→18→16→18→19
* 開始   : 2026-06-10 15:50:00 (UTC)
* 終了   : 2026-06-10 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→18→15→16→18→15→16
* 開始   : 2026-06-10 17:10:00 (UTC)
* 終了   : 2026-06-10 17:15:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→16→12→11→12→16→12→11→12
* 開始   : 2026-06-10 19:00:00 (UTC)
* 終了   : 2026-06-10 19:05:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→11→10→13→11→10→13→11
* 開始   : 2026-06-10 19:10:00 (UTC)
* 終了   : 2026-06-10 19:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→13→11→10→13→14
* 開始   : 2026-06-10 19:25:00 (UTC)
* 終了   : 2026-06-10 19:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 8→9→12→9→12→9→10
* 開始   : 2026-06-11 02:30:00 (UTC)
* 終了   : 2026-06-11 02:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260611-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→19→21→25→19→21→25→21→23
* 開始   : 2026-06-11 13:00:00 (UTC)
* 終了   : 2026-06-11 13:10:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→15→18→17
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 18:50:00 (UTC)
* 現象   : 2026-06-11 18:50:00 (UTC)を境に水準が 15.03から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.832, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→8→6→9→8→6→9
* 開始   : 2026-06-11 23:05:00 (UTC)
* 終了   : 2026-06-11 23:10:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→14→16→14→16→15
* 開始   : 2026-06-12 05:25:00 (UTC)
* 終了   : 2026-06-12 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→19→16→20→19→16→20→17→16
* 開始   : 2026-06-12 06:55:00 (UTC)
* 終了   : 2026-06-12 07:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260612-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 22→21→22→21→22
* 開始   : 2026-06-12 14:20:00 (UTC)
* 終了   : 2026-06-12 15:30:00 (UTC)
* 現象   : 2026-06-12 15:30:00 (UTC)を境に水準が 14.97から12.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.739σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→18→16→18→16→18→16→19→18
* 開始   : 2026-06-12 15:55:00 (UTC)
* 終了   : 2026-06-12 16:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260612-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→21→15→18→21→15→18→17
* 開始   : 2026-06-12 16:40:00 (UTC)
* 終了   : 2026-06-12 16:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→15→…→15→11→14→13
* 開始   : 2026-06-12 18:40:00 (UTC)
* 終了   : 2026-06-12 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→12→11→13→15→12→11→13→15
* 開始   : 2026-06-12 18:45:00 (UTC)
* 終了   : 2026-06-12 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→9→9→11→8→10→10→10→9
* 開始   : 2026-06-12 22:15:00 (UTC)
* 終了   : 2026-06-12 23:00:00 (UTC)
* 現象   : 2026-06-12 23:00:00 (UTC)を境に水準が 14.9から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.559, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→7→12→9→7→12→9→10
* 開始   : 2026-06-13 03:50:00 (UTC)
* 終了   : 2026-06-13 03:55:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→9→5→8→9→5→8→6
* 開始   : 2026-06-13 23:30:00 (UTC)
* 終了   : 2026-06-13 23:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→10→11→8→8→7→8→9→10
* 開始   : 2026-06-14 01:00:00 (UTC)
* 終了   : 2026-06-14 01:55:00 (UTC)
* 現象   : 2026-06-14 01:55:00 (UTC)を境に水準が 11.86から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→10→13→9→13→9→13→12→11
* 開始   : 2026-06-14 04:40:00 (UTC)
* 終了   : 2026-06-14 04:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→13→12→9→14→12→13→15
* 開始   : 2026-06-14 16:50:00 (UTC)
* 終了   : 2026-06-14 18:20:00 (UTC)
* 現象   : 2026-06-14 18:20:00 (UTC)を境に水準が 11.78から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→8→10→9→10
* 開始   : 2026-06-14 22:00:00 (UTC)
* 終了   : 2026-06-14 22:20:00 (UTC)
* 現象   : 2026-06-14 22:20:00 (UTC)を境に水準が 11.98から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→10→10→11
* 開始   : 2026-06-15 00:20:00 (UTC)
* 終了   : 2026-06-15 00:35:00 (UTC)
* 現象   : 2026-06-15 00:35:00 (UTC)を境に水準が 11.7から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→7→11→8→7→11→8→9
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 01:55:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260615-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→6→8→12→…→8→6→7→9
* 開始   : 2026-06-15 22:25:00 (UTC)
* 終了   : 2026-06-15 22:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→11→10→8→5→11→10
* 開始   : 2026-06-16 02:25:00 (UTC)
* 終了   : 2026-06-16 02:30:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 21→18→21→19→22→22→20
* 開始   : 2026-06-16 08:25:00 (UTC)
* 終了   : 2026-06-16 08:55:00 (UTC)
* 現象   : 2026-06-16 08:55:00 (UTC)を境に水準が 15から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.456, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 23→23→22→22→23→19→25
* 開始   : 2026-06-16 10:00:00 (UTC)
* 終了   : 2026-06-16 10:30:00 (UTC)
* 現象   : 2026-06-16 10:30:00 (UTC)を境に水準が 15.04から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 23→21→25→19→…→25→19→20→22
* 開始   : 2026-06-16 13:00:00 (UTC)
* 終了   : 2026-06-16 13:05:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→22→19→22→19→22→19→22→20
* 開始   : 2026-06-16 13:10:00 (UTC)
* 終了   : 2026-06-16 13:20:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260616-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 22→25→19→22→25→19→20
* 開始   : 2026-06-16 13:20:00 (UTC)
* 終了   : 2026-06-16 13:25:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260616-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→18→19→16→18→16
* 開始   : 2026-06-16 16:10:00 (UTC)
* 終了   : 2026-06-16 16:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→14→14→14→12→14→14→13→15
* 開始   : 2026-06-16 18:45:00 (UTC)
* 終了   : 2026-06-16 19:25:00 (UTC)
* 現象   : 2026-06-16 19:25:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→7→9→7→9→10
* 開始   : 2026-06-16 21:30:00 (UTC)
* 終了   : 2026-06-16 21:35:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.6412(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.739σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→5→7→11→5→7→11→7→8
* 開始   : 2026-06-16 23:20:00 (UTC)
* 終了   : 2026-06-16 23:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-084 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→17→21→17→21→19→16
* 開始   : 2026-06-17 08:00:00 (UTC)
* 終了   : 2026-06-17 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260617-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→21→19→22→21→19→22→19→20
* 開始   : 2026-06-17 08:35:00 (UTC)
* 終了   : 2026-06-17 09:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260617-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→13→14→15→13→13→15→14→14
* 開始   : 2026-06-17 17:40:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 2026-06-17 19:40:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.734σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.872, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→15
* 開始   : 2026-06-17 19:00:00 (UTC)
* 終了   : 2026-06-17 19:05:00 (UTC)
* 現象   : 2026-06-17 19:05:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→10→9→11→9
* 開始   : 2026-06-17 23:45:00 (UTC)
* 終了   : 2026-06-18 00:05:00 (UTC)
* 現象   : 2026-06-18 00:05:00 (UTC)を境に水準が 15から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→14→10→12→13→14→10→12
* 開始   : 2026-06-18 04:00:00 (UTC)
* 終了   : 2026-06-18 04:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→15→14→16→15→14
* 開始   : 2026-06-18 05:45:00 (UTC)
* 終了   : 2026-06-18 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→13→17→16→…→16→18→16→15
* 開始   : 2026-06-18 06:05:00 (UTC)
* 終了   : 2026-06-18 06:15:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→16→19→16→19→16→19→17→16
* 開始   : 2026-06-18 06:40:00 (UTC)
* 終了   : 2026-06-18 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→21→18→22→21→18→22→20→19
* 開始   : 2026-06-18 08:05:00 (UTC)
* 終了   : 2026-06-18 08:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 25→20→19→21→20→19→21→20
* 開始   : 2026-06-18 13:30:00 (UTC)
* 終了   : 2026-06-18 13:35:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.8382(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260618-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→14→16→15→15→16→15→14
* 開始   : 2026-06-18 18:10:00 (UTC)
* 終了   : 2026-06-18 18:45:00 (UTC)
* 現象   : 2026-06-18 18:45:00 (UTC)を境に水準が 15.02から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→8→9→10→12→9
* 開始   : 2026-06-18 20:50:00 (UTC)
* 終了   : 2026-06-18 22:35:00 (UTC)
* 現象   : 2026-06-18 22:35:00 (UTC)を境に水準が 15から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.692σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→14→17→16→14→17→15
* 開始   : 2026-06-19 05:20:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→19→20→23→22→22
* 開始   : 2026-06-19 08:35:00 (UTC)
* 終了   : 2026-06-19 09:00:00 (UTC)
* 現象   : 2026-06-19 09:00:00 (UTC)を境に水準が 15.18から14.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 23→25→25→23
* 開始   : 2026-06-19 11:55:00 (UTC)
* 終了   : 2026-06-19 12:10:00 (UTC)
* 現象   : 2026-06-19 12:10:00 (UTC)を境に水準が 15.02から13.47へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→15→17→15→17→15→16→18
* 開始   : 2026-06-19 16:15:00 (UTC)
* 終了   : 2026-06-19 17:00:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260619-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→12→10→12→10→11
* 開始   : 2026-06-19 19:45:00 (UTC)
* 終了   : 2026-06-19 19:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→7→10→14→7→10→11
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 04:50:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分

![EVT-20260620-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→10→7→10→7→11
* 開始   : 2026-06-20 20:25:00 (UTC)
* 終了   : 2026-06-20 20:35:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→7→9→10→9→10→10
* 開始   : 2026-06-21 00:25:00 (UTC)
* 終了   : 2026-06-21 01:30:00 (UTC)
* 現象   : 2026-06-21 01:30:00 (UTC)を境に水準が 11.83から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→13→11→14
* 開始   : 2026-06-21 05:20:00 (UTC)
* 終了   : 2026-06-21 06:45:00 (UTC)
* 現象   : 2026-06-21 06:45:00 (UTC)を境に水準が 11.86から12.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→9→10→9→10
* 開始   : 2026-06-21 20:30:00 (UTC)
* 終了   : 2026-06-21 20:50:00 (UTC)
* 現象   : 2026-06-21 20:50:00 (UTC)を境に水準が 11.75から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→9→10→11
* 開始   : 2026-06-21 20:50:00 (UTC)
* 終了   : 2026-06-21 21:15:00 (UTC)
* 現象   : 2026-06-21 21:15:00 (UTC)を境に水準が 11.94から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→8→11→9→8→10→9→10
* 開始   : 2026-06-22 01:00:00 (UTC)
* 終了   : 2026-06-22 01:35:00 (UTC)
* 現象   : 2026-06-22 01:35:00 (UTC)を境に水準が 11.73から14.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.047, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→8→11→6→12→10→8→12→11
* 開始   : 2026-06-23 01:40:00 (UTC)
* 終了   : 2026-06-23 03:45:00 (UTC)
* 現象   : 2026-06-23 03:45:00 (UTC)を境に水準が 14.79から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→15→17→17→15→16→18
* 開始   : 2026-06-23 05:40:00 (UTC)
* 終了   : 2026-06-23 07:35:00 (UTC)
* 現象   : 2026-06-23 07:35:00 (UTC)を境に水準が 14.89から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.483, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→17→17→17→18→18→17→19→19
* 開始   : 2026-06-23 16:25:00 (UTC)
* 終了   : 2026-06-23 17:05:00 (UTC)
* 現象   : 2026-06-23 17:05:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.274, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→17→15→16→14→15→16→14→16
* 開始   : 2026-06-23 17:20:00 (UTC)
* 終了   : 2026-06-23 17:30:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→13→15→13→12
* 開始   : 2026-06-23 19:40:00 (UTC)
* 終了   : 2026-06-23 20:00:00 (UTC)
* 現象   : 2026-06-23 20:00:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→9→…→9→6→9→10
* 開始   : 2026-06-23 21:05:00 (UTC)
* 終了   : 2026-06-23 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→10→7→10
* 開始   : 2026-06-23 21:30:00 (UTC)
* 終了   : 2026-06-23 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host07-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→10→10→9→9→10→11→11
* 開始   : 2026-06-23 22:10:00 (UTC)
* 終了   : 2026-06-23 22:45:00 (UTC)
* 現象   : 2026-06-23 22:45:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→9→9→9→12
* 開始   : 2026-06-24 01:25:00 (UTC)
* 終了   : 2026-06-24 01:45:00 (UTC)
* 現象   : 2026-06-24 01:45:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→10→11→12→10→10→11→12→11
* 開始   : 2026-06-24 02:30:00 (UTC)
* 終了   : 2026-06-24 03:30:00 (UTC)
* 現象   : 2026-06-24 03:30:00 (UTC)を境に水準が 14.88から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.015, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→11→14
* 開始   : 2026-06-24 04:20:00 (UTC)
* 終了   : 2026-06-24 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→13→12→16→13
* 開始   : 2026-06-24 04:55:00 (UTC)
* 終了   : 2026-06-24 05:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.362倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→18→21→15→…→15→21→18→20
* 開始   : 2026-06-24 07:50:00 (UTC)
* 終了   : 2026-06-24 08:30:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260624-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 25 分
  - EVT-20260624-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→21→16→15→18→21→16→15→18
* 開始   : 2026-06-24 16:15:00 (UTC)
* 終了   : 2026-06-24 16:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→16→14→17→16→14→17→15
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→13→16
* 開始   : 2026-06-24 17:50:00 (UTC)
* 終了   : 2026-06-24 19:15:00 (UTC)
* 現象   : 2026-06-24 19:15:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→15→10→11→15→10→11→13
* 開始   : 2026-06-24 19:30:00 (UTC)
* 終了   : 2026-06-24 19:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host12-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host07-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→8→11→12→10→8→11→12→12
* 開始   : 2026-06-24 20:10:00 (UTC)
* 終了   : 2026-06-24 21:10:00 (UTC)
* 現象   : 2026-06-24 21:10:00 (UTC)を境に水準が 14.91から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→12→7→13→12→7→13→12
* 開始   : 2026-06-25 03:00:00 (UTC)
* 終了   : 2026-06-25 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→16→18→14→15
* 開始   : 2026-06-25 06:05:00 (UTC)
* 終了   : 2026-06-25 06:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→23→21→23→21→23→21→18
* 開始   : 2026-06-25 09:25:00 (UTC)
* 終了   : 2026-06-25 09:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.205倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.721σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→19→18→22→19→18→22→21
* 開始   : 2026-06-25 13:50:00 (UTC)
* 終了   : 2026-06-25 13:55:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→16→…→16→13→16→15
* 開始   : 2026-06-25 17:15:00 (UTC)
* 終了   : 2026-06-25 17:40:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→17→12→13→…→13→12→13→12
* 開始   : 2026-06-25 18:30:00 (UTC)
* 終了   : 2026-06-25 18:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.845σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260625-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→12→9→12→9→11→10
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host01-012 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→11→8→11→9
* 開始   : 2026-06-25 21:15:00 (UTC)
* 終了   : 2026-06-25 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→13→14→12→…→12→15→11→14
* 開始   : 2026-06-26 04:15:00 (UTC)
* 終了   : 2026-06-26 04:25:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→15→13→15→13→15→14→13
* 開始   : 2026-06-26 04:35:00 (UTC)
* 終了   : 2026-06-26 04:45:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.385倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.909σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→16→18→17→16→18→17
* 開始   : 2026-06-26 06:20:00 (UTC)
* 終了   : 2026-06-26 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→19→20→23→19→21
* 開始   : 2026-06-26 09:25:00 (UTC)
* 終了   : 2026-06-26 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→18→22→19→18→22
* 開始   : 2026-06-26 13:35:00 (UTC)
* 終了   : 2026-06-26 13:40:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→15→17→15→17
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 16:55:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→8→8→10→9→8→9→10→10
* 開始   : 2026-06-27 00:20:00 (UTC)
* 終了   : 2026-06-27 01:10:00 (UTC)
* 現象   : 2026-06-27 01:10:00 (UTC)を境に水準が 14.88から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→8→9→…→8→9→12→11
* 開始   : 2026-06-27 04:25:00 (UTC)
* 終了   : 2026-06-27 04:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260627-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→12→…→8→11→12→13
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 05:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.761, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分

![EVT-20260627-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→8→…→8→11→12→9
* 開始   : 2026-06-27 19:40:00 (UTC)
* 終了   : 2026-06-27 19:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260627-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260627-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260627-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→4→…→12→4→8→9
* 開始   : 2026-06-27 23:50:00 (UTC)
* 終了   : 2026-06-27 23:55:00 (UTC)
* 現象   : 土曜23時台の平常値(8.142)に対し 12であった
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.193σ 外れた (平常値=8.142)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→11→9→8→11→12
* 開始   : 2026-06-28 02:15:00 (UTC)
* 終了   : 2026-06-28 02:40:00 (UTC)
* 現象   : 2026-06-28 02:40:00 (UTC)を境に水準が 11.73から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→15→16→17→17→17→15→16→18
* 開始   : 2026-06-28 13:35:00 (UTC)
* 終了   : 2026-06-28 14:45:00 (UTC)
* 現象   : 2026-06-28 14:45:00 (UTC)を境に水準が 11.86から14.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.839, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→17→15→15→19→15→16
* 開始   : 2026-06-28 13:55:00 (UTC)
* 終了   : 2026-06-28 14:25:00 (UTC)
* 現象   : 2026-06-28 14:25:00 (UTC)を境に水準が 11.84から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.857, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→11→13→10→11→10→12
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 03:15:00 (UTC)
* 現象   : 2026-06-29 03:15:00 (UTC)を境に水準が 11.81から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10→9→8→9→9→9
* 開始   : 2026-06-29 21:40:00 (UTC)
* 終了   : 2026-06-29 22:20:00 (UTC)
* 現象   : 2026-06-29 22:20:00 (UTC)を境に水準が 14.84から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.872, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 24→23→21→23→22→23→23→23→26
* 開始   : 2026-06-30 11:55:00 (UTC)
* 終了   : 2026-06-30 13:30:00 (UTC)
* 現象   : 2026-06-30 13:30:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→23→26→19→…→26→19→21→20
* 開始   : 2026-06-30 12:20:00 (UTC)
* 終了   : 2026-06-30 12:25:00 (UTC)
* 現象   : 平常時(22.17)に対し 1.173倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→22→19→19→22→20→21
* 開始   : 2026-06-30 15:05:00 (UTC)
* 終了   : 2026-06-30 15:35:00 (UTC)
* 現象   : 2026-06-30 15:35:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→12→14→12→14
* 開始   : 2026-06-30 18:15:00 (UTC)
* 終了   : 2026-06-30 18:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.7461(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.851σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→8→11→7→8→11→7→9→11
* 開始   : 2026-06-30 21:25:00 (UTC)
* 終了   : 2026-06-30 21:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host07-007 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
