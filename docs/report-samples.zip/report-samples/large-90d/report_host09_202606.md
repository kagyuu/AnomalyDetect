# host09 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host09 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 296 (SEVERE: 23, FATAL: 130, WARN: 143, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 23 | 130 | 143 | 296 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260606-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→10→…→12→11→12→13
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.781, 限界=2.684)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.159σ 外れた (平常値=14.21)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260606-host09-004 active_connections の推移](charts/EVT-20260606-host09-004.svg)

# イベントID( EVT-20260608-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→18→16→18→…→13→17→15→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 19:30:00 (UTC)
* 現象   : 2026-06-08 19:30:00 (UTC)を境に水準が 11.92から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.917, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-002 active_connections の推移](charts/EVT-20260608-host09-002.svg)

# イベントID( EVT-20260608-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→15→16→14→…→12→14→10→12
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.66から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.504, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-003 active_connections の推移](charts/EVT-20260608-host09-003.svg)

# イベントID( EVT-20260608-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→14→…→13→14→12→14
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.8から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.889, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-004 active_connections の推移](charts/EVT-20260608-host09-004.svg)

# イベントID( EVT-20260608-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→12→14→13→…→12→16→12→14
* 開始   : 2026-06-08 03:05:00 (UTC)
* 終了   : 2026-06-08 21:35:00 (UTC)
* 現象   : 2026-06-08 21:35:00 (UTC)を境に水準が 11.87から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.035, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.561, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-005 active_connections の推移](charts/EVT-20260608-host09-005.svg)

# イベントID( EVT-20260608-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→15→…→14→13→12→13
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.84から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.552, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-006 active_connections の推移](charts/EVT-20260608-host09-006.svg)

# イベントID( EVT-20260608-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→20→…→14→12→13→11
* 開始   : 2026-06-08 04:20:00 (UTC)
* 終了   : 2026-06-08 19:30:00 (UTC)
* 現象   : 2026-06-08 19:30:00 (UTC)を境に水準が 11.99から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.489σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.694, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.801, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host09-007 active_connections の推移](charts/EVT-20260608-host09-007.svg)

# イベントID( EVT-20260615-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→13→…→11→15→13→14
* 開始   : 2026-06-15 01:40:00 (UTC)
* 終了   : 2026-06-15 19:10:00 (UTC)
* 現象   : 2026-06-15 19:10:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.732, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-002 active_connections の推移](charts/EVT-20260615-host09-002.svg)

# イベントID( EVT-20260615-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→17→…→14→13→14→12
* 開始   : 2026-06-15 02:10:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.8から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.671, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-003 active_connections の推移](charts/EVT-20260615-host09-003.svg)

# イベントID( EVT-20260615-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→18→…→16→14→12→15
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 19:35:00 (UTC)
* 現象   : 2026-06-15 19:35:00 (UTC)を境に水準が 11.92から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.786, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.276, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-005 active_connections の推移](charts/EVT-20260615-host09-005.svg)

# イベントID( EVT-20260615-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→17→…→14→13→11→14
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.895, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.701, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-006 active_connections の推移](charts/EVT-20260615-host09-006.svg)

# イベントID( EVT-20260615-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→15→…→12→13→14→12
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 22:10:00 (UTC)
* 現象   : 2026-06-15 22:10:00 (UTC)を境に水準が 11.65から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.249, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-007 active_connections の推移](charts/EVT-20260615-host09-007.svg)

# イベントID( EVT-20260622-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→15→14→15→…→14→12→10→14
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 19:05:00 (UTC)
* 現象   : 2026-06-22 19:05:00 (UTC)を境に水準が 11.8から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.618σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.972, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.296, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-002 active_connections の推移](charts/EVT-20260622-host09-002.svg)

# イベントID( EVT-20260622-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→12→…→13→14→13→14
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 21:15:00 (UTC)
* 現象   : 2026-06-22 21:15:00 (UTC)を境に水準が 11.8から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.955σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.975, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-004 active_connections の推移](charts/EVT-20260622-host09-004.svg)

# イベントID( EVT-20260622-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→15→…→12→14→12→13
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.756, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-005 active_connections の推移](charts/EVT-20260622-host09-005.svg)

# イベントID( EVT-20260622-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→17→…→15→11→15→11
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 12.01から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.024, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-006 active_connections の推移](charts/EVT-20260622-host09-006.svg)

# イベントID( EVT-20260622-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→17→18→16→…→12→13→12→11
* 開始   : 2026-06-22 05:00:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.89から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.808, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-007 active_connections の推移](charts/EVT-20260622-host09-007.svg)

# イベントID( EVT-20260629-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→14→18→16→…→16→14→16→15
* 開始   : 2026-06-29 01:10:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.77から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.89, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.965, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-001 active_connections の推移](charts/EVT-20260629-host09-001.svg)

# イベントID( EVT-20260629-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→13→16→…→13→15→14→13
* 開始   : 2026-06-29 01:15:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.616σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.682, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.646, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-002 active_connections の推移](charts/EVT-20260629-host09-002.svg)

# イベントID( EVT-20260629-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→16→…→15→14→11→13
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.85から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.664, 限界=2.698)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.374, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-003 active_connections の推移](charts/EVT-20260629-host09-003.svg)

# イベントID( EVT-20260629-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→18→21→16→…→15→14→13→12
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 11.96から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.276, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-004 active_connections の推移](charts/EVT-20260629-host09-004.svg)

# イベントID( EVT-20260629-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→15→…→14→15→16→14
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:45:00 (UTC)
* 現象   : 2026-06-29 20:45:00 (UTC)を境に水準が 11.84から15.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.699, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-005 active_connections の推移](charts/EVT-20260629-host09-005.svg)

# イベントID( EVT-20260629-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→18→15→18→…→15→14→11→14
* 開始   : 2026-06-29 04:10:00 (UTC)
* 終了   : 2026-06-29 19:30:00 (UTC)
* 現象   : 2026-06-29 19:30:00 (UTC)を境に水準が 12.08から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.922, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host09-006 active_connections の推移](charts/EVT-20260629-host09-006.svg)

# イベントID( EVT-20260601-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→15→23→18→19
* 開始   : 2026-06-01 07:20:00 (UTC)
* 終了   : 2026-06-01 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.453倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 5.001σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host09-005 active_connections の推移](charts/EVT-20260601-host09-005.svg)

# イベントID( EVT-20260601-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→16→20→20
* 開始   : 2026-06-01 15:00:00 (UTC)
* 終了   : 2026-06-01 15:00:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→14→13
* 開始   : 2026-06-01 18:20:00 (UTC)
* 終了   : 2026-06-01 18:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→8→7
* 開始   : 2026-06-01 21:45:00 (UTC)
* 終了   : 2026-06-01 21:45:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 8→9→13→10→9
* 開始   : 2026-06-02 02:30:00 (UTC)
* 終了   : 2026-06-02 02:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→13→14
* 開始   : 2026-06-02 04:25:00 (UTC)
* 終了   : 2026-06-02 04:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→15→20→17→19
* 開始   : 2026-06-02 06:50:00 (UTC)
* 終了   : 2026-06-02 06:50:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→20→18→23
* 開始   : 2026-06-02 07:45:00 (UTC)
* 終了   : 2026-06-02 08:00:00 (UTC)
* 現象   : 2026-06-02 08:00:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→20→24→20→24→20→24→23→20
* 開始   : 2026-06-02 09:25:00 (UTC)
* 終了   : 2026-06-02 09:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→16→20→17→16
* 開始   : 2026-06-03 07:00:00 (UTC)
* 終了   : 2026-06-03 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 21→19→24→21→22
* 開始   : 2026-06-03 10:00:00 (UTC)
* 終了   : 2026-06-03 10:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→22→24→18→…→24→18→19→22
* 開始   : 2026-06-03 15:00:00 (UTC)
* 終了   : 2026-06-03 15:25:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260603-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host09-009 active_connections の推移](charts/EVT-20260603-host09-009.svg)

# イベントID( EVT-20260603-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→15→12→14→15
* 開始   : 2026-06-03 18:00:00 (UTC)
* 終了   : 2026-06-03 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→12→16→14→12
* 開始   : 2026-06-04 04:30:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-001 active_connections の推移](charts/EVT-20260604-host09-001.svg)

# イベントID( EVT-20260604-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→17→17
* 開始   : 2026-06-04 06:35:00 (UTC)
* 終了   : 2026-06-04 06:35:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.387倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.914σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host09-003 active_connections の推移](charts/EVT-20260604-host09-003.svg)

# イベントID( EVT-20260604-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 16→17→20→18→19
* 開始   : 2026-06-04 06:50:00 (UTC)
* 終了   : 2026-06-04 06:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→20→23→19→21
* 開始   : 2026-06-04 09:00:00 (UTC)
* 終了   : 2026-06-04 09:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 23→22→18→19→21
* 開始   : 2026-06-04 13:10:00 (UTC)
* 終了   : 2026-06-04 13:10:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→21→17→19→20
* 開始   : 2026-06-04 14:30:00 (UTC)
* 終了   : 2026-06-04 14:30:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→16→11→17→16
* 開始   : 2026-06-04 18:10:00 (UTC)
* 終了   : 2026-06-04 18:55:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260604-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-012 active_connections の推移](charts/EVT-20260604-host09-012.svg)

# イベントID( EVT-20260604-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→13→14→12
* 開始   : 2026-06-04 20:45:00 (UTC)
* 終了   : 2026-06-04 21:55:00 (UTC)
* 現象   : 2026-06-04 21:55:00 (UTC)を境に水準が 15.04から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 9→11→6→4→8→11→6→4→8
* 開始   : 2026-06-04 23:00:00 (UTC)
* 終了   : 2026-06-04 23:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→11→15→12→12
* 開始   : 2026-06-05 04:10:00 (UTC)
* 終了   : 2026-06-05 04:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→14→20→18→20→18→20→18
* 開始   : 2026-06-05 06:25:00 (UTC)
* 終了   : 2026-06-05 07:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.245σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260605-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260605-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 16→17→20→17→18
* 開始   : 2026-06-05 07:00:00 (UTC)
* 終了   : 2026-06-05 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→20→…→20→24→19→20
* 開始   : 2026-06-05 08:25:00 (UTC)
* 終了   : 2026-06-05 08:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→16→22→21→…→22→21→19→20
* 開始   : 2026-06-05 08:30:00 (UTC)
* 終了   : 2026-06-05 08:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→20→25→20→19
* 開始   : 2026-06-05 15:15:00 (UTC)
* 終了   : 2026-06-05 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→11→12→13
* 開始   : 2026-06-05 20:45:00 (UTC)
* 終了   : 2026-06-05 21:30:00 (UTC)
* 現象   : 2026-06-05 21:30:00 (UTC)を境に水準が 14.96から11.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→10→6→8→10
* 開始   : 2026-06-05 21:00:00 (UTC)
* 終了   : 2026-06-05 21:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.5373(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-077 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host09-013 active_connections の推移](charts/EVT-20260605-host09-013.svg)

# イベントID( EVT-20260606-host09-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→10→8→11→…→11→10→12→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.307, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host09-002 active_connections の推移](charts/EVT-20260606-host09-002.svg)

# イベントID( EVT-20260606-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→10→12→13→…→11→12→13→12
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.021, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host09-003 active_connections の推移](charts/EVT-20260606-host09-003.svg)

# イベントID( EVT-20260606-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→12→11→13→…→9→10→12→13
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 20:50:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.868, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host09-005 active_connections の推移](charts/EVT-20260606-host09-005.svg)

# イベントID( EVT-20260606-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→14→…→11→10→11→12
* 開始   : 2026-06-06 06:25:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.507, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host09-006 active_connections の推移](charts/EVT-20260606-host09-006.svg)

# イベントID( EVT-20260606-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→13→12→11→…→11→12→13→12
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.789, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-004 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host09-007 active_connections の推移](charts/EVT-20260606-host09-007.svg)

# イベントID( EVT-20260607-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→14→17→13→14
* 開始   : 2026-06-07 07:50:00 (UTC)
* 終了   : 2026-06-07 07:50:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→13→14
* 開始   : 2026-06-07 08:00:00 (UTC)
* 終了   : 2026-06-07 08:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→15→19→13→14
* 開始   : 2026-06-07 15:20:00 (UTC)
* 終了   : 2026-06-07 15:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→11→13
* 開始   : 2026-06-07 16:50:00 (UTC)
* 終了   : 2026-06-07 16:50:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.5854(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.948σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host09-010 active_connections の推移](charts/EVT-20260607-host09-010.svg)

# イベントID( EVT-20260607-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→9→5→9→10
* 開始   : 2026-06-07 21:35:00 (UTC)
* 終了   : 2026-06-07 21:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→14→18→14→13
* 開始   : 2026-06-09 05:20:00 (UTC)
* 終了   : 2026-06-09 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-001 active_connections の推移](charts/EVT-20260609-host09-001.svg)

# イベントID( EVT-20260609-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→15→20→16→17
* 開始   : 2026-06-09 06:40:00 (UTC)
* 終了   : 2026-06-09 06:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→22→23→18→22→23→18→21
* 開始   : 2026-06-09 08:25:00 (UTC)
* 終了   : 2026-06-09 08:30:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→17→22→18→24→22→18→24→20
* 開始   : 2026-06-09 09:00:00 (UTC)
* 終了   : 2026-06-09 09:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→22→22
* 開始   : 2026-06-09 11:10:00 (UTC)
* 終了   : 2026-06-09 11:10:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 24→21→26→20→21
* 開始   : 2026-06-09 11:20:00 (UTC)
* 終了   : 2026-06-09 11:20:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.187σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→10→6→9→10
* 開始   : 2026-06-09 22:00:00 (UTC)
* 終了   : 2026-06-09 22:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→19→23→20→20
* 開始   : 2026-06-10 08:35:00 (UTC)
* 終了   : 2026-06-10 08:35:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.419σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→21→16→20→21
* 開始   : 2026-06-10 15:25:00 (UTC)
* 終了   : 2026-06-10 15:25:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→17→13→18→17
* 開始   : 2026-06-10 16:55:00 (UTC)
* 終了   : 2026-06-10 16:55:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→11→13→10→9
* 開始   : 2026-06-11 02:30:00 (UTC)
* 終了   : 2026-06-11 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→12→11
* 開始   : 2026-06-11 04:50:00 (UTC)
* 終了   : 2026-06-11 04:50:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→19→16→17→19→16
* 開始   : 2026-06-11 06:10:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 16→16→19→16→15
* 開始   : 2026-06-11 06:15:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→17→17
* 開始   : 2026-06-11 06:30:00 (UTC)
* 終了   : 2026-06-11 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→21→18→21→18→21→22
* 開始   : 2026-06-11 13:20:00 (UTC)
* 終了   : 2026-06-11 13:25:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.188σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→13→8→12→12
* 開始   : 2026-06-11 20:15:00 (UTC)
* 終了   : 2026-06-11 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→15→15
* 開始   : 2026-06-12 05:30:00 (UTC)
* 終了   : 2026-06-12 05:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-003 active_connections の推移](charts/EVT-20260612-host09-003.svg)

# イベントID( EVT-20260612-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 23→21→27→22→22
* 開始   : 2026-06-12 11:45:00 (UTC)
* 終了   : 2026-06-12 11:45:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.241倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.663σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-011 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分

![EVT-20260612-host09-007 active_connections の推移](charts/EVT-20260612-host09-007.svg)

# イベントID( EVT-20260612-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→12→8→13→12
* 開始   : 2026-06-12 19:55:00 (UTC)
* 終了   : 2026-06-12 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-010 active_connections の推移](charts/EVT-20260612-host09-010.svg)

# イベントID( EVT-20260613-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→9→10→9→…→12→11→13→11
* 開始   : 2026-06-13 04:45:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.246, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host09-001 active_connections の推移](charts/EVT-20260613-host09-001.svg)

# イベントID( EVT-20260613-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→13→14→13→…→11→13→11→10
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.935, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host09-002 active_connections の推移](charts/EVT-20260613-host09-002.svg)

# イベントID( EVT-20260613-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→12→…→9→11→12→9
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.193, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host09-003 active_connections の推移](charts/EVT-20260613-host09-003.svg)

# イベントID( EVT-20260613-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→13→…→12→10→12→11
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.997, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host09-004 active_connections の推移](charts/EVT-20260613-host09-004.svg)

# イベントID( EVT-20260613-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→13→12→13→12
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.896σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.84, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host09-005 active_connections の推移](charts/EVT-20260613-host09-005.svg)

# イベントID( EVT-20260613-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→10→12→13→12
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host09-006 active_connections の推移](charts/EVT-20260613-host09-006.svg)

# イベントID( EVT-20260613-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→7→…→6→7→8→12
* 開始   : 2026-06-13 20:25:00 (UTC)
* 終了   : 2026-06-13 20:30:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→8→12→9→9
* 開始   : 2026-06-15 00:30:00 (UTC)
* 終了   : 2026-06-15 00:30:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-lsfhost01-001 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260615-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→17→…→13→15→13→12
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.85から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.043, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→12
* 開始   : 2026-06-16 04:00:00 (UTC)
* 終了   : 2026-06-16 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→20→18→…→20→18→16→17
* 開始   : 2026-06-16 06:40:00 (UTC)
* 終了   : 2026-06-16 06:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.371倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.779σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host09-003 active_connections の推移](charts/EVT-20260616-host09-003.svg)

# イベントID( EVT-20260616-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→20→23→19→19
* 開始   : 2026-06-16 08:50:00 (UTC)
* 終了   : 2026-06-16 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→8→14→9→10
* 開始   : 2026-06-17 03:05:00 (UTC)
* 終了   : 2026-06-17 03:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→11→16→13→13
* 開始   : 2026-06-17 04:35:00 (UTC)
* 終了   : 2026-06-17 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→14→13→16→14
* 開始   : 2026-06-17 05:00:00 (UTC)
* 終了   : 2026-06-17 05:40:00 (UTC)
* 現象   : 平常時(12)に対し 1.333倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.791σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host09-003 active_connections の推移](charts/EVT-20260617-host09-003.svg)

# イベントID( EVT-20260617-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→15→19→15→15
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host09-004 active_connections の推移](charts/EVT-20260617-host09-004.svg)

# イベントID( EVT-20260617-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→12→12
* 開始   : 2026-06-17 19:35:00 (UTC)
* 終了   : 2026-06-17 19:35:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→11→8→10→11
* 開始   : 2026-06-17 20:35:00 (UTC)
* 終了   : 2026-06-17 21:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-021 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260617-host13-020 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260617-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-081 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260617-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 7→12→11→8→7→12→11→8→9
* 開始   : 2026-06-18 00:05:00 (UTC)
* 終了   : 2026-06-18 00:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260618-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→11→15→13→11
* 開始   : 2026-06-18 04:00:00 (UTC)
* 終了   : 2026-06-18 04:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260618-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→19→22→18→17
* 開始   : 2026-06-18 08:10:00 (UTC)
* 終了   : 2026-06-18 08:10:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→20→20
* 開始   : 2026-06-18 08:45:00 (UTC)
* 終了   : 2026-06-18 08:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 21→21→16→19→18
* 開始   : 2026-06-18 15:45:00 (UTC)
* 終了   : 2026-06-18 15:45:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→19→15→18→18
* 開始   : 2026-06-18 16:10:00 (UTC)
* 終了   : 2026-06-18 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→4→8→10→13→4→8
* 開始   : 2026-06-18 21:45:00 (UTC)
* 終了   : 2026-06-18 21:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host09-008 active_connections の推移](charts/EVT-20260618-host09-008.svg)

# イベントID( EVT-20260619-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→15→16→19
* 開始   : 2026-06-19 05:20:00 (UTC)
* 終了   : 2026-06-19 05:35:00 (UTC)
* 現象   : 2026-06-19 05:35:00 (UTC)を境に水準が 15.02から14.78へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→16→18
* 開始   : 2026-06-19 07:25:00 (UTC)
* 終了   : 2026-06-19 07:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→16→14→16→…→16→12→16→15
* 開始   : 2026-06-19 17:40:00 (UTC)
* 終了   : 2026-06-19 17:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→16→12→15→14
* 開始   : 2026-06-19 18:00:00 (UTC)
* 終了   : 2026-06-19 18:00:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.605σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→13→…→11→10→12→14
* 開始   : 2026-06-20 04:25:00 (UTC)
* 終了   : 2026-06-20 19:45:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.908, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260620-host09-003 active_connections の推移](charts/EVT-20260620-host09-003.svg)

# イベントID( EVT-20260620-host09-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→13→14→12→…→12→11→12→11
* 開始   : 2026-06-20 04:55:00 (UTC)
* 終了   : 2026-06-20 18:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.112, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host09-004 active_connections の推移](charts/EVT-20260620-host09-004.svg)

# イベントID( EVT-20260620-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→10→11→12→…→12→13→12→13
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.733, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host09-005 active_connections の推移](charts/EVT-20260620-host09-005.svg)

# イベントID( EVT-20260620-host09-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→13→…→11→13→10→13
* 開始   : 2026-06-20 05:30:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host09-006 active_connections の推移](charts/EVT-20260620-host09-006.svg)

# イベントID( EVT-20260620-host09-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→9→12→9→…→10→13→12→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host09-007 active_connections の推移](charts/EVT-20260620-host09-007.svg)

# イベントID( EVT-20260620-host09-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→12→…→13→12→14→13
* 開始   : 2026-06-20 06:30:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host09-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260620-host09-008 active_connections の推移](charts/EVT-20260620-host09-008.svg)

# イベントID( EVT-20260621-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→16→10→14→16
* 開始   : 2026-06-21 13:55:00 (UTC)
* 終了   : 2026-06-21 13:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→15→10→16→13
* 開始   : 2026-06-21 15:40:00 (UTC)
* 終了   : 2026-06-21 15:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.6486(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.797σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host09-003 active_connections の推移](charts/EVT-20260621-host09-003.svg)

# イベントID( EVT-20260621-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→14→8→14→13
* 開始   : 2026-06-21 17:25:00 (UTC)
* 終了   : 2026-06-21 17:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.5926(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.838σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host09-005 active_connections の推移](charts/EVT-20260621-host09-005.svg)

# イベントID( EVT-20260622-host09-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→14→…→13→11→13→14
* 開始   : 2026-06-22 03:05:00 (UTC)
* 終了   : 2026-06-22 19:45:00 (UTC)
* 現象   : 2026-06-22 19:45:00 (UTC)を境に水準が 11.87から14.77へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.035, 限界=2.71)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→13→12
* 開始   : 2026-06-23 04:20:00 (UTC)
* 終了   : 2026-06-23 04:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host09-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→15→18→15→15
* 開始   : 2026-06-23 05:40:00 (UTC)
* 終了   : 2026-06-23 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→14→11→12
* 開始   : 2026-06-24 03:15:00 (UTC)
* 終了   : 2026-06-24 03:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→22→23
* 開始   : 2026-06-24 09:10:00 (UTC)
* 終了   : 2026-06-24 09:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.129σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→15→…→16→15→17→16
* 開始   : 2026-06-24 16:20:00 (UTC)
* 終了   : 2026-06-24 16:55:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 25 分
  - EVT-20260624-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260624-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-011 active_connections の推移](charts/EVT-20260624-host09-011.svg)

# イベントID( EVT-20260625-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 23→22→17→21→20
* 開始   : 2026-06-25 13:45:00 (UTC)
* 終了   : 2026-06-25 13:45:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→20→15→19→19
* 開始   : 2026-06-25 15:40:00 (UTC)
* 終了   : 2026-06-25 15:40:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→12→12
* 開始   : 2026-06-25 19:20:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→10→8→10→12
* 開始   : 2026-06-25 19:50:00 (UTC)
* 終了   : 2026-06-25 19:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 9→11→4→11→…→11→6→8→7
* 開始   : 2026-06-25 22:20:00 (UTC)
* 終了   : 2026-06-25 22:30:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.4324(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host09-013 active_connections の推移](charts/EVT-20260625-host09-013.svg)

# イベントID( EVT-20260626-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→14→19→15→15
* 開始   : 2026-06-26 05:45:00 (UTC)
* 終了   : 2026-06-26 05:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.407倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-003 active_connections の推移](charts/EVT-20260626-host09-003.svg)

# イベントID( EVT-20260626-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→17→18
* 開始   : 2026-06-26 16:35:00 (UTC)
* 終了   : 2026-06-26 16:35:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 19→19→14→17→16
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→11→10
* 開始   : 2026-06-26 20:50:00 (UTC)
* 終了   : 2026-06-26 20:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host09-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→13→…→13→12→13→11
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.051, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host09-001 active_connections の推移](charts/EVT-20260627-host09-001.svg)

# イベントID( EVT-20260627-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→12→…→12→10→13→11
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.204, 限界=2.698)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host09-002 active_connections の推移](charts/EVT-20260627-host09-002.svg)

# イベントID( EVT-20260627-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→11→…→15→13→15→13
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.926, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host09-003 active_connections の推移](charts/EVT-20260627-host09-003.svg)

# イベントID( EVT-20260627-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→12→…→13→10→13→10
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.061, 限界=2.71)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host09-004 active_connections の推移](charts/EVT-20260627-host09-004.svg)

# イベントID( EVT-20260627-host09-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→14→11→13→10
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.789, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260627-host09-005 active_connections の推移](charts/EVT-20260627-host09-005.svg)

# イベントID( EVT-20260627-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→12→…→12→13→12→13
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host09-006 active_connections の推移](charts/EVT-20260627-host09-006.svg)

# イベントID( EVT-20260628-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→12→12
* 開始   : 2026-06-28 06:40:00 (UTC)
* 終了   : 2026-06-28 06:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.071σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 14→15→19→14→16
* 開始   : 2026-06-28 15:25:00 (UTC)
* 終了   : 2026-06-28 15:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→9→11
* 開始   : 2026-06-28 18:00:00 (UTC)
* 終了   : 2026-06-28 19:00:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260628-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host09-005 active_connections の推移](charts/EVT-20260628-host09-005.svg)

# イベントID( EVT-20260629-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 8→10→5→8→8
* 開始   : 2026-06-29 22:35:00 (UTC)
* 終了   : 2026-06-29 22:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→7→12→8→8
* 開始   : 2026-06-30 00:30:00 (UTC)
* 終了   : 2026-06-30 00:30:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→9→4→12→9→4→12→9→7
* 開始   : 2026-06-30 01:00:00 (UTC)
* 終了   : 2026-06-30 01:05:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.4948(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.84σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-001 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→8→11→9
* 開始   : 2026-06-30 01:10:00 (UTC)
* 終了   : 2026-06-30 02:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.696倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host09-003 active_connections の推移](charts/EVT-20260630-host09-003.svg)

# イベントID( EVT-20260630-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→9→14→9→11
* 開始   : 2026-06-30 03:40:00 (UTC)
* 終了   : 2026-06-30 03:40:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→13→…→12→14→10→12
* 開始   : 2026-06-30 03:45:00 (UTC)
* 終了   : 2026-06-30 04:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 19→19→22→19→20
* 開始   : 2026-06-30 08:10:00 (UTC)
* 終了   : 2026-06-30 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.013σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 22→20→26→22→21
* 開始   : 2026-06-30 12:55:00 (UTC)
* 終了   : 2026-06-30 12:55:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 9→11→12→9→…→12→14→12→10
* 開始   : 2026-06-01 02:50:00 (UTC)
* 終了   : 2026-06-01 03:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260601-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→14→16→14
* 開始   : 2026-06-01 05:20:00 (UTC)
* 終了   : 2026-06-01 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→19→18→15→19→16→17
* 開始   : 2026-06-01 06:00:00 (UTC)
* 終了   : 2026-06-01 06:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→17→…→17→20→17→19
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 19→21→23→21→23→21→20
* 開始   : 2026-06-01 09:25:00 (UTC)
* 終了   : 2026-06-01 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→20→16→17→20→16→17
* 開始   : 2026-06-01 16:30:00 (UTC)
* 終了   : 2026-06-01 16:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260601-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→8→9→9→9→9→10→9
* 開始   : 2026-06-02 00:00:00 (UTC)
* 終了   : 2026-06-02 00:35:00 (UTC)
* 現象   : 2026-06-02 00:35:00 (UTC)を境に水準が 15.1から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.411, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→13→12→13→8→10
* 開始   : 2026-06-02 03:10:00 (UTC)
* 終了   : 2026-06-02 03:20:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 15→14→18→12→…→16→12→18→16
* 開始   : 2026-06-02 06:20:00 (UTC)
* 終了   : 2026-06-02 06:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→25→19→23→22→25→19→23→24
* 開始   : 2026-06-02 11:30:00 (UTC)
* 終了   : 2026-06-02 11:35:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→21→18→21→…→21→17→21→18
* 開始   : 2026-06-02 15:15:00 (UTC)
* 終了   : 2026-06-02 15:25:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→14→16→12→14→13
* 開始   : 2026-06-02 18:25:00 (UTC)
* 終了   : 2026-06-02 18:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→10→12→10→9→10→12→12→11
* 開始   : 2026-06-02 21:10:00 (UTC)
* 終了   : 2026-06-02 21:50:00 (UTC)
* 現象   : 2026-06-02 21:50:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 8→10→6→7→10→6→7→9
* 開始   : 2026-06-02 22:30:00 (UTC)
* 終了   : 2026-06-02 22:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-001 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→15→10→13→10→13→10→14
* 開始   : 2026-06-03 05:05:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 水曜5時台の平常値(14.02)に対し 10であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.311σ 外れた (平常値=14.02)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→14→18→14→18→16→17
* 開始   : 2026-06-03 06:20:00 (UTC)
* 終了   : 2026-06-03 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→19→23→24→…→23→24→21→23
* 開始   : 2026-06-03 10:15:00 (UTC)
* 終了   : 2026-06-03 10:20:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 22→25→26→23→22→25→26→23
* 開始   : 2026-06-03 11:25:00 (UTC)
* 終了   : 2026-06-03 11:30:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260603-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→24→19→25→22→24→19→25→22
* 開始   : 2026-06-03 11:50:00 (UTC)
* 終了   : 2026-06-03 11:55:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 21→18→20→18→20→18→20→23
* 開始   : 2026-06-03 14:25:00 (UTC)
* 終了   : 2026-06-03 14:35:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.8308(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→17→13→12→…→13→12→14→15
* 開始   : 2026-06-03 18:15:00 (UTC)
* 終了   : 2026-06-03 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→14→12→14→12→14
* 開始   : 2026-06-03 18:50:00 (UTC)
* 終了   : 2026-06-03 18:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→11→12→12→11→11→12→9→13
* 開始   : 2026-06-03 20:00:00 (UTC)
* 終了   : 2026-06-03 20:40:00 (UTC)
* 現象   : 2026-06-03 20:40:00 (UTC)を境に水準が 15.03から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→11→10→12→13→10→12
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 21:40:00 (UTC)
* 現象   : 2026-06-03 21:40:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.561, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→9→…→9→6→11→8
* 開始   : 2026-06-03 21:15:00 (UTC)
* 終了   : 2026-06-03 21:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260603-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→12→11→15→12
* 開始   : 2026-06-04 04:55:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260604-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→21→19→21→19→17→18→18→20
* 開始   : 2026-06-04 15:20:00 (UTC)
* 終了   : 2026-06-04 16:05:00 (UTC)
* 現象   : 2026-06-04 16:05:00 (UTC)を境に水準が 15.07から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.623, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→20→20→19→18→20→18→18→19
* 開始   : 2026-06-04 16:00:00 (UTC)
* 終了   : 2026-06-04 16:45:00 (UTC)
* 現象   : 2026-06-04 16:45:00 (UTC)を境に水準が 15から15.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.668, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→15→14→15→14→17→15
* 開始   : 2026-06-04 17:10:00 (UTC)
* 終了   : 2026-06-04 17:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→18→13→17→13→17→13→17→16
* 開始   : 2026-06-04 17:30:00 (UTC)
* 終了   : 2026-06-04 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.7647(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.804σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→7→…→8→7→8→10
* 開始   : 2026-06-04 20:45:00 (UTC)
* 終了   : 2026-06-04 20:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→9→10→9→11
* 開始   : 2026-06-05 00:40:00 (UTC)
* 終了   : 2026-06-05 01:10:00 (UTC)
* 現象   : 2026-06-05 01:10:00 (UTC)を境に水準が 15.03から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 11→13→11→10
* 開始   : 2026-06-05 02:15:00 (UTC)
* 終了   : 2026-06-05 02:30:00 (UTC)
* 現象   : 2026-06-05 02:30:00 (UTC)を境に水準が 14.94から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→14→11→14→11→14→12→13
* 開始   : 2026-06-05 03:50:00 (UTC)
* 終了   : 2026-06-05 04:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-007 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→13→14→15→13→14→15→13→12
* 開始   : 2026-06-05 04:45:00 (UTC)
* 終了   : 2026-06-05 04:50:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→24→19→23→…→19→18→22→21
* 開始   : 2026-06-05 13:20:00 (UTC)
* 終了   : 2026-06-05 13:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→13→…→12→13→9→10
* 開始   : 2026-06-06 04:10:00 (UTC)
* 終了   : 2026-06-06 04:30:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 10→8→12→10→…→10→6→8→6
* 開始   : 2026-06-07 00:15:00 (UTC)
* 終了   : 2026-06-07 00:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 10→9→11→9→10→10→11→10
* 開始   : 2026-06-07 02:00:00 (UTC)
* 終了   : 2026-06-07 02:35:00 (UTC)
* 現象   : 2026-06-07 02:35:00 (UTC)を境に水準が 11.72から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.441, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 7→8→5→11→9→8→5→11→9
* 開始   : 2026-06-07 02:25:00 (UTC)
* 終了   : 2026-06-07 02:30:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→12→13→12→12→11→11
* 開始   : 2026-06-07 04:15:00 (UTC)
* 終了   : 2026-06-07 05:05:00 (UTC)
* 現象   : 2026-06-07 05:05:00 (UTC)を境に水準が 11.72から12.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 13→16→13→16→13→16→14→13
* 開始   : 2026-06-07 07:35:00 (UTC)
* 終了   : 2026-06-07 07:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→14→16→12→14→13
* 開始   : 2026-06-07 14:05:00 (UTC)
* 終了   : 2026-06-07 14:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→5→8→11→5→8→11→9
* 開始   : 2026-06-08 00:10:00 (UTC)
* 終了   : 2026-06-08 00:20:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260608-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260608-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→15→18→19→…→18→19→16→17
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→19→18→21→19→18→21→20
* 開始   : 2026-06-09 14:10:00 (UTC)
* 終了   : 2026-06-09 14:15:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 23→22→18→21→18→21→18→19→21
* 開始   : 2026-06-09 14:55:00 (UTC)
* 終了   : 2026-06-09 15:05:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260609-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→21→20→20→22→20→20→20→20
* 開始   : 2026-06-09 15:00:00 (UTC)
* 終了   : 2026-06-09 15:50:00 (UTC)
* 現象   : 2026-06-09 15:50:00 (UTC)を境に水準が 15.01から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→18→15→18→15→18
* 開始   : 2026-06-09 16:55:00 (UTC)
* 終了   : 2026-06-09 17:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→17→12→14→…→14→12→11→14
* 開始   : 2026-06-09 18:40:00 (UTC)
* 終了   : 2026-06-09 18:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.724σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260609-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→7→10→11→7→10
* 開始   : 2026-06-09 21:25:00 (UTC)
* 終了   : 2026-06-09 21:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 7→8→11→8→11→8→9
* 開始   : 2026-06-09 23:45:00 (UTC)
* 終了   : 2026-06-09 23:50:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-082 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260609-host09-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 11→14→15→12→…→15→12→16→12
* 開始   : 2026-06-10 04:35:00 (UTC)
* 終了   : 2026-06-10 04:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260610-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→13→16→13→16→15
* 開始   : 2026-06-10 05:35:00 (UTC)
* 終了   : 2026-06-10 05:45:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→18→22→20→22→20→22→19
* 開始   : 2026-06-10 08:35:00 (UTC)
* 終了   : 2026-06-10 09:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260610-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→16→17→15→16→18
* 開始   : 2026-06-10 16:55:00 (UTC)
* 終了   : 2026-06-10 17:00:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→13→9→10→13→9→12
* 開始   : 2026-06-10 19:20:00 (UTC)
* 終了   : 2026-06-10 19:30:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→9→8→7→…→8→7→11→10
* 開始   : 2026-06-10 21:10:00 (UTC)
* 終了   : 2026-06-10 21:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→17→18→14→…→16→17→18→16
* 開始   : 2026-06-11 06:05:00 (UTC)
* 終了   : 2026-06-11 06:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 22→22→23→22→20→21→18→20→21
* 開始   : 2026-06-11 14:40:00 (UTC)
* 終了   : 2026-06-11 15:30:00 (UTC)
* 現象   : 2026-06-11 15:30:00 (UTC)を境に水準が 15.01から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.607, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 18→19→15→17→19→15→17
* 開始   : 2026-06-11 16:20:00 (UTC)
* 終了   : 2026-06-11 16:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.7826(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260611-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→17→…→16→17→15→18
* 開始   : 2026-06-11 16:25:00 (UTC)
* 終了   : 2026-06-11 16:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→10→8→10→8→10→8
* 開始   : 2026-06-11 21:30:00 (UTC)
* 終了   : 2026-06-11 21:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→13→13→11→15→11→15
* 開始   : 2026-06-12 03:25:00 (UTC)
* 終了   : 2026-06-12 04:20:00 (UTC)
* 現象   : 2026-06-12 04:20:00 (UTC)を境に水準が 14.94から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→12→11→15→12→11
* 開始   : 2026-06-12 04:15:00 (UTC)
* 終了   : 2026-06-12 04:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→17→15→18→17→15→18→14→15
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 17→18→22→19→18→22→19
* 開始   : 2026-06-12 08:30:00 (UTC)
* 終了   : 2026-06-12 08:35:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.211倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 23→23→23→22
* 開始   : 2026-06-12 09:50:00 (UTC)
* 終了   : 2026-06-12 10:05:00 (UTC)
* 現象   : 2026-06-12 10:05:00 (UTC)を境に水準が 14.99から14.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 23→19→23→19→23→19→22
* 開始   : 2026-06-12 12:25:00 (UTC)
* 終了   : 2026-06-12 12:35:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260612-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 12→10→13→10→13→10→13→12
* 開始   : 2026-06-12 19:35:00 (UTC)
* 終了   : 2026-06-12 19:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→9→12→9→12→9→10→12
* 開始   : 2026-06-12 20:20:00 (UTC)
* 終了   : 2026-06-12 20:30:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→11→…→11→7→9→10
* 開始   : 2026-06-12 21:15:00 (UTC)
* 終了   : 2026-06-12 21:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-090 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→12→…→11→12→9→8
* 開始   : 2026-06-12 23:40:00 (UTC)
* 終了   : 2026-06-12 23:45:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→13→12→12
* 開始   : 2026-06-14 18:30:00 (UTC)
* 終了   : 2026-06-14 19:30:00 (UTC)
* 現象   : 2026-06-14 19:30:00 (UTC)を境に水準が 11.81から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.235, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→11→7→6→11→7→6→11
* 開始   : 2026-06-14 20:30:00 (UTC)
* 終了   : 2026-06-14 20:35:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→5→8→5→8→5→8→10
* 開始   : 2026-06-14 23:00:00 (UTC)
* 終了   : 2026-06-14 23:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→13→12→15→13
* 開始   : 2026-06-16 04:30:00 (UTC)
* 終了   : 2026-06-16 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 17→19→15→14→17→19→15→14→17
* 開始   : 2026-06-16 17:15:00 (UTC)
* 終了   : 2026-06-16 17:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→14→…→13→11→13→12
* 開始   : 2026-06-16 19:15:00 (UTC)
* 終了   : 2026-06-16 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260616-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260616-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→13→11→11→12→11→12
* 開始   : 2026-06-16 19:35:00 (UTC)
* 終了   : 2026-06-16 20:35:00 (UTC)
* 現象   : 2026-06-16 20:35:00 (UTC)を境に水準が 14.99から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.717, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→16→17→13→16→14
* 開始   : 2026-06-17 17:45:00 (UTC)
* 終了   : 2026-06-17 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host09-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→10→11→12→10→11
* 開始   : 2026-06-18 02:05:00 (UTC)
* 終了   : 2026-06-18 02:30:00 (UTC)
* 現象   : 2026-06-18 02:30:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.801, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→18→13→20→18→13→20→18→19
* 開始   : 2026-06-19 07:35:00 (UTC)
* 終了   : 2026-06-19 07:40:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→20→23→20→17→23→20→17→21
* 開始   : 2026-06-19 08:50:00 (UTC)
* 終了   : 2026-06-19 09:00:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 21→23→24→19→24→19→24→22→23
* 開始   : 2026-06-19 11:05:00 (UTC)
* 終了   : 2026-06-19 11:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→14→13→14→14
* 開始   : 2026-06-19 18:35:00 (UTC)
* 終了   : 2026-06-19 19:05:00 (UTC)
* 現象   : 2026-06-19 19:05:00 (UTC)を境に水準が 14.85から12.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.235, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→14→10→14→10→12→10
* 開始   : 2026-06-19 19:40:00 (UTC)
* 終了   : 2026-06-19 19:50:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→8→11→9→8→11
* 開始   : 2026-06-19 20:20:00 (UTC)
* 終了   : 2026-06-19 20:25:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→7→…→8→7→9→11
* 開始   : 2026-06-19 21:05:00 (UTC)
* 終了   : 2026-06-19 21:10:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260619-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 8→11→10→12→11→10→12→9→10
* 開始   : 2026-06-20 02:10:00 (UTC)
* 終了   : 2026-06-20 02:20:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→7→13→9→13→9→13→10
* 開始   : 2026-06-20 03:45:00 (UTC)
* 終了   : 2026-06-20 03:55:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→6→9→6→9→6→10→9
* 開始   : 2026-06-20 21:10:00 (UTC)
* 終了   : 2026-06-20 21:20:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host09-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 10→9→10→9→9
* 開始   : 2026-06-20 23:30:00 (UTC)
* 終了   : 2026-06-20 23:50:00 (UTC)
* 現象   : 2026-06-20 23:50:00 (UTC)を境に水準が 11.87から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 7→9→11→5→…→11→5→7→8
* 開始   : 2026-06-21 00:50:00 (UTC)
* 終了   : 2026-06-21 00:55:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→14→12→16→13
* 開始   : 2026-06-21 15:55:00 (UTC)
* 終了   : 2026-06-21 16:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host09-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 9→10→10→11→8→10→9→9→11
* 開始   : 2026-06-21 22:00:00 (UTC)
* 終了   : 2026-06-21 22:40:00 (UTC)
* 現象   : 2026-06-21 22:40:00 (UTC)を境に水準が 11.71から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→9→10→8→8→10→11
* 開始   : 2026-06-22 00:50:00 (UTC)
* 終了   : 2026-06-22 02:30:00 (UTC)
* 現象   : 2026-06-22 02:30:00 (UTC)を境に水準が 11.87から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 10→7→8→7→8→7→11
* 開始   : 2026-06-22 21:40:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260622-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→11→…→11→15→12→10
* 開始   : 2026-06-23 04:10:00 (UTC)
* 終了   : 2026-06-23 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host09-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→14→14→16→15→14→15→16→18
* 開始   : 2026-06-23 04:50:00 (UTC)
* 終了   : 2026-06-23 06:10:00 (UTC)
* 現象   : 2026-06-23 06:10:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.999, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→14→15→17→15→15
* 開始   : 2026-06-23 05:00:00 (UTC)
* 終了   : 2026-06-23 05:45:00 (UTC)
* 現象   : 2026-06-23 05:45:00 (UTC)を境に水準が 14.98から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.623, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→17→20→21→19→17→20→21→19
* 開始   : 2026-06-23 07:50:00 (UTC)
* 終了   : 2026-06-23 07:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 22→21→20→22→20→21→22→21→24
* 開始   : 2026-06-23 09:15:00 (UTC)
* 終了   : 2026-06-23 10:10:00 (UTC)
* 現象   : 2026-06-23 10:10:00 (UTC)を境に水準が 14.82から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.504, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 9→10→10→11→12→10→12→12→12
* 開始   : 2026-06-24 02:15:00 (UTC)
* 終了   : 2026-06-24 02:55:00 (UTC)
* 現象   : 2026-06-24 02:55:00 (UTC)を境に水準が 14.97から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.588, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 15→18→20→17→20→17→20→18→19
* 開始   : 2026-06-24 07:40:00 (UTC)
* 終了   : 2026-06-24 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→17→21→17→21→19→18
* 開始   : 2026-06-24 08:00:00 (UTC)
* 終了   : 2026-06-24 08:10:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.223倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 19→22→19→22→19
* 開始   : 2026-06-24 08:40:00 (UTC)
* 終了   : 2026-06-24 08:45:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 23→22→22→23→22→21
* 開始   : 2026-06-24 13:00:00 (UTC)
* 終了   : 2026-06-24 13:25:00 (UTC)
* 現象   : 2026-06-24 13:25:00 (UTC)を境に水準が 15.02から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.252, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 20→21→18→20→…→20→17→20→19
* 開始   : 2026-06-24 14:45:00 (UTC)
* 終了   : 2026-06-24 14:55:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260624-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 19→20→16→17→16→17→16→19→17
* 開始   : 2026-06-24 16:10:00 (UTC)
* 終了   : 2026-06-24 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 19→21→16→18→21→16→18
* 開始   : 2026-06-24 16:15:00 (UTC)
* 終了   : 2026-06-24 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 15→13→15→13→15
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→9→…→9→6→8→9
* 開始   : 2026-06-24 22:00:00 (UTC)
* 終了   : 2026-06-24 22:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host12-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260624-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host09-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 9→10→10→8→10
* 開始   : 2026-06-24 23:35:00 (UTC)
* 終了   : 2026-06-24 23:55:00 (UTC)
* 現象   : 2026-06-24 23:55:00 (UTC)を境に水準が 14.99から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.834, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 17→14→18→17→14→18→17
* 開始   : 2026-06-25 06:35:00 (UTC)
* 終了   : 2026-06-25 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 18→19→21→18→19→21→18→20
* 開始   : 2026-06-25 08:05:00 (UTC)
* 終了   : 2026-06-25 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→22→24→21→24→21→24→20→21
* 開始   : 2026-06-25 10:35:00 (UTC)
* 終了   : 2026-06-25 10:45:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 22→21→25→21→19→25→21→19→22
* 開始   : 2026-06-25 11:35:00 (UTC)
* 終了   : 2026-06-25 11:45:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260625-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→23→25→19→…→25→19→20→21
* 開始   : 2026-06-25 13:40:00 (UTC)
* 終了   : 2026-06-25 13:45:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260625-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 22→19→18→17→19→18→17→19→20
* 開始   : 2026-06-25 14:55:00 (UTC)
* 終了   : 2026-06-25 15:00:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→17→13→14→17→13→15
* 開始   : 2026-06-25 17:35:00 (UTC)
* 終了   : 2026-06-25 17:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host09-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→12→16→13→12→16→13
* 開始   : 2026-06-25 18:10:00 (UTC)
* 終了   : 2026-06-25 18:15:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host09-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→12→15→12→15→12
* 開始   : 2026-06-26 04:50:00 (UTC)
* 終了   : 2026-06-26 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260626-host09-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 13→12→15→16→…→15→16→15→14
* 開始   : 2026-06-26 05:05:00 (UTC)
* 終了   : 2026-06-26 05:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 18→15→19→17→…→17→20→16→17
* 開始   : 2026-06-26 07:15:00 (UTC)
* 終了   : 2026-06-26 07:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 19→21→22→20→21→22→20
* 開始   : 2026-06-26 08:50:00 (UTC)
* 終了   : 2026-06-26 08:55:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host09-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 20→23→20→23→20→23→21→22
* 開始   : 2026-06-26 09:05:00 (UTC)
* 終了   : 2026-06-26 09:15:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.216倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.84σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→17→21→20→23→17→21
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 21→20→25→18→20→25→18→20
* 開始   : 2026-06-26 14:30:00 (UTC)
* 終了   : 2026-06-26 14:35:00 (UTC)
* 現象   : 平常時(21)に対し 1.19倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.804σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→15→17→13→15→17
* 開始   : 2026-06-26 17:45:00 (UTC)
* 終了   : 2026-06-26 17:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 13→9→11→9→11→9→11→12
* 開始   : 2026-06-26 20:05:00 (UTC)
* 終了   : 2026-06-26 20:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host09-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→12→6→8→12→6→8→10
* 開始   : 2026-06-27 22:35:00 (UTC)
* 終了   : 2026-06-27 22:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260627-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→14→17→14→17→14→13
* 開始   : 2026-06-28 09:10:00 (UTC)
* 終了   : 2026-06-28 09:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host09-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host09-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_1
* 値     : 15→12→18→17→15→12→18→17→15
* 開始   : 2026-06-28 11:10:00 (UTC)
* 終了   : 2026-06-28 11:15:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host09-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host09-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 8→10→5→9→5→9→5→9→7
* 開始   : 2026-06-29 23:35:00 (UTC)
* 終了   : 2026-06-29 23:45:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260629-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260629-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260629-host09-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 9→11→15→10→…→10→14→11→12
* 開始   : 2026-06-30 03:55:00 (UTC)
* 終了   : 2026-06-30 04:05:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.385倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.897σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 14→15→15→16→16
* 開始   : 2026-06-30 05:05:00 (UTC)
* 終了   : 2026-06-30 05:25:00 (UTC)
* 現象   : 2026-06-30 05:25:00 (UTC)を境に水準が 15.02から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host09-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_3
* 値     : 17→21→19→17→21→19→20
* 開始   : 2026-06-30 08:10:00 (UTC)
* 終了   : 2026-06-30 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 20→19→17→20→17→20→17→19
* 開始   : 2026-06-30 15:05:00 (UTC)
* 終了   : 2026-06-30 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8031(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.903σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260630-host09-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_2
* 値     : 17→19→16→18→16→18→16→17→16
* 開始   : 2026-06-30 16:25:00 (UTC)
* 終了   : 2026-06-30 16:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→14→…→15→14→17→16
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260630-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host09-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→12→11→9→12→11
* 開始   : 2026-06-30 20:15:00 (UTC)
* 終了   : 2026-06-30 20:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host09-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host09-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host09, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→11→10→7→11→8
* 開始   : 2026-06-30 21:25:00 (UTC)
* 終了   : 2026-06-30 21:30:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host09-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
