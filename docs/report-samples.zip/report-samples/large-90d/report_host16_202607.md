# host16 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host16 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 313 (SEVERE: 22, FATAL: 115, WARN: 176, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 115 | 176 | 313 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→14→…→14→13→14→13
* 開始   : 2026-07-06 02:00:00 (UTC)
* 終了   : 2026-07-06 22:00:00 (UTC)
* 現象   : 2026-07-06 22:00:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.786, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.819, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-002 active_connections の推移](charts/EVT-20260706-host16-002.svg)

# イベントID( EVT-20260706-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→17→…→13→15→13→11
* 開始   : 2026-07-06 02:15:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 11.79から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.929, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.771, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-003 active_connections の推移](charts/EVT-20260706-host16-003.svg)

# イベントID( EVT-20260706-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→15→16→14→…→12→13→12→13
* 開始   : 2026-07-06 02:25:00 (UTC)
* 終了   : 2026-07-06 21:20:00 (UTC)
* 現象   : 2026-07-06 21:20:00 (UTC)を境に水準が 11.85から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.737, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.692, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-004 active_connections の推移](charts/EVT-20260706-host16-004.svg)

# イベントID( EVT-20260706-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→17→…→17→16→15→16
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.79から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.697, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-005 active_connections の推移](charts/EVT-20260706-host16-005.svg)

# イベントID( EVT-20260706-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→16→19→15→…→15→16→13→14
* 開始   : 2026-07-06 03:15:00 (UTC)
* 終了   : 2026-07-06 20:10:00 (UTC)
* 現象   : 2026-07-06 20:10:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.458, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-006 active_connections の推移](charts/EVT-20260706-host16-006.svg)

# イベントID( EVT-20260706-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→13→14→15→…→17→15→14→13
* 開始   : 2026-07-06 03:35:00 (UTC)
* 終了   : 2026-07-06 21:45:00 (UTC)
* 現象   : 2026-07-06 21:45:00 (UTC)を境に水準が 11.79から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.892, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-007 active_connections の推移](charts/EVT-20260706-host16-007.svg)

# イベントID( EVT-20260713-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→14→13→14→13
* 開始   : 2026-07-13 01:40:00 (UTC)
* 終了   : 2026-07-13 20:30:00 (UTC)
* 現象   : 2026-07-13 20:30:00 (UTC)を境に水準が 11.8から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.887, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-001 active_connections の推移](charts/EVT-20260713-host16-001.svg)

# イベントID( EVT-20260713-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→17→…→14→13→10→15
* 開始   : 2026-07-13 02:10:00 (UTC)
* 終了   : 2026-07-13 22:25:00 (UTC)
* 現象   : 2026-07-13 22:25:00 (UTC)を境に水準が 11.79から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.692, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.892, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-003 active_connections の推移](charts/EVT-20260713-host16-003.svg)

# イベントID( EVT-20260713-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→13→14→16→…→14→13→11→9
* 開始   : 2026-07-13 02:35:00 (UTC)
* 終了   : 2026-07-13 20:35:00 (UTC)
* 現象   : 2026-07-13 20:35:00 (UTC)を境に水準が 11.8から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.992σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.729, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-004 active_connections の推移](charts/EVT-20260713-host16-004.svg)

# イベントID( EVT-20260713-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→16→…→14→13→15→13
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 20:00:00 (UTC)
* 現象   : 2026-07-13 20:00:00 (UTC)を境に水準が 11.76から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.697, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-006 active_connections の推移](charts/EVT-20260713-host16-006.svg)

# イベントID( EVT-20260720-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→14→…→13→15→12→13
* 開始   : 2026-07-20 02:10:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.8から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.344, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-002 active_connections の推移](charts/EVT-20260720-host16-002.svg)

# イベントID( EVT-20260720-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→15→…→13→15→13→14
* 開始   : 2026-07-20 02:35:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.861, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-003 active_connections の推移](charts/EVT-20260720-host16-003.svg)

# イベントID( EVT-20260720-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→13→10→13→11
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 21:30:00 (UTC)
* 現象   : 2026-07-20 21:30:00 (UTC)を境に水準が 11.86から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.939, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-004 active_connections の推移](charts/EVT-20260720-host16-004.svg)

# イベントID( EVT-20260720-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→15→16→15→…→13→15→12→13
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 20:05:00 (UTC)
* 現象   : 2026-07-20 20:05:00 (UTC)を境に水準が 11.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-005 active_connections の推移](charts/EVT-20260720-host16-005.svg)

# イベントID( EVT-20260720-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→16→15→16→…→14→13→14→13
* 開始   : 2026-07-20 02:55:00 (UTC)
* 終了   : 2026-07-20 20:20:00 (UTC)
* 現象   : 2026-07-20 20:20:00 (UTC)を境に水準が 11.82から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.663, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.989, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-006 active_connections の推移](charts/EVT-20260720-host16-006.svg)

# イベントID( EVT-20260720-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→19→…→12→13→14→12
* 開始   : 2026-07-20 03:15:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.98から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-007 active_connections の推移](charts/EVT-20260720-host16-007.svg)

# イベントID( EVT-20260727-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→14→…→16→13→11→14
* 開始   : 2026-07-27 02:20:00 (UTC)
* 終了   : 2026-07-27 20:10:00 (UTC)
* 現象   : 2026-07-27 20:10:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.733, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-001 active_connections の推移](charts/EVT-20260727-host16-001.svg)

# イベントID( EVT-20260727-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→13→14→13→14
* 開始   : 2026-07-27 02:25:00 (UTC)
* 終了   : 2026-07-27 20:05:00 (UTC)
* 現象   : 2026-07-27 20:05:00 (UTC)を境に水準が 11.75から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.068, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.934, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-002 active_connections の推移](charts/EVT-20260727-host16-002.svg)

# イベントID( EVT-20260727-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→14→15→14→…→15→14→13→12
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 21:25:00 (UTC)
* 現象   : 2026-07-27 21:25:00 (UTC)を境に水準が 11.92から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-003 active_connections の推移](charts/EVT-20260727-host16-003.svg)

# イベントID( EVT-20260727-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→16→…→16→15→13→15
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 21:15:00 (UTC)
* 現象   : 2026-07-27 21:15:00 (UTC)を境に水準が 11.8から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.022, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-004 active_connections の推移](charts/EVT-20260727-host16-004.svg)

# イベントID( EVT-20260727-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→15→11→14→…→13→16→13→15
* 開始   : 2026-07-27 03:35:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.79から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.811, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-005 active_connections の推移](charts/EVT-20260727-host16-005.svg)

# イベントID( EVT-20260727-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→15→17→16→…→15→14→13→15
* 開始   : 2026-07-27 03:35:00 (UTC)
* 終了   : 2026-07-27 21:45:00 (UTC)
* 現象   : 2026-07-27 21:45:00 (UTC)を境に水準が 11.84から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.933, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host16-006 active_connections の推移](charts/EVT-20260727-host16-006.svg)

# イベントID( EVT-20260701-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→12→13
* 開始   : 2026-07-01 04:40:00 (UTC)
* 終了   : 2026-07-01 04:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→15→20→19→…→20→14→19→17
* 開始   : 2026-07-01 06:55:00 (UTC)
* 終了   : 2026-07-01 07:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260701-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260701-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→21→16→17→…→16→17→19→20
* 開始   : 2026-07-01 15:05:00 (UTC)
* 終了   : 2026-07-01 15:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→19→15→21→18
* 開始   : 2026-07-01 15:55:00 (UTC)
* 終了   : 2026-07-01 15:55:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→16→16
* 開始   : 2026-07-01 17:25:00 (UTC)
* 終了   : 2026-07-01 17:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→14→12→14→12→15
* 開始   : 2026-07-01 18:45:00 (UTC)
* 終了   : 2026-07-01 19:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260701-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260701-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260701-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260701-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host16-013 active_connections の推移](charts/EVT-20260701-host16-013.svg)

# イベントID( EVT-20260702-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→17→14→17→18
* 開始   : 2026-07-02 16:00:00 (UTC)
* 終了   : 2026-07-02 16:00:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.7273(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host16-008 active_connections の推移](charts/EVT-20260702-host16-008.svg)

# イベントID( EVT-20260702-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→13→13
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 18:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→12→12
* 開始   : 2026-07-03 05:00:00 (UTC)
* 終了   : 2026-07-03 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→16→15
* 開始   : 2026-07-03 05:45:00 (UTC)
* 終了   : 2026-07-03 05:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.416倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.93σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260703-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host16-003 active_connections の推移](charts/EVT-20260703-host16-003.svg)

# イベントID( EVT-20260703-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→20→25→20→22
* 開始   : 2026-07-03 10:10:00 (UTC)
* 終了   : 2026-07-03 10:10:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→22→18→20→20
* 開始   : 2026-07-03 13:35:00 (UTC)
* 終了   : 2026-07-03 13:35:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→16→12→16→12→16→12→15→16
* 開始   : 2026-07-03 17:40:00 (UTC)
* 終了   : 2026-07-03 17:50:00 (UTC)
* 現象   : 金曜17時台の平常値(15.98)に対し 12であった
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.046σ 外れた (平常値=15.98)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260703-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→10→5→7→9
* 開始   : 2026-07-03 22:35:00 (UTC)
* 終了   : 2026-07-03 22:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→9→14→9→11
* 開始   : 2026-07-04 04:25:00 (UTC)
* 終了   : 2026-07-04 04:25:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260704-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260704-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→12→14→12→…→13→11→13→11
* 開始   : 2026-07-04 04:50:00 (UTC)
* 終了   : 2026-07-04 19:05:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.783, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260704-host16-002 active_connections の推移](charts/EVT-20260704-host16-002.svg)

# イベントID( EVT-20260704-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→12→…→10→14→12→13
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.8, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host16-003 active_connections の推移](charts/EVT-20260704-host16-003.svg)

# イベントID( EVT-20260704-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→9→12→11→…→12→11→12→14
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host16-004 active_connections の推移](charts/EVT-20260704-host16-004.svg)

# イベントID( EVT-20260704-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→12→…→14→12→14→13
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 20:15:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.821, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260704-host16-005 active_connections の推移](charts/EVT-20260704-host16-005.svg)

# イベントID( EVT-20260704-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→11→…→11→13→10→11
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host16-006 active_connections の推移](charts/EVT-20260704-host16-006.svg)

# イベントID( EVT-20260704-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→11→…→10→11→10→11
* 開始   : 2026-07-04 06:05:00 (UTC)
* 終了   : 2026-07-04 19:05:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.31, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間

![EVT-20260704-host16-007 active_connections の推移](charts/EVT-20260704-host16-007.svg)

# イベントID( EVT-20260704-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→8→8
* 開始   : 2026-07-04 21:45:00 (UTC)
* 終了   : 2026-07-04 21:45:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→9→13→9→9
* 開始   : 2026-07-05 00:40:00 (UTC)
* 終了   : 2026-07-05 00:40:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.66倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→13→15→10→…→11→13→15→11
* 開始   : 2026-07-05 05:10:00 (UTC)
* 終了   : 2026-07-05 05:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→13→8→11→10
* 開始   : 2026-07-05 18:10:00 (UTC)
* 終了   : 2026-07-05 18:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→13→13
* 開始   : 2026-07-05 19:15:00 (UTC)
* 終了   : 2026-07-05 20:10:00 (UTC)
* 現象   : 2026-07-05 20:10:00 (UTC)を境に水準が 11.72から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.297, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→11→14→11→10
* 開始   : 2026-07-07 02:50:00 (UTC)
* 終了   : 2026-07-07 02:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→12→18→15→15
* 開始   : 2026-07-07 06:05:00 (UTC)
* 終了   : 2026-07-07 06:05:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→14→…→14→19→16→17
* 開始   : 2026-07-07 06:20:00 (UTC)
* 終了   : 2026-07-07 06:30:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host16-003 active_connections の推移](charts/EVT-20260707-host16-003.svg)

# イベントID( EVT-20260707-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→21→16→17
* 開始   : 2026-07-07 07:10:00 (UTC)
* 終了   : 2026-07-07 07:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→19→15→16→17
* 開始   : 2026-07-07 16:20:00 (UTC)
* 終了   : 2026-07-07 16:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→17→14→17→16
* 開始   : 2026-07-07 16:40:00 (UTC)
* 終了   : 2026-07-07 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host16-009 active_connections の推移](charts/EVT-20260707-host16-009.svg)

# イベントID( EVT-20260707-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→6→9→10
* 開始   : 2026-07-07 21:35:00 (UTC)
* 終了   : 2026-07-07 21:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→8→4→8→8
* 開始   : 2026-07-07 22:35:00 (UTC)
* 終了   : 2026-07-07 22:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-069 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260707-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→14→17→13→12
* 開始   : 2026-07-08 05:15:00 (UTC)
* 終了   : 2026-07-08 05:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→16→20→14→17
* 開始   : 2026-07-08 06:40:00 (UTC)
* 終了   : 2026-07-08 06:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→16→15→16→18→16→15→16→17
* 開始   : 2026-07-08 16:40:00 (UTC)
* 終了   : 2026-07-08 17:05:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→16→12→15→15
* 開始   : 2026-07-08 17:55:00 (UTC)
* 終了   : 2026-07-08 17:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→19→19→20→18→21→21→21→23
* 開始   : 2026-07-09 06:35:00 (UTC)
* 終了   : 2026-07-09 09:50:00 (UTC)
* 現象   : 2026-07-09 09:50:00 (UTC)を境に水準が 14.88から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→15→19→17→19→17→19→16→17
* 開始   : 2026-07-09 06:50:00 (UTC)
* 終了   : 2026-07-09 07:00:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260709-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→20→21→18→17→20→21→18
* 開始   : 2026-07-09 07:15:00 (UTC)
* 終了   : 2026-07-09 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.263倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260709-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→18→23→18→20
* 開始   : 2026-07-09 08:45:00 (UTC)
* 終了   : 2026-07-09 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→19→13→15→15
* 開始   : 2026-07-09 17:10:00 (UTC)
* 終了   : 2026-07-09 17:10:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→9→5→9→10
* 開始   : 2026-07-09 22:25:00 (UTC)
* 終了   : 2026-07-09 22:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→15→9→15→14
* 開始   : 2026-07-10 18:40:00 (UTC)
* 終了   : 2026-07-10 18:40:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.6316(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host16-005 active_connections の推移](charts/EVT-20260710-host16-005.svg)

# イベントID( EVT-20260711-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→13→…→9→12→13→12
* 開始   : 2026-07-11 04:55:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host16-001 active_connections の推移](charts/EVT-20260711-host16-001.svg)

# イベントID( EVT-20260711-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→8→11→10→…→13→12→10→13
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.317, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host16-002 active_connections の推移](charts/EVT-20260711-host16-002.svg)

# イベントID( EVT-20260711-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→11→…→11→12→11→10
* 開始   : 2026-07-11 05:20:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host16-003 active_connections の推移](charts/EVT-20260711-host16-003.svg)

# イベントID( EVT-20260711-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→14→…→13→11→15→12
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 17:50:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.157, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260711-host16-004 active_connections の推移](charts/EVT-20260711-host16-004.svg)

# イベントID( EVT-20260711-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→11→12→13→…→12→9→10→12
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.524, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host16-005 active_connections の推移](charts/EVT-20260711-host16-005.svg)

# イベントID( EVT-20260711-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→12→13→14→…→14→10→9→12
* 開始   : 2026-07-11 05:35:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260711-host16-006 active_connections の推移](charts/EVT-20260711-host16-006.svg)

# イベントID( EVT-20260712-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→10→15→12→12
* 開始   : 2026-07-12 05:00:00 (UTC)
* 終了   : 2026-07-12 05:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260712-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host16-003 active_connections の推移](charts/EVT-20260712-host16-003.svg)

# イベントID( EVT-20260712-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→17→12→14→12→14→12→17
* 開始   : 2026-07-12 14:15:00 (UTC)
* 終了   : 2026-07-12 15:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260712-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260712-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→7→12→14→7→12→14→13→9
* 開始   : 2026-07-12 18:40:00 (UTC)
* 終了   : 2026-07-12 18:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260712-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260712-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→10→6→8→8
* 開始   : 2026-07-12 20:10:00 (UTC)
* 終了   : 2026-07-12 20:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→8→7→10→10→9
* 開始   : 2026-07-12 23:35:00 (UTC)
* 終了   : 2026-07-13 00:35:00 (UTC)
* 現象   : 2026-07-13 00:35:00 (UTC)を境に水準が 11.77から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→15→16→17→…→14→13→12→13
* 開始   : 2026-07-13 02:05:00 (UTC)
* 終了   : 2026-07-13 19:20:00 (UTC)
* 現象   : 2026-07-13 19:20:00 (UTC)を境に水準が 11.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.951, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→13→14→16→…→15→13→15→13
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 20:20:00 (UTC)
* 現象   : 2026-07-13 20:20:00 (UTC)を境に水準が 11.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.89, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 7→8→5→4→…→5→4→6→8
* 開始   : 2026-07-13 23:50:00 (UTC)
* 終了   : 2026-07-13 23:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.566(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260713-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→15→14
* 開始   : 2026-07-14 06:10:00 (UTC)
* 終了   : 2026-07-14 06:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host16-002 active_connections の推移](charts/EVT-20260714-host16-002.svg)

# イベントID( EVT-20260714-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→13→14
* 開始   : 2026-07-14 18:55:00 (UTC)
* 終了   : 2026-07-14 18:55:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260714-host16-007 active_connections の推移](charts/EVT-20260714-host16-007.svg)

# イベントID( EVT-20260714-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→14→8→10→12
* 開始   : 2026-07-14 20:05:00 (UTC)
* 終了   : 2026-07-14 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→18→23→19→19
* 開始   : 2026-07-15 08:25:00 (UTC)
* 終了   : 2026-07-15 08:25:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→11→9→11→11
* 開始   : 2026-07-15 19:45:00 (UTC)
* 終了   : 2026-07-15 19:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→21→24→20→20
* 開始   : 2026-07-16 09:20:00 (UTC)
* 終了   : 2026-07-16 09:20:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260716-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→7→13→8→8
* 開始   : 2026-07-17 01:25:00 (UTC)
* 終了   : 2026-07-17 01:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host16-002 active_connections の推移](charts/EVT-20260717-host16-002.svg)

# イベントID( EVT-20260717-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→23→26→21→23
* 開始   : 2026-07-17 12:15:00 (UTC)
* 終了   : 2026-07-17 12:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→15→10→14→14
* 開始   : 2026-07-17 18:25:00 (UTC)
* 終了   : 2026-07-17 18:25:00 (UTC)
* 現象   : 平常時(16)に対し 0.625(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host16-008 active_connections の推移](charts/EVT-20260717-host16-008.svg)

# イベントID( EVT-20260718-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→13→…→11→10→14→9
* 開始   : 2026-07-18 04:45:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.048, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260718-host16-002 active_connections の推移](charts/EVT-20260718-host16-002.svg)

# イベントID( EVT-20260718-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→12→…→13→9→14→12
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 19:45:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.079, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260718-host16-003 active_connections の推移](charts/EVT-20260718-host16-003.svg)

# イベントID( EVT-20260718-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→13→…→9→10→13→11
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260718-host16-004 active_connections の推移](charts/EVT-20260718-host16-004.svg)

# イベントID( EVT-20260718-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→12→…→12→10→14→11
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 18:35:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.854, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260718-host16-005 active_connections の推移](charts/EVT-20260718-host16-005.svg)

# イベントID( EVT-20260718-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→12→…→12→13→14→12
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.032, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260718-host16-006 active_connections の推移](charts/EVT-20260718-host16-006.svg)

# イベントID( EVT-20260718-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→11→12→11→…→11→14→13→11
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 18:20:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.262, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260718-host16-007 active_connections の推移](charts/EVT-20260718-host16-007.svg)

# イベントID( EVT-20260719-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→12→16→12→13
* 開始   : 2026-07-19 06:15:00 (UTC)
* 終了   : 2026-07-19 06:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→14
* 開始   : 2026-07-19 09:10:00 (UTC)
* 終了   : 2026-07-19 09:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→11→13→14
* 開始   : 2026-07-19 14:00:00 (UTC)
* 終了   : 2026-07-19 14:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→15→13→12
* 開始   : 2026-07-21 04:05:00 (UTC)
* 終了   : 2026-07-21 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→23→16→23→22
* 開始   : 2026-07-21 14:30:00 (UTC)
* 終了   : 2026-07-21 14:30:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→17→15→18→17→15→18→17
* 開始   : 2026-07-21 16:20:00 (UTC)
* 終了   : 2026-07-21 16:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→13→7→11→10
* 開始   : 2026-07-21 20:25:00 (UTC)
* 終了   : 2026-07-21 20:25:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260721-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→16→21→17→18
* 開始   : 2026-07-22 07:10:00 (UTC)
* 終了   : 2026-07-22 08:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.326倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 30 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260722-host16-003 active_connections の推移](charts/EVT-20260722-host16-003.svg)

# イベントID( EVT-20260722-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→20→23→20→20
* 開始   : 2026-07-22 08:50:00 (UTC)
* 終了   : 2026-07-22 08:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→18→15→17→…→17→14→17→16
* 開始   : 2026-07-22 17:05:00 (UTC)
* 終了   : 2026-07-22 18:20:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260722-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host16-006 active_connections の推移](charts/EVT-20260722-host16-006.svg)

# イベントID( EVT-20260722-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→11→14→14
* 開始   : 2026-07-22 18:25:00 (UTC)
* 終了   : 2026-07-22 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→12→12→14→12→14
* 開始   : 2026-07-22 19:30:00 (UTC)
* 終了   : 2026-07-22 20:00:00 (UTC)
* 現象   : 2026-07-22 20:00:00 (UTC)を境に水準が 15.04から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.446, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→11→14→12→8
* 開始   : 2026-07-23 03:05:00 (UTC)
* 終了   : 2026-07-23 03:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260723-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→13→17→12→12
* 開始   : 2026-07-23 05:05:00 (UTC)
* 終了   : 2026-07-23 05:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.704σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host16-005 active_connections の推移](charts/EVT-20260723-host16-005.svg)

# イベントID( EVT-20260724-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→19→20→19→…→19→21→17→20
* 開始   : 2026-07-24 07:40:00 (UTC)
* 終了   : 2026-07-24 08:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 21→20→17→19→20
* 開始   : 2026-07-24 13:55:00 (UTC)
* 終了   : 2026-07-24 13:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260724-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→16→12→16→16
* 開始   : 2026-07-24 17:35:00 (UTC)
* 終了   : 2026-07-24 17:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→16→12→16→14
* 開始   : 2026-07-24 17:55:00 (UTC)
* 終了   : 2026-07-24 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→14→9→13→12
* 開始   : 2026-07-24 19:20:00 (UTC)
* 終了   : 2026-07-24 19:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260724-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→12→10→13→…→12→10→11→13
* 開始   : 2026-07-25 05:05:00 (UTC)
* 終了   : 2026-07-25 18:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.982, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host16-003 active_connections の推移](charts/EVT-20260725-host16-003.svg)

# イベントID( EVT-20260725-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→11→…→11→10→13→12
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.498, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260725-host16-004 active_connections の推移](charts/EVT-20260725-host16-004.svg)

# イベントID( EVT-20260725-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→10→9→10→…→12→14→13→12
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 18:00:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260725-host16-005 active_connections の推移](charts/EVT-20260725-host16-005.svg)

# イベントID( EVT-20260725-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→14→13→12→…→11→12→13→10
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.791, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host16-006 active_connections の推移](charts/EVT-20260725-host16-006.svg)

# イベントID( EVT-20260725-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→9→…→12→11→14→10
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:55:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.731, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260725-host16-007 active_connections の推移](charts/EVT-20260725-host16-007.svg)

# イベントID( EVT-20260725-host16-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→14→…→12→11→12→11
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.074, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host16-008 active_connections の推移](charts/EVT-20260725-host16-008.svg)

# イベントID( EVT-20260726-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→13→14→15→13→14→12→18
* 開始   : 2026-07-26 06:20:00 (UTC)
* 終了   : 2026-07-26 08:00:00 (UTC)
* 現象   : 2026-07-26 08:00:00 (UTC)を境に水準が 11.79から12.38へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→15→19
* 開始   : 2026-07-26 08:45:00 (UTC)
* 終了   : 2026-07-26 09:10:00 (UTC)
* 現象   : 2026-07-26 09:10:00 (UTC)を境に水準が 11.94から12.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→10→6→9→10
* 開始   : 2026-07-26 20:15:00 (UTC)
* 終了   : 2026-07-26 20:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→8→5→10→7
* 開始   : 2026-07-26 21:35:00 (UTC)
* 終了   : 2026-07-26 22:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260726-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260726-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 7→9→13→7→8
* 開始   : 2026-07-27 23:45:00 (UTC)
* 終了   : 2026-07-27 23:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→22→22→23→22→21→20→22→22
* 開始   : 2026-07-28 13:25:00 (UTC)
* 終了   : 2026-07-28 14:10:00 (UTC)
* 現象   : 2026-07-28 14:10:00 (UTC)を境に水準が 14.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→19→14→16→17
* 開始   : 2026-07-28 16:35:00 (UTC)
* 終了   : 2026-07-28 16:35:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→16→11→16→14
* 開始   : 2026-07-29 18:10:00 (UTC)
* 終了   : 2026-07-29 18:10:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host16-010 active_connections の推移](charts/EVT-20260729-host16-010.svg)

# イベントID( EVT-20260729-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→8→10
* 開始   : 2026-07-29 21:50:00 (UTC)
* 終了   : 2026-07-29 21:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→16→14
* 開始   : 2026-07-30 06:10:00 (UTC)
* 終了   : 2026-07-30 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→19→19
* 開始   : 2026-07-30 09:10:00 (UTC)
* 終了   : 2026-07-30 09:10:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host16-003 active_connections の推移](charts/EVT-20260730-host16-003.svg)

# イベントID( EVT-20260730-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→14→9→11→11
* 開始   : 2026-07-30 19:35:00 (UTC)
* 終了   : 2026-07-30 20:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260730-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→21→20→20→20
* 開始   : 2026-07-31 15:30:00 (UTC)
* 終了   : 2026-07-31 16:45:00 (UTC)
* 現象   : 2026-07-31 16:45:00 (UTC)を境に水準が 15.05から12.63へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→18→12→16→16
* 開始   : 2026-07-31 17:20:00 (UTC)
* 終了   : 2026-07-31 17:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.689(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.785σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host16-005 active_connections の推移](charts/EVT-20260731-host16-005.svg)

# イベントID( EVT-20260731-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→10→14→11→10→14→11→12→14
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 18:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.6557(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host16-006 active_connections の推移](charts/EVT-20260731-host16-006.svg)

# イベントID( EVT-20260731-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→14→13
* 開始   : 2026-07-31 18:40:00 (UTC)
* 終了   : 2026-07-31 18:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→18→15→17→18→15
* 開始   : 2026-07-01 06:00:00 (UTC)
* 終了   : 2026-07-01 06:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→16→18→16→18→16
* 開始   : 2026-07-01 06:00:00 (UTC)
* 終了   : 2026-07-01 06:05:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→19→18→19→18→19→17
* 開始   : 2026-07-01 06:50:00 (UTC)
* 終了   : 2026-07-01 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.816σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→19→17→19→20→20→20
* 開始   : 2026-07-01 07:35:00 (UTC)
* 終了   : 2026-07-01 08:05:00 (UTC)
* 現象   : 2026-07-01 08:05:00 (UTC)を境に水準が 14.93から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.377, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→18→…→18→22→18→21
* 開始   : 2026-07-01 08:15:00 (UTC)
* 終了   : 2026-07-01 08:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→18
* 開始   : 2026-07-01 16:30:00 (UTC)
* 終了   : 2026-07-01 16:35:00 (UTC)
* 現象   : 2026-07-01 16:35:00 (UTC)を境に水準が 15.03から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.622, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→16→…→16→12→15→12
* 開始   : 2026-07-01 18:05:00 (UTC)
* 終了   : 2026-07-01 18:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260701-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host02-013 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260701-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→10→14→11→14→11→14→11
* 開始   : 2026-07-02 04:10:00 (UTC)
* 終了   : 2026-07-02 04:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→16→…→16→17→15→12
* 開始   : 2026-07-02 05:10:00 (UTC)
* 終了   : 2026-07-02 05:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260702-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→18→16→18→16
* 開始   : 2026-07-02 06:45:00 (UTC)
* 終了   : 2026-07-02 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→18→18→18→16→19→18→18
* 開始   : 2026-07-02 06:55:00 (UTC)
* 終了   : 2026-07-02 07:30:00 (UTC)
* 現象   : 2026-07-02 07:30:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→19→19→20→19→19→19→19→21
* 開始   : 2026-07-02 07:05:00 (UTC)
* 終了   : 2026-07-02 08:15:00 (UTC)
* 現象   : 2026-07-02 08:15:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.707, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→18→17→20→20→21→19→19→20
* 開始   : 2026-07-02 07:50:00 (UTC)
* 終了   : 2026-07-02 08:45:00 (UTC)
* 現象   : 2026-07-02 08:45:00 (UTC)を境に水準が 14.94から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 23→23→25→23→22→23→23
* 開始   : 2026-07-02 12:05:00 (UTC)
* 終了   : 2026-07-02 12:35:00 (UTC)
* 現象   : 2026-07-02 12:35:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→17→14→13→14→13→16
* 開始   : 2026-07-02 17:40:00 (UTC)
* 終了   : 2026-07-02 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→9→10→12→9→10→12
* 開始   : 2026-07-02 19:40:00 (UTC)
* 終了   : 2026-07-02 19:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-019 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→9→11→9→13
* 開始   : 2026-07-02 21:55:00 (UTC)
* 終了   : 2026-07-02 22:15:00 (UTC)
* 現象   : 2026-07-02 22:15:00 (UTC)を境に水準が 15.04から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→13→15→13→15→13→11
* 開始   : 2026-07-03 04:40:00 (UTC)
* 終了   : 2026-07-03 04:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→18→18→19
* 開始   : 2026-07-03 06:35:00 (UTC)
* 終了   : 2026-07-03 06:50:00 (UTC)
* 現象   : 2026-07-03 06:50:00 (UTC)を境に水準が 14.93から14.63へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→19→…→22→23→20→19
* 開始   : 2026-07-03 09:05:00 (UTC)
* 終了   : 2026-07-03 09:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 24→23→23→25
* 開始   : 2026-07-03 12:10:00 (UTC)
* 終了   : 2026-07-03 12:25:00 (UTC)
* 現象   : 2026-07-03 12:25:00 (UTC)を境に水準が 14.99から13.37へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→19→17→19→17→19→17
* 開始   : 2026-07-03 15:35:00 (UTC)
* 終了   : 2026-07-03 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260703-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→10→12→13→13→11→13
* 開始   : 2026-07-03 18:50:00 (UTC)
* 終了   : 2026-07-03 20:00:00 (UTC)
* 現象   : 2026-07-03 20:00:00 (UTC)を境に水準が 14.9から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.951, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→9→10→9→8→8→9→10→10
* 開始   : 2026-07-04 23:45:00 (UTC)
* 終了   : 2026-07-05 00:25:00 (UTC)
* 現象   : 2026-07-05 00:25:00 (UTC)を境に水準が 11.85から11.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260704-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→11→7→10→11→12
* 開始   : 2026-07-05 01:55:00 (UTC)
* 終了   : 2026-07-05 02:20:00 (UTC)
* 現象   : 2026-07-05 02:20:00 (UTC)を境に水準が 11.78から11.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→8→14→7→…→14→7→12→10
* 開始   : 2026-07-05 04:45:00 (UTC)
* 終了   : 2026-07-05 04:50:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.436倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.97σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→12→15→16→12→15→13
* 開始   : 2026-07-05 14:30:00 (UTC)
* 終了   : 2026-07-05 14:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→9→8→9→10→10→11
* 開始   : 2026-07-06 01:05:00 (UTC)
* 終了   : 2026-07-06 01:55:00 (UTC)
* 現象   : 2026-07-06 01:55:00 (UTC)を境に水準が 11.78から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→20→18→20→19→20→18→21→20
* 開始   : 2026-07-07 07:30:00 (UTC)
* 終了   : 2026-07-07 08:10:00 (UTC)
* 現象   : 2026-07-07 08:10:00 (UTC)を境に水準が 14.94から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→20→24→25→…→24→25→24→22
* 開始   : 2026-07-07 11:35:00 (UTC)
* 終了   : 2026-07-07 11:40:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→20→16→19→16→19→16
* 開始   : 2026-07-07 16:30:00 (UTC)
* 終了   : 2026-07-07 16:40:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→16→12→11→…→12→11→17→14
* 開始   : 2026-07-07 18:15:00 (UTC)
* 終了   : 2026-07-07 18:20:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→13→12→14→13→12→14→13
* 開始   : 2026-07-07 18:30:00 (UTC)
* 終了   : 2026-07-07 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→12→13→11→12→13
* 開始   : 2026-07-07 19:05:00 (UTC)
* 終了   : 2026-07-07 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260707-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 6→8→11→5→…→11→5→9→8
* 開始   : 2026-07-08 01:10:00 (UTC)
* 終了   : 2026-07-08 01:15:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→14→…→8→14→13→11
* 開始   : 2026-07-08 04:05:00 (UTC)
* 終了   : 2026-07-08 04:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→14→16→16→15→14→16→16→18
* 開始   : 2026-07-08 05:10:00 (UTC)
* 終了   : 2026-07-08 06:00:00 (UTC)
* 現象   : 2026-07-08 06:00:00 (UTC)を境に水準が 15.01から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→14→13→16→18→14→15→17→19
* 開始   : 2026-07-08 05:45:00 (UTC)
* 終了   : 2026-07-08 06:25:00 (UTC)
* 現象   : 2026-07-08 06:25:00 (UTC)を境に水準が 15.03から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→20→19→21→20→18→22→20→23
* 開始   : 2026-07-08 08:00:00 (UTC)
* 終了   : 2026-07-08 08:40:00 (UTC)
* 現象   : 2026-07-08 08:40:00 (UTC)を境に水準が 14.94から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→19→22→18→19→22→18→20
* 開始   : 2026-07-08 08:40:00 (UTC)
* 終了   : 2026-07-08 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→22→22→22→21→23
* 開始   : 2026-07-08 13:50:00 (UTC)
* 終了   : 2026-07-08 15:00:00 (UTC)
* 現象   : 2026-07-08 15:00:00 (UTC)を境に水準が 14.87から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→12→14→11→12→14→11→15→16
* 開始   : 2026-07-08 18:30:00 (UTC)
* 終了   : 2026-07-08 18:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→12→8→10→8→10→8→9→12
* 開始   : 2026-07-08 20:35:00 (UTC)
* 終了   : 2026-07-08 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→9→7→8→9→7→10
* 開始   : 2026-07-08 20:50:00 (UTC)
* 終了   : 2026-07-08 21:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host14-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260708-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→13→10→16→13→10→15
* 開始   : 2026-07-09 04:55:00 (UTC)
* 終了   : 2026-07-09 05:05:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→17→15→17→13→17
* 開始   : 2026-07-09 05:45:00 (UTC)
* 終了   : 2026-07-09 05:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260709-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→19→18→20→19→17→20→20→20
* 開始   : 2026-07-09 06:10:00 (UTC)
* 終了   : 2026-07-09 07:55:00 (UTC)
* 現象   : 2026-07-09 07:55:00 (UTC)を境に水準が 15.1から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→18→20→21→…→20→21→19→17
* 開始   : 2026-07-09 07:50:00 (UTC)
* 終了   : 2026-07-09 07:55:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→20→23→19→20→23→19→21
* 開始   : 2026-07-09 09:15:00 (UTC)
* 終了   : 2026-07-09 09:20:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→22→21→23→22→25→23→22→23
* 開始   : 2026-07-09 12:50:00 (UTC)
* 終了   : 2026-07-09 13:35:00 (UTC)
* 現象   : 2026-07-09 13:35:00 (UTC)を境に水準が 14.95から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→13→17→16→14→13→17
* 開始   : 2026-07-09 17:30:00 (UTC)
* 終了   : 2026-07-09 17:35:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→12→15→16→12→15→16
* 開始   : 2026-07-09 18:25:00 (UTC)
* 終了   : 2026-07-09 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260709-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→13→8→11→8→11→8→10
* 開始   : 2026-07-09 20:45:00 (UTC)
* 終了   : 2026-07-09 20:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host16-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→11→10→9→11→10→10→11→10
* 開始   : 2026-07-09 20:50:00 (UTC)
* 終了   : 2026-07-09 22:00:00 (UTC)
* 現象   : 2026-07-09 22:00:00 (UTC)を境に水準が 14.87から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.667, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→18→20→19→21→20→19→21→19
* 開始   : 2026-07-10 07:50:00 (UTC)
* 終了   : 2026-07-10 08:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260710-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→20→18→22→20
* 開始   : 2026-07-10 08:50:00 (UTC)
* 終了   : 2026-07-10 08:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→24→18→20→24→18→20→21
* 開始   : 2026-07-10 10:35:00 (UTC)
* 終了   : 2026-07-10 10:40:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260710-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→24→19→21→19→21→19→21→23
* 開始   : 2026-07-10 12:25:00 (UTC)
* 終了   : 2026-07-10 12:35:00 (UTC)
* 現象   : 平常時(22.75)に対し 0.8352(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→15→11→14→11→14→11→12→14
* 開始   : 2026-07-10 18:50:00 (UTC)
* 終了   : 2026-07-10 19:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→11→13→14→11→13
* 開始   : 2026-07-10 19:15:00 (UTC)
* 終了   : 2026-07-10 19:20:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260710-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→7→6→9→11→7→6→9
* 開始   : 2026-07-10 22:00:00 (UTC)
* 終了   : 2026-07-10 22:05:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→12
* 開始   : 2026-07-12 03:20:00 (UTC)
* 終了   : 2026-07-12 03:35:00 (UTC)
* 現象   : 2026-07-12 03:35:00 (UTC)を境に水準が 11.9から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.964, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→11→13→10→11→13→10→11
* 開始   : 2026-07-12 04:30:00 (UTC)
* 終了   : 2026-07-12 04:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.458倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.864σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→18→16→18→16→14
* 開始   : 2026-07-12 10:25:00 (UTC)
* 終了   : 2026-07-12 10:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→17
* 開始   : 2026-07-12 14:15:00 (UTC)
* 終了   : 2026-07-12 14:30:00 (UTC)
* 現象   : 2026-07-12 14:30:00 (UTC)を境に水準が 11.78から14.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→11→10→11→10→11→12
* 開始   : 2026-07-12 17:15:00 (UTC)
* 終了   : 2026-07-12 17:20:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260712-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→8→8→10→10→10→11→12
* 開始   : 2026-07-13 21:40:00 (UTC)
* 終了   : 2026-07-13 22:15:00 (UTC)
* 現象   : 2026-07-13 22:15:00 (UTC)を境に水準が 14.86から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→7→…→6→7→10→9
* 開始   : 2026-07-13 21:40:00 (UTC)
* 終了   : 2026-07-13 21:45:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.5854(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.992σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260713-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→13→16→15→13→16→14
* 開始   : 2026-07-14 05:05:00 (UTC)
* 終了   : 2026-07-14 05:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260714-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→17→19→16→19→16→19→17→15
* 開始   : 2026-07-14 06:35:00 (UTC)
* 終了   : 2026-07-14 06:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→23→24→21→25→21→21→23
* 開始   : 2026-07-14 11:45:00 (UTC)
* 終了   : 2026-07-14 12:20:00 (UTC)
* 現象   : 2026-07-14 12:20:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→17→…→18→17→20→19
* 開始   : 2026-07-14 14:55:00 (UTC)
* 終了   : 2026-07-14 15:00:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→18→14→16→14→16→14→16
* 開始   : 2026-07-14 17:10:00 (UTC)
* 終了   : 2026-07-14 17:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→11→12→10→11→14
* 開始   : 2026-07-14 19:20:00 (UTC)
* 終了   : 2026-07-14 19:25:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→13→10→12→11
* 開始   : 2026-07-14 19:35:00 (UTC)
* 終了   : 2026-07-14 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260714-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→11→12→11
* 開始   : 2026-07-14 21:45:00 (UTC)
* 終了   : 2026-07-14 22:10:00 (UTC)
* 現象   : 2026-07-14 22:10:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→20→16→18→22→16→18→22→17
* 開始   : 2026-07-15 16:00:00 (UTC)
* 終了   : 2026-07-15 16:10:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→14→14→14→15→15
* 開始   : 2026-07-15 18:30:00 (UTC)
* 終了   : 2026-07-15 18:55:00 (UTC)
* 現象   : 2026-07-15 18:55:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.298, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→13→13→13
* 開始   : 2026-07-15 19:15:00 (UTC)
* 終了   : 2026-07-15 19:30:00 (UTC)
* 現象   : 2026-07-15 19:30:00 (UTC)を境に水準が 15.06から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→8→10→12→8
* 開始   : 2026-07-16 01:55:00 (UTC)
* 終了   : 2026-07-16 02:00:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.455倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→17→21→20→…→20→21→20→18
* 開始   : 2026-07-16 07:30:00 (UTC)
* 終了   : 2026-07-16 07:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.922σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→23→18→22→20→20→21→19
* 開始   : 2026-07-16 14:50:00 (UTC)
* 終了   : 2026-07-16 15:25:00 (UTC)
* 現象   : 2026-07-16 15:25:00 (UTC)を境に水準が 14.97から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→19→17→19→17→18
* 開始   : 2026-07-16 15:25:00 (UTC)
* 終了   : 2026-07-16 15:35:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260716-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→17→20→19→17→20→18
* 開始   : 2026-07-16 15:30:00 (UTC)
* 終了   : 2026-07-16 15:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host16-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260716-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→17→15→17→15
* 開始   : 2026-07-16 16:50:00 (UTC)
* 終了   : 2026-07-16 16:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→18→…→18→21→15→16
* 開始   : 2026-07-16 17:00:00 (UTC)
* 終了   : 2026-07-16 17:10:00 (UTC)
* 現象   : 平常時(18)に対し 0.7778(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.822σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→15→…→17→14→17→15
* 開始   : 2026-07-16 17:15:00 (UTC)
* 終了   : 2026-07-16 17:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260716-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→16→12→13→11→12→13→11→13
* 開始   : 2026-07-16 18:40:00 (UTC)
* 終了   : 2026-07-16 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→11→13→13→13→12
* 開始   : 2026-07-16 19:40:00 (UTC)
* 終了   : 2026-07-16 20:15:00 (UTC)
* 現象   : 2026-07-16 20:15:00 (UTC)を境に水準が 14.98から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→5→8→9→5→8→10
* 開始   : 2026-07-17 00:55:00 (UTC)
* 終了   : 2026-07-17 01:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→11→9
* 開始   : 2026-07-17 01:55:00 (UTC)
* 終了   : 2026-07-17 02:15:00 (UTC)
* 現象   : 2026-07-17 02:15:00 (UTC)を境に水準が 15.01から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→16→16→17→18→17→16→17
* 開始   : 2026-07-17 05:50:00 (UTC)
* 終了   : 2026-07-17 06:30:00 (UTC)
* 現象   : 2026-07-17 06:30:00 (UTC)を境に水準が 15.06から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→14→18→15→18→15→18→16
* 開始   : 2026-07-17 06:10:00 (UTC)
* 終了   : 2026-07-17 06:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.763σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→21→19→18→23→21→19→18→23
* 開始   : 2026-07-17 13:50:00 (UTC)
* 終了   : 2026-07-17 13:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260717-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→11→10→12→11→10→12→11
* 開始   : 2026-07-17 19:35:00 (UTC)
* 終了   : 2026-07-17 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260717-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→12→13→10→12→10
* 開始   : 2026-07-17 19:45:00 (UTC)
* 終了   : 2026-07-17 19:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→8→…→8→10→13→9
* 開始   : 2026-07-18 04:30:00 (UTC)
* 終了   : 2026-07-18 04:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260718-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host16-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→11→9→11→10→9→11→10
* 開始   : 2026-07-18 20:10:00 (UTC)
* 終了   : 2026-07-18 20:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.753, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260718-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 7→12→9→9→8→9→10→11→10
* 開始   : 2026-07-19 02:35:00 (UTC)
* 終了   : 2026-07-19 03:25:00 (UTC)
* 現象   : 2026-07-19 03:25:00 (UTC)を境に水準が 11.82から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→12→12→10→12→12
* 開始   : 2026-07-19 04:10:00 (UTC)
* 終了   : 2026-07-19 04:35:00 (UTC)
* 現象   : 2026-07-19 04:35:00 (UTC)を境に水準が 11.8から12.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.45, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→12→13→12→13→12→10
* 開始   : 2026-07-19 04:35:00 (UTC)
* 終了   : 2026-07-19 04:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→13→13→13→14→12→13→13→15
* 開始   : 2026-07-19 06:05:00 (UTC)
* 終了   : 2026-07-19 06:45:00 (UTC)
* 現象   : 2026-07-19 06:45:00 (UTC)を境に水準が 11.89から12.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→15→…→15→12→16→15
* 開始   : 2026-07-19 10:25:00 (UTC)
* 終了   : 2026-07-19 10:35:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→17→16→16→16→14→18
* 開始   : 2026-07-19 11:50:00 (UTC)
* 終了   : 2026-07-19 12:55:00 (UTC)
* 現象   : 2026-07-19 12:55:00 (UTC)を境に水準が 11.75から13.66へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.593, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→13→12→14
* 開始   : 2026-07-19 17:45:00 (UTC)
* 終了   : 2026-07-19 18:05:00 (UTC)
* 現象   : 2026-07-19 18:05:00 (UTC)を境に水準が 11.85から14.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→7→13→10→7→13→10→8
* 開始   : 2026-07-19 20:20:00 (UTC)
* 終了   : 2026-07-19 20:25:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260719-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260719-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→10→9→12→10
* 開始   : 2026-07-19 20:20:00 (UTC)
* 終了   : 2026-07-19 20:40:00 (UTC)
* 現象   : 2026-07-19 20:40:00 (UTC)を境に水準が 11.85から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host16-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→10→8→8→8→8→10→11→9
* 開始   : 2026-07-19 22:40:00 (UTC)
* 終了   : 2026-07-19 23:25:00 (UTC)
* 現象   : 2026-07-19 23:25:00 (UTC)を境に水準が 11.76から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 7→9→10→7→…→7→11→10→9
* 開始   : 2026-07-20 01:20:00 (UTC)
* 終了   : 2026-07-20 01:30:00 (UTC)
* 現象   : 平常時(7)に対し 1.429倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 7→8→6→9→12→6→9→12→8
* 開始   : 2026-07-20 22:35:00 (UTC)
* 終了   : 2026-07-20 22:45:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→7→10→9→8→11→9
* 開始   : 2026-07-20 23:55:00 (UTC)
* 終了   : 2026-07-21 00:30:00 (UTC)
* 現象   : 2026-07-21 00:30:00 (UTC)を境に水準が 15.12から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→11→12→9→12→9→12→11
* 開始   : 2026-07-21 02:45:00 (UTC)
* 終了   : 2026-07-21 02:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 24→21→24→22→22→23→23→24→23
* 開始   : 2026-07-21 12:25:00 (UTC)
* 終了   : 2026-07-21 13:25:00 (UTC)
* 現象   : 2026-07-21 13:25:00 (UTC)を境に水準が 15.03から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.045, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 23→22→20→24→23→23→23→23→23
* 開始   : 2026-07-21 12:40:00 (UTC)
* 終了   : 2026-07-21 13:25:00 (UTC)
* 現象   : 2026-07-21 13:25:00 (UTC)を境に水準が 15.09から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→20→23→20→22→20→21→20→21
* 開始   : 2026-07-21 14:10:00 (UTC)
* 終了   : 2026-07-21 15:35:00 (UTC)
* 現象   : 2026-07-21 15:35:00 (UTC)を境に水準が 15.04から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→20→18→17→…→18→17→22→21
* 開始   : 2026-07-21 14:50:00 (UTC)
* 終了   : 2026-07-21 14:55:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→15→14→12→15
* 開始   : 2026-07-21 18:20:00 (UTC)
* 終了   : 2026-07-21 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.587σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→13→9→10→8→9→10→8→10
* 開始   : 2026-07-21 20:25:00 (UTC)
* 終了   : 2026-07-21 20:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host16-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260721-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→6→9→6→9→6→8→7
* 開始   : 2026-07-21 22:55:00 (UTC)
* 終了   : 2026-07-21 23:05:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→14→14→13→15→16→13
* 開始   : 2026-07-22 03:50:00 (UTC)
* 終了   : 2026-07-22 05:10:00 (UTC)
* 現象   : 2026-07-22 05:10:00 (UTC)を境に水準が 15.07から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.528σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.164, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→16→14→16→17→16→16→17
* 開始   : 2026-07-22 05:50:00 (UTC)
* 終了   : 2026-07-22 06:35:00 (UTC)
* 現象   : 2026-07-22 06:35:00 (UTC)を境に水準が 15.06から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.111, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→17→…→17→15→18→19
* 開始   : 2026-07-22 16:40:00 (UTC)
* 終了   : 2026-07-22 17:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→12→…→12→8→10→11
* 開始   : 2026-07-22 21:05:00 (UTC)
* 終了   : 2026-07-22 21:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.6269(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.923σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→12→9→13→12→9→13→10
* 開始   : 2026-07-23 02:45:00 (UTC)
* 終了   : 2026-07-23 02:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→16→…→15→16→15→11
* 開始   : 2026-07-23 04:45:00 (UTC)
* 終了   : 2026-07-23 04:50:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→11→15→13→15→13→12
* 開始   : 2026-07-23 04:50:00 (UTC)
* 終了   : 2026-07-23 05:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260723-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→16→17→17→17→17→19→18→19
* 開始   : 2026-07-23 06:15:00 (UTC)
* 終了   : 2026-07-23 07:05:00 (UTC)
* 現象   : 2026-07-23 07:05:00 (UTC)を境に水準が 14.98から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→19→18→19→18→19→18→15
* 開始   : 2026-07-23 06:40:00 (UTC)
* 終了   : 2026-07-23 06:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260723-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 21→18→17→19→21→18→17→19→22
* 開始   : 2026-07-23 15:00:00 (UTC)
* 終了   : 2026-07-23 15:05:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260723-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 19→17→14→16→…→16→13→14→15
* 開始   : 2026-07-23 17:50:00 (UTC)
* 終了   : 2026-07-23 18:00:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260723-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→14→11→13→11→13→11→13→14
* 開始   : 2026-07-23 19:15:00 (UTC)
* 終了   : 2026-07-23 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host16-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260723-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→12→…→12→10→11→12
* 開始   : 2026-07-23 19:20:00 (UTC)
* 終了   : 2026-07-23 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260723-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→7→6→8→6→8→6→7→8
* 開始   : 2026-07-23 22:40:00 (UTC)
* 終了   : 2026-07-23 22:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→10→9→9
* 開始   : 2026-07-24 00:25:00 (UTC)
* 終了   : 2026-07-24 00:50:00 (UTC)
* 現象   : 2026-07-24 00:50:00 (UTC)を境に水準が 14.82から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→11→10→10→12
* 開始   : 2026-07-24 01:25:00 (UTC)
* 終了   : 2026-07-24 01:45:00 (UTC)
* 現象   : 2026-07-24 01:45:00 (UTC)を境に水準が 15.08から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→15→13→16→15→16
* 開始   : 2026-07-24 05:45:00 (UTC)
* 終了   : 2026-07-24 05:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→18→…→18→23→19→17
* 開始   : 2026-07-24 08:30:00 (UTC)
* 終了   : 2026-07-24 08:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260724-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→20→18→22→17→18→22→17→18
* 開始   : 2026-07-24 14:55:00 (UTC)
* 終了   : 2026-07-24 15:05:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→15→13→17→15→13→17→14
* 開始   : 2026-07-24 17:50:00 (UTC)
* 終了   : 2026-07-24 17:55:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260724-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→17→12→14→17→12→14→13
* 開始   : 2026-07-24 18:00:00 (UTC)
* 終了   : 2026-07-24 18:05:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.7385(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→15→13→14
* 開始   : 2026-07-24 18:00:00 (UTC)
* 終了   : 2026-07-24 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→8→10→11→…→11→10→11→10
* 開始   : 2026-07-25 04:00:00 (UTC)
* 終了   : 2026-07-25 04:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.872, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260725-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→10→8→9→…→8→9→10→11
* 開始   : 2026-07-25 04:00:00 (UTC)
* 終了   : 2026-07-25 04:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.214, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260725-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260725-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260725-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host16-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→10→…→10→11→10→9
* 開始   : 2026-07-25 19:15:00 (UTC)
* 終了   : 2026-07-25 19:55:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.941, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 40 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分

![EVT-20260725-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→9→12→13→10→11→14→11→12
* 開始   : 2026-07-26 05:00:00 (UTC)
* 終了   : 2026-07-26 06:00:00 (UTC)
* 現象   : 2026-07-26 06:00:00 (UTC)を境に水準が 11.83から12.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→14→14→13→15→13→13
* 開始   : 2026-07-26 06:45:00 (UTC)
* 終了   : 2026-07-26 07:15:00 (UTC)
* 現象   : 2026-07-26 07:15:00 (UTC)を境に水準が 11.75から12.2へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→15→19→18→15→19→15
* 開始   : 2026-07-26 10:40:00 (UTC)
* 終了   : 2026-07-26 10:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→12→9→12→9→10
* 開始   : 2026-07-26 18:25:00 (UTC)
* 終了   : 2026-07-26 18:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.587σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→16→13→17→16→15
* 開始   : 2026-07-28 05:50:00 (UTC)
* 終了   : 2026-07-28 05:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260728-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→18→19→21→21→17→19→21→20
* 開始   : 2026-07-28 07:20:00 (UTC)
* 終了   : 2026-07-28 08:10:00 (UTC)
* 現象   : 2026-07-28 08:10:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→20→22→20→…→20→23→22→19
* 開始   : 2026-07-28 08:50:00 (UTC)
* 終了   : 2026-07-28 09:00:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 23→20→22→21→22→21→23→21→22
* 開始   : 2026-07-28 13:10:00 (UTC)
* 終了   : 2026-07-28 14:45:00 (UTC)
* 現象   : 2026-07-28 14:45:00 (UTC)を境に水準が 14.92から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→14→15→14→15→14→15
* 開始   : 2026-07-28 17:35:00 (UTC)
* 終了   : 2026-07-28 17:45:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host16-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→16→14→18→16→14→18→14
* 開始   : 2026-07-28 17:40:00 (UTC)
* 終了   : 2026-07-28 18:10:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260728-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→11→14→11→13→15
* 開始   : 2026-07-28 19:10:00 (UTC)
* 終了   : 2026-07-28 19:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260728-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→10→9→10→9→9→9
* 開始   : 2026-07-28 21:40:00 (UTC)
* 終了   : 2026-07-28 22:35:00 (UTC)
* 現象   : 2026-07-28 22:35:00 (UTC)を境に水準が 14.97から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.361, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→8→12→7→12→7→12→9→11
* 開始   : 2026-07-29 02:35:00 (UTC)
* 終了   : 2026-07-29 02:45:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→13→12→14→13
* 開始   : 2026-07-29 04:30:00 (UTC)
* 終了   : 2026-07-29 04:35:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→16→17→16→17→16→15
* 開始   : 2026-07-29 05:55:00 (UTC)
* 終了   : 2026-07-29 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→16→17→16→18→17→17→17→17
* 開始   : 2026-07-29 06:05:00 (UTC)
* 終了   : 2026-07-29 06:55:00 (UTC)
* 現象   : 2026-07-29 06:55:00 (UTC)を境に水準が 15.05から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 23→22→21→22
* 開始   : 2026-07-29 09:15:00 (UTC)
* 終了   : 2026-07-29 09:30:00 (UTC)
* 現象   : 2026-07-29 09:30:00 (UTC)を境に水準が 15.06から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.865, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→21→17→21→…→21→16→20→18
* 開始   : 2026-07-29 15:20:00 (UTC)
* 終了   : 2026-07-29 15:30:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→18→14→17→…→17→13→18→14
* 開始   : 2026-07-29 17:45:00 (UTC)
* 終了   : 2026-07-29 17:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260729-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→14→16→16→16→15→16→15→15
* 開始   : 2026-07-29 17:50:00 (UTC)
* 終了   : 2026-07-29 18:35:00 (UTC)
* 現象   : 2026-07-29 18:35:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→14→16→14→14→16→16
* 開始   : 2026-07-29 17:55:00 (UTC)
* 終了   : 2026-07-29 18:35:00 (UTC)
* 現象   : 2026-07-29 18:35:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→11→14→13→11→14→11
* 開始   : 2026-07-29 19:15:00 (UTC)
* 終了   : 2026-07-29 19:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→18→15→18→15→18→15→14
* 開始   : 2026-07-30 06:10:00 (UTC)
* 終了   : 2026-07-30 06:20:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→20→21→20→20→22→20→19→20
* 開始   : 2026-07-30 14:40:00 (UTC)
* 終了   : 2026-07-30 15:25:00 (UTC)
* 現象   : 2026-07-30 15:25:00 (UTC)を境に水準が 15.02から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→19→19→19→20→18→19→19→18
* 開始   : 2026-07-30 16:05:00 (UTC)
* 終了   : 2026-07-30 16:50:00 (UTC)
* 現象   : 2026-07-30 16:50:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.111, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→16→14→16→14→16→18
* 開始   : 2026-07-30 17:25:00 (UTC)
* 終了   : 2026-07-30 17:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→15→19→18→13→19→18→13→14
* 開始   : 2026-07-30 18:00:00 (UTC)
* 終了   : 2026-07-30 18:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260730-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260730-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→19→15→20→19→17
* 開始   : 2026-07-31 07:25:00 (UTC)
* 終了   : 2026-07-31 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260731-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→23→24→21→22→25→24
* 開始   : 2026-07-31 10:25:00 (UTC)
* 終了   : 2026-07-31 10:55:00 (UTC)
* 現象   : 2026-07-31 10:55:00 (UTC)を境に水準が 14.92から13.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→19→17→16→…→19→16→20→17
* 開始   : 2026-07-31 15:45:00 (UTC)
* 終了   : 2026-07-31 16:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→10→10→12→9→9→10→10→11
* 開始   : 2026-07-31 21:20:00 (UTC)
* 終了   : 2026-07-31 22:35:00 (UTC)
* 現象   : 2026-07-31 22:35:00 (UTC)を境に水準が 14.98から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→8→8→10→10→8→8→7→11
* 開始   : 2026-07-31 22:25:00 (UTC)
* 終了   : 2026-07-31 23:10:00 (UTC)
* 現象   : 2026-07-31 23:10:00 (UTC)を境に水準が 14.87から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host16-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
