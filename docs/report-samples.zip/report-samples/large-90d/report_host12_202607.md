# host12 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host12 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 317 (SEVERE: 35, FATAL: 124, WARN: 158, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 35 | 124 | 158 | 317 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260701-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→9→9→10
* 開始   : 2026-07-01 23:25:00 (UTC)
* 終了   : 2026-07-01 23:40:00 (UTC)
* 現象   : 2026-07-01 23:40:00 (UTC)を境に水準が 15.01から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host12-010 active_connections の推移](charts/EVT-20260701-host12-010.svg)

# イベントID( EVT-20260705-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→10→12→10→12→11→12
* 開始   : 2026-07-05 04:20:00 (UTC)
* 終了   : 2026-07-05 05:15:00 (UTC)
* 現象   : 2026-07-05 05:15:00 (UTC)を境に水準が 11.86から12.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host12-003 active_connections の推移](charts/EVT-20260705-host12-003.svg)

# イベントID( EVT-20260706-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→16→12→14→12
* 開始   : 2026-07-06 01:05:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 11.75から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.157, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-001 active_connections の推移](charts/EVT-20260706-host12-001.svg)

# イベントID( EVT-20260706-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→14→16→13→12
* 開始   : 2026-07-06 02:10:00 (UTC)
* 終了   : 2026-07-06 21:15:00 (UTC)
* 現象   : 2026-07-06 21:15:00 (UTC)を境に水準が 11.85から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.079, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-002 active_connections の推移](charts/EVT-20260706-host12-002.svg)

# イベントID( EVT-20260706-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→17→…→14→16→15→14
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:35:00 (UTC)
* 現象   : 2026-07-06 20:35:00 (UTC)を境に水準が 11.94から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.803, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-003 active_connections の推移](charts/EVT-20260706-host12-003.svg)

# イベントID( EVT-20260706-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→14→…→14→15→11→12
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:15:00 (UTC)
* 現象   : 2026-07-06 20:15:00 (UTC)を境に水準が 11.95から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.008, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-004 active_connections の推移](charts/EVT-20260706-host12-004.svg)

# イベントID( EVT-20260706-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→17→16→14→16
* 開始   : 2026-07-06 03:45:00 (UTC)
* 終了   : 2026-07-06 21:00:00 (UTC)
* 現象   : 2026-07-06 21:00:00 (UTC)を境に水準が 11.98から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.238, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-005 active_connections の推移](charts/EVT-20260706-host12-005.svg)

# イベントID( EVT-20260706-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→19→…→13→14→13→14
* 開始   : 2026-07-06 04:00:00 (UTC)
* 終了   : 2026-07-06 20:50:00 (UTC)
* 現象   : 2026-07-06 20:50:00 (UTC)を境に水準が 11.87から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.669, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-006 active_connections の推移](charts/EVT-20260706-host12-006.svg)

# イベントID( EVT-20260706-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→12→12
* 開始   : 2026-07-06 21:55:00 (UTC)
* 終了   : 2026-07-06 22:05:00 (UTC)
* 現象   : 2026-07-06 22:05:00 (UTC)を境に水準が 14.98から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.632, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host12-008 active_connections の推移](charts/EVT-20260706-host12-008.svg)

# イベントID( EVT-20260708-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→11→11→11→10
* 開始   : 2026-07-08 21:25:00 (UTC)
* 終了   : 2026-07-08 21:45:00 (UTC)
* 現象   : 2026-07-08 21:45:00 (UTC)を境に水準が 14.93から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-011 active_connections の推移](charts/EVT-20260708-host12-011.svg)

# イベントID( EVT-20260709-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→18→…→18→20→16→17
* 開始   : 2026-07-09 06:50:00 (UTC)
* 終了   : 2026-07-09 07:05:00 (UTC)
* 現象   : 2026-07-09 07:05:00 (UTC)を境に水準が 14.97から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host12-007 active_connections の推移](charts/EVT-20260709-host12-007.svg)

# イベントID( EVT-20260709-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→15→16→16→15
* 開始   : 2026-07-09 18:00:00 (UTC)
* 終了   : 2026-07-09 18:30:00 (UTC)
* 現象   : 2026-07-09 18:30:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host12-011 active_connections の推移](charts/EVT-20260709-host12-011.svg)

# イベントID( EVT-20260713-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→15→17→16→…→14→15→14→15
* 開始   : 2026-07-13 01:45:00 (UTC)
* 終了   : 2026-07-13 21:30:00 (UTC)
* 現象   : 2026-07-13 21:30:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.657, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-002 active_connections の推移](charts/EVT-20260713-host12-002.svg)

# イベントID( EVT-20260713-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→…→13→14→11→14
* 開始   : 2026-07-13 02:20:00 (UTC)
* 終了   : 2026-07-13 20:05:00 (UTC)
* 現象   : 2026-07-13 20:05:00 (UTC)を境に水準が 11.86から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.97, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-003 active_connections の推移](charts/EVT-20260713-host12-003.svg)

# イベントID( EVT-20260713-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→15→…→11→14→11→13
* 開始   : 2026-07-13 03:30:00 (UTC)
* 終了   : 2026-07-13 22:15:00 (UTC)
* 現象   : 2026-07-13 22:15:00 (UTC)を境に水準が 11.79から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.671, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-005 active_connections の推移](charts/EVT-20260713-host12-005.svg)

# イベントID( EVT-20260713-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→14→15→…→13→16→14→13
* 開始   : 2026-07-13 03:35:00 (UTC)
* 終了   : 2026-07-13 21:40:00 (UTC)
* 現象   : 2026-07-13 21:40:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.684, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-006 active_connections の推移](charts/EVT-20260713-host12-006.svg)

# イベントID( EVT-20260713-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→15→…→15→11→12→15
* 開始   : 2026-07-13 04:25:00 (UTC)
* 終了   : 2026-07-13 19:30:00 (UTC)
* 現象   : 2026-07-13 19:30:00 (UTC)を境に水準が 11.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.042, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-007 active_connections の推移](charts/EVT-20260713-host12-007.svg)

# イベントID( EVT-20260715-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 23→22→22→21→21→22→22→23→23
* 開始   : 2026-07-15 12:50:00 (UTC)
* 終了   : 2026-07-15 13:35:00 (UTC)
* 現象   : 2026-07-15 13:35:00 (UTC)を境に水準が 15.04から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host12-008 active_connections の推移](charts/EVT-20260715-host12-008.svg)

# イベントID( EVT-20260719-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→11→13→13→12→11
* 開始   : 2026-07-19 18:00:00 (UTC)
* 終了   : 2026-07-19 18:35:00 (UTC)
* 現象   : 2026-07-19 18:35:00 (UTC)を境に水準が 11.85から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host12-007 active_connections の推移](charts/EVT-20260719-host12-007.svg)

# イベントID( EVT-20260720-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→15→14→16→…→13→14→13→14
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 21:10:00 (UTC)
* 現象   : 2026-07-20 21:10:00 (UTC)を境に水準が 11.88から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-003 active_connections の推移](charts/EVT-20260720-host12-003.svg)

# イベントID( EVT-20260720-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→15→…→13→12→13→12
* 開始   : 2026-07-20 02:55:00 (UTC)
* 終了   : 2026-07-20 20:25:00 (UTC)
* 現象   : 2026-07-20 20:25:00 (UTC)を境に水準が 11.84から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.689, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.185, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-004 active_connections の推移](charts/EVT-20260720-host12-004.svg)

# イベントID( EVT-20260720-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→13→14→13→…→15→14→13→12
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.74から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.664, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-005 active_connections の推移](charts/EVT-20260720-host12-005.svg)

# イベントID( EVT-20260720-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→15→…→12→14→11→12
* 開始   : 2026-07-20 03:20:00 (UTC)
* 終了   : 2026-07-20 21:55:00 (UTC)
* 現象   : 2026-07-20 21:55:00 (UTC)を境に水準が 11.81から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.877, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-006 active_connections の推移](charts/EVT-20260720-host12-006.svg)

# イベントID( EVT-20260720-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→17→16→17→…→12→15→14→12
* 開始   : 2026-07-20 03:50:00 (UTC)
* 終了   : 2026-07-20 20:25:00 (UTC)
* 現象   : 2026-07-20 20:25:00 (UTC)を境に水準が 11.96から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.775, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-007 active_connections の推移](charts/EVT-20260720-host12-007.svg)

# イベントID( EVT-20260720-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→15→…→16→14→13→14
* 開始   : 2026-07-20 03:50:00 (UTC)
* 終了   : 2026-07-20 20:20:00 (UTC)
* 現象   : 2026-07-20 20:20:00 (UTC)を境に水準が 11.97から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.167, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.567, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-008 active_connections の推移](charts/EVT-20260720-host12-008.svg)

# イベントID( EVT-20260721-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→21→21→21→20→20→24→22
* 開始   : 2026-07-21 08:05:00 (UTC)
* 終了   : 2026-07-21 09:35:00 (UTC)
* 現象   : 2026-07-21 09:35:00 (UTC)を境に水準が 15.01から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.78σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host12-002 active_connections の推移](charts/EVT-20260721-host12-002.svg)

# イベントID( EVT-20260724-host12-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→8→9→10→7→10→10
* 開始   : 2026-07-24 23:35:00 (UTC)
* 終了   : 2026-07-25 00:05:00 (UTC)
* 現象   : 2026-07-25 00:05:00 (UTC)を境に水準が 15から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host12-013 active_connections の推移](charts/EVT-20260724-host12-013.svg)

# イベントID( EVT-20260726-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→8→10→11→11→10→9→12
* 開始   : 2026-07-26 21:20:00 (UTC)
* 終了   : 2026-07-26 22:20:00 (UTC)
* 現象   : 2026-07-26 22:20:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host12-005 active_connections の推移](charts/EVT-20260726-host12-005.svg)

# イベントID( EVT-20260727-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→11→9→9→11→9→10→9
* 開始   : 2026-07-27 01:25:00 (UTC)
* 終了   : 2026-07-27 02:00:00 (UTC)
* 現象   : 2026-07-27 02:00:00 (UTC)を境に水準が 11.76から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-003 active_connections の推移](charts/EVT-20260727-host12-003.svg)

# イベントID( EVT-20260727-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→12→14→12→11
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 19:30:00 (UTC)
* 現象   : 2026-07-27 19:30:00 (UTC)を境に水準が 11.83から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.296, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.685, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-004 active_connections の推移](charts/EVT-20260727-host12-004.svg)

# イベントID( EVT-20260727-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→14→…→12→15→13→12
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 20:20:00 (UTC)
* 現象   : 2026-07-27 20:20:00 (UTC)を境に水準が 11.84から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.844, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-006 active_connections の推移](charts/EVT-20260727-host12-006.svg)

# イベントID( EVT-20260727-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→14→…→13→12→14→11
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 20:20:00 (UTC)
* 現象   : 2026-07-27 20:20:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.991, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.358, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-007 active_connections の推移](charts/EVT-20260727-host12-007.svg)

# イベントID( EVT-20260727-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→16→…→13→14→13→12
* 開始   : 2026-07-27 03:25:00 (UTC)
* 終了   : 2026-07-27 20:50:00 (UTC)
* 現象   : 2026-07-27 20:50:00 (UTC)を境に水準が 11.91から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.903, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-008 active_connections の推移](charts/EVT-20260727-host12-008.svg)

# イベントID( EVT-20260727-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→9→10→11→9
* 開始   : 2026-07-27 22:00:00 (UTC)
* 終了   : 2026-07-27 22:20:00 (UTC)
* 現象   : 2026-07-27 22:20:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-011 active_connections の推移](charts/EVT-20260727-host12-011.svg)

# イベントID( EVT-20260729-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→9→6→9→10→8→12→9→11
* 開始   : 2026-07-29 01:20:00 (UTC)
* 終了   : 2026-07-29 02:00:00 (UTC)
* 現象   : 2026-07-29 02:00:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host12-001 active_connections の推移](charts/EVT-20260729-host12-001.svg)

# イベントID( EVT-20260701-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→11→10
* 開始   : 2026-07-01 03:50:00 (UTC)
* 終了   : 2026-07-01 03:50:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.466倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→13→16→12→12
* 開始   : 2026-07-01 04:25:00 (UTC)
* 終了   : 2026-07-01 04:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→22→18→21→22→18→21→20
* 開始   : 2026-07-01 14:55:00 (UTC)
* 終了   : 2026-07-01 16:00:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260701-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 21→19→15→18→18
* 開始   : 2026-07-01 16:25:00 (UTC)
* 終了   : 2026-07-01 16:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260701-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→11→15→11→12
* 開始   : 2026-07-02 03:55:00 (UTC)
* 終了   : 2026-07-02 03:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→20→25→22→23
* 開始   : 2026-07-02 10:05:00 (UTC)
* 終了   : 2026-07-02 10:05:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→18→18
* 開始   : 2026-07-02 16:35:00 (UTC)
* 終了   : 2026-07-02 16:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→16→13→17→16
* 開始   : 2026-07-02 17:25:00 (UTC)
* 終了   : 2026-07-02 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260702-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→19→13→14→…→13→14→15→16
* 開始   : 2026-07-02 17:25:00 (UTC)
* 終了   : 2026-07-02 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→16→18
* 開始   : 2026-07-03 07:00:00 (UTC)
* 終了   : 2026-07-03 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→22→22
* 開始   : 2026-07-03 09:30:00 (UTC)
* 終了   : 2026-07-03 09:30:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.288倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host12-007 active_connections の推移](charts/EVT-20260703-host12-007.svg)

# イベントID( EVT-20260703-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 26→23→21→23→24
* 開始   : 2026-07-03 10:35:00 (UTC)
* 終了   : 2026-07-03 10:55:00 (UTC)
* 現象   : 2026-07-03 10:55:00 (UTC)を境に水準が 15.04から13.74へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.725σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→10→7→13→9
* 開始   : 2026-07-03 20:40:00 (UTC)
* 終了   : 2026-07-03 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→14→11→13→…→9→11→12→11
* 開始   : 2026-07-04 05:15:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.073, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host12-003 active_connections の推移](charts/EVT-20260704-host12-003.svg)

# イベントID( EVT-20260704-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→11→…→12→11→13→11
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.816, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host12-004 active_connections の推移](charts/EVT-20260704-host12-004.svg)

# イベントID( EVT-20260704-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→12→…→11→13→14→11
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260704-host12-005 active_connections の推移](charts/EVT-20260704-host12-005.svg)

# イベントID( EVT-20260704-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→12→11→13→…→14→10→12→10
* 開始   : 2026-07-04 05:50:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host12-006 active_connections の推移](charts/EVT-20260704-host12-006.svg)

# イベントID( EVT-20260704-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→13→10→11→…→13→12→13→11
* 開始   : 2026-07-04 06:10:00 (UTC)
* 終了   : 2026-07-04 19:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260704-host12-007 active_connections の推移](charts/EVT-20260704-host12-007.svg)

# イベントID( EVT-20260704-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→13→…→11→13→11→13
* 開始   : 2026-07-04 06:30:00 (UTC)
* 終了   : 2026-07-04 19:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.877, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間

![EVT-20260704-host12-008 active_connections の推移](charts/EVT-20260704-host12-008.svg)

# イベントID( EVT-20260704-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→10→9
* 開始   : 2026-07-04 20:00:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260704-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→11→14→10→…→10→5→11→9
* 開始   : 2026-07-05 04:00:00 (UTC)
* 終了   : 2026-07-05 04:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host12-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260705-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→10→7→9→12
* 開始   : 2026-07-05 18:45:00 (UTC)
* 終了   : 2026-07-05 18:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→9→5→9→9
* 開始   : 2026-07-06 21:55:00 (UTC)
* 終了   : 2026-07-06 21:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260706-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260706-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→7→4→8→8
* 開始   : 2026-07-07 00:50:00 (UTC)
* 終了   : 2026-07-07 00:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→14→18→16→17
* 開始   : 2026-07-07 05:55:00 (UTC)
* 終了   : 2026-07-07 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→17→21→19→19
* 開始   : 2026-07-07 07:30:00 (UTC)
* 終了   : 2026-07-07 07:30:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→19→25→22→20
* 開始   : 2026-07-07 10:30:00 (UTC)
* 終了   : 2026-07-07 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→20→15→19→19
* 開始   : 2026-07-07 15:45:00 (UTC)
* 終了   : 2026-07-07 15:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.7407(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host12-010 active_connections の推移](charts/EVT-20260707-host12-010.svg)

# イベントID( EVT-20260708-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→17→20→21→20→22→22→22→20
* 開始   : 2026-07-08 14:55:00 (UTC)
* 終了   : 2026-07-08 16:30:00 (UTC)
* 現象   : 2026-07-08 16:30:00 (UTC)を境に水準が 14.93から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.508, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→8→14→10→…→10→13→11→9
* 開始   : 2026-07-09 03:20:00 (UTC)
* 終了   : 2026-07-09 03:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260709-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→13→17→12→15
* 開始   : 2026-07-09 04:50:00 (UTC)
* 終了   : 2026-07-09 04:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→15→19→17→17
* 開始   : 2026-07-09 06:40:00 (UTC)
* 終了   : 2026-07-09 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→18→21→18→18
* 開始   : 2026-07-09 06:55:00 (UTC)
* 終了   : 2026-07-09 07:25:00 (UTC)
* 現象   : 2026-07-09 07:25:00 (UTC)を境に水準が 14.95から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→16→14→17→18
* 開始   : 2026-07-09 16:50:00 (UTC)
* 終了   : 2026-07-09 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→10→13→8→9
* 開始   : 2026-07-10 02:10:00 (UTC)
* 終了   : 2026-07-10 02:10:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→19→…→18→19→15→14
* 開始   : 2026-07-10 06:00:00 (UTC)
* 終了   : 2026-07-10 06:05:00 (UTC)
* 現象   : 平常時(14)に対し 1.286倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→17→20→17→18
* 開始   : 2026-07-10 06:55:00 (UTC)
* 終了   : 2026-07-10 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→18→22→19→17
* 開始   : 2026-07-10 07:55:00 (UTC)
* 終了   : 2026-07-10 07:55:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→22→22
* 開始   : 2026-07-10 10:30:00 (UTC)
* 終了   : 2026-07-10 10:30:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.235倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260710-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→23→26→21→23
* 開始   : 2026-07-10 10:30:00 (UTC)
* 終了   : 2026-07-10 10:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.263倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260710-host12-007 active_connections の推移](charts/EVT-20260710-host12-007.svg)

# イベントID( EVT-20260710-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→17→13→17→16
* 開始   : 2026-07-10 17:10:00 (UTC)
* 終了   : 2026-07-10 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260710-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→15→9→15→13
* 開始   : 2026-07-10 18:35:00 (UTC)
* 終了   : 2026-07-10 18:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.6102(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host12-011 active_connections の推移](charts/EVT-20260710-host12-011.svg)

# イベントID( EVT-20260710-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→12→7→9→8
* 開始   : 2026-07-10 20:55:00 (UTC)
* 終了   : 2026-07-10 20:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→13→…→10→12→10→12
* 開始   : 2026-07-11 05:00:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.4 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260711-host12-001 active_connections の推移](charts/EVT-20260711-host12-001.svg)

# イベントID( EVT-20260711-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→9→12→13→…→13→11→13→11
* 開始   : 2026-07-11 05:00:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260711-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→8→9→11→…→9→12→13→11
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.16, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260711-host12-003 active_connections の推移](charts/EVT-20260711-host12-003.svg)

# イベントID( EVT-20260711-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→11→…→10→11→12→11
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.169, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host12-004 active_connections の推移](charts/EVT-20260711-host12-004.svg)

# イベントID( EVT-20260711-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→9→13→9→…→13→12→13→15
* 開始   : 2026-07-11 05:55:00 (UTC)
* 終了   : 2026-07-11 18:05:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260711-host12-005 active_connections の推移](charts/EVT-20260711-host12-005.svg)

# イベントID( EVT-20260711-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→14→…→14→12→14→13
* 開始   : 2026-07-11 06:25:00 (UTC)
* 終了   : 2026-07-11 18:20:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.18, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260711-host12-006 active_connections の推移](charts/EVT-20260711-host12-006.svg)

# イベントID( EVT-20260712-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→12→15→11→11
* 開始   : 2026-07-12 05:55:00 (UTC)
* 終了   : 2026-07-12 05:55:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→11→14→15→11→14→15
* 開始   : 2026-07-12 15:15:00 (UTC)
* 終了   : 2026-07-12 15:20:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260712-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 8→7→9→8→12→9→8→10→11
* 開始   : 2026-07-13 00:25:00 (UTC)
* 終了   : 2026-07-13 01:10:00 (UTC)
* 現象   : 2026-07-13 01:10:00 (UTC)を境に水準が 11.76から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→16→14→12→15
* 開始   : 2026-07-13 02:45:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.658, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→20→25→20→20
* 開始   : 2026-07-14 10:30:00 (UTC)
* 終了   : 2026-07-14 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→16→14
* 開始   : 2026-07-14 18:45:00 (UTC)
* 終了   : 2026-07-14 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→13→11
* 開始   : 2026-07-15 04:20:00 (UTC)
* 終了   : 2026-07-15 04:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→15→14→…→15→14→13→12
* 開始   : 2026-07-15 04:25:00 (UTC)
* 終了   : 2026-07-15 04:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→12→14→13→…→13→16→12→11
* 開始   : 2026-07-15 04:35:00 (UTC)
* 終了   : 2026-07-15 04:45:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→16→21→18→18
* 開始   : 2026-07-15 07:10:00 (UTC)
* 終了   : 2026-07-15 07:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→14→18→14→14
* 開始   : 2026-07-16 05:35:00 (UTC)
* 終了   : 2026-07-16 05:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260716-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→17→…→17→21→18→19
* 開始   : 2026-07-16 07:25:00 (UTC)
* 終了   : 2026-07-16 07:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→20→22→18→20
* 開始   : 2026-07-16 08:20:00 (UTC)
* 終了   : 2026-07-16 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→16→11→16→15
* 開始   : 2026-07-16 18:10:00 (UTC)
* 終了   : 2026-07-16 18:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host12-006 active_connections の推移](charts/EVT-20260716-host12-006.svg)

# イベントID( EVT-20260717-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→10→15→12→11
* 開始   : 2026-07-17 03:40:00 (UTC)
* 終了   : 2026-07-17 03:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→16→13→16→13→16→14→13
* 開始   : 2026-07-17 05:05:00 (UTC)
* 終了   : 2026-07-17 05:35:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.324倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260717-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260717-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→14→13
* 開始   : 2026-07-17 05:40:00 (UTC)
* 終了   : 2026-07-17 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→22→17→20→20
* 開始   : 2026-07-17 14:00:00 (UTC)
* 終了   : 2026-07-17 14:00:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→13→12→13→12→13→16
* 開始   : 2026-07-17 18:00:00 (UTC)
* 終了   : 2026-07-17 18:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260717-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 25 分
  - EVT-20260717-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host12-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→11→10→11→…→12→9→11→12
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.789, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260718-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host12-001 active_connections の推移](charts/EVT-20260718-host12-001.svg)

# イベントID( EVT-20260718-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→10→12→10→…→15→14→15→13
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 19:40:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.868, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260718-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260718-host12-002 active_connections の推移](charts/EVT-20260718-host12-002.svg)

# イベントID( EVT-20260718-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→10→11→12→…→12→11→12→13
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 19:55:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.501, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260718-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host12-003 active_connections の推移](charts/EVT-20260718-host12-003.svg)

# イベントID( EVT-20260718-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→11→…→10→11→10→12
* 開始   : 2026-07-18 05:55:00 (UTC)
* 終了   : 2026-07-18 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.723, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260718-host12-004 active_connections の推移](charts/EVT-20260718-host12-004.svg)

# イベントID( EVT-20260718-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→14→…→11→10→13→11
* 開始   : 2026-07-18 06:25:00 (UTC)
* 終了   : 2026-07-18 18:35:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.375, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260718-host12-005 active_connections の推移](charts/EVT-20260718-host12-005.svg)

# イベントID( EVT-20260718-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→11→12→13→…→11→12→11→15
* 開始   : 2026-07-18 06:35:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.732, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host12-006 active_connections の推移](charts/EVT-20260718-host12-006.svg)

# イベントID( EVT-20260719-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→15→11→14→15
* 開始   : 2026-07-19 14:40:00 (UTC)
* 終了   : 2026-07-19 14:40:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 8→8→5→9→9
* 開始   : 2026-07-20 22:25:00 (UTC)
* 終了   : 2026-07-20 22:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260720-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→7→12→8→6
* 開始   : 2026-07-21 00:35:00 (UTC)
* 終了   : 2026-07-21 00:35:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→20→23→21→20
* 開始   : 2026-07-21 09:05:00 (UTC)
* 終了   : 2026-07-21 09:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→19→…→19→15→19→18
* 開始   : 2026-07-21 15:45:00 (UTC)
* 終了   : 2026-07-21 17:55:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260721-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260721-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host12-007 active_connections の推移](charts/EVT-20260721-host12-007.svg)

# イベントID( EVT-20260721-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→17→12→13→…→12→13→15→14
* 開始   : 2026-07-21 17:55:00 (UTC)
* 終了   : 2026-07-21 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→13→15→16→13→15→16→13→14
* 開始   : 2026-07-22 04:45:00 (UTC)
* 終了   : 2026-07-22 04:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 20→21→25→22→22
* 開始   : 2026-07-22 11:15:00 (UTC)
* 終了   : 2026-07-22 11:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→12→9→14→12
* 開始   : 2026-07-22 19:10:00 (UTC)
* 終了   : 2026-07-22 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6279(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host12-008 active_connections の推移](charts/EVT-20260722-host12-008.svg)

# イベントID( EVT-20260722-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→13→9→12→11
* 開始   : 2026-07-22 19:25:00 (UTC)
* 終了   : 2026-07-22 19:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→11→9
* 開始   : 2026-07-22 20:55:00 (UTC)
* 終了   : 2026-07-22 20:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→19→15→18→22
* 開始   : 2026-07-23 14:45:00 (UTC)
* 終了   : 2026-07-23 14:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-008 active_connections の推移](charts/EVT-20260723-host12-008.svg)

# イベントID( EVT-20260723-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→20→16→19→22
* 開始   : 2026-07-23 15:00:00 (UTC)
* 終了   : 2026-07-23 15:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260723-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→16→17
* 開始   : 2026-07-24 05:55:00 (UTC)
* 終了   : 2026-07-24 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→15→20→17→18
* 開始   : 2026-07-24 07:05:00 (UTC)
* 終了   : 2026-07-24 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→12→8→11→10
* 開始   : 2026-07-24 20:25:00 (UTC)
* 終了   : 2026-07-24 20:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→10→12
* 開始   : 2026-07-24 20:40:00 (UTC)
* 終了   : 2026-07-24 21:20:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 7→6→13→8→7
* 開始   : 2026-07-25 00:55:00 (UTC)
* 終了   : 2026-07-25 00:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.696倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.725σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→13→…→12→10→13→10
* 開始   : 2026-07-25 03:35:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.87, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.5 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260725-host12-003 active_connections の推移](charts/EVT-20260725-host12-003.svg)

# イベントID( EVT-20260725-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→12→14→13→…→12→11→13→12
* 開始   : 2026-07-25 05:15:00 (UTC)
* 終了   : 2026-07-25 17:50:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260725-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260725-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260725-host12-004 active_connections の推移](charts/EVT-20260725-host12-004.svg)

# イベントID( EVT-20260725-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→10→12→10→12
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:30:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260725-host12-006 active_connections の推移](charts/EVT-20260725-host12-006.svg)

# イベントID( EVT-20260725-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→9→10→9→…→11→9→10→11
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 19:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.992, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260725-host12-007 active_connections の推移](charts/EVT-20260725-host12-007.svg)

# イベントID( EVT-20260725-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→13→…→10→12→10→11
* 開始   : 2026-07-25 06:35:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.773, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260725-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→14→…→12→11→13→11
* 開始   : 2026-07-25 07:05:00 (UTC)
* 終了   : 2026-07-25 19:35:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.234, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260725-host12-009 active_connections の推移](charts/EVT-20260725-host12-009.svg)

# イベントID( EVT-20260725-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→6→7→10→6→7→10→8
* 開始   : 2026-07-25 20:15:00 (UTC)
* 終了   : 2026-07-25 20:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→10→13→9→10
* 開始   : 2026-07-26 04:05:00 (UTC)
* 終了   : 2026-07-26 04:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260726-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→10→16→11→…→15→16→11→12
* 開始   : 2026-07-26 06:10:00 (UTC)
* 終了   : 2026-07-26 06:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260726-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260726-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→15→…→14→15→14→13
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.74から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.236, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host12-009 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→13→…→14→13→11→12
* 開始   : 2026-07-27 03:55:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.98から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.953, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→10→15→9→11
* 開始   : 2026-07-28 03:40:00 (UTC)
* 終了   : 2026-07-28 03:40:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.538倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.667σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260728-host12-003 active_connections の推移](charts/EVT-20260728-host12-003.svg)

# イベントID( EVT-20260728-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→17→…→16→17→18→16
* 開始   : 2026-07-28 05:55:00 (UTC)
* 終了   : 2026-07-28 06:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260728-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260728-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260728-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→19→18→16→19→18→17
* 開始   : 2026-07-28 06:35:00 (UTC)
* 終了   : 2026-07-28 06:40:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→20→…→21→20→17→20
* 開始   : 2026-07-28 07:55:00 (UTC)
* 終了   : 2026-07-28 08:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→21→22→16→21→22→21
* 開始   : 2026-07-28 08:40:00 (UTC)
* 終了   : 2026-07-28 10:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260728-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 55 分
  - EVT-20260728-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 20 分
  - EVT-20260728-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260728-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260728-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→22→27→23→23
* 開始   : 2026-07-28 11:05:00 (UTC)
* 終了   : 2026-07-28 11:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.281倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host12-009 active_connections の推移](charts/EVT-20260728-host12-009.svg)

# イベントID( EVT-20260728-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→12→9→13→14
* 開始   : 2026-07-28 19:20:00 (UTC)
* 終了   : 2026-07-28 19:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.6506(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→18→16→19→…→19→14→20→18
* 開始   : 2026-07-29 16:05:00 (UTC)
* 終了   : 2026-07-29 16:15:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260729-host12-006 active_connections の推移](charts/EVT-20260729-host12-006.svg)

# イベントID( EVT-20260729-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→19→14→17→18
* 開始   : 2026-07-29 16:55:00 (UTC)
* 終了   : 2026-07-29 16:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→16→13→16→13→16→15→14
* 開始   : 2026-07-30 04:40:00 (UTC)
* 終了   : 2026-07-30 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-025 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-029 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260730-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→16→17
* 開始   : 2026-07-30 17:10:00 (UTC)
* 終了   : 2026-07-30 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→13→11→13→16
* 開始   : 2026-07-30 18:35:00 (UTC)
* 終了   : 2026-07-30 19:35:00 (UTC)
* 現象   : 平常時(15)に対し 0.7333(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260730-host12-009 active_connections の推移](charts/EVT-20260730-host12-009.svg)

# イベントID( EVT-20260730-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→15→10→13→10→13→14
* 開始   : 2026-07-30 18:50:00 (UTC)
* 終了   : 2026-07-30 19:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260730-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260730-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→13→16→13→16→13→15
* 開始   : 2026-07-31 04:10:00 (UTC)
* 終了   : 2026-07-31 05:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 1.0 時間
  - EVT-20260731-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260731-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→16→13→12
* 開始   : 2026-07-31 04:50:00 (UTC)
* 終了   : 2026-07-31 04:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→15→21→16→16
* 開始   : 2026-07-31 06:35:00 (UTC)
* 終了   : 2026-07-31 06:35:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.385倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host12-004 active_connections の推移](charts/EVT-20260731-host12-004.svg)

# イベントID( EVT-20260731-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 21→21→16→23→19
* 開始   : 2026-07-31 15:00:00 (UTC)
* 終了   : 2026-07-31 15:00:00 (UTC)
* 現象   : 平常時(21)に対し 0.7619(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.475σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→17→14→17→18
* 開始   : 2026-07-31 16:45:00 (UTC)
* 終了   : 2026-07-31 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→16→10→14→13
* 開始   : 2026-07-31 19:00:00 (UTC)
* 終了   : 2026-07-31 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→12→…→12→8→11→10
* 開始   : 2026-07-31 19:55:00 (UTC)
* 終了   : 2026-07-31 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-host02-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 6→11→10→4→11→10→4→9→8
* 開始   : 2026-07-31 22:40:00 (UTC)
* 終了   : 2026-07-31 22:50:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-073 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→11→14→11→14→11→14→11→12
* 開始   : 2026-07-01 04:05:00 (UTC)
* 終了   : 2026-07-01 04:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→20→20→20→22→22→20→20→22
* 開始   : 2026-07-01 08:35:00 (UTC)
* 終了   : 2026-07-01 09:45:00 (UTC)
* 現象   : 2026-07-01 09:45:00 (UTC)を境に水準が 14.84から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 23→22→22→23→20→25→22→24
* 開始   : 2026-07-01 11:10:00 (UTC)
* 終了   : 2026-07-01 11:45:00 (UTC)
* 現象   : 2026-07-01 11:45:00 (UTC)を境に水準が 14.97から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→23→23→23→22→23
* 開始   : 2026-07-01 12:40:00 (UTC)
* 終了   : 2026-07-01 13:05:00 (UTC)
* 現象   : 2026-07-01 13:05:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.075, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→6→…→12→6→9→7
* 開始   : 2026-07-01 22:45:00 (UTC)
* 終了   : 2026-07-01 22:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host09-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 7→9→5→9→5→9→5→10→9
* 開始   : 2026-07-02 00:20:00 (UTC)
* 終了   : 2026-07-02 00:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→20→19→18→16→20→20→18→22
* 開始   : 2026-07-02 07:25:00 (UTC)
* 終了   : 2026-07-02 08:35:00 (UTC)
* 現象   : 2026-07-02 08:35:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.607, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→19→21→20→…→20→22→18→20
* 開始   : 2026-07-02 08:30:00 (UTC)
* 終了   : 2026-07-02 08:40:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→19→22→20→22→20→22→18→21
* 開始   : 2026-07-02 08:50:00 (UTC)
* 終了   : 2026-07-02 09:00:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→24→21→24→21→23
* 開始   : 2026-07-02 10:30:00 (UTC)
* 終了   : 2026-07-02 10:35:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260702-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→24→23→24→23→21→23→23→22
* 開始   : 2026-07-02 11:25:00 (UTC)
* 終了   : 2026-07-02 12:50:00 (UTC)
* 現象   : 2026-07-02 12:50:00 (UTC)を境に水準が 14.99から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.729, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→12→11→14→16→12→11→14→15
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→13→11→16→13→11→16→13
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 18:55:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→13
* 開始   : 2026-07-02 21:45:00 (UTC)
* 終了   : 2026-07-02 22:40:00 (UTC)
* 現象   : 2026-07-02 22:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→12→11→9→11→12→11→6
* 開始   : 2026-07-03 02:25:00 (UTC)
* 終了   : 2026-07-03 02:30:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→20→18→20→…→20→21→18→19
* 開始   : 2026-07-03 07:30:00 (UTC)
* 終了   : 2026-07-03 07:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→19→21→22→22
* 開始   : 2026-07-03 08:05:00 (UTC)
* 終了   : 2026-07-03 08:25:00 (UTC)
* 現象   : 2026-07-03 08:25:00 (UTC)を境に水準が 15.04から14.29へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→20→21→17→21→17→21→19→20
* 開始   : 2026-07-03 08:10:00 (UTC)
* 終了   : 2026-07-03 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→19→22→21→23→19→22→25
* 開始   : 2026-07-03 08:55:00 (UTC)
* 終了   : 2026-07-03 09:45:00 (UTC)
* 現象   : 2026-07-03 09:45:00 (UTC)を境に水準が 14.96から14.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.018, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 24→23→21→23→23→23→23→24→23
* 開始   : 2026-07-03 11:25:00 (UTC)
* 終了   : 2026-07-03 12:50:00 (UTC)
* 現象   : 2026-07-03 12:50:00 (UTC)を境に水準が 14.94から13.24へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→18→19→16→18→19
* 開始   : 2026-07-03 16:30:00 (UTC)
* 終了   : 2026-07-03 16:35:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→12→14→13→12→14→16
* 開始   : 2026-07-03 18:00:00 (UTC)
* 終了   : 2026-07-03 18:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→13→11→14→12
* 開始   : 2026-07-03 19:00:00 (UTC)
* 終了   : 2026-07-03 19:05:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-013 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260703-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→10→11→10→…→11→9→11→10
* 開始   : 2026-07-03 19:35:00 (UTC)
* 終了   : 2026-07-03 20:00:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→10→11→12
* 開始   : 2026-07-03 19:50:00 (UTC)
* 終了   : 2026-07-03 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→8→10→6→9→9→10→9→10
* 開始   : 2026-07-04 00:50:00 (UTC)
* 終了   : 2026-07-04 02:00:00 (UTC)
* 現象   : 2026-07-04 02:00:00 (UTC)を境に水準が 14.94から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.752, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260704-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→8→13→9→8→13→9→10
* 開始   : 2026-07-04 04:00:00 (UTC)
* 終了   : 2026-07-04 04:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→10→13→10
* 開始   : 2026-07-05 04:00:00 (UTC)
* 終了   : 2026-07-05 04:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260705-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→10→12→10→12→14
* 開始   : 2026-07-05 16:55:00 (UTC)
* 終了   : 2026-07-05 17:05:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→9→12→8→12→8→12→9
* 開始   : 2026-07-07 03:00:00 (UTC)
* 終了   : 2026-07-07 03:10:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→10→14→10→14→13
* 開始   : 2026-07-07 04:30:00 (UTC)
* 終了   : 2026-07-07 04:40:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→20→14→17→18→20→14→17→18
* 開始   : 2026-07-07 07:50:00 (UTC)
* 終了   : 2026-07-07 07:55:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 23→21→24→23→21→24→23
* 開始   : 2026-07-07 11:05:00 (UTC)
* 終了   : 2026-07-07 11:10:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→20→25→26→…→25→26→21→23
* 開始   : 2026-07-07 13:10:00 (UTC)
* 終了   : 2026-07-07 13:15:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→19→18→19→19→17→19→19→19
* 開始   : 2026-07-07 16:20:00 (UTC)
* 終了   : 2026-07-07 18:25:00 (UTC)
* 現象   : 2026-07-07 18:25:00 (UTC)を境に水準が 14.86から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→16→15→16→15→18→16
* 開始   : 2026-07-07 16:35:00 (UTC)
* 終了   : 2026-07-07 16:45:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→16→12→11→…→12→11→14→12
* 開始   : 2026-07-07 18:30:00 (UTC)
* 終了   : 2026-07-07 18:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→15→11→10→…→11→10→13→11
* 開始   : 2026-07-07 19:25:00 (UTC)
* 終了   : 2026-07-07 19:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→10→13→10→13
* 開始   : 2026-07-07 19:40:00 (UTC)
* 終了   : 2026-07-07 19:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→8→11→8→11→8→11
* 開始   : 2026-07-07 20:50:00 (UTC)
* 終了   : 2026-07-07 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260707-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host12-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→10→11→9
* 開始   : 2026-07-07 22:15:00 (UTC)
* 終了   : 2026-07-07 22:40:00 (UTC)
* 現象   : 2026-07-07 22:40:00 (UTC)を境に水準が 14.91から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.101, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 8→9→11→11→11
* 開始   : 2026-07-08 01:30:00 (UTC)
* 終了   : 2026-07-08 01:50:00 (UTC)
* 現象   : 2026-07-08 01:50:00 (UTC)を境に水準が 14.95から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→15→19→15→19→16
* 開始   : 2026-07-08 07:00:00 (UTC)
* 終了   : 2026-07-08 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260708-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→20→19→21→20→21→23→23→23
* 開始   : 2026-07-08 08:20:00 (UTC)
* 終了   : 2026-07-08 09:10:00 (UTC)
* 現象   : 2026-07-08 09:10:00 (UTC)を境に水準が 15.08から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→22→19→19→19→22→23→21→22
* 開始   : 2026-07-08 08:50:00 (UTC)
* 終了   : 2026-07-08 09:50:00 (UTC)
* 現象   : 2026-07-08 09:50:00 (UTC)を境に水準が 15.08から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.385, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→19→23→17→…→23→17→21→19
* 開始   : 2026-07-08 09:25:00 (UTC)
* 終了   : 2026-07-08 09:30:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260708-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→24→25→24→25→22
* 開始   : 2026-07-08 11:00:00 (UTC)
* 終了   : 2026-07-08 11:10:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→20→21→21→19→20→20→20→20
* 開始   : 2026-07-08 15:00:00 (UTC)
* 終了   : 2026-07-08 16:00:00 (UTC)
* 現象   : 2026-07-08 16:00:00 (UTC)を境に水準が 14.94から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.582, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→14→…→14→12→15→14
* 開始   : 2026-07-08 18:00:00 (UTC)
* 終了   : 2026-07-08 18:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→12→11→15→12→11→15
* 開始   : 2026-07-08 18:45:00 (UTC)
* 終了   : 2026-07-08 18:50:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 7→4→11→8→7→4→11→8→10
* 開始   : 2026-07-09 01:10:00 (UTC)
* 終了   : 2026-07-09 01:15:00 (UTC)
* 現象   : 平常時(7.083)に対し 0.5647(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→10→10→14→11→12→12→11→12
* 開始   : 2026-07-09 03:05:00 (UTC)
* 終了   : 2026-07-09 03:45:00 (UTC)
* 現象   : 2026-07-09 03:45:00 (UTC)を境に水準が 15.03から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→16→18→16→18→17→15
* 開始   : 2026-07-09 06:10:00 (UTC)
* 終了   : 2026-07-09 06:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260709-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260709-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→16→14→18→…→18→13→16→15
* 開始   : 2026-07-09 17:25:00 (UTC)
* 終了   : 2026-07-09 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260709-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→13→11→14→13→12
* 開始   : 2026-07-10 04:25:00 (UTC)
* 終了   : 2026-07-10 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 23→21→21→22
* 開始   : 2026-07-10 14:55:00 (UTC)
* 終了   : 2026-07-10 15:10:00 (UTC)
* 現象   : 2026-07-10 15:10:00 (UTC)を境に水準が 14.93から12.59へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→12→16→…→14→11→12→14
* 開始   : 2026-07-10 18:30:00 (UTC)
* 終了   : 2026-07-10 18:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260710-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→10→9→10→…→10→8→10→11
* 開始   : 2026-07-10 20:20:00 (UTC)
* 終了   : 2026-07-10 20:30:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-080 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→5→8→12→5→8→12→8→7
* 開始   : 2026-07-10 22:20:00 (UTC)
* 終了   : 2026-07-10 22:30:00 (UTC)
* 現象   : 金曜22時台の平常値(8.529)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 2.858σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.223σ 外れた (平常値=8.529)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→16→13→16→13→17→16
* 開始   : 2026-07-12 14:00:00 (UTC)
* 終了   : 2026-07-12 14:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→10→13→16→10→12
* 開始   : 2026-07-12 17:15:00 (UTC)
* 終了   : 2026-07-12 17:20:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260712-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→14→13→12→12→12→14
* 開始   : 2026-07-12 18:10:00 (UTC)
* 終了   : 2026-07-12 18:40:00 (UTC)
* 現象   : 2026-07-12 18:40:00 (UTC)を境に水準が 11.75から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→10→11→11→9→10→10→9→12
* 開始   : 2026-07-12 21:00:00 (UTC)
* 終了   : 2026-07-12 21:45:00 (UTC)
* 現象   : 2026-07-12 21:45:00 (UTC)を境に水準が 11.75から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→14→13→11→14→13→12
* 開始   : 2026-07-14 03:55:00 (UTC)
* 終了   : 2026-07-14 04:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.412倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.852σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→17→19→20→17
* 開始   : 2026-07-14 07:30:00 (UTC)
* 終了   : 2026-07-14 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→20→22→20→22→20
* 開始   : 2026-07-14 08:55:00 (UTC)
* 終了   : 2026-07-14 09:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260714-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 23→22→22→22→21→20→22→22→24
* 開始   : 2026-07-14 09:30:00 (UTC)
* 終了   : 2026-07-14 10:25:00 (UTC)
* 現象   : 2026-07-14 10:25:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→16→14→17→14→17→14→15→16
* 開始   : 2026-07-14 17:30:00 (UTC)
* 終了   : 2026-07-14 17:40:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260714-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→13→15→15→13→14→14→14→15
* 開始   : 2026-07-14 18:35:00 (UTC)
* 終了   : 2026-07-14 19:20:00 (UTC)
* 現象   : 2026-07-14 19:20:00 (UTC)を境に水準が 14.98から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→12→9→9→9→10→7→10→10
* 開始   : 2026-07-14 21:05:00 (UTC)
* 終了   : 2026-07-14 23:25:00 (UTC)
* 現象   : 2026-07-14 23:25:00 (UTC)を境に水準が 14.8から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→10→11→9
* 開始   : 2026-07-14 22:40:00 (UTC)
* 終了   : 2026-07-14 22:55:00 (UTC)
* 現象   : 2026-07-14 22:55:00 (UTC)を境に水準が 14.83から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→10→11→11→13
* 開始   : 2026-07-15 02:15:00 (UTC)
* 終了   : 2026-07-15 02:45:00 (UTC)
* 現象   : 2026-07-15 02:45:00 (UTC)を境に水準が 14.97から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→17→15→17→16
* 開始   : 2026-07-15 05:55:00 (UTC)
* 終了   : 2026-07-15 06:05:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260715-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 25→24→23→22→22
* 開始   : 2026-07-15 11:15:00 (UTC)
* 終了   : 2026-07-15 11:35:00 (UTC)
* 現象   : 2026-07-15 11:35:00 (UTC)を境に水準が 14.97から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→22→18→23→18→23→18→21→22
* 開始   : 2026-07-15 13:30:00 (UTC)
* 終了   : 2026-07-15 13:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8213(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→14→17→14→17→14→17
* 開始   : 2026-07-15 17:05:00 (UTC)
* 終了   : 2026-07-15 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→15→13→15→17
* 開始   : 2026-07-15 17:45:00 (UTC)
* 終了   : 2026-07-15 17:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260715-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→15→13→15→13→15→14
* 開始   : 2026-07-15 18:15:00 (UTC)
* 終了   : 2026-07-15 18:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→10→…→10→6→8→10
* 開始   : 2026-07-15 21:45:00 (UTC)
* 終了   : 2026-07-15 21:55:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host12-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→7→9→8→10
* 開始   : 2026-07-15 23:00:00 (UTC)
* 終了   : 2026-07-15 23:30:00 (UTC)
* 現象   : 2026-07-15 23:30:00 (UTC)を境に水準が 14.85から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 7→10→12→13→11→10→12→13→11
* 開始   : 2026-07-16 03:30:00 (UTC)
* 終了   : 2026-07-16 03:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260716-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260716-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→18→…→25→18→23→21
* 開始   : 2026-07-16 11:50:00 (UTC)
* 終了   : 2026-07-16 11:55:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→13→…→13→10→14→10
* 開始   : 2026-07-16 18:35:00 (UTC)
* 終了   : 2026-07-16 19:15:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260716-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→14→19→15→14→19→15→18
* 開始   : 2026-07-17 06:50:00 (UTC)
* 終了   : 2026-07-17 06:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→20→18→20→18→20→18
* 開始   : 2026-07-17 07:25:00 (UTC)
* 終了   : 2026-07-17 07:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→23→21→19→23→21
* 開始   : 2026-07-17 09:40:00 (UTC)
* 終了   : 2026-07-17 09:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→16→…→17→16→18→21
* 開始   : 2026-07-17 16:00:00 (UTC)
* 終了   : 2026-07-17 16:05:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→11→12→11→14→13
* 開始   : 2026-07-17 18:50:00 (UTC)
* 終了   : 2026-07-17 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260717-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→12→10→12→10→11→10
* 開始   : 2026-07-17 19:00:00 (UTC)
* 終了   : 2026-07-17 19:10:00 (UTC)
* 現象   : 平常時(14)に対し 0.7143(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260717-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→11→9→10→…→10→8→11→12
* 開始   : 2026-07-17 20:20:00 (UTC)
* 終了   : 2026-07-17 20:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→11→5→7→8→11→5→7→8
* 開始   : 2026-07-19 00:30:00 (UTC)
* 終了   : 2026-07-19 00:35:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→12→7→13→10→12→7→13→10
* 開始   : 2026-07-19 04:35:00 (UTC)
* 終了   : 2026-07-19 04:40:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→16→13→19→…→13→19→18→16
* 開始   : 2026-07-19 11:40:00 (UTC)
* 終了   : 2026-07-19 11:45:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→19→15→13→19→15
* 開始   : 2026-07-19 14:05:00 (UTC)
* 終了   : 2026-07-19 14:10:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.281倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→14→16→17→17→16
* 開始   : 2026-07-19 14:05:00 (UTC)
* 終了   : 2026-07-19 14:40:00 (UTC)
* 現象   : 2026-07-19 14:40:00 (UTC)を境に水準が 11.89から14.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→10→11→10→12→14→12→11→13
* 開始   : 2026-07-19 18:05:00 (UTC)
* 終了   : 2026-07-19 20:05:00 (UTC)
* 現象   : 2026-07-19 20:05:00 (UTC)を境に水準が 11.77から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.526, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→6→9→6→9→6→9→10
* 開始   : 2026-07-19 23:10:00 (UTC)
* 終了   : 2026-07-19 23:20:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→10→9→8→8→11→6→11→11
* 開始   : 2026-07-20 01:15:00 (UTC)
* 終了   : 2026-07-20 01:55:00 (UTC)
* 現象   : 2026-07-20 01:55:00 (UTC)を境に水準が 11.85から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.364, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→11→10
* 開始   : 2026-07-20 02:00:00 (UTC)
* 終了   : 2026-07-20 02:15:00 (UTC)
* 現象   : 2026-07-20 02:15:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→15→21→19→…→19→21→19→20
* 開始   : 2026-07-21 08:10:00 (UTC)
* 終了   : 2026-07-21 08:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260721-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 23→21→21→21→21→23→21→23→22
* 開始   : 2026-07-21 09:55:00 (UTC)
* 終了   : 2026-07-21 10:40:00 (UTC)
* 現象   : 2026-07-21 10:40:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→21→…→21→18→22→24
* 開始   : 2026-07-21 13:55:00 (UTC)
* 終了   : 2026-07-21 14:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→14→10→13→10→13→10→11
* 開始   : 2026-07-21 19:50:00 (UTC)
* 終了   : 2026-07-21 20:00:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→8→9→10→11→10→8→10→12
* 開始   : 2026-07-22 00:00:00 (UTC)
* 終了   : 2026-07-22 01:35:00 (UTC)
* 現象   : 2026-07-22 01:35:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.583, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→15→13→15→12
* 開始   : 2026-07-22 04:55:00 (UTC)
* 終了   : 2026-07-22 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260722-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→18→16→18→16
* 開始   : 2026-07-22 06:40:00 (UTC)
* 終了   : 2026-07-22 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→23→20→21→23→20
* 開始   : 2026-07-22 09:50:00 (UTC)
* 終了   : 2026-07-22 09:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260722-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 24→23→24→24
* 開始   : 2026-07-22 11:35:00 (UTC)
* 終了   : 2026-07-22 12:15:00 (UTC)
* 現象   : 2026-07-22 12:15:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→5→7→11→5→7→11→8
* 開始   : 2026-07-22 23:40:00 (UTC)
* 終了   : 2026-07-22 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-019 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 6→8→11→10→11→10→11→10→8
* 開始   : 2026-07-23 01:10:00 (UTC)
* 終了   : 2026-07-23 01:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 7→8→5→11→…→5→11→9→10
* 開始   : 2026-07-23 02:00:00 (UTC)
* 終了   : 2026-07-23 02:05:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→10→14→12→…→12→15→12→13
* 開始   : 2026-07-23 04:15:00 (UTC)
* 終了   : 2026-07-23 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260723-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→15→18→16→15→18→16
* 開始   : 2026-07-23 06:25:00 (UTC)
* 終了   : 2026-07-23 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 20→19→22→21→21→22→21→22→21
* 開始   : 2026-07-23 08:40:00 (UTC)
* 終了   : 2026-07-23 09:25:00 (UTC)
* 現象   : 2026-07-23 09:25:00 (UTC)を境に水準が 14.85から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→22→20→23→22→20→23→20
* 開始   : 2026-07-23 08:55:00 (UTC)
* 終了   : 2026-07-23 09:05:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→21→18→24→…→22→25→19→20
* 開始   : 2026-07-23 13:20:00 (UTC)
* 終了   : 2026-07-23 13:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260723-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→16→17→14→16
* 開始   : 2026-07-23 17:25:00 (UTC)
* 終了   : 2026-07-23 17:30:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260723-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→16→14→17→15→16→16
* 開始   : 2026-07-23 17:25:00 (UTC)
* 終了   : 2026-07-23 18:05:00 (UTC)
* 現象   : 2026-07-23 18:05:00 (UTC)を境に水準が 14.95から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→9→8→11→…→8→11→14→11
* 開始   : 2026-07-23 20:40:00 (UTC)
* 終了   : 2026-07-23 20:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260723-lsfhost01-072 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-073 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260723-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→9→11→9→10→11→12
* 開始   : 2026-07-24 01:35:00 (UTC)
* 終了   : 2026-07-24 02:25:00 (UTC)
* 現象   : 2026-07-24 02:25:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→11→14→11→14→11
* 開始   : 2026-07-24 03:40:00 (UTC)
* 終了   : 2026-07-24 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.436倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.96σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260724-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→23→22→21
* 開始   : 2026-07-24 14:10:00 (UTC)
* 終了   : 2026-07-24 14:25:00 (UTC)
* 現象   : 2026-07-24 14:25:00 (UTC)を境に水準が 14.92から12.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 21→21→20→21→19→22→20→20→22
* 開始   : 2026-07-24 14:30:00 (UTC)
* 終了   : 2026-07-24 15:20:00 (UTC)
* 現象   : 2026-07-24 15:20:00 (UTC)を境に水準が 14.96から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.445, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→17→15→17→15→17→15→16
* 開始   : 2026-07-24 16:50:00 (UTC)
* 終了   : 2026-07-24 17:00:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→13→12→15→12→15→12→13
* 開始   : 2026-07-24 18:20:00 (UTC)
* 終了   : 2026-07-24 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260724-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→14→13→12→14→13
* 開始   : 2026-07-24 18:45:00 (UTC)
* 終了   : 2026-07-24 18:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→8→11→7→…→7→5→8→10
* 開始   : 2026-07-24 23:00:00 (UTC)
* 終了   : 2026-07-24 23:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→6→5→9→…→9→12→8→11
* 開始   : 2026-07-25 01:45:00 (UTC)
* 終了   : 2026-07-25 01:55:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→13→11→13→15
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 05:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 25 分
  - EVT-20260725-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260725-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→9→7→10→…→8→10→8→10
* 開始   : 2026-07-25 20:00:00 (UTC)
* 終了   : 2026-07-25 20:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.043, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260725-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→7→6→12→8→7→6→12→8
* 開始   : 2026-07-25 21:25:00 (UTC)
* 終了   : 2026-07-25 21:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→11→12→10→11→12→10→8
* 開始   : 2026-07-26 03:25:00 (UTC)
* 終了   : 2026-07-26 03:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→12→13→10→12
* 開始   : 2026-07-26 04:30:00 (UTC)
* 終了   : 2026-07-26 04:35:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260726-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→7→7→8→7→10→10→9→9
* 開始   : 2026-07-27 00:20:00 (UTC)
* 終了   : 2026-07-27 01:25:00 (UTC)
* 現象   : 2026-07-27 01:25:00 (UTC)を境に水準が 11.72から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.755, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→7→9→10→7→10→9
* 開始   : 2026-07-27 00:30:00 (UTC)
* 終了   : 2026-07-27 01:10:00 (UTC)
* 現象   : 2026-07-27 01:10:00 (UTC)を境に水準が 11.82から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→9→9→10→9→10→11→10
* 開始   : 2026-07-27 21:25:00 (UTC)
* 終了   : 2026-07-27 22:00:00 (UTC)
* 現象   : 2026-07-27 22:00:00 (UTC)を境に水準が 14.87から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→13→10→12→13→10→9
* 開始   : 2026-07-28 02:45:00 (UTC)
* 終了   : 2026-07-28 02:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→12→13→…→12→13→10→12
* 開始   : 2026-07-28 02:50:00 (UTC)
* 終了   : 2026-07-28 02:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→13→14→13→14→13→9
* 開始   : 2026-07-28 04:30:00 (UTC)
* 終了   : 2026-07-28 04:35:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260728-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→13→15→12→13
* 開始   : 2026-07-28 18:40:00 (UTC)
* 終了   : 2026-07-28 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→15→…→14→15→12→13
* 開始   : 2026-07-29 04:15:00 (UTC)
* 終了   : 2026-07-29 04:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→14→14→16→14→15→15→16
* 開始   : 2026-07-29 05:10:00 (UTC)
* 終了   : 2026-07-29 05:45:00 (UTC)
* 現象   : 2026-07-29 05:45:00 (UTC)を境に水準が 14.95から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→19→17→20→17→19→17→17→18
* 開始   : 2026-07-29 06:50:00 (UTC)
* 終了   : 2026-07-29 07:30:00 (UTC)
* 現象   : 2026-07-29 07:30:00 (UTC)を境に水準が 14.87から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→19→23→21→23→21→23→22→21
* 開始   : 2026-07-29 09:40:00 (UTC)
* 終了   : 2026-07-29 09:50:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→15→16→12→15→13
* 開始   : 2026-07-29 18:05:00 (UTC)
* 終了   : 2026-07-29 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→11→…→10→11→15→12
* 開始   : 2026-07-29 18:50:00 (UTC)
* 終了   : 2026-07-29 18:55:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7059(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→13→9→13→9→13→9→11
* 開始   : 2026-07-29 20:00:00 (UTC)
* 終了   : 2026-07-29 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→11→10→10→10→9→11
* 開始   : 2026-07-30 01:35:00 (UTC)
* 終了   : 2026-07-30 02:05:00 (UTC)
* 現象   : 2026-07-30 02:05:00 (UTC)を境に水準が 15.03から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→17→20→21→…→20→21→19→20
* 開始   : 2026-07-30 07:55:00 (UTC)
* 終了   : 2026-07-30 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→22→21→21
* 開始   : 2026-07-30 09:00:00 (UTC)
* 終了   : 2026-07-30 09:25:00 (UTC)
* 現象   : 2026-07-30 09:25:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.101, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→19→18→22→…→22→17→19→20
* 開始   : 2026-07-30 15:00:00 (UTC)
* 終了   : 2026-07-30 15:10:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→18→19→16→18→17
* 開始   : 2026-07-30 16:20:00 (UTC)
* 終了   : 2026-07-30 16:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→17→…→17→14→16→14
* 開始   : 2026-07-30 17:00:00 (UTC)
* 終了   : 2026-07-30 17:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260730-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→12→14→8→12→14→8→12→10
* 開始   : 2026-07-31 04:05:00 (UTC)
* 終了   : 2026-07-31 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→20→17→16→…→17→16→18→21
* 開始   : 2026-07-31 15:15:00 (UTC)
* 終了   : 2026-07-31 15:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→15→12→15→12→13
* 開始   : 2026-07-31 18:45:00 (UTC)
* 終了   : 2026-07-31 18:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→11→12→9→11→10
* 開始   : 2026-07-31 20:20:00 (UTC)
* 終了   : 2026-07-31 20:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host08-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host12-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→8→9→9→8→9→10→11
* 開始   : 2026-07-31 21:40:00 (UTC)
* 終了   : 2026-07-31 23:20:00 (UTC)
* 現象   : 2026-07-31 23:20:00 (UTC)を境に水準が 15.07から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host12-012 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
