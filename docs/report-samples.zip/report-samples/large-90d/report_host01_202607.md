# host01 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host01 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 329 (SEVERE: 20, FATAL: 139, WARN: 170, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 18 | 118 | 143 | 279 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |
| eu | 2 | 21 | 27 | 50 | ALG-A1, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→17→20→18→…→14→15→12→13
* 開始   : 2026-07-06 01:35:00 (UTC)
* 終了   : 2026-07-06 19:30:00 (UTC)
* 現象   : 2026-07-06 19:30:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.251, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-003 active_connections の推移](charts/EVT-20260706-host01-003.svg)

# イベントID( EVT-20260706-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→15→…→14→12→11→14
* 開始   : 2026-07-06 03:40:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.994, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-006 active_connections の推移](charts/EVT-20260706-host01-006.svg)

# イベントID( EVT-20260706-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→15→…→14→13→11→13
* 開始   : 2026-07-06 03:45:00 (UTC)
* 終了   : 2026-07-06 20:40:00 (UTC)
* 現象   : 2026-07-06 20:40:00 (UTC)を境に水準が 11.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.165, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-007 active_connections の推移](charts/EVT-20260706-host01-007.svg)

# イベントID( EVT-20260706-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→18→16→…→13→14→13→14
* 開始   : 2026-07-06 04:00:00 (UTC)
* 終了   : 2026-07-06 19:20:00 (UTC)
* 現象   : 2026-07-06 19:20:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.501, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.004, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-008 active_connections の推移](charts/EVT-20260706-host01-008.svg)

# イベントID( EVT-20260713-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→16→18→15→…→14→13→11→15
* 開始   : 2026-07-13 01:40:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.85から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.89, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-001 active_connections の推移](charts/EVT-20260713-host01-001.svg)

# イベントID( EVT-20260713-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.29→49.42→54.44→48.98→…→42.85→44.14→37.86→37.01
* 開始   : 2026-07-13 02:00:00 (UTC)
* 終了   : 2026-07-13 21:00:00 (UTC)
* 現象   : 2026-07-13 21:00:00 (UTC)を境に水準が 40.92から50.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.007σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.749, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-002 eu の推移](charts/EVT-20260713-host01-002.svg)

# イベントID( EVT-20260713-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→12→16→12→…→11→14→12→9
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 21:00:00 (UTC)
* 現象   : 2026-07-13 21:00:00 (UTC)を境に水準が 11.87から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.654, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.894, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-003 active_connections の推移](charts/EVT-20260713-host01-003.svg)

# イベントID( EVT-20260713-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→16→14→15→…→14→13→12→14
* 開始   : 2026-07-13 03:35:00 (UTC)
* 終了   : 2026-07-13 18:50:00 (UTC)
* 現象   : 2026-07-13 18:50:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.847, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-005 active_connections の推移](charts/EVT-20260713-host01-005.svg)

# イベントID( EVT-20260713-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→15→16→15→…→11→12→13→11
* 開始   : 2026-07-13 03:35:00 (UTC)
* 終了   : 2026-07-13 21:15:00 (UTC)
* 現象   : 2026-07-13 21:15:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.55σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.905, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-006 active_connections の推移](charts/EVT-20260713-host01-006.svg)

# イベントID( EVT-20260713-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→13→14→…→13→12→15→12
* 開始   : 2026-07-13 03:40:00 (UTC)
* 終了   : 2026-07-13 22:15:00 (UTC)
* 現象   : 2026-07-13 22:15:00 (UTC)を境に水準が 11.74から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.713, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-007 active_connections の推移](charts/EVT-20260713-host01-007.svg)

# イベントID( EVT-20260720-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→17→16→17→…→13→14→13→15
* 開始   : 2026-07-20 01:20:00 (UTC)
* 終了   : 2026-07-20 20:05:00 (UTC)
* 現象   : 2026-07-20 20:05:00 (UTC)を境に水準が 11.78から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.895, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-002 active_connections の推移](charts/EVT-20260720-host01-002.svg)

# イベントID( EVT-20260720-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.01→49.99→49.01→44.55→…→46.05→44.05→40.84→48.01
* 開始   : 2026-07-20 02:45:00 (UTC)
* 終了   : 2026-07-20 21:05:00 (UTC)
* 現象   : 2026-07-20 21:05:00 (UTC)を境に水準が 40.87から50へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.415σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.798, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=29.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-003 eu の推移](charts/EVT-20260720-host01-003.svg)

# イベントID( EVT-20260720-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→14→…→15→14→12→11
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 21:05:00 (UTC)
* 現象   : 2026-07-20 21:05:00 (UTC)を境に水準が 11.75から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.793, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.991, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-004 active_connections の推移](charts/EVT-20260720-host01-004.svg)

# イベントID( EVT-20260720-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→16→13→15→…→14→11→15→13
* 開始   : 2026-07-20 03:10:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 2026-07-20 20:40:00 (UTC)を境に水準が 11.84から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.718, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.596, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-005 active_connections の推移](charts/EVT-20260720-host01-005.svg)

# イベントID( EVT-20260720-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→16→20→18→…→12→13→11→13
* 開始   : 2026-07-20 03:35:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.125, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-006 active_connections の推移](charts/EVT-20260720-host01-006.svg)

# イベントID( EVT-20260720-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→16→…→13→14→12→13
* 開始   : 2026-07-20 03:45:00 (UTC)
* 終了   : 2026-07-20 22:05:00 (UTC)
* 現象   : 2026-07-20 22:05:00 (UTC)を境に水準が 11.86から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.864, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-007 active_connections の推移](charts/EVT-20260720-host01-007.svg)

# イベントID( EVT-20260727-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→16→15→14→…→11→13→11→10
* 開始   : 2026-07-27 02:30:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.89から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.864, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-002 active_connections の推移](charts/EVT-20260727-host01-002.svg)

# イベントID( EVT-20260727-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→15→…→12→14→12→13
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.84から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.963, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.565, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-003 active_connections の推移](charts/EVT-20260727-host01-003.svg)

# イベントID( EVT-20260727-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→13→…→11→13→11→12
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 21:50:00 (UTC)
* 現象   : 2026-07-27 21:50:00 (UTC)を境に水準が 11.84から15.23へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.75, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.753, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-006 active_connections の推移](charts/EVT-20260727-host01-006.svg)

# イベントID( EVT-20260727-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→14→…→14→13→12→13
* 開始   : 2026-07-27 04:00:00 (UTC)
* 終了   : 2026-07-27 20:50:00 (UTC)
* 現象   : 2026-07-27 20:50:00 (UTC)を境に水準が 11.94から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.901, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-008 active_connections の推移](charts/EVT-20260727-host01-008.svg)

# イベントID( EVT-20260701-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→13→13
* 開始   : 2026-07-01 04:45:00 (UTC)
* 終了   : 2026-07-01 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→19→23→18→17
* 開始   : 2026-07-01 07:35:00 (UTC)
* 終了   : 2026-07-01 07:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.34倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-005 active_connections の推移](charts/EVT-20260701-host01-005.svg)

# イベントID( EVT-20260701-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→18→14→19→18
* 開始   : 2026-07-01 16:45:00 (UTC)
* 終了   : 2026-07-01 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.8→35.46→48.6→43.59→…→43.59→46.48→42.07→42.73
* 開始   : 2026-07-02 03:40:00 (UTC)
* 終了   : 2026-07-02 03:50:00 (UTC)
* 現象   : 平常時(36.56)に対し 1.33倍(48.6)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→17→19→16→…→20→18→20→17
* 開始   : 2026-07-02 06:35:00 (UTC)
* 終了   : 2026-07-02 06:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.46→49.8→42.66→52.19→52.64
* 開始   : 2026-07-02 17:30:00 (UTC)
* 終了   : 2026-07-02 17:30:00 (UTC)
* 現象   : 平常時(54.82)に対し 0.7782(42.66)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.35→48.41→32.69→40.62→40.21
* 開始   : 2026-07-02 19:20:00 (UTC)
* 終了   : 2026-07-02 19:20:00 (UTC)
* 現象   : 平常時(46.36)に対し 0.7052(32.69)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.777σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host01-009 eu の推移](charts/EVT-20260702-host01-009.svg)

# イベントID( EVT-20260702-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→8→…→10→8→12→11
* 開始   : 2026-07-02 19:40:00 (UTC)
* 終了   : 2026-07-02 19:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-019 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→10→15→12→10
* 開始   : 2026-07-03 03:40:00 (UTC)
* 終了   : 2026-07-03 03:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.513倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→16→18→17→…→17→19→17→16
* 開始   : 2026-07-03 06:20:00 (UTC)
* 終了   : 2026-07-03 06:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→18→22→19→17
* 開始   : 2026-07-03 08:05:00 (UTC)
* 終了   : 2026-07-03 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 61.04→61.18→56.44→65.62→…→65.62→51.04→64.94→61.43
* 開始   : 2026-07-03 15:40:00 (UTC)
* 終了   : 2026-07-03 15:50:00 (UTC)
* 現象   : 平常時(64.25)に対し 0.8784(56.44)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→19→14→17→17
* 開始   : 2026-07-03 16:45:00 (UTC)
* 終了   : 2026-07-03 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.66→45.14→37.62→49.38→45.59
* 開始   : 2026-07-03 18:50:00 (UTC)
* 終了   : 2026-07-03 19:15:00 (UTC)
* 現象   : 平常時(49.95)に対し 0.7531(37.62)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.408σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260703-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→9→6→9→8
* 開始   : 2026-07-03 21:35:00 (UTC)
* 終了   : 2026-07-03 21:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→14→10→11→…→7→9→12→9
* 開始   : 2026-07-04 04:40:00 (UTC)
* 終了   : 2026-07-04 20:10:00 (UTC)
* 現象   : 15.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.737, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260704-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.9 時間

![EVT-20260704-host01-003 active_connections の推移](charts/EVT-20260704-host01-003.svg)

# イベントID( EVT-20260704-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→14→13→12→…→12→11→12→13
* 開始   : 2026-07-04 05:05:00 (UTC)
* 終了   : 2026-07-04 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.158, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host01-004 active_connections の推移](charts/EVT-20260704-host01-004.svg)

# イベントID( EVT-20260704-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→12→14→12→…→9→11→12→10
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.773, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host01-005 active_connections の推移](charts/EVT-20260704-host01-005.svg)

# イベントID( EVT-20260704-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→9→…→12→10→12→11
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260704-host01-006 active_connections の推移](charts/EVT-20260704-host01-006.svg)

# イベントID( EVT-20260704-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→9→…→8→9→8→11
* 開始   : 2026-07-04 05:50:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.723, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host01-007 active_connections の推移](charts/EVT-20260704-host01-007.svg)

# イベントID( EVT-20260704-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.29→44.27→43.37→42.48→…→39.02→40.56→40.9→40.4
* 開始   : 2026-07-04 05:55:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-8.723, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host01-008 eu の推移](charts/EVT-20260704-host01-008.svg)

# イベントID( EVT-20260704-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→13→12→11→…→12→15→17→13
* 開始   : 2026-07-04 06:20:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.246, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-008 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260704-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→14→20→14→14
* 開始   : 2026-07-05 10:55:00 (UTC)
* 終了   : 2026-07-05 10:55:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→13→8→11→…→11→9→10→12
* 開始   : 2026-07-05 17:40:00 (UTC)
* 終了   : 2026-07-05 17:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260705-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→8→10
* 開始   : 2026-07-05 20:40:00 (UTC)
* 終了   : 2026-07-05 20:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.417σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 8→9→4→11→10
* 開始   : 2026-07-05 22:15:00 (UTC)
* 終了   : 2026-07-05 22:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 6→9→12→9→7
* 開始   : 2026-07-06 00:10:00 (UTC)
* 終了   : 2026-07-06 00:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260706-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.81→49.36→53.25→47.23→…→46.36→43.38→41.7→42.26
* 開始   : 2026-07-06 01:05:00 (UTC)
* 終了   : 2026-07-06 20:25:00 (UTC)
* 現象   : 2026-07-06 20:25:00 (UTC)を境に水準が 40.8から49.77へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.706, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-002 eu の推移](charts/EVT-20260706-host01-002.svg)

# イベントID( EVT-20260706-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→16→…→9→12→9→13
* 開始   : 2026-07-06 02:30:00 (UTC)
* 終了   : 2026-07-06 21:00:00 (UTC)
* 現象   : 2026-07-06 21:00:00 (UTC)を境に水準が 11.77から15.13へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.222, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→17→…→13→15→11→12
* 開始   : 2026-07-06 02:35:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 11.82から15.1へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.116, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 29.67→27.36→39.76→27.56→34.56
* 開始   : 2026-07-07 00:10:00 (UTC)
* 終了   : 2026-07-07 00:10:00 (UTC)
* 現象   : 平常時(28.56)に対し 1.392倍(39.76)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260707-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→14→15
* 開始   : 2026-07-07 05:15:00 (UTC)
* 終了   : 2026-07-07 05:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.301σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→18→19
* 開始   : 2026-07-07 07:35:00 (UTC)
* 終了   : 2026-07-07 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→19→17→20→…→23→15→20→19
* 開始   : 2026-07-07 15:25:00 (UTC)
* 終了   : 2026-07-07 15:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260707-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host01-008 active_connections の推移](charts/EVT-20260707-host01-008.svg)

# イベントID( EVT-20260707-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→16→15
* 開始   : 2026-07-07 17:30:00 (UTC)
* 終了   : 2026-07-07 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→14→10→14→13
* 開始   : 2026-07-07 18:50:00 (UTC)
* 終了   : 2026-07-07 18:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→13→12→10→9→13→12→10
* 開始   : 2026-07-08 02:55:00 (UTC)
* 終了   : 2026-07-08 03:00:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→10→13→12→…→12→15→10→13
* 開始   : 2026-07-08 03:50:00 (UTC)
* 終了   : 2026-07-08 04:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260708-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→17→19→18→17→19→18
* 開始   : 2026-07-08 07:00:00 (UTC)
* 終了   : 2026-07-08 07:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-006 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 50 分
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→8→7→11→8→7→11→8
* 開始   : 2026-07-08 20:05:00 (UTC)
* 終了   : 2026-07-08 20:45:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.301σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→8→7→11→10→8→7→11
* 開始   : 2026-07-08 20:25:00 (UTC)
* 終了   : 2026-07-08 20:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host01-016 active_connections の推移](charts/EVT-20260708-host01-016.svg)

# イベントID( EVT-20260709-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.4→49.98→59.05→55.37→48.47
* 開始   : 2026-07-09 06:15:00 (UTC)
* 終了   : 2026-07-09 06:15:00 (UTC)
* 現象   : 平常時(47.93)に対し 1.232倍(59.05)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→13→19→16→14
* 開始   : 2026-07-09 06:20:00 (UTC)
* 終了   : 2026-07-09 06:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→19→23→17→21
* 開始   : 2026-07-09 08:25:00 (UTC)
* 終了   : 2026-07-09 08:25:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→17→17
* 開始   : 2026-07-09 17:25:00 (UTC)
* 終了   : 2026-07-09 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→17→12→13→15→17→12→13→15
* 開始   : 2026-07-09 17:30:00 (UTC)
* 終了   : 2026-07-09 17:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→9→5→11→12
* 開始   : 2026-07-09 22:00:00 (UTC)
* 終了   : 2026-07-09 22:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260709-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→10→13→9→10
* 開始   : 2026-07-10 02:25:00 (UTC)
* 終了   : 2026-07-10 02:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→13→11
* 開始   : 2026-07-10 20:30:00 (UTC)
* 終了   : 2026-07-10 20:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→13→9→11→…→11→15→14→15
* 開始   : 2026-07-11 05:00:00 (UTC)
* 終了   : 2026-07-11 19:35:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.38σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 14.5 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260711-host01-002 active_connections の推移](charts/EVT-20260711-host01-002.svg)

# イベントID( EVT-20260711-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 39.61→44.66→46.85→43.68→…→45.9→46.52→47.7→45.26
* 開始   : 2026-07-11 05:05:00 (UTC)
* 終了   : 2026-07-11 19:55:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.789, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260711-host01-003 eu の推移](charts/EVT-20260711-host01-003.svg)

# イベントID( EVT-20260711-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→11→12→…→12→13→14→13
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.831, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host01-004 active_connections の推移](charts/EVT-20260711-host01-004.svg)

# イベントID( EVT-20260711-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→12→11→12→…→11→13→14→10
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.788, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260711-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→12→11→12→…→13→15→16→13
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.888, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260711-host01-006 active_connections の推移](charts/EVT-20260711-host01-006.svg)

# イベントID( EVT-20260711-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→11→13→11→…→14→11→13→12
* 開始   : 2026-07-11 05:50:00 (UTC)
* 終了   : 2026-07-11 19:25:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.757, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host01-007 active_connections の推移](charts/EVT-20260711-host01-007.svg)

# イベントID( EVT-20260711-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→15→…→11→15→12→13
* 開始   : 2026-07-11 06:35:00 (UTC)
* 終了   : 2026-07-11 18:55:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.973, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260711-host01-008 active_connections の推移](charts/EVT-20260711-host01-008.svg)

# イベントID( EVT-20260712-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→10→15→11→10
* 開始   : 2026-07-12 05:35:00 (UTC)
* 終了   : 2026-07-12 05:35:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.08→50.66→56.6→48.08→51.23
* 開始   : 2026-07-12 09:15:00 (UTC)
* 終了   : 2026-07-12 09:15:00 (UTC)
* 現象   : 平常時(45.59)に対し 1.241倍(56.6)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→14→11
* 開始   : 2026-07-12 17:50:00 (UTC)
* 終了   : 2026-07-12 17:50:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→12→7→12→11
* 開始   : 2026-07-12 19:10:00 (UTC)
* 終了   : 2026-07-12 19:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→12→17→16→…→17→16→15→14
* 開始   : 2026-07-13 03:05:00 (UTC)
* 終了   : 2026-07-13 21:05:00 (UTC)
* 現象   : 2026-07-13 21:05:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.227, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→9→11
* 開始   : 2026-07-14 00:55:00 (UTC)
* 終了   : 2026-07-14 01:05:00 (UTC)
* 現象   : 2026-07-14 01:05:00 (UTC)を境に水準が 14.89から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→16→15
* 開始   : 2026-07-14 17:30:00 (UTC)
* 終了   : 2026-07-14 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→10→15→11→12
* 開始   : 2026-07-15 04:10:00 (UTC)
* 終了   : 2026-07-15 04:10:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→18→22→18→20
* 開始   : 2026-07-15 07:25:00 (UTC)
* 終了   : 2026-07-15 07:25:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.32倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host01-003 active_connections の推移](charts/EVT-20260715-host01-003.svg)

# イベントID( EVT-20260715-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 24→22→25→22→18→25→22→18→22
* 開始   : 2026-07-15 11:25:00 (UTC)
* 終了   : 2026-07-15 11:35:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→14→…→14→13→14→17
* 開始   : 2026-07-15 17:15:00 (UTC)
* 終了   : 2026-07-15 17:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host01-006 active_connections の推移](charts/EVT-20260715-host01-006.svg)

# イベントID( EVT-20260715-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 54.8→57→44.08→50.42→53.32
* 開始   : 2026-07-15 17:30:00 (UTC)
* 終了   : 2026-07-15 17:30:00 (UTC)
* 現象   : 平常時(56.35)に対し 0.7822(44.08)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→11→8→12→13
* 開始   : 2026-07-15 20:00:00 (UTC)
* 終了   : 2026-07-15 20:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→7→11→13→…→11→13→9→11
* 開始   : 2026-07-16 01:40:00 (UTC)
* 終了   : 2026-07-16 01:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→15→14→…→15→14→10→12
* 開始   : 2026-07-16 04:05:00 (UTC)
* 終了   : 2026-07-16 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→19→…→20→19→17→15
* 開始   : 2026-07-16 06:30:00 (UTC)
* 終了   : 2026-07-16 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host01-006 active_connections の推移](charts/EVT-20260716-host01-006.svg)

# イベントID( EVT-20260716-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→16→20→15→15
* 開始   : 2026-07-16 06:55:00 (UTC)
* 終了   : 2026-07-16 06:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 22→21→26→21→22
* 開始   : 2026-07-16 11:25:00 (UTC)
* 終了   : 2026-07-16 11:25:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260716-host01-012 active_connections の推移](charts/EVT-20260716-host01-012.svg)

# イベントID( EVT-20260716-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→22→17→21→20
* 開始   : 2026-07-16 13:25:00 (UTC)
* 終了   : 2026-07-16 13:25:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260716-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→9→14→12→11
* 開始   : 2026-07-17 02:45:00 (UTC)
* 終了   : 2026-07-17 02:45:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→16→14→17→19
* 開始   : 2026-07-17 16:45:00 (UTC)
* 終了   : 2026-07-17 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260717-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260717-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.28→58.5→46.98→46.47→…→46.47→42.06→54.78→46.67
* 開始   : 2026-07-17 17:40:00 (UTC)
* 終了   : 2026-07-17 18:10:00 (UTC)
* 現象   : 平常時(54.46)に対し 0.8626(46.98)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.068σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260717-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→11→…→14→12→13→14
* 開始   : 2026-07-18 04:55:00 (UTC)
* 終了   : 2026-07-18 18:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host01-001 active_connections の推移](charts/EVT-20260718-host01-001.svg)

# イベントID( EVT-20260718-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→14→12→13→14
* 開始   : 2026-07-18 04:55:00 (UTC)
* 終了   : 2026-07-18 17:50:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.854, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260718-host01-002 active_connections の推移](charts/EVT-20260718-host01-002.svg)

# イベントID( EVT-20260718-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→10→…→10→12→14→12
* 開始   : 2026-07-18 05:00:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host01-003 active_connections の推移](charts/EVT-20260718-host01-003.svg)

# イベントID( EVT-20260718-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→13→…→10→11→10→11
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.169, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host01-004 active_connections の推移](charts/EVT-20260718-host01-004.svg)

# イベントID( EVT-20260718-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 40.12→35.55→38.95→41.75→…→43.04→45.67→44.67→42.2
* 開始   : 2026-07-18 05:35:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.473, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260718-host01-005 eu の推移](charts/EVT-20260718-host01-005.svg)

# イベントID( EVT-20260718-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→15→…→12→13→12→13
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 18:25:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.265, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260718-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→14→…→11→10→11→10
* 開始   : 2026-07-18 05:55:00 (UTC)
* 終了   : 2026-07-18 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.206, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260718-host01-007 active_connections の推移](charts/EVT-20260718-host01-007.svg)

# イベントID( EVT-20260719-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→16→11→15→16
* 開始   : 2026-07-19 14:00:00 (UTC)
* 終了   : 2026-07-19 14:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6839(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host01-003 active_connections の推移](charts/EVT-20260719-host01-003.svg)

# イベントID( EVT-20260719-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→13→11
* 開始   : 2026-07-19 17:55:00 (UTC)
* 終了   : 2026-07-19 17:55:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→14→17→15→…→14→17→16→15
* 開始   : 2026-07-20 00:45:00 (UTC)
* 終了   : 2026-07-20 19:25:00 (UTC)
* 現象   : 2026-07-20 19:25:00 (UTC)を境に水準が 11.92から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.45, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→20→20→23→17→20→21→19→21
* 開始   : 2026-07-21 15:20:00 (UTC)
* 終了   : 2026-07-21 16:35:00 (UTC)
* 現象   : 2026-07-21 16:35:00 (UTC)を境に水準が 15.02から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.064, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→8→13→7→8
* 開始   : 2026-07-22 00:50:00 (UTC)
* 終了   : 2026-07-22 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-003 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260722-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→11→14→12→11
* 開始   : 2026-07-22 03:10:00 (UTC)
* 終了   : 2026-07-22 03:10:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→11→7→9→10
* 開始   : 2026-07-22 20:50:00 (UTC)
* 終了   : 2026-07-22 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→14→12→15→14→12→15→13→11
* 開始   : 2026-07-23 03:50:00 (UTC)
* 終了   : 2026-07-23 04:00:00 (UTC)
* 現象   : 平常時(10)に対し 1.4倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260723-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.24→43.42→49.63→54.14→…→49.63→54.14→47.82→42.04
* 開始   : 2026-07-23 05:15:00 (UTC)
* 終了   : 2026-07-23 05:20:00 (UTC)
* 現象   : 平常時(41.92)に対し 1.184倍(49.63)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.77→49.21→57.65→54.71→…→54.71→61.35→51.72→60.04
* 開始   : 2026-07-23 07:10:00 (UTC)
* 終了   : 2026-07-23 07:35:00 (UTC)
* 現象   : 平常時(50.26)に対し 1.147倍(57.65)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260723-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host01-007 eu の推移](charts/EVT-20260723-host01-007.svg)

# イベントID( EVT-20260723-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.6→58.89→44.94→51.05→51.09
* 開始   : 2026-07-23 17:45:00 (UTC)
* 終了   : 2026-07-23 17:45:00 (UTC)
* 現象   : 平常時(56.04)に対し 0.802(44.94)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→11→6→9→10
* 開始   : 2026-07-23 21:05:00 (UTC)
* 終了   : 2026-07-23 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host01-012 active_connections の推移](charts/EVT-20260723-host01-012.svg)

# イベントID( EVT-20260723-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→6→4→10→8
* 開始   : 2026-07-23 23:10:00 (UTC)
* 終了   : 2026-07-23 23:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→17→22→20→17
* 開始   : 2026-07-24 07:55:00 (UTC)
* 終了   : 2026-07-24 07:55:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260724-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→20→13→17→17
* 開始   : 2026-07-24 16:30:00 (UTC)
* 終了   : 2026-07-24 16:30:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.6903(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host01-007 active_connections の推移](charts/EVT-20260724-host01-007.svg)

# イベントID( EVT-20260724-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→14→9→13→13
* 開始   : 2026-07-24 18:55:00 (UTC)
* 終了   : 2026-07-24 18:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6171(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.901σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host01-010 active_connections の推移](charts/EVT-20260724-host01-010.svg)

# イベントID( EVT-20260725-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→13→12→11→…→11→9→11→12
* 開始   : 2026-07-25 05:00:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.37, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host01-002 active_connections の推移](charts/EVT-20260725-host01-002.svg)

# イベントID( EVT-20260725-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→11→…→12→10→12→10
* 開始   : 2026-07-25 05:05:00 (UTC)
* 終了   : 2026-07-25 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host01-003 active_connections の推移](charts/EVT-20260725-host01-003.svg)

# イベントID( EVT-20260725-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.35→41.97→34.17→37.87→…→38.16→31.28→40.22→40.21
* 開始   : 2026-07-25 05:15:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.005σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.958, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260725-host01-004 eu の推移](charts/EVT-20260725-host01-004.svg)

# イベントID( EVT-20260725-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→13→…→13→15→13→14
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 17:45:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.407, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260725-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→11→…→12→14→15→12
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host01-006 active_connections の推移](charts/EVT-20260725-host01-006.svg)

# イベントID( EVT-20260725-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→16→11→13→…→12→13→11→12
* 開始   : 2026-07-25 06:00:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.189, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host01-007 active_connections の推移](charts/EVT-20260725-host01-007.svg)

# イベントID( EVT-20260725-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→12→…→10→11→12→11
* 開始   : 2026-07-25 06:20:00 (UTC)
* 終了   : 2026-07-25 18:40:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260725-host01-008 active_connections の推移](charts/EVT-20260725-host01-008.svg)

# イベントID( EVT-20260725-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→10→6→10→9
* 開始   : 2026-07-25 20:05:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260725-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→9→5→9→7
* 開始   : 2026-07-25 21:45:00 (UTC)
* 終了   : 2026-07-25 21:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260725-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→12→15→10→12
* 開始   : 2026-07-26 05:30:00 (UTC)
* 終了   : 2026-07-26 05:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260726-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→12→16→18→…→16→18→14→12
* 開始   : 2026-07-26 07:45:00 (UTC)
* 終了   : 2026-07-26 07:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260726-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→7→13→7→9
* 開始   : 2026-07-27 00:55:00 (UTC)
* 終了   : 2026-07-27 00:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.696倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260727-host01-001 active_connections の推移](charts/EVT-20260727-host01-001.svg)

# イベントID( EVT-20260727-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.05→50.55→49.56→51.93→…→38.48→40.89→40.57→43.31
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 41.1から50.09へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.392, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-004 eu の推移](charts/EVT-20260727-host01-004.svg)

# イベントID( EVT-20260727-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→15→…→15→12→13→15
* 開始   : 2026-07-27 02:45:00 (UTC)
* 終了   : 2026-07-27 18:55:00 (UTC)
* 現象   : 2026-07-27 18:55:00 (UTC)を境に水準が 11.96から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.472, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.224, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→15→16→15→…→12→13→14→12
* 開始   : 2026-07-27 03:30:00 (UTC)
* 終了   : 2026-07-27 20:10:00 (UTC)
* 現象   : 2026-07-27 20:10:00 (UTC)を境に水準が 11.76から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.28, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→10→5→8→9
* 開始   : 2026-07-27 22:45:00 (UTC)
* 終了   : 2026-07-27 22:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→15→19→16→15
* 開始   : 2026-07-28 06:15:00 (UTC)
* 終了   : 2026-07-28 06:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→15→20→17→14
* 開始   : 2026-07-28 06:15:00 (UTC)
* 終了   : 2026-07-28 06:15:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.364倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.724σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host01-005 active_connections の推移](charts/EVT-20260728-host01-005.svg)

# イベントID( EVT-20260728-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→16→12→15→16
* 開始   : 2026-07-28 17:35:00 (UTC)
* 終了   : 2026-07-28 17:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host01-007 active_connections の推移](charts/EVT-20260728-host01-007.svg)

# イベントID( EVT-20260728-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 54.2→53.07→42.67→47.42→46.78
* 開始   : 2026-07-28 17:50:00 (UTC)
* 終了   : 2026-07-28 17:50:00 (UTC)
* 現象   : 平常時(54.74)に対し 0.7794(42.67)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→20→25→22→21
* 開始   : 2026-07-29 10:35:00 (UTC)
* 終了   : 2026-07-29 11:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260729-host01-006 active_connections の推移](charts/EVT-20260729-host01-006.svg)

# イベントID( EVT-20260730-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→15→18→15→13
* 開始   : 2026-07-30 05:40:00 (UTC)
* 終了   : 2026-07-30 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260730-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→15→16
* 開始   : 2026-07-30 05:40:00 (UTC)
* 終了   : 2026-07-30 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260730-host01-002 active_connections の推移](charts/EVT-20260730-host01-002.svg)

# イベントID( EVT-20260730-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→17→20→19→…→20→19→18→16
* 開始   : 2026-07-30 07:15:00 (UTC)
* 終了   : 2026-07-30 07:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 20→18→23→17→20
* 開始   : 2026-07-30 09:05:00 (UTC)
* 終了   : 2026-07-30 09:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→22→26→22→23
* 開始   : 2026-07-30 12:35:00 (UTC)
* 終了   : 2026-07-30 12:35:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→22→20→20→22→19→19→20→19
* 開始   : 2026-07-30 14:40:00 (UTC)
* 終了   : 2026-07-30 17:30:00 (UTC)
* 現象   : 2026-07-30 17:30:00 (UTC)を境に水準が 15.02から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.013, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→16→11→13→16→11→13
* 開始   : 2026-07-30 18:25:00 (UTC)
* 終了   : 2026-07-30 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→15→14
* 開始   : 2026-07-30 19:15:00 (UTC)
* 終了   : 2026-07-30 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6243(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.795σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260730-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host01-011 active_connections の推移](charts/EVT-20260730-host01-011.svg)

# イベントID( EVT-20260731-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→10→10
* 開始   : 2026-07-31 02:35:00 (UTC)
* 終了   : 2026-07-31 02:35:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→12→12→11→10→14→13→14→16
* 開始   : 2026-07-31 03:30:00 (UTC)
* 終了   : 2026-07-31 04:50:00 (UTC)
* 現象   : 2026-07-31 04:50:00 (UTC)を境に水準が 15.06から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.494σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→19→15→18→18
* 開始   : 2026-07-31 15:45:00 (UTC)
* 終了   : 2026-07-31 15:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→16→11→15→15
* 開始   : 2026-07-31 18:00:00 (UTC)
* 終了   : 2026-07-31 18:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6839(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host01-008 active_connections の推移](charts/EVT-20260731-host01-008.svg)

# イベントID( EVT-20260731-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.87→49.4→42.26→45.39→…→45.39→37.93→49.65→45.15
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 18:35:00 (UTC)
* 現象   : 平常時(50.35)に対し 0.8393(42.26)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.236σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→16→11→13→13
* 開始   : 2026-07-31 18:30:00 (UTC)
* 終了   : 2026-07-31 19:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-010 (同一ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260731-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→12→13
* 開始   : 2026-07-31 19:10:00 (UTC)
* 終了   : 2026-07-31 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→11→7→10→9
* 開始   : 2026-07-31 20:50:00 (UTC)
* 終了   : 2026-07-31 20:50:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→11→5→10→9
* 開始   : 2026-07-31 22:20:00 (UTC)
* 終了   : 2026-07-31 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→10→14→10→14→10
* 開始   : 2026-07-01 03:15:00 (UTC)
* 終了   : 2026-07-01 03:20:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.424倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.73→45.96→47.62→46.4→49.28→43.23→49.21→49.65→51.91
* 開始   : 2026-07-01 04:20:00 (UTC)
* 終了   : 2026-07-01 05:25:00 (UTC)
* 現象   : 2026-07-01 05:25:00 (UTC)を境に水準が 50.23から50.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→17→16→13→17→14
* 開始   : 2026-07-01 05:30:00 (UTC)
* 終了   : 2026-07-01 05:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260701-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260701-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260701-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→20→21→21→19→21→23→21→23
* 開始   : 2026-07-01 08:15:00 (UTC)
* 終了   : 2026-07-01 09:15:00 (UTC)
* 現象   : 2026-07-01 09:15:00 (UTC)を境に水準が 14.91から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.725, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→23→22→21→23→22→20
* 開始   : 2026-07-01 09:25:00 (UTC)
* 終了   : 2026-07-01 09:30:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 62.88→62.66→53.83→63.94→…→63.94→55.2→66.12→58.52
* 開始   : 2026-07-01 15:35:00 (UTC)
* 終了   : 2026-07-01 15:45:00 (UTC)
* 現象   : 平常時(64.09)に対し 0.8399(53.83)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.835σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260701-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.14→48.85→39.49→44.69→…→44.69→37.14→44.63→42.65
* 開始   : 2026-07-01 19:15:00 (UTC)
* 終了   : 2026-07-01 19:25:00 (UTC)
* 現象   : 平常時(48.33)に対し 0.8172(39.49)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→13→7→8→7→8→7→8→10
* 開始   : 2026-07-01 21:20:00 (UTC)
* 終了   : 2026-07-01 21:30:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.6462(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260701-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→8→6→10→8→6→10→9
* 開始   : 2026-07-01 22:20:00 (UTC)
* 終了   : 2026-07-01 22:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→9
* 開始   : 2026-07-01 23:10:00 (UTC)
* 終了   : 2026-07-01 23:25:00 (UTC)
* 現象   : 2026-07-01 23:25:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.915, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host01-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→11→8→9
* 開始   : 2026-07-01 23:35:00 (UTC)
* 終了   : 2026-07-01 23:50:00 (UTC)
* 現象   : 2026-07-01 23:50:00 (UTC)を境に水準が 14.85から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→10→11→11→8→12→12
* 開始   : 2026-07-02 01:55:00 (UTC)
* 終了   : 2026-07-02 02:40:00 (UTC)
* 現象   : 2026-07-02 02:40:00 (UTC)を境に水準が 14.95から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→20→25→20→25→20→22
* 開始   : 2026-07-02 12:00:00 (UTC)
* 終了   : 2026-07-02 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260702-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→18→19→16→18→16
* 開始   : 2026-07-02 16:30:00 (UTC)
* 終了   : 2026-07-02 16:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→10→13→11→10→13→14
* 開始   : 2026-07-02 19:10:00 (UTC)
* 終了   : 2026-07-02 19:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→15→11→10→12→15→11→10→12
* 開始   : 2026-07-02 19:15:00 (UTC)
* 終了   : 2026-07-02 19:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-009 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-host01-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→9→7→8→…→8→6→9→8
* 開始   : 2026-07-02 21:55:00 (UTC)
* 終了   : 2026-07-02 22:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-012 (同一ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260702-host07-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host02-022 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260702-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.27→33.02→24.73→32.97→…→32.97→25.66→33.39→28.68
* 開始   : 2026-07-02 21:55:00 (UTC)
* 終了   : 2026-07-02 22:05:00 (UTC)
* 現象   : 平常時(35.52)に対し 0.6963(24.73)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.981σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host07-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host02-022 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260702-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→12→14→15→12→14
* 開始   : 2026-07-03 04:40:00 (UTC)
* 終了   : 2026-07-03 04:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→16→13→17→16→17
* 開始   : 2026-07-03 05:45:00 (UTC)
* 終了   : 2026-07-03 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-004 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260703-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.5→42.76→52.18→54.06→…→52.18→54.06→51.56→46.64
* 開始   : 2026-07-03 05:45:00 (UTC)
* 終了   : 2026-07-03 05:50:00 (UTC)
* 現象   : 平常時(44.76)に対し 1.166倍(52.18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→21→20→19→19→17→21→22→22
* 開始   : 2026-07-03 07:45:00 (UTC)
* 終了   : 2026-07-03 09:30:00 (UTC)
* 現象   : 2026-07-03 09:30:00 (UTC)を境に水準が 14.84から14.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.762, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 23→25→23→20→25
* 開始   : 2026-07-03 11:35:00 (UTC)
* 終了   : 2026-07-03 11:55:00 (UTC)
* 現象   : 2026-07-03 11:55:00 (UTC)を境に水準が 15.03から13.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→23→25→20→…→20→19→22→21
* 開始   : 2026-07-03 11:45:00 (UTC)
* 終了   : 2026-07-03 11:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260703-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→11→14→12→11→14
* 開始   : 2026-07-03 18:40:00 (UTC)
* 終了   : 2026-07-03 18:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→12→…→12→8→11→10
* 開始   : 2026-07-03 20:05:00 (UTC)
* 終了   : 2026-07-03 20:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→12→9→10→…→10→8→12→11
* 開始   : 2026-07-03 20:30:00 (UTC)
* 終了   : 2026-07-03 20:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260703-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→8→8→7→8→8→9→9→10
* 開始   : 2026-07-04 00:05:00 (UTC)
* 終了   : 2026-07-04 01:00:00 (UTC)
* 現象   : 2026-07-04 01:00:00 (UTC)を境に水準が 14.99から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.507, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260704-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→7→8→9→…→8→9→10→8
* 開始   : 2026-07-04 03:55:00 (UTC)
* 終了   : 2026-07-04 04:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.995, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→11→13→7→9→11→13→7→9
* 開始   : 2026-07-04 21:20:00 (UTC)
* 終了   : 2026-07-04 21:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260704-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→8→6→9→6→9→6→7→9
* 開始   : 2026-07-04 21:50:00 (UTC)
* 終了   : 2026-07-04 22:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→9→9→10→9→8
* 開始   : 2026-07-04 23:45:00 (UTC)
* 終了   : 2026-07-05 01:10:00 (UTC)
* 現象   : 2026-07-05 01:10:00 (UTC)を境に水準が 11.82から11.79へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260704-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→7→…→7→12→10→6
* 開始   : 2026-07-05 00:50:00 (UTC)
* 終了   : 2026-07-05 01:00:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260705-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→11→11→9→11→10→10
* 開始   : 2026-07-05 19:10:00 (UTC)
* 終了   : 2026-07-05 20:05:00 (UTC)
* 現象   : 2026-07-05 20:05:00 (UTC)を境に水準が 11.78から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.746, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 10→9→11→10→10→10→10→12→13
* 開始   : 2026-07-06 21:15:00 (UTC)
* 終了   : 2026-07-06 23:10:00 (UTC)
* 現象   : 2026-07-06 23:10:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→9→8→8→7→10→7→10
* 開始   : 2026-07-06 22:35:00 (UTC)
* 終了   : 2026-07-06 23:30:00 (UTC)
* 現象   : 2026-07-06 23:30:00 (UTC)を境に水準が 15.03から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→12→14
* 開始   : 2026-07-07 03:35:00 (UTC)
* 終了   : 2026-07-07 04:00:00 (UTC)
* 現象   : 2026-07-07 04:00:00 (UTC)を境に水準が 14.91から15.19へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.628, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→16→17→17→14→17→18→19→18
* 開始   : 2026-07-07 05:55:00 (UTC)
* 終了   : 2026-07-07 06:55:00 (UTC)
* 現象   : 2026-07-07 06:55:00 (UTC)を境に水準が 15.05から15.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 23→23→22→22→23→24→23→25
* 開始   : 2026-07-07 09:55:00 (UTC)
* 終了   : 2026-07-07 10:30:00 (UTC)
* 現象   : 2026-07-07 10:30:00 (UTC)を境に水準が 15.19から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 21→20→19→21→21
* 開始   : 2026-07-07 15:05:00 (UTC)
* 終了   : 2026-07-07 15:25:00 (UTC)
* 現象   : 2026-07-07 15:25:00 (UTC)を境に水準が 15から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 59.16→56.97→59.68→55.65→60.16→54.96
* 開始   : 2026-07-07 16:55:00 (UTC)
* 終了   : 2026-07-07 17:20:00 (UTC)
* 現象   : 2026-07-07 17:20:00 (UTC)を境に水準が 50.3から50.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→15→14→16→15→14→16→15
* 開始   : 2026-07-07 17:25:00 (UTC)
* 終了   : 2026-07-07 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→15→10→11→15→10→11→10
* 開始   : 2026-07-07 19:35:00 (UTC)
* 終了   : 2026-07-07 19:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host01-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.59→39.34→38.86→39.75→32.64→37.55→35.36→38.97→37.6
* 開始   : 2026-07-07 20:35:00 (UTC)
* 終了   : 2026-07-07 21:55:00 (UTC)
* 現象   : 2026-07-07 21:55:00 (UTC)を境に水準が 50.27から50.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=24.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→11→13→10→13→10→13→11
* 開始   : 2026-07-08 03:05:00 (UTC)
* 終了   : 2026-07-08 03:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→13→14→15→13→15
* 開始   : 2026-07-08 05:05:00 (UTC)
* 終了   : 2026-07-08 05:10:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 53.52→58.14→61.72→62.07→…→61.72→62.07→58.39→57.28
* 開始   : 2026-07-08 07:00:00 (UTC)
* 終了   : 2026-07-08 07:05:00 (UTC)
* 現象   : 平常時(52.42)に対し 1.177倍(61.72)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→19→21→18→21→18→21→19
* 開始   : 2026-07-08 08:15:00 (UTC)
* 終了   : 2026-07-08 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 23→23→23→23→20→23→23
* 開始   : 2026-07-08 11:25:00 (UTC)
* 終了   : 2026-07-08 11:55:00 (UTC)
* 現象   : 2026-07-08 11:55:00 (UTC)を境に水準が 14.93から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 22→20→19→18→20→19→18→20
* 開始   : 2026-07-08 14:40:00 (UTC)
* 終了   : 2026-07-08 14:45:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→20→23→21→19
* 開始   : 2026-07-08 15:05:00 (UTC)
* 終了   : 2026-07-08 15:25:00 (UTC)
* 現象   : 2026-07-08 15:25:00 (UTC)を境に水準が 14.94から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→18→17→15→18
* 開始   : 2026-07-08 16:30:00 (UTC)
* 終了   : 2026-07-08 16:35:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.793(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→17→14→17→14→19→16
* 開始   : 2026-07-08 16:50:00 (UTC)
* 終了   : 2026-07-08 17:00:00 (UTC)
* 現象   : 平常時(18)に対し 0.7778(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.803σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260708-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→17→…→17→12→16→15
* 開始   : 2026-07-08 17:40:00 (UTC)
* 終了   : 2026-07-08 18:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→16→13→15→13→15→13→17→15
* 開始   : 2026-07-08 18:00:00 (UTC)
* 終了   : 2026-07-08 18:10:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7685(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 6→10→6→10→6→10→8
* 開始   : 2026-07-09 00:45:00 (UTC)
* 終了   : 2026-07-09 00:55:00 (UTC)
* 現象   : 平常時(6.917)に対し 1.446倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→16→11→13→…→13→10→11→12
* 開始   : 2026-07-09 19:20:00 (UTC)
* 終了   : 2026-07-09 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 40.32→45.85→36.42→43.17→…→43.17→34.93→40.15→40.51
* 開始   : 2026-07-09 19:55:00 (UTC)
* 終了   : 2026-07-09 20:05:00 (UTC)
* 現象   : 平常時(43.66)に対し 0.8341(36.42)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.001σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→8→14→11→…→11→7→10→9
* 開始   : 2026-07-09 20:55:00 (UTC)
* 終了   : 2026-07-09 21:05:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→9→11→12→10→11→11
* 開始   : 2026-07-10 02:25:00 (UTC)
* 終了   : 2026-07-10 03:30:00 (UTC)
* 現象   : 2026-07-10 03:30:00 (UTC)を境に水準が 14.9から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.704, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→18→17→15→18→16→15
* 開始   : 2026-07-10 05:55:00 (UTC)
* 終了   : 2026-07-10 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→17→19→17→19→17→18
* 開始   : 2026-07-10 06:50:00 (UTC)
* 終了   : 2026-07-10 07:00:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→18→23→18→…→18→17→20→18
* 開始   : 2026-07-10 15:30:00 (UTC)
* 終了   : 2026-07-10 15:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260710-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 20→19→17→22→19→17→22→19
* 開始   : 2026-07-10 15:35:00 (UTC)
* 終了   : 2026-07-10 15:40:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260710-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→18→17→18→18→16→17
* 開始   : 2026-07-10 17:05:00 (UTC)
* 終了   : 2026-07-10 17:50:00 (UTC)
* 現象   : 2026-07-10 17:50:00 (UTC)を境に水準が 15.07から12.26へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.978σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→12→8→9→12→8→9
* 開始   : 2026-07-10 21:15:00 (UTC)
* 終了   : 2026-07-10 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 33.25→30.39→42→30.03→…→30.03→41.54→37.31→33.14
* 開始   : 2026-07-11 03:45:00 (UTC)
* 終了   : 2026-07-11 03:55:00 (UTC)
* 現象   : 平常時(32.73)に対し 1.283倍(42)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260711-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→6→5→8→…→8→11→8→6
* 開始   : 2026-07-12 00:35:00 (UTC)
* 終了   : 2026-07-12 00:45:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→11→8→11→8
* 開始   : 2026-07-12 02:45:00 (UTC)
* 終了   : 2026-07-12 02:50:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→6→10→6→10→6→11
* 開始   : 2026-07-12 03:35:00 (UTC)
* 終了   : 2026-07-12 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260712-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260712-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→13→14→14→17→15→15→15→15
* 開始   : 2026-07-12 06:50:00 (UTC)
* 終了   : 2026-07-12 08:50:00 (UTC)
* 現象   : 2026-07-12 08:50:00 (UTC)を境に水準が 11.81から12.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 51.99→45.86→42.41→50.94→…→49.99→56.51→51.53→44.55
* 開始   : 2026-07-12 15:05:00 (UTC)
* 終了   : 2026-07-12 15:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260712-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→8→…→8→13→11→10
* 開始   : 2026-07-14 02:35:00 (UTC)
* 終了   : 2026-07-14 03:25:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260714-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→17→21→15→…→15→21→18→19
* 開始   : 2026-07-14 08:10:00 (UTC)
* 終了   : 2026-07-14 08:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 24→21→23→24→22
* 開始   : 2026-07-14 10:10:00 (UTC)
* 終了   : 2026-07-14 10:30:00 (UTC)
* 現象   : 2026-07-14 10:30:00 (UTC)を境に水準が 15.06から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 25→23→23→24→22→24→22→22
* 開始   : 2026-07-14 11:50:00 (UTC)
* 終了   : 2026-07-14 12:45:00 (UTC)
* 現象   : 2026-07-14 12:45:00 (UTC)を境に水準が 14.86から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→18→17→20→18→17→20
* 開始   : 2026-07-14 14:25:00 (UTC)
* 終了   : 2026-07-14 14:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→20→21→23
* 開始   : 2026-07-14 15:00:00 (UTC)
* 終了   : 2026-07-14 15:20:00 (UTC)
* 現象   : 2026-07-14 15:20:00 (UTC)を境に水準が 14.98から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→13→11→10→13
* 開始   : 2026-07-14 19:05:00 (UTC)
* 終了   : 2026-07-14 19:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→14→12→11→14→12
* 開始   : 2026-07-15 04:25:00 (UTC)
* 終了   : 2026-07-15 04:30:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→14→…→15→14→20→19
* 開始   : 2026-07-15 16:55:00 (UTC)
* 終了   : 2026-07-15 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→14→15→15→15→14→14
* 開始   : 2026-07-15 18:20:00 (UTC)
* 終了   : 2026-07-15 19:15:00 (UTC)
* 現象   : 2026-07-15 19:15:00 (UTC)を境に水準が 15から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→8→11→8→11→10
* 開始   : 2026-07-15 20:45:00 (UTC)
* 終了   : 2026-07-15 20:50:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→7→8→6→7→8→6→9→8
* 開始   : 2026-07-15 22:00:00 (UTC)
* 終了   : 2026-07-15 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 25.94→29.47→36.22→37.07→…→36.22→37.07→31.35→26.59
* 開始   : 2026-07-16 00:30:00 (UTC)
* 終了   : 2026-07-16 00:35:00 (UTC)
* 現象   : 平常時(28.93)に対し 1.252倍(36.22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-001 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260716-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→12→7→11→…→11→14→12→10
* 開始   : 2026-07-16 03:20:00 (UTC)
* 終了   : 2026-07-16 03:30:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260716-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260716-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→13→15→13→15→13→15→13→11
* 開始   : 2026-07-16 04:15:00 (UTC)
* 終了   : 2026-07-16 04:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→18→20→18→20→18→19
* 開始   : 2026-07-16 07:30:00 (UTC)
* 終了   : 2026-07-16 07:35:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→19→21→17→19→21→17→18
* 開始   : 2026-07-16 08:00:00 (UTC)
* 終了   : 2026-07-16 08:05:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→21→19→22→…→22→15→19→20
* 開始   : 2026-07-16 08:20:00 (UTC)
* 終了   : 2026-07-16 09:45:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 35 分
  - EVT-20260716-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260716-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→17→23→…→17→23→20→21
* 開始   : 2026-07-16 08:50:00 (UTC)
* 終了   : 2026-07-16 08:55:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→22→16→18→16→18→16→19→21
* 開始   : 2026-07-16 16:05:00 (UTC)
* 終了   : 2026-07-16 16:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260716-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→10→…→11→10→14→12
* 開始   : 2026-07-16 19:10:00 (UTC)
* 終了   : 2026-07-16 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 8→9→7→10→…→10→6→10→7
* 開始   : 2026-07-16 21:00:00 (UTC)
* 終了   : 2026-07-16 21:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 45 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host01-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→9→9→9→9→10→10→8→9
* 開始   : 2026-07-16 23:25:00 (UTC)
* 終了   : 2026-07-17 00:30:00 (UTC)
* 現象   : 2026-07-17 00:30:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 7→5→9→11→5→9→11→9→8
* 開始   : 2026-07-17 01:10:00 (UTC)
* 終了   : 2026-07-17 01:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-006 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260717-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→14→15→14
* 開始   : 2026-07-17 04:50:00 (UTC)
* 終了   : 2026-07-17 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→13→17→14→17→14→17→15
* 開始   : 2026-07-17 05:45:00 (UTC)
* 終了   : 2026-07-17 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260717-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260717-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→14→16→17→14→17
* 開始   : 2026-07-17 06:15:00 (UTC)
* 終了   : 2026-07-17 06:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→18→…→18→22→19→20
* 開始   : 2026-07-17 08:25:00 (UTC)
* 終了   : 2026-07-17 08:35:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260717-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→20→21→22→23→22→22→23→22
* 開始   : 2026-07-17 09:20:00 (UTC)
* 終了   : 2026-07-17 10:00:00 (UTC)
* 現象   : 2026-07-17 10:00:00 (UTC)を境に水準が 14.98から13.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→13→14→14→14→16
* 開始   : 2026-07-17 19:05:00 (UTC)
* 終了   : 2026-07-17 19:40:00 (UTC)
* 現象   : 2026-07-17 19:40:00 (UTC)を境に水準が 15.03から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.26→41.67→36.61→42.88→…→42.88→35.57→42.21→39.66
* 開始   : 2026-07-17 19:40:00 (UTC)
* 終了   : 2026-07-17 19:50:00 (UTC)
* 現象   : 平常時(44.11)に対し 0.83(36.61)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.36→36.97→28.18→27.55→…→28.18→27.55→33.09→33.39
* 開始   : 2026-07-18 20:20:00 (UTC)
* 終了   : 2026-07-18 20:25:00 (UTC)
* 現象   : 平常時(36.81)に対し 0.7656(28.18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260718-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260718-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 10→10→11→9→9→11→11→11→10
* 開始   : 2026-07-19 02:45:00 (UTC)
* 終了   : 2026-07-19 04:00:00 (UTC)
* 現象   : 2026-07-19 04:00:00 (UTC)を境に水準が 11.84から12.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.345, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→17→15→16→15→15→17→17→16
* 開始   : 2026-07-19 12:50:00 (UTC)
* 終了   : 2026-07-19 14:05:00 (UTC)
* 現象   : 2026-07-19 14:05:00 (UTC)を境に水準が 11.77から13.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.703, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→12→14→18→12→14→18→17→15
* 開始   : 2026-07-19 14:50:00 (UTC)
* 終了   : 2026-07-19 15:00:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→10→9→11→8→11→9→7→9
* 開始   : 2026-07-20 22:35:00 (UTC)
* 終了   : 2026-07-20 23:45:00 (UTC)
* 現象   : 2026-07-20 23:45:00 (UTC)を境に水準が 14.93から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.847, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→11→8→10→7→9→11→9→10
* 開始   : 2026-07-21 00:05:00 (UTC)
* 終了   : 2026-07-21 00:45:00 (UTC)
* 現象   : 2026-07-21 00:45:00 (UTC)を境に水準が 14.93から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→11→13→12→12→13
* 開始   : 2026-07-21 03:20:00 (UTC)
* 終了   : 2026-07-21 04:50:00 (UTC)
* 現象   : 2026-07-21 04:50:00 (UTC)を境に水準が 15.05から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→16→19→16→19→17→18
* 開始   : 2026-07-21 07:00:00 (UTC)
* 終了   : 2026-07-21 07:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→21→23→21→23→21→23→21→22
* 開始   : 2026-07-21 09:25:00 (UTC)
* 終了   : 2026-07-21 09:35:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 67.33→71.54→76.99→74.16→…→74.16→61.7→69.72→69.42
* 開始   : 2026-07-21 12:35:00 (UTC)
* 終了   : 2026-07-21 12:45:00 (UTC)
* 現象   : 平常時(69.17)に対し 1.113倍(76.99)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260721-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 63.71→58.63→52.39→55.11→…→55.11→50.33→53.57→52.63
* 開始   : 2026-07-21 16:45:00 (UTC)
* 終了   : 2026-07-21 16:55:00 (UTC)
* 現象   : 平常時(60.68)に対し 0.8633(52.39)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.292σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260721-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→11→7→9→7→9→7→9→10
* 開始   : 2026-07-21 20:55:00 (UTC)
* 終了   : 2026-07-21 21:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→10→5→11→6→5→11→6→10
* 開始   : 2026-07-21 22:50:00 (UTC)
* 終了   : 2026-07-21 23:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.5607(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.76→34.35→47.95→46.51→…→42.76→47.52→39.33→42.63
* 開始   : 2026-07-22 04:05:00 (UTC)
* 終了   : 2026-07-22 04:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.864σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 59.36→55.73→65.58→58.37→…→58.37→69.38→60.84→62.26
* 開始   : 2026-07-22 07:30:00 (UTC)
* 終了   : 2026-07-22 08:15:00 (UTC)
* 現象   : 平常時(56.08)に対し 1.153倍(64.69)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260722-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→21→21→22→23→21
* 開始   : 2026-07-22 09:30:00 (UTC)
* 終了   : 2026-07-22 09:55:00 (UTC)
* 現象   : 2026-07-22 09:55:00 (UTC)を境に水準が 15.11から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→15→14→16→17→15→14→16→18
* 開始   : 2026-07-22 17:10:00 (UTC)
* 終了   : 2026-07-22 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 54.11→54.54→47.57→48.28→…→48.28→43.45→47.8→48.32
* 開始   : 2026-07-22 18:00:00 (UTC)
* 終了   : 2026-07-22 18:10:00 (UTC)
* 現象   : 平常時(54.93)に対し 0.8661(47.57)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260722-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260722-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→12→14→12→15
* 開始   : 2026-07-22 18:20:00 (UTC)
* 終了   : 2026-07-22 18:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260722-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→13→12→13→12→13→14
* 開始   : 2026-07-22 18:40:00 (UTC)
* 終了   : 2026-07-22 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→11→9→10→11→9→11
* 開始   : 2026-07-22 19:30:00 (UTC)
* 終了   : 2026-07-22 19:40:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260722-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 36.75→33.44→30.42→28.93→27.78→36.67→33.87→34.69
* 開始   : 2026-07-23 01:00:00 (UTC)
* 終了   : 2026-07-23 01:35:00 (UTC)
* 現象   : 2026-07-23 01:35:00 (UTC)を境に水準が 49.85から49.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→18→19→17→18→17→22→20→21
* 開始   : 2026-07-23 06:45:00 (UTC)
* 終了   : 2026-07-23 08:55:00 (UTC)
* 現象   : 2026-07-23 08:55:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→18→14→19→18→14→19→17→18
* 開始   : 2026-07-23 06:55:00 (UTC)
* 終了   : 2026-07-23 07:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→17→19→16→19→16→19→17→18
* 開始   : 2026-07-23 07:00:00 (UTC)
* 終了   : 2026-07-23 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260723-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260723-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 68.43→66.76→60.24→64.78→…→62.31→58.12→59.45→61.13
* 開始   : 2026-07-23 15:00:00 (UTC)
* 終了   : 2026-07-23 15:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 20→20→19→18→19→20→19→18→21
* 開始   : 2026-07-23 15:20:00 (UTC)
* 終了   : 2026-07-23 16:00:00 (UTC)
* 現象   : 2026-07-23 16:00:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host01-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→15→13→14→13→13→14→13→13
* 開始   : 2026-07-23 18:45:00 (UTC)
* 終了   : 2026-07-23 19:40:00 (UTC)
* 現象   : 2026-07-23 19:40:00 (UTC)を境に水準が 14.91から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→10→6→9→12→6→9→12→10
* 開始   : 2026-07-24 02:20:00 (UTC)
* 終了   : 2026-07-24 02:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→16→15→13→…→13→16→14→15
* 開始   : 2026-07-24 05:15:00 (UTC)
* 終了   : 2026-07-24 05:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.837σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260724-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260724-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→19→16→18
* 開始   : 2026-07-24 07:20:00 (UTC)
* 終了   : 2026-07-24 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→21→22→23→21→22→23→21
* 開始   : 2026-07-24 09:30:00 (UTC)
* 終了   : 2026-07-24 09:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260724-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 20→21→25→20→25→20→25→23→22
* 開始   : 2026-07-24 12:25:00 (UTC)
* 終了   : 2026-07-24 12:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 53.18→53.46→49.41→49.13→…→49.13→47.79→58.46→50.02
* 開始   : 2026-07-24 17:25:00 (UTC)
* 終了   : 2026-07-24 17:35:00 (UTC)
* 現象   : 平常時(57.27)に対し 0.8628(49.41)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.172σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→13→16→17→13→16
* 開始   : 2026-07-24 18:00:00 (UTC)
* 終了   : 2026-07-24 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→10→9→13→14→10→9→13→11
* 開始   : 2026-07-24 19:40:00 (UTC)
* 終了   : 2026-07-24 19:45:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host01-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→9→8→10→9→9→11→10
* 開始   : 2026-07-24 23:15:00 (UTC)
* 終了   : 2026-07-24 23:50:00 (UTC)
* 現象   : 2026-07-24 23:50:00 (UTC)を境に水準が 14.96から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→11→8→14→11→8→14→11
* 開始   : 2026-07-25 04:55:00 (UTC)
* 終了   : 2026-07-25 05:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260725-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→12→13→15→12
* 開始   : 2026-07-26 05:15:00 (UTC)
* 終了   : 2026-07-26 05:35:00 (UTC)
* 現象   : 2026-07-26 05:35:00 (UTC)を境に水準が 11.84から12.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 18→18→15→14→15→15→14→16→18
* 開始   : 2026-07-26 14:25:00 (UTC)
* 終了   : 2026-07-26 15:50:00 (UTC)
* 現象   : 2026-07-26 15:50:00 (UTC)を境に水準が 11.88から14.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.18→47.16→39.73→50.24→…→50.24→41.92→48.57→47.4
* 開始   : 2026-07-26 15:25:00 (UTC)
* 終了   : 2026-07-26 15:35:00 (UTC)
* 現象   : 平常時(49.98)に対し 0.795(39.73)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.832σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260726-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→8→13→9→…→9→7→8→11
* 開始   : 2026-07-26 21:00:00 (UTC)
* 終了   : 2026-07-26 21:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 29.29→33.84→38.05→27.6→34.09→31.28→29.98→31.72→30.64
* 開始   : 2026-07-27 22:35:00 (UTC)
* 終了   : 2026-07-28 00:05:00 (UTC)
* 現象   : 2026-07-28 00:05:00 (UTC)を境に水準が 49.86から50.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 7→6→11→12→…→11→12→9→8
* 開始   : 2026-07-28 00:50:00 (UTC)
* 終了   : 2026-07-28 00:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→12→7→9→…→12→7→12→9
* 開始   : 2026-07-28 02:35:00 (UTC)
* 終了   : 2026-07-28 02:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→15→13→15→13→15
* 開始   : 2026-07-28 05:05:00 (UTC)
* 終了   : 2026-07-28 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 20→22→23→20→20→19→22→21→22
* 開始   : 2026-07-28 09:00:00 (UTC)
* 終了   : 2026-07-28 09:40:00 (UTC)
* 現象   : 2026-07-28 09:40:00 (UTC)を境に水準が 14.87から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→16
* 開始   : 2026-07-28 18:00:00 (UTC)
* 終了   : 2026-07-28 18:15:00 (UTC)
* 現象   : 2026-07-28 18:15:00 (UTC)を境に水準が 14.91から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→12→13→11→12
* 開始   : 2026-07-28 19:10:00 (UTC)
* 終了   : 2026-07-28 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260728-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→12→11→13→12→11→13→10
* 開始   : 2026-07-29 02:30:00 (UTC)
* 終了   : 2026-07-29 02:40:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→11→14→11→14→10→14
* 開始   : 2026-07-29 04:20:00 (UTC)
* 終了   : 2026-07-29 04:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→13→13→15→13→15
* 開始   : 2026-07-29 04:25:00 (UTC)
* 終了   : 2026-07-29 04:55:00 (UTC)
* 現象   : 2026-07-29 04:55:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→16→18→16→17
* 開始   : 2026-07-29 06:20:00 (UTC)
* 終了   : 2026-07-29 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→21→19→20→20→21→21
* 開始   : 2026-07-29 08:00:00 (UTC)
* 終了   : 2026-07-29 08:30:00 (UTC)
* 現象   : 2026-07-29 08:30:00 (UTC)を境に水準が 14.93から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.909σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→16→14→13→16→17
* 開始   : 2026-07-29 17:15:00 (UTC)
* 終了   : 2026-07-29 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260729-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→14→15→11→14→15
* 開始   : 2026-07-29 18:40:00 (UTC)
* 終了   : 2026-07-29 18:45:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→14→11→12→14
* 開始   : 2026-07-29 19:00:00 (UTC)
* 終了   : 2026-07-29 19:05:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 24→21→23→23→23→22→23→23→22
* 開始   : 2026-07-30 11:50:00 (UTC)
* 終了   : 2026-07-30 13:10:00 (UTC)
* 現象   : 2026-07-30 13:10:00 (UTC)を境に水準が 15.04から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 65.68→67.27→70.99→66.23→66.76→64.79→65.19→63.7→66.13
* 開始   : 2026-07-30 14:35:00 (UTC)
* 終了   : 2026-07-30 15:15:00 (UTC)
* 現象   : 2026-07-30 15:15:00 (UTC)を境に水準が 49.74から50.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→21→19→18→20→20→19
* 開始   : 2026-07-30 15:35:00 (UTC)
* 終了   : 2026-07-30 16:35:00 (UTC)
* 現象   : 2026-07-30 16:35:00 (UTC)を境に水準が 15.04から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→11→10→14→11→10→14→13
* 開始   : 2026-07-30 19:35:00 (UTC)
* 終了   : 2026-07-30 19:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260730-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→15→12→15→12→15
* 開始   : 2026-07-31 04:40:00 (UTC)
* 終了   : 2026-07-31 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→20→23→21→23→21→23→22
* 開始   : 2026-07-31 09:05:00 (UTC)
* 終了   : 2026-07-31 09:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-005 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260731-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 60.66→66.56→72.12→67.99→…→67.99→71.5→65.38→65.21
* 開始   : 2026-07-31 09:10:00 (UTC)
* 終了   : 2026-07-31 09:20:00 (UTC)
* 現象   : 平常時(61.75)に対し 1.168倍(72.12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.866σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 71.49→72.9→80.2→68.97→…→68.97→62.51→71.46→73.36
* 開始   : 2026-07-31 12:25:00 (UTC)
* 終了   : 2026-07-31 12:35:00 (UTC)
* 現象   : 平常時(70.15)に対し 1.143倍(80.2)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.777σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→16→14→15→15→12→15
* 開始   : 2026-07-31 18:25:00 (UTC)
* 終了   : 2026-07-31 19:10:00 (UTC)
* 現象   : 2026-07-31 19:10:00 (UTC)を境に水準が 14.81から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.789, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→7→5→7→5→7
* 開始   : 2026-07-31 23:45:00 (UTC)
* 終了   : 2026-07-31 23:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host01-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
