# host03 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host03 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 302 (SEVERE: 26, FATAL: 137, WARN: 139, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 26 | 137 | 139 | 302 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→17→…→16→14→13→14
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.9から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-003 active_connections の推移](charts/EVT-20260608-host03-003.svg)

# イベントID( EVT-20260608-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→13→…→14→12→13→14
* 開始   : 2026-06-08 03:15:00 (UTC)
* 終了   : 2026-06-08 18:50:00 (UTC)
* 現象   : 2026-06-08 18:50:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.829, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.953, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-004 active_connections の推移](charts/EVT-20260608-host03-004.svg)

# イベントID( EVT-20260608-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→14→13→14→…→15→11→14→11
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-005 active_connections の推移](charts/EVT-20260608-host03-005.svg)

# イベントID( EVT-20260608-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→17→…→14→13→12→14
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.86から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.712, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-006 active_connections の推移](charts/EVT-20260608-host03-006.svg)

# イベントID( EVT-20260608-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→14→…→14→15→12→13
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.783, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-007 active_connections の推移](charts/EVT-20260608-host03-007.svg)

# イベントID( EVT-20260615-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→15→16→15→14
* 開始   : 2026-06-15 00:25:00 (UTC)
* 終了   : 2026-06-15 21:15:00 (UTC)
* 現象   : 2026-06-15 21:15:00 (UTC)を境に水準が 11.74から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.515σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.078, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.884, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-001 active_connections の推移](charts/EVT-20260615-host03-001.svg)

# イベントID( EVT-20260615-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→15→13→15→…→14→15→14→12
* 開始   : 2026-06-15 01:15:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.71から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.789, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.166, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-002 active_connections の推移](charts/EVT-20260615-host03-002.svg)

# イベントID( EVT-20260615-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→17→…→16→14→11→13
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.005, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-004 active_connections の推移](charts/EVT-20260615-host03-004.svg)

# イベントID( EVT-20260615-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→14→…→12→14→12→13
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.026, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-005 active_connections の推移](charts/EVT-20260615-host03-005.svg)

# イベントID( EVT-20260615-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→15→…→11→14→11→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.88から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.265, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-006 active_connections の推移](charts/EVT-20260615-host03-006.svg)

# イベントID( EVT-20260618-host03-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→12→9→12→10→11→12
* 開始   : 2026-06-18 21:00:00 (UTC)
* 終了   : 2026-06-18 21:30:00 (UTC)
* 現象   : 2026-06-18 21:30:00 (UTC)を境に水準が 14.8から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-014 active_connections の推移](charts/EVT-20260618-host03-014.svg)

# イベントID( EVT-20260619-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 24→22→23→24→25→23→24
* 開始   : 2026-06-19 12:10:00 (UTC)
* 終了   : 2026-06-19 12:40:00 (UTC)
* 現象   : 2026-06-19 12:40:00 (UTC)を境に水準が 15.06から13.25へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-004 active_connections の推移](charts/EVT-20260619-host03-004.svg)

# イベントID( EVT-20260622-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→14→…→15→13→11→14
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 21:50:00 (UTC)
* 現象   : 2026-06-22 21:50:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-001 active_connections の推移](charts/EVT-20260622-host03-001.svg)

# イベントID( EVT-20260622-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→15→…→14→16→14→15
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 22:10:00 (UTC)
* 現象   : 2026-06-22 22:10:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.339σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.698, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-003 active_connections の推移](charts/EVT-20260622-host03-003.svg)

# イベントID( EVT-20260622-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→13→15→12→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 11.8から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.893, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-004 active_connections の推移](charts/EVT-20260622-host03-004.svg)

# イベントID( EVT-20260622-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→13→…→13→14→12→13
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.833, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-005 active_connections の推移](charts/EVT-20260622-host03-005.svg)

# イベントID( EVT-20260622-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→15→14→13→…→12→14→13→12
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 19:15:00 (UTC)
* 現象   : 2026-06-22 19:15:00 (UTC)を境に水準が 11.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-006 active_connections の推移](charts/EVT-20260622-host03-006.svg)

# イベントID( EVT-20260624-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→11→12→9→12
* 開始   : 2026-06-24 20:45:00 (UTC)
* 終了   : 2026-06-24 21:15:00 (UTC)
* 現象   : 2026-06-24 21:15:00 (UTC)を境に水準が 15.01から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host03-009 active_connections の推移](charts/EVT-20260624-host03-009.svg)

# イベントID( EVT-20260625-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→13→14→14→11→14→12→12
* 開始   : 2026-06-25 19:00:00 (UTC)
* 終了   : 2026-06-25 20:10:00 (UTC)
* 現象   : 2026-06-25 20:10:00 (UTC)を境に水準が 14.91から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host03-010 active_connections の推移](charts/EVT-20260625-host03-010.svg)

# イベントID( EVT-20260628-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→12→13→12→12
* 開始   : 2026-06-28 05:40:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 2026-06-28 06:05:00 (UTC)を境に水準が 11.79から12.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-003 active_connections の推移](charts/EVT-20260628-host03-003.svg)

# イベントID( EVT-20260629-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→15→…→14→15→12→15
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 21:15:00 (UTC)
* 現象   : 2026-06-29 21:15:00 (UTC)を境に水準が 11.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-002 active_connections の推移](charts/EVT-20260629-host03-002.svg)

# イベントID( EVT-20260629-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→15→…→17→14→15→13
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.86から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.768, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-003 active_connections の推移](charts/EVT-20260629-host03-003.svg)

# イベントID( EVT-20260629-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→15→…→14→12→14→13
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.175, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-004 active_connections の推移](charts/EVT-20260629-host03-004.svg)

# イベントID( EVT-20260629-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→13→12→14→13
* 開始   : 2026-06-29 03:15:00 (UTC)
* 終了   : 2026-06-29 22:10:00 (UTC)
* 現象   : 2026-06-29 22:10:00 (UTC)を境に水準が 11.9から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.867, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-005 active_connections の推移](charts/EVT-20260629-host03-005.svg)

# イベントID( EVT-20260629-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→19→18→17→…→14→15→13→15
* 開始   : 2026-06-29 03:55:00 (UTC)
* 終了   : 2026-06-29 19:20:00 (UTC)
* 現象   : 2026-06-29 19:20:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.855, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-006 active_connections の推移](charts/EVT-20260629-host03-006.svg)

# イベントID( EVT-20260630-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→12→7→11→12→12→11
* 開始   : 2026-06-30 02:25:00 (UTC)
* 終了   : 2026-06-30 03:15:00 (UTC)
* 現象   : 2026-06-30 03:15:00 (UTC)を境に水準が 14.83から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.953, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-002 active_connections の推移](charts/EVT-20260630-host03-002.svg)

# イベントID( EVT-20260601-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→13→17→16→13→17→16→13→15
* 開始   : 2026-06-01 05:05:00 (UTC)
* 終了   : 2026-06-01 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→15→18→14→15
* 開始   : 2026-06-01 05:30:00 (UTC)
* 終了   : 2026-06-01 05:30:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→18→14→18→17
* 開始   : 2026-06-01 16:35:00 (UTC)
* 終了   : 2026-06-01 16:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→16→17
* 開始   : 2026-06-01 17:45:00 (UTC)
* 終了   : 2026-06-01 17:45:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-009 active_connections の推移](charts/EVT-20260601-host03-009.svg)

# イベントID( EVT-20260602-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→14→17→15→15
* 開始   : 2026-06-02 05:25:00 (UTC)
* 終了   : 2026-06-02 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→14→19→17→15
* 開始   : 2026-06-02 06:05:00 (UTC)
* 終了   : 2026-06-02 06:05:00 (UTC)
* 現象   : 平常時(14)に対し 1.357倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→20→19→21→20→19
* 開始   : 2026-06-02 07:50:00 (UTC)
* 終了   : 2026-06-02 07:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→11→…→15→13→16→12
* 開始   : 2026-06-03 04:30:00 (UTC)
* 終了   : 2026-06-03 04:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→15→15
* 開始   : 2026-06-03 05:25:00 (UTC)
* 終了   : 2026-06-03 05:25:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→20→23→19→…→19→21→17→20
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.314倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.831σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host03-006 active_connections の推移](charts/EVT-20260603-host03-006.svg)

# イベントID( EVT-20260603-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→20→26→22→20
* 開始   : 2026-06-03 11:20:00 (UTC)
* 終了   : 2026-06-03 11:20:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260603-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→11→14→8→9
* 開始   : 2026-06-04 03:30:00 (UTC)
* 終了   : 2026-06-04 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→12→17→15→11
* 開始   : 2026-06-04 05:00:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→21→17→21→21
* 開始   : 2026-06-04 13:50:00 (UTC)
* 終了   : 2026-06-04 13:50:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→17→15
* 開始   : 2026-06-04 17:35:00 (UTC)
* 終了   : 2026-06-04 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→14→17→14→14→14→14→15→14
* 開始   : 2026-06-04 18:15:00 (UTC)
* 終了   : 2026-06-04 19:40:00 (UTC)
* 現象   : 2026-06-04 19:40:00 (UTC)を境に水準が 14.96から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→15→10→14→14
* 開始   : 2026-06-04 18:30:00 (UTC)
* 終了   : 2026-06-04 18:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.6557(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.658σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-012 active_connections の推移](charts/EVT-20260604-host03-012.svg)

# イベントID( EVT-20260604-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→12→13
* 開始   : 2026-06-04 20:00:00 (UTC)
* 終了   : 2026-06-04 20:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.715σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260604-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host03-014 active_connections の推移](charts/EVT-20260604-host03-014.svg)

# イベントID( EVT-20260605-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→11→14→11→9
* 開始   : 2026-06-05 03:15:00 (UTC)
* 終了   : 2026-06-05 03:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→12→15→11→11
* 開始   : 2026-06-05 03:55:00 (UTC)
* 終了   : 2026-06-05 03:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→17→19→17→15
* 開始   : 2026-06-05 06:25:00 (UTC)
* 終了   : 2026-06-05 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→18→22→16→18
* 開始   : 2026-06-05 07:50:00 (UTC)
* 終了   : 2026-06-05 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→21→16→19→22
* 開始   : 2026-06-05 14:45:00 (UTC)
* 終了   : 2026-06-05 14:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→21→16→18→14→16→18→14→17
* 開始   : 2026-06-05 16:30:00 (UTC)
* 終了   : 2026-06-05 16:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→13→10→14→15
* 開始   : 2026-06-05 19:00:00 (UTC)
* 終了   : 2026-06-05 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→12→…→13→11→13→12
* 開始   : 2026-06-06 04:30:00 (UTC)
* 終了   : 2026-06-06 18:30:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 13.8 時間
  - EVT-20260606-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.7 時間

![EVT-20260606-host03-001 active_connections の推移](charts/EVT-20260606-host03-001.svg)

# イベントID( EVT-20260606-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→11→…→11→12→14→12
* 開始   : 2026-06-06 04:50:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.031, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260606-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host03-002 active_connections の推移](charts/EVT-20260606-host03-002.svg)

# イベントID( EVT-20260606-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→14→10→13→…→9→13→10→11
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host03-003 active_connections の推移](charts/EVT-20260606-host03-003.svg)

# イベントID( EVT-20260606-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→12→…→11→12→8→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.764, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host03-004 active_connections の推移](charts/EVT-20260606-host03-004.svg)

# イベントID( EVT-20260606-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→10→…→12→11→12→10
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260606-host03-005 active_connections の推移](charts/EVT-20260606-host03-005.svg)

# イベントID( EVT-20260606-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→14→…→13→12→11→15
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260606-host03-006 active_connections の推移](charts/EVT-20260606-host03-006.svg)

# イベントID( EVT-20260606-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→7→5→9→9
* 開始   : 2026-06-06 21:25:00 (UTC)
* 終了   : 2026-06-06 21:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→7→5→7→10
* 開始   : 2026-06-06 22:00:00 (UTC)
* 終了   : 2026-06-06 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260606-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 7→9→13→9→…→9→5→8→7
* 開始   : 2026-06-07 00:10:00 (UTC)
* 終了   : 2026-06-07 00:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→14→13
* 開始   : 2026-06-07 07:40:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→12→8→10→13
* 開始   : 2026-06-07 16:50:00 (UTC)
* 終了   : 2026-06-07 16:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→17→…→15→14→11→12
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→9→10
* 開始   : 2026-06-09 01:45:00 (UTC)
* 終了   : 2026-06-09 01:45:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→23→18→21→…→21→19→22→20
* 開始   : 2026-06-09 13:35:00 (UTC)
* 終了   : 2026-06-09 13:45:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→20→16→20→19
* 開始   : 2026-06-09 15:00:00 (UTC)
* 終了   : 2026-06-09 15:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→11→13→10→11→13
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 19:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→12→11
* 開始   : 2026-06-09 19:55:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→9→4→6→9
* 開始   : 2026-06-09 22:20:00 (UTC)
* 終了   : 2026-06-09 22:20:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→11→13→10→…→10→15→10→9
* 開始   : 2026-06-10 03:15:00 (UTC)
* 終了   : 2026-06-10 03:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→14→10→14→12→14→12
* 開始   : 2026-06-10 04:05:00 (UTC)
* 終了   : 2026-06-10 05:00:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260610-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260610-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→16→11→12→15→16→11
* 開始   : 2026-06-10 04:15:00 (UTC)
* 終了   : 2026-06-10 04:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→16→18
* 開始   : 2026-06-10 07:15:00 (UTC)
* 終了   : 2026-06-10 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→16→21→19→17
* 開始   : 2026-06-10 07:30:00 (UTC)
* 終了   : 2026-06-10 07:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→11→9→11→14
* 開始   : 2026-06-10 19:40:00 (UTC)
* 終了   : 2026-06-10 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→8→4→6→7
* 開始   : 2026-06-10 22:50:00 (UTC)
* 終了   : 2026-06-10 22:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→14→14
* 開始   : 2026-06-11 05:40:00 (UTC)
* 終了   : 2026-06-11 05:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→17→22→19→19
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→23→18→19
* 開始   : 2026-06-11 09:00:00 (UTC)
* 終了   : 2026-06-11 09:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→21→17→21→22
* 開始   : 2026-06-11 14:30:00 (UTC)
* 終了   : 2026-06-11 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→13→13→14→12→14→13
* 開始   : 2026-06-11 17:45:00 (UTC)
* 終了   : 2026-06-11 19:30:00 (UTC)
* 現象   : 2026-06-11 19:30:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.16σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-013 active_connections の推移](charts/EVT-20260611-host03-013.svg)

# イベントID( EVT-20260612-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→11→15→12→12
* 開始   : 2026-06-12 03:50:00 (UTC)
* 終了   : 2026-06-12 03:50:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-019 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host03-001 active_connections の推移](charts/EVT-20260612-host03-001.svg)

# イベントID( EVT-20260612-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→19→22→16→…→22→16→18→20
* 開始   : 2026-06-12 07:55:00 (UTC)
* 終了   : 2026-06-12 08:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.38倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-044 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-004 active_connections の推移](charts/EVT-20260612-host03-004.svg)

# イベントID( EVT-20260612-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→16→23→19→19
* 開始   : 2026-06-12 08:50:00 (UTC)
* 終了   : 2026-06-12 08:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→10→12→8→10
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 20:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260612-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→13→8→13→8→13→9
* 開始   : 2026-06-12 20:55:00 (UTC)
* 終了   : 2026-06-12 22:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-089 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host11-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host11-019 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-090 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260612-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→10→…→12→13→14→13
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host03-004 active_connections の推移](charts/EVT-20260613-host03-004.svg)

# イベントID( EVT-20260613-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→9→…→13→11→13→11
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260613-host03-005 active_connections の推移](charts/EVT-20260613-host03-005.svg)

# イベントID( EVT-20260613-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→9→…→12→14→11→10
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.761, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host03-006 active_connections の推移](charts/EVT-20260613-host03-006.svg)

# イベントID( EVT-20260613-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→10→…→14→11→14→11
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.686σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host03-007 active_connections の推移](charts/EVT-20260613-host03-007.svg)

# イベントID( EVT-20260613-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→13→11→12→…→13→14→13→12
* 開始   : 2026-06-13 05:40:00 (UTC)
* 終了   : 2026-06-13 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260613-host03-008 active_connections の推移](charts/EVT-20260613-host03-008.svg)

# イベントID( EVT-20260613-host03-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→11→12→14→…→10→12→8→11
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.986, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host03-009 active_connections の推移](charts/EVT-20260613-host03-009.svg)

# イベントID( EVT-20260615-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→…→14→12→11→12
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.85から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→7→3→9→9
* 開始   : 2026-06-15 23:15:00 (UTC)
* 終了   : 2026-06-15 23:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.3462(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.948σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host03-007 active_connections の推移](charts/EVT-20260615-host03-007.svg)

# イベントID( EVT-20260615-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→9→4→5→…→4→5→7→10
* 開始   : 2026-06-15 23:20:00 (UTC)
* 終了   : 2026-06-15 23:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→14→…→14→10→12→11
* 開始   : 2026-06-16 18:50:00 (UTC)
* 終了   : 2026-06-16 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.691σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→12→13
* 開始   : 2026-06-16 19:25:00 (UTC)
* 終了   : 2026-06-16 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→13→11
* 開始   : 2026-06-16 19:45:00 (UTC)
* 終了   : 2026-06-16 19:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→10→10
* 開始   : 2026-06-16 21:35:00 (UTC)
* 終了   : 2026-06-16 21:35:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→5→6→9→5→6→9→10
* 開始   : 2026-06-16 21:45:00 (UTC)
* 終了   : 2026-06-16 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 7→6→12→8→7
* 開始   : 2026-06-17 01:05:00 (UTC)
* 終了   : 2026-06-17 01:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→11→11
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→13→16→11→14
* 開始   : 2026-06-17 04:35:00 (UTC)
* 終了   : 2026-06-17 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→20→17→20→17→20→17→18
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→18→20→21→…→17→20→18→19
* 開始   : 2026-06-17 07:40:00 (UTC)
* 終了   : 2026-06-17 08:50:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 45 分
  - EVT-20260617-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260617-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260617-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→23→21
* 開始   : 2026-06-17 14:20:00 (UTC)
* 終了   : 2026-06-17 14:20:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→21→19→18→17→20→20
* 開始   : 2026-06-17 16:15:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 2026-06-17 17:20:00 (UTC)を境に水準が 14.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.823, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→14→11→14→14
* 開始   : 2026-06-17 18:25:00 (UTC)
* 終了   : 2026-06-17 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→17→15→13→13→14→13→12→14
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 20:35:00 (UTC)
* 現象   : 2026-06-17 20:35:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.68, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→17→20→15→16→19
* 開始   : 2026-06-18 05:55:00 (UTC)
* 終了   : 2026-06-18 06:50:00 (UTC)
* 現象   : 2026-06-18 06:50:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→17→20→19→…→19→20→19→18
* 開始   : 2026-06-18 07:20:00 (UTC)
* 終了   : 2026-06-18 07:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→13→14→11→13→12
* 開始   : 2026-06-18 18:40:00 (UTC)
* 終了   : 2026-06-18 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→17→16→20→17→20→20→16→19
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 07:30:00 (UTC)
* 現象   : 2026-06-19 07:30:00 (UTC)を境に水準が 14.98から14.46へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→22→20→16
* 開始   : 2026-06-19 07:55:00 (UTC)
* 終了   : 2026-06-19 07:55:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→18→16→20→18
* 開始   : 2026-06-19 15:25:00 (UTC)
* 終了   : 2026-06-19 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→18→15→18→18
* 開始   : 2026-06-19 16:05:00 (UTC)
* 終了   : 2026-06-19 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→15→15→17→16→15→15
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 2026-06-19 18:25:00 (UTC)を境に水準が 15.05から12.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.984σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-008 active_connections の推移](charts/EVT-20260619-host03-008.svg)

# イベントID( EVT-20260619-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→11→10
* 開始   : 2026-06-19 20:45:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.308σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→9→5→10→9
* 開始   : 2026-06-19 22:35:00 (UTC)
* 終了   : 2026-06-19 22:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→6→12→9→8
* 開始   : 2026-06-20 01:10:00 (UTC)
* 終了   : 2026-06-20 01:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→9→8
* 開始   : 2026-06-20 01:20:00 (UTC)
* 終了   : 2026-06-20 01:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→12→14→12
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.917, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host03-004 active_connections の推移](charts/EVT-20260620-host03-004.svg)

# イベントID( EVT-20260620-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→12→10→12→…→9→11→13→11
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 20:40:00 (UTC)
* 現象   : 15.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.358, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260620-host03-005 active_connections の推移](charts/EVT-20260620-host03-005.svg)

# イベントID( EVT-20260620-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→11→…→11→14→12→13
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host03-006 active_connections の推移](charts/EVT-20260620-host03-006.svg)

# イベントID( EVT-20260620-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→13→…→10→11→12→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:45:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.988, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260620-host03-007 active_connections の推移](charts/EVT-20260620-host03-007.svg)

# イベントID( EVT-20260620-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→13→…→13→12→13→12
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260620-host03-008 active_connections の推移](charts/EVT-20260620-host03-008.svg)

# イベントID( EVT-20260620-host03-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→12→14→12→…→12→13→12→11
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 18:05:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.758, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260620-host03-009 active_connections の推移](charts/EVT-20260620-host03-009.svg)

# イベントID( EVT-20260621-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→16→12→16→16
* 開始   : 2026-06-21 11:40:00 (UTC)
* 終了   : 2026-06-21 11:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→9→9
* 開始   : 2026-06-21 20:00:00 (UTC)
* 終了   : 2026-06-21 20:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→6→11→7→6→11→7→9→11
* 開始   : 2026-06-21 20:50:00 (UTC)
* 終了   : 2026-06-21 21:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→10→5→10→11
* 開始   : 2026-06-21 22:45:00 (UTC)
* 終了   : 2026-06-21 22:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→17→…→14→13→11→12
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 19:25:00 (UTC)
* 現象   : 2026-06-22 19:25:00 (UTC)を境に水準が 11.77から15.16へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 7→10→13→10→8
* 開始   : 2026-06-22 22:30:00 (UTC)
* 終了   : 2026-06-22 22:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→7→13→8→7
* 開始   : 2026-06-23 02:10:00 (UTC)
* 終了   : 2026-06-23 02:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→10→8
* 開始   : 2026-06-23 20:55:00 (UTC)
* 終了   : 2026-06-23 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.707σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host03-007 active_connections の推移](charts/EVT-20260623-host03-007.svg)

# イベントID( EVT-20260624-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→15→17→15→14
* 開始   : 2026-06-24 05:25:00 (UTC)
* 終了   : 2026-06-24 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→13→16
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→15→18→17→15→18→17→15
* 開始   : 2026-06-24 06:00:00 (UTC)
* 終了   : 2026-06-24 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→17→19
* 開始   : 2026-06-24 07:35:00 (UTC)
* 終了   : 2026-06-24 07:35:00 (UTC)
* 現象   : 平常時(17)に対し 1.294倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-005 active_connections の推移](charts/EVT-20260624-host03-005.svg)

# イベントID( EVT-20260625-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→12→12
* 開始   : 2026-06-25 03:45:00 (UTC)
* 終了   : 2026-06-25 03:45:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→16→22→20→19
* 開始   : 2026-06-25 08:05:00 (UTC)
* 終了   : 2026-06-25 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→17→18→15→17→18→15→18
* 開始   : 2026-06-25 16:15:00 (UTC)
* 終了   : 2026-06-25 16:25:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→17→13→18→16
* 開始   : 2026-06-25 16:55:00 (UTC)
* 終了   : 2026-06-25 16:55:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→10→10
* 開始   : 2026-06-26 03:25:00 (UTC)
* 終了   : 2026-06-26 03:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→15→…→15→17→14→17
* 開始   : 2026-06-26 05:45:00 (UTC)
* 終了   : 2026-06-26 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→23→19→16
* 開始   : 2026-06-26 08:15:00 (UTC)
* 終了   : 2026-06-26 08:15:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-006 active_connections の推移](charts/EVT-20260626-host03-006.svg)

# イベントID( EVT-20260626-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→18→23→20→19
* 開始   : 2026-06-26 08:35:00 (UTC)
* 終了   : 2026-06-26 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.296倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.65σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-007 active_connections の推移](charts/EVT-20260626-host03-007.svg)

# イベントID( EVT-20260626-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→21→25→22→20
* 開始   : 2026-06-26 10:05:00 (UTC)
* 終了   : 2026-06-26 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→14→12→…→11→10→13→10
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.917, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host03-001 active_connections の推移](charts/EVT-20260627-host03-001.svg)

# イベントID( EVT-20260627-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→12→…→11→12→13→11
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 4.005σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.053, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host03-002 active_connections の推移](charts/EVT-20260627-host03-002.svg)

# イベントID( EVT-20260627-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→11→…→9→11→12→8
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.608, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host03-003 active_connections の推移](charts/EVT-20260627-host03-003.svg)

# イベントID( EVT-20260627-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→9→10→9→…→12→10→13→12
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.275, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260627-host03-004 active_connections の推移](charts/EVT-20260627-host03-004.svg)

# イベントID( EVT-20260627-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→12→11→…→10→12→13→12
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 20:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host03-005 active_connections の推移](charts/EVT-20260627-host03-005.svg)

# イベントID( EVT-20260627-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→14→12→14→…→12→14→12→13
* 開始   : 2026-06-27 06:35:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.755, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260627-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host03-006 active_connections の推移](charts/EVT-20260627-host03-006.svg)

# イベントID( EVT-20260628-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→16→15→14→15→17
* 開始   : 2026-06-28 14:45:00 (UTC)
* 終了   : 2026-06-28 15:50:00 (UTC)
* 現象   : 2026-06-28 15:50:00 (UTC)を境に水準が 11.82から14.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.484σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.731, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→11→7→11→10
* 開始   : 2026-06-28 19:25:00 (UTC)
* 終了   : 2026-06-28 19:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→16→…→13→12→13→11
* 開始   : 2026-06-29 01:45:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.8から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host03-001 active_connections の推移](charts/EVT-20260629-host03-001.svg)

# イベントID( EVT-20260630-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→8→13→10→9
* 開始   : 2026-06-30 02:15:00 (UTC)
* 終了   : 2026-06-30 02:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→13→17→15→15
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→21→20→21→21→19→21→20→22
* 開始   : 2026-06-30 08:30:00 (UTC)
* 終了   : 2026-06-30 09:25:00 (UTC)
* 現象   : 2026-06-30 09:25:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 25→22→25→23→23→23
* 開始   : 2026-06-30 12:35:00 (UTC)
* 終了   : 2026-06-30 13:35:00 (UTC)
* 現象   : 2026-06-30 13:35:00 (UTC)を境に水準が 15.07から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.328, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→19→17→20→19
* 開始   : 2026-06-30 14:30:00 (UTC)
* 終了   : 2026-06-30 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→17→15
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 17:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→11→7→5→11→7→5→9→8
* 開始   : 2026-06-01 01:00:00 (UTC)
* 終了   : 2026-06-01 01:10:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→9→12→6→9→12→10
* 開始   : 2026-06-01 02:25:00 (UTC)
* 終了   : 2026-06-01 02:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→18→16→20→18→19
* 開始   : 2026-06-01 07:25:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→20→19→22→20→21
* 開始   : 2026-06-01 08:25:00 (UTC)
* 終了   : 2026-06-01 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.228倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 18→14→15→14→15→14→17
* 開始   : 2026-06-01 17:35:00 (UTC)
* 終了   : 2026-06-01 17:45:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→13→10→12→13→10→12→11
* 開始   : 2026-06-01 19:55:00 (UTC)
* 終了   : 2026-06-01 20:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260601-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→8→10→6→8
* 開始   : 2026-06-01 22:05:00 (UTC)
* 終了   : 2026-06-01 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-071 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→7→5→8→5→8→5→7→9
* 開始   : 2026-06-02 01:25:00 (UTC)
* 終了   : 2026-06-02 01:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260602-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→19→22→21→…→21→23→20→22
* 開始   : 2026-06-02 09:25:00 (UTC)
* 終了   : 2026-06-02 09:35:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→16→19→19→19→20
* 開始   : 2026-06-02 16:40:00 (UTC)
* 終了   : 2026-06-02 18:05:00 (UTC)
* 現象   : 2026-06-02 18:05:00 (UTC)を境に水準が 15.08から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→8→11→10→8→11→8
* 開始   : 2026-06-02 21:05:00 (UTC)
* 終了   : 2026-06-02 21:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→10→11→8→12→10→10→11→12
* 開始   : 2026-06-03 01:25:00 (UTC)
* 終了   : 2026-06-03 03:40:00 (UTC)
* 現象   : 2026-06-03 03:40:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→19→16→18→19→16
* 開始   : 2026-06-03 06:45:00 (UTC)
* 終了   : 2026-06-03 06:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→19→17→19→14→18
* 開始   : 2026-06-03 06:50:00 (UTC)
* 終了   : 2026-06-03 07:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260603-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→20→23→21→24→23→21→24→21
* 開始   : 2026-06-03 09:40:00 (UTC)
* 終了   : 2026-06-03 09:50:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-033 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260603-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→19→21→17→19→17
* 開始   : 2026-06-03 15:50:00 (UTC)
* 終了   : 2026-06-03 15:55:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→14→16→14→16→15→15→16
* 開始   : 2026-06-03 18:15:00 (UTC)
* 終了   : 2026-06-03 18:50:00 (UTC)
* 現象   : 2026-06-03 18:50:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→19→21→17→19→21→17→20
* 開始   : 2026-06-04 07:55:00 (UTC)
* 終了   : 2026-06-04 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→23→22→23→19→21→23
* 開始   : 2026-06-04 08:15:00 (UTC)
* 終了   : 2026-06-04 09:45:00 (UTC)
* 現象   : 2026-06-04 09:45:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→21→18→21→18→21→20→19
* 開始   : 2026-06-04 08:15:00 (UTC)
* 終了   : 2026-06-04 08:25:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→19→20→21→22
* 開始   : 2026-06-04 14:50:00 (UTC)
* 終了   : 2026-06-04 15:10:00 (UTC)
* 現象   : 2026-06-04 15:10:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→21→16→21→16→21→20
* 開始   : 2026-06-04 15:45:00 (UTC)
* 終了   : 2026-06-04 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→17→17→16→15→17→18
* 開始   : 2026-06-04 17:30:00 (UTC)
* 終了   : 2026-06-04 18:20:00 (UTC)
* 現象   : 2026-06-04 18:20:00 (UTC)を境に水準が 14.96から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→11→…→14→11→14→12
* 開始   : 2026-06-04 19:00:00 (UTC)
* 終了   : 2026-06-04 19:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host03-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→10→11
* 開始   : 2026-06-04 22:45:00 (UTC)
* 終了   : 2026-06-04 22:55:00 (UTC)
* 現象   : 2026-06-04 22:55:00 (UTC)を境に水準が 14.96から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→15→12→16→15→12→16→14→12
* 開始   : 2026-06-05 04:45:00 (UTC)
* 終了   : 2026-06-05 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→15→13→12→15→13
* 開始   : 2026-06-05 04:50:00 (UTC)
* 終了   : 2026-06-05 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→17→12→16→…→16→18→16→17
* 開始   : 2026-06-05 06:35:00 (UTC)
* 終了   : 2026-06-05 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→18→19→19→19→21→20
* 開始   : 2026-06-05 07:35:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 2026-06-05 08:05:00 (UTC)を境に水準が 14.98から14.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→21→19→17→21→19
* 開始   : 2026-06-05 08:00:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 24→20→22→21→23→23→21→21→23
* 開始   : 2026-06-05 12:40:00 (UTC)
* 終了   : 2026-06-05 14:05:00 (UTC)
* 現象   : 2026-06-05 14:05:00 (UTC)を境に水準が 14.91から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 22→22→22→20→20→23→20→23→21
* 開始   : 2026-06-05 13:40:00 (UTC)
* 終了   : 2026-06-05 14:25:00 (UTC)
* 現象   : 2026-06-05 14:25:00 (UTC)を境に水準が 15.04から12.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.175, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→10→…→11→10→13→11
* 開始   : 2026-06-05 19:10:00 (UTC)
* 終了   : 2026-06-05 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→8→12→6→…→11→6→10→9
* 開始   : 2026-06-05 22:45:00 (UTC)
* 終了   : 2026-06-05 23:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→9→12→9→10
* 開始   : 2026-06-07 03:05:00 (UTC)
* 終了   : 2026-06-07 03:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260607-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→13→10→6→13→10→6→10
* 開始   : 2026-06-07 03:30:00 (UTC)
* 終了   : 2026-06-07 03:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.458倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.871σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260607-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→12→…→12→14→10→11
* 開始   : 2026-06-07 04:50:00 (UTC)
* 終了   : 2026-06-07 05:00:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→12→12→13→14→13→11→12→11
* 開始   : 2026-06-07 04:50:00 (UTC)
* 終了   : 2026-06-07 05:45:00 (UTC)
* 現象   : 2026-06-07 05:45:00 (UTC)を境に水準が 11.8から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→14→13→13→16
* 開始   : 2026-06-07 06:55:00 (UTC)
* 終了   : 2026-06-07 07:25:00 (UTC)
* 現象   : 2026-06-07 07:25:00 (UTC)を境に水準が 11.88から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→15→14→18→15→16→16
* 開始   : 2026-06-07 09:05:00 (UTC)
* 終了   : 2026-06-07 09:55:00 (UTC)
* 現象   : 2026-06-07 09:55:00 (UTC)を境に水準が 11.78から12.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.731, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→18→17→16
* 開始   : 2026-06-07 09:30:00 (UTC)
* 終了   : 2026-06-07 09:55:00 (UTC)
* 現象   : 2026-06-07 09:55:00 (UTC)を境に水準が 11.87から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→17→17→17→14→17→16
* 開始   : 2026-06-07 11:15:00 (UTC)
* 終了   : 2026-06-07 12:15:00 (UTC)
* 現象   : 2026-06-07 12:15:00 (UTC)を境に水準が 11.83から13.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→14→13→10→12
* 開始   : 2026-06-07 18:50:00 (UTC)
* 終了   : 2026-06-07 19:15:00 (UTC)
* 現象   : 2026-06-07 19:15:00 (UTC)を境に水準が 11.85から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→11→11→10→13
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 02:20:00 (UTC)
* 現象   : 2026-06-08 02:20:00 (UTC)を境に水準が 11.79から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→13→11→12→10→12
* 開始   : 2026-06-09 03:10:00 (UTC)
* 終了   : 2026-06-09 03:35:00 (UTC)
* 現象   : 2026-06-09 03:35:00 (UTC)を境に水準が 15.11から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→15→10→16→15→10→16→13→12
* 開始   : 2026-06-09 04:50:00 (UTC)
* 終了   : 2026-06-09 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260609-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→16→17→20→16→19
* 開始   : 2026-06-09 07:20:00 (UTC)
* 終了   : 2026-06-09 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→19→21→19→21→21→23→21→20
* 開始   : 2026-06-09 08:15:00 (UTC)
* 終了   : 2026-06-09 09:40:00 (UTC)
* 現象   : 2026-06-09 09:40:00 (UTC)を境に水準が 14.97から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→21→17→22→17→22→17→18
* 開始   : 2026-06-09 15:25:00 (UTC)
* 終了   : 2026-06-09 15:35:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→16→13→14→…→14→12→14→15
* 開始   : 2026-06-09 17:50:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 8→7→11→12→7→11→12→7→8
* 開始   : 2026-06-10 01:20:00 (UTC)
* 終了   : 2026-06-10 01:25:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 7→9→11→12→…→11→12→9→11
* 開始   : 2026-06-10 02:15:00 (UTC)
* 終了   : 2026-06-10 02:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→11→8→5→11
* 開始   : 2026-06-10 02:20:00 (UTC)
* 終了   : 2026-06-10 02:25:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→14→15→17→14
* 開始   : 2026-06-10 05:35:00 (UTC)
* 終了   : 2026-06-10 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→16→17→16→18→18→16
* 開始   : 2026-06-10 05:40:00 (UTC)
* 終了   : 2026-06-10 06:45:00 (UTC)
* 現象   : 2026-06-10 06:45:00 (UTC)を境に水準が 14.95から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.115, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→18→…→17→18→16→15
* 開始   : 2026-06-10 06:15:00 (UTC)
* 終了   : 2026-06-10 06:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→23→22→21→21→24→22
* 開始   : 2026-06-10 13:35:00 (UTC)
* 終了   : 2026-06-10 14:05:00 (UTC)
* 現象   : 2026-06-10 14:05:00 (UTC)を境に水準が 14.96から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→12→15→17→12→15→16
* 開始   : 2026-06-10 18:15:00 (UTC)
* 終了   : 2026-06-10 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→10→10
* 開始   : 2026-06-11 01:40:00 (UTC)
* 終了   : 2026-06-11 01:50:00 (UTC)
* 現象   : 2026-06-11 01:50:00 (UTC)を境に水準が 14.87から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.096, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→9→12→11→9→12→11
* 開始   : 2026-06-11 03:15:00 (UTC)
* 終了   : 2026-06-11 03:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260611-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→13→11→14→13
* 開始   : 2026-06-11 04:10:00 (UTC)
* 終了   : 2026-06-11 04:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→13→12→15→13→11
* 開始   : 2026-06-11 04:55:00 (UTC)
* 終了   : 2026-06-11 05:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→15→14→15→14→15→14
* 開始   : 2026-06-11 05:00:00 (UTC)
* 終了   : 2026-06-11 05:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→17→21→18→…→18→14→19→18
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.902σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→17→14→17→20→14→17→20→19
* 開始   : 2026-06-11 07:40:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 22→21→18→20→21→18→20→18
* 開始   : 2026-06-11 15:00:00 (UTC)
* 終了   : 2026-06-11 15:05:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→11→8→10→…→10→7→10→9
* 開始   : 2026-06-11 20:20:00 (UTC)
* 終了   : 2026-06-11 21:05:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 20 分
  - EVT-20260611-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host03-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→10→10→8→9→8
* 開始   : 2026-06-11 23:35:00 (UTC)
* 終了   : 2026-06-12 00:10:00 (UTC)
* 現象   : 2026-06-12 00:10:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→12→13→13→14→13
* 開始   : 2026-06-12 04:05:00 (UTC)
* 終了   : 2026-06-12 04:40:00 (UTC)
* 現象   : 2026-06-12 04:40:00 (UTC)を境に水準が 15.06から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→20→19→20→19→20→18→19
* 開始   : 2026-06-12 07:35:00 (UTC)
* 終了   : 2026-06-12 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→20→19→…→19→21→17→19
* 開始   : 2026-06-12 07:55:00 (UTC)
* 終了   : 2026-06-12 08:05:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 25→21→23→23→21→23→23→22→24
* 開始   : 2026-06-12 11:35:00 (UTC)
* 終了   : 2026-06-12 12:55:00 (UTC)
* 現象   : 2026-06-12 12:55:00 (UTC)を境に水準が 15.01から13.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 23→23→25→22→23→23→22→23→23
* 開始   : 2026-06-12 13:00:00 (UTC)
* 終了   : 2026-06-12 13:40:00 (UTC)
* 現象   : 2026-06-12 13:40:00 (UTC)を境に水準が 15.14から13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.416, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 23→21→18→19→…→19→17→20→18
* 開始   : 2026-06-12 15:05:00 (UTC)
* 終了   : 2026-06-12 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→16→14→13→…→16→13→15→14
* 開始   : 2026-06-12 17:50:00 (UTC)
* 終了   : 2026-06-12 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→12→11→12→…→12→11→13→12
* 開始   : 2026-06-12 18:45:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→9→7→11→9→11
* 開始   : 2026-06-13 00:20:00 (UTC)
* 終了   : 2026-06-13 00:45:00 (UTC)
* 現象   : 2026-06-13 00:45:00 (UTC)を境に水準が 15.04から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260613-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→12→7→10→…→10→14→13→10
* 開始   : 2026-06-13 04:20:00 (UTC)
* 終了   : 2026-06-13 04:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→10→8→11→…→9→11→12→10
* 開始   : 2026-06-13 04:25:00 (UTC)
* 終了   : 2026-06-13 05:00:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.099, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 35 分
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260613-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分

![EVT-20260613-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→10→14→10→14→11
* 開始   : 2026-06-13 20:05:00 (UTC)
* 終了   : 2026-06-13 20:15:00 (UTC)
* 現象   : 土曜20時台の平常値(9.594)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.332σ 外れた (平常値=9.594)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260613-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260613-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→16→16→17→16→16→17→17→17
* 開始   : 2026-06-14 12:10:00 (UTC)
* 終了   : 2026-06-14 12:55:00 (UTC)
* 現象   : 2026-06-14 12:55:00 (UTC)を境に水準が 11.92から13.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→5→12→9→10→5→12→9
* 開始   : 2026-06-14 21:40:00 (UTC)
* 終了   : 2026-06-14 21:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→14→15→16→14→15
* 開始   : 2026-06-16 05:25:00 (UTC)
* 終了   : 2026-06-16 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→14→15→19→14→16→17
* 開始   : 2026-06-16 16:50:00 (UTC)
* 終了   : 2026-06-16 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260616-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→15→17→14→15→17→14→17→15
* 開始   : 2026-06-16 17:10:00 (UTC)
* 終了   : 2026-06-16 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→7→10→11→9→10→11→11→11
* 開始   : 2026-06-17 02:10:00 (UTC)
* 終了   : 2026-06-17 02:50:00 (UTC)
* 現象   : 2026-06-17 02:50:00 (UTC)を境に水準が 14.84から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.416, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→17→19→16→17→19→16→17
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 20→20→20→22→21→20→20→21→21
* 開始   : 2026-06-17 08:20:00 (UTC)
* 終了   : 2026-06-17 09:30:00 (UTC)
* 現象   : 2026-06-17 09:30:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.653, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→19→16→15→…→16→15→17→18
* 開始   : 2026-06-17 15:40:00 (UTC)
* 終了   : 2026-06-17 15:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.636σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→15→14→15→19→15→14→15→17
* 開始   : 2026-06-17 16:40:00 (UTC)
* 終了   : 2026-06-17 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→7→6→12→…→6→12→9→11
* 開始   : 2026-06-17 21:50:00 (UTC)
* 終了   : 2026-06-17 21:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260617-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→11→12→11→12→11→10
* 開始   : 2026-06-18 03:00:00 (UTC)
* 終了   : 2026-06-18 03:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→21→17→22→21→17→22→19
* 開始   : 2026-06-18 08:25:00 (UTC)
* 終了   : 2026-06-18 08:35:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→23→20→23→22→23→22
* 開始   : 2026-06-18 09:30:00 (UTC)
* 終了   : 2026-06-18 09:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→21→21→21→19→20→20→22
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 15:30:00 (UTC)
* 現象   : 2026-06-18 15:30:00 (UTC)を境に水準が 15.04から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→21→21→20→20→19→19→19→19
* 開始   : 2026-06-18 15:05:00 (UTC)
* 終了   : 2026-06-18 15:50:00 (UTC)
* 現象   : 2026-06-18 15:50:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→19→17→16→19→18
* 開始   : 2026-06-18 15:45:00 (UTC)
* 終了   : 2026-06-18 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→14→16→19→14→16
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:10:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→13→…→14→13→18→16
* 開始   : 2026-06-18 17:20:00 (UTC)
* 終了   : 2026-06-18 17:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→14→16→12→14→16
* 開始   : 2026-06-18 18:25:00 (UTC)
* 終了   : 2026-06-18 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→8→11→12→8→11→12
* 開始   : 2026-06-18 20:25:00 (UTC)
* 終了   : 2026-06-18 20:30:00 (UTC)
* 現象   : 平常時(12)に対し 0.6667(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.812σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→12→13→14
* 開始   : 2026-06-19 03:40:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 2026-06-19 03:55:00 (UTC)を境に水準が 15.1から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→20→22→21→21→20→19→21→21
* 開始   : 2026-06-19 14:45:00 (UTC)
* 終了   : 2026-06-19 15:45:00 (UTC)
* 現象   : 2026-06-19 15:45:00 (UTC)を境に水準が 14.96から12.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→15→12→11→…→12→11→10→13
* 開始   : 2026-06-19 18:30:00 (UTC)
* 終了   : 2026-06-19 18:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→6→11→8→5→11→8→5→9
* 開始   : 2026-06-20 01:45:00 (UTC)
* 終了   : 2026-06-20 01:55:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→15→16→15→17→16→17
* 開始   : 2026-06-21 09:10:00 (UTC)
* 終了   : 2026-06-21 09:40:00 (UTC)
* 現象   : 2026-06-21 09:40:00 (UTC)を境に水準が 11.88から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→16→15→16→17→17→19→17→16
* 開始   : 2026-06-21 13:00:00 (UTC)
* 終了   : 2026-06-21 13:45:00 (UTC)
* 現象   : 2026-06-21 13:45:00 (UTC)を境に水準が 11.85から13.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→12→8→12→11→9
* 開始   : 2026-06-23 02:25:00 (UTC)
* 終了   : 2026-06-23 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→11→16→11→16→12→13
* 開始   : 2026-06-23 05:15:00 (UTC)
* 終了   : 2026-06-23 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→19→23→24→…→23→24→21→20
* 開始   : 2026-06-23 09:35:00 (UTC)
* 終了   : 2026-06-23 09:40:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 23→19→24→21→…→21→18→21→20
* 開始   : 2026-06-23 13:55:00 (UTC)
* 終了   : 2026-06-23 14:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→14→12→15→12→15→12→13→14
* 開始   : 2026-06-23 18:25:00 (UTC)
* 終了   : 2026-06-23 19:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260623-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 17→17→18→18→17→19→16→20→18
* 開始   : 2026-06-24 06:45:00 (UTC)
* 終了   : 2026-06-24 07:40:00 (UTC)
* 現象   : 2026-06-24 07:40:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→21→23→20→…→20→24→21→20
* 開始   : 2026-06-24 09:30:00 (UTC)
* 終了   : 2026-06-24 09:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260624-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→20→16→20→16→17→18
* 開始   : 2026-06-24 16:05:00 (UTC)
* 終了   : 2026-06-24 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→18→17→19
* 開始   : 2026-06-24 16:40:00 (UTC)
* 終了   : 2026-06-24 17:05:00 (UTC)
* 現象   : 2026-06-24 17:05:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→6→11→7→6→11→7→10
* 開始   : 2026-06-25 01:35:00 (UTC)
* 終了   : 2026-06-25 01:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-003 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→12→9→6→12→9→6→8
* 開始   : 2026-06-25 01:35:00 (UTC)
* 終了   : 2026-06-25 01:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-003 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→17→14→17→14→17→13→14
* 開始   : 2026-06-25 05:30:00 (UTC)
* 終了   : 2026-06-25 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→24→22→23→24
* 開始   : 2026-06-25 10:05:00 (UTC)
* 終了   : 2026-06-25 11:20:00 (UTC)
* 現象   : 2026-06-25 11:20:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→22→17→19→…→19→16→19→17
* 開始   : 2026-06-25 15:55:00 (UTC)
* 終了   : 2026-06-25 16:05:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→13→…→14→17→15→16
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 06:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260626-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→16→18→16→14
* 開始   : 2026-06-26 06:15:00 (UTC)
* 終了   : 2026-06-26 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→16→18→19→…→18→19→15→17
* 開始   : 2026-06-26 06:35:00 (UTC)
* 終了   : 2026-06-26 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 21→21→19→21→23→22→23→20→24
* 開始   : 2026-06-26 09:00:00 (UTC)
* 終了   : 2026-06-26 09:50:00 (UTC)
* 現象   : 2026-06-26 09:50:00 (UTC)を境に水準が 15.01から13.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.679, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 19→21→24→22→24→22→24→21→22
* 開始   : 2026-06-26 10:25:00 (UTC)
* 終了   : 2026-06-26 10:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→13→…→14→13→15→17
* 開始   : 2026-06-26 17:25:00 (UTC)
* 終了   : 2026-06-26 17:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→10→13→10→13→10→12
* 開始   : 2026-06-26 19:35:00 (UTC)
* 終了   : 2026-06-26 19:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→9→7→8→6→7→10→10→10
* 開始   : 2026-06-28 00:00:00 (UTC)
* 終了   : 2026-06-28 01:15:00 (UTC)
* 現象   : 2026-06-28 01:15:00 (UTC)を境に水準が 11.8から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→12→10→12→10→12→10→9
* 開始   : 2026-06-28 03:40:00 (UTC)
* 終了   : 2026-06-28 03:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→13→13→11→14
* 開始   : 2026-06-28 05:50:00 (UTC)
* 終了   : 2026-06-28 06:10:00 (UTC)
* 現象   : 2026-06-28 06:10:00 (UTC)を境に水準が 11.73から12.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→10→7→8→7→8→7→10
* 開始   : 2026-06-28 20:20:00 (UTC)
* 終了   : 2026-06-28 20:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260628-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→7→8→9→9
* 開始   : 2026-06-28 23:20:00 (UTC)
* 終了   : 2026-06-28 23:40:00 (UTC)
* 現象   : 2026-06-28 23:40:00 (UTC)を境に水準が 11.9から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→14→12→14→11→12
* 開始   : 2026-06-30 04:05:00 (UTC)
* 終了   : 2026-06-30 04:15:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→17→…→16→17→12→15
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 05:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→22→24→21→18→24→21→18→22
* 開始   : 2026-06-30 10:40:00 (UTC)
* 終了   : 2026-06-30 10:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→19→16→19→18→18→21→19→19
* 開始   : 2026-06-30 15:50:00 (UTC)
* 終了   : 2026-06-30 16:30:00 (UTC)
* 現象   : 2026-06-30 16:30:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→13→12→12→14
* 開始   : 2026-06-30 19:35:00 (UTC)
* 終了   : 2026-06-30 20:05:00 (UTC)
* 現象   : 2026-06-30 20:05:00 (UTC)を境に水準が 14.92から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→9→11→12→9→11
* 開始   : 2026-06-30 20:05:00 (UTC)
* 終了   : 2026-06-30 20:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260630-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host03-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
