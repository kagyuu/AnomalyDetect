# host05 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host05 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 311 (SEVERE: 20, FATAL: 134, WARN: 157, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 134 | 157 | 311 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260607-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→16→11→16→11→14
* 開始   : 2026-06-07 06:30:00 (UTC)
* 終了   : 2026-06-07 06:35:00 (UTC)
* 現象   : 日曜6時台の平常値(12.26)に対し 16であった
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.01σ 外れた (平常値=12.26)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260607-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260607-host05-003 active_connections の推移](charts/EVT-20260607-host05-003.svg)

# イベントID( EVT-20260608-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→13→…→11→13→11→13
* 開始   : 2026-06-08 01:05:00 (UTC)
* 終了   : 2026-06-08 22:15:00 (UTC)
* 現象   : 2026-06-08 22:15:00 (UTC)を境に水準が 11.8から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.724, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-001 active_connections の推移](charts/EVT-20260608-host05-001.svg)

# イベントID( EVT-20260608-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→17→15→17→…→15→13→15→13
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.58から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.016, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-002 active_connections の推移](charts/EVT-20260608-host05-002.svg)

# イベントID( EVT-20260608-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→14→15→13→…→17→15→14→17
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.94から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.054, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.954, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-003 active_connections の推移](charts/EVT-20260608-host05-003.svg)

# イベントID( EVT-20260608-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→13→…→14→13→12→10
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 11.68から15.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.398σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-004 active_connections の推移](charts/EVT-20260608-host05-004.svg)

# イベントID( EVT-20260608-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→18→…→15→16→14→16
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.842σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-005 active_connections の推移](charts/EVT-20260608-host05-005.svg)

# イベントID( EVT-20260608-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→17→…→11→13→12→10
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.78から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.314, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host05-006 active_connections の推移](charts/EVT-20260608-host05-006.svg)

# イベントID( EVT-20260615-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→17→…→12→14→10→12
* 開始   : 2026-06-15 01:00:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.8から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.237, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-001 active_connections の推移](charts/EVT-20260615-host05-001.svg)

# イベントID( EVT-20260615-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→12→17→15→…→15→14→12→14
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 20:20:00 (UTC)
* 現象   : 2026-06-15 20:20:00 (UTC)を境に水準が 12から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.83, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-003 active_connections の推移](charts/EVT-20260615-host05-003.svg)

# イベントID( EVT-20260615-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→15→13→12→15
* 開始   : 2026-06-15 03:25:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.83から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.325, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-005 active_connections の推移](charts/EVT-20260615-host05-005.svg)

# イベントID( EVT-20260615-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→19→…→14→13→14→13
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 12から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-006 active_connections の推移](charts/EVT-20260615-host05-006.svg)

# イベントID( EVT-20260622-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→15→14→16→…→13→15→12→14
* 開始   : 2026-06-22 01:40:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.75から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.53σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.282, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-001 active_connections の推移](charts/EVT-20260622-host05-001.svg)

# イベントID( EVT-20260622-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→15→…→14→13→14→13
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-23 01:00:00 (UTC)
* 現象   : 2026-06-23 01:00:00 (UTC)を境に水準が 11.7から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.4, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-002 active_connections の推移](charts/EVT-20260622-host05-002.svg)

# イベントID( EVT-20260622-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→15→14→15→…→15→17→12→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.88から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.709, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-003 active_connections の推移](charts/EVT-20260622-host05-003.svg)

# イベントID( EVT-20260622-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→17→…→15→14→12→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.88から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-004 active_connections の推移](charts/EVT-20260622-host05-004.svg)

# イベントID( EVT-20260622-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→18→…→12→15→10→12
* 開始   : 2026-06-22 03:40:00 (UTC)
* 終了   : 2026-06-22 21:40:00 (UTC)
* 現象   : 2026-06-22 21:40:00 (UTC)を境に水準が 11.92から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.475, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.954, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-006 active_connections の推移](charts/EVT-20260622-host05-006.svg)

# イベントID( EVT-20260629-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→…→14→15→9→13
* 開始   : 2026-06-29 02:10:00 (UTC)
* 終了   : 2026-06-29 22:45:00 (UTC)
* 現象   : 2026-06-29 22:45:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.12, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.631, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-003 active_connections の推移](charts/EVT-20260629-host05-003.svg)

# イベントID( EVT-20260629-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→14→15→16→…→15→13→14→11
* 開始   : 2026-06-29 02:20:00 (UTC)
* 終了   : 2026-06-29 22:35:00 (UTC)
* 現象   : 2026-06-29 22:35:00 (UTC)を境に水準が 11.75から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.874, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-004 active_connections の推移](charts/EVT-20260629-host05-004.svg)

# イベントID( EVT-20260629-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→12→…→13→14→13→12
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:35:00 (UTC)
* 現象   : 2026-06-29 20:35:00 (UTC)を境に水準が 11.73から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.508, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-005 active_connections の推移](charts/EVT-20260629-host05-005.svg)

# イベントID( EVT-20260629-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→15→17→…→14→11→15→13
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 19:50:00 (UTC)
* 現象   : 2026-06-29 19:50:00 (UTC)を境に水準が 11.77から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.934, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-007 active_connections の推移](charts/EVT-20260629-host05-007.svg)

# イベントID( EVT-20260601-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→14→9→11
* 開始   : 2026-06-01 02:15:00 (UTC)
* 終了   : 2026-06-01 02:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host05-001 active_connections の推移](charts/EVT-20260601-host05-001.svg)

# イベントID( EVT-20260601-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→11→16→13→13
* 開始   : 2026-06-01 04:55:00 (UTC)
* 終了   : 2026-06-01 04:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→16→20→18→17
* 開始   : 2026-06-01 06:45:00 (UTC)
* 終了   : 2026-06-01 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 21→23→25→19→21
* 開始   : 2026-06-01 10:00:00 (UTC)
* 終了   : 2026-06-01 10:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→20→15→18→18
* 開始   : 2026-06-01 15:20:00 (UTC)
* 終了   : 2026-06-01 15:20:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-006 active_connections の推移](charts/EVT-20260601-host05-006.svg)

# イベントID( EVT-20260601-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→20→15→19→22
* 開始   : 2026-06-01 15:35:00 (UTC)
* 終了   : 2026-06-01 15:35:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 7→9→8→10→7→10→10→7→13
* 開始   : 2026-06-02 00:05:00 (UTC)
* 終了   : 2026-06-02 01:05:00 (UTC)
* 現象   : 2026-06-02 01:05:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→18→20→17→17
* 開始   : 2026-06-02 07:05:00 (UTC)
* 終了   : 2026-06-02 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→20→24→21→18
* 開始   : 2026-06-02 09:00:00 (UTC)
* 終了   : 2026-06-02 09:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.274倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host05-008 active_connections の推移](charts/EVT-20260602-host05-008.svg)

# イベントID( EVT-20260602-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→26→…→24→26→19→23
* 開始   : 2026-06-02 10:20:00 (UTC)
* 終了   : 2026-06-02 10:25:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→11→7→9→9
* 開始   : 2026-06-02 20:55:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→10→13→9→11
* 開始   : 2026-06-03 02:55:00 (UTC)
* 終了   : 2026-06-03 02:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→13→14
* 開始   : 2026-06-03 04:25:00 (UTC)
* 終了   : 2026-06-03 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→16→16
* 開始   : 2026-06-03 06:20:00 (UTC)
* 終了   : 2026-06-03 06:20:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host05-005 active_connections の推移](charts/EVT-20260603-host05-005.svg)

# イベントID( EVT-20260603-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→20→20
* 開始   : 2026-06-03 08:10:00 (UTC)
* 終了   : 2026-06-03 08:10:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.545σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host05-006 active_connections の推移](charts/EVT-20260603-host05-006.svg)

# イベントID( EVT-20260603-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→7→5→6→8
* 開始   : 2026-06-03 22:10:00 (UTC)
* 終了   : 2026-06-03 22:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→12→15→13→13
* 開始   : 2026-06-04 04:15:00 (UTC)
* 終了   : 2026-06-04 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→14→14
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→18→15→…→15→20→17→18
* 開始   : 2026-06-04 06:50:00 (UTC)
* 終了   : 2026-06-04 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host05-004 active_connections の推移](charts/EVT-20260604-host05-004.svg)

# イベントID( EVT-20260604-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→10→…→12→10→13→15
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 18:55:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→8→9
* 開始   : 2026-06-04 21:15:00 (UTC)
* 終了   : 2026-06-04 21:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.4545(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-011 active_connections の推移](charts/EVT-20260604-host05-011.svg)

# イベントID( EVT-20260605-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→16→15→12→16→15
* 開始   : 2026-06-05 05:00:00 (UTC)
* 終了   : 2026-06-05 05:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260605-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→19→13→12→16→19→13→12→16
* 開始   : 2026-06-05 17:25:00 (UTC)
* 終了   : 2026-06-05 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host05-005 active_connections の推移](charts/EVT-20260605-host05-005.svg)

# イベントID( EVT-20260605-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→15→14
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→12→12
* 開始   : 2026-06-05 19:40:00 (UTC)
* 終了   : 2026-06-05 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→10→5→7→8
* 開始   : 2026-06-05 22:30:00 (UTC)
* 終了   : 2026-06-05 22:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→8→7
* 開始   : 2026-06-06 00:20:00 (UTC)
* 終了   : 2026-06-06 00:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→9→13→14→…→13→14→13→14
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.325, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host05-002 active_connections の推移](charts/EVT-20260606-host05-002.svg)

# イベントID( EVT-20260606-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→12→11→12→…→11→10→12→11
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.142, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host05-003 active_connections の推移](charts/EVT-20260606-host05-003.svg)

# イベントID( EVT-20260606-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→12→14→13→…→9→11→9→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host05-004 active_connections の推移](charts/EVT-20260606-host05-004.svg)

# イベントID( EVT-20260606-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→10→13→10→…→15→12→13→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.214, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260606-host05-005 active_connections の推移](charts/EVT-20260606-host05-005.svg)

# イベントID( EVT-20260606-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→12→…→10→9→13→11
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.806, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host05-006 active_connections の推移](charts/EVT-20260606-host05-006.svg)

# イベントID( EVT-20260606-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→…→12→14→13→12
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:15:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.241, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260606-host05-007 active_connections の推移](charts/EVT-20260606-host05-007.svg)

# イベントID( EVT-20260607-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→10→13
* 開始   : 2026-06-07 05:35:00 (UTC)
* 終了   : 2026-06-07 05:35:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host05-002 active_connections の推移](charts/EVT-20260607-host05-002.svg)

# イベントID( EVT-20260607-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→13→17→13→13
* 開始   : 2026-06-07 07:00:00 (UTC)
* 終了   : 2026-06-07 07:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→14→19→16→17
* 開始   : 2026-06-07 12:20:00 (UTC)
* 終了   : 2026-06-07 12:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→10→7→11→9
* 開始   : 2026-06-09 20:25:00 (UTC)
* 終了   : 2026-06-09 20:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→10→15→10→13
* 開始   : 2026-06-10 03:45:00 (UTC)
* 終了   : 2026-06-10 03:45:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 22→22→17→21→23
* 開始   : 2026-06-10 12:05:00 (UTC)
* 終了   : 2026-06-10 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→23→19→22→…→23→19→21→22
* 開始   : 2026-06-10 12:40:00 (UTC)
* 終了   : 2026-06-10 14:00:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260610-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→18→…→23→15→17→20
* 開始   : 2026-06-10 16:05:00 (UTC)
* 終了   : 2026-06-10 17:05:00 (UTC)
* 現象   : 1.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260610-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→10→5→6→…→5→6→9→7
* 開始   : 2026-06-10 22:25:00 (UTC)
* 終了   : 2026-06-10 22:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260610-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→12→15→12→15→12
* 開始   : 2026-06-11 04:55:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260611-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260611-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→13→9→13→11
* 開始   : 2026-06-11 19:35:00 (UTC)
* 終了   : 2026-06-11 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→5→6→8→5→6→8→10
* 開始   : 2026-06-11 23:00:00 (UTC)
* 終了   : 2026-06-11 23:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→12→6→11→…→11→14→11→12
* 開始   : 2026-06-12 03:50:00 (UTC)
* 終了   : 2026-06-12 04:00:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-019 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→19→22→19→18
* 開始   : 2026-06-12 08:30:00 (UTC)
* 終了   : 2026-06-12 08:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 23→24→18→23→23
* 開始   : 2026-06-12 13:15:00 (UTC)
* 終了   : 2026-06-12 13:15:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 22→21→17→21→19
* 開始   : 2026-06-12 13:50:00 (UTC)
* 終了   : 2026-06-12 13:50:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→16→…→16→13→17→16
* 開始   : 2026-06-12 17:00:00 (UTC)
* 終了   : 2026-06-12 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→13→14→16→13→14→16→15
* 開始   : 2026-06-12 17:25:00 (UTC)
* 終了   : 2026-06-12 17:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→15→11→14→14
* 開始   : 2026-06-12 18:40:00 (UTC)
* 終了   : 2026-06-12 18:40:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→12→10→12→15→12→10→12→13
* 開始   : 2026-06-12 18:55:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→12→5→12→9
* 開始   : 2026-06-12 21:15:00 (UTC)
* 終了   : 2026-06-12 21:15:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.4615(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-015 active_connections の推移](charts/EVT-20260612-host05-015.svg)

# イベントID( EVT-20260612-host05-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 7→9→4→10→9
* 開始   : 2026-06-12 23:25:00 (UTC)
* 終了   : 2026-06-12 23:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host05-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host05-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→13→…→9→11→12→10
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.29, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host05-001 active_connections の推移](charts/EVT-20260613-host05-001.svg)

# イベントID( EVT-20260613-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→14→…→10→12→11→13
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host05-002 active_connections の推移](charts/EVT-20260613-host05-002.svg)

# イベントID( EVT-20260613-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→14→…→11→12→13→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host05-003 active_connections の推移](charts/EVT-20260613-host05-003.svg)

# イベントID( EVT-20260613-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→12→14→11→…→9→11→12→11
* 開始   : 2026-06-13 06:25:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.971, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260613-host05-004 active_connections の推移](charts/EVT-20260613-host05-004.svg)

# イベントID( EVT-20260613-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→12→11→13→12
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.732, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host05-005 active_connections の推移](charts/EVT-20260613-host05-005.svg)

# イベントID( EVT-20260613-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→11→13→14→…→13→12→13→15
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.107, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260613-host05-006 active_connections の推移](charts/EVT-20260613-host05-006.svg)

# イベントID( EVT-20260613-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→9→5→7→9
* 開始   : 2026-06-13 22:10:00 (UTC)
* 終了   : 2026-06-13 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→12→14→11→…→14→16→14→13
* 開始   : 2026-06-14 05:40:00 (UTC)
* 終了   : 2026-06-14 05:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260614-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260614-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→16→11→15→16→11→15→12
* 開始   : 2026-06-14 06:35:00 (UTC)
* 終了   : 2026-06-14 06:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260614-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→13→17→13→14
* 開始   : 2026-06-14 08:00:00 (UTC)
* 終了   : 2026-06-14 08:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→18→12→17→16
* 開始   : 2026-06-14 11:55:00 (UTC)
* 終了   : 2026-06-14 11:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260614-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→15→10→14→13
* 開始   : 2026-06-14 15:50:00 (UTC)
* 終了   : 2026-06-14 15:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→11→14→8→10
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 01:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260615-host05-002 active_connections の推移](charts/EVT-20260615-host05-002.svg)

# イベントID( EVT-20260615-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→16→13→16→…→14→15→13→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→16→…→16→13→14→13
* 開始   : 2026-06-15 04:25:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 12.1から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.962, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→19→24→19→…→19→23→21→22
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.309倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.969σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host05-003 active_connections の推移](charts/EVT-20260616-host05-003.svg)

# イベントID( EVT-20260616-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→18→23→19→19
* 開始   : 2026-06-16 08:35:00 (UTC)
* 終了   : 2026-06-16 08:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 23→21→16→20→20
* 開始   : 2026-06-16 14:25:00 (UTC)
* 終了   : 2026-06-16 14:25:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 23→21→16→22→20
* 開始   : 2026-06-16 14:45:00 (UTC)
* 終了   : 2026-06-16 14:45:00 (UTC)
* 現象   : 平常時(21)に対し 0.7619(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 22→18→16→20→20
* 開始   : 2026-06-16 15:00:00 (UTC)
* 終了   : 2026-06-16 15:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→18→13→16→16
* 開始   : 2026-06-16 17:10:00 (UTC)
* 終了   : 2026-06-16 17:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→15→11→15→15
* 開始   : 2026-06-16 18:20:00 (UTC)
* 終了   : 2026-06-16 18:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→18→14→16→16
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-012 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260617-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→13→12
* 開始   : 2026-06-17 19:40:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→9→7
* 開始   : 2026-06-18 00:20:00 (UTC)
* 終了   : 2026-06-18 00:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→17→21→17→16
* 開始   : 2026-06-18 07:00:00 (UTC)
* 終了   : 2026-06-18 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-007 active_connections の推移](charts/EVT-20260618-host05-007.svg)

# イベントID( EVT-20260618-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→21→…→22→21→18→19
* 開始   : 2026-06-18 08:20:00 (UTC)
* 終了   : 2026-06-18 08:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260618-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→22→26→22→22
* 開始   : 2026-06-18 11:10:00 (UTC)
* 終了   : 2026-06-18 11:10:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→17→19→21→17→19→17
* 開始   : 2026-06-18 14:10:00 (UTC)
* 終了   : 2026-06-18 15:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→13→8→11→12
* 開始   : 2026-06-18 20:05:00 (UTC)
* 終了   : 2026-06-18 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→11→11
* 開始   : 2026-06-18 20:10:00 (UTC)
* 終了   : 2026-06-18 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.609σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host05-017 active_connections の推移](charts/EVT-20260618-host05-017.svg)

# イベントID( EVT-20260619-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→20→…→18→20→17→18
* 開始   : 2026-06-19 06:40:00 (UTC)
* 終了   : 2026-06-19 06:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→12→9→13→13
* 開始   : 2026-06-19 19:15:00 (UTC)
* 終了   : 2026-06-19 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.6353(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.609σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260619-host05-008 active_connections の推移](charts/EVT-20260619-host05-008.svg)

# イベントID( EVT-20260619-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→8→4→9→9
* 開始   : 2026-06-19 23:20:00 (UTC)
* 終了   : 2026-06-19 23:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→8→12→7→9
* 開始   : 2026-06-20 01:10:00 (UTC)
* 終了   : 2026-06-20 01:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→12→…→12→10→12→11
* 開始   : 2026-06-20 03:35:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.145, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host05-002 active_connections の推移](charts/EVT-20260620-host05-002.svg)

# イベントID( EVT-20260620-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→12→…→12→11→9→10
* 開始   : 2026-06-20 04:45:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.913, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.2 時間
  - EVT-20260620-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260620-host05-003 active_connections の推移](charts/EVT-20260620-host05-003.svg)

# イベントID( EVT-20260620-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→10→…→12→10→11→9
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.909, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260620-host05-004 active_connections の推移](charts/EVT-20260620-host05-004.svg)

# イベントID( EVT-20260620-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→12→…→10→12→10→11
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host05-005 active_connections の推移](charts/EVT-20260620-host05-005.svg)

# イベントID( EVT-20260620-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→10→11→13→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.805, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host05-006 active_connections の推移](charts/EVT-20260620-host05-006.svg)

# イベントID( EVT-20260620-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→11→…→14→13→14→13
* 開始   : 2026-06-20 06:10:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.244, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host05-007 active_connections の推移](charts/EVT-20260620-host05-007.svg)

# イベントID( EVT-20260621-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→14→20→16→13
* 開始   : 2026-06-21 11:25:00 (UTC)
* 終了   : 2026-06-21 11:25:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→17→20→19→…→20→19→14→16
* 開始   : 2026-06-21 11:30:00 (UTC)
* 終了   : 2026-06-21 11:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→13→15
* 開始   : 2026-06-21 16:05:00 (UTC)
* 終了   : 2026-06-21 16:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260621-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→15→…→13→15→14→13
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.82から14.85へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-005 active_connections の推移](charts/EVT-20260622-host05-005.svg)

# イベントID( EVT-20260623-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→17→18→22→18→18→21→19→21
* 開始   : 2026-06-23 07:10:00 (UTC)
* 終了   : 2026-06-23 07:50:00 (UTC)
* 現象   : 2026-06-23 07:50:00 (UTC)を境に水準が 15.02から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.101σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-004 active_connections の推移](charts/EVT-20260623-host05-004.svg)

# イベントID( EVT-20260623-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→19→23→19→19
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:25:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-005 active_connections の推移](charts/EVT-20260623-host05-005.svg)

# イベントID( EVT-20260623-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 18→19→23→17→20
* 開始   : 2026-06-23 08:30:00 (UTC)
* 終了   : 2026-06-23 08:30:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→23→18→23→22
* 開始   : 2026-06-23 13:00:00 (UTC)
* 終了   : 2026-06-23 13:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→15→14→16→14→16→14→17→14
* 開始   : 2026-06-23 17:35:00 (UTC)
* 終了   : 2026-06-23 18:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260623-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260623-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 30 分
  - EVT-20260623-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260623-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→14→14
* 開始   : 2026-06-23 18:25:00 (UTC)
* 終了   : 2026-06-23 18:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→14→18→15→13
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→19→18→23→20
* 開始   : 2026-06-24 08:20:00 (UTC)
* 終了   : 2026-06-24 08:40:00 (UTC)
* 現象   : 2026-06-24 08:40:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→9→15→13
* 開始   : 2026-06-24 18:40:00 (UTC)
* 終了   : 2026-06-24 18:40:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6034(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-065 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host05-007 active_connections の推移](charts/EVT-20260624-host05-007.svg)

# イベントID( EVT-20260624-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→11→11
* 開始   : 2026-06-24 20:50:00 (UTC)
* 終了   : 2026-06-24 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-071 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→13→14
* 開始   : 2026-06-25 05:00:00 (UTC)
* 終了   : 2026-06-25 05:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→16→20→16→17
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-004 active_connections の推移](charts/EVT-20260625-host05-004.svg)

# イベントID( EVT-20260625-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→12→8→11→12
* 開始   : 2026-06-25 20:15:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→14→13→16
* 開始   : 2026-06-26 04:25:00 (UTC)
* 終了   : 2026-06-26 05:50:00 (UTC)
* 現象   : 2026-06-26 05:50:00 (UTC)を境に水準が 14.93から14.7へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→21→24→20→18
* 開始   : 2026-06-26 09:05:00 (UTC)
* 終了   : 2026-06-26 09:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→20→24→21→21
* 開始   : 2026-06-26 09:25:00 (UTC)
* 終了   : 2026-06-26 09:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 23→22→26→22→21
* 開始   : 2026-06-26 11:25:00 (UTC)
* 終了   : 2026-06-26 11:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→20→18→16→15→20→17
* 開始   : 2026-06-26 15:55:00 (UTC)
* 終了   : 2026-06-26 16:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260626-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→13→16→12→13→14
* 開始   : 2026-06-26 19:00:00 (UTC)
* 終了   : 2026-06-26 19:50:00 (UTC)
* 現象   : 2026-06-26 19:50:00 (UTC)を境に水準が 15.02から11.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.695σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→14→10→13→…→13→12→14→12
* 開始   : 2026-06-27 04:55:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.766, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260627-host05-001 active_connections の推移](charts/EVT-20260627-host05-001.svg)

# イベントID( EVT-20260627-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→8→10→11→…→13→12→13→11
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.284, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host05-002 active_connections の推移](charts/EVT-20260627-host05-002.svg)

# イベントID( EVT-20260627-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→14→11→14→10
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host05-003 active_connections の推移](charts/EVT-20260627-host05-003.svg)

# イベントID( EVT-20260627-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→10→…→10→11→12→10
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.955, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260627-host05-004 active_connections の推移](charts/EVT-20260627-host05-004.svg)

# イベントID( EVT-20260627-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→12→…→10→12→11→12
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.574, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host05-005 active_connections の推移](charts/EVT-20260627-host05-005.svg)

# イベントID( EVT-20260627-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→14→…→13→10→13→11
* 開始   : 2026-06-27 06:30:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.286, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260627-host05-006 active_connections の推移](charts/EVT-20260627-host05-006.svg)

# イベントID( EVT-20260628-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→13→16→13→12
* 開始   : 2026-06-28 07:05:00 (UTC)
* 終了   : 2026-06-28 07:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→8→5→9→9
* 開始   : 2026-06-28 21:40:00 (UTC)
* 終了   : 2026-06-28 21:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→9→8
* 開始   : 2026-06-29 01:40:00 (UTC)
* 終了   : 2026-06-29 01:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14→…→15→14→15→14
* 開始   : 2026-06-29 01:50:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.81から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.788, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.792, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→14→15→14→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:30:00 (UTC)
* 現象   : 2026-06-29 21:30:00 (UTC)を境に水準が 11.88から15.12へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host05-006 active_connections の推移](charts/EVT-20260629-host05-006.svg)

# イベントID( EVT-20260630-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→13→13
* 開始   : 2026-06-30 04:30:00 (UTC)
* 終了   : 2026-06-30 04:30:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→18→14→19→18
* 開始   : 2026-06-30 16:20:00 (UTC)
* 終了   : 2026-06-30 16:20:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→15
* 開始   : 2026-06-30 18:30:00 (UTC)
* 終了   : 2026-06-30 19:05:00 (UTC)
* 現象   : 2026-06-30 19:05:00 (UTC)を境に水準が 14.95から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→12→10→13→15→12→10→13→15
* 開始   : 2026-06-30 18:35:00 (UTC)
* 終了   : 2026-06-30 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host05-009 active_connections の推移](charts/EVT-20260630-host05-009.svg)

# イベントID( EVT-20260601-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→21→22→20→19→21→22→20→21
* 開始   : 2026-06-01 08:35:00 (UTC)
* 終了   : 2026-06-01 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→19→15→17→19→15→17→19
* 開始   : 2026-06-01 17:00:00 (UTC)
* 終了   : 2026-06-01 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→10→12→8→12→8→12→11
* 開始   : 2026-06-02 02:35:00 (UTC)
* 終了   : 2026-06-02 02:45:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→13→11→14→13→12
* 開始   : 2026-06-02 04:20:00 (UTC)
* 終了   : 2026-06-02 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-001 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260602-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→13→15→16→13→15→16→13→14
* 開始   : 2026-06-02 05:00:00 (UTC)
* 終了   : 2026-06-02 05:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→15→17→17→15→18→19
* 開始   : 2026-06-02 05:45:00 (UTC)
* 終了   : 2026-06-02 07:05:00 (UTC)
* 現象   : 2026-06-02 07:05:00 (UTC)を境に水準が 15.06から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→16→21→18→16→21→18
* 開始   : 2026-06-02 08:05:00 (UTC)
* 終了   : 2026-06-02 08:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260602-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→22→23→22→23→22
* 開始   : 2026-06-02 09:35:00 (UTC)
* 終了   : 2026-06-02 09:40:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→21→24→21→…→21→25→22→20
* 開始   : 2026-06-02 10:30:00 (UTC)
* 終了   : 2026-06-02 10:40:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→22→25→19→…→25→19→23→21
* 開始   : 2026-06-02 12:55:00 (UTC)
* 終了   : 2026-06-02 13:00:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→20→19→16→20→19
* 開始   : 2026-06-02 16:05:00 (UTC)
* 終了   : 2026-06-02 16:10:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→15→16→14→15
* 開始   : 2026-06-02 17:25:00 (UTC)
* 終了   : 2026-06-02 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host05-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→10→11→10
* 開始   : 2026-06-02 21:00:00 (UTC)
* 終了   : 2026-06-02 21:25:00 (UTC)
* 現象   : 2026-06-02 21:25:00 (UTC)を境に水準が 14.99から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.862, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→14→12→11→14→12→13
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→15→16→15→16→13
* 開始   : 2026-06-03 05:05:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→24→21→24→21→20
* 開始   : 2026-06-03 10:15:00 (UTC)
* 終了   : 2026-06-03 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→14→11→12→14→11→12→14
* 開始   : 2026-06-03 18:55:00 (UTC)
* 終了   : 2026-06-03 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260603-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→13→13→13→11→13→12→12
* 開始   : 2026-06-03 19:20:00 (UTC)
* 終了   : 2026-06-03 20:30:00 (UTC)
* 現象   : 2026-06-03 20:30:00 (UTC)を境に水準が 15.11から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.724, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→12→12→10→12→13
* 開始   : 2026-06-03 20:40:00 (UTC)
* 終了   : 2026-06-03 21:05:00 (UTC)
* 現象   : 2026-06-03 21:05:00 (UTC)を境に水準が 14.89から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→7→12→10→7→12→10→9
* 開始   : 2026-06-04 02:30:00 (UTC)
* 終了   : 2026-06-04 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→19→21→19→21→17→18
* 開始   : 2026-06-04 08:00:00 (UTC)
* 終了   : 2026-06-04 08:10:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→18→19→22→18→20
* 開始   : 2026-06-04 09:00:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→17→16→21→…→21→15→17→18
* 開始   : 2026-06-04 16:05:00 (UTC)
* 終了   : 2026-06-04 16:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→15→13→13→11→13→13→12→13
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 20:00:00 (UTC)
* 現象   : 2026-06-04 20:00:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.591, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→11→13→11→10→11→14
* 開始   : 2026-06-04 19:15:00 (UTC)
* 終了   : 2026-06-04 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→11→10→9→9→8→9
* 開始   : 2026-06-04 21:25:00 (UTC)
* 終了   : 2026-06-04 22:15:00 (UTC)
* 現象   : 2026-06-04 22:15:00 (UTC)を境に水準が 14.95から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→18→19→17→16→18→19→17
* 開始   : 2026-06-05 06:50:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→21→21→20→19→21→20→22→20
* 開始   : 2026-06-05 08:20:00 (UTC)
* 終了   : 2026-06-05 09:10:00 (UTC)
* 現象   : 2026-06-05 09:10:00 (UTC)を境に水準が 14.89から14.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→22→23→19→23→19→23→20→19
* 開始   : 2026-06-05 09:15:00 (UTC)
* 終了   : 2026-06-05 09:25:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260605-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→16→12→14→16→12→14→15
* 開始   : 2026-06-05 18:20:00 (UTC)
* 終了   : 2026-06-05 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→10→…→10→7→10→8
* 開始   : 2026-06-05 21:20:00 (UTC)
* 終了   : 2026-06-05 21:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host05-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→7→9→7→9
* 開始   : 2026-06-06 21:00:00 (UTC)
* 終了   : 2026-06-06 21:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260606-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→13→…→12→13→9→11
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 04:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260607-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→16→15→…→16→15→12→11
* 開始   : 2026-06-07 07:00:00 (UTC)
* 終了   : 2026-06-07 07:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.362倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.952σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→17→16→15→15→16→15→16→18
* 開始   : 2026-06-07 14:15:00 (UTC)
* 終了   : 2026-06-07 15:00:00 (UTC)
* 現象   : 2026-06-07 15:00:00 (UTC)を境に水準が 11.84から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→14→10→11→9→10→11→9→13
* 開始   : 2026-06-07 17:20:00 (UTC)
* 終了   : 2026-06-07 17:30:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→7→6→12→…→6→12→8→9
* 開始   : 2026-06-07 20:55:00 (UTC)
* 終了   : 2026-06-07 21:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260607-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→9→10→6→9→10
* 開始   : 2026-06-07 21:00:00 (UTC)
* 終了   : 2026-06-07 21:05:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.778σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host05-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→9→10→9→11→11→11
* 開始   : 2026-06-07 21:00:00 (UTC)
* 終了   : 2026-06-07 21:30:00 (UTC)
* 現象   : 2026-06-07 21:30:00 (UTC)を境に水準が 11.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.959, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→9→13→12→9→13→12→11
* 開始   : 2026-06-09 03:50:00 (UTC)
* 終了   : 2026-06-09 03:55:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→14→17→14→17→16
* 開始   : 2026-06-09 06:20:00 (UTC)
* 終了   : 2026-06-09 06:30:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→19→19→22→23
* 開始   : 2026-06-09 08:40:00 (UTC)
* 終了   : 2026-06-09 09:00:00 (UTC)
* 現象   : 2026-06-09 09:00:00 (UTC)を境に水準が 15.11から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→23→25→24→…→24→19→22→24
* 開始   : 2026-06-09 11:00:00 (UTC)
* 終了   : 2026-06-09 11:10:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→19→17→20→16→17→20→16→19
* 開始   : 2026-06-09 15:20:00 (UTC)
* 終了   : 2026-06-09 15:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→17→13→12→14→17→13→12→14
* 開始   : 2026-06-09 18:20:00 (UTC)
* 終了   : 2026-06-09 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→14→…→16→11→13→12
* 開始   : 2026-06-09 18:30:00 (UTC)
* 終了   : 2026-06-09 18:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260609-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→9→7→6→…→7→6→9→8
* 開始   : 2026-06-09 22:20:00 (UTC)
* 終了   : 2026-06-09 22:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→9→6→9→6→7→9
* 開始   : 2026-06-09 22:45:00 (UTC)
* 終了   : 2026-06-09 22:55:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→17→14→13→17→14→16
* 開始   : 2026-06-10 05:40:00 (UTC)
* 終了   : 2026-06-10 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.753σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→15→…→15→17→14→16
* 開始   : 2026-06-10 05:55:00 (UTC)
* 終了   : 2026-06-10 07:20:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→17→18→18→17→18→20
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:55:00 (UTC)
* 現象   : 2026-06-10 06:55:00 (UTC)を境に水準が 15.06から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→22→23→21→22→23→21
* 開始   : 2026-06-10 09:40:00 (UTC)
* 終了   : 2026-06-10 09:45:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→22→21→23→23→20→23→22→23
* 開始   : 2026-06-10 10:00:00 (UTC)
* 終了   : 2026-06-10 10:40:00 (UTC)
* 現象   : 2026-06-10 10:40:00 (UTC)を境に水準が 14.85から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→16→…→17→16→19→20
* 開始   : 2026-06-10 15:25:00 (UTC)
* 終了   : 2026-06-10 15:30:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260610-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 19→17→18→19→17→18
* 開始   : 2026-06-10 15:40:00 (UTC)
* 終了   : 2026-06-10 15:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→18→16→18→16
* 開始   : 2026-06-10 16:40:00 (UTC)
* 終了   : 2026-06-10 16:45:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→13→14→15→13→15→17
* 開始   : 2026-06-10 17:45:00 (UTC)
* 終了   : 2026-06-10 17:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→8→6→7→8→6→9
* 開始   : 2026-06-10 22:20:00 (UTC)
* 終了   : 2026-06-10 22:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260610-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→11→9→9→9→11→10
* 開始   : 2026-06-11 01:45:00 (UTC)
* 終了   : 2026-06-11 02:15:00 (UTC)
* 現象   : 2026-06-11 02:15:00 (UTC)を境に水準が 14.88から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→9→7→11→…→11→13→11→10
* 開始   : 2026-06-11 03:30:00 (UTC)
* 終了   : 2026-06-11 03:40:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260611-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→17→15→17→15→17→15
* 開始   : 2026-06-11 05:40:00 (UTC)
* 終了   : 2026-06-11 05:50:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→18→16→18
* 開始   : 2026-06-11 06:40:00 (UTC)
* 終了   : 2026-06-11 06:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→17→…→19→20→14→16
* 開始   : 2026-06-11 07:10:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 21→24→21→25→24→21→25→20→22
* 開始   : 2026-06-11 10:40:00 (UTC)
* 終了   : 2026-06-11 10:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→22→19→23→…→23→25→24→21
* 開始   : 2026-06-11 12:30:00 (UTC)
* 終了   : 2026-06-11 12:50:00 (UTC)
* 現象   : 2026-06-11 12:50:00 (UTC)を境に水準が 14.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 22→21→20→20→21
* 開始   : 2026-06-11 15:30:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 2026-06-11 15:50:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→19→17→15→18
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:25:00 (UTC)
* 現象   : 2026-06-11 17:25:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→8→6→5→…→6→5→7→8
* 開始   : 2026-06-11 22:15:00 (UTC)
* 終了   : 2026-06-11 22:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-081 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260611-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→10→11→8→…→8→5→8→7
* 開始   : 2026-06-11 23:10:00 (UTC)
* 終了   : 2026-06-11 23:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→14→18→17→18→17→18→16
* 開始   : 2026-06-12 06:20:00 (UTC)
* 終了   : 2026-06-12 06:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.848σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→16→18→16→18→17
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260612-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→17→…→17→19→16→18
* 開始   : 2026-06-12 06:40:00 (UTC)
* 終了   : 2026-06-12 06:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→18→…→18→16→18→19
* 開始   : 2026-06-12 15:55:00 (UTC)
* 終了   : 2026-06-12 16:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260612-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→18→15→14→18→15→14→18
* 開始   : 2026-06-12 16:55:00 (UTC)
* 終了   : 2026-06-12 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→7→9→7→9→7→11
* 開始   : 2026-06-12 21:05:00 (UTC)
* 終了   : 2026-06-12 21:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.6269(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.893σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→6→10→5→6→10→5→8→9
* 開始   : 2026-06-12 22:50:00 (UTC)
* 終了   : 2026-06-12 23:00:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→9→7→9→…→9→6→8→9
* 開始   : 2026-06-13 21:00:00 (UTC)
* 終了   : 2026-06-13 21:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260613-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→7→8→11→13→7→8
* 開始   : 2026-06-13 21:05:00 (UTC)
* 終了   : 2026-06-13 21:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260613-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→10→13→10→14→13→10→14→10
* 開始   : 2026-06-14 04:05:00 (UTC)
* 終了   : 2026-06-14 04:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→15→17→16→18→17→16→18→15
* 開始   : 2026-06-14 09:05:00 (UTC)
* 終了   : 2026-06-14 09:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→17→13→17→13→15→16
* 開始   : 2026-06-14 13:50:00 (UTC)
* 終了   : 2026-06-14 14:00:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-026 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260614-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→10→8→9→8
* 開始   : 2026-06-15 23:55:00 (UTC)
* 終了   : 2026-06-16 01:15:00 (UTC)
* 現象   : 2026-06-16 01:15:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→8→11→5→8→11→5→8→6
* 開始   : 2026-06-16 00:55:00 (UTC)
* 終了   : 2026-06-16 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→16→15→13→16→15
* 開始   : 2026-06-16 05:25:00 (UTC)
* 終了   : 2026-06-16 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→10→8→10→8→10→8→9→8
* 開始   : 2026-06-16 20:40:00 (UTC)
* 終了   : 2026-06-16 20:50:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260616-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260616-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→7→9→7→9→7→9→10
* 開始   : 2026-06-16 21:10:00 (UTC)
* 終了   : 2026-06-16 21:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.6462(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.695σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→5→8→7→5→8
* 開始   : 2026-06-17 00:10:00 (UTC)
* 終了   : 2026-06-17 00:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→16→14→13
* 開始   : 2026-06-17 05:15:00 (UTC)
* 終了   : 2026-06-17 05:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→16→15→17→…→15→17→14→15
* 開始   : 2026-06-17 05:15:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 2026-06-17 05:30:00 (UTC)を境に水準が 14.91から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.977, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→17→16→15→17→16→12
* 開始   : 2026-06-17 05:35:00 (UTC)
* 終了   : 2026-06-17 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→16→20→22→16→20→22→19→17
* 開始   : 2026-06-17 15:45:00 (UTC)
* 終了   : 2026-06-17 16:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→11→17→11→…→11→17→11→12
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→9→10→11→10→11
* 開始   : 2026-06-17 20:40:00 (UTC)
* 終了   : 2026-06-17 21:15:00 (UTC)
* 現象   : 2026-06-17 21:15:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→13→12→…→12→14→12→10
* 開始   : 2026-06-18 03:25:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→11→13→12→…→12→14→9→12
* 開始   : 2026-06-18 04:05:00 (UTC)
* 終了   : 2026-06-18 04:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→14→…→14→16→14→15
* 開始   : 2026-06-18 04:50:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→17→14→17→15
* 開始   : 2026-06-18 05:55:00 (UTC)
* 終了   : 2026-06-18 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→18→…→17→18→14→13
* 開始   : 2026-06-18 06:00:00 (UTC)
* 終了   : 2026-06-18 06:05:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→23→17→20→23→17→20
* 開始   : 2026-06-18 09:20:00 (UTC)
* 終了   : 2026-06-18 09:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 24→21→22→21→25→21→24
* 開始   : 2026-06-18 11:15:00 (UTC)
* 終了   : 2026-06-18 11:45:00 (UTC)
* 現象   : 2026-06-18 11:45:00 (UTC)を境に水準が 14.97から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→20→21→21
* 開始   : 2026-06-18 15:40:00 (UTC)
* 終了   : 2026-06-18 15:55:00 (UTC)
* 現象   : 2026-06-18 15:55:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→15→…→16→15→17→19
* 開始   : 2026-06-18 16:30:00 (UTC)
* 終了   : 2026-06-18 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→15→13→15→13→16→14
* 開始   : 2026-06-18 17:50:00 (UTC)
* 終了   : 2026-06-18 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→13→12→13→11→11→15
* 開始   : 2026-06-19 03:20:00 (UTC)
* 終了   : 2026-06-19 04:05:00 (UTC)
* 現象   : 2026-06-19 04:05:00 (UTC)を境に水準が 14.97から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→10→14→10→14→11→12
* 開始   : 2026-06-19 04:00:00 (UTC)
* 終了   : 2026-06-19 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→13→15→14→13→15→13
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 04:50:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 23→20→22→20→20→20→17→18→18
* 開始   : 2026-06-19 14:35:00 (UTC)
* 終了   : 2026-06-19 17:15:00 (UTC)
* 現象   : 2026-06-19 17:15:00 (UTC)を境に水準が 15から12.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→21→20→20
* 開始   : 2026-06-19 14:55:00 (UTC)
* 終了   : 2026-06-19 15:10:00 (UTC)
* 現象   : 2026-06-19 15:10:00 (UTC)を境に水準が 14.82から12.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→14→…→15→14→15→16
* 開始   : 2026-06-19 17:00:00 (UTC)
* 終了   : 2026-06-19 17:05:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→14
* 開始   : 2026-06-19 19:15:00 (UTC)
* 終了   : 2026-06-19 19:30:00 (UTC)
* 現象   : 2026-06-19 19:30:00 (UTC)を境に水準が 14.96から12.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→11→10→12→10→9→10
* 開始   : 2026-06-19 21:15:00 (UTC)
* 終了   : 2026-06-19 22:05:00 (UTC)
* 現象   : 2026-06-19 22:05:00 (UTC)を境に水準が 14.99から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→9→7→8→9
* 開始   : 2026-06-19 23:25:00 (UTC)
* 終了   : 2026-06-19 23:55:00 (UTC)
* 現象   : 2026-06-19 23:55:00 (UTC)を境に水準が 14.87から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 6→8→11→10→8→11→10→7
* 開始   : 2026-06-20 23:45:00 (UTC)
* 終了   : 2026-06-20 23:50:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→9→8→9→10→12
* 開始   : 2026-06-21 02:50:00 (UTC)
* 終了   : 2026-06-21 03:15:00 (UTC)
* 現象   : 2026-06-21 03:15:00 (UTC)を境に水準が 11.83から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→15→16→15→16→14→16
* 開始   : 2026-06-21 08:10:00 (UTC)
* 終了   : 2026-06-21 08:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260621-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→13→17→11→14→13→17→11→14
* 開始   : 2026-06-21 08:10:00 (UTC)
* 終了   : 2026-06-21 08:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→8→9→9→9→10→9
* 開始   : 2026-06-22 23:30:00 (UTC)
* 終了   : 2026-06-23 00:00:00 (UTC)
* 現象   : 2026-06-23 00:00:00 (UTC)を境に水準が 15.09から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→12→9→13→12→9→13→10→8
* 開始   : 2026-06-23 02:15:00 (UTC)
* 終了   : 2026-06-23 02:25:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→15→18→17→15→18→15
* 開始   : 2026-06-23 06:00:00 (UTC)
* 終了   : 2026-06-23 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→18→…→17→18→16→14
* 開始   : 2026-06-23 06:15:00 (UTC)
* 終了   : 2026-06-23 06:20:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→20→19→22→20→21
* 開始   : 2026-06-23 08:40:00 (UTC)
* 終了   : 2026-06-23 08:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→24→22→23
* 開始   : 2026-06-23 10:00:00 (UTC)
* 終了   : 2026-06-23 10:15:00 (UTC)
* 現象   : 2026-06-23 10:15:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→17→18→20→17→18→17
* 開始   : 2026-06-23 15:20:00 (UTC)
* 終了   : 2026-06-23 15:25:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8127(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→12→9→8→…→9→8→9→10
* 開始   : 2026-06-23 20:30:00 (UTC)
* 終了   : 2026-06-23 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260623-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→13→15→14→15→14→15→11→14
* 開始   : 2026-06-24 04:30:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→…→18→14→19→16
* 開始   : 2026-06-24 07:00:00 (UTC)
* 終了   : 2026-06-24 07:45:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260624-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分

![EVT-20260624-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→17→20→17→20
* 開始   : 2026-06-24 15:20:00 (UTC)
* 終了   : 2026-06-24 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→15→12→15→12→15
* 開始   : 2026-06-24 18:00:00 (UTC)
* 終了   : 2026-06-24 18:10:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-015 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→13→11→14
* 開始   : 2026-06-24 19:05:00 (UTC)
* 終了   : 2026-06-24 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 7→5→10→7→5→10→9
* 開始   : 2026-06-24 23:00:00 (UTC)
* 終了   : 2026-06-24 23:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.519σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 7→9→11→12→…→11→12→8→9
* 開始   : 2026-06-24 23:35:00 (UTC)
* 終了   : 2026-06-24 23:40:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260624-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→6→10→11→8→11
* 開始   : 2026-06-25 00:15:00 (UTC)
* 終了   : 2026-06-25 00:40:00 (UTC)
* 現象   : 2026-06-25 00:40:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→15→18→16→15→18→16→15
* 開始   : 2026-06-25 06:35:00 (UTC)
* 終了   : 2026-06-25 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→16→20→16→20→16→20→17
* 開始   : 2026-06-25 07:10:00 (UTC)
* 終了   : 2026-06-25 07:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.244倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 18→20→21→20→21→20→19
* 開始   : 2026-06-25 08:25:00 (UTC)
* 終了   : 2026-06-25 08:30:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→16→17→19→16→17
* 開始   : 2026-06-25 16:05:00 (UTC)
* 終了   : 2026-06-25 16:10:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→17→14→17
* 開始   : 2026-06-25 17:30:00 (UTC)
* 終了   : 2026-06-25 17:35:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→11→15→14→11→15
* 開始   : 2026-06-25 19:05:00 (UTC)
* 終了   : 2026-06-25 19:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→6→9→6→9→6→9→11
* 開始   : 2026-06-25 21:40:00 (UTC)
* 終了   : 2026-06-25 21:50:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260625-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→8→10→9
* 開始   : 2026-06-25 22:50:00 (UTC)
* 終了   : 2026-06-25 23:05:00 (UTC)
* 現象   : 2026-06-25 23:05:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→15→18→17→15→18→17→15→16
* 開始   : 2026-06-26 05:50:00 (UTC)
* 終了   : 2026-06-26 05:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.309倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.977σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→20→19→21→20
* 開始   : 2026-06-26 08:15:00 (UTC)
* 終了   : 2026-06-26 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→13→…→14→13→15→16
* 開始   : 2026-06-26 17:35:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→11→…→12→11→15→12
* 開始   : 2026-06-26 18:45:00 (UTC)
* 終了   : 2026-06-26 18:50:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→8→6→9→8→6→9
* 開始   : 2026-06-27 23:30:00 (UTC)
* 終了   : 2026-06-27 23:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→8→10→10→7→8→12
* 開始   : 2026-06-28 01:30:00 (UTC)
* 終了   : 2026-06-28 02:15:00 (UTC)
* 現象   : 2026-06-28 02:15:00 (UTC)を境に水準が 11.72から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→11→12
* 開始   : 2026-06-28 03:25:00 (UTC)
* 終了   : 2026-06-28 03:35:00 (UTC)
* 現象   : 2026-06-28 03:35:00 (UTC)を境に水準が 11.79から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.359, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→10→13→10→13→10→11
* 開始   : 2026-06-28 04:45:00 (UTC)
* 終了   : 2026-06-28 04:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→14→…→15→10→13→14
* 開始   : 2026-06-28 17:10:00 (UTC)
* 終了   : 2026-06-28 17:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→11→…→11→9→10→11
* 開始   : 2026-06-28 17:40:00 (UTC)
* 終了   : 2026-06-28 17:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→5→…→12→5→11→8
* 開始   : 2026-06-28 21:35:00 (UTC)
* 終了   : 2026-06-28 21:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→14→…→14→17→15→14
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260630-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260630-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→17→…→16→17→13→15
* 開始   : 2026-06-30 05:30:00 (UTC)
* 終了   : 2026-06-30 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→17→15→18→17→15→18→15
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→15→18→15→18→16→15
* 開始   : 2026-06-30 06:10:00 (UTC)
* 終了   : 2026-06-30 06:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.301倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→16→15→17→16→15→17→15
* 開始   : 2026-06-30 16:55:00 (UTC)
* 終了   : 2026-06-30 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→9→10→10→12→11→12
* 開始   : 2026-06-30 20:55:00 (UTC)
* 終了   : 2026-06-30 21:25:00 (UTC)
* 現象   : 2026-06-30 21:25:00 (UTC)を境に水準が 14.91から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host05-010 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
