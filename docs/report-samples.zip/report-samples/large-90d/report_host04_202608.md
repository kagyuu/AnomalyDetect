# host04 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host04 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 299 (SEVERE: 21, FATAL: 114, WARN: 164, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 114 | 164 | 299 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→15→…→14→15→12→15
* 開始   : 2026-08-03 01:00:00 (UTC)
* 終了   : 2026-08-03 20:10:00 (UTC)
* 現象   : 2026-08-03 20:10:00 (UTC)を境に水準が 11.81から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.937, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.097, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-001 active_connections の推移](charts/EVT-20260803-host04-001.svg)

# イベントID( EVT-20260803-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→14→15→16→…→14→16→13→14
* 開始   : 2026-08-03 01:15:00 (UTC)
* 終了   : 2026-08-03 20:30:00 (UTC)
* 現象   : 2026-08-03 20:30:00 (UTC)を境に水準が 11.93から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.212, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-002 active_connections の推移](charts/EVT-20260803-host04-002.svg)

# イベントID( EVT-20260803-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→15→…→13→14→13→15
* 開始   : 2026-08-03 02:40:00 (UTC)
* 終了   : 2026-08-03 19:20:00 (UTC)
* 現象   : 2026-08-03 19:20:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.095, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-003 active_connections の推移](charts/EVT-20260803-host04-003.svg)

# イベントID( EVT-20260803-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→17→16→19→…→13→15→11→14
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 20:05:00 (UTC)
* 現象   : 2026-08-03 20:05:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-004 active_connections の推移](charts/EVT-20260803-host04-004.svg)

# イベントID( EVT-20260803-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→13→…→14→11→12→10
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 21:35:00 (UTC)
* 現象   : 2026-08-03 21:35:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.659, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-005 active_connections の推移](charts/EVT-20260803-host04-005.svg)

# イベントID( EVT-20260803-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→15→…→15→13→15→12
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 20:30:00 (UTC)
* 現象   : 2026-08-03 20:30:00 (UTC)を境に水準が 11.84から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.036, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.332, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host04-006 active_connections の推移](charts/EVT-20260803-host04-006.svg)

# イベントID( EVT-20260810-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→14→…→15→14→12→11
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 11.68から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-002 active_connections の推移](charts/EVT-20260810-host04-002.svg)

# イベントID( EVT-20260810-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→16→14→16→…→14→15→13→14
* 開始   : 2026-08-10 02:40:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-003 active_connections の推移](charts/EVT-20260810-host04-003.svg)

# イベントID( EVT-20260810-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→16→18→15→…→13→12→10→13
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.87から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.146, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-004 active_connections の推移](charts/EVT-20260810-host04-004.svg)

# イベントID( EVT-20260810-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→13→16→17→…→13→15→13→15
* 開始   : 2026-08-10 03:00:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 12から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.911, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-005 active_connections の推移](charts/EVT-20260810-host04-005.svg)

# イベントID( EVT-20260810-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→16→18→15→…→16→15→14→13
* 開始   : 2026-08-10 03:15:00 (UTC)
* 終了   : 2026-08-10 20:10:00 (UTC)
* 現象   : 2026-08-10 20:10:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.783, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.112, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-006 active_connections の推移](charts/EVT-20260810-host04-006.svg)

# イベントID( EVT-20260810-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→16→…→14→13→12→13
* 開始   : 2026-08-10 03:40:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.78から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-007 active_connections の推移](charts/EVT-20260810-host04-007.svg)

# イベントID( EVT-20260817-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→13→…→14→13→12→13
* 開始   : 2026-08-17 03:30:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 11.97から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.684, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-005 active_connections の推移](charts/EVT-20260817-host04-005.svg)

# イベントID( EVT-20260817-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→15→…→15→12→14→13
* 開始   : 2026-08-17 04:00:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-006 active_connections の推移](charts/EVT-20260817-host04-006.svg)

# イベントID( EVT-20260817-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→13→…→15→13→12→14
* 開始   : 2026-08-17 04:00:00 (UTC)
* 終了   : 2026-08-17 20:45:00 (UTC)
* 現象   : 2026-08-17 20:45:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.839, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-007 active_connections の推移](charts/EVT-20260817-host04-007.svg)

# イベントID( EVT-20260824-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→12→…→14→13→15→14
* 開始   : 2026-08-24 01:05:00 (UTC)
* 終了   : 2026-08-24 20:45:00 (UTC)
* 現象   : 2026-08-24 20:45:00 (UTC)を境に水準が 11.83から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.81, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-001 active_connections の推移](charts/EVT-20260824-host04-001.svg)

# イベントID( EVT-20260824-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→…→16→15→14→15
* 開始   : 2026-08-24 02:00:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.82から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.951, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-002 active_connections の推移](charts/EVT-20260824-host04-002.svg)

# イベントID( EVT-20260824-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→17→…→15→14→11→10
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 19:40:00 (UTC)
* 現象   : 2026-08-24 19:40:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.771, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-003 active_connections の推移](charts/EVT-20260824-host04-003.svg)

# イベントID( EVT-20260824-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→16→…→13→12→10→13
* 開始   : 2026-08-24 03:00:00 (UTC)
* 終了   : 2026-08-24 21:55:00 (UTC)
* 現象   : 2026-08-24 21:55:00 (UTC)を境に水準が 11.73から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.126, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.929, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-004 active_connections の推移](charts/EVT-20260824-host04-004.svg)

# イベントID( EVT-20260824-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→17→15→17→…→13→14→12→13
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 20:00:00 (UTC)
* 現象   : 2026-08-24 20:00:00 (UTC)を境に水準が 11.96から14.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-005 active_connections の推移](charts/EVT-20260824-host04-005.svg)

# イベントID( EVT-20260824-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→17→…→13→14→13→11
* 開始   : 2026-08-24 03:15:00 (UTC)
* 終了   : 2026-08-25 00:10:00 (UTC)
* 現象   : 2026-08-25 00:10:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.771, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host04-006 active_connections の推移](charts/EVT-20260824-host04-006.svg)

# イベントID( EVT-20260801-host04-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→12→…→12→13→12→13
* 開始   : 2026-08-01 04:10:00 (UTC)
* 終了   : 2026-08-01 19:45:00 (UTC)
* 現象   : 15.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.927, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 15.4 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260801-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260801-host04-001 active_connections の推移](charts/EVT-20260801-host04-001.svg)

# イベントID( EVT-20260801-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→9→10→9→…→10→11→10→9
* 開始   : 2026-08-01 05:00:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260801-host04-002 active_connections の推移](charts/EVT-20260801-host04-002.svg)

# イベントID( EVT-20260801-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→11→9→10→…→12→11→13→12
* 開始   : 2026-08-01 05:15:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host04-003 active_connections の推移](charts/EVT-20260801-host04-003.svg)

# イベントID( EVT-20260801-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→10→…→12→9→12→8
* 開始   : 2026-08-01 05:15:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.764, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260801-host04-004 active_connections の推移](charts/EVT-20260801-host04-004.svg)

# イベントID( EVT-20260801-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→11→14→11→…→9→12→10→11
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.266, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260801-host04-005 active_connections の推移](charts/EVT-20260801-host04-005.svg)

# イベントID( EVT-20260801-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→11→…→12→9→12→11
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.235, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260801-host04-006 active_connections の推移](charts/EVT-20260801-host04-006.svg)

# イベントID( EVT-20260801-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→10→9
* 開始   : 2026-08-01 21:05:00 (UTC)
* 終了   : 2026-08-01 21:05:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260801-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→11→12→15→11→12→15→16
* 開始   : 2026-08-02 15:10:00 (UTC)
* 終了   : 2026-08-02 15:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260802-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→14→10→11→14→10→11→14→12
* 開始   : 2026-08-02 15:40:00 (UTC)
* 終了   : 2026-08-02 15:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→10→6→10→10
* 開始   : 2026-08-03 20:50:00 (UTC)
* 終了   : 2026-08-03 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.733σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→18→21→19→19
* 開始   : 2026-08-04 07:25:00 (UTC)
* 終了   : 2026-08-04 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→19→22→16→19
* 開始   : 2026-08-04 07:25:00 (UTC)
* 終了   : 2026-08-04 07:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 23→22→19→24→…→24→18→22→23
* 開始   : 2026-08-04 12:15:00 (UTC)
* 終了   : 2026-08-04 12:50:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→18→14→13→18→14→16
* 開始   : 2026-08-04 17:25:00 (UTC)
* 終了   : 2026-08-04 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→15→14
* 開始   : 2026-08-04 17:35:00 (UTC)
* 終了   : 2026-08-04 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 6→9→12→5→…→12→5→8→9
* 開始   : 2026-08-05 01:05:00 (UTC)
* 終了   : 2026-08-05 01:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→16→15→12→16→15→12→13
* 開始   : 2026-08-05 04:05:00 (UTC)
* 終了   : 2026-08-05 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260805-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host04-002 active_connections の推移](charts/EVT-20260805-host04-002.svg)

# イベントID( EVT-20260805-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→18→23→19→19
* 開始   : 2026-08-05 08:30:00 (UTC)
* 終了   : 2026-08-05 08:30:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→14→15→17→14→15
* 開始   : 2026-08-05 16:45:00 (UTC)
* 終了   : 2026-08-05 17:20:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260805-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260805-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→9→10
* 開始   : 2026-08-06 02:25:00 (UTC)
* 終了   : 2026-08-06 02:25:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→10→15→10→12
* 開始   : 2026-08-06 03:45:00 (UTC)
* 終了   : 2026-08-06 03:45:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host04-002 active_connections の推移](charts/EVT-20260806-host04-002.svg)

# イベントID( EVT-20260806-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→16→18→19→18→21
* 開始   : 2026-08-06 06:35:00 (UTC)
* 終了   : 2026-08-06 07:00:00 (UTC)
* 現象   : 2026-08-06 07:00:00 (UTC)を境に水準が 15.01から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.65, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→17→20→18→18
* 開始   : 2026-08-06 07:00:00 (UTC)
* 終了   : 2026-08-06 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→11→15→9→…→8→14→10→11
* 開始   : 2026-08-06 20:10:00 (UTC)
* 終了   : 2026-08-06 20:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host04-009 active_connections の推移](charts/EVT-20260806-host04-009.svg)

# イベントID( EVT-20260806-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→11→5→9→8
* 開始   : 2026-08-06 21:05:00 (UTC)
* 終了   : 2026-08-06 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.4545(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host04-010 active_connections の推移](charts/EVT-20260806-host04-010.svg)

# イベントID( EVT-20260807-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→15→18→15→14
* 開始   : 2026-08-07 06:15:00 (UTC)
* 終了   : 2026-08-07 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→20→23→20→18
* 開始   : 2026-08-07 08:40:00 (UTC)
* 終了   : 2026-08-07 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→18→14→18→18
* 開始   : 2026-08-07 16:25:00 (UTC)
* 終了   : 2026-08-07 16:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.7273(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.661σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-008 active_connections の推移](charts/EVT-20260807-host04-008.svg)

# イベントID( EVT-20260807-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→19→14→18→18
* 開始   : 2026-08-07 16:35:00 (UTC)
* 終了   : 2026-08-07 16:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→9→12→10→9→12→10
* 開始   : 2026-08-07 18:55:00 (UTC)
* 終了   : 2026-08-07 19:35:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host04-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260807-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→9→…→10→11→12→13
* 開始   : 2026-08-08 04:15:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.052, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host04-001 active_connections の推移](charts/EVT-20260808-host04-001.svg)

# イベントID( EVT-20260808-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→11→…→11→10→9→11
* 開始   : 2026-08-08 04:35:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.739, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間

![EVT-20260808-host04-003 active_connections の推移](charts/EVT-20260808-host04-003.svg)

# イベントID( EVT-20260808-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→12→14→13→…→11→10→13→10
* 開始   : 2026-08-08 05:20:00 (UTC)
* 終了   : 2026-08-08 18:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.188σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.825, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host04-004 active_connections の推移](charts/EVT-20260808-host04-004.svg)

# イベントID( EVT-20260808-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→…→11→10→11→12
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.782, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host04-005 active_connections の推移](charts/EVT-20260808-host04-005.svg)

# イベントID( EVT-20260808-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→13→…→10→11→10→11
* 開始   : 2026-08-08 06:05:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.124, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260808-host04-006 active_connections の推移](charts/EVT-20260808-host04-006.svg)

# イベントID( EVT-20260808-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→13→…→13→11→13→12
* 開始   : 2026-08-08 06:10:00 (UTC)
* 終了   : 2026-08-08 18:30:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260808-host04-007 active_connections の推移](charts/EVT-20260808-host04-007.svg)

# イベントID( EVT-20260809-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→16→11→15→13
* 開始   : 2026-08-09 13:55:00 (UTC)
* 終了   : 2026-08-09 13:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→9→5→8→10
* 開始   : 2026-08-09 20:15:00 (UTC)
* 終了   : 2026-08-09 20:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.4688(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.975σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host04-008 active_connections の推移](charts/EVT-20260809-host04-008.svg)

# イベントID( EVT-20260811-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→22→21→19→18→22→21→19→21
* 開始   : 2026-08-11 08:15:00 (UTC)
* 終了   : 2026-08-11 08:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260811-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→21→26→21→22
* 開始   : 2026-08-11 10:35:00 (UTC)
* 終了   : 2026-08-11 10:35:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.476σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host04-005 active_connections の推移](charts/EVT-20260811-host04-005.svg)

# イベントID( EVT-20260811-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 22→21→16→19→18
* 開始   : 2026-08-11 15:05:00 (UTC)
* 終了   : 2026-08-11 15:05:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→19→19→19→19→17→16→16→20
* 開始   : 2026-08-11 15:40:00 (UTC)
* 終了   : 2026-08-11 17:20:00 (UTC)
* 現象   : 2026-08-11 17:20:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.446σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.242, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→16→17
* 開始   : 2026-08-11 16:40:00 (UTC)
* 終了   : 2026-08-11 16:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7434(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→14→11→16→13
* 開始   : 2026-08-11 17:55:00 (UTC)
* 終了   : 2026-08-11 17:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→19→16→19→16→19→17
* 開始   : 2026-08-12 06:35:00 (UTC)
* 終了   : 2026-08-12 06:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→16→13
* 開始   : 2026-08-12 18:30:00 (UTC)
* 終了   : 2026-08-12 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→17→19→18→…→18→19→17→18
* 開始   : 2026-08-13 06:30:00 (UTC)
* 終了   : 2026-08-13 06:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→14→20→18→…→17→19→16→18
* 開始   : 2026-08-13 06:45:00 (UTC)
* 終了   : 2026-08-13 07:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.777σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host04-006 active_connections の推移](charts/EVT-20260813-host04-006.svg)

# イベントID( EVT-20260813-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→20→18→21→20→18
* 開始   : 2026-08-13 07:45:00 (UTC)
* 終了   : 2026-08-13 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 20→21→16→21→…→21→18→22→19
* 開始   : 2026-08-13 14:20:00 (UTC)
* 終了   : 2026-08-13 14:30:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7385(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.975σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260813-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host04-009 active_connections の推移](charts/EVT-20260813-host04-009.svg)

# イベントID( EVT-20260813-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→12→7→11→10
* 開始   : 2026-08-13 20:40:00 (UTC)
* 終了   : 2026-08-13 20:40:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.304σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260813-host04-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→12
* 開始   : 2026-08-13 22:15:00 (UTC)
* 終了   : 2026-08-13 22:40:00 (UTC)
* 現象   : 2026-08-13 22:40:00 (UTC)を境に水準が 15.04から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.326, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host04-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→15→15
* 開始   : 2026-08-14 05:55:00 (UTC)
* 終了   : 2026-08-14 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→18→18
* 開始   : 2026-08-14 06:55:00 (UTC)
* 終了   : 2026-08-14 07:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.362σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260814-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→8→12→8→7
* 開始   : 2026-08-15 00:00:00 (UTC)
* 終了   : 2026-08-15 00:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260815-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→9→8→11→…→11→13→12→10
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:10:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.739, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260815-host04-002 active_connections の推移](charts/EVT-20260815-host04-002.svg)

# イベントID( EVT-20260815-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→14→10→11→…→11→12→13→12
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.42σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.732, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host04-003 active_connections の推移](charts/EVT-20260815-host04-003.svg)

# イベントID( EVT-20260815-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→10→11→13→…→12→9→13→11
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 19:45:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.837, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host04-004 active_connections の推移](charts/EVT-20260815-host04-004.svg)

# イベントID( EVT-20260815-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→12→…→12→9→10→11
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.736, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host04-005 active_connections の推移](charts/EVT-20260815-host04-005.svg)

# イベントID( EVT-20260815-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→15→…→12→10→13→9
* 開始   : 2026-08-15 05:45:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.354, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host04-006 active_connections の推移](charts/EVT-20260815-host04-006.svg)

# イベントID( EVT-20260815-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→10→11→12→…→13→9→11→12
* 開始   : 2026-08-15 06:15:00 (UTC)
* 終了   : 2026-08-15 20:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.112, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host04-007 active_connections の推移](charts/EVT-20260815-host04-007.svg)

# イベントID( EVT-20260816-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→8→11
* 開始   : 2026-08-16 21:00:00 (UTC)
* 終了   : 2026-08-16 21:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→16→…→12→17→15→14
* 開始   : 2026-08-17 02:25:00 (UTC)
* 終了   : 2026-08-17 20:35:00 (UTC)
* 現象   : 2026-08-17 20:35:00 (UTC)を境に水準が 11.88から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.467, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→18→16→…→12→13→14→13
* 開始   : 2026-08-17 02:30:00 (UTC)
* 終了   : 2026-08-17 21:05:00 (UTC)
* 現象   : 2026-08-17 21:05:00 (UTC)を境に水準が 11.88から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.095, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-003 active_connections の推移](charts/EVT-20260817-host04-003.svg)

# イベントID( EVT-20260817-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→15→…→13→11→12→11
* 開始   : 2026-08-17 03:20:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.066, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.232, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-004 active_connections の推移](charts/EVT-20260817-host04-004.svg)

# イベントID( EVT-20260817-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 7→9→11→4→…→11→4→5→8
* 開始   : 2026-08-17 23:35:00 (UTC)
* 終了   : 2026-08-18 00:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260817-lsfhost01-061 (他ホスト) lsf_queue / susp : WARN / 重なり 25 分
  - EVT-20260817-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260817-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260817-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→18→19→20→19→20→18→16
* 開始   : 2026-08-18 06:55:00 (UTC)
* 終了   : 2026-08-18 07:25:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260818-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host04-005 active_connections の推移](charts/EVT-20260818-host04-005.svg)

# イベントID( EVT-20260818-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→14→11→15→15
* 開始   : 2026-08-18 18:15:00 (UTC)
* 終了   : 2026-08-18 18:15:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host04-010 active_connections の推移](charts/EVT-20260818-host04-010.svg)

# イベントID( EVT-20260819-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→14→…→15→14→11→10
* 開始   : 2026-08-19 04:05:00 (UTC)
* 終了   : 2026-08-19 04:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260819-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 24→21→18→20→22
* 開始   : 2026-08-19 14:00:00 (UTC)
* 終了   : 2026-08-19 14:00:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→17→14→18→17
* 開始   : 2026-08-19 16:50:00 (UTC)
* 終了   : 2026-08-19 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→14→15
* 開始   : 2026-08-19 17:55:00 (UTC)
* 終了   : 2026-08-19 17:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→15→9→14→15
* 開始   : 2026-08-19 18:25:00 (UTC)
* 終了   : 2026-08-19 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.5745(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host04-009 active_connections の推移](charts/EVT-20260819-host04-009.svg)

# イベントID( EVT-20260819-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→15→10→14→14
* 開始   : 2026-08-19 18:55:00 (UTC)
* 終了   : 2026-08-19 18:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→18→10→14→14
* 開始   : 2026-08-19 18:55:00 (UTC)
* 終了   : 2026-08-19 19:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.6486(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260819-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 35 分
  - EVT-20260819-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260819-host04-011 active_connections の推移](charts/EVT-20260819-host04-011.svg)

# イベントID( EVT-20260819-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→7→8→7→10→12
* 開始   : 2026-08-19 20:25:00 (UTC)
* 終了   : 2026-08-19 21:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-069 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260819-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260819-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→11→11
* 開始   : 2026-08-20 03:00:00 (UTC)
* 終了   : 2026-08-20 03:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.514倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→10→14→11→12
* 開始   : 2026-08-20 03:20:00 (UTC)
* 終了   : 2026-08-20 03:20:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→17→13→18→14→13→18→14→15
* 開始   : 2026-08-20 17:20:00 (UTC)
* 終了   : 2026-08-20 17:30:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→12→15→11→13
* 開始   : 2026-08-21 04:00:00 (UTC)
* 終了   : 2026-08-21 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→14→19→21→…→19→21→17→18
* 開始   : 2026-08-21 07:15:00 (UTC)
* 終了   : 2026-08-21 07:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 23→23→21→23→21→21→21→23→23
* 開始   : 2026-08-21 13:40:00 (UTC)
* 終了   : 2026-08-21 15:05:00 (UTC)
* 現象   : 2026-08-21 15:05:00 (UTC)を境に水準が 15.08から12.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→15→13
* 開始   : 2026-08-21 18:00:00 (UTC)
* 終了   : 2026-08-21 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host04-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→11→…→11→12→13→12
* 開始   : 2026-08-22 04:30:00 (UTC)
* 終了   : 2026-08-22 19:05:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.749, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260822-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260822-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260822-host04-001 active_connections の推移](charts/EVT-20260822-host04-001.svg)

# イベントID( EVT-20260822-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→12→…→10→11→13→10
* 開始   : 2026-08-22 04:35:00 (UTC)
* 終了   : 2026-08-22 18:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.895, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260822-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260822-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260822-host04-002 active_connections の推移](charts/EVT-20260822-host04-002.svg)

# イベントID( EVT-20260822-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→11→10→11→10
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.819, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260822-host04-006 active_connections の推移](charts/EVT-20260822-host04-006.svg)

# イベントID( EVT-20260822-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→9→…→13→11→13→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.071, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260822-host04-007 active_connections の推移](charts/EVT-20260822-host04-007.svg)

# イベントID( EVT-20260822-host04-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→13→9→11→…→15→12→14→12
* 開始   : 2026-08-22 06:20:00 (UTC)
* 終了   : 2026-08-22 17:55:00 (UTC)
* 現象   : 11.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.547, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.6 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間

![EVT-20260822-host04-008 active_connections の推移](charts/EVT-20260822-host04-008.svg)

# イベントID( EVT-20260822-host04-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→13→11→…→12→10→12→10
* 開始   : 2026-08-22 07:05:00 (UTC)
* 終了   : 2026-08-22 18:35:00 (UTC)
* 現象   : 11.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.5 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260822-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間

![EVT-20260822-host04-009 active_connections の推移](charts/EVT-20260822-host04-009.svg)

# イベントID( EVT-20260823-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→10→9→8→11
* 開始   : 2026-08-23 22:10:00 (UTC)
* 終了   : 2026-08-23 22:55:00 (UTC)
* 現象   : 2026-08-23 22:55:00 (UTC)を境に水準が 11.85から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→19→14→18→…→18→20→16→17
* 開始   : 2026-08-25 06:10:00 (UTC)
* 終了   : 2026-08-25 07:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260825-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260825-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 20 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260825-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→15→18→15→18→15→16
* 開始   : 2026-08-25 06:30:00 (UTC)
* 終了   : 2026-08-25 06:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260825-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→10→15→14
* 開始   : 2026-08-25 18:30:00 (UTC)
* 終了   : 2026-08-25 18:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host04-009 active_connections の推移](charts/EVT-20260825-host04-009.svg)

# イベントID( EVT-20260826-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→12→12→11→11→13→11→14→14
* 開始   : 2026-08-26 03:10:00 (UTC)
* 終了   : 2026-08-26 05:45:00 (UTC)
* 現象   : 2026-08-26 05:45:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.344, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→12→12
* 開始   : 2026-08-26 04:30:00 (UTC)
* 終了   : 2026-08-26 04:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→11→6→9→10
* 開始   : 2026-08-26 21:20:00 (UTC)
* 終了   : 2026-08-26 21:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-073 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260826-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→12→9→9
* 開始   : 2026-08-27 02:05:00 (UTC)
* 終了   : 2026-08-27 02:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→12→17→13→12
* 開始   : 2026-08-27 04:35:00 (UTC)
* 終了   : 2026-08-27 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.707σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-017 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260827-host04-003 active_connections の推移](charts/EVT-20260827-host04-003.svg)

# イベントID( EVT-20260827-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→16→16
* 開始   : 2026-08-27 06:20:00 (UTC)
* 終了   : 2026-08-27 06:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→19→17
* 開始   : 2026-08-27 07:10:00 (UTC)
* 終了   : 2026-08-27 07:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→21→18→16→19→21→18
* 開始   : 2026-08-27 07:25:00 (UTC)
* 終了   : 2026-08-27 07:30:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→16→16
* 開始   : 2026-08-27 17:05:00 (UTC)
* 終了   : 2026-08-27 17:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→14→13
* 開始   : 2026-08-27 19:25:00 (UTC)
* 終了   : 2026-08-27 19:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→14→9→12→9→12→9→11
* 開始   : 2026-08-27 19:25:00 (UTC)
* 終了   : 2026-08-27 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260827-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→20→26→20→22
* 開始   : 2026-08-28 11:05:00 (UTC)
* 終了   : 2026-08-28 11:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→19→15→19→15→19→20
* 開始   : 2026-08-28 16:25:00 (UTC)
* 終了   : 2026-08-28 16:30:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→12→15→12→15→12→15→14
* 開始   : 2026-08-28 18:00:00 (UTC)
* 終了   : 2026-08-28 18:10:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→12→8→11→11
* 開始   : 2026-08-28 20:00:00 (UTC)
* 終了   : 2026-08-28 20:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→12→…→13→12→13→12
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.917, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260829-host04-002 active_connections の推移](charts/EVT-20260829-host04-002.svg)

# イベントID( EVT-20260829-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→15→12→14→…→13→14→12→13
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 18:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.205, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260829-host04-003 active_connections の推移](charts/EVT-20260829-host04-003.svg)

# イベントID( EVT-20260829-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→11→…→9→12→13→12
* 開始   : 2026-08-29 05:40:00 (UTC)
* 終了   : 2026-08-29 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260829-host04-004 active_connections の推移](charts/EVT-20260829-host04-004.svg)

# イベントID( EVT-20260829-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→15→10→14→12
* 開始   : 2026-08-29 05:40:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.72, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host04-005 active_connections の推移](charts/EVT-20260829-host04-005.svg)

# イベントID( EVT-20260829-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→12→10→14→…→13→12→10→12
* 開始   : 2026-08-29 06:00:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260829-host04-006 active_connections の推移](charts/EVT-20260829-host04-006.svg)

# イベントID( EVT-20260829-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→11→12→11→12
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.882, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260829-host04-007 active_connections の推移](charts/EVT-20260829-host04-007.svg)

# イベントID( EVT-20260801-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 8→10→10→9→8→8→9→7→10
* 開始   : 2026-08-01 23:35:00 (UTC)
* 終了   : 2026-08-02 00:25:00 (UTC)
* 現象   : 2026-08-02 00:25:00 (UTC)を境に水準が 11.82から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.936, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260801-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→10→15→16→…→15→16→12→11
* 開始   : 2026-08-02 06:45:00 (UTC)
* 終了   : 2026-08-02 06:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→16→17→16→17→14→13
* 開始   : 2026-08-02 08:45:00 (UTC)
* 終了   : 2026-08-02 08:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→15→18→16→18→16→18→14→15
* 開始   : 2026-08-02 09:25:00 (UTC)
* 終了   : 2026-08-02 09:35:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260802-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→14→12→10→14→13
* 開始   : 2026-08-02 16:40:00 (UTC)
* 終了   : 2026-08-02 16:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→12→12→12→12→11→11→12→14
* 開始   : 2026-08-02 18:20:00 (UTC)
* 終了   : 2026-08-02 19:00:00 (UTC)
* 現象   : 2026-08-02 19:00:00 (UTC)を境に水準が 11.75から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.584, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→7→8→10→8→10→12
* 開始   : 2026-08-04 00:25:00 (UTC)
* 終了   : 2026-08-04 01:20:00 (UTC)
* 現象   : 2026-08-04 01:20:00 (UTC)を境に水準が 15.04から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.994, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→10→12→11→12
* 開始   : 2026-08-04 03:00:00 (UTC)
* 終了   : 2026-08-04 03:30:00 (UTC)
* 現象   : 2026-08-04 03:30:00 (UTC)を境に水準が 14.92から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→9→14→10→14→10→14→11→13
* 開始   : 2026-08-04 03:40:00 (UTC)
* 終了   : 2026-08-04 03:50:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260804-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→15→15→14→15→15→17
* 開始   : 2026-08-04 05:30:00 (UTC)
* 終了   : 2026-08-04 06:00:00 (UTC)
* 現象   : 2026-08-04 06:00:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.232, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→14→15→17→14→13
* 開始   : 2026-08-04 05:45:00 (UTC)
* 終了   : 2026-08-04 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→15→17→16
* 開始   : 2026-08-04 05:55:00 (UTC)
* 終了   : 2026-08-04 06:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260804-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→16→19→15→…→18→20→16→18
* 開始   : 2026-08-04 07:05:00 (UTC)
* 終了   : 2026-08-04 07:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260804-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260804-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→19→18→21→19→18
* 開始   : 2026-08-04 07:55:00 (UTC)
* 終了   : 2026-08-04 08:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→21→24→21
* 開始   : 2026-08-04 10:35:00 (UTC)
* 終了   : 2026-08-04 10:40:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.185倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→25→21→24→25→21→24→22→21
* 開始   : 2026-08-04 10:40:00 (UTC)
* 終了   : 2026-08-04 10:50:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.2倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.92σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→19→14→15→…→15→13→14→13
* 開始   : 2026-08-04 17:45:00 (UTC)
* 終了   : 2026-08-04 17:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260804-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host04-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host04-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→13→10→13→10→13→14
* 開始   : 2026-08-04 19:15:00 (UTC)
* 終了   : 2026-08-04 19:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host04-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→20→22→23→…→22→23→18→19
* 開始   : 2026-08-05 08:30:00 (UTC)
* 終了   : 2026-08-05 08:35:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→24→22→23→26→23→24
* 開始   : 2026-08-05 10:15:00 (UTC)
* 終了   : 2026-08-05 11:00:00 (UTC)
* 現象   : 2026-08-05 11:00:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→13→19→14→13→19→14→15
* 開始   : 2026-08-05 17:55:00 (UTC)
* 終了   : 2026-08-05 19:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260805-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260805-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→9→13→9→13→9→12
* 開始   : 2026-08-05 19:45:00 (UTC)
* 終了   : 2026-08-05 19:55:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→11→8→7→…→8→7→10→8
* 開始   : 2026-08-05 21:25:00 (UTC)
* 終了   : 2026-08-05 21:30:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→9→6→9→6→9→8
* 開始   : 2026-08-05 21:45:00 (UTC)
* 終了   : 2026-08-05 21:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260805-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→6→5→11→…→5→11→8→7
* 開始   : 2026-08-05 23:20:00 (UTC)
* 終了   : 2026-08-05 23:25:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 8→7→5→9→…→9→11→10→9
* 開始   : 2026-08-05 23:55:00 (UTC)
* 終了   : 2026-08-06 00:05:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260805-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→16→…→16→20→19→17
* 開始   : 2026-08-06 07:45:00 (UTC)
* 終了   : 2026-08-06 07:55:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→17→18→16→17→16
* 開始   : 2026-08-06 16:30:00 (UTC)
* 終了   : 2026-08-06 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260806-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→15→14→17→…→14→17→13→16
* 開始   : 2026-08-06 17:05:00 (UTC)
* 終了   : 2026-08-06 17:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→13→11→13→11→13
* 開始   : 2026-08-06 19:00:00 (UTC)
* 終了   : 2026-08-06 19:10:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260806-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→10→10→9→8
* 開始   : 2026-08-06 21:55:00 (UTC)
* 終了   : 2026-08-06 22:25:00 (UTC)
* 現象   : 2026-08-06 22:25:00 (UTC)を境に水準が 14.91から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→19→17→19→17→19→15→18
* 開始   : 2026-08-07 06:40:00 (UTC)
* 終了   : 2026-08-07 06:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260807-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→17→20→16→17→20→16→20
* 開始   : 2026-08-07 09:20:00 (UTC)
* 終了   : 2026-08-07 09:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→23→21→19→23→21
* 開始   : 2026-08-07 10:10:00 (UTC)
* 終了   : 2026-08-07 10:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→21→24→22
* 開始   : 2026-08-07 13:55:00 (UTC)
* 終了   : 2026-08-07 14:55:00 (UTC)
* 現象   : 2026-08-07 14:55:00 (UTC)を境に水準が 14.91から12.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→21→19→23→21→19→23→21
* 開始   : 2026-08-07 14:05:00 (UTC)
* 終了   : 2026-08-07 14:10:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→12→15→12
* 開始   : 2026-08-07 18:30:00 (UTC)
* 終了   : 2026-08-07 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→15→…→10→12→10→12
* 開始   : 2026-08-07 19:20:00 (UTC)
* 終了   : 2026-08-07 19:45:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260807-host04-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→11→…→11→9→11→12
* 開始   : 2026-08-07 19:35:00 (UTC)
* 終了   : 2026-08-07 19:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260807-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host04-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→9→8→10→11→10
* 開始   : 2026-08-07 22:20:00 (UTC)
* 終了   : 2026-08-07 22:45:00 (UTC)
* 現象   : 2026-08-07 22:45:00 (UTC)を境に水準が 15.01から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→10→8→9→10
* 開始   : 2026-08-08 04:25:00 (UTC)
* 終了   : 2026-08-08 04:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260808-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260808-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260808-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→8→12
* 開始   : 2026-08-08 22:30:00 (UTC)
* 終了   : 2026-08-08 23:40:00 (UTC)
* 現象   : 2026-08-08 23:40:00 (UTC)を境に水準が 11.76から11.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260808-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→9→11→10→10→10→12→12
* 開始   : 2026-08-09 02:20:00 (UTC)
* 終了   : 2026-08-09 03:10:00 (UTC)
* 現象   : 2026-08-09 03:10:00 (UTC)を境に水準が 11.8から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.936, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→9→10→11→12
* 開始   : 2026-08-09 02:35:00 (UTC)
* 終了   : 2026-08-09 02:55:00 (UTC)
* 現象   : 2026-08-09 02:55:00 (UTC)を境に水準が 11.82から11.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→12→10→10→11→9→12→8→12
* 開始   : 2026-08-09 02:50:00 (UTC)
* 終了   : 2026-08-09 03:50:00 (UTC)
* 現象   : 2026-08-09 03:50:00 (UTC)を境に水準が 11.78から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→16→17→16→15→15→18
* 開始   : 2026-08-09 14:05:00 (UTC)
* 終了   : 2026-08-09 14:35:00 (UTC)
* 現象   : 2026-08-09 14:35:00 (UTC)を境に水準が 11.92から14.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→13→…→13→9→13→11
* 開始   : 2026-08-09 17:20:00 (UTC)
* 終了   : 2026-08-09 17:30:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→7→6→9→11→7→6→9→10
* 開始   : 2026-08-09 19:55:00 (UTC)
* 終了   : 2026-08-09 20:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260809-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→9→7→9→8
* 開始   : 2026-08-09 20:20:00 (UTC)
* 終了   : 2026-08-09 20:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→9→9→8→8→10→10
* 開始   : 2026-08-10 00:25:00 (UTC)
* 終了   : 2026-08-10 01:10:00 (UTC)
* 現象   : 2026-08-10 01:10:00 (UTC)を境に水準が 11.66から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→9→9→9→10→8→9→9→10
* 開始   : 2026-08-10 22:30:00 (UTC)
* 終了   : 2026-08-10 23:10:00 (UTC)
* 現象   : 2026-08-10 23:10:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→9→8→8→10→8→9→10→12
* 開始   : 2026-08-10 23:40:00 (UTC)
* 終了   : 2026-08-11 00:35:00 (UTC)
* 現象   : 2026-08-11 00:35:00 (UTC)を境に水準が 14.93から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→10→10→14→13→11→12
* 開始   : 2026-08-11 02:45:00 (UTC)
* 終了   : 2026-08-11 03:50:00 (UTC)
* 現象   : 2026-08-11 03:50:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→13→12→12→13→15→14→14→14
* 開始   : 2026-08-11 03:55:00 (UTC)
* 終了   : 2026-08-11 05:50:00 (UTC)
* 現象   : 2026-08-11 05:50:00 (UTC)を境に水準が 14.86から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.244, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→14→15→14→15→14→13
* 開始   : 2026-08-11 04:50:00 (UTC)
* 終了   : 2026-08-11 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 23→19→23→19→23→19→22
* 開始   : 2026-08-11 12:20:00 (UTC)
* 終了   : 2026-08-11 12:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→24
* 開始   : 2026-08-11 12:40:00 (UTC)
* 終了   : 2026-08-11 13:25:00 (UTC)
* 現象   : 2026-08-11 13:25:00 (UTC)を境に水準が 14.95から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→13→…→14→13→15→14
* 開始   : 2026-08-11 17:55:00 (UTC)
* 終了   : 2026-08-11 18:00:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→8→13→8→13→8→10
* 開始   : 2026-08-11 20:45:00 (UTC)
* 終了   : 2026-08-11 20:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260811-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260811-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→14→12→14→12→14→12
* 開始   : 2026-08-12 03:50:00 (UTC)
* 終了   : 2026-08-12 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→14→15→11→13→14→15→11→13
* 開始   : 2026-08-12 04:30:00 (UTC)
* 終了   : 2026-08-12 04:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260812-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→17→18→17→18→16→15
* 開始   : 2026-08-12 06:20:00 (UTC)
* 終了   : 2026-08-12 06:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→21→20→21→23→24→22
* 開始   : 2026-08-12 13:20:00 (UTC)
* 終了   : 2026-08-12 13:50:00 (UTC)
* 現象   : 2026-08-12 13:50:00 (UTC)を境に水準が 15.09から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→19→17→19→17→19
* 開始   : 2026-08-12 15:40:00 (UTC)
* 終了   : 2026-08-12 15:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→11→…→11→9→12→13
* 開始   : 2026-08-12 19:25:00 (UTC)
* 終了   : 2026-08-12 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260812-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→11→12→10→11→12
* 開始   : 2026-08-12 19:30:00 (UTC)
* 終了   : 2026-08-12 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→9→8→10→11→9→8→10
* 開始   : 2026-08-12 20:30:00 (UTC)
* 終了   : 2026-08-12 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→8→11
* 開始   : 2026-08-13 00:05:00 (UTC)
* 終了   : 2026-08-13 00:25:00 (UTC)
* 現象   : 2026-08-13 00:25:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.666, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→8→13→10→…→10→7→10→12
* 開始   : 2026-08-13 03:00:00 (UTC)
* 終了   : 2026-08-13 03:10:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260813-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→12→11→14→12→11
* 開始   : 2026-08-13 04:20:00 (UTC)
* 終了   : 2026-08-13 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260813-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→15→13→15→16→15→14
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→21→20→21→20→21→19→17
* 開始   : 2026-08-13 08:00:00 (UTC)
* 終了   : 2026-08-13 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→16→18→16→…→16→19→16→17
* 開始   : 2026-08-13 15:45:00 (UTC)
* 終了   : 2026-08-13 16:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→13→15→12→13→15→12→15→13
* 開始   : 2026-08-13 18:00:00 (UTC)
* 終了   : 2026-08-13 18:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→15→18→15→…→15→12→13→12
* 開始   : 2026-08-13 18:55:00 (UTC)
* 終了   : 2026-08-13 19:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→13
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 19:40:00 (UTC)
* 現象   : 2026-08-13 19:40:00 (UTC)を境に水準が 14.94から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→11→10→11→10→14→12
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→12→12→13
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 20:45:00 (UTC)
* 現象   : 2026-08-13 20:45:00 (UTC)を境に水準が 15から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→8→9→12→8→9→10
* 開始   : 2026-08-13 20:50:00 (UTC)
* 終了   : 2026-08-13 20:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260813-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260813-host04-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host04-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→11→7→11→7→8
* 開始   : 2026-08-13 23:30:00 (UTC)
* 終了   : 2026-08-13 23:35:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host04-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→10→12→10→12→10
* 開始   : 2026-08-14 02:45:00 (UTC)
* 終了   : 2026-08-14 02:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→16→12→16→…→16→15→17→15
* 開始   : 2026-08-14 05:25:00 (UTC)
* 終了   : 2026-08-14 05:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260814-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260814-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→16→17→16→17→13→14
* 開始   : 2026-08-14 05:35:00 (UTC)
* 終了   : 2026-08-14 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→22→22→22→22→23
* 開始   : 2026-08-14 10:10:00 (UTC)
* 終了   : 2026-08-14 10:35:00 (UTC)
* 現象   : 2026-08-14 10:35:00 (UTC)を境に水準が 15.01から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→25→20→24→25→20→22
* 開始   : 2026-08-14 10:40:00 (UTC)
* 終了   : 2026-08-14 10:45:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260814-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 24→23→21→23→24
* 開始   : 2026-08-14 11:05:00 (UTC)
* 終了   : 2026-08-14 11:25:00 (UTC)
* 現象   : 2026-08-14 11:25:00 (UTC)を境に水準が 14.97から13.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→21→19→23→19→23→19
* 開始   : 2026-08-14 13:25:00 (UTC)
* 終了   : 2026-08-14 13:35:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260814-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→19→19→18→20
* 開始   : 2026-08-14 15:45:00 (UTC)
* 終了   : 2026-08-14 16:05:00 (UTC)
* 現象   : 2026-08-14 16:05:00 (UTC)を境に水準が 14.97から12.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 7→9→5→10→9→5→10→8
* 開始   : 2026-08-14 23:50:00 (UTC)
* 終了   : 2026-08-14 23:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→19→16→13→19→16→13→16→17
* 開始   : 2026-08-16 11:10:00 (UTC)
* 終了   : 2026-08-16 11:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260816-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→10→9→9→9→9→11→11
* 開始   : 2026-08-17 01:45:00 (UTC)
* 終了   : 2026-08-17 02:40:00 (UTC)
* 現象   : 2026-08-17 02:40:00 (UTC)を境に水準が 11.81から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.994, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→10→9→7→10→11
* 開始   : 2026-08-17 22:05:00 (UTC)
* 終了   : 2026-08-17 22:10:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260817-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260817-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 7→9→12→9→12→9→12→10→12
* 開始   : 2026-08-18 02:45:00 (UTC)
* 終了   : 2026-08-18 02:55:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→10→13→11→10→13→11
* 開始   : 2026-08-18 03:15:00 (UTC)
* 終了   : 2026-08-18 03:20:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→15→17→16→18→18
* 開始   : 2026-08-18 06:20:00 (UTC)
* 終了   : 2026-08-18 06:45:00 (UTC)
* 現象   : 2026-08-18 06:45:00 (UTC)を境に水準が 14.98から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→19→16→15→19→16→17
* 開始   : 2026-08-18 06:55:00 (UTC)
* 終了   : 2026-08-18 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→23→22→20→23→22
* 開始   : 2026-08-18 10:00:00 (UTC)
* 終了   : 2026-08-18 10:05:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→21→16→21→16→18→17
* 開始   : 2026-08-18 15:40:00 (UTC)
* 終了   : 2026-08-18 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 18→16→20→20→16→15→17
* 開始   : 2026-08-18 17:15:00 (UTC)
* 終了   : 2026-08-18 17:45:00 (UTC)
* 現象   : 2026-08-18 17:45:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→18→14→13→14→13→15→16
* 開始   : 2026-08-18 17:45:00 (UTC)
* 終了   : 2026-08-18 17:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→13→10→13→10
* 開始   : 2026-08-18 19:50:00 (UTC)
* 終了   : 2026-08-18 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→12→…→12→8→11→9
* 開始   : 2026-08-18 20:45:00 (UTC)
* 終了   : 2026-08-18 20:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260818-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→10→7→10→…→10→13→9→10
* 開始   : 2026-08-19 03:30:00 (UTC)
* 終了   : 2026-08-19 03:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→21→20→19→20→21
* 開始   : 2026-08-19 08:00:00 (UTC)
* 終了   : 2026-08-19 08:25:00 (UTC)
* 現象   : 2026-08-19 08:25:00 (UTC)を境に水準が 15.02から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 23→21→19→23→…→23→26→21→20
* 開始   : 2026-08-19 11:45:00 (UTC)
* 終了   : 2026-08-19 11:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→16→17→14→16→15
* 開始   : 2026-08-19 17:20:00 (UTC)
* 終了   : 2026-08-19 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→11→9→13
* 開始   : 2026-08-19 21:45:00 (UTC)
* 終了   : 2026-08-19 22:10:00 (UTC)
* 現象   : 2026-08-19 22:10:00 (UTC)を境に水準が 14.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→11→14→10→14→10→14→11→12
* 開始   : 2026-08-20 04:20:00 (UTC)
* 終了   : 2026-08-20 04:30:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→17→18→15→18→15→18
* 開始   : 2026-08-20 06:30:00 (UTC)
* 終了   : 2026-08-20 06:40:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→19→21→18→19→21→18→19
* 開始   : 2026-08-20 07:45:00 (UTC)
* 終了   : 2026-08-20 07:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.628σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→21→20→21→20→21→20
* 開始   : 2026-08-20 08:15:00 (UTC)
* 終了   : 2026-08-20 08:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→15→11→15→11→14→11
* 開始   : 2026-08-20 19:15:00 (UTC)
* 終了   : 2026-08-20 19:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→12
* 開始   : 2026-08-20 21:30:00 (UTC)
* 終了   : 2026-08-20 21:40:00 (UTC)
* 現象   : 2026-08-20 21:40:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→10→6→8→10→6→8
* 開始   : 2026-08-20 22:50:00 (UTC)
* 終了   : 2026-08-20 22:55:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→8→12→10→8→12→10
* 開始   : 2026-08-21 01:45:00 (UTC)
* 終了   : 2026-08-21 01:50:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.548倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.954σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→16→20→21→20→21→19→20
* 開始   : 2026-08-21 07:50:00 (UTC)
* 終了   : 2026-08-21 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→23→…→24→23→21→23
* 開始   : 2026-08-21 10:55:00 (UTC)
* 終了   : 2026-08-21 11:00:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.21倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.905σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→18→17→19→18→17→19→21
* 開始   : 2026-08-21 15:00:00 (UTC)
* 終了   : 2026-08-21 15:05:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→16→18→19→16→18→19
* 開始   : 2026-08-21 16:00:00 (UTC)
* 終了   : 2026-08-21 16:05:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→15→17→14→15
* 開始   : 2026-08-21 17:15:00 (UTC)
* 終了   : 2026-08-21 17:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260821-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→12→9→11
* 開始   : 2026-08-21 22:05:00 (UTC)
* 終了   : 2026-08-21 22:25:00 (UTC)
* 現象   : 2026-08-21 22:25:00 (UTC)を境に水準が 15.01から11.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host04-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→13→11
* 開始   : 2026-08-21 22:15:00 (UTC)
* 終了   : 2026-08-21 22:25:00 (UTC)
* 現象   : 2026-08-21 22:25:00 (UTC)を境に水準が 14.93から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→10→11→10→…→11→10→12→13
* 開始   : 2026-08-22 04:45:00 (UTC)
* 終了   : 2026-08-22 04:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(11)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.804, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260822-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→9→…→11→10→12→13
* 開始   : 2026-08-22 04:50:00 (UTC)
* 終了   : 2026-08-22 05:15:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.328, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260822-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→12→…→13→11→12→14
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 05:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.086, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 20 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分

![EVT-20260822-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host04-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→9→7→8→9→7→8→9→11
* 開始   : 2026-08-22 20:55:00 (UTC)
* 終了   : 2026-08-22 21:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.323, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260822-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→8→13→9→…→9→14→10→11
* 開始   : 2026-08-23 04:45:00 (UTC)
* 終了   : 2026-08-23 04:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260823-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→13→13→12→13→13→15
* 開始   : 2026-08-23 05:55:00 (UTC)
* 終了   : 2026-08-23 06:25:00 (UTC)
* 現象   : 2026-08-23 06:25:00 (UTC)を境に水準が 11.93から12.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→16→13→16→13→16→15
* 開始   : 2026-08-23 13:55:00 (UTC)
* 終了   : 2026-08-23 14:05:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260823-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→14→…→14→12→16→14
* 開始   : 2026-08-23 14:35:00 (UTC)
* 終了   : 2026-08-23 14:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260823-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→16→19→14→16→14→14→17→16
* 開始   : 2026-08-23 14:55:00 (UTC)
* 終了   : 2026-08-23 16:00:00 (UTC)
* 現象   : 2026-08-23 16:00:00 (UTC)を境に水準が 11.87から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→11→…→10→11→14→11
* 開始   : 2026-08-23 16:20:00 (UTC)
* 終了   : 2026-08-23 16:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7101(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-037 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260823-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→12→10→10→10→11→8
* 開始   : 2026-08-23 20:50:00 (UTC)
* 終了   : 2026-08-23 21:45:00 (UTC)
* 現象   : 2026-08-23 21:45:00 (UTC)を境に水準が 11.87から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→12→14→12→14→11→12
* 開始   : 2026-08-25 04:20:00 (UTC)
* 終了   : 2026-08-25 04:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260825-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260825-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→12→13→14
* 開始   : 2026-08-25 04:30:00 (UTC)
* 終了   : 2026-08-25 04:55:00 (UTC)
* 現象   : 2026-08-25 04:55:00 (UTC)を境に水準が 14.75から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→16→14→17→18→16
* 開始   : 2026-08-25 06:20:00 (UTC)
* 終了   : 2026-08-25 06:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 18→21→19→21→19→21→19
* 開始   : 2026-08-25 08:00:00 (UTC)
* 終了   : 2026-08-25 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260825-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 20→19→21→17→…→17→22→20→19
* 開始   : 2026-08-25 08:35:00 (UTC)
* 終了   : 2026-08-25 08:45:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260825-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→20→15→14→…→15→14→17→15
* 開始   : 2026-08-25 17:10:00 (UTC)
* 終了   : 2026-08-25 17:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→10→12→13→11→10→12
* 開始   : 2026-08-25 19:10:00 (UTC)
* 終了   : 2026-08-25 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→7→…→8→7→9→12
* 開始   : 2026-08-25 20:40:00 (UTC)
* 終了   : 2026-08-25 20:45:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→8→11→10→8→11→9
* 開始   : 2026-08-25 20:55:00 (UTC)
* 終了   : 2026-08-25 21:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260825-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→5→7→12→5→7→12→8→9
* 開始   : 2026-08-26 01:10:00 (UTC)
* 終了   : 2026-08-26 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→19→20→21→…→20→21→20→17
* 開始   : 2026-08-26 07:45:00 (UTC)
* 終了   : 2026-08-26 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→20→22→20→22→20→19
* 開始   : 2026-08-26 08:10:00 (UTC)
* 終了   : 2026-08-26 08:15:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→20→23→21→…→24→23→19→20
* 開始   : 2026-08-26 09:25:00 (UTC)
* 終了   : 2026-08-26 09:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→18→22→18→22→18→20→19
* 開始   : 2026-08-26 15:00:00 (UTC)
* 終了   : 2026-08-26 15:30:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260826-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260826-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→18→18→16→18→17
* 開始   : 2026-08-26 17:05:00 (UTC)
* 終了   : 2026-08-26 17:30:00 (UTC)
* 現象   : 2026-08-26 17:30:00 (UTC)を境に水準が 14.86から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→14→13→17→18→14→13→17→15
* 開始   : 2026-08-26 17:15:00 (UTC)
* 終了   : 2026-08-26 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→16→15→14→13→16
* 開始   : 2026-08-26 18:00:00 (UTC)
* 終了   : 2026-08-26 18:05:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→13→11→12→13→11→12→14
* 開始   : 2026-08-26 18:55:00 (UTC)
* 終了   : 2026-08-26 19:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260826-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→7→6→7→6→7
* 開始   : 2026-08-26 23:05:00 (UTC)
* 終了   : 2026-08-26 23:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-081 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260826-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→9→10→9→10→9→10
* 開始   : 2026-08-27 00:55:00 (UTC)
* 終了   : 2026-08-27 02:00:00 (UTC)
* 現象   : 2026-08-27 02:00:00 (UTC)を境に水準が 14.93から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→17→18→19→18→20→18→19→21
* 開始   : 2026-08-27 07:05:00 (UTC)
* 終了   : 2026-08-27 07:50:00 (UTC)
* 現象   : 2026-08-27 07:50:00 (UTC)を境に水準が 15.04から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 23→21→25→24→25→24→25→22
* 開始   : 2026-08-27 12:15:00 (UTC)
* 終了   : 2026-08-27 12:25:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→19→17→20→19→17→20→18
* 開始   : 2026-08-27 15:55:00 (UTC)
* 終了   : 2026-08-27 16:00:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260827-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→17→13→14→17→13→14→15
* 開始   : 2026-08-27 17:55:00 (UTC)
* 終了   : 2026-08-27 18:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→9→…→9→5→9→8
* 開始   : 2026-08-27 23:20:00 (UTC)
* 終了   : 2026-08-27 23:30:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260827-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 6→7→12→7→…→7→5→9→8
* 開始   : 2026-08-27 23:35:00 (UTC)
* 終了   : 2026-08-27 23:45:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.905σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→10→10→9→11→9
* 開始   : 2026-08-28 01:15:00 (UTC)
* 終了   : 2026-08-28 01:50:00 (UTC)
* 現象   : 2026-08-28 01:50:00 (UTC)を境に水準が 15.12から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.408, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→18→16→18→16
* 開始   : 2026-08-28 06:20:00 (UTC)
* 終了   : 2026-08-28 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260828-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→25→22→18→25→22→18→21→23
* 開始   : 2026-08-28 13:40:00 (UTC)
* 終了   : 2026-08-28 13:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→14
* 開始   : 2026-08-28 19:25:00 (UTC)
* 終了   : 2026-08-28 19:40:00 (UTC)
* 現象   : 2026-08-28 19:40:00 (UTC)を境に水準が 14.96から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.652, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host04-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→12→10→9→12
* 開始   : 2026-08-29 04:40:00 (UTC)
* 終了   : 2026-08-29 04:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.145, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260829-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260829-host04-001 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
