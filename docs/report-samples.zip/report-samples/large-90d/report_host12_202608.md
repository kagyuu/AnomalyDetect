# host12 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host12 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 295 (SEVERE: 34, FATAL: 123, WARN: 138, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 34 | 123 | 138 | 295 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→8→9→9→9→10→7→11
* 開始   : 2026-08-03 00:15:00 (UTC)
* 終了   : 2026-08-03 00:50:00 (UTC)
* 現象   : 2026-08-03 00:50:00 (UTC)を境に水準が 11.78から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→15→16→14→…→14→13→14→13
* 開始   : 2026-08-03 02:30:00 (UTC)
* 終了   : 2026-08-03 19:10:00 (UTC)
* 現象   : 2026-08-03 19:10:00 (UTC)を境に水準が 11.91から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.73, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-003 active_connections の推移](charts/EVT-20260803-host12-003.svg)

# イベントID( EVT-20260803-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→14→…→14→13→15→12
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 20:15:00 (UTC)
* 現象   : 2026-08-03 20:15:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.49, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-004 active_connections の推移](charts/EVT-20260803-host12-004.svg)

# イベントID( EVT-20260803-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→14→…→16→14→13→14
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 19:25:00 (UTC)
* 現象   : 2026-08-03 19:25:00 (UTC)を境に水準が 11.84から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.962, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-006 active_connections の推移](charts/EVT-20260803-host12-006.svg)

# イベントID( EVT-20260803-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→15→…→14→15→11→13
* 開始   : 2026-08-03 04:20:00 (UTC)
* 終了   : 2026-08-03 19:35:00 (UTC)
* 現象   : 2026-08-03 19:35:00 (UTC)を境に水準が 11.92から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.008, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-009 active_connections の推移](charts/EVT-20260803-host12-009.svg)

# イベントID( EVT-20260805-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→13→14→12→13
* 開始   : 2026-08-05 04:05:00 (UTC)
* 終了   : 2026-08-05 04:25:00 (UTC)
* 現象   : 2026-08-05 04:25:00 (UTC)を境に水準が 14.89から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-006 active_connections の推移](charts/EVT-20260805-host12-006.svg)

# イベントID( EVT-20260805-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→18→17→16→18→18
* 開始   : 2026-08-05 06:00:00 (UTC)
* 終了   : 2026-08-05 06:25:00 (UTC)
* 現象   : 2026-08-05 06:25:00 (UTC)を境に水準が 14.98から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-008 active_connections の推移](charts/EVT-20260805-host12-008.svg)

# イベントID( EVT-20260809-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→10→12
* 開始   : 2026-08-09 22:40:00 (UTC)
* 終了   : 2026-08-09 23:00:00 (UTC)
* 現象   : 2026-08-09 23:00:00 (UTC)を境に水準が 11.86から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host12-006 active_connections の推移](charts/EVT-20260809-host12-006.svg)

# イベントID( EVT-20260810-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→14→…→10→13→11→12
* 開始   : 2026-08-10 02:25:00 (UTC)
* 終了   : 2026-08-10 20:35:00 (UTC)
* 現象   : 2026-08-10 20:35:00 (UTC)を境に水準が 11.69から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.767, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.404, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-001 active_connections の推移](charts/EVT-20260810-host12-001.svg)

# イベントID( EVT-20260810-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→15→18→17→…→12→15→12→14
* 開始   : 2026-08-10 02:25:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.86から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.677, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-002 active_connections の推移](charts/EVT-20260810-host12-002.svg)

# イベントID( EVT-20260810-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→14→…→12→14→11→13
* 開始   : 2026-08-10 03:00:00 (UTC)
* 終了   : 2026-08-10 19:40:00 (UTC)
* 現象   : 2026-08-10 19:40:00 (UTC)を境に水準が 11.81から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-003 active_connections の推移](charts/EVT-20260810-host12-003.svg)

# イベントID( EVT-20260810-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→16→…→14→15→14→15
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 20:35:00 (UTC)
* 現象   : 2026-08-10 20:35:00 (UTC)を境に水準が 11.91から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.889, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-004 active_connections の推移](charts/EVT-20260810-host12-004.svg)

# イベントID( EVT-20260810-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→16→…→16→15→12→14
* 開始   : 2026-08-10 03:45:00 (UTC)
* 終了   : 2026-08-10 21:15:00 (UTC)
* 現象   : 2026-08-10 21:15:00 (UTC)を境に水準が 11.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.004, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-005 active_connections の推移](charts/EVT-20260810-host12-005.svg)

# イベントID( EVT-20260810-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→15→…→12→14→13→11
* 開始   : 2026-08-10 04:25:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.854, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.895, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host12-006 active_connections の推移](charts/EVT-20260810-host12-006.svg)

# イベントID( EVT-20260812-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→12→15→12→14→14
* 開始   : 2026-08-12 03:25:00 (UTC)
* 終了   : 2026-08-12 04:00:00 (UTC)
* 現象   : 2026-08-12 04:00:00 (UTC)を境に水準が 15.01から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host12-001 active_connections の推移](charts/EVT-20260812-host12-001.svg)

# イベントID( EVT-20260813-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→11
* 開始   : 2026-08-13 01:45:00 (UTC)
* 終了   : 2026-08-13 02:05:00 (UTC)
* 現象   : 2026-08-13 02:05:00 (UTC)を境に水準が 15.07から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host12-001 active_connections の推移](charts/EVT-20260813-host12-001.svg)

# イベントID( EVT-20260814-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 24→24→24→21→22→21→20→21→25
* 開始   : 2026-08-14 12:55:00 (UTC)
* 終了   : 2026-08-14 13:55:00 (UTC)
* 現象   : 2026-08-14 13:55:00 (UTC)を境に水準が 14.96から12.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→…→13→15→14→15
* 開始   : 2026-08-17 01:55:00 (UTC)
* 終了   : 2026-08-17 21:30:00 (UTC)
* 現象   : 2026-08-17 21:30:00 (UTC)を境に水準が 11.76から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.888, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-002 active_connections の推移](charts/EVT-20260817-host12-002.svg)

# イベントID( EVT-20260817-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→15→19→18→…→16→13→14→12
* 開始   : 2026-08-17 02:40:00 (UTC)
* 終了   : 2026-08-17 22:25:00 (UTC)
* 現象   : 2026-08-17 22:25:00 (UTC)を境に水準が 11.79から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-003 active_connections の推移](charts/EVT-20260817-host12-003.svg)

# イベントID( EVT-20260817-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→14→13→14→…→15→12→10→11
* 開始   : 2026-08-17 02:50:00 (UTC)
* 終了   : 2026-08-17 20:35:00 (UTC)
* 現象   : 2026-08-17 20:35:00 (UTC)を境に水準が 11.78から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.697, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.766, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-004 active_connections の推移](charts/EVT-20260817-host12-004.svg)

# イベントID( EVT-20260817-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→16→…→13→15→11→14
* 開始   : 2026-08-17 03:05:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.187, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.225, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-005 active_connections の推移](charts/EVT-20260817-host12-005.svg)

# イベントID( EVT-20260817-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→14→…→16→14→12→13
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 21:50:00 (UTC)
* 現象   : 2026-08-17 21:50:00 (UTC)を境に水準が 11.89から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.928, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-006 active_connections の推移](charts/EVT-20260817-host12-006.svg)

# イベントID( EVT-20260817-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→12→…→13→15→13→14
* 開始   : 2026-08-17 03:20:00 (UTC)
* 終了   : 2026-08-17 21:40:00 (UTC)
* 現象   : 2026-08-17 21:40:00 (UTC)を境に水準が 11.82から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.974, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-007 active_connections の推移](charts/EVT-20260817-host12-007.svg)

# イベントID( EVT-20260819-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→21→20→18→20→17→17→19→20
* 開始   : 2026-08-19 16:00:00 (UTC)
* 終了   : 2026-08-19 17:30:00 (UTC)
* 現象   : 2026-08-19 17:30:00 (UTC)を境に水準が 14.95から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host12-007 active_connections の推移](charts/EVT-20260819-host12-007.svg)

# イベントID( EVT-20260820-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→21→21→22→23→22→21→21
* 開始   : 2026-08-20 09:10:00 (UTC)
* 終了   : 2026-08-20 09:45:00 (UTC)
* 現象   : 2026-08-20 09:45:00 (UTC)を境に水準が 14.88から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→17→16
* 開始   : 2026-08-23 13:10:00 (UTC)
* 終了   : 2026-08-23 13:30:00 (UTC)
* 現象   : 2026-08-23 13:30:00 (UTC)を境に水準が 11.71から13.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host12-001 active_connections の推移](charts/EVT-20260823-host12-001.svg)

# イベントID( EVT-20260824-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→14→13→…→17→14→17→14
* 開始   : 2026-08-24 02:15:00 (UTC)
* 終了   : 2026-08-24 21:25:00 (UTC)
* 現象   : 2026-08-24 21:25:00 (UTC)を境に水準が 11.87から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.814, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-001 active_connections の推移](charts/EVT-20260824-host12-001.svg)

# イベントID( EVT-20260824-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→14→…→13→14→11→15
* 開始   : 2026-08-24 02:20:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.7から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.08, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-002 active_connections の推移](charts/EVT-20260824-host12-002.svg)

# イベントID( EVT-20260824-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→16→…→15→14→12→13
* 開始   : 2026-08-24 02:25:00 (UTC)
* 終了   : 2026-08-24 20:40:00 (UTC)
* 現象   : 2026-08-24 20:40:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.722σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.877, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-003 active_connections の推移](charts/EVT-20260824-host12-003.svg)

# イベントID( EVT-20260824-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→13→…→13→14→13→15
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 22:30:00 (UTC)
* 現象   : 2026-08-24 22:30:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.768, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.405, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-004 active_connections の推移](charts/EVT-20260824-host12-004.svg)

# イベントID( EVT-20260824-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→18→…→11→13→11→13
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 19:40:00 (UTC)
* 現象   : 2026-08-24 19:40:00 (UTC)を境に水準が 11.86から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-005 active_connections の推移](charts/EVT-20260824-host12-005.svg)

# イベントID( EVT-20260824-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→7→10→10→9→10→9
* 開始   : 2026-08-24 22:00:00 (UTC)
* 終了   : 2026-08-24 23:10:00 (UTC)
* 現象   : 2026-08-24 23:10:00 (UTC)を境に水準が 14.87から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-007 active_connections の推移](charts/EVT-20260824-host12-007.svg)

# イベントID( EVT-20260827-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→20
* 開始   : 2026-08-27 16:35:00 (UTC)
* 終了   : 2026-08-27 16:50:00 (UTC)
* 現象   : 2026-08-27 16:50:00 (UTC)を境に水準が 15.09から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→13→13→13→11→11→12→14
* 開始   : 2026-08-28 19:55:00 (UTC)
* 終了   : 2026-08-28 20:40:00 (UTC)
* 現象   : 2026-08-28 20:40:00 (UTC)を境に水準が 14.91から11.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host12-011 active_connections の推移](charts/EVT-20260828-host12-011.svg)

# イベントID( EVT-20260801-host12-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→14→9→11→…→9→11→10→11
* 開始   : 2026-08-01 05:00:00 (UTC)
* 終了   : 2026-08-01 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→10→11→12→…→11→12→13→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.259, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260801-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→11→…→10→11→10→11
* 開始   : 2026-08-01 05:30:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.104, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host12-003 active_connections の推移](charts/EVT-20260801-host12-003.svg)

# イベントID( EVT-20260801-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→12→11→12→…→11→13→11→10
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.08, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260801-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→…→13→10→14→11
* 開始   : 2026-08-01 06:20:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.217, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260801-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→13→…→14→12→14→11
* 開始   : 2026-08-01 07:05:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260801-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260801-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 7→8→12→8→8
* 開始   : 2026-08-02 01:20:00 (UTC)
* 終了   : 2026-08-02 01:20:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→8→15→11→13
* 開始   : 2026-08-02 06:15:00 (UTC)
* 終了   : 2026-08-02 06:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→14→14
* 開始   : 2026-08-02 07:50:00 (UTC)
* 終了   : 2026-08-02 07:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→14→12→14→14→13
* 開始   : 2026-08-02 15:55:00 (UTC)
* 終了   : 2026-08-02 17:10:00 (UTC)
* 現象   : 2026-08-02 17:10:00 (UTC)を境に水準が 11.93から14.57へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→11→8→14→13
* 開始   : 2026-08-02 18:15:00 (UTC)
* 終了   : 2026-08-02 18:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→14→…→13→15→12→15
* 開始   : 2026-08-03 04:05:00 (UTC)
* 終了   : 2026-08-03 19:50:00 (UTC)
* 現象   : 2026-08-03 19:50:00 (UTC)を境に水準が 11.99から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.051, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→15→…→15→13→12→11
* 開始   : 2026-08-03 04:15:00 (UTC)
* 終了   : 2026-08-03 21:00:00 (UTC)
* 現象   : 2026-08-03 21:00:00 (UTC)を境に水準が 11.84から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.834, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.121, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→12→6→10→11
* 開始   : 2026-08-03 21:20:00 (UTC)
* 終了   : 2026-08-03 21:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260803-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→9→13→9→12
* 開始   : 2026-08-04 02:55:00 (UTC)
* 終了   : 2026-08-04 02:55:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→19→22→18→18
* 開始   : 2026-08-04 08:30:00 (UTC)
* 終了   : 2026-08-04 08:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 20→21→26→20→21
* 開始   : 2026-08-04 12:05:00 (UTC)
* 終了   : 2026-08-04 12:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→14→12→14→16
* 開始   : 2026-08-04 17:20:00 (UTC)
* 終了   : 2026-08-04 17:20:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→14→9→11→…→8→9→12→11
* 開始   : 2026-08-04 19:40:00 (UTC)
* 終了   : 2026-08-04 19:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→9→7
* 開始   : 2026-08-04 23:00:00 (UTC)
* 終了   : 2026-08-04 23:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 7→9→12→4→9→12→4→9→11
* 開始   : 2026-08-05 01:10:00 (UTC)
* 終了   : 2026-08-05 01:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→9→13→8→10
* 開始   : 2026-08-05 02:45:00 (UTC)
* 終了   : 2026-08-05 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260805-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→11→14→10→…→10→13→10→11
* 開始   : 2026-08-05 03:25:00 (UTC)
* 終了   : 2026-08-05 03:35:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260805-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→8→14→11→11
* 開始   : 2026-08-05 03:40:00 (UTC)
* 終了   : 2026-08-05 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→11→17→13→12
* 開始   : 2026-08-05 05:10:00 (UTC)
* 終了   : 2026-08-05 05:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→21→18→19→21→20→20→19→19
* 開始   : 2026-08-05 15:15:00 (UTC)
* 終了   : 2026-08-05 16:40:00 (UTC)
* 現象   : 2026-08-05 16:40:00 (UTC)を境に水準が 14.95から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→19→15→18→17
* 開始   : 2026-08-06 16:15:00 (UTC)
* 終了   : 2026-08-06 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→13→9→11→12
* 開始   : 2026-08-06 19:35:00 (UTC)
* 終了   : 2026-08-06 19:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→14→17→12→11
* 開始   : 2026-08-07 05:10:00 (UTC)
* 終了   : 2026-08-07 05:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→15→…→15→18→16→17
* 開始   : 2026-08-07 05:20:00 (UTC)
* 終了   : 2026-08-07 06:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→14→18→15→12
* 開始   : 2026-08-07 05:25:00 (UTC)
* 終了   : 2026-08-07 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host12-005 active_connections の推移](charts/EVT-20260807-host12-005.svg)

# イベントID( EVT-20260807-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→15→…→15→18→16→18
* 開始   : 2026-08-07 06:35:00 (UTC)
* 終了   : 2026-08-07 06:45:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260807-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→16→22→17→18
* 開始   : 2026-08-07 07:45:00 (UTC)
* 終了   : 2026-08-07 07:45:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→16→16
* 開始   : 2026-08-07 16:50:00 (UTC)
* 終了   : 2026-08-07 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host12-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→11→…→14→11→14→11
* 開始   : 2026-08-08 05:20:00 (UTC)
* 終了   : 2026-08-08 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260808-host12-001 active_connections の推移](charts/EVT-20260808-host12-001.svg)

# イベントID( EVT-20260808-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→11→13→12→13
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.229, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host12-002 active_connections の推移](charts/EVT-20260808-host12-002.svg)

# イベントID( EVT-20260808-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→…→11→10→11→10
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 18:55:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.778, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host12-003 active_connections の推移](charts/EVT-20260808-host12-003.svg)

# イベントID( EVT-20260808-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→12→…→12→13→12→10
* 開始   : 2026-08-08 05:35:00 (UTC)
* 終了   : 2026-08-08 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.075, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host12-004 active_connections の推移](charts/EVT-20260808-host12-004.svg)

# イベントID( EVT-20260808-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→10→…→9→10→13→12
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 18:50:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.052, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260808-host12-005 active_connections の推移](charts/EVT-20260808-host12-005.svg)

# イベントID( EVT-20260808-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→14→13→14→…→11→9→10→11
* 開始   : 2026-08-08 06:35:00 (UTC)
* 終了   : 2026-08-08 20:10:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.964, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.4 時間
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.4 時間

![EVT-20260808-host12-006 active_connections の推移](charts/EVT-20260808-host12-006.svg)

# イベントID( EVT-20260809-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→15→15→15→15→18→13→15→15
* 開始   : 2026-08-09 07:45:00 (UTC)
* 終了   : 2026-08-09 08:40:00 (UTC)
* 現象   : 2026-08-09 08:40:00 (UTC)を境に水準が 11.81から12.62へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→9→6→9→10
* 開始   : 2026-08-10 21:10:00 (UTC)
* 終了   : 2026-08-10 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→13→7→11→14→7→11→14→13
* 開始   : 2026-08-11 04:20:00 (UTC)
* 終了   : 2026-08-11 04:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260811-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→15→17→15→13
* 開始   : 2026-08-11 05:15:00 (UTC)
* 終了   : 2026-08-11 05:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 20→19→17→15→19→17→15→19→18
* 開始   : 2026-08-11 15:25:00 (UTC)
* 終了   : 2026-08-11 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host12-005 active_connections の推移](charts/EVT-20260811-host12-005.svg)

# イベントID( EVT-20260811-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→14→11
* 開始   : 2026-08-11 19:30:00 (UTC)
* 終了   : 2026-08-11 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→11→8→11→12
* 開始   : 2026-08-11 20:05:00 (UTC)
* 終了   : 2026-08-11 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→16→19
* 開始   : 2026-08-12 07:00:00 (UTC)
* 終了   : 2026-08-12 07:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.326倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host12-003 active_connections の推移](charts/EVT-20260812-host12-003.svg)

# イベントID( EVT-20260812-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→5→7→5→7→5→9
* 開始   : 2026-08-12 23:05:00 (UTC)
* 終了   : 2026-08-12 23:40:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260812-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→19→12→17→16→19→12→17
* 開始   : 2026-08-13 06:25:00 (UTC)
* 終了   : 2026-08-13 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→17→21→19→19
* 開始   : 2026-08-13 07:45:00 (UTC)
* 終了   : 2026-08-13 07:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→10→10
* 開始   : 2026-08-13 20:40:00 (UTC)
* 終了   : 2026-08-13 20:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260813-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→15→21→13→17→15→21→13→17
* 開始   : 2026-08-14 06:55:00 (UTC)
* 終了   : 2026-08-14 07:00:00 (UTC)
* 現象   : 金曜6時台の平常値(15.72)に対し 21であった
* 説明   : ALG-A1: 移動平均からの残差が 3.848σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 4.086σ 外れた (平常値=15.72)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host12-002 active_connections の推移](charts/EVT-20260814-host12-002.svg)

# イベントID( EVT-20260814-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→18→21→17→18
* 開始   : 2026-08-14 07:40:00 (UTC)
* 終了   : 2026-08-14 07:40:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→20→25→21→22
* 開始   : 2026-08-14 10:10:00 (UTC)
* 終了   : 2026-08-14 10:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→21→19
* 開始   : 2026-08-14 14:50:00 (UTC)
* 終了   : 2026-08-14 14:50:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→19→18→19→17→16→19→17→19
* 開始   : 2026-08-14 16:30:00 (UTC)
* 終了   : 2026-08-14 17:25:00 (UTC)
* 現象   : 2026-08-14 17:25:00 (UTC)を境に水準が 14.93から12.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 7→10→14→10→11
* 開始   : 2026-08-15 04:35:00 (UTC)
* 終了   : 2026-08-15 04:35:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260815-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→14→…→11→13→12→11
* 開始   : 2026-08-15 04:55:00 (UTC)
* 終了   : 2026-08-15 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260815-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→12→11→13→12
* 開始   : 2026-08-15 05:00:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260815-host12-004 active_connections の推移](charts/EVT-20260815-host12-004.svg)

# イベントID( EVT-20260815-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→10→13
* 開始   : 2026-08-15 05:25:00 (UTC)
* 終了   : 2026-08-15 05:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260815-host12-005 active_connections の推移](charts/EVT-20260815-host12-005.svg)

# イベントID( EVT-20260815-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→13→…→11→12→10→9
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.807, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host12-006 active_connections の推移](charts/EVT-20260815-host12-006.svg)

# イベントID( EVT-20260815-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→11→12→10→…→11→10→12→11
* 開始   : 2026-08-15 05:40:00 (UTC)
* 終了   : 2026-08-15 19:40:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.972, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260815-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260815-host12-007 active_connections の推移](charts/EVT-20260815-host12-007.svg)

# イベントID( EVT-20260815-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→13→…→11→12→11→10
* 開始   : 2026-08-15 06:30:00 (UTC)
* 終了   : 2026-08-15 19:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host12-008 active_connections の推移](charts/EVT-20260815-host12-008.svg)

# イベントID( EVT-20260815-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→12→…→12→11→12→10
* 開始   : 2026-08-15 06:40:00 (UTC)
* 終了   : 2026-08-15 18:50:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260815-host12-009 active_connections の推移](charts/EVT-20260815-host12-009.svg)

# イベントID( EVT-20260815-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→8→5→10→9
* 開始   : 2026-08-15 20:50:00 (UTC)
* 終了   : 2026-08-15 20:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260815-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→8→14→11→11
* 開始   : 2026-08-16 04:15:00 (UTC)
* 終了   : 2026-08-16 04:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→13→15→13→15→13→15→13
* 開始   : 2026-08-18 04:15:00 (UTC)
* 終了   : 2026-08-18 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→12→13
* 開始   : 2026-08-18 04:45:00 (UTC)
* 終了   : 2026-08-18 04:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→15→18→13→14
* 開始   : 2026-08-18 05:50:00 (UTC)
* 終了   : 2026-08-18 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→21→26→22→20
* 開始   : 2026-08-18 12:05:00 (UTC)
* 終了   : 2026-08-18 12:05:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→23→18→21→23
* 開始   : 2026-08-18 12:20:00 (UTC)
* 終了   : 2026-08-18 12:20:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→19→16→20→21
* 開始   : 2026-08-18 15:20:00 (UTC)
* 終了   : 2026-08-18 15:20:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→11→12
* 開始   : 2026-08-18 19:45:00 (UTC)
* 終了   : 2026-08-18 19:45:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→11→7→11→10
* 開始   : 2026-08-18 20:20:00 (UTC)
* 終了   : 2026-08-18 20:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.5563(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.881σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host12-012 active_connections の推移](charts/EVT-20260818-host12-012.svg)

# イベントID( EVT-20260819-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→13→16→11→12
* 開始   : 2026-08-19 04:25:00 (UTC)
* 終了   : 2026-08-19 04:25:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host12-002 active_connections の推移](charts/EVT-20260819-host12-002.svg)

# イベントID( EVT-20260819-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→15→21→16→19
* 開始   : 2026-08-19 07:30:00 (UTC)
* 終了   : 2026-08-19 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260819-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→18→14→16→…→16→13→16→15
* 開始   : 2026-08-19 17:20:00 (UTC)
* 終了   : 2026-08-19 17:30:00 (UTC)
* 現象   : 平常時(18)に対し 0.7778(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→8→7
* 開始   : 2026-08-19 22:35:00 (UTC)
* 終了   : 2026-08-19 22:35:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→11→13
* 開始   : 2026-08-20 04:35:00 (UTC)
* 終了   : 2026-08-20 04:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→11→16→15→17→16→15→17→13
* 開始   : 2026-08-20 05:35:00 (UTC)
* 終了   : 2026-08-20 06:25:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260820-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260820-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→15→20→15→14
* 開始   : 2026-08-20 06:45:00 (UTC)
* 終了   : 2026-08-20 06:45:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→18→20→18→15
* 開始   : 2026-08-20 07:00:00 (UTC)
* 終了   : 2026-08-20 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→14→16→12→…→12→13→15→14
* 開始   : 2026-08-20 17:40:00 (UTC)
* 終了   : 2026-08-20 17:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→16→19→16→19→18→18→18
* 開始   : 2026-08-21 06:00:00 (UTC)
* 終了   : 2026-08-21 07:20:00 (UTC)
* 現象   : 2026-08-21 07:20:00 (UTC)を境に水準が 15.01から14.48へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→19→19→18→18→16→18→16→16
* 開始   : 2026-08-21 15:00:00 (UTC)
* 終了   : 2026-08-21 19:10:00 (UTC)
* 現象   : 2026-08-21 19:10:00 (UTC)を境に水準が 14.98から12.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.972, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→16→14→16→18
* 開始   : 2026-08-21 17:00:00 (UTC)
* 終了   : 2026-08-21 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→17→13→16→18
* 開始   : 2026-08-21 17:20:00 (UTC)
* 終了   : 2026-08-21 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→7→10→11→7→10→9
* 開始   : 2026-08-21 21:25:00 (UTC)
* 終了   : 2026-08-21 21:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-077 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260821-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 8→9→13→7→7
* 開始   : 2026-08-22 02:35:00 (UTC)
* 終了   : 2026-08-22 02:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260822-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→11→10→11→9
* 開始   : 2026-08-22 03:55:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 15.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.96σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.964, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.5 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260822-host12-002 active_connections の推移](charts/EVT-20260822-host12-002.svg)

# イベントID( EVT-20260822-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10→…→13→12→13→14
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 18:25:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host12-004 active_connections の推移](charts/EVT-20260822-host12-004.svg)

# イベントID( EVT-20260822-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→13→…→12→14→12→14
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 18:35:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.731, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260822-host12-005 active_connections の推移](charts/EVT-20260822-host12-005.svg)

# イベントID( EVT-20260822-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→12→…→13→11→15→13
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:25:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.661, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260822-host12-006 active_connections の推移](charts/EVT-20260822-host12-006.svg)

# イベントID( EVT-20260822-host12-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→12→…→12→11→13→10
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 18:00:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260822-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→11→13→9→…→13→8→11→12
* 開始   : 2026-08-22 06:10:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.075, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host12-008 active_connections の推移](charts/EVT-20260822-host12-008.svg)

# イベントID( EVT-20260823-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→11→13→16→15
* 開始   : 2026-08-23 16:35:00 (UTC)
* 終了   : 2026-08-23 17:40:00 (UTC)
* 現象   : 2026-08-23 17:40:00 (UTC)を境に水準が 11.9から14.51へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.725σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→11→6→12→11
* 開始   : 2026-08-23 20:05:00 (UTC)
* 終了   : 2026-08-23 20:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→8→4→8→6
* 開始   : 2026-08-23 22:10:00 (UTC)
* 終了   : 2026-08-23 22:10:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 7→7→4→9→10
* 開始   : 2026-08-23 23:10:00 (UTC)
* 終了   : 2026-08-23 23:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260823-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→14→…→13→14→13→14
* 開始   : 2026-08-24 03:20:00 (UTC)
* 終了   : 2026-08-24 21:10:00 (UTC)
* 現象   : 2026-08-24 21:10:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.877, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→12→13
* 開始   : 2026-08-25 03:55:00 (UTC)
* 終了   : 2026-08-25 03:55:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 23→23→26→23→22
* 開始   : 2026-08-25 12:30:00 (UTC)
* 終了   : 2026-08-25 12:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→12→8→13→10
* 開始   : 2026-08-25 19:50:00 (UTC)
* 終了   : 2026-08-25 19:50:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→16→21→16→16
* 開始   : 2026-08-26 07:00:00 (UTC)
* 終了   : 2026-08-26 07:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→16→8→15→15
* 開始   : 2026-08-26 19:00:00 (UTC)
* 終了   : 2026-08-26 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.5517(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host12-006 active_connections の推移](charts/EVT-20260826-host12-006.svg)

# イベントID( EVT-20260826-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→9→6→9→10
* 開始   : 2026-08-26 21:15:00 (UTC)
* 終了   : 2026-08-26 21:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→18→17→13→14→18→17→13→14
* 開始   : 2026-08-27 05:50:00 (UTC)
* 終了   : 2026-08-27 05:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→13→18→16→16
* 開始   : 2026-08-27 06:10:00 (UTC)
* 終了   : 2026-08-27 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→14→19→16→17
* 開始   : 2026-08-27 06:10:00 (UTC)
* 終了   : 2026-08-27 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→20→25→23→21
* 開始   : 2026-08-27 10:25:00 (UTC)
* 終了   : 2026-08-27 10:25:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→16→20→20
* 開始   : 2026-08-27 16:00:00 (UTC)
* 終了   : 2026-08-27 16:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→11→16→13→12
* 開始   : 2026-08-28 04:35:00 (UTC)
* 終了   : 2026-08-28 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 22→20→27→21→21
* 開始   : 2026-08-28 11:35:00 (UTC)
* 終了   : 2026-08-28 11:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.261倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→20→16→19→21
* 開始   : 2026-08-28 15:00:00 (UTC)
* 終了   : 2026-08-28 15:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→16→13→14→…→13→14→19→15
* 開始   : 2026-08-28 17:05:00 (UTC)
* 終了   : 2026-08-28 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→11→9
* 開始   : 2026-08-29 03:30:00 (UTC)
* 終了   : 2026-08-29 03:30:00 (UTC)
* 現象   : 平常時(9)に対し 1.556倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260829-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260829-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→12→11→14→12
* 開始   : 2026-08-29 04:50:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260829-host12-002 active_connections の推移](charts/EVT-20260829-host12-002.svg)

# イベントID( EVT-20260829-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→10→…→10→9→11→12
* 開始   : 2026-08-29 05:10:00 (UTC)
* 終了   : 2026-08-29 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.965, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host12-004 active_connections の推移](charts/EVT-20260829-host12-004.svg)

# イベントID( EVT-20260829-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→10→11→12→…→13→12→11→13
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 19:40:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.796, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260829-host12-005 active_connections の推移](charts/EVT-20260829-host12-005.svg)

# イベントID( EVT-20260829-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→11→…→15→10→14→13
* 開始   : 2026-08-29 05:50:00 (UTC)
* 終了   : 2026-08-29 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260829-host12-006 active_connections の推移](charts/EVT-20260829-host12-006.svg)

# イベントID( EVT-20260829-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→14→…→14→11→12→11
* 開始   : 2026-08-29 05:55:00 (UTC)
* 終了   : 2026-08-29 19:35:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.989, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260829-host12-007 active_connections の推移](charts/EVT-20260829-host12-007.svg)

# イベントID( EVT-20260829-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→15→…→12→13→12→10
* 開始   : 2026-08-29 06:45:00 (UTC)
* 終了   : 2026-08-29 20:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.345, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-lsfhost01-037 (他ホスト) lsf_queue / run : FATAL / 重なり 13.6 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260829-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→14→11→12→14→12
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 05:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(11)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260801-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→12→13→16→12→11
* 開始   : 2026-08-02 07:10:00 (UTC)
* 終了   : 2026-08-02 07:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→13→18→15→13→18→15
* 開始   : 2026-08-02 11:30:00 (UTC)
* 終了   : 2026-08-02 11:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260802-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→15→14→12→15→16
* 開始   : 2026-08-02 15:05:00 (UTC)
* 終了   : 2026-08-02 15:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→15→15→12→11→15→14
* 開始   : 2026-08-02 16:55:00 (UTC)
* 終了   : 2026-08-02 17:35:00 (UTC)
* 現象   : 2026-08-02 17:35:00 (UTC)を境に水準が 11.78から14.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→7→…→13→7→6→7
* 開始   : 2026-08-02 21:15:00 (UTC)
* 終了   : 2026-08-02 21:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host02-007 (他ホスト) db_connection / active_connections : SEVERE / 重なり 0 分
  - EVT-20260802-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→9→7→9→10→8→10→9→10
* 開始   : 2026-08-03 00:40:00 (UTC)
* 終了   : 2026-08-03 01:25:00 (UTC)
* 現象   : 2026-08-03 01:25:00 (UTC)を境に水準が 11.78から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→12
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 02:50:00 (UTC)
* 現象   : 2026-08-03 02:50:00 (UTC)を境に水準が 11.76から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.162, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→8
* 開始   : 2026-08-03 21:20:00 (UTC)
* 終了   : 2026-08-03 21:35:00 (UTC)
* 現象   : 2026-08-03 21:35:00 (UTC)を境に水準が 14.98から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→8→12→6→…→9→13→11→9
* 開始   : 2026-08-04 02:45:00 (UTC)
* 終了   : 2026-08-04 03:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→13→14→11→…→12→16→12→13
* 開始   : 2026-08-04 04:15:00 (UTC)
* 終了   : 2026-08-04 04:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260804-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→16→10→14→13→16→10→14→15
* 開始   : 2026-08-04 05:30:00 (UTC)
* 終了   : 2026-08-04 05:35:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→19→18→19→16→17
* 開始   : 2026-08-04 06:50:00 (UTC)
* 終了   : 2026-08-04 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→16→19→15→…→16→20→15→18
* 開始   : 2026-08-04 06:55:00 (UTC)
* 終了   : 2026-08-04 07:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260804-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 24→23→22→22→20→23→22→22→21
* 開始   : 2026-08-04 13:40:00 (UTC)
* 終了   : 2026-08-04 14:50:00 (UTC)
* 現象   : 2026-08-04 14:50:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→17→16→17→15→16→15→16→15
* 開始   : 2026-08-04 17:25:00 (UTC)
* 終了   : 2026-08-04 18:30:00 (UTC)
* 現象   : 2026-08-04 18:30:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.508, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 8→12→7→10→12→7→10→8
* 開始   : 2026-08-04 21:15:00 (UTC)
* 終了   : 2026-08-04 21:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→9→9→11→9→10→8
* 開始   : 2026-08-05 00:00:00 (UTC)
* 終了   : 2026-08-05 00:30:00 (UTC)
* 現象   : 2026-08-05 00:30:00 (UTC)を境に水準が 15.05から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→18→17→18→…→18→15→18→14
* 開始   : 2026-08-05 06:20:00 (UTC)
* 終了   : 2026-08-05 06:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260805-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→20→21→19→18→20→21→19→16
* 開始   : 2026-08-05 07:30:00 (UTC)
* 終了   : 2026-08-05 07:35:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→16→21→20→…→20→22→20→19
* 開始   : 2026-08-05 08:15:00 (UTC)
* 終了   : 2026-08-05 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 23→23→23→23→24→22→23
* 開始   : 2026-08-05 10:55:00 (UTC)
* 終了   : 2026-08-05 11:25:00 (UTC)
* 現象   : 2026-08-05 11:25:00 (UTC)を境に水準が 14.96から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.284, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→16→19→16→19→18
* 開始   : 2026-08-05 15:55:00 (UTC)
* 終了   : 2026-08-05 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→17→17→18
* 開始   : 2026-08-05 17:15:00 (UTC)
* 終了   : 2026-08-05 17:35:00 (UTC)
* 現象   : 2026-08-05 17:35:00 (UTC)を境に水準が 15.07から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→15→13→12→…→13→12→14→13
* 開始   : 2026-08-05 18:05:00 (UTC)
* 終了   : 2026-08-05 18:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host12-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→14→13→13→13→14→13
* 開始   : 2026-08-05 18:45:00 (UTC)
* 終了   : 2026-08-05 19:35:00 (UTC)
* 現象   : 2026-08-05 19:35:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.445, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→13→14→10→…→10→15→12→14
* 開始   : 2026-08-06 03:20:00 (UTC)
* 終了   : 2026-08-06 04:35:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260806-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 35 分
  - EVT-20260806-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→13→14→12→14→11→12→11→13
* 開始   : 2026-08-06 19:10:00 (UTC)
* 終了   : 2026-08-06 20:00:00 (UTC)
* 現象   : 2026-08-06 20:00:00 (UTC)を境に水準が 14.91から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.185, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→14→12→11→12→10→11→12→11
* 開始   : 2026-08-06 20:15:00 (UTC)
* 終了   : 2026-08-06 20:55:00 (UTC)
* 現象   : 2026-08-06 20:55:00 (UTC)を境に水準が 14.8から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→12→13→12→9→12→13→12→11
* 開始   : 2026-08-07 03:20:00 (UTC)
* 終了   : 2026-08-07 03:25:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→15→14→11→15→14→13
* 開始   : 2026-08-07 04:50:00 (UTC)
* 終了   : 2026-08-07 04:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→11→16→14→11→16→14→15
* 開始   : 2026-08-07 05:25:00 (UTC)
* 終了   : 2026-08-07 05:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→21→23→21→23→21→23→21→23
* 開始   : 2026-08-07 09:45:00 (UTC)
* 終了   : 2026-08-07 09:55:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→23→25→19→21→23→25→19→21
* 開始   : 2026-08-07 12:10:00 (UTC)
* 終了   : 2026-08-07 12:15:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260807-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→12→15→12→15→13
* 開始   : 2026-08-07 18:05:00 (UTC)
* 終了   : 2026-08-07 18:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→12→14→12→14→12→14→12
* 開始   : 2026-08-07 18:30:00 (UTC)
* 終了   : 2026-08-07 18:40:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→15→11→15→11→13
* 開始   : 2026-08-07 18:50:00 (UTC)
* 終了   : 2026-08-07 19:00:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260807-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→8→12→7→8→10→9→9→11
* 開始   : 2026-08-09 00:25:00 (UTC)
* 終了   : 2026-08-09 01:10:00 (UTC)
* 現象   : 2026-08-09 01:10:00 (UTC)を境に水準が 11.87から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→10→12→10→12→10→12→14
* 開始   : 2026-08-09 16:55:00 (UTC)
* 終了   : 2026-08-09 17:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→12→12→11→12→12→12→11→12
* 開始   : 2026-08-09 18:45:00 (UTC)
* 終了   : 2026-08-09 20:20:00 (UTC)
* 現象   : 2026-08-09 20:20:00 (UTC)を境に水準が 11.82から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.364, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→9→10→11
* 開始   : 2026-08-09 20:50:00 (UTC)
* 終了   : 2026-08-09 21:15:00 (UTC)
* 現象   : 2026-08-09 21:15:00 (UTC)を境に水準が 11.78から14.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→8→10→8→8→10→8→9
* 開始   : 2026-08-11 00:10:00 (UTC)
* 終了   : 2026-08-11 00:45:00 (UTC)
* 現象   : 2026-08-11 00:45:00 (UTC)を境に水準が 14.84から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.433, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→13→15→16→…→15→16→12→14
* 開始   : 2026-08-11 05:10:00 (UTC)
* 終了   : 2026-08-11 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260811-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→16→12→16→12→13→14
* 開始   : 2026-08-11 18:45:00 (UTC)
* 終了   : 2026-08-11 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→11→10→9→9→8→9
* 開始   : 2026-08-11 21:40:00 (UTC)
* 終了   : 2026-08-11 22:50:00 (UTC)
* 現象   : 2026-08-11 22:50:00 (UTC)を境に水準が 15.01から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→18→…→17→18→17→16
* 開始   : 2026-08-12 06:15:00 (UTC)
* 終了   : 2026-08-12 06:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→20→19→21→20→19→21→20→19
* 開始   : 2026-08-12 08:00:00 (UTC)
* 終了   : 2026-08-12 08:10:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 23→22→24→23→22→21→25→22→23
* 開始   : 2026-08-12 09:55:00 (UTC)
* 終了   : 2026-08-12 10:55:00 (UTC)
* 現象   : 2026-08-12 10:55:00 (UTC)を境に水準が 15.05から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.582, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→18→…→18→23→21→20
* 開始   : 2026-08-12 15:20:00 (UTC)
* 終了   : 2026-08-12 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→15→18→14→15→18→14→16
* 開始   : 2026-08-12 17:10:00 (UTC)
* 終了   : 2026-08-12 17:20:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→9→…→9→15→12→9
* 開始   : 2026-08-12 19:50:00 (UTC)
* 終了   : 2026-08-12 20:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260812-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260812-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→12→8→12→8→12→8→11→10
* 開始   : 2026-08-12 20:30:00 (UTC)
* 終了   : 2026-08-12 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→13→…→11→7→11→9
* 開始   : 2026-08-12 21:25:00 (UTC)
* 終了   : 2026-08-12 21:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→9→12→8→9→12→8→10
* 開始   : 2026-08-13 02:05:00 (UTC)
* 終了   : 2026-08-13 02:10:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.516倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→16→15→18
* 開始   : 2026-08-13 05:05:00 (UTC)
* 終了   : 2026-08-13 06:05:00 (UTC)
* 現象   : 2026-08-13 06:05:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→19→15→20→21→15→20→21→20
* 開始   : 2026-08-13 08:15:00 (UTC)
* 終了   : 2026-08-13 08:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→22→23→21→20→22→23→21
* 開始   : 2026-08-13 09:15:00 (UTC)
* 終了   : 2026-08-13 09:20:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→20→15→18→…→18→14→16→18
* 開始   : 2026-08-13 16:45:00 (UTC)
* 終了   : 2026-08-13 16:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→14→15→13→14→16
* 開始   : 2026-08-13 17:45:00 (UTC)
* 終了   : 2026-08-13 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→15→…→14→15→13→14
* 開始   : 2026-08-13 17:45:00 (UTC)
* 終了   : 2026-08-13 18:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→13→11→12→13→11→13
* 開始   : 2026-08-13 18:40:00 (UTC)
* 終了   : 2026-08-13 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→9→12→8→9→12→8→10→11
* 開始   : 2026-08-13 20:10:00 (UTC)
* 終了   : 2026-08-13 20:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→9→13→9→13→9→12→11
* 開始   : 2026-08-13 20:20:00 (UTC)
* 終了   : 2026-08-13 20:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260813-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→9→6→9→6→10→6
* 開始   : 2026-08-13 22:00:00 (UTC)
* 終了   : 2026-08-13 22:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-064 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260813-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→7→5→12→7→5→12→7→9
* 開始   : 2026-08-13 22:20:00 (UTC)
* 終了   : 2026-08-13 22:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.5455(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.902σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host09-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-065 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260813-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host12-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→7→10→9→8→9→9→11→8
* 開始   : 2026-08-13 22:35:00 (UTC)
* 終了   : 2026-08-13 23:15:00 (UTC)
* 現象   : 2026-08-13 23:15:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→13→11→13→10
* 開始   : 2026-08-14 03:15:00 (UTC)
* 終了   : 2026-08-14 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→18→19→20→18→19→20→18→17
* 開始   : 2026-08-14 07:35:00 (UTC)
* 終了   : 2026-08-14 07:40:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→18→19→21→19→19→21→21→22
* 開始   : 2026-08-14 08:10:00 (UTC)
* 終了   : 2026-08-14 08:55:00 (UTC)
* 現象   : 2026-08-14 08:55:00 (UTC)を境に水準が 15.01から14.24へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→18→18→18→14→17
* 開始   : 2026-08-14 17:25:00 (UTC)
* 終了   : 2026-08-14 18:05:00 (UTC)
* 現象   : 2026-08-14 18:05:00 (UTC)を境に水準が 15.07から12.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.075, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→15→…→15→12→15→12
* 開始   : 2026-08-14 18:20:00 (UTC)
* 終了   : 2026-08-14 18:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260814-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→16→12→15→12→15→12→15→13
* 開始   : 2026-08-14 18:30:00 (UTC)
* 終了   : 2026-08-14 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260814-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→14→11→8→14→11→10
* 開始   : 2026-08-14 20:20:00 (UTC)
* 終了   : 2026-08-14 20:25:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→9→11→9→11→8
* 開始   : 2026-08-15 00:15:00 (UTC)
* 終了   : 2026-08-15 00:25:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-001 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260815-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→11→…→11→6→9→11
* 開始   : 2026-08-15 20:50:00 (UTC)
* 終了   : 2026-08-15 21:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260815-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260815-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→…→9→7→8→9
* 開始   : 2026-08-15 21:10:00 (UTC)
* 終了   : 2026-08-15 21:20:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 6→8→10→9→10→9→10→8→9
* 開始   : 2026-08-16 01:20:00 (UTC)
* 終了   : 2026-08-16 01:30:00 (UTC)
* 現象   : 平常時(6.833)に対し 1.463倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→15→12→17→15→14
* 開始   : 2026-08-16 14:35:00 (UTC)
* 終了   : 2026-08-16 14:40:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260816-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→11→15→11→15→16
* 開始   : 2026-08-16 16:10:00 (UTC)
* 終了   : 2026-08-16 16:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→14→11→14→11→14
* 開始   : 2026-08-16 16:35:00 (UTC)
* 終了   : 2026-08-16 16:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→15→10→13→15→10→13→12
* 開始   : 2026-08-16 17:30:00 (UTC)
* 終了   : 2026-08-16 17:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260816-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260816-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260816-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→9→7→9→9→9
* 開始   : 2026-08-17 00:30:00 (UTC)
* 終了   : 2026-08-17 00:55:00 (UTC)
* 現象   : 2026-08-17 00:55:00 (UTC)を境に水準が 11.82から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→10→7→6→…→7→6→8→9
* 開始   : 2026-08-17 22:00:00 (UTC)
* 終了   : 2026-08-17 22:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260817-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260817-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 7→8→12→9→8→12→9→11
* 開始   : 2026-08-18 02:35:00 (UTC)
* 終了   : 2026-08-18 02:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→18→16→18→16→18→19
* 開始   : 2026-08-18 15:15:00 (UTC)
* 終了   : 2026-08-18 16:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260818-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260818-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→18→13→15→13→15→13→14→15
* 開始   : 2026-08-18 18:05:00 (UTC)
* 終了   : 2026-08-18 18:15:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→13→12→13→…→13→11→13→15
* 開始   : 2026-08-18 18:40:00 (UTC)
* 終了   : 2026-08-18 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host12-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→9→10→8→10→9
* 開始   : 2026-08-18 23:40:00 (UTC)
* 終了   : 2026-08-19 00:05:00 (UTC)
* 現象   : 2026-08-19 00:05:00 (UTC)を境に水準が 15.04から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.075, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→10→11→9
* 開始   : 2026-08-19 00:55:00 (UTC)
* 終了   : 2026-08-19 01:10:00 (UTC)
* 現象   : 2026-08-19 01:10:00 (UTC)を境に水準が 14.87から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→17→18→…→17→18→15→17
* 開始   : 2026-08-19 06:10:00 (UTC)
* 終了   : 2026-08-19 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→19→17→16→…→17→19→18→17
* 開始   : 2026-08-19 06:25:00 (UTC)
* 終了   : 2026-08-19 06:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260819-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→25→23→19→25→23→19→22→25
* 開始   : 2026-08-19 11:55:00 (UTC)
* 終了   : 2026-08-19 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→8→9→10→7→8→10
* 開始   : 2026-08-20 00:10:00 (UTC)
* 終了   : 2026-08-20 00:40:00 (UTC)
* 現象   : 2026-08-20 00:40:00 (UTC)を境に水準が 14.99から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 18→20→17→18→20→17→18
* 開始   : 2026-08-20 07:40:00 (UTC)
* 終了   : 2026-08-20 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→20→21→20→21→20→21
* 開始   : 2026-08-20 08:25:00 (UTC)
* 終了   : 2026-08-20 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→14→11→12→…→12→10→13→14
* 開始   : 2026-08-20 19:00:00 (UTC)
* 終了   : 2026-08-20 19:10:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host07-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→12→…→12→8→11→12
* 開始   : 2026-08-20 20:05:00 (UTC)
* 終了   : 2026-08-20 20:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→8→12→11→8→12
* 開始   : 2026-08-20 20:25:00 (UTC)
* 終了   : 2026-08-20 20:30:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→11→8→6→11→9
* 開始   : 2026-08-20 22:00:00 (UTC)
* 終了   : 2026-08-20 22:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→12→11→13→12→11→13→10→8
* 開始   : 2026-08-21 02:35:00 (UTC)
* 終了   : 2026-08-21 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→16→17→18→…→17→18→15→16
* 開始   : 2026-08-21 06:25:00 (UTC)
* 終了   : 2026-08-21 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260821-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→18→19→20→16→18→19→20→16
* 開始   : 2026-08-21 07:10:00 (UTC)
* 終了   : 2026-08-21 07:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→20→18→20→18→21
* 開始   : 2026-08-21 15:15:00 (UTC)
* 終了   : 2026-08-21 15:20:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→17→12→11→…→12→11→15→12
* 開始   : 2026-08-21 18:30:00 (UTC)
* 終了   : 2026-08-21 18:35:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260821-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→11→15→14→11→15
* 開始   : 2026-08-21 19:10:00 (UTC)
* 終了   : 2026-08-21 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→12→11→8→12→10
* 開始   : 2026-08-21 21:00:00 (UTC)
* 終了   : 2026-08-21 21:05:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→9→7→10→9→7→10→11
* 開始   : 2026-08-21 21:35:00 (UTC)
* 終了   : 2026-08-21 21:40:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→6→7→6→7→6→8→7
* 開始   : 2026-08-21 22:40:00 (UTC)
* 終了   : 2026-08-21 22:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260821-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→10→11→13→10→11
* 開始   : 2026-08-22 04:35:00 (UTC)
* 終了   : 2026-08-22 04:40:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260822-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260822-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→7→9→7→9→7→11→10
* 開始   : 2026-08-22 20:10:00 (UTC)
* 終了   : 2026-08-22 20:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260822-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260822-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→11→12→11→11→12→13
* 開始   : 2026-08-23 18:50:00 (UTC)
* 終了   : 2026-08-23 19:20:00 (UTC)
* 現象   : 2026-08-23 19:20:00 (UTC)を境に水準が 11.87から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→6→5→6→8→6→5→6
* 開始   : 2026-08-23 22:20:00 (UTC)
* 終了   : 2026-08-23 22:25:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260823-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→5→8→10→6→5→8
* 開始   : 2026-08-24 22:35:00 (UTC)
* 終了   : 2026-08-24 22:40:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-host12-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260824-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→6→8→9→6→8→9
* 開始   : 2026-08-24 22:35:00 (UTC)
* 終了   : 2026-08-24 22:40:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-host12-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260824-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→9→12→13→12→13→11→9
* 開始   : 2026-08-25 02:40:00 (UTC)
* 終了   : 2026-08-25 02:50:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→17→15→17→…→17→18→15→16
* 開始   : 2026-08-25 06:20:00 (UTC)
* 終了   : 2026-08-25 06:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260825-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→18→19→18→19→16
* 開始   : 2026-08-25 06:50:00 (UTC)
* 終了   : 2026-08-25 07:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→19→23→18→…→18→16→19→20
* 開始   : 2026-08-25 15:30:00 (UTC)
* 終了   : 2026-08-25 15:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→15→16→15→16→15→19
* 開始   : 2026-08-25 16:50:00 (UTC)
* 終了   : 2026-08-25 17:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→11→12→11→12→12
* 開始   : 2026-08-26 02:45:00 (UTC)
* 終了   : 2026-08-26 03:10:00 (UTC)
* 現象   : 2026-08-26 03:10:00 (UTC)を境に水準が 15.06から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.895, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→21→…→20→21→17→19
* 開始   : 2026-08-26 07:55:00 (UTC)
* 終了   : 2026-08-26 08:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→17→19→19→20→17→18→21→18
* 開始   : 2026-08-26 15:50:00 (UTC)
* 終了   : 2026-08-26 16:40:00 (UTC)
* 現象   : 2026-08-26 16:40:00 (UTC)を境に水準が 14.94から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→16→15→14→…→15→14→18→17
* 開始   : 2026-08-26 16:40:00 (UTC)
* 終了   : 2026-08-26 16:45:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→8→9→5→8→6
* 開始   : 2026-08-27 00:05:00 (UTC)
* 終了   : 2026-08-27 00:10:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→14→16→14→17→16→14→17→14
* 開始   : 2026-08-27 04:55:00 (UTC)
* 終了   : 2026-08-27 05:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→19→20→18→17→19→20→18→17
* 開始   : 2026-08-27 07:05:00 (UTC)
* 終了   : 2026-08-27 07:10:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→9→…→12→9→11→9
* 開始   : 2026-08-27 19:55:00 (UTC)
* 終了   : 2026-08-27 20:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260827-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→7→…→7→6→7→9
* 開始   : 2026-08-27 22:15:00 (UTC)
* 終了   : 2026-08-27 22:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host12-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→8→11→9→10→8→8→9
* 開始   : 2026-08-27 23:50:00 (UTC)
* 終了   : 2026-08-28 00:25:00 (UTC)
* 現象   : 2026-08-28 00:25:00 (UTC)を境に水準が 15.06から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→10
* 開始   : 2026-08-28 00:05:00 (UTC)
* 終了   : 2026-08-28 00:20:00 (UTC)
* 現象   : 2026-08-28 00:20:00 (UTC)を境に水準が 14.98から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.162, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→9→12→11→9→12→11→10
* 開始   : 2026-08-28 02:40:00 (UTC)
* 終了   : 2026-08-28 02:45:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260828-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→14→…→14→17→14→15
* 開始   : 2026-08-28 05:40:00 (UTC)
* 終了   : 2026-08-28 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→18→16→15→18→16→18
* 開始   : 2026-08-28 06:30:00 (UTC)
* 終了   : 2026-08-28 06:35:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→20→…→20→23→19→21
* 開始   : 2026-08-28 08:40:00 (UTC)
* 終了   : 2026-08-28 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→18→15→16→18→15→16→18
* 開始   : 2026-08-28 16:45:00 (UTC)
* 終了   : 2026-08-28 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→9→12→8→9→12→8→9
* 開始   : 2026-08-28 20:10:00 (UTC)
* 終了   : 2026-08-28 20:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→7→9→6→7→8
* 開始   : 2026-08-28 22:10:00 (UTC)
* 終了   : 2026-08-28 22:15:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→11→8→10→…→10→11→12→11
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 05:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260829-host12-003 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
