# 異常検知サマリ 2026-06

## 1. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| ホスト数 | 17 |
| 系列数 | 156 |
| 検知イベント数 | 7157 (SEVERE: 441, FATAL: 2895, WARN: 3821, INFO: 0) |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 2. ホスト別の集計

| ホスト | SEVERE | FATAL | WARN | 計 | 主なメトリクス | レポート |
| --- | --- | --- | --- | --- | --- | --- |
| lsfhost01 | 48 | 819 | 1261 | 2128 | pend, run, njobs | report_lsfhost01_202606.md |
| host08 | 40 | 118 | 147 | 305 | active_connections | report_host08_202606.md |
| host11 | 38 | 121 | 173 | 332 | active_connections | report_host11_202606.md |
| host12 | 36 | 135 | 156 | 327 | active_connections | report_host12_202606.md |
| host03 | 26 | 137 | 139 | 302 | active_connections | report_host03_202606.md |
| host02 | 26 | 131 | 182 | 339 | active_connections, ou, mu | report_host02_202606.md |
| host01 | 24 | 153 | 175 | 352 | active_connections, eu, fgc_delta | report_host01_202606.md |
| host14 | 23 | 132 | 163 | 318 | active_connections | report_host14_202606.md |
| host09 | 23 | 130 | 143 | 296 | active_connections | report_host09_202606.md |
| host16 | 21 | 133 | 174 | 328 | active_connections | report_host16_202606.md |

(ほか 7 ホスト。脅威度の高い順に上位 10 件のみ表示。全ホストのファイルは report_*_202606.md にある)

## 3. 日別のイベント数

| 日 | SEVERE | FATAL | WARN | 計 |
| --- | --- | --- | --- | --- |
| 06-02 | 3 | 104 | 167 | 274 |
| 06-09 | 5 | 104 | 172 | 281 |
| 06-10 | 7 | 105 | 176 | 288 |
| 06-11 | 3 | 103 | 179 | 285 |
| 06-12 | 2 | 114 | 187 | 303 |
| 06-17 | 5 | 108 | 183 | 296 |
| 06-18 | 3 | 106 | 163 | 272 |
| 06-24 | 5 | 129 | 166 | 300 |
| 06-25 | 5 | 116 | 170 | 291 |
| 06-26 | 2 | 111 | 171 | 284 |

(全 30 日中、イベント数の多い上位 10 日のみ表示)

## 4. 複数ホストで同時に発生したアノマリー

| 時間帯 | ホスト数 | イベント数 | 関与したホスト | 主なメトリクス |
| --- | --- | --- | --- | --- |
| 2026-06-06 05:35 | 15 | 12 | host01, host02, host03 ほか 12 件 | active_connections, eu |
| 2026-06-27 05:15 | 12 | 9 | host01, host02, host03 ほか 9 件 | active_connections, njobs |
| 2026-06-13 05:35 | 10 | 8 | host01, host02, host04 ほか 7 件 | active_connections, eu |
| 2026-06-27 06:05 | 9 | 8 | host01, host02, host03 ほか 6 件 | active_connections, eu |
| 2026-06-20 05:25 | 14 | 7 | host01, host02, host03 ほか 11 件 | active_connections, eu |
| 2026-06-06 05:55 | 13 | 7 | host01, host02, host03 ほか 10 件 | active_connections, eu, njobs |
| 2026-06-20 05:10 | 13 | 7 | host01, host03, host04 ほか 10 件 | active_connections, eu, njobs |
| 2026-06-20 05:20 | 13 | 7 | host01, host02, host03 ほか 10 件 | active_connections, eu |

(ほか 2676 件。件数の多い順に上位 8 件のみ表示)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
