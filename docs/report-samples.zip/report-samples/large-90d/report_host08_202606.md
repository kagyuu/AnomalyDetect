# host08 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host08 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 305 (SEVERE: 40, FATAL: 118, WARN: 147, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 40 | 118 | 147 | 305 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260603-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→22→19→19→17→18→18→20→21
* 開始   : 2026-06-03 07:20:00 (UTC)
* 終了   : 2026-06-03 08:35:00 (UTC)
* 現象   : 2026-06-03 08:35:00 (UTC)を境に水準が 14.95から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.534σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.983, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-006 active_connections の推移](charts/EVT-20260603-host08-006.svg)

# イベントID( EVT-20260603-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 22→21→23
* 開始   : 2026-06-03 14:00:00 (UTC)
* 終了   : 2026-06-03 14:10:00 (UTC)
* 現象   : 2026-06-03 14:10:00 (UTC)を境に水準が 15.05から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.934, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→9→10→8
* 開始   : 2026-06-03 22:45:00 (UTC)
* 終了   : 2026-06-03 23:10:00 (UTC)
* 現象   : 2026-06-03 23:10:00 (UTC)を境に水準が 15.08から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→20→22
* 開始   : 2026-06-04 07:55:00 (UTC)
* 終了   : 2026-06-04 08:15:00 (UTC)
* 現象   : 2026-06-04 08:15:00 (UTC)を境に水準が 15.11から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host08-004 active_connections の推移](charts/EVT-20260604-host08-004.svg)

# イベントID( EVT-20260607-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→14→13→13
* 開始   : 2026-06-07 16:55:00 (UTC)
* 終了   : 2026-06-07 17:40:00 (UTC)
* 現象   : 2026-06-07 17:40:00 (UTC)を境に水準が 11.81から14.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host08-005 active_connections の推移](charts/EVT-20260607-host08-005.svg)

# イベントID( EVT-20260608-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→12→14→12→11
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 21:50:00 (UTC)
* 現象   : 2026-06-08 21:50:00 (UTC)を境に水準が 11.8から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.776, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-001 active_connections の推移](charts/EVT-20260608-host08-001.svg)

# イベントID( EVT-20260608-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→15→14→12→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.684, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-002 active_connections の推移](charts/EVT-20260608-host08-002.svg)

# イベントID( EVT-20260608-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→16→…→19→16→14→16
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 19:40:00 (UTC)
* 現象   : 2026-06-08 19:40:00 (UTC)を境に水準が 11.79から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.842, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-003 active_connections の推移](charts/EVT-20260608-host08-003.svg)

# イベントID( EVT-20260608-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→15→17→18→…→12→13→11→10
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 19:50:00 (UTC)
* 現象   : 2026-06-08 19:50:00 (UTC)を境に水準が 11.92から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.297, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.567, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-004 active_connections の推移](charts/EVT-20260608-host08-004.svg)

# イベントID( EVT-20260608-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→14→…→13→14→12→14
* 開始   : 2026-06-08 04:30:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.776, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-007 active_connections の推移](charts/EVT-20260608-host08-007.svg)

# イベントID( EVT-20260609-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→8→8→9→8→9
* 開始   : 2026-06-09 23:55:00 (UTC)
* 終了   : 2026-06-10 00:20:00 (UTC)
* 現象   : 2026-06-10 00:20:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→19→20→21→22
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:35:00 (UTC)
* 現象   : 2026-06-10 08:35:00 (UTC)を境に水準が 15.01から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host08-004 active_connections の推移](charts/EVT-20260610-host08-004.svg)

# イベントID( EVT-20260611-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→8→7→9→9→9→8→10→11
* 開始   : 2026-06-11 00:35:00 (UTC)
* 終了   : 2026-06-11 01:50:00 (UTC)
* 現象   : 2026-06-11 01:50:00 (UTC)を境に水準が 15.03から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.983, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-001 active_connections の推移](charts/EVT-20260611-host08-001.svg)

# イベントID( EVT-20260611-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→7→8→10→10→9
* 開始   : 2026-06-11 23:20:00 (UTC)
* 終了   : 2026-06-11 23:50:00 (UTC)
* 現象   : 2026-06-11 23:50:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→10→10→8→9→8→8→10
* 開始   : 2026-06-14 00:00:00 (UTC)
* 終了   : 2026-06-14 00:50:00 (UTC)
* 現象   : 2026-06-14 00:50:00 (UTC)を境に水準が 11.94から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host08-001 active_connections の推移](charts/EVT-20260614-host08-001.svg)

# イベントID( EVT-20260615-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→11→10→7→9→9→8→12
* 開始   : 2026-06-15 01:00:00 (UTC)
* 終了   : 2026-06-15 03:10:00 (UTC)
* 現象   : 2026-06-15 03:10:00 (UTC)を境に水準が 11.93から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.409, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-002 active_connections の推移](charts/EVT-20260615-host08-002.svg)

# イベントID( EVT-20260615-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→17→15→18→…→14→16→14→15
* 開始   : 2026-06-15 02:45:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.84から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.815, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-003 active_connections の推移](charts/EVT-20260615-host08-003.svg)

# イベントID( EVT-20260615-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→17→18→15→…→12→15→12→10
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.76から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.114, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-004 active_connections の推移](charts/EVT-20260615-host08-004.svg)

# イベントID( EVT-20260615-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→19→…→13→15→13→14
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 22:50:00 (UTC)
* 現象   : 2026-06-15 22:50:00 (UTC)を境に水準が 11.78から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.917, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-006 active_connections の推移](charts/EVT-20260615-host08-006.svg)

# イベントID( EVT-20260615-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→15→…→18→15→12→17
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 20:10:00 (UTC)
* 現象   : 2026-06-15 20:10:00 (UTC)を境に水準が 11.8から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.009, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-007 active_connections の推移](charts/EVT-20260615-host08-007.svg)

# イベントID( EVT-20260615-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→14→…→13→15→14→13
* 開始   : 2026-06-15 04:25:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 12.07から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.126, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-008 active_connections の推移](charts/EVT-20260615-host08-008.svg)

# イベントID( EVT-20260617-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→19→20→19→19→19→20→21→24
* 開始   : 2026-06-17 08:00:00 (UTC)
* 終了   : 2026-06-17 09:35:00 (UTC)
* 現象   : 2026-06-17 09:35:00 (UTC)を境に水準が 14.95から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-004 active_connections の推移](charts/EVT-20260617-host08-004.svg)

# イベントID( EVT-20260619-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→17→19→18→18→17→17→19
* 開始   : 2026-06-19 16:40:00 (UTC)
* 終了   : 2026-06-19 17:40:00 (UTC)
* 現象   : 2026-06-19 17:40:00 (UTC)を境に水準が 15.01から12.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host08-009 active_connections の推移](charts/EVT-20260619-host08-009.svg)

# イベントID( EVT-20260619-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→10→9→10→10→9→9→9→11
* 開始   : 2026-06-19 21:55:00 (UTC)
* 終了   : 2026-06-19 22:50:00 (UTC)
* 現象   : 2026-06-19 22:50:00 (UTC)を境に水準が 15から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.737, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host08-013 active_connections の推移](charts/EVT-20260619-host08-013.svg)

# イベントID( EVT-20260622-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→12→14→13→12
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 19:25:00 (UTC)
* 現象   : 2026-06-22 19:25:00 (UTC)を境に水準が 11.79から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.929, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-002 active_connections の推移](charts/EVT-20260622-host08-002.svg)

# イベントID( EVT-20260622-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→16→13→16→…→16→14→13→11
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.904, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.983, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-003 active_connections の推移](charts/EVT-20260622-host08-003.svg)

# イベントID( EVT-20260622-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→13→…→14→15→13→14
* 開始   : 2026-06-22 03:15:00 (UTC)
* 終了   : 2026-06-22 21:35:00 (UTC)
* 現象   : 2026-06-22 21:35:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.676, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.341, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-004 active_connections の推移](charts/EVT-20260622-host08-004.svg)

# イベントID( EVT-20260622-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→17→20→17→…→11→14→11→12
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.82から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.763, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-005 active_connections の推移](charts/EVT-20260622-host08-005.svg)

# イベントID( EVT-20260622-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→15→17→14→…→11→13→12→11
* 開始   : 2026-06-22 04:10:00 (UTC)
* 終了   : 2026-06-22 21:00:00 (UTC)
* 現象   : 2026-06-22 21:00:00 (UTC)を境に水準が 11.96から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.038, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-006 active_connections の推移](charts/EVT-20260622-host08-006.svg)

# イベントID( EVT-20260624-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 24→22→23
* 開始   : 2026-06-24 10:20:00 (UTC)
* 終了   : 2026-06-24 10:30:00 (UTC)
* 現象   : 2026-06-24 10:30:00 (UTC)を境に水準が 14.97から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.934, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→9→8→8→10→9→9
* 開始   : 2026-06-25 00:25:00 (UTC)
* 終了   : 2026-06-25 01:00:00 (UTC)
* 現象   : 2026-06-25 01:00:00 (UTC)を境に水準が 14.98から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host08-001 active_connections の推移](charts/EVT-20260625-host08-001.svg)

# イベントID( EVT-20260625-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→22→21→20
* 開始   : 2026-06-25 14:30:00 (UTC)
* 終了   : 2026-06-25 14:45:00 (UTC)
* 現象   : 2026-06-25 14:45:00 (UTC)を境に水準が 15.05から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host08-005 active_connections の推移](charts/EVT-20260625-host08-005.svg)

# イベントID( EVT-20260628-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→16→15→14→15→13→14→14→16
* 開始   : 2026-06-28 14:35:00 (UTC)
* 終了   : 2026-06-28 16:10:00 (UTC)
* 現象   : 2026-06-28 16:10:00 (UTC)を境に水準が 11.85から14.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host08-008 active_connections の推移](charts/EVT-20260628-host08-008.svg)

# イベントID( EVT-20260629-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→16→15→19→…→12→13→12→13
* 開始   : 2026-06-29 01:35:00 (UTC)
* 終了   : 2026-06-29 18:55:00 (UTC)
* 現象   : 2026-06-29 18:55:00 (UTC)を境に水準が 11.87から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.731, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.567, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-001 active_connections の推移](charts/EVT-20260629-host08-001.svg)

# イベントID( EVT-20260629-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→18→16→18→…→13→14→13→14
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 20:05:00 (UTC)
* 現象   : 2026-06-29 20:05:00 (UTC)を境に水準が 11.73から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.989, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-002 active_connections の推移](charts/EVT-20260629-host08-002.svg)

# イベントID( EVT-20260629-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→14→…→14→16→13→15
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.93から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.07, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-003 active_connections の推移](charts/EVT-20260629-host08-003.svg)

# イベントID( EVT-20260629-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→15→…→12→14→12→11
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 19:40:00 (UTC)
* 現象   : 2026-06-29 19:40:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.19, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-004 active_connections の推移](charts/EVT-20260629-host08-004.svg)

# イベントID( EVT-20260629-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→14→17→…→16→12→13→14
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 11.92から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.747, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.341, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-005 active_connections の推移](charts/EVT-20260629-host08-005.svg)

# イベントID( EVT-20260629-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→17→15→17→…→13→14→12→13
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 21:35:00 (UTC)
* 現象   : 2026-06-29 21:35:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.046, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host08-006 active_connections の推移](charts/EVT-20260629-host08-006.svg)

# イベントID( EVT-20260630-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→8→10→10→10→9→12
* 開始   : 2026-06-30 21:10:00 (UTC)
* 終了   : 2026-06-30 22:25:00 (UTC)
* 現象   : 2026-06-30 22:25:00 (UTC)を境に水準が 14.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-014 active_connections の推移](charts/EVT-20260630-host08-014.svg)

# イベントID( EVT-20260601-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→20→16→16
* 開始   : 2026-06-01 06:50:00 (UTC)
* 終了   : 2026-06-01 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→18→20→18→20→19
* 開始   : 2026-06-01 07:50:00 (UTC)
* 終了   : 2026-06-01 09:00:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260601-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→10→7→11→11
* 開始   : 2026-06-01 21:00:00 (UTC)
* 終了   : 2026-06-01 21:00:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→17→21→17→18
* 開始   : 2026-06-02 07:45:00 (UTC)
* 終了   : 2026-06-02 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→19→23→22→19→23→22→19
* 開始   : 2026-06-02 08:40:00 (UTC)
* 終了   : 2026-06-02 09:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 24→21→18→23→22
* 開始   : 2026-06-02 12:30:00 (UTC)
* 終了   : 2026-06-02 12:30:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→22→17→23→20
* 開始   : 2026-06-02 13:55:00 (UTC)
* 終了   : 2026-06-02 13:55:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→23→17→18→…→17→18→20→19
* 開始   : 2026-06-02 14:00:00 (UTC)
* 終了   : 2026-06-02 14:05:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→21→16→19→20
* 開始   : 2026-06-02 15:00:00 (UTC)
* 終了   : 2026-06-02 15:00:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.75(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-008 active_connections の推移](charts/EVT-20260602-host08-008.svg)

# イベントID( EVT-20260602-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→18→14→16→18
* 開始   : 2026-06-02 16:25:00 (UTC)
* 終了   : 2026-06-02 16:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.7304(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-010 active_connections の推移](charts/EVT-20260602-host08-010.svg)

# イベントID( EVT-20260602-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→19→14→18→18
* 開始   : 2026-06-02 16:25:00 (UTC)
* 終了   : 2026-06-02 16:25:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→10→8→11→13→10→8→11→10
* 開始   : 2026-06-02 19:10:00 (UTC)
* 終了   : 2026-06-02 19:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host08-012 active_connections の推移](charts/EVT-20260602-host08-012.svg)

# イベントID( EVT-20260603-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→7→3→6→8
* 開始   : 2026-06-03 00:15:00 (UTC)
* 終了   : 2026-06-03 00:15:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.3789(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-001 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→6→13→10→9
* 開始   : 2026-06-03 01:15:00 (UTC)
* 終了   : 2026-06-03 01:15:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.696倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.699σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-003 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host08-002 active_connections の推移](charts/EVT-20260603-host08-002.svg)

# イベントID( EVT-20260603-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→20→23→18→20→23→18→21
* 開始   : 2026-06-03 08:50:00 (UTC)
* 終了   : 2026-06-03 08:55:00 (UTC)
* 現象   : 水曜8時台の平常値(19.38)に対し 23であった
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.095σ 外れた (平常値=19.38)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→13→10→14→13
* 開始   : 2026-06-03 18:25:00 (UTC)
* 終了   : 2026-06-03 18:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→8→4→7→8
* 開始   : 2026-06-03 23:35:00 (UTC)
* 終了   : 2026-06-03 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→10→15→13→11
* 開始   : 2026-06-04 04:00:00 (UTC)
* 終了   : 2026-06-04 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→17→15→14→17→15→16
* 開始   : 2026-06-04 05:20:00 (UTC)
* 終了   : 2026-06-04 05:50:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→10→8→7→10→8→7→10→9
* 開始   : 2026-06-04 20:40:00 (UTC)
* 終了   : 2026-06-04 20:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→11→16→13→13
* 開始   : 2026-06-05 04:40:00 (UTC)
* 終了   : 2026-06-05 04:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-001 active_connections の推移](charts/EVT-20260605-host08-001.svg)

# イベントID( EVT-20260605-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→19→23→20→23→20→23→21→20
* 開始   : 2026-06-05 09:00:00 (UTC)
* 終了   : 2026-06-05 09:10:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→19→15→19→18
* 開始   : 2026-06-05 16:10:00 (UTC)
* 終了   : 2026-06-05 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→15→19
* 開始   : 2026-06-05 16:25:00 (UTC)
* 終了   : 2026-06-05 16:25:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260605-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→9→11→8→9→10
* 開始   : 2026-06-05 19:35:00 (UTC)
* 終了   : 2026-06-05 20:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→10→7→10→11
* 開始   : 2026-06-05 20:05:00 (UTC)
* 終了   : 2026-06-05 20:05:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.5714(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.653σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-016 active_connections の推移](charts/EVT-20260605-host08-016.svg)

# イベントID( EVT-20260605-host08-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→6→13→6→6
* 開始   : 2026-06-05 23:15:00 (UTC)
* 終了   : 2026-06-05 23:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host08-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→11→…→12→11→13→14
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.212, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→13→10→13→…→12→11→14→11
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.799, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host08-002 active_connections の推移](charts/EVT-20260606-host08-002.svg)

# イベントID( EVT-20260606-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→8→12→9→…→11→9→13→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.923, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host08-003 active_connections の推移](charts/EVT-20260606-host08-003.svg)

# イベントID( EVT-20260606-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→14→12→15→13
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host08-004 active_connections の推移](charts/EVT-20260606-host08-004.svg)

# イベントID( EVT-20260606-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→14→11→13→…→11→8→11→12
* 開始   : 2026-06-06 06:05:00 (UTC)
* 終了   : 2026-06-06 20:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.842, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host08-005 active_connections の推移](charts/EVT-20260606-host08-005.svg)

# イベントID( EVT-20260606-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→11→…→11→14→16→11
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 20:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.009, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→8→12→7→7
* 開始   : 2026-06-07 01:20:00 (UTC)
* 終了   : 2026-06-07 01:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→14→8→9→11→11→9→11→13
* 開始   : 2026-06-07 02:30:00 (UTC)
* 終了   : 2026-06-07 03:45:00 (UTC)
* 現象   : 2026-06-07 03:45:00 (UTC)を境に水準が 11.9から11.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→11→5→10→9
* 開始   : 2026-06-07 20:50:00 (UTC)
* 終了   : 2026-06-07 20:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→17→…→12→13→12→13
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.8から15.12へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.23, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→18→22→17→18
* 開始   : 2026-06-09 07:30:00 (UTC)
* 終了   : 2026-06-09 07:30:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host08-005 active_connections の推移](charts/EVT-20260609-host08-005.svg)

# イベントID( EVT-20260609-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→18→15→18→17
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:40:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→9→11→11→11→9→11
* 開始   : 2026-06-09 21:20:00 (UTC)
* 終了   : 2026-06-09 22:45:00 (UTC)
* 現象   : 2026-06-09 22:45:00 (UTC)を境に水準が 14.94から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→12→15→15→16→15→16
* 開始   : 2026-06-10 03:30:00 (UTC)
* 終了   : 2026-06-10 06:30:00 (UTC)
* 現象   : 2026-06-10 06:30:00 (UTC)を境に水準が 14.76から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→15→13→12
* 開始   : 2026-06-10 04:10:00 (UTC)
* 終了   : 2026-06-10 04:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→22→17→17
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17)に対し 1.294倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→15→12→17→15
* 開始   : 2026-06-11 17:40:00 (UTC)
* 終了   : 2026-06-11 17:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→15→11→13→13
* 開始   : 2026-06-11 18:25:00 (UTC)
* 終了   : 2026-06-11 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→16→10→15→12
* 開始   : 2026-06-11 18:45:00 (UTC)
* 終了   : 2026-06-11 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→18→13→17→18→13→17→14
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→11→10
* 開始   : 2026-06-12 20:10:00 (UTC)
* 終了   : 2026-06-12 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→10→6→12→10
* 開始   : 2026-06-12 20:20:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.4737(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host08-009 active_connections の推移](charts/EVT-20260612-host08-009.svg)

# イベントID( EVT-20260612-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 7→9→5→6→10
* 開始   : 2026-06-12 22:10:00 (UTC)
* 終了   : 2026-06-12 22:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→8→8→7→9→9
* 開始   : 2026-06-12 22:15:00 (UTC)
* 終了   : 2026-06-12 23:45:00 (UTC)
* 現象   : 2026-06-12 23:45:00 (UTC)を境に水準が 14.94から11.71へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→14→…→13→12→13→12
* 開始   : 2026-06-13 04:30:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 15.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.113, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.9 時間
  - EVT-20260613-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260613-host08-002 active_connections の推移](charts/EVT-20260613-host08-002.svg)

# イベントID( EVT-20260613-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→11→…→12→13→11→12
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.784σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.965, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host08-003 active_connections の推移](charts/EVT-20260613-host08-003.svg)

# イベントID( EVT-20260613-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→11→…→13→12→14→12
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 20:10:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.804, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host08-004 active_connections の推移](charts/EVT-20260613-host08-004.svg)

# イベントID( EVT-20260613-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→12→9→14→…→13→15→13→14
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.405, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host08-005 active_connections の推移](charts/EVT-20260613-host08-005.svg)

# イベントID( EVT-20260613-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→11→…→11→13→12→13
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.947, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host08-006 active_connections の推移](charts/EVT-20260613-host08-006.svg)

# イベントID( EVT-20260613-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→12→14→13→…→13→12→13→14
* 開始   : 2026-06-13 06:40:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.859, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260613-host08-007 active_connections の推移](charts/EVT-20260613-host08-007.svg)

# イベントID( EVT-20260614-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→17→20→15→16
* 開始   : 2026-06-14 10:10:00 (UTC)
* 終了   : 2026-06-14 10:10:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.348倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.592σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→8→4→7→8
* 開始   : 2026-06-15 00:05:00 (UTC)
* 終了   : 2026-06-15 00:05:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260615-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→12→14→12→…→13→15→11→13
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.989, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.395, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→13→13
* 開始   : 2026-06-16 05:00:00 (UTC)
* 終了   : 2026-06-16 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→15→20→17→18
* 開始   : 2026-06-16 07:05:00 (UTC)
* 終了   : 2026-06-16 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→19→20→19→…→19→22→20→18
* 開始   : 2026-06-16 08:10:00 (UTC)
* 終了   : 2026-06-16 08:20:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→16→13→16→17
* 開始   : 2026-06-16 17:10:00 (UTC)
* 終了   : 2026-06-16 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→17→20→18→15
* 開始   : 2026-06-17 06:50:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 23→22→17→21→19
* 開始   : 2026-06-17 13:45:00 (UTC)
* 終了   : 2026-06-17 13:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.764(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.641σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host08-007 active_connections の推移](charts/EVT-20260617-host08-007.svg)

# イベントID( EVT-20260617-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→14→12→12→10→12→13→13
* 開始   : 2026-06-17 19:20:00 (UTC)
* 終了   : 2026-06-17 20:25:00 (UTC)
* 現象   : 2026-06-17 20:25:00 (UTC)を境に水準が 15.07から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→16→19→17→14
* 開始   : 2026-06-18 06:25:00 (UTC)
* 終了   : 2026-06-18 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.534σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→17→20→16→19
* 開始   : 2026-06-18 07:00:00 (UTC)
* 終了   : 2026-06-18 07:00:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→22→23→21→25→23→21→25→20
* 開始   : 2026-06-18 09:45:00 (UTC)
* 終了   : 2026-06-18 09:55:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→20→16→18→17
* 開始   : 2026-06-18 15:35:00 (UTC)
* 終了   : 2026-06-18 15:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260618-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→19→13→15→16
* 開始   : 2026-06-18 17:25:00 (UTC)
* 終了   : 2026-06-18 17:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→12→18→15→15
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→17→…→17→20→18→15
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 06:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→17→…→17→14→18→16
* 開始   : 2026-06-19 15:30:00 (UTC)
* 終了   : 2026-06-19 16:30:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 35 分
  - EVT-20260619-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260619-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→22→16→20→20
* 開始   : 2026-06-19 15:35:00 (UTC)
* 終了   : 2026-06-19 15:35:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→20→14→18→19
* 開始   : 2026-06-19 16:00:00 (UTC)
* 終了   : 2026-06-19 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.721(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.757σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-008 active_connections の推移](charts/EVT-20260619-host08-008.svg)

# イベントID( EVT-20260619-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→13→12
* 開始   : 2026-06-19 19:50:00 (UTC)
* 終了   : 2026-06-19 19:50:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→11→8→12→11→8→12→10
* 開始   : 2026-06-19 20:15:00 (UTC)
* 終了   : 2026-06-19 20:45:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.831σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260619-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260619-host08-012 active_connections の推移](charts/EVT-20260619-host08-012.svg)

# イベントID( EVT-20260620-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→11→12→11→…→11→12→11→12
* 開始   : 2026-06-20 03:50:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.855, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host08-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host08-001 active_connections の推移](charts/EVT-20260620-host08-001.svg)

# イベントID( EVT-20260620-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→13→12→11→…→12→11→15→13
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host08-003 active_connections の推移](charts/EVT-20260620-host08-003.svg)

# イベントID( EVT-20260620-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→9→12→…→12→13→14→12
* 開始   : 2026-06-20 05:30:00 (UTC)
* 終了   : 2026-06-20 19:30:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.001, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→10→12→13→…→12→11→12→13
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.894, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host08-005 active_connections の推移](charts/EVT-20260620-host08-005.svg)

# イベントID( EVT-20260620-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→14→11→14→…→12→11→12→11
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.291, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host08-006 active_connections の推移](charts/EVT-20260620-host08-006.svg)

# イベントID( EVT-20260620-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→11→…→16→15→12→14
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 18:25:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.537, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260620-host08-007 active_connections の推移](charts/EVT-20260620-host08-007.svg)

# イベントID( EVT-20260621-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→16→13→10
* 開始   : 2026-06-21 06:35:00 (UTC)
* 終了   : 2026-06-21 06:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→12→13
* 開始   : 2026-06-21 17:05:00 (UTC)
* 終了   : 2026-06-21 17:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→15→12→7→15→12→7→12→11
* 開始   : 2026-06-21 17:55:00 (UTC)
* 終了   : 2026-06-21 18:05:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260621-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→9→6→10→10
* 開始   : 2026-06-21 19:50:00 (UTC)
* 終了   : 2026-06-21 19:50:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→10→14→10→10
* 開始   : 2026-06-21 20:20:00 (UTC)
* 終了   : 2026-06-21 20:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→17→15→17→…→14→13→12→13
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.93から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.664, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→9→15→12→10
* 開始   : 2026-06-23 04:10:00 (UTC)
* 終了   : 2026-06-23 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→17→20→17→17
* 開始   : 2026-06-23 06:45:00 (UTC)
* 終了   : 2026-06-23 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→17→…→17→13→16→15
* 開始   : 2026-06-23 17:00:00 (UTC)
* 終了   : 2026-06-23 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7671(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.976σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→17→14→16→15
* 開始   : 2026-06-24 16:35:00 (UTC)
* 終了   : 2026-06-24 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260624-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→16→15
* 開始   : 2026-06-25 05:50:00 (UTC)
* 終了   : 2026-06-25 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→9→11→10→10→10→9
* 開始   : 2026-06-26 00:15:00 (UTC)
* 終了   : 2026-06-26 01:35:00 (UTC)
* 現象   : 2026-06-26 01:35:00 (UTC)を境に水準が 14.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→13→14→16→13→14
* 開始   : 2026-06-26 05:35:00 (UTC)
* 終了   : 2026-06-26 06:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260626-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260626-host08-003 active_connections の推移](charts/EVT-20260626-host08-003.svg)

# イベントID( EVT-20260626-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→17→14→16→17
* 開始   : 2026-06-26 17:00:00 (UTC)
* 終了   : 2026-06-26 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→17→13→18→15
* 開始   : 2026-06-26 17:20:00 (UTC)
* 終了   : 2026-06-26 17:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→10→4→8→7
* 開始   : 2026-06-27 00:50:00 (UTC)
* 終了   : 2026-06-27 00:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→10→12→10→…→12→11→13→12
* 開始   : 2026-06-27 04:10:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.204, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host08-002 active_connections の推移](charts/EVT-20260627-host08-002.svg)

# イベントID( EVT-20260627-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→13→…→12→13→14→12
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260627-host08-003 active_connections の推移](charts/EVT-20260627-host08-003.svg)

# イベントID( EVT-20260627-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→8→…→14→10→12→11
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host08-004 active_connections の推移](charts/EVT-20260627-host08-004.svg)

# イベントID( EVT-20260627-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→13→…→10→12→10→13
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 20:00:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.843, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host08-005 active_connections の推移](charts/EVT-20260627-host08-005.svg)

# イベントID( EVT-20260627-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→14→10→12→…→14→13→14→13
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:10:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.791, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260627-host08-006 active_connections の推移](charts/EVT-20260627-host08-006.svg)

# イベントID( EVT-20260627-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→13→…→9→10→11→12
* 開始   : 2026-06-27 05:55:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host08-007 active_connections の推移](charts/EVT-20260627-host08-007.svg)

# イベントID( EVT-20260628-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→16→12→12
* 開始   : 2026-06-28 06:00:00 (UTC)
* 終了   : 2026-06-28 06:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→13→20→16→14
* 開始   : 2026-06-28 10:20:00 (UTC)
* 終了   : 2026-06-28 10:40:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260628-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→15→10→16→14
* 開始   : 2026-06-28 15:50:00 (UTC)
* 終了   : 2026-06-28 15:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→12→8→11→12
* 開始   : 2026-06-28 17:20:00 (UTC)
* 終了   : 2026-06-28 17:20:00 (UTC)
* 現象   : 平常時(13)に対し 0.6154(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→12→7→12→11
* 開始   : 2026-06-28 19:30:00 (UTC)
* 終了   : 2026-06-28 19:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→14→16→14→16→14
* 開始   : 2026-06-30 04:35:00 (UTC)
* 終了   : 2026-06-30 05:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260630-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→15→12→16→15→12
* 開始   : 2026-06-30 04:45:00 (UTC)
* 終了   : 2026-06-30 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→15→21→15→19
* 開始   : 2026-06-30 07:05:00 (UTC)
* 終了   : 2026-06-30 07:05:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.326倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.592σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host08-005 active_connections の推移](charts/EVT-20260630-host08-005.svg)

# イベントID( EVT-20260630-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→19→20→21→…→21→23→19→20
* 開始   : 2026-06-30 08:05:00 (UTC)
* 終了   : 2026-06-30 08:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260630-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→18→22→22
* 開始   : 2026-06-30 13:10:00 (UTC)
* 終了   : 2026-06-30 13:10:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→14→10→13→16
* 開始   : 2026-06-30 18:45:00 (UTC)
* 終了   : 2026-06-30 18:45:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→14→13→11→14→13→14
* 開始   : 2026-06-01 04:15:00 (UTC)
* 終了   : 2026-06-01 04:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→21→17→24→…→19→17→24→19
* 開始   : 2026-06-01 15:20:00 (UTC)
* 終了   : 2026-06-01 15:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→18→16→17→18→16→17
* 開始   : 2026-06-01 16:10:00 (UTC)
* 終了   : 2026-06-01 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→19→15→18→19→15→18→19
* 開始   : 2026-06-01 16:15:00 (UTC)
* 終了   : 2026-06-01 16:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.7826(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.899σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→7→5→12→…→5→12→8→7
* 開始   : 2026-06-02 00:35:00 (UTC)
* 終了   : 2026-06-02 00:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→15→18→16→18→16→18→17→16
* 開始   : 2026-06-02 06:25:00 (UTC)
* 終了   : 2026-06-02 06:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→16→…→17→16→18→19
* 開始   : 2026-06-02 15:50:00 (UTC)
* 終了   : 2026-06-02 16:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→12→10→12→11
* 開始   : 2026-06-02 19:45:00 (UTC)
* 終了   : 2026-06-02 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260602-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→10→7→13→…→7→13→11→10
* 開始   : 2026-06-02 21:35:00 (UTC)
* 終了   : 2026-06-02 21:40:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-078 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260602-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→12→7→12→13→7→12→13→12
* 開始   : 2026-06-03 03:20:00 (UTC)
* 終了   : 2026-06-03 03:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→11→13→11→13→11→10
* 開始   : 2026-06-03 04:00:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→18→…→17→18→14→15
* 開始   : 2026-06-03 06:05:00 (UTC)
* 終了   : 2026-06-03 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→15→20→21→…→20→21→18→19
* 開始   : 2026-06-03 07:45:00 (UTC)
* 終了   : 2026-06-03 07:50:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→15→17→15→14→15→16
* 開始   : 2026-06-03 16:50:00 (UTC)
* 終了   : 2026-06-03 16:55:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260603-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→13→15
* 開始   : 2026-06-03 19:05:00 (UTC)
* 終了   : 2026-06-03 19:20:00 (UTC)
* 現象   : 2026-06-03 19:20:00 (UTC)を境に水準が 14.87から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→18→19→15→19→15→19→16→19
* 開始   : 2026-06-04 06:55:00 (UTC)
* 終了   : 2026-06-04 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→18→22→18→…→18→23→20→21
* 開始   : 2026-06-04 08:55:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→21→24→23→23
* 開始   : 2026-06-04 10:55:00 (UTC)
* 終了   : 2026-06-04 11:20:00 (UTC)
* 現象   : 2026-06-04 11:20:00 (UTC)を境に水準が 14.9から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→21→18→21→18
* 開始   : 2026-06-04 14:10:00 (UTC)
* 終了   : 2026-06-04 14:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260604-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→19→16→19→17
* 開始   : 2026-06-04 16:15:00 (UTC)
* 終了   : 2026-06-04 16:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→16→15→17→16→15→17
* 開始   : 2026-06-04 16:45:00 (UTC)
* 終了   : 2026-06-04 16:50:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→9→7→10→…→10→6→9→8
* 開始   : 2026-06-04 21:05:00 (UTC)
* 終了   : 2026-06-04 21:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.6412(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.717σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→15→…→15→18→14→16
* 開始   : 2026-06-05 06:00:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→14→15→17→14→15
* 開始   : 2026-06-05 06:05:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→19→20→23→19→20
* 開始   : 2026-06-05 09:00:00 (UTC)
* 終了   : 2026-06-05 09:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→20→22→23→…→22→23→18→22
* 開始   : 2026-06-05 09:10:00 (UTC)
* 終了   : 2026-06-05 09:15:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→18→23→22→18→23→22→21
* 開始   : 2026-06-05 09:30:00 (UTC)
* 終了   : 2026-06-05 09:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→22→22→23→25
* 開始   : 2026-06-05 10:15:00 (UTC)
* 終了   : 2026-06-05 10:35:00 (UTC)
* 現象   : 2026-06-05 10:35:00 (UTC)を境に水準が 14.87から13.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→17→18→19→17→18→19
* 開始   : 2026-06-05 15:40:00 (UTC)
* 終了   : 2026-06-05 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→16→14→16→…→14→13→17→15
* 開始   : 2026-06-05 17:05:00 (UTC)
* 終了   : 2026-06-05 17:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260605-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→17→14→17→14→16
* 開始   : 2026-06-05 17:15:00 (UTC)
* 終了   : 2026-06-05 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260605-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→13→11→10→13→15
* 開始   : 2026-06-05 19:20:00 (UTC)
* 終了   : 2026-06-05 19:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→8→8→9→8→10→8→9→10
* 開始   : 2026-06-07 00:10:00 (UTC)
* 終了   : 2026-06-07 01:10:00 (UTC)
* 現象   : 2026-06-07 01:10:00 (UTC)を境に水準が 11.77から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.123, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→17→16→16→16→18→15→15→17
* 開始   : 2026-06-07 10:35:00 (UTC)
* 終了   : 2026-06-07 12:50:00 (UTC)
* 現象   : 2026-06-07 12:50:00 (UTC)を境に水準が 11.81から13.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→11→11→10→13
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 03:05:00 (UTC)
* 現象   : 2026-06-08 03:05:00 (UTC)を境に水準が 11.84から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→7→8→7→10
* 開始   : 2026-06-08 21:20:00 (UTC)
* 終了   : 2026-06-08 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260608-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→12→10→11→12→12→12
* 開始   : 2026-06-09 03:05:00 (UTC)
* 終了   : 2026-06-09 03:55:00 (UTC)
* 現象   : 2026-06-09 03:55:00 (UTC)を境に水準が 15.06から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.475, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→13→13→12→12→12→12→13
* 開始   : 2026-06-09 03:25:00 (UTC)
* 終了   : 2026-06-09 04:00:00 (UTC)
* 現象   : 2026-06-09 04:00:00 (UTC)を境に水準が 14.89から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→15→…→14→15→12→13
* 開始   : 2026-06-09 04:25:00 (UTC)
* 終了   : 2026-06-09 04:30:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→17→18→17→20
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:55:00 (UTC)
* 現象   : 2026-06-09 06:55:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→17→11→12→17→11→12
* 開始   : 2026-06-09 19:00:00 (UTC)
* 終了   : 2026-06-09 19:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→11→13→11→13→10
* 開始   : 2026-06-10 03:35:00 (UTC)
* 終了   : 2026-06-10 03:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→19→22
* 開始   : 2026-06-10 09:05:00 (UTC)
* 終了   : 2026-06-10 09:20:00 (UTC)
* 現象   : 2026-06-10 09:20:00 (UTC)を境に水準が 14.94から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→20→17→16→…→17→16→18→19
* 開始   : 2026-06-10 15:50:00 (UTC)
* 終了   : 2026-06-10 15:55:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→16→21→15→…→21→15→17→16
* 開始   : 2026-06-10 17:00:00 (UTC)
* 終了   : 2026-06-10 18:05:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→14→14→13→13→11→14
* 開始   : 2026-06-10 19:00:00 (UTC)
* 終了   : 2026-06-10 19:40:00 (UTC)
* 現象   : 2026-06-10 19:40:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→9→7→9→10
* 開始   : 2026-06-10 21:55:00 (UTC)
* 終了   : 2026-06-10 22:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→23→21→21→21→22→22→23→23
* 開始   : 2026-06-11 09:10:00 (UTC)
* 終了   : 2026-06-11 10:20:00 (UTC)
* 現象   : 2026-06-11 10:20:00 (UTC)を境に水準が 14.97から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.287, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→14→15→17→14→16→17
* 開始   : 2026-06-11 17:00:00 (UTC)
* 終了   : 2026-06-11 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→12→9→10→9→10→9→11
* 開始   : 2026-06-11 20:10:00 (UTC)
* 終了   : 2026-06-11 20:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260611-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→11→8→14→…→8→14→13→9
* 開始   : 2026-06-11 20:45:00 (UTC)
* 終了   : 2026-06-11 20:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→11→10→10→8→9→11→11
* 開始   : 2026-06-11 21:30:00 (UTC)
* 終了   : 2026-06-11 22:05:00 (UTC)
* 現象   : 2026-06-11 22:05:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host08-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→7→10→10→9→8→10→10→11
* 開始   : 2026-06-11 22:35:00 (UTC)
* 終了   : 2026-06-11 23:15:00 (UTC)
* 現象   : 2026-06-11 23:15:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→9→13→12→9→13→12→10
* 開始   : 2026-06-12 03:30:00 (UTC)
* 終了   : 2026-06-12 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→14→14→17→16
* 開始   : 2026-06-12 05:20:00 (UTC)
* 終了   : 2026-06-12 05:50:00 (UTC)
* 現象   : 2026-06-12 05:50:00 (UTC)を境に水準が 15.1から14.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→15→16→17→…→16→17→16→15
* 開始   : 2026-06-12 05:30:00 (UTC)
* 終了   : 2026-06-12 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 23→24→23→23→21→23→23→23→25
* 開始   : 2026-06-12 10:25:00 (UTC)
* 終了   : 2026-06-12 11:15:00 (UTC)
* 現象   : 2026-06-12 11:15:00 (UTC)を境に水準が 15.06から13.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→18→17→18→17→21→19
* 開始   : 2026-06-12 15:10:00 (UTC)
* 終了   : 2026-06-12 15:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→14→17→14→17
* 開始   : 2026-06-12 17:25:00 (UTC)
* 終了   : 2026-06-12 17:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→9→12→9→12→11
* 開始   : 2026-06-13 04:20:00 (UTC)
* 終了   : 2026-06-13 04:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260613-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→7→11→12→…→11→12→8→9
* 開始   : 2026-06-14 01:30:00 (UTC)
* 終了   : 2026-06-14 01:35:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→8→11→12→…→11→12→7→8
* 開始   : 2026-06-14 01:55:00 (UTC)
* 終了   : 2026-06-14 02:00:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-002 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260614-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→13→14→15→17→17→16→16→15
* 開始   : 2026-06-14 09:15:00 (UTC)
* 終了   : 2026-06-14 10:35:00 (UTC)
* 現象   : 2026-06-14 10:35:00 (UTC)を境に水準が 11.78から12.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→13→13→15→15→16→17→16
* 開始   : 2026-06-16 04:55:00 (UTC)
* 終了   : 2026-06-16 06:00:00 (UTC)
* 現象   : 2026-06-16 06:00:00 (UTC)を境に水準が 14.87から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→22→18→22→18→22→21→19
* 開始   : 2026-06-16 08:30:00 (UTC)
* 終了   : 2026-06-16 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.228倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.832σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→23→24→18→23→24→18→23→22
* 開始   : 2026-06-16 10:45:00 (UTC)
* 終了   : 2026-06-16 10:50:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260616-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→19→…→19→15→17→16
* 開始   : 2026-06-16 16:50:00 (UTC)
* 終了   : 2026-06-16 17:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260616-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→17→14→17→14→17→16
* 開始   : 2026-06-16 17:20:00 (UTC)
* 終了   : 2026-06-16 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→13→11→11
* 開始   : 2026-06-16 20:35:00 (UTC)
* 終了   : 2026-06-16 20:50:00 (UTC)
* 現象   : 2026-06-16 20:50:00 (UTC)を境に水準が 15.09から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host08-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→7→11→9→10
* 開始   : 2026-06-16 22:55:00 (UTC)
* 終了   : 2026-06-16 23:15:00 (UTC)
* 現象   : 2026-06-16 23:15:00 (UTC)を境に水準が 15.01から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→6→12→13→6→12→13→11
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:35:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.78σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→18→17→18→19→19
* 開始   : 2026-06-17 07:10:00 (UTC)
* 終了   : 2026-06-17 07:35:00 (UTC)
* 現象   : 2026-06-17 07:35:00 (UTC)を境に水準が 15.07から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→22→22→18→22→22→21→21
* 開始   : 2026-06-17 08:50:00 (UTC)
* 終了   : 2026-06-17 10:25:00 (UTC)
* 現象   : 2026-06-17 10:25:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 22→19→23→24→22→19→23→24→22
* 開始   : 2026-06-17 09:35:00 (UTC)
* 終了   : 2026-06-17 09:40:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260617-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→16→17→15→16→17
* 開始   : 2026-06-17 16:45:00 (UTC)
* 終了   : 2026-06-17 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-012 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260617-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→12→14→12→14→12→13
* 開始   : 2026-06-17 18:20:00 (UTC)
* 終了   : 2026-06-17 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260617-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→13→11→14→12
* 開始   : 2026-06-17 18:50:00 (UTC)
* 終了   : 2026-06-17 18:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→10→12→13→…→10→6→11→10
* 開始   : 2026-06-18 02:30:00 (UTC)
* 終了   : 2026-06-18 02:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→11→13→10→13→10→13→10
* 開始   : 2026-06-18 03:00:00 (UTC)
* 終了   : 2026-06-18 03:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→12→13→15→12
* 開始   : 2026-06-18 04:30:00 (UTC)
* 終了   : 2026-06-18 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→15→…→14→15→13→12
* 開始   : 2026-06-18 04:55:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 24→22→23→22
* 開始   : 2026-06-18 10:20:00 (UTC)
* 終了   : 2026-06-18 10:35:00 (UTC)
* 現象   : 2026-06-18 10:35:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.328, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→24→21→18→24→21
* 開始   : 2026-06-18 14:05:00 (UTC)
* 終了   : 2026-06-18 14:10:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8213(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→15→16→12→15→14
* 開始   : 2026-06-18 18:00:00 (UTC)
* 終了   : 2026-06-18 18:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.717σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→16→13→16→13→14→13
* 開始   : 2026-06-18 18:05:00 (UTC)
* 終了   : 2026-06-18 18:15:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→14→14→15→15→13→16→15
* 開始   : 2026-06-18 18:20:00 (UTC)
* 終了   : 2026-06-18 18:55:00 (UTC)
* 現象   : 2026-06-18 18:55:00 (UTC)を境に水準が 14.89から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→10→9
* 開始   : 2026-06-18 23:45:00 (UTC)
* 終了   : 2026-06-19 00:00:00 (UTC)
* 現象   : 2026-06-19 00:00:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→15→15→17
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 2026-06-19 05:55:00 (UTC)を境に水準が 15.03から14.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→17→16→19→17→16
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 06:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→20→17→22→…→22→16→18→19
* 開始   : 2026-06-19 15:15:00 (UTC)
* 終了   : 2026-06-19 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260619-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260619-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→13→…→13→17→11→12
* 開始   : 2026-06-19 18:50:00 (UTC)
* 終了   : 2026-06-19 19:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→7→6→10→…→6→10→11→9
* 開始   : 2026-06-20 03:55:00 (UTC)
* 終了   : 2026-06-20 04:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.992, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 7→8→6→10→8→6→10→7
* 開始   : 2026-06-20 21:10:00 (UTC)
* 終了   : 2026-06-20 21:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.994, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260620-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→6→5→9→10→6→5→9
* 開始   : 2026-06-20 23:10:00 (UTC)
* 終了   : 2026-06-20 23:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→11→11→11
* 開始   : 2026-06-21 03:40:00 (UTC)
* 終了   : 2026-06-21 03:55:00 (UTC)
* 現象   : 2026-06-21 03:55:00 (UTC)を境に水準が 11.86から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→16→14→16
* 開始   : 2026-06-21 08:35:00 (UTC)
* 終了   : 2026-06-21 09:00:00 (UTC)
* 現象   : 2026-06-21 09:00:00 (UTC)を境に水準が 11.78から12.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→10→12→13→9→10→9→10→11
* 開始   : 2026-06-21 19:15:00 (UTC)
* 終了   : 2026-06-21 20:20:00 (UTC)
* 現象   : 2026-06-21 20:20:00 (UTC)を境に水準が 11.66から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.201, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 7→11→10→11→…→8→5→7→6
* 開始   : 2026-06-21 23:20:00 (UTC)
* 終了   : 2026-06-21 23:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260621-host11-019 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 7→12→8→11→…→8→4→8→10
* 開始   : 2026-06-22 23:50:00 (UTC)
* 終了   : 2026-06-23 00:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.726σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→15→15→15
* 開始   : 2026-06-23 04:30:00 (UTC)
* 終了   : 2026-06-23 04:45:00 (UTC)
* 現象   : 2026-06-23 04:45:00 (UTC)を境に水準が 15.06から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→15→17→16→18→17→16→18→16
* 開始   : 2026-06-23 05:40:00 (UTC)
* 終了   : 2026-06-23 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260623-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→22→23→21→22
* 開始   : 2026-06-23 10:00:00 (UTC)
* 終了   : 2026-06-23 10:20:00 (UTC)
* 現象   : 2026-06-23 10:20:00 (UTC)を境に水準が 15.02から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→23→19→23→…→23→18→20→21
* 開始   : 2026-06-23 13:45:00 (UTC)
* 終了   : 2026-06-23 13:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→17→16→20→…→17→16→19→20
* 開始   : 2026-06-23 15:50:00 (UTC)
* 終了   : 2026-06-23 16:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→11→13→10→11→13→10→11
* 開始   : 2026-06-23 19:05:00 (UTC)
* 終了   : 2026-06-23 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→10→…→11→10→14→12
* 開始   : 2026-06-23 19:20:00 (UTC)
* 終了   : 2026-06-23 19:25:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→12→8→12→8→12
* 開始   : 2026-06-23 20:20:00 (UTC)
* 終了   : 2026-06-23 20:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→14→…→8→14→10→9
* 開始   : 2026-06-23 20:50:00 (UTC)
* 終了   : 2026-06-23 20:55:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 8→10→5→9→…→9→11→9→11
* 開始   : 2026-06-24 01:35:00 (UTC)
* 終了   : 2026-06-24 01:45:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→13→…→12→13→10→12
* 開始   : 2026-06-24 02:50:00 (UTC)
* 終了   : 2026-06-24 02:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→14→9→13→…→13→15→14→13
* 開始   : 2026-06-24 04:30:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→16→18→19→16
* 開始   : 2026-06-24 06:30:00 (UTC)
* 終了   : 2026-06-24 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260624-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→17→19→17→19→17→19→16
* 開始   : 2026-06-24 07:10:00 (UTC)
* 終了   : 2026-06-24 07:20:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260624-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 22→18→25→22→18→25→22→21
* 開始   : 2026-06-24 11:55:00 (UTC)
* 終了   : 2026-06-24 12:00:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.812(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.917σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 25→21→23→22→22
* 開始   : 2026-06-24 11:55:00 (UTC)
* 終了   : 2026-06-24 12:15:00 (UTC)
* 現象   : 2026-06-24 12:15:00 (UTC)を境に水準が 15.06から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→19→17→18→19→17→18→21
* 開始   : 2026-06-24 14:35:00 (UTC)
* 終了   : 2026-06-24 14:40:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8031(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260624-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→14→12→14→12→14→12
* 開始   : 2026-06-24 18:25:00 (UTC)
* 終了   : 2026-06-24 18:35:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→9→…→10→9→11→10
* 開始   : 2026-06-24 19:55:00 (UTC)
* 終了   : 2026-06-24 20:00:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→15→15→15→15→16→16→18→16
* 開始   : 2026-06-25 05:25:00 (UTC)
* 終了   : 2026-06-25 06:20:00 (UTC)
* 現象   : 2026-06-25 06:20:00 (UTC)を境に水準が 15.01から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 25→21→23→24→22→22
* 開始   : 2026-06-25 12:25:00 (UTC)
* 終了   : 2026-06-25 12:50:00 (UTC)
* 現象   : 2026-06-25 12:50:00 (UTC)を境に水準が 15.08から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→14→10→14→10→15→11
* 開始   : 2026-06-25 19:00:00 (UTC)
* 終了   : 2026-06-25 19:10:00 (UTC)
* 現象   : 平常時(14)に対し 0.7143(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→10→…→10→8→11→10
* 開始   : 2026-06-25 20:10:00 (UTC)
* 終了   : 2026-06-25 20:20:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→5→9→12→5→9→12→6→8
* 開始   : 2026-06-25 22:45:00 (UTC)
* 終了   : 2026-06-25 22:55:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→9→5→9→5→9→5→8→7
* 開始   : 2026-06-26 00:15:00 (UTC)
* 終了   : 2026-06-26 00:25:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→19→18→17→19→15→17
* 開始   : 2026-06-26 06:15:00 (UTC)
* 終了   : 2026-06-26 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→14→19→18→14→19→18
* 開始   : 2026-06-26 07:00:00 (UTC)
* 終了   : 2026-06-26 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260626-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→20→…→19→20→19→18
* 開始   : 2026-06-26 07:10:00 (UTC)
* 終了   : 2026-06-26 07:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→19→18→19→19→20→20→21
* 開始   : 2026-06-26 07:35:00 (UTC)
* 終了   : 2026-06-26 08:10:00 (UTC)
* 現象   : 2026-06-26 08:10:00 (UTC)を境に水準が 14.88から14.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 23→21→21→21→22→23→21→22→24
* 開始   : 2026-06-26 09:15:00 (UTC)
* 終了   : 2026-06-26 09:55:00 (UTC)
* 現象   : 2026-06-26 09:55:00 (UTC)を境に水準が 14.92から13.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 22→18→23→19→18→23→19→22→23
* 開始   : 2026-06-26 10:55:00 (UTC)
* 終了   : 2026-06-26 11:05:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8213(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.726σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 21→23→18→23→…→23→19→23→22
* 開始   : 2026-06-26 13:55:00 (UTC)
* 終了   : 2026-06-26 14:05:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.809(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.96σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260626-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→14→14→12→14→15
* 開始   : 2026-06-26 18:50:00 (UTC)
* 終了   : 2026-06-26 19:25:00 (UTC)
* 現象   : 2026-06-26 19:25:00 (UTC)を境に水準が 14.9から12.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→12→8→9→…→9→7→10→8
* 開始   : 2026-06-26 21:00:00 (UTC)
* 終了   : 2026-06-26 21:10:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 8→10→6→8→…→8→5→10→8
* 開始   : 2026-06-27 22:35:00 (UTC)
* 終了   : 2026-06-27 22:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260627-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→5→9→11→5→9→11→8→11
* 開始   : 2026-06-28 01:05:00 (UTC)
* 終了   : 2026-06-28 01:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→11→11→11→13→12→12→14→13
* 開始   : 2026-06-28 05:05:00 (UTC)
* 終了   : 2026-06-28 06:00:00 (UTC)
* 現象   : 2026-06-28 06:00:00 (UTC)を境に水準が 11.87から12.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→15→12→14→14→15→15→15→16
* 開始   : 2026-06-28 07:30:00 (UTC)
* 終了   : 2026-06-28 08:50:00 (UTC)
* 現象   : 2026-06-28 08:50:00 (UTC)を境に水準が 11.8から12.69へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→17→14→17→14→15
* 開始   : 2026-06-28 09:05:00 (UTC)
* 終了   : 2026-06-28 09:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→14→18→16→…→16→12→16→15
* 開始   : 2026-06-28 10:15:00 (UTC)
* 終了   : 2026-06-28 10:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260628-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→10→11→9→11→10
* 開始   : 2026-06-30 01:15:00 (UTC)
* 終了   : 2026-06-30 01:40:00 (UTC)
* 現象   : 2026-06-30 01:40:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→14→18→14→18→13→17
* 開始   : 2026-06-30 06:20:00 (UTC)
* 終了   : 2026-06-30 06:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→23→22→19→23→22
* 開始   : 2026-06-30 09:50:00 (UTC)
* 終了   : 2026-06-30 09:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260630-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 23→23→24→22→20→23→21→23→23
* 開始   : 2026-06-30 11:40:00 (UTC)
* 終了   : 2026-06-30 13:25:00 (UTC)
* 現象   : 2026-06-30 13:25:00 (UTC)を境に水準が 14.99から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→14→13→17→13→17→13→15
* 開始   : 2026-06-30 18:00:00 (UTC)
* 終了   : 2026-06-30 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→10→9→12→10→9→12→11
* 開始   : 2026-06-30 20:00:00 (UTC)
* 終了   : 2026-06-30 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260630-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→12→8→11→10→13→9→11→10
* 開始   : 2026-06-30 20:10:00 (UTC)
* 終了   : 2026-06-30 21:50:00 (UTC)
* 現象   : 2026-06-30 21:50:00 (UTC)を境に水準が 14.99から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→9→9→9→10→9→10
* 開始   : 2026-06-30 22:45:00 (UTC)
* 終了   : 2026-06-30 23:15:00 (UTC)
* 現象   : 2026-06-30 23:15:00 (UTC)を境に水準が 14.98から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host08-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
