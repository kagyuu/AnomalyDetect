# host13 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host13 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 302 (SEVERE: 20, FATAL: 113, WARN: 169, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 113 | 169 | 302 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→14→…→16→15→13→14
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 19:00:00 (UTC)
* 現象   : 2026-06-08 19:00:00 (UTC)を境に水準が 11.97から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.673, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.875, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-001 active_connections の推移](charts/EVT-20260608-host13-001.svg)

# イベントID( EVT-20260608-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→12→15→14→…→15→13→12→13
* 開始   : 2026-06-08 02:25:00 (UTC)
* 終了   : 2026-06-08 19:25:00 (UTC)
* 現象   : 2026-06-08 19:25:00 (UTC)を境に水準が 11.79から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.969, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-002 active_connections の推移](charts/EVT-20260608-host13-002.svg)

# イベントID( EVT-20260608-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→16→…→13→14→12→14
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.9から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.745, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-003 active_connections の推移](charts/EVT-20260608-host13-003.svg)

# イベントID( EVT-20260608-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→14→16→14→…→13→15→14→15
* 開始   : 2026-06-08 03:10:00 (UTC)
* 終了   : 2026-06-08 21:55:00 (UTC)
* 現象   : 2026-06-08 21:55:00 (UTC)を境に水準が 11.85から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-004 active_connections の推移](charts/EVT-20260608-host13-004.svg)

# イベントID( EVT-20260615-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→13→14→12→…→14→13→12→14
* 開始   : 2026-06-15 01:05:00 (UTC)
* 終了   : 2026-06-15 19:40:00 (UTC)
* 現象   : 2026-06-15 19:40:00 (UTC)を境に水準が 11.8から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.854, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-002 active_connections の推移](charts/EVT-20260615-host13-002.svg)

# イベントID( EVT-20260615-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→15→17→16→…→15→14→11→15
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.473, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-003 active_connections の推移](charts/EVT-20260615-host13-003.svg)

# イベントID( EVT-20260615-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→15→…→13→14→11→12
* 開始   : 2026-06-15 02:40:00 (UTC)
* 終了   : 2026-06-15 20:45:00 (UTC)
* 現象   : 2026-06-15 20:45:00 (UTC)を境に水準が 11.88から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.65, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.362, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-004 active_connections の推移](charts/EVT-20260615-host13-004.svg)

# イベントID( EVT-20260615-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→15→14→13→…→17→15→14→12
* 開始   : 2026-06-15 03:00:00 (UTC)
* 終了   : 2026-06-15 21:00:00 (UTC)
* 現象   : 2026-06-15 21:00:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.2, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-005 active_connections の推移](charts/EVT-20260615-host13-005.svg)

# イベントID( EVT-20260615-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→15→14→13→…→14→17→12→15
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 11.94から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.97σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.933, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-006 active_connections の推移](charts/EVT-20260615-host13-006.svg)

# イベントID( EVT-20260615-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→18→17→16→…→15→17→13→14
* 開始   : 2026-06-15 03:15:00 (UTC)
* 終了   : 2026-06-15 20:20:00 (UTC)
* 現象   : 2026-06-15 20:20:00 (UTC)を境に水準が 11.97から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.869, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.942, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-007 active_connections の推移](charts/EVT-20260615-host13-007.svg)

# イベントID( EVT-20260622-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→14→…→13→14→11→12
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.171, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.357, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-002 active_connections の推移](charts/EVT-20260622-host13-002.svg)

# イベントID( EVT-20260622-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→16→…→11→13→15→11
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.83から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-004 active_connections の推移](charts/EVT-20260622-host13-004.svg)

# イベントID( EVT-20260622-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→17→19→15→…→15→13→14→15
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.88から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.767, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-005 active_connections の推移](charts/EVT-20260622-host13-005.svg)

# イベントID( EVT-20260622-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→18→…→13→12→11→12
* 開始   : 2026-06-22 03:50:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.507, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-006 active_connections の推移](charts/EVT-20260622-host13-006.svg)

# イベントID( EVT-20260629-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→16→…→14→13→10→12
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.7から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-002 active_connections の推移](charts/EVT-20260629-host13-002.svg)

# イベントID( EVT-20260629-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→18→16→15→…→12→14→13→14
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 22:15:00 (UTC)
* 現象   : 2026-06-29 22:15:00 (UTC)を境に水準が 11.89から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.955, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-003 active_connections の推移](charts/EVT-20260629-host13-003.svg)

# イベントID( EVT-20260629-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→14→15→14→…→15→14→15→13
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 19:50:00 (UTC)
* 現象   : 2026-06-29 19:50:00 (UTC)を境に水準が 12.04から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.629, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-004 active_connections の推移](charts/EVT-20260629-host13-004.svg)

# イベントID( EVT-20260629-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→19→16→19→…→14→12→13→11
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 11.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.748, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-005 active_connections の推移](charts/EVT-20260629-host13-005.svg)

# イベントID( EVT-20260629-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→16→…→12→16→13→11
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:15:00 (UTC)
* 現象   : 2026-06-29 21:15:00 (UTC)を境に水準が 11.82から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.746, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.999, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-006 active_connections の推移](charts/EVT-20260629-host13-006.svg)

# イベントID( EVT-20260629-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→17→…→15→11→13→14
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 19:55:00 (UTC)
* 現象   : 2026-06-29 19:55:00 (UTC)を境に水準が 11.76から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.945, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-007 active_connections の推移](charts/EVT-20260629-host13-007.svg)

# イベントID( EVT-20260601-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 7→7→12→8→8
* 開始   : 2026-06-01 01:30:00 (UTC)
* 終了   : 2026-06-01 01:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-006 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→23→26→22→22
* 開始   : 2026-06-01 10:20:00 (UTC)
* 終了   : 2026-06-01 10:20:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.248倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host13-004 active_connections の推移](charts/EVT-20260601-host13-004.svg)

# イベントID( EVT-20260601-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→18→16→18→18
* 開始   : 2026-06-01 15:30:00 (UTC)
* 終了   : 2026-06-01 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→12→7→10→9
* 開始   : 2026-06-02 21:00:00 (UTC)
* 終了   : 2026-06-02 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→9→7
* 開始   : 2026-06-02 22:15:00 (UTC)
* 終了   : 2026-06-02 22:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-085 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260602-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→8→5→9→9
* 開始   : 2026-06-02 22:45:00 (UTC)
* 終了   : 2026-06-02 22:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 8→9→4→7→8
* 開始   : 2026-06-02 23:45:00 (UTC)
* 終了   : 2026-06-02 23:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→10→15→11→11
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→19→20
* 開始   : 2026-06-03 08:25:00 (UTC)
* 終了   : 2026-06-03 08:25:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→14→15→16→18→14→15→16
* 開始   : 2026-06-03 16:35:00 (UTC)
* 終了   : 2026-06-03 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→12→15→17→13→12→15
* 開始   : 2026-06-03 17:45:00 (UTC)
* 終了   : 2026-06-03 17:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7685(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→9→14→10→11
* 開始   : 2026-06-04 03:40:00 (UTC)
* 終了   : 2026-06-04 03:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host13-002 active_connections の推移](charts/EVT-20260604-host13-002.svg)

# イベントID( EVT-20260604-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→22→18→22→21
* 開始   : 2026-06-04 13:15:00 (UTC)
* 終了   : 2026-06-04 13:15:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→11→13
* 開始   : 2026-06-04 19:15:00 (UTC)
* 終了   : 2026-06-04 19:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→22→20
* 開始   : 2026-06-05 10:40:00 (UTC)
* 終了   : 2026-06-05 10:40:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→17→12→19→16→17→12→19→16
* 開始   : 2026-06-05 16:45:00 (UTC)
* 終了   : 2026-06-05 17:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260605-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260605-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→12→11
* 開始   : 2026-06-06 03:40:00 (UTC)
* 終了   : 2026-06-06 03:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→13→12→13→…→13→12→11→12
* 開始   : 2026-06-06 04:55:00 (UTC)
* 終了   : 2026-06-06 20:05:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260606-host13-002 active_connections の推移](charts/EVT-20260606-host13-002.svg)

# イベントID( EVT-20260606-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→13→…→12→14→12→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.893, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host13-003 active_connections の推移](charts/EVT-20260606-host13-003.svg)

# イベントID( EVT-20260606-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→11→10→9→…→11→14→12→13
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.04, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host13-004 active_connections の推移](charts/EVT-20260606-host13-004.svg)

# イベントID( EVT-20260606-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→10→11→10→11
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.855, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host13-005 active_connections の推移](charts/EVT-20260606-host13-005.svg)

# イベントID( EVT-20260606-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→14→…→10→8→11→12
* 開始   : 2026-06-06 06:10:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.044, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host13-006 active_connections の推移](charts/EVT-20260606-host13-006.svg)

# イベントID( EVT-20260606-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→11→…→11→10→11→12
* 開始   : 2026-06-06 06:15:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.495σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.995, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260606-host13-007 active_connections の推移](charts/EVT-20260606-host13-007.svg)

# イベントID( EVT-20260606-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→10→5→9→10
* 開始   : 2026-06-06 21:45:00 (UTC)
* 終了   : 2026-06-06 21:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→13→14
* 開始   : 2026-06-07 07:10:00 (UTC)
* 終了   : 2026-06-07 07:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→13→18→13→15
* 開始   : 2026-06-07 08:15:00 (UTC)
* 終了   : 2026-06-07 08:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.227σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→13→18→14→12
* 開始   : 2026-06-07 15:45:00 (UTC)
* 終了   : 2026-06-07 15:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→8→4→7→9
* 開始   : 2026-06-07 23:15:00 (UTC)
* 終了   : 2026-06-07 23:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→17→18→15→…→13→14→16→14
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.87から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.884, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.454, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-005 active_connections の推移](charts/EVT-20260608-host13-005.svg)

# イベントID( EVT-20260608-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→15→13→15→…→14→15→11→15
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.92から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.114, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→18→23→18→19
* 開始   : 2026-06-09 08:40:00 (UTC)
* 終了   : 2026-06-09 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 23→22→17→23→22
* 開始   : 2026-06-09 12:15:00 (UTC)
* 終了   : 2026-06-09 12:15:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→20→16→21→19
* 開始   : 2026-06-09 15:10:00 (UTC)
* 終了   : 2026-06-09 15:10:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→14→10→14→12
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 19:15:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→13→18→13→15
* 開始   : 2026-06-10 05:50:00 (UTC)
* 終了   : 2026-06-10 05:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→17→19
* 開始   : 2026-06-10 07:45:00 (UTC)
* 終了   : 2026-06-10 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→13→17→18→…→17→18→15→14
* 開始   : 2026-06-11 05:25:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→20→24→20→20
* 開始   : 2026-06-11 09:25:00 (UTC)
* 終了   : 2026-06-11 09:25:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.521σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→25→22→22→23→22→18→22→21
* 開始   : 2026-06-11 13:05:00 (UTC)
* 終了   : 2026-06-11 14:15:00 (UTC)
* 現象   : 2026-06-11 14:15:00 (UTC)を境に水準が 15.05から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→16→14→18→17
* 開始   : 2026-06-11 16:35:00 (UTC)
* 終了   : 2026-06-11 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→17→14→16→16
* 開始   : 2026-06-11 16:45:00 (UTC)
* 終了   : 2026-06-11 16:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→14→13
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 21→21→25→21→20
* 開始   : 2026-06-12 09:30:00 (UTC)
* 終了   : 2026-06-12 09:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host13-005 active_connections の推移](charts/EVT-20260612-host13-005.svg)

# イベントID( EVT-20260612-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→14
* 開始   : 2026-06-12 19:00:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.462σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host13-011 active_connections の推移](charts/EVT-20260612-host13-011.svg)

# イベントID( EVT-20260613-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→12→…→8→11→13→12
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.053, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host13-003 active_connections の推移](charts/EVT-20260613-host13-003.svg)

# イベントID( EVT-20260613-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→13→14→11→…→9→8→14→11
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.096, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260613-host13-004 active_connections の推移](charts/EVT-20260613-host13-004.svg)

# イベントID( EVT-20260613-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→13→…→11→12→13→11
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.3, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260613-host13-005 active_connections の推移](charts/EVT-20260613-host13-005.svg)

# イベントID( EVT-20260613-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→14→…→10→11→10→11
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.063, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host13-006 active_connections の推移](charts/EVT-20260613-host13-006.svg)

# イベントID( EVT-20260613-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→12→11→…→13→11→12→13
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.065, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host13-007 active_connections の推移](charts/EVT-20260613-host13-007.svg)

# イベントID( EVT-20260613-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→10→13→12→…→11→13→11→10
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.521σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.901, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host13-008 active_connections の推移](charts/EVT-20260613-host13-008.svg)

# イベントID( EVT-20260614-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→17→16
* 開始   : 2026-06-14 10:55:00 (UTC)
* 終了   : 2026-06-14 10:55:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→15→19→16→16
* 開始   : 2026-06-14 11:25:00 (UTC)
* 終了   : 2026-06-14 11:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→15→13
* 開始   : 2026-06-14 15:40:00 (UTC)
* 終了   : 2026-06-14 15:40:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→10→10→11→9→9→11→11→10
* 開始   : 2026-06-15 21:35:00 (UTC)
* 終了   : 2026-06-15 22:30:00 (UTC)
* 現象   : 2026-06-15 22:30:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.495σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→15→20→16→17
* 開始   : 2026-06-16 07:15:00 (UTC)
* 終了   : 2026-06-16 07:15:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→13→10→13→13
* 開始   : 2026-06-16 19:00:00 (UTC)
* 終了   : 2026-06-16 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→10→8→9→10→8→9→11
* 開始   : 2026-06-16 20:15:00 (UTC)
* 終了   : 2026-06-16 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→10→13→11→8
* 開始   : 2026-06-17 02:40:00 (UTC)
* 終了   : 2026-06-17 02:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→13→12
* 開始   : 2026-06-17 04:00:00 (UTC)
* 終了   : 2026-06-17 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→18→22→19→19
* 開始   : 2026-06-17 08:05:00 (UTC)
* 終了   : 2026-06-17 08:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 25→21→18→23→23
* 開始   : 2026-06-17 12:40:00 (UTC)
* 終了   : 2026-06-17 12:40:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→21→17→21→23
* 開始   : 2026-06-17 14:25:00 (UTC)
* 終了   : 2026-06-17 14:25:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→22→17→19→22→17→19→20
* 開始   : 2026-06-17 14:40:00 (UTC)
* 終了   : 2026-06-17 15:00:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→21→14→18→19
* 開始   : 2026-06-17 16:20:00 (UTC)
* 終了   : 2026-06-17 16:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-014 active_connections の推移](charts/EVT-20260617-host13-014.svg)

# イベントID( EVT-20260617-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→15→16→15
* 開始   : 2026-06-17 18:35:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 2026-06-17 19:40:00 (UTC)を境に水準が 15.15から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.863, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-021 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→9→11
* 開始   : 2026-06-17 21:10:00 (UTC)
* 終了   : 2026-06-17 21:10:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-081 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-021 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→8→4→9→9
* 開始   : 2026-06-18 00:05:00 (UTC)
* 終了   : 2026-06-18 00:05:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260618-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→9→15→11→12
* 開始   : 2026-06-18 03:55:00 (UTC)
* 終了   : 2026-06-18 03:55:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→16→16→15
* 開始   : 2026-06-18 05:45:00 (UTC)
* 終了   : 2026-06-18 06:20:00 (UTC)
* 現象   : 2026-06-18 06:20:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.53σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.125, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→19→22→20→16
* 開始   : 2026-06-18 07:45:00 (UTC)
* 終了   : 2026-06-18 07:45:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.403σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-006 active_connections の推移](charts/EVT-20260618-host13-006.svg)

# イベントID( EVT-20260618-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→15→17
* 開始   : 2026-06-18 18:10:00 (UTC)
* 終了   : 2026-06-18 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→13→13
* 開始   : 2026-06-18 18:35:00 (UTC)
* 終了   : 2026-06-18 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.58σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260618-host13-009 active_connections の推移](charts/EVT-20260618-host13-009.svg)

# イベントID( EVT-20260618-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→15→8→11→11
* 開始   : 2026-06-18 19:55:00 (UTC)
* 終了   : 2026-06-18 19:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→8→5→8→8
* 開始   : 2026-06-18 22:25:00 (UTC)
* 終了   : 2026-06-18 22:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→15→14
* 開始   : 2026-06-19 06:05:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→4→8→5→4→8→6
* 開始   : 2026-06-19 23:15:00 (UTC)
* 終了   : 2026-06-19 23:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→13→…→10→12→13→12
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.133, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間

![EVT-20260620-host13-004 active_connections の推移](charts/EVT-20260620-host13-004.svg)

# イベントID( EVT-20260620-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→11→14→12→…→10→9→12→10
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260620-host13-005 active_connections の推移](charts/EVT-20260620-host13-005.svg)

# イベントID( EVT-20260620-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→9→10→11→…→10→9→11→10
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.932, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host13-007 active_connections の推移](charts/EVT-20260620-host13-007.svg)

# イベントID( EVT-20260620-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→10→…→12→10→13→12
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.86, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260620-host13-008 active_connections の推移](charts/EVT-20260620-host13-008.svg)

# イベントID( EVT-20260620-host13-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→10→…→12→13→14→13
* 開始   : 2026-06-20 06:05:00 (UTC)
* 終了   : 2026-06-20 17:55:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.128, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260620-host13-009 active_connections の推移](charts/EVT-20260620-host13-009.svg)

# イベントID( EVT-20260620-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→10→…→11→13→14→12
* 開始   : 2026-06-20 06:40:00 (UTC)
* 終了   : 2026-06-20 18:30:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.873, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260620-host13-010 active_connections の推移](charts/EVT-20260620-host13-010.svg)

# イベントID( EVT-20260621-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→15→21→16→15
* 開始   : 2026-06-21 11:50:00 (UTC)
* 終了   : 2026-06-21 11:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.903σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host13-005 active_connections の推移](charts/EVT-20260621-host13-005.svg)

# イベントID( EVT-20260622-host13-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→…→12→15→13→12
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.8から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.867, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→15→13→14→…→18→16→15→14
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.91から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.958, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.999, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-003 active_connections の推移](charts/EVT-20260622-host13-003.svg)

# イベントID( EVT-20260623-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→12→11
* 開始   : 2026-06-23 04:50:00 (UTC)
* 終了   : 2026-06-23 04:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-004 active_connections の推移](charts/EVT-20260623-host13-004.svg)

# イベントID( EVT-20260623-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→14→18→15→15
* 開始   : 2026-06-23 06:00:00 (UTC)
* 終了   : 2026-06-23 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→17→20→18→17
* 開始   : 2026-06-23 07:15:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→16→14→13
* 開始   : 2026-06-24 04:15:00 (UTC)
* 終了   : 2026-06-24 04:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→18→13→17→18→13→17→16
* 開始   : 2026-06-24 05:50:00 (UTC)
* 終了   : 2026-06-24 06:00:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→17→22→19→20
* 開始   : 2026-06-24 07:50:00 (UTC)
* 終了   : 2026-06-24 07:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-004 active_connections の推移](charts/EVT-20260624-host13-004.svg)

# イベントID( EVT-20260624-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→22→18→22→21
* 開始   : 2026-06-24 13:55:00 (UTC)
* 終了   : 2026-06-24 13:55:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→15→17→20
* 開始   : 2026-06-24 15:45:00 (UTC)
* 終了   : 2026-06-24 15:45:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.7469(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→13→15→13→15→13→16→15
* 開始   : 2026-06-24 17:20:00 (UTC)
* 終了   : 2026-06-24 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→15→18
* 開始   : 2026-06-24 17:25:00 (UTC)
* 終了   : 2026-06-24 17:25:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→14→18→15→12
* 開始   : 2026-06-25 05:40:00 (UTC)
* 終了   : 2026-06-25 05:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→19→23→20→20
* 開始   : 2026-06-25 08:40:00 (UTC)
* 終了   : 2026-06-25 08:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→23→16→20→19
* 開始   : 2026-06-25 15:10:00 (UTC)
* 終了   : 2026-06-25 15:10:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.462σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-006 active_connections の推移](charts/EVT-20260625-host13-006.svg)

# イベントID( EVT-20260625-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→5→12→10
* 開始   : 2026-06-25 21:40:00 (UTC)
* 終了   : 2026-06-25 21:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host13-009 active_connections の推移](charts/EVT-20260625-host13-009.svg)

# イベントID( EVT-20260626-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→9→13→8→10
* 開始   : 2026-06-26 02:20:00 (UTC)
* 終了   : 2026-06-26 02:20:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.547σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-001 active_connections の推移](charts/EVT-20260626-host13-001.svg)

# イベントID( EVT-20260626-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→16→…→17→16→15→13
* 開始   : 2026-06-26 05:10:00 (UTC)
* 終了   : 2026-06-26 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→17→22→19→16
* 開始   : 2026-06-26 07:35:00 (UTC)
* 終了   : 2026-06-26 07:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host13-006 active_connections の推移](charts/EVT-20260626-host13-006.svg)

# イベントID( EVT-20260627-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→11→13→11→10
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.13, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260627-host13-001 active_connections の推移](charts/EVT-20260627-host13-001.svg)

# イベントID( EVT-20260627-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→13→…→10→11→12→10
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:40:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.959, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260627-host13-002 active_connections の推移](charts/EVT-20260627-host13-002.svg)

# イベントID( EVT-20260627-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→12→…→10→11→10→11
* 開始   : 2026-06-27 05:30:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.982, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host13-003 active_connections の推移](charts/EVT-20260627-host13-003.svg)

# イベントID( EVT-20260627-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→9→…→11→12→14→12
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.848, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host13-004 active_connections の推移](charts/EVT-20260627-host13-004.svg)

# イベントID( EVT-20260627-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→12→13→14→…→13→14→11→13
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 17:50:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260627-host13-005 active_connections の推移](charts/EVT-20260627-host13-005.svg)

# イベントID( EVT-20260627-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→14→…→11→13→12→10
* 開始   : 2026-06-27 06:50:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 11.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間

![EVT-20260627-host13-006 active_connections の推移](charts/EVT-20260627-host13-006.svg)

# イベントID( EVT-20260628-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→11→16→14→14→16
* 開始   : 2026-06-28 16:40:00 (UTC)
* 終了   : 2026-06-28 17:30:00 (UTC)
* 現象   : 2026-06-28 17:30:00 (UTC)を境に水準が 11.94から14.64へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.756σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.545, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→8→5→8→8
* 開始   : 2026-06-28 21:50:00 (UTC)
* 終了   : 2026-06-28 21:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 7→9→4→6→8
* 開始   : 2026-06-28 21:55:00 (UTC)
* 終了   : 2026-06-28 21:55:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.4286(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→10→3→10→6
* 開始   : 2026-06-30 00:30:00 (UTC)
* 終了   : 2026-06-30 00:30:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.3789(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-001 active_connections の推移](charts/EVT-20260630-host13-001.svg)

# イベントID( EVT-20260630-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→11→15→12→13
* 開始   : 2026-06-30 04:15:00 (UTC)
* 終了   : 2026-06-30 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→13→14→13→11→13→14→13→10
* 開始   : 2026-06-01 03:50:00 (UTC)
* 終了   : 2026-06-01 03:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→13→14→10→14→10→14→13
* 開始   : 2026-06-01 04:20:00 (UTC)
* 終了   : 2026-06-01 04:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→20→25→22→…→22→19→22→21
* 開始   : 2026-06-01 12:30:00 (UTC)
* 終了   : 2026-06-01 13:45:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260601-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→15→13→16→15→13→16→15
* 開始   : 2026-06-01 18:05:00 (UTC)
* 終了   : 2026-06-01 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→11→13→11→13
* 開始   : 2026-06-01 19:25:00 (UTC)
* 終了   : 2026-06-01 19:35:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→14→…→14→9→12→10
* 開始   : 2026-06-01 20:00:00 (UTC)
* 終了   : 2026-06-01 20:10:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→6→10→9→6→10
* 開始   : 2026-06-01 22:10:00 (UTC)
* 終了   : 2026-06-01 22:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→5→11→9→…→9→5→8→10
* 開始   : 2026-06-02 00:55:00 (UTC)
* 終了   : 2026-06-02 01:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→19→22→23→…→22→23→21→19
* 開始   : 2026-06-02 09:05:00 (UTC)
* 終了   : 2026-06-02 09:10:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→20→22→16→…→22→16→18→21
* 開始   : 2026-06-02 15:50:00 (UTC)
* 終了   : 2026-06-02 15:55:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→17→…→17→13→15→17
* 開始   : 2026-06-02 17:25:00 (UTC)
* 終了   : 2026-06-02 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→13→14→15→14→13→14
* 開始   : 2026-06-02 17:45:00 (UTC)
* 終了   : 2026-06-02 17:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→10→15→…→15→11→12→14
* 開始   : 2026-06-02 18:50:00 (UTC)
* 終了   : 2026-06-02 19:00:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7018(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→12→15→11→12
* 開始   : 2026-06-02 19:10:00 (UTC)
* 終了   : 2026-06-02 19:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260602-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-008 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→10→12→15→10→13
* 開始   : 2026-06-02 20:00:00 (UTC)
* 終了   : 2026-06-02 20:05:00 (UTC)
* 現象   : 火曜20時台の平常値(10.79)に対し 15であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.169σ 外れた (平常値=10.79)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260602-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-073 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→8→11→8→11→8→9→11
* 開始   : 2026-06-02 20:35:00 (UTC)
* 終了   : 2026-06-02 20:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→10→14→13→10→14→13→12
* 開始   : 2026-06-03 03:45:00 (UTC)
* 終了   : 2026-06-03 03:50:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.424倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.912σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→18→17→18→14→16
* 開始   : 2026-06-03 06:15:00 (UTC)
* 終了   : 2026-06-03 06:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→17→21→18→22→21→18→22→20
* 開始   : 2026-06-03 08:45:00 (UTC)
* 終了   : 2026-06-03 08:55:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260603-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→17→23→21→20→17→23→21→19
* 開始   : 2026-06-03 09:30:00 (UTC)
* 終了   : 2026-06-03 09:35:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 23→23→22→22→19→23→24→21→23
* 開始   : 2026-06-03 11:30:00 (UTC)
* 終了   : 2026-06-03 12:25:00 (UTC)
* 現象   : 2026-06-03 12:25:00 (UTC)を境に水準が 14.91から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 22→19→25→22→19→25→22→21
* 開始   : 2026-06-03 12:30:00 (UTC)
* 終了   : 2026-06-03 12:35:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→14→12→13→14→12→13→16
* 開始   : 2026-06-03 18:35:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→13→9→10→8→9→10→8→11
* 開始   : 2026-06-03 20:30:00 (UTC)
* 終了   : 2026-06-03 20:40:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→8→9→12→8→9→10
* 開始   : 2026-06-03 20:40:00 (UTC)
* 終了   : 2026-06-03 20:45:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.6531(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260603-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→9→6→9→…→9→12→11→10
* 開始   : 2026-06-04 02:25:00 (UTC)
* 終了   : 2026-06-04 02:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→18→16→16→17→17
* 開始   : 2026-06-04 05:50:00 (UTC)
* 終了   : 2026-06-04 06:15:00 (UTC)
* 現象   : 2026-06-04 06:15:00 (UTC)を境に水準が 15.09から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 24→22→22→22→22→21
* 開始   : 2026-06-04 10:30:00 (UTC)
* 終了   : 2026-06-04 10:55:00 (UTC)
* 現象   : 2026-06-04 10:55:00 (UTC)を境に水準が 15.06から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 22→21→21→21→22→23→19→22→20
* 開始   : 2026-06-04 14:25:00 (UTC)
* 終了   : 2026-06-04 15:25:00 (UTC)
* 現象   : 2026-06-04 15:25:00 (UTC)を境に水準が 14.95から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→18→18→19
* 開始   : 2026-06-04 16:35:00 (UTC)
* 終了   : 2026-06-04 16:50:00 (UTC)
* 現象   : 2026-06-04 16:50:00 (UTC)を境に水準が 14.98から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.363, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→13→10→13→10→12
* 開始   : 2026-06-04 19:45:00 (UTC)
* 終了   : 2026-06-04 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260604-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→6→9→6→9→6→11→10
* 開始   : 2026-06-05 02:00:00 (UTC)
* 終了   : 2026-06-05 02:10:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→11→9→10
* 開始   : 2026-06-05 02:35:00 (UTC)
* 終了   : 2026-06-05 03:00:00 (UTC)
* 現象   : 2026-06-05 03:00:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→17→19→17→19→16→17
* 開始   : 2026-06-05 07:05:00 (UTC)
* 終了   : 2026-06-05 07:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→10→13→10→13→10→13→12
* 開始   : 2026-06-05 19:15:00 (UTC)
* 終了   : 2026-06-05 19:25:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→11→6→8→…→8→12→9→7
* 開始   : 2026-06-05 22:35:00 (UTC)
* 終了   : 2026-06-05 22:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host03-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→8→…→8→11→10→9
* 開始   : 2026-06-07 01:05:00 (UTC)
* 終了   : 2026-06-07 01:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→13→…→13→14→10→13
* 開始   : 2026-06-07 05:50:00 (UTC)
* 終了   : 2026-06-07 06:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→16→17→15→15→14→15→18→16
* 開始   : 2026-06-07 09:50:00 (UTC)
* 終了   : 2026-06-07 11:00:00 (UTC)
* 現象   : 2026-06-07 11:00:00 (UTC)を境に水準が 11.89から13.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→19→21→21→21
* 開始   : 2026-06-09 08:10:00 (UTC)
* 終了   : 2026-06-09 08:30:00 (UTC)
* 現象   : 2026-06-09 08:30:00 (UTC)を境に水準が 14.92から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→22→24→22→24→22→20
* 開始   : 2026-06-09 10:30:00 (UTC)
* 終了   : 2026-06-09 10:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→19→19→18→19→18→19→19→21
* 開始   : 2026-06-09 15:55:00 (UTC)
* 終了   : 2026-06-09 17:30:00 (UTC)
* 現象   : 2026-06-09 17:30:00 (UTC)を境に水準が 15.02から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→12→…→11→10→12→11
* 開始   : 2026-06-09 19:20:00 (UTC)
* 終了   : 2026-06-09 19:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→12→…→11→9→11→12
* 開始   : 2026-06-09 20:00:00 (UTC)
* 終了   : 2026-06-09 20:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→9→11→9→11→9→11→9
* 開始   : 2026-06-09 20:05:00 (UTC)
* 終了   : 2026-06-09 20:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host13-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→9→11→10→9
* 開始   : 2026-06-09 23:40:00 (UTC)
* 終了   : 2026-06-10 00:00:00 (UTC)
* 現象   : 2026-06-10 00:00:00 (UTC)を境に水準が 14.97から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→8→8→9→9→9→9→10→12
* 開始   : 2026-06-10 00:45:00 (UTC)
* 終了   : 2026-06-10 01:50:00 (UTC)
* 現象   : 2026-06-10 01:50:00 (UTC)を境に水準が 14.9から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→14→13→15→14
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→17→…→16→17→13→15
* 開始   : 2026-06-10 05:25:00 (UTC)
* 終了   : 2026-06-10 05:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→18→…→18→22→18→19
* 開始   : 2026-06-10 08:05:00 (UTC)
* 終了   : 2026-06-10 08:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260610-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→20→23→19→20→23→19
* 開始   : 2026-06-10 09:10:00 (UTC)
* 終了   : 2026-06-10 09:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→19→21→21→23→22→24→23→23
* 開始   : 2026-06-10 09:30:00 (UTC)
* 終了   : 2026-06-10 10:55:00 (UTC)
* 現象   : 2026-06-10 10:55:00 (UTC)を境に水準が 15.03から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.884, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→16→19→16→19
* 開始   : 2026-06-10 15:45:00 (UTC)
* 終了   : 2026-06-10 15:50:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→16→13→12→…→13→12→13→14
* 開始   : 2026-06-10 18:00:00 (UTC)
* 終了   : 2026-06-10 18:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→17→13→14→17
* 開始   : 2026-06-10 18:10:00 (UTC)
* 終了   : 2026-06-10 18:40:00 (UTC)
* 現象   : 2026-06-10 18:40:00 (UTC)を境に水準が 15.03から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.636, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→…→12→9→13→10
* 開始   : 2026-06-10 19:40:00 (UTC)
* 終了   : 2026-06-10 19:50:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host13-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→10→15→10→13→11→12→14
* 開始   : 2026-06-10 19:55:00 (UTC)
* 終了   : 2026-06-10 20:30:00 (UTC)
* 現象   : 2026-06-10 20:30:00 (UTC)を境に水準が 14.93から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→9→9→11→13
* 開始   : 2026-06-11 01:40:00 (UTC)
* 終了   : 2026-06-11 02:30:00 (UTC)
* 現象   : 2026-06-11 02:30:00 (UTC)を境に水準が 14.93から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→12→13→8→…→8→14→12→11
* 開始   : 2026-06-11 03:45:00 (UTC)
* 終了   : 2026-06-11 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→13→12→14→15
* 開始   : 2026-06-11 04:25:00 (UTC)
* 終了   : 2026-06-11 04:55:00 (UTC)
* 現象   : 2026-06-11 04:55:00 (UTC)を境に水準が 14.99から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→20→14→17→18→20→14→17
* 開始   : 2026-06-11 07:20:00 (UTC)
* 終了   : 2026-06-11 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→18→…→24→18→23→22
* 開始   : 2026-06-11 10:40:00 (UTC)
* 終了   : 2026-06-11 10:45:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 21→17→18→16→17→18→16→18→20
* 開始   : 2026-06-11 15:20:00 (UTC)
* 終了   : 2026-06-11 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260611-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→14→16→17→…→14→16→14→16
* 開始   : 2026-06-11 17:25:00 (UTC)
* 終了   : 2026-06-11 17:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→12→15→16→12→15
* 開始   : 2026-06-11 18:20:00 (UTC)
* 終了   : 2026-06-11 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→12→11→12→13
* 開始   : 2026-06-11 19:15:00 (UTC)
* 終了   : 2026-06-11 19:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→11→8→11
* 開始   : 2026-06-11 21:15:00 (UTC)
* 終了   : 2026-06-11 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→9→…→9→6→7→9
* 開始   : 2026-06-11 23:00:00 (UTC)
* 終了   : 2026-06-11 23:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-083 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host13-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→11→10→9→9→8→10
* 開始   : 2026-06-11 23:30:00 (UTC)
* 終了   : 2026-06-12 00:00:00 (UTC)
* 現象   : 2026-06-12 00:00:00 (UTC)を境に水準が 15.03から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→11→5→8→5→8→5→6→7
* 開始   : 2026-06-12 01:10:00 (UTC)
* 終了   : 2026-06-12 01:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 6→8→11→5→8→11→5→8→9
* 開始   : 2026-06-12 01:10:00 (UTC)
* 終了   : 2026-06-12 01:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→10→12→10→12→10→9
* 開始   : 2026-06-12 02:50:00 (UTC)
* 終了   : 2026-06-12 03:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260612-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→21→18→20→…→20→17→21→22
* 開始   : 2026-06-12 14:50:00 (UTC)
* 終了   : 2026-06-12 15:00:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→20→19→20
* 開始   : 2026-06-12 15:20:00 (UTC)
* 終了   : 2026-06-12 15:35:00 (UTC)
* 現象   : 2026-06-12 15:35:00 (UTC)を境に水準が 15.02から12.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.863, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→20→21→20→17
* 開始   : 2026-06-12 16:15:00 (UTC)
* 終了   : 2026-06-12 17:10:00 (UTC)
* 現象   : 2026-06-12 17:10:00 (UTC)を境に水準が 14.9から12.37へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→14→13→14→13→14→13
* 開始   : 2026-06-12 17:55:00 (UTC)
* 終了   : 2026-06-12 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-072 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→13→15→12→13→15→12→15
* 開始   : 2026-06-12 18:05:00 (UTC)
* 終了   : 2026-06-12 19:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-016 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260612-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→13→11→12→11→11→11
* 開始   : 2026-06-12 20:05:00 (UTC)
* 終了   : 2026-06-12 20:35:00 (UTC)
* 現象   : 2026-06-12 20:35:00 (UTC)を境に水準が 14.9から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host13-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→9→12→10→11→10→10→11
* 開始   : 2026-06-12 21:45:00 (UTC)
* 終了   : 2026-06-12 22:35:00 (UTC)
* 現象   : 2026-06-12 22:35:00 (UTC)を境に水準が 15.04から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→8→9→10→8→10→7→10
* 開始   : 2026-06-13 00:15:00 (UTC)
* 終了   : 2026-06-13 00:50:00 (UTC)
* 現象   : 2026-06-13 00:50:00 (UTC)を境に水準が 15.08から11.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260613-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→8→5→9→…→9→11→10→8
* 開始   : 2026-06-13 00:55:00 (UTC)
* 終了   : 2026-06-13 01:05:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260613-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→9→12→9→14
* 開始   : 2026-06-14 19:15:00 (UTC)
* 終了   : 2026-06-14 19:50:00 (UTC)
* 現象   : 2026-06-14 19:50:00 (UTC)を境に水準が 11.76から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→10→10→9→9→9→9→8→10
* 開始   : 2026-06-14 22:05:00 (UTC)
* 終了   : 2026-06-14 22:50:00 (UTC)
* 現象   : 2026-06-14 22:50:00 (UTC)を境に水準が 11.82から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→8→11→10→8→9→10
* 開始   : 2026-06-15 00:20:00 (UTC)
* 終了   : 2026-06-15 01:10:00 (UTC)
* 現象   : 2026-06-15 01:10:00 (UTC)を境に水準が 11.91から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.374, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→12→14→12→14→12→14
* 開始   : 2026-06-16 04:00:00 (UTC)
* 終了   : 2026-06-16 04:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→12→16→13→16→13→16→15→14
* 開始   : 2026-06-16 05:35:00 (UTC)
* 終了   : 2026-06-16 05:45:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→18→16→18→16→18
* 開始   : 2026-06-16 06:25:00 (UTC)
* 終了   : 2026-06-16 06:30:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→18→18→18→18→18→19→20→22
* 開始   : 2026-06-16 07:25:00 (UTC)
* 終了   : 2026-06-16 08:35:00 (UTC)
* 現象   : 2026-06-16 08:35:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.812, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→8→9→11→8→9→10
* 開始   : 2026-06-16 20:45:00 (UTC)
* 終了   : 2026-06-16 20:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→10→6→5→…→6→5→7→10
* 開始   : 2026-06-16 22:45:00 (UTC)
* 終了   : 2026-06-16 22:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→8→5→7→11→5→7→11→7
* 開始   : 2026-06-17 00:15:00 (UTC)
* 終了   : 2026-06-17 00:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→15→12→13→13→13→13→16→14
* 開始   : 2026-06-17 04:20:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 2026-06-17 05:30:00 (UTC)を境に水準が 14.89から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.812, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→18→19→18→20→19→18→20→18
* 開始   : 2026-06-17 07:25:00 (UTC)
* 終了   : 2026-06-17 07:35:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→23→23→23→24
* 開始   : 2026-06-17 10:20:00 (UTC)
* 終了   : 2026-06-17 10:40:00 (UTC)
* 現象   : 2026-06-17 10:40:00 (UTC)を境に水準が 15.01から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→17→20→17→20→17→21→23
* 開始   : 2026-06-17 10:25:00 (UTC)
* 終了   : 2026-06-17 10:35:00 (UTC)
* 現象   : 水曜10時台の平常値(21.39)に対し 17であった
* 説明   : ALG-A1: 移動平均からの残差が 2.758σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.249σ 外れた (平常値=21.39)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→20→17→16→…→17→16→19→18
* 開始   : 2026-06-17 15:25:00 (UTC)
* 終了   : 2026-06-17 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→20→17→18→…→18→16→19→21
* 開始   : 2026-06-17 15:30:00 (UTC)
* 終了   : 2026-06-17 15:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→20→15→16→…→16→14→16→17
* 開始   : 2026-06-17 17:05:00 (UTC)
* 終了   : 2026-06-17 17:15:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→15→…→15→11→15→16
* 開始   : 2026-06-17 18:10:00 (UTC)
* 終了   : 2026-06-17 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.733σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→10→15→13→…→10→15→10→13
* 開始   : 2026-06-17 19:25:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260617-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260617-host13-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→14→10→9→10→14→10→9→10
* 開始   : 2026-06-17 20:05:00 (UTC)
* 終了   : 2026-06-17 20:10:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分

![EVT-20260617-host13-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host13-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→12→…→12→8→11→12
* 開始   : 2026-06-17 20:45:00 (UTC)
* 終了   : 2026-06-17 21:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260617-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host13-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→15→13→15→13→11
* 開始   : 2026-06-18 04:35:00 (UTC)
* 終了   : 2026-06-18 04:40:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→18→18→18
* 開始   : 2026-06-18 06:20:00 (UTC)
* 終了   : 2026-06-18 06:35:00 (UTC)
* 現象   : 2026-06-18 06:35:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→25→21→25→21→25→21→23
* 開始   : 2026-06-18 11:50:00 (UTC)
* 終了   : 2026-06-18 12:00:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→13→11→13→11→14→11
* 開始   : 2026-06-18 19:00:00 (UTC)
* 終了   : 2026-06-18 19:10:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→12→…→12→10→13→11
* 開始   : 2026-06-18 19:15:00 (UTC)
* 終了   : 2026-06-18 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→9→…→9→14→9→10
* 開始   : 2026-06-19 03:45:00 (UTC)
* 終了   : 2026-06-19 03:55:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→14→13→14→13→11
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:15:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→14→14→16→15→15→14→16→18
* 開始   : 2026-06-19 05:00:00 (UTC)
* 終了   : 2026-06-19 06:15:00 (UTC)
* 現象   : 2026-06-19 06:15:00 (UTC)を境に水準が 14.94から14.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→16→17→18→16→15
* 開始   : 2026-06-19 06:10:00 (UTC)
* 終了   : 2026-06-19 06:15:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→18→14→16→14→16→14→17→16
* 開始   : 2026-06-19 16:55:00 (UTC)
* 終了   : 2026-06-19 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.7706(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.908σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→20→14→16→14→16→14→17→14
* 開始   : 2026-06-19 17:15:00 (UTC)
* 終了   : 2026-06-19 17:25:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→13→18→14→…→11→15→11→13
* 開始   : 2026-06-19 18:40:00 (UTC)
* 終了   : 2026-06-19 19:10:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260619-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→8→9→10→7→10→8→10→10
* 開始   : 2026-06-20 00:35:00 (UTC)
* 終了   : 2026-06-20 01:15:00 (UTC)
* 現象   : 2026-06-20 01:15:00 (UTC)を境に水準が 14.94から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260620-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→13→10→9→12→13→10
* 開始   : 2026-06-20 03:45:00 (UTC)
* 終了   : 2026-06-20 03:50:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260620-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→10→9→10→…→9→10→12→8
* 開始   : 2026-06-20 04:20:00 (UTC)
* 終了   : 2026-06-20 04:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.055, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260620-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→11→…→10→11→14→12
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 05:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.865, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260620-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host13-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→10→9→10→…→9→10→8→12
* 開始   : 2026-06-20 19:25:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.033, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260620-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→10→10→9→8→10
* 開始   : 2026-06-21 01:10:00 (UTC)
* 終了   : 2026-06-21 01:40:00 (UTC)
* 現象   : 2026-06-21 01:40:00 (UTC)を境に水準が 11.84から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→5→11→8→7→5→11→8→10
* 開始   : 2026-06-21 01:45:00 (UTC)
* 終了   : 2026-06-21 01:50:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→9→8→9→9→9→9→9→11
* 開始   : 2026-06-21 02:05:00 (UTC)
* 終了   : 2026-06-21 02:50:00 (UTC)
* 現象   : 2026-06-21 02:50:00 (UTC)を境に水準が 11.8から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→17→13→17→12→14
* 開始   : 2026-06-21 08:15:00 (UTC)
* 終了   : 2026-06-21 08:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260621-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260621-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→11→12→16→11→15→12
* 開始   : 2026-06-21 15:25:00 (UTC)
* 終了   : 2026-06-21 15:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260621-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→13→14→13
* 開始   : 2026-06-21 17:30:00 (UTC)
* 終了   : 2026-06-21 17:45:00 (UTC)
* 現象   : 2026-06-21 17:45:00 (UTC)を境に水準が 11.8から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→11→10→13→11→14
* 開始   : 2026-06-21 18:00:00 (UTC)
* 終了   : 2026-06-21 18:35:00 (UTC)
* 現象   : 2026-06-21 18:35:00 (UTC)を境に水準が 11.85から14.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.726, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→8→11→14→8→11→14→10→8
* 開始   : 2026-06-21 19:30:00 (UTC)
* 終了   : 2026-06-21 19:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→7→6→7→6→11→10
* 開始   : 2026-06-21 21:20:00 (UTC)
* 終了   : 2026-06-21 21:30:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→10→9→12
* 開始   : 2026-06-22 21:10:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→12→13
* 開始   : 2026-06-23 03:05:00 (UTC)
* 終了   : 2026-06-23 03:15:00 (UTC)
* 現象   : 2026-06-23 03:15:00 (UTC)を境に水準が 15.04から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→13→11→13→11→13→10→11
* 開始   : 2026-06-23 03:20:00 (UTC)
* 終了   : 2026-06-23 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-007 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260623-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→13→…→13→15→13→14
* 開始   : 2026-06-23 04:30:00 (UTC)
* 終了   : 2026-06-23 04:40:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→21→22→22→19→22→21→21→22
* 開始   : 2026-06-23 08:40:00 (UTC)
* 終了   : 2026-06-23 09:35:00 (UTC)
* 現象   : 2026-06-23 09:35:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→18→15→16→…→15→14→17→16
* 開始   : 2026-06-23 16:05:00 (UTC)
* 終了   : 2026-06-23 17:10:00 (UTC)
* 現象   : 2026-06-23 17:10:00 (UTC)を境に水準が 14.98から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→17→15→14→…→15→14→18→17
* 開始   : 2026-06-23 16:50:00 (UTC)
* 終了   : 2026-06-23 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→11→16→11→16→11→13→12
* 開始   : 2026-06-23 19:05:00 (UTC)
* 終了   : 2026-06-23 19:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→17→16→14→17→15
* 開始   : 2026-06-24 05:45:00 (UTC)
* 終了   : 2026-06-24 05:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→22→22→21→21→21→22→24→22
* 開始   : 2026-06-24 09:45:00 (UTC)
* 終了   : 2026-06-24 10:40:00 (UTC)
* 現象   : 2026-06-24 10:40:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→25→22→21→25→22→23
* 開始   : 2026-06-24 12:00:00 (UTC)
* 終了   : 2026-06-24 12:05:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260624-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→18→16→19→16→19→16→18→17
* 開始   : 2026-06-24 16:15:00 (UTC)
* 終了   : 2026-06-24 16:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→15→12→15→12→15
* 開始   : 2026-06-24 18:20:00 (UTC)
* 終了   : 2026-06-24 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 7→8→13→10→13→10→13→11→10
* 開始   : 2026-06-25 02:20:00 (UTC)
* 終了   : 2026-06-25 02:30:00 (UTC)
* 現象   : 平常時(9)に対し 1.444倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.778σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→11→14→11→14→11→14
* 開始   : 2026-06-25 04:45:00 (UTC)
* 終了   : 2026-06-25 04:50:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 25→22→24→24→24→23→24
* 開始   : 2026-06-25 11:25:00 (UTC)
* 終了   : 2026-06-25 11:55:00 (UTC)
* 現象   : 2026-06-25 11:55:00 (UTC)を境に水準が 15から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→17→18
* 開始   : 2026-06-25 17:20:00 (UTC)
* 終了   : 2026-06-25 17:30:00 (UTC)
* 現象   : 2026-06-25 17:30:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→17→14→14→12→14→14
* 開始   : 2026-06-25 18:10:00 (UTC)
* 終了   : 2026-06-25 20:10:00 (UTC)
* 現象   : 2026-06-25 20:10:00 (UTC)を境に水準が 15.03から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.708, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→6→11→8→11→8→11→8
* 開始   : 2026-06-25 23:45:00 (UTC)
* 終了   : 2026-06-25 23:55:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→10→13→8→13→8→13→12
* 開始   : 2026-06-26 03:10:00 (UTC)
* 終了   : 2026-06-26 03:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260626-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分

![EVT-20260626-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→15→17→16→16→19
* 開始   : 2026-06-26 05:50:00 (UTC)
* 終了   : 2026-06-26 06:50:00 (UTC)
* 現象   : 2026-06-26 06:50:00 (UTC)を境に水準が 14.94から14.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.181, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→18→16→19→…→17→19→18→16
* 開始   : 2026-06-26 06:45:00 (UTC)
* 終了   : 2026-06-26 07:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260626-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 22→23→19→21→21→19→21→22→21
* 開始   : 2026-06-26 14:35:00 (UTC)
* 終了   : 2026-06-26 15:15:00 (UTC)
* 現象   : 2026-06-26 15:15:00 (UTC)を境に水準が 14.94から12.66へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 22→22→22→21→19→22→23→20
* 開始   : 2026-06-26 14:45:00 (UTC)
* 終了   : 2026-06-26 15:30:00 (UTC)
* 現象   : 2026-06-26 15:30:00 (UTC)を境に水準が 14.98から12.79へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→15→18→16→15→18→16
* 開始   : 2026-06-26 16:25:00 (UTC)
* 終了   : 2026-06-26 16:30:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→16→13→16→17
* 開始   : 2026-06-26 18:00:00 (UTC)
* 終了   : 2026-06-26 18:05:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260626-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→12→9→8→…→9→8→9→10
* 開始   : 2026-06-26 20:15:00 (UTC)
* 終了   : 2026-06-26 20:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host13-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→10→8→11
* 開始   : 2026-06-26 21:55:00 (UTC)
* 終了   : 2026-06-26 22:20:00 (UTC)
* 現象   : 2026-06-26 22:20:00 (UTC)を境に水準が 14.91から12.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→6→8→6→8→6→10→7
* 開始   : 2026-06-27 21:15:00 (UTC)
* 終了   : 2026-06-27 21:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→16→16→16→18→14→15→18
* 開始   : 2026-06-28 11:10:00 (UTC)
* 終了   : 2026-06-28 11:45:00 (UTC)
* 現象   : 2026-06-28 11:45:00 (UTC)を境に水準が 11.88から13.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.726, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→17→18
* 開始   : 2026-06-28 12:45:00 (UTC)
* 終了   : 2026-06-28 12:55:00 (UTC)
* 現象   : 2026-06-28 12:55:00 (UTC)を境に水準が 11.93から13.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→12→10→12→9→10→10→10
* 開始   : 2026-06-28 20:15:00 (UTC)
* 終了   : 2026-06-28 21:00:00 (UTC)
* 現象   : 2026-06-28 21:00:00 (UTC)を境に水準が 11.73から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→5→8→11→5→8→7
* 開始   : 2026-06-28 23:35:00 (UTC)
* 終了   : 2026-06-28 23:40:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260628-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→10→10→10→10→8→9→10→10
* 開始   : 2026-06-29 00:20:00 (UTC)
* 終了   : 2026-06-29 01:20:00 (UTC)
* 現象   : 2026-06-29 01:20:00 (UTC)を境に水準が 11.78から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→8→9→9
* 開始   : 2026-06-30 00:35:00 (UTC)
* 終了   : 2026-06-30 00:50:00 (UTC)
* 現象   : 2026-06-30 00:50:00 (UTC)を境に水準が 15.03から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.836, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→10→8→14→12→10→8→14→12
* 開始   : 2026-06-30 04:10:00 (UTC)
* 終了   : 2026-06-30 04:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→12→…→15→14→16→15
* 開始   : 2026-06-30 05:20:00 (UTC)
* 終了   : 2026-06-30 05:45:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260630-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→17→15→17→18
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 06:10:00 (UTC)
* 現象   : 2026-06-30 06:10:00 (UTC)を境に水準が 14.87から15.2へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→17→21→17→21→19
* 開始   : 2026-06-30 07:45:00 (UTC)
* 終了   : 2026-06-30 07:55:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260630-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→22→18→24→21→22→18→24→21
* 開始   : 2026-06-30 13:35:00 (UTC)
* 終了   : 2026-06-30 13:40:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→11→6→11→6→9→8
* 開始   : 2026-06-30 23:15:00 (UTC)
* 終了   : 2026-06-30 23:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-068 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host13-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
