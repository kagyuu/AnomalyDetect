# host06 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host06 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 307 (SEVERE: 22, FATAL: 130, WARN: 155, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 130 | 155 | 307 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→18→…→14→15→14→15
* 開始   : 2026-07-06 01:40:00 (UTC)
* 終了   : 2026-07-06 19:15:00 (UTC)
* 現象   : 2026-07-06 19:15:00 (UTC)を境に水準が 11.85から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.394, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-001 active_connections の推移](charts/EVT-20260706-host06-001.svg)

# イベントID( EVT-20260706-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→15→13→17→…→12→14→13→12
* 開始   : 2026-07-06 02:15:00 (UTC)
* 終了   : 2026-07-06 20:40:00 (UTC)
* 現象   : 2026-07-06 20:40:00 (UTC)を境に水準が 11.71から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.765, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-002 active_connections の推移](charts/EVT-20260706-host06-002.svg)

# イベントID( EVT-20260706-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→15→…→13→14→13→12
* 開始   : 2026-07-06 02:15:00 (UTC)
* 終了   : 2026-07-06 22:25:00 (UTC)
* 現象   : 2026-07-06 22:25:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.997, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-003 active_connections の推移](charts/EVT-20260706-host06-003.svg)

# イベントID( EVT-20260706-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→15→16→17→…→16→15→13→14
* 開始   : 2026-07-06 02:45:00 (UTC)
* 終了   : 2026-07-06 21:35:00 (UTC)
* 現象   : 2026-07-06 21:35:00 (UTC)を境に水準が 11.88から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.667, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-004 active_connections の推移](charts/EVT-20260706-host06-004.svg)

# イベントID( EVT-20260706-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→14→15→13→…→13→15→13→14
* 開始   : 2026-07-06 03:20:00 (UTC)
* 終了   : 2026-07-06 21:55:00 (UTC)
* 現象   : 2026-07-06 21:55:00 (UTC)を境に水準が 11.83から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.743, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-005 active_connections の推移](charts/EVT-20260706-host06-005.svg)

# イベントID( EVT-20260713-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→14→…→13→15→14→15
* 開始   : 2026-07-13 02:05:00 (UTC)
* 終了   : 2026-07-13 19:15:00 (UTC)
* 現象   : 2026-07-13 19:15:00 (UTC)を境に水準が 11.82から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-002 active_connections の推移](charts/EVT-20260713-host06-002.svg)

# イベントID( EVT-20260713-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→16→…→16→14→16→14
* 開始   : 2026-07-13 02:10:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.84から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.109, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-003 active_connections の推移](charts/EVT-20260713-host06-003.svg)

# イベントID( EVT-20260713-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→17→15→16→…→12→14→12→14
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 19:50:00 (UTC)
* 現象   : 2026-07-13 19:50:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.703, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-004 active_connections の推移](charts/EVT-20260713-host06-004.svg)

# イベントID( EVT-20260713-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→17→16→15→…→12→13→11→12
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 19:50:00 (UTC)
* 現象   : 2026-07-13 19:50:00 (UTC)を境に水準が 11.64から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.67, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-005 active_connections の推移](charts/EVT-20260713-host06-005.svg)

# イベントID( EVT-20260713-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→17→…→15→14→15→14
* 開始   : 2026-07-13 02:40:00 (UTC)
* 終了   : 2026-07-13 21:05:00 (UTC)
* 現象   : 2026-07-13 21:05:00 (UTC)を境に水準が 11.95から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.71, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-006 active_connections の推移](charts/EVT-20260713-host06-006.svg)

# イベントID( EVT-20260713-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→16→…→16→14→16→14
* 開始   : 2026-07-13 03:50:00 (UTC)
* 終了   : 2026-07-13 21:25:00 (UTC)
* 現象   : 2026-07-13 21:25:00 (UTC)を境に水準が 11.93から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.822, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-007 active_connections の推移](charts/EVT-20260713-host06-007.svg)

# イベントID( EVT-20260720-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→12→13→16→…→13→15→13→14
* 開始   : 2026-07-20 01:55:00 (UTC)
* 終了   : 2026-07-20 21:05:00 (UTC)
* 現象   : 2026-07-20 21:05:00 (UTC)を境に水準が 11.72から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-001 active_connections の推移](charts/EVT-20260720-host06-001.svg)

# イベントID( EVT-20260720-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→14→…→13→14→11→14
* 開始   : 2026-07-20 02:30:00 (UTC)
* 終了   : 2026-07-20 21:50:00 (UTC)
* 現象   : 2026-07-20 21:50:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-004 active_connections の推移](charts/EVT-20260720-host06-004.svg)

# イベントID( EVT-20260720-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→16→15→14→…→14→15→14→12
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.84から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.905, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.714, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-005 active_connections の推移](charts/EVT-20260720-host06-005.svg)

# イベントID( EVT-20260720-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→14→15→13→14
* 開始   : 2026-07-20 03:25:00 (UTC)
* 終了   : 2026-07-20 21:10:00 (UTC)
* 現象   : 2026-07-20 21:10:00 (UTC)を境に水準が 11.96から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.728, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-006 active_connections の推移](charts/EVT-20260720-host06-006.svg)

# イベントID( EVT-20260720-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→18→…→16→13→12→13
* 開始   : 2026-07-20 04:25:00 (UTC)
* 終了   : 2026-07-21 00:00:00 (UTC)
* 現象   : 2026-07-21 00:00:00 (UTC)を境に水準が 11.92から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-007 active_connections の推移](charts/EVT-20260720-host06-007.svg)

# イベントID( EVT-20260727-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→13→15→17→…→12→17→13→15
* 開始   : 2026-07-27 02:25:00 (UTC)
* 終了   : 2026-07-27 20:25:00 (UTC)
* 現象   : 2026-07-27 20:25:00 (UTC)を境に水準が 11.69から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.964, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.154, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-001 active_connections の推移](charts/EVT-20260727-host06-001.svg)

# イベントID( EVT-20260727-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→15→…→14→16→15→13
* 開始   : 2026-07-27 02:25:00 (UTC)
* 終了   : 2026-07-27 19:40:00 (UTC)
* 現象   : 2026-07-27 19:40:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.309, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-002 active_connections の推移](charts/EVT-20260727-host06-002.svg)

# イベントID( EVT-20260727-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→15→…→14→15→14→15
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.92から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-003 active_connections の推移](charts/EVT-20260727-host06-003.svg)

# イベントID( EVT-20260727-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→13→14→13→…→12→13→10→12
* 開始   : 2026-07-27 02:45:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 11.76から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-004 active_connections の推移](charts/EVT-20260727-host06-004.svg)

# イベントID( EVT-20260727-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→15→…→14→16→13→12
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 20:30:00 (UTC)
* 現象   : 2026-07-27 20:30:00 (UTC)を境に水準が 11.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-005 active_connections の推移](charts/EVT-20260727-host06-005.svg)

# イベントID( EVT-20260727-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→18→17→…→15→11→12→13
* 開始   : 2026-07-27 03:15:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.95から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.686, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-006 active_connections の推移](charts/EVT-20260727-host06-006.svg)

# イベントID( EVT-20260701-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→13→9→7
* 開始   : 2026-07-01 02:10:00 (UTC)
* 終了   : 2026-07-01 02:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 24→21→19→18→…→18→17→22→20
* 開始   : 2026-07-01 14:10:00 (UTC)
* 終了   : 2026-07-01 14:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→13→21→15→…→13→21→15→18
* 開始   : 2026-07-01 16:50:00 (UTC)
* 終了   : 2026-07-01 17:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host06-008 active_connections の推移](charts/EVT-20260701-host06-008.svg)

# イベントID( EVT-20260701-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→9→13→12
* 開始   : 2026-07-01 19:00:00 (UTC)
* 終了   : 2026-07-01 19:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→9→12→11→8→9→12
* 開始   : 2026-07-01 19:45:00 (UTC)
* 終了   : 2026-07-01 19:50:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→9→12→8→9→12→9
* 開始   : 2026-07-01 20:15:00 (UTC)
* 終了   : 2026-07-01 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260701-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260701-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→14→17→14→13
* 開始   : 2026-07-02 04:55:00 (UTC)
* 終了   : 2026-07-02 04:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260702-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→17→16
* 開始   : 2026-07-02 06:25:00 (UTC)
* 終了   : 2026-07-02 06:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→17→22→20→18
* 開始   : 2026-07-02 08:05:00 (UTC)
* 終了   : 2026-07-02 08:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→21→15→19→18
* 開始   : 2026-07-02 15:50:00 (UTC)
* 終了   : 2026-07-02 15:50:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.7595(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→15→10→13→14
* 開始   : 2026-07-02 19:05:00 (UTC)
* 終了   : 2026-07-02 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→12→16→18→…→16→18→13→15
* 開始   : 2026-07-03 05:35:00 (UTC)
* 終了   : 2026-07-03 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→17→21→20→17
* 開始   : 2026-07-03 07:45:00 (UTC)
* 終了   : 2026-07-03 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 23→21→17→20→20
* 開始   : 2026-07-03 14:45:00 (UTC)
* 終了   : 2026-07-03 15:35:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260703-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260703-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→14→10→14→12
* 開始   : 2026-07-03 18:50:00 (UTC)
* 終了   : 2026-07-03 18:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-013 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→…→10→13→11→12
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 19:45:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.056, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260704-host06-003 active_connections の推移](charts/EVT-20260704-host06-003.svg)

# イベントID( EVT-20260704-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→10→14→13→15
* 開始   : 2026-07-04 05:10:00 (UTC)
* 終了   : 2026-07-04 18:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.934, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260704-host06-004 active_connections の推移](charts/EVT-20260704-host06-004.svg)

# イベントID( EVT-20260704-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→13→10→11→…→13→12→13→12
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 18:10:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260704-host06-005 active_connections の推移](charts/EVT-20260704-host06-005.svg)

# イベントID( EVT-20260704-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→10→11→12→…→13→12→14→11
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.863σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.425, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host06-006 active_connections の推移](charts/EVT-20260704-host06-006.svg)

# イベントID( EVT-20260704-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→13→…→10→11→12→10
* 開始   : 2026-07-04 05:55:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.935, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260704-host06-007 active_connections の推移](charts/EVT-20260704-host06-007.svg)

# イベントID( EVT-20260704-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→13→15→11→…→12→13→15→12
* 開始   : 2026-07-04 06:10:00 (UTC)
* 終了   : 2026-07-04 18:15:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260704-host06-008 active_connections の推移](charts/EVT-20260704-host06-008.svg)

# イベントID( EVT-20260705-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→8→13→9→10
* 開始   : 2026-07-05 02:20:00 (UTC)
* 終了   : 2026-07-05 02:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→14→19→15→14
* 開始   : 2026-07-05 14:40:00 (UTC)
* 終了   : 2026-07-05 14:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→16→11→14→14
* 開始   : 2026-07-05 14:40:00 (UTC)
* 終了   : 2026-07-05 14:40:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→13→…→13→14→13→14
* 開始   : 2026-07-06 03:55:00 (UTC)
* 終了   : 2026-07-06 20:20:00 (UTC)
* 現象   : 2026-07-06 20:20:00 (UTC)を境に水準が 11.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.721, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→20→24→20→24→20→21
* 開始   : 2026-07-07 09:15:00 (UTC)
* 終了   : 2026-07-07 09:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 23→22→18→21→22
* 開始   : 2026-07-07 13:10:00 (UTC)
* 終了   : 2026-07-07 13:10:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 20→19→15→18→19
* 開始   : 2026-07-07 16:05:00 (UTC)
* 終了   : 2026-07-07 16:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.766(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.195σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→8→15→8→…→8→6→9→10
* 開始   : 2026-07-07 21:20:00 (UTC)
* 終了   : 2026-07-07 21:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.488倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.454σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260707-host06-010 active_connections の推移](charts/EVT-20260707-host06-010.svg)

# イベントID( EVT-20260708-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→20→25→20→22
* 開始   : 2026-07-08 10:00:00 (UTC)
* 終了   : 2026-07-08 10:00:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→20→16→21→19
* 開始   : 2026-07-08 14:50:00 (UTC)
* 終了   : 2026-07-08 14:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→20→15→20→17
* 開始   : 2026-07-08 15:55:00 (UTC)
* 終了   : 2026-07-08 15:55:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.7595(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→13→17→18
* 開始   : 2026-07-08 17:20:00 (UTC)
* 終了   : 2026-07-08 17:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→14→12
* 開始   : 2026-07-08 19:05:00 (UTC)
* 終了   : 2026-07-08 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→14→9→12→…→12→10→12→13
* 開始   : 2026-07-08 19:20:00 (UTC)
* 終了   : 2026-07-08 19:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→8→4→6→6
* 開始   : 2026-07-08 23:50:00 (UTC)
* 終了   : 2026-07-08 23:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→11→13
* 開始   : 2026-07-09 04:40:00 (UTC)
* 終了   : 2026-07-09 04:40:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→18→23→21→18
* 開始   : 2026-07-09 08:35:00 (UTC)
* 終了   : 2026-07-09 08:35:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260709-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→15→11→13→15
* 開始   : 2026-07-09 18:20:00 (UTC)
* 終了   : 2026-07-09 18:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→9→15→9→10
* 開始   : 2026-07-10 03:30:00 (UTC)
* 終了   : 2026-07-10 03:30:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→14→19→14→14
* 開始   : 2026-07-10 06:15:00 (UTC)
* 終了   : 2026-07-10 06:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→21→19→21→19→21→20
* 開始   : 2026-07-10 08:05:00 (UTC)
* 終了   : 2026-07-10 09:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260710-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260710-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260710-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 24→22→17→23→21
* 開始   : 2026-07-10 13:05:00 (UTC)
* 終了   : 2026-07-10 13:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→12→…→11→13→10→11
* 開始   : 2026-07-11 04:40:00 (UTC)
* 終了   : 2026-07-11 19:20:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.954, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260711-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260711-host06-002 active_connections の推移](charts/EVT-20260711-host06-002.svg)

# イベントID( EVT-20260711-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→13→11→13→…→13→14→13→14
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host06-003 active_connections の推移](charts/EVT-20260711-host06-003.svg)

# イベントID( EVT-20260711-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→10→9→13→…→12→10→13→12
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.311, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host06-004 active_connections の推移](charts/EVT-20260711-host06-004.svg)

# イベントID( EVT-20260711-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→14→…→10→12→13→12
* 開始   : 2026-07-11 05:50:00 (UTC)
* 終了   : 2026-07-11 18:55:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260711-host06-005 active_connections の推移](charts/EVT-20260711-host06-005.svg)

# イベントID( EVT-20260711-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→13→12→11→…→10→8→9→11
* 開始   : 2026-07-11 06:10:00 (UTC)
* 終了   : 2026-07-11 19:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.124, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host06-006 active_connections の推移](charts/EVT-20260711-host06-006.svg)

# イベントID( EVT-20260711-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→12→…→13→11→15→14
* 開始   : 2026-07-11 06:10:00 (UTC)
* 終了   : 2026-07-11 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host06-007 active_connections の推移](charts/EVT-20260711-host06-007.svg)

# イベントID( EVT-20260712-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→8→5→9→…→9→12→8→7
* 開始   : 2026-07-12 01:05:00 (UTC)
* 終了   : 2026-07-12 01:15:00 (UTC)
* 現象   : 日曜1時台の平常値(8.413)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.113σ 外れた (平常値=8.413)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→14→16
* 開始   : 2026-07-12 08:25:00 (UTC)
* 終了   : 2026-07-12 08:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→15→11→13→…→13→10→14→15
* 開始   : 2026-07-12 16:00:00 (UTC)
* 終了   : 2026-07-12 16:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→13→14→12
* 開始   : 2026-07-12 18:25:00 (UTC)
* 終了   : 2026-07-12 19:45:00 (UTC)
* 現象   : 2026-07-12 19:45:00 (UTC)を境に水準が 11.78から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.846σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→13→16→12→11
* 開始   : 2026-07-14 04:25:00 (UTC)
* 終了   : 2026-07-14 04:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→19→17→15
* 開始   : 2026-07-14 06:25:00 (UTC)
* 終了   : 2026-07-14 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 22→21→17→20→19
* 開始   : 2026-07-14 14:30:00 (UTC)
* 終了   : 2026-07-14 14:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→9→6→9→10
* 開始   : 2026-07-14 21:30:00 (UTC)
* 終了   : 2026-07-14 21:30:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→18→13→15→18→13
* 開始   : 2026-07-15 05:00:00 (UTC)
* 終了   : 2026-07-15 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260715-host06-004 active_connections の推移](charts/EVT-20260715-host06-004.svg)

# イベントID( EVT-20260715-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→19→14→18→17
* 開始   : 2026-07-15 15:55:00 (UTC)
* 終了   : 2026-07-15 15:55:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host06-007 active_connections の推移](charts/EVT-20260715-host06-007.svg)

# イベントID( EVT-20260715-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→13→16→12→13→16→12→15→14
* 開始   : 2026-07-15 17:55:00 (UTC)
* 終了   : 2026-07-15 19:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260715-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→16→11→14→13
* 開始   : 2026-07-15 18:10:00 (UTC)
* 終了   : 2026-07-15 18:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host06-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→14→…→14→11→17→16
* 開始   : 2026-07-15 18:10:00 (UTC)
* 終了   : 2026-07-15 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→10→15→13→11
* 開始   : 2026-07-16 03:45:00 (UTC)
* 終了   : 2026-07-16 03:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→11→16→14→13
* 開始   : 2026-07-16 04:30:00 (UTC)
* 終了   : 2026-07-16 04:30:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→17→21→17→16
* 開始   : 2026-07-16 07:20:00 (UTC)
* 終了   : 2026-07-16 07:20:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 24→20→17→21→21
* 開始   : 2026-07-16 14:05:00 (UTC)
* 終了   : 2026-07-16 14:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→16→12→16→16
* 開始   : 2026-07-16 17:55:00 (UTC)
* 終了   : 2026-07-16 17:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260716-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→7→9→9→8→10
* 開始   : 2026-07-16 22:10:00 (UTC)
* 終了   : 2026-07-16 22:35:00 (UTC)
* 現象   : 2026-07-16 22:35:00 (UTC)を境に水準が 14.85から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→8→4→8→7
* 開始   : 2026-07-17 00:10:00 (UTC)
* 終了   : 2026-07-17 00:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→23→17→21→21
* 開始   : 2026-07-17 14:05:00 (UTC)
* 終了   : 2026-07-17 14:05:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host06-005 active_connections の推移](charts/EVT-20260717-host06-005.svg)

# イベントID( EVT-20260717-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→12→10→…→10→11→13→12
* 開始   : 2026-07-17 19:00:00 (UTC)
* 終了   : 2026-07-17 19:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260717-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260717-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→8→4→8→9
* 開始   : 2026-07-17 23:15:00 (UTC)
* 終了   : 2026-07-17 23:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-094 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→11→10→11→…→10→13→12→11
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.731, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host06-002 active_connections の推移](charts/EVT-20260718-host06-002.svg)

# イベントID( EVT-20260718-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→12→9→11→…→12→11→14→11
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 18:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.167, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260718-host06-003 active_connections の推移](charts/EVT-20260718-host06-003.svg)

# イベントID( EVT-20260718-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→14→11→10→…→13→11→13→11
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 18:35:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.868, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260718-host06-004 active_connections の推移](charts/EVT-20260718-host06-004.svg)

# イベントID( EVT-20260718-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→14→…→13→11→12→13
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 18:00:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.168, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260718-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260718-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260718-host06-005 active_connections の推移](charts/EVT-20260718-host06-005.svg)

# イベントID( EVT-20260718-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→13→…→10→12→14→10
* 開始   : 2026-07-18 06:25:00 (UTC)
* 終了   : 2026-07-18 18:40:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260718-host06-006 active_connections の推移](charts/EVT-20260718-host06-006.svg)

# イベントID( EVT-20260718-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→12→13→11→…→12→13→14→13
* 開始   : 2026-07-18 06:35:00 (UTC)
* 終了   : 2026-07-18 18:45:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.838, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260718-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260718-host06-007 active_connections の推移](charts/EVT-20260718-host06-007.svg)

# イベントID( EVT-20260719-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→12→15→12→11
* 開始   : 2026-07-19 05:45:00 (UTC)
* 終了   : 2026-07-19 05:45:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→16→20→15→16
* 開始   : 2026-07-19 14:05:00 (UTC)
* 終了   : 2026-07-19 14:05:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→13→9→12→…→12→16→15→12
* 開始   : 2026-07-19 16:55:00 (UTC)
* 終了   : 2026-07-19 17:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260719-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→15→…→15→13→15→13
* 開始   : 2026-07-20 02:30:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.87から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.442, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-003 active_connections の推移](charts/EVT-20260720-host06-003.svg)

# イベントID( EVT-20260721-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→21→18→17→20→21→18
* 開始   : 2026-07-21 07:40:00 (UTC)
* 終了   : 2026-07-21 08:10:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 30 分
  - EVT-20260721-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host06-002 active_connections の推移](charts/EVT-20260721-host06-002.svg)

# イベントID( EVT-20260721-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→15→…→15→12→17→15
* 開始   : 2026-07-21 18:05:00 (UTC)
* 終了   : 2026-07-21 18:55:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260721-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→12→9→15→11
* 開始   : 2026-07-21 19:25:00 (UTC)
* 終了   : 2026-07-21 19:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→10→6→9→10
* 開始   : 2026-07-21 21:35:00 (UTC)
* 終了   : 2026-07-21 21:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→18→…→17→18→14→13
* 開始   : 2026-07-22 05:35:00 (UTC)
* 終了   : 2026-07-22 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→15→18→16→14
* 開始   : 2026-07-22 05:45:00 (UTC)
* 終了   : 2026-07-22 05:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→19→22→17→19→22→17→21
* 開始   : 2026-07-22 12:45:00 (UTC)
* 終了   : 2026-07-22 12:55:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260722-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260722-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 24→21→18→22→23
* 開始   : 2026-07-22 13:00:00 (UTC)
* 終了   : 2026-07-22 13:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→18→14→19→18
* 開始   : 2026-07-22 16:15:00 (UTC)
* 終了   : 2026-07-22 16:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.7304(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host06-011 active_connections の推移](charts/EVT-20260722-host06-011.svg)

# イベントID( EVT-20260722-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→19→13→15→16
* 開始   : 2026-07-22 17:20:00 (UTC)
* 終了   : 2026-07-22 17:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→14→9→11→14→9→13
* 開始   : 2026-07-22 19:10:00 (UTC)
* 終了   : 2026-07-22 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host06-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→7→13→11
* 開始   : 2026-07-22 20:45:00 (UTC)
* 終了   : 2026-07-22 20:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host06-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→10→5→9→10
* 開始   : 2026-07-22 21:50:00 (UTC)
* 終了   : 2026-07-22 21:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host06-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-021 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→6→12→9→10
* 開始   : 2026-07-22 23:20:00 (UTC)
* 終了   : 2026-07-22 23:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host06-021 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→13→17→12→14
* 開始   : 2026-07-23 04:45:00 (UTC)
* 終了   : 2026-07-23 04:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.5倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host06-001 active_connections の推移](charts/EVT-20260723-host06-001.svg)

# イベントID( EVT-20260723-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→9→4→6→7
* 開始   : 2026-07-23 22:55:00 (UTC)
* 終了   : 2026-07-23 22:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-084 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→13→10→7
* 開始   : 2026-07-24 01:50:00 (UTC)
* 終了   : 2026-07-24 01:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→18→22→20→18→22→20→21
* 開始   : 2026-07-24 09:05:00 (UTC)
* 終了   : 2026-07-24 09:45:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 40 分
  - EVT-20260724-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 22→21→18→22→…→22→17→20→19
* 開始   : 2026-07-24 14:35:00 (UTC)
* 終了   : 2026-07-24 15:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260724-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260724-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→16→14→12→…→12→14→17→14
* 開始   : 2026-07-24 17:25:00 (UTC)
* 終了   : 2026-07-24 17:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260724-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host06-009 active_connections の推移](charts/EVT-20260724-host06-009.svg)

# イベントID( EVT-20260724-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→12→14→13→11→12→14
* 開始   : 2026-07-24 18:30:00 (UTC)
* 終了   : 2026-07-24 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→14→10→13→13
* 開始   : 2026-07-24 18:50:00 (UTC)
* 終了   : 2026-07-24 18:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→11→6→10→12
* 開始   : 2026-07-24 21:05:00 (UTC)
* 終了   : 2026-07-24 21:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→6→3→9→…→5→10→11→7
* 開始   : 2026-07-25 01:00:00 (UTC)
* 終了   : 2026-07-25 01:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host06-001 active_connections の推移](charts/EVT-20260725-host06-001.svg)

# イベントID( EVT-20260725-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→11→…→12→10→14→11
* 開始   : 2026-07-25 04:05:00 (UTC)
* 終了   : 2026-07-25 18:40:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.819, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260725-host06-003 active_connections の推移](charts/EVT-20260725-host06-003.svg)

# イベントID( EVT-20260725-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→13→14→11
* 開始   : 2026-07-25 05:15:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260725-host06-005 active_connections の推移](charts/EVT-20260725-host06-005.svg)

# イベントID( EVT-20260725-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→13→…→11→10→12→13
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.978, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host06-006 active_connections の推移](charts/EVT-20260725-host06-006.svg)

# イベントID( EVT-20260725-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→10→13→10→13
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host06-007 active_connections の推移](charts/EVT-20260725-host06-007.svg)

# イベントID( EVT-20260725-host06-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→14→…→13→9→14→11
* 開始   : 2026-07-25 05:55:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host06-008 active_connections の推移](charts/EVT-20260725-host06-008.svg)

# イベントID( EVT-20260725-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→11→…→10→12→14→13
* 開始   : 2026-07-25 06:05:00 (UTC)
* 終了   : 2026-07-25 19:00:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.078σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260725-host06-009 active_connections の推移](charts/EVT-20260725-host06-009.svg)

# イベントID( EVT-20260727-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→4→8→7
* 開始   : 2026-07-27 23:35:00 (UTC)
* 終了   : 2026-07-27 23:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→17→20→17→17
* 開始   : 2026-07-28 06:50:00 (UTC)
* 終了   : 2026-07-28 06:50:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→17→21→16→19
* 開始   : 2026-07-28 07:25:00 (UTC)
* 終了   : 2026-07-28 07:25:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→18→13→16→16
* 開始   : 2026-07-28 17:30:00 (UTC)
* 終了   : 2026-07-28 17:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260728-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→10→5→9→10
* 開始   : 2026-07-28 21:00:00 (UTC)
* 終了   : 2026-07-28 21:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.4317(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host06-009 active_connections の推移](charts/EVT-20260728-host06-009.svg)

# イベントID( EVT-20260729-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→17→20→18→17
* 開始   : 2026-07-29 07:05:00 (UTC)
* 終了   : 2026-07-29 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 17→19→17→20→19→17→20→17→16
* 開始   : 2026-07-29 07:10:00 (UTC)
* 終了   : 2026-07-29 09:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.1 時間
  - EVT-20260729-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260729-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260729-host06-003 active_connections の推移](charts/EVT-20260729-host06-003.svg)

# イベントID( EVT-20260729-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→16→20→15→18
* 開始   : 2026-07-29 07:15:00 (UTC)
* 終了   : 2026-07-29 07:15:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→15→10→15→14
* 開始   : 2026-07-29 18:25:00 (UTC)
* 終了   : 2026-07-29 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.6522(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host06-007 active_connections の推移](charts/EVT-20260729-host06-007.svg)

# イベントID( EVT-20260729-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→13→7→12→11
* 開始   : 2026-07-29 20:20:00 (UTC)
* 終了   : 2026-07-29 20:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.5793(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host06-008 active_connections の推移](charts/EVT-20260729-host06-008.svg)

# イベントID( EVT-20260730-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→17→17→16→17→19
* 開始   : 2026-07-30 05:35:00 (UTC)
* 終了   : 2026-07-30 08:55:00 (UTC)
* 現象   : 2026-07-30 08:55:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→18→16→15
* 開始   : 2026-07-30 05:50:00 (UTC)
* 終了   : 2026-07-30 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host06-005 active_connections の推移](charts/EVT-20260730-host06-005.svg)

# イベントID( EVT-20260730-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→19→20
* 開始   : 2026-07-30 14:00:00 (UTC)
* 終了   : 2026-07-30 14:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→19→14→19→18
* 開始   : 2026-07-30 16:30:00 (UTC)
* 終了   : 2026-07-30 16:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7241(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→12→12
* 開始   : 2026-07-30 19:25:00 (UTC)
* 終了   : 2026-07-30 19:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host06-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260730-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→17→21→19→17→21→19
* 開始   : 2026-07-31 07:15:00 (UTC)
* 終了   : 2026-07-31 07:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.194σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260731-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260731-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→20→22→17→18
* 開始   : 2026-07-31 07:50:00 (UTC)
* 終了   : 2026-07-31 07:50:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→9→13→12
* 開始   : 2026-07-31 19:15:00 (UTC)
* 終了   : 2026-07-31 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-011 active_connections の推移](charts/EVT-20260731-host06-011.svg)

# イベントID( EVT-20260701-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→9→9→8→8→10→9→8→9
* 開始   : 2026-07-01 00:15:00 (UTC)
* 終了   : 2026-07-01 00:55:00 (UTC)
* 現象   : 2026-07-01 00:55:00 (UTC)を境に水準が 15.02から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.615, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→8→11→8→12→11→8→12→8
* 開始   : 2026-07-01 01:50:00 (UTC)
* 終了   : 2026-07-01 02:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→13→15→18→13→16
* 開始   : 2026-07-01 06:10:00 (UTC)
* 終了   : 2026-07-01 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→15→19→15→19→15→19→17→14
* 開始   : 2026-07-01 06:35:00 (UTC)
* 終了   : 2026-07-01 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.788σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 24→22→23→23→23→22→25→22→24
* 開始   : 2026-07-01 11:20:00 (UTC)
* 終了   : 2026-07-01 12:00:00 (UTC)
* 現象   : 2026-07-01 12:00:00 (UTC)を境に水準が 15.13から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→15→14→13→…→14→13→14→18
* 開始   : 2026-07-01 17:35:00 (UTC)
* 終了   : 2026-07-01 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→13→16→13→…→16→13→14→13
* 開始   : 2026-07-01 17:55:00 (UTC)
* 終了   : 2026-07-01 18:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-013 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260701-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→11→14→11→14→11→15→11
* 開始   : 2026-07-01 18:50:00 (UTC)
* 終了   : 2026-07-01 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260701-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→8→9→12→9→8→9
* 開始   : 2026-07-01 20:55:00 (UTC)
* 終了   : 2026-07-01 21:00:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host06-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→10→11→11
* 開始   : 2026-07-01 21:00:00 (UTC)
* 終了   : 2026-07-01 21:25:00 (UTC)
* 現象   : 2026-07-01 21:25:00 (UTC)を境に水準が 14.93から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→18→16→14→18→16→15
* 開始   : 2026-07-02 06:25:00 (UTC)
* 終了   : 2026-07-02 06:30:00 (UTC)
* 現象   : 平常時(14)に対し 1.286倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→17→21→17→21→17→21→19→20
* 開始   : 2026-07-02 08:10:00 (UTC)
* 終了   : 2026-07-02 08:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→19→18→19→18→19→21
* 開始   : 2026-07-02 14:20:00 (UTC)
* 終了   : 2026-07-02 14:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260702-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→20→22→19→20
* 開始   : 2026-07-02 15:30:00 (UTC)
* 終了   : 2026-07-02 16:30:00 (UTC)
* 現象   : 2026-07-02 16:30:00 (UTC)を境に水準が 15.06から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→15→10→9→…→9→13→9→12
* 開始   : 2026-07-02 19:30:00 (UTC)
* 終了   : 2026-07-02 19:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-019 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260702-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 6→9→11→8→11→8→11→7→8
* 開始   : 2026-07-02 23:05:00 (UTC)
* 終了   : 2026-07-02 23:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→8→11→8→11→7
* 開始   : 2026-07-03 01:10:00 (UTC)
* 終了   : 2026-07-03 01:20:00 (UTC)
* 現象   : 平常時(7.25)に対し 1.517倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.634σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260703-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→11→14→11→14→11→13
* 開始   : 2026-07-03 03:45:00 (UTC)
* 終了   : 2026-07-03 03:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→11→15→13→15→13→15→12
* 開始   : 2026-07-03 04:50:00 (UTC)
* 終了   : 2026-07-03 05:00:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→12→13→16→17→12→16
* 開始   : 2026-07-03 05:40:00 (UTC)
* 終了   : 2026-07-03 05:45:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260703-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→16→21→18→16→21→18→19
* 開始   : 2026-07-03 07:55:00 (UTC)
* 終了   : 2026-07-03 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→17→15→17→18
* 開始   : 2026-07-03 16:55:00 (UTC)
* 終了   : 2026-07-03 17:00:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→16→13→14→16→13→14→13
* 開始   : 2026-07-03 18:05:00 (UTC)
* 終了   : 2026-07-03 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→13→12→…→13→12→14→13
* 開始   : 2026-07-03 18:15:00 (UTC)
* 終了   : 2026-07-03 18:20:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→6→9→6→9→10
* 開始   : 2026-07-03 22:00:00 (UTC)
* 終了   : 2026-07-03 22:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→7→10→8→9→8→9→8→8
* 開始   : 2026-07-04 00:10:00 (UTC)
* 終了   : 2026-07-04 00:50:00 (UTC)
* 現象   : 2026-07-04 00:50:00 (UTC)を境に水準が 15.02から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260704-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 7→9→11→8→11→8→11→7→9
* 開始   : 2026-07-04 01:35:00 (UTC)
* 終了   : 2026-07-04 01:45:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260704-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260704-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host06-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→10→9→11→…→10→9→11→9
* 開始   : 2026-07-04 19:05:00 (UTC)
* 終了   : 2026-07-04 19:35:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分

![EVT-20260704-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→8→11→5→…→11→5→9→10
* 開始   : 2026-07-05 00:30:00 (UTC)
* 終了   : 2026-07-05 00:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→18→…→19→18→16→15
* 開始   : 2026-07-05 12:15:00 (UTC)
* 終了   : 2026-07-05 12:20:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.985σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→13→12→13→11→12→13→11→13
* 開始   : 2026-07-05 15:50:00 (UTC)
* 終了   : 2026-07-05 16:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→9→…→9→6→8→10
* 開始   : 2026-07-07 00:45:00 (UTC)
* 終了   : 2026-07-07 00:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→9→7→14→…→7→14→10→12
* 開始   : 2026-07-07 03:55:00 (UTC)
* 終了   : 2026-07-07 04:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→16→15→16→17→18→18
* 開始   : 2026-07-07 05:25:00 (UTC)
* 終了   : 2026-07-07 06:15:00 (UTC)
* 現象   : 2026-07-07 06:15:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→17→19→17→19→16
* 開始   : 2026-07-07 06:50:00 (UTC)
* 終了   : 2026-07-07 07:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→18→22→23→…→22→23→20→21
* 開始   : 2026-07-07 09:00:00 (UTC)
* 終了   : 2026-07-07 09:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→23→16→21→18→23→16→21→18
* 開始   : 2026-07-07 15:35:00 (UTC)
* 終了   : 2026-07-07 15:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→12→11→8→12→11→7
* 開始   : 2026-07-08 02:35:00 (UTC)
* 終了   : 2026-07-08 02:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→13→16→13→16→15
* 開始   : 2026-07-08 05:35:00 (UTC)
* 終了   : 2026-07-08 05:45:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260708-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→12→13→12→13→12→10
* 開始   : 2026-07-09 03:20:00 (UTC)
* 終了   : 2026-07-09 03:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260709-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→18→15→…→15→19→17→15
* 開始   : 2026-07-09 06:20:00 (UTC)
* 終了   : 2026-07-09 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260709-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→16→22→18→…→22→23→21→20
* 開始   : 2026-07-09 08:50:00 (UTC)
* 終了   : 2026-07-09 09:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260709-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→19→…→19→23→21→23
* 開始   : 2026-07-09 10:00:00 (UTC)
* 終了   : 2026-07-09 10:10:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→19→20→25→19→20→25→22→21
* 開始   : 2026-07-09 13:20:00 (UTC)
* 終了   : 2026-07-09 13:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 25→23→22→21→25
* 開始   : 2026-07-09 13:25:00 (UTC)
* 終了   : 2026-07-09 13:45:00 (UTC)
* 現象   : 2026-07-09 13:45:00 (UTC)を境に水準が 14.96から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.554, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→12→14→16→12→14
* 開始   : 2026-07-09 18:25:00 (UTC)
* 終了   : 2026-07-09 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260709-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→13→12→9→8→13→12→9
* 開始   : 2026-07-10 02:50:00 (UTC)
* 終了   : 2026-07-10 02:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.98σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→15→…→14→15→11→14
* 開始   : 2026-07-10 04:25:00 (UTC)
* 終了   : 2026-07-10 04:30:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→…→14→10→15→11
* 開始   : 2026-07-10 05:20:00 (UTC)
* 終了   : 2026-07-10 06:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→18→14→17
* 開始   : 2026-07-10 17:15:00 (UTC)
* 終了   : 2026-07-10 17:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260710-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→11→12→14→11→13
* 開始   : 2026-07-10 18:35:00 (UTC)
* 終了   : 2026-07-10 18:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→12→10→11→11→12→12
* 開始   : 2026-07-10 20:50:00 (UTC)
* 終了   : 2026-07-10 21:30:00 (UTC)
* 現象   : 2026-07-10 21:30:00 (UTC)を境に水準が 14.88から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→7→11→7→9→7→10→11
* 開始   : 2026-07-10 23:30:00 (UTC)
* 終了   : 2026-07-11 00:10:00 (UTC)
* 現象   : 2026-07-11 00:10:00 (UTC)を境に水準が 15.05から11.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→9→11→9→11→10
* 開始   : 2026-07-11 00:00:00 (UTC)
* 終了   : 2026-07-11 00:25:00 (UTC)
* 現象   : 2026-07-11 00:25:00 (UTC)を境に水準が 14.97から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260711-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→12→8→6→12→8→10
* 開始   : 2026-07-11 21:40:00 (UTC)
* 終了   : 2026-07-11 21:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260711-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→10→14→15→…→14→15→12→13
* 開始   : 2026-07-12 05:55:00 (UTC)
* 終了   : 2026-07-12 06:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260712-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→16→18→16→18→16→18
* 開始   : 2026-07-12 11:55:00 (UTC)
* 終了   : 2026-07-12 12:40:00 (UTC)
* 現象   : 2026-07-12 12:40:00 (UTC)を境に水準が 11.83から13.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→15→14→14→14→15→14→15→15
* 開始   : 2026-07-12 15:45:00 (UTC)
* 終了   : 2026-07-12 16:35:00 (UTC)
* 現象   : 2026-07-12 16:35:00 (UTC)を境に水準が 11.8から14.38へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.123, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→10→12→15→10→12→14
* 開始   : 2026-07-12 17:30:00 (UTC)
* 終了   : 2026-07-12 17:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→11→11→10→10→8→10→11
* 開始   : 2026-07-12 20:50:00 (UTC)
* 終了   : 2026-07-12 21:25:00 (UTC)
* 現象   : 2026-07-12 21:25:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→9→8→10→9→10→10→11
* 開始   : 2026-07-13 00:55:00 (UTC)
* 終了   : 2026-07-13 01:30:00 (UTC)
* 現象   : 2026-07-13 01:30:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→7→8→6→7→8→6→7→8
* 開始   : 2026-07-13 22:30:00 (UTC)
* 終了   : 2026-07-13 22:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260713-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→19→18→20→19→17
* 開始   : 2026-07-14 07:25:00 (UTC)
* 終了   : 2026-07-14 07:30:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→23→22→23→22→23→21→20
* 開始   : 2026-07-14 09:30:00 (UTC)
* 終了   : 2026-07-14 09:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.221倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.921σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260714-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→13→13→14→12→12→13
* 開始   : 2026-07-14 19:35:00 (UTC)
* 終了   : 2026-07-14 20:25:00 (UTC)
* 現象   : 2026-07-14 20:25:00 (UTC)を境に水準が 14.91から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.217, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→9→9→10→10→13→12
* 開始   : 2026-07-15 02:20:00 (UTC)
* 終了   : 2026-07-15 03:20:00 (UTC)
* 現象   : 2026-07-15 03:20:00 (UTC)を境に水準が 14.86から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→8→12→11→8→12→11→9
* 開始   : 2026-07-15 02:40:00 (UTC)
* 終了   : 2026-07-15 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→9→14→13→9→14→13→14
* 開始   : 2026-07-15 04:35:00 (UTC)
* 終了   : 2026-07-15 04:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→17→23→20→22→23→20→22→20
* 開始   : 2026-07-15 08:50:00 (UTC)
* 終了   : 2026-07-15 09:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.221倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.921σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260715-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 23→20→22→23→23→22→23→22
* 開始   : 2026-07-15 09:40:00 (UTC)
* 終了   : 2026-07-15 10:15:00 (UTC)
* 現象   : 2026-07-15 10:15:00 (UTC)を境に水準が 14.93から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→19→16→18→16→18→16→18→17
* 開始   : 2026-07-15 16:20:00 (UTC)
* 終了   : 2026-07-15 16:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 21→18→16→15→18→16→15→18→19
* 開始   : 2026-07-15 16:50:00 (UTC)
* 終了   : 2026-07-15 16:55:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→13→14→11→13→12→14
* 開始   : 2026-07-15 19:10:00 (UTC)
* 終了   : 2026-07-15 20:20:00 (UTC)
* 現象   : 2026-07-15 20:20:00 (UTC)を境に水準が 14.95から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→11→14→9→11→10
* 開始   : 2026-07-15 20:00:00 (UTC)
* 終了   : 2026-07-15 20:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→8→…→10→9→8→10
* 開始   : 2026-07-15 20:15:00 (UTC)
* 終了   : 2026-07-15 20:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 7→6→12→10→12→10→12→11→8
* 開始   : 2026-07-16 02:35:00 (UTC)
* 終了   : 2026-07-16 02:45:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→12→…→12→9→13→12
* 開始   : 2026-07-16 04:40:00 (UTC)
* 終了   : 2026-07-16 04:50:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260716-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260716-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→17→16→13→17→16→17
* 開始   : 2026-07-16 06:05:00 (UTC)
* 終了   : 2026-07-16 06:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→20→23→23→22→21
* 開始   : 2026-07-16 10:05:00 (UTC)
* 終了   : 2026-07-16 10:30:00 (UTC)
* 現象   : 2026-07-16 10:30:00 (UTC)を境に水準が 15から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 23→24→21→23→22→22
* 開始   : 2026-07-16 12:45:00 (UTC)
* 終了   : 2026-07-16 13:10:00 (UTC)
* 現象   : 2026-07-16 13:10:00 (UTC)を境に水準が 15.03から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→12→13→14→12→16→15
* 開始   : 2026-07-16 18:25:00 (UTC)
* 終了   : 2026-07-16 18:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→9→5→9→5→9
* 開始   : 2026-07-16 22:20:00 (UTC)
* 終了   : 2026-07-16 22:30:00 (UTC)
* 現象   : 平常時(9)に対し 0.5556(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.805σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-088 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260716-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 7→11→5→9→7→11→5→9
* 開始   : 2026-07-17 01:00:00 (UTC)
* 終了   : 2026-07-17 01:05:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→19→17→17→19→19→18→18→19
* 開始   : 2026-07-17 07:10:00 (UTC)
* 終了   : 2026-07-17 07:55:00 (UTC)
* 現象   : 2026-07-17 07:55:00 (UTC)を境に水準が 15.01から14.45へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→20→21→20→21→20→19
* 開始   : 2026-07-17 08:10:00 (UTC)
* 終了   : 2026-07-17 08:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→24→22→18→24→22→18→21
* 開始   : 2026-07-17 14:05:00 (UTC)
* 終了   : 2026-07-17 14:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→13→15→14→13→15
* 開始   : 2026-07-17 17:10:00 (UTC)
* 終了   : 2026-07-17 17:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→18→19→17→14→14
* 開始   : 2026-07-17 17:15:00 (UTC)
* 終了   : 2026-07-17 17:40:00 (UTC)
* 現象   : 2026-07-17 17:40:00 (UTC)を境に水準が 14.79から12.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→14→17→15→14→17
* 開始   : 2026-07-17 17:35:00 (UTC)
* 終了   : 2026-07-17 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260717-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→15→13→15→13→15
* 開始   : 2026-07-17 17:50:00 (UTC)
* 終了   : 2026-07-17 17:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260717-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→8→7→…→8→7→10→9
* 開始   : 2026-07-17 21:00:00 (UTC)
* 終了   : 2026-07-17 21:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-087 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→10→12→10
* 開始   : 2026-07-18 04:00:00 (UTC)
* 終了   : 2026-07-18 04:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260718-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→10→14→8→10→14→8→10→9
* 開始   : 2026-07-18 19:30:00 (UTC)
* 終了   : 2026-07-18 19:35:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260718-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→10→…→10→12→8→10
* 開始   : 2026-07-19 03:40:00 (UTC)
* 終了   : 2026-07-19 03:50:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260719-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→12→14→14→13→13
* 開始   : 2026-07-19 17:10:00 (UTC)
* 終了   : 2026-07-19 17:40:00 (UTC)
* 現象   : 2026-07-19 17:40:00 (UTC)を境に水準が 11.76から14.7へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→13→9→10→9→10→9→12
* 開始   : 2026-07-19 18:15:00 (UTC)
* 終了   : 2026-07-19 18:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host02-013 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260719-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→9→9→11→10→11→10→11→12
* 開始   : 2026-07-20 02:05:00 (UTC)
* 終了   : 2026-07-20 03:00:00 (UTC)
* 現象   : 2026-07-20 03:00:00 (UTC)を境に水準が 11.79から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→14→…→13→16→13→16
* 開始   : 2026-07-21 05:30:00 (UTC)
* 終了   : 2026-07-21 05:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260721-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260721-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→18→15→18→15→16
* 開始   : 2026-07-21 16:45:00 (UTC)
* 終了   : 2026-07-21 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260721-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→9→10→11→9→13
* 開始   : 2026-07-21 19:50:00 (UTC)
* 終了   : 2026-07-21 20:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→9→8→10→10→8
* 開始   : 2026-07-22 00:20:00 (UTC)
* 終了   : 2026-07-22 00:45:00 (UTC)
* 現象   : 2026-07-22 00:45:00 (UTC)を境に水準が 14.86から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→14→10→13→14→10→9
* 開始   : 2026-07-22 03:25:00 (UTC)
* 終了   : 2026-07-22 03:30:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→14→18→15→14→18→15→13
* 開始   : 2026-07-22 06:00:00 (UTC)
* 終了   : 2026-07-22 07:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260722-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→19→23→22→…→23→22→20→18
* 開始   : 2026-07-22 09:00:00 (UTC)
* 終了   : 2026-07-22 09:05:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.227倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.98σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→25→21→19→25→21→19→24→20
* 開始   : 2026-07-22 12:20:00 (UTC)
* 終了   : 2026-07-22 12:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→20→18→20→…→20→17→20→19
* 開始   : 2026-07-22 14:35:00 (UTC)
* 終了   : 2026-07-22 14:45:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260722-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→18→…→18→15→16→18
* 開始   : 2026-07-22 16:25:00 (UTC)
* 終了   : 2026-07-22 16:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→16→14→13→16→15
* 開始   : 2026-07-22 17:25:00 (UTC)
* 終了   : 2026-07-22 17:30:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→16→16→15→14→17→16→15→16
* 開始   : 2026-07-22 17:45:00 (UTC)
* 終了   : 2026-07-22 18:35:00 (UTC)
* 現象   : 2026-07-22 18:35:00 (UTC)を境に水準が 15.04から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→12→18→12→…→14→12→13→14
* 開始   : 2026-07-22 18:20:00 (UTC)
* 終了   : 2026-07-22 18:45:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.81σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260722-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260722-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host06-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→9→6→9→…→9→5→8→9
* 開始   : 2026-07-22 23:05:00 (UTC)
* 終了   : 2026-07-22 23:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host06-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 24→23→24
* 開始   : 2026-07-23 12:45:00 (UTC)
* 終了   : 2026-07-23 12:55:00 (UTC)
* 現象   : 2026-07-23 12:55:00 (UTC)を境に水準が 15.01から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→17→18→19→17→18→19
* 開始   : 2026-07-23 15:20:00 (UTC)
* 終了   : 2026-07-23 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260723-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→22→…→16→22→19→17
* 開始   : 2026-07-23 16:00:00 (UTC)
* 終了   : 2026-07-23 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→15→18→15→18→15→17
* 開始   : 2026-07-23 16:35:00 (UTC)
* 終了   : 2026-07-23 16:45:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→10→8→9→8→9→8→9→11
* 開始   : 2026-07-23 20:55:00 (UTC)
* 終了   : 2026-07-23 21:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-073 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260723-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→8→9→5→8→7
* 開始   : 2026-07-23 22:25:00 (UTC)
* 終了   : 2026-07-23 22:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.5505(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.863σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-082 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260723-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→13→16→13→15
* 開始   : 2026-07-24 05:20:00 (UTC)
* 終了   : 2026-07-24 05:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→18→22→23→…→22→23→22→20
* 開始   : 2026-07-24 09:15:00 (UTC)
* 終了   : 2026-07-24 09:20:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260724-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→21→25→19→…→25→19→22→23
* 開始   : 2026-07-24 13:10:00 (UTC)
* 終了   : 2026-07-24 13:15:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→17→18→19→17→18→20
* 開始   : 2026-07-24 15:40:00 (UTC)
* 終了   : 2026-07-24 15:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260724-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→16→15→16→15→16→17
* 開始   : 2026-07-24 17:00:00 (UTC)
* 終了   : 2026-07-24 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→7→11→7→…→7→12→9→8
* 開始   : 2026-07-25 01:50:00 (UTC)
* 終了   : 2026-07-25 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→11→13→11→13→11→13→11→12
* 開始   : 2026-07-25 04:20:00 (UTC)
* 終了   : 2026-07-25 04:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260725-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host06-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→7→…→7→8→10→11
* 開始   : 2026-07-25 19:50:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260725-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→15→15→14→14→18
* 開始   : 2026-07-26 15:10:00 (UTC)
* 終了   : 2026-07-26 15:40:00 (UTC)
* 現象   : 2026-07-26 15:40:00 (UTC)を境に水準が 11.7から14.25へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→15→14→12→15→16
* 開始   : 2026-07-26 15:15:00 (UTC)
* 終了   : 2026-07-26 15:20:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260726-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260726-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→7→6→8→6→8→6→8→7
* 開始   : 2026-07-26 22:35:00 (UTC)
* 終了   : 2026-07-26 22:45:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260726-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260726-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→10→11→9→11
* 開始   : 2026-07-27 21:30:00 (UTC)
* 終了   : 2026-07-27 21:50:00 (UTC)
* 現象   : 2026-07-27 21:50:00 (UTC)を境に水準が 14.83から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→8→11→11→9→10→12
* 開始   : 2026-07-28 02:15:00 (UTC)
* 終了   : 2026-07-28 04:20:00 (UTC)
* 現象   : 2026-07-28 04:20:00 (UTC)を境に水準が 14.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→23→19→20→23→19→20→23
* 開始   : 2026-07-28 13:50:00 (UTC)
* 終了   : 2026-07-28 13:55:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260728-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→24→19→18→…→19→18→20→21
* 開始   : 2026-07-28 14:25:00 (UTC)
* 終了   : 2026-07-28 14:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260728-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→10→12→10→10→11→11
* 開始   : 2026-07-28 20:15:00 (UTC)
* 終了   : 2026-07-28 21:10:00 (UTC)
* 現象   : 2026-07-28 21:10:00 (UTC)を境に水準が 14.93から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.225, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→8→12→11→8→12→11
* 開始   : 2026-07-28 20:25:00 (UTC)
* 終了   : 2026-07-28 20:30:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.6809(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→9→…→9→13→9→11
* 開始   : 2026-07-29 03:00:00 (UTC)
* 終了   : 2026-07-29 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→22→20→22→21
* 開始   : 2026-07-29 09:00:00 (UTC)
* 終了   : 2026-07-29 09:05:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260729-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→21→21→21→23
* 開始   : 2026-07-29 09:05:00 (UTC)
* 終了   : 2026-07-29 09:25:00 (UTC)
* 現象   : 2026-07-29 09:25:00 (UTC)を境に水準が 14.87から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→9→6→8→6→8→6→8→9
* 開始   : 2026-07-29 22:30:00 (UTC)
* 終了   : 2026-07-29 22:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-085 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-086 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→10→10→8→9→9→9
* 開始   : 2026-07-30 00:15:00 (UTC)
* 終了   : 2026-07-30 00:45:00 (UTC)
* 現象   : 2026-07-30 00:45:00 (UTC)を境に水準が 14.95から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.672, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 7→6→11→5→…→11→5→7→8
* 開始   : 2026-07-30 00:35:00 (UTC)
* 終了   : 2026-07-30 00:40:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→14→15→14→16→15→14→16→14
* 開始   : 2026-07-30 05:05:00 (UTC)
* 終了   : 2026-07-30 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260730-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→26→21→19→26→21→19→20→22
* 開始   : 2026-07-30 13:45:00 (UTC)
* 終了   : 2026-07-30 13:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.191倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.927σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→24→19→18→21→24→19→18→21
* 開始   : 2026-07-30 14:15:00 (UTC)
* 終了   : 2026-07-30 14:20:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260730-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→20→17→20→17→20→17
* 開始   : 2026-07-30 15:25:00 (UTC)
* 終了   : 2026-07-30 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→20→18→21→17→19→19→19
* 開始   : 2026-07-30 16:05:00 (UTC)
* 終了   : 2026-07-30 16:55:00 (UTC)
* 現象   : 2026-07-30 16:55:00 (UTC)を境に水準が 15.09から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→10→9→14→13→10→9→14→12
* 開始   : 2026-07-30 19:25:00 (UTC)
* 終了   : 2026-07-30 19:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host06-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260730-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host06-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→11→11→13→11→10→12→11
* 開始   : 2026-07-30 20:40:00 (UTC)
* 終了   : 2026-07-30 21:15:00 (UTC)
* 現象   : 2026-07-30 21:15:00 (UTC)を境に水準が 15.02から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→9→6→12→9→6→10
* 開始   : 2026-07-31 02:05:00 (UTC)
* 終了   : 2026-07-31 02:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→13→9→13→9→13→11
* 開始   : 2026-07-31 03:35:00 (UTC)
* 終了   : 2026-07-31 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→14→15→15→14→15
* 開始   : 2026-07-31 05:00:00 (UTC)
* 終了   : 2026-07-31 05:35:00 (UTC)
* 現象   : 2026-07-31 05:35:00 (UTC)を境に水準が 15.07から14.69へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→13→…→13→18→17→15
* 開始   : 2026-07-31 06:15:00 (UTC)
* 終了   : 2026-07-31 06:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→19→24→22→19→24
* 開始   : 2026-07-31 10:50:00 (UTC)
* 終了   : 2026-07-31 10:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 23→19→22→25→…→21→25→23→22
* 開始   : 2026-07-31 12:00:00 (UTC)
* 終了   : 2026-07-31 12:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260731-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→21→23
* 開始   : 2026-07-31 13:55:00 (UTC)
* 終了   : 2026-07-31 14:15:00 (UTC)
* 現象   : 2026-07-31 14:15:00 (UTC)を境に水準が 15.08から12.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→16→17→16→19
* 開始   : 2026-07-31 15:40:00 (UTC)
* 終了   : 2026-07-31 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host06-010 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
