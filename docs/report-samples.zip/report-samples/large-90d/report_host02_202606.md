# host02 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host02 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 339 (SEVERE: 26, FATAL: 131, WARN: 182, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 109 | 142 | 273 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-B4 |
| ou | 3 | 21 | 33 | 57 | ALG-A1, ALG-A4, ALG-B4 |
| eu | 1 | 0 | 0 | 1 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B2, ALG-B4 |
| mu | 0 | 0 | 7 | 7 | ALG-A4, ALG-B4 |
| fgct_delta | 0 | 1 | 0 | 1 | ALG-B2 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260601-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B2 Mann-Kendall 傾向検定, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app02, host=host02
* 値     : 2490→4441→4997→3741→3465→4063→5094→4486→3475
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 2026-08-29 23:55:00 (UTC)を境に水準が 3263から3268へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.6σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.836 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-393.3, 限界=352.7)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.778σ 外れた (平常値=4992)
             ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=68073, p=8.935e-09, Sen勾配=7.366/日)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=1282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260601-host02-001 eu の推移](charts/EVT-20260601-host02-001.svg)

# イベントID( EVT-20260603-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→10→37→42→…→12→14→12→14
* 開始   : 2026-06-03 02:35:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 2026-06-03 04:45:00 (UTC)を境に水準が 14.93から16.34へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 10.53σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 18.21 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=37)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.529, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=28.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-003 active_connections の推移](charts/EVT-20260603-host02-003.svg)

# イベントID( EVT-20260608-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→13→16→17→…→15→13→11→13
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 20:40:00 (UTC)
* 現象   : 2026-06-08 20:40:00 (UTC)を境に水準が 11.9から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-004 active_connections の推移](charts/EVT-20260608-host02-004.svg)

# イベントID( EVT-20260608-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→15→17→14→…→11→14→13→10
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.887, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-005 active_connections の推移](charts/EVT-20260608-host02-005.svg)

# イベントID( EVT-20260608-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→12→16→15→…→13→14→13→15
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 21:40:00 (UTC)
* 現象   : 2026-06-08 21:40:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.65, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-006 active_connections の推移](charts/EVT-20260608-host02-006.svg)

# イベントID( EVT-20260608-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→14→…→14→15→14→13
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 22:00:00 (UTC)
* 現象   : 2026-06-08 22:00:00 (UTC)を境に水準が 11.85から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-007 active_connections の推移](charts/EVT-20260608-host02-007.svg)

# イベントID( EVT-20260608-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.024e+04→1.035e+04→1.075e+04→1.028e+04→…→1.03e+04→1.036e+04→1.011e+04→9665
* 開始   : 2026-06-08 03:50:00 (UTC)
* 終了   : 2026-06-08 17:25:00 (UTC)
* 現象   : 2026-06-08 17:25:00 (UTC)を境に水準が 9807から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.055σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=546.4, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2137, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-008 ou の推移](charts/EVT-20260608-host02-008.svg)

# イベントID( EVT-20260608-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→15→…→14→16→13→14
* 開始   : 2026-06-08 04:15:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.85から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-009 active_connections の推移](charts/EVT-20260608-host02-009.svg)

# イベントID( EVT-20260610-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→11→35→44→…→13→12→13→14
* 開始   : 2026-06-10 02:30:00 (UTC)
* 終了   : 2026-06-10 04:50:00 (UTC)
* 現象   : 2026-06-10 04:50:00 (UTC)を境に水準が 14.92から16.35へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 9.762σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 17.54 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=35)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.845, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-001 active_connections の推移](charts/EVT-20260610-host02-001.svg)

# イベントID( EVT-20260615-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→18→15→16→…→17→13→15→13
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.96から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-001 active_connections の推移](charts/EVT-20260615-host02-001.svg)

# イベントID( EVT-20260615-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→15→…→12→14→13→12
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 11.79から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.134, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-002 active_connections の推移](charts/EVT-20260615-host02-002.svg)

# イベントID( EVT-20260615-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→18→…→17→16→13→15
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 19:10:00 (UTC)
* 現象   : 2026-06-15 19:10:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-004 active_connections の推移](charts/EVT-20260615-host02-004.svg)

# イベントID( EVT-20260615-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.043e+04→1.086e+04→1.079e+04→1.096e+04→…→1.097e+04→1.092e+04→1.027e+04→1.021e+04
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 9781から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=633.6, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2465, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-005 ou の推移](charts/EVT-20260615-host02-005.svg)

# イベントID( EVT-20260615-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→18→14→…→11→13→12→10
* 開始   : 2026-06-15 03:50:00 (UTC)
* 終了   : 2026-06-15 20:15:00 (UTC)
* 現象   : 2026-06-15 20:15:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.776, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-007 active_connections の推移](charts/EVT-20260615-host02-007.svg)

# イベントID( EVT-20260617-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→9→45→44→…→11→12→13→12
* 開始   : 2026-06-17 02:50:00 (UTC)
* 終了   : 2026-06-17 04:45:00 (UTC)
* 現象   : 2026-06-17 04:45:00 (UTC)を境に水準が 14.92から16.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 13.72σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 24.28 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=45)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.255, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=35.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-002 active_connections の推移](charts/EVT-20260617-host02-002.svg)

# イベントID( EVT-20260621-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→9→10→8→9→11→11→10→12
* 開始   : 2026-06-21 18:40:00 (UTC)
* 終了   : 2026-06-21 21:55:00 (UTC)
* 現象   : 2026-06-21 21:55:00 (UTC)を境に水準が 11.8から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host02-004 active_connections の推移](charts/EVT-20260621-host02-004.svg)

# イベントID( EVT-20260622-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→17→18→16→…→15→14→15→14
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.96から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.603, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.969, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-003 active_connections の推移](charts/EVT-20260622-host02-003.svg)

# イベントID( EVT-20260622-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→20→…→11→13→11→13
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.82から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.945σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.872, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-004 active_connections の推移](charts/EVT-20260622-host02-004.svg)

# イベントID( EVT-20260622-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→14→18→15→…→14→15→13→12
* 開始   : 2026-06-22 04:05:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.91から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.335, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-006 active_connections の推移](charts/EVT-20260622-host02-006.svg)

# イベントID( EVT-20260622-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→12→15→14→…→12→14→12→13
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 19:45:00 (UTC)
* 現象   : 2026-06-22 19:45:00 (UTC)を境に水準が 11.77から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.82, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-009 active_connections の推移](charts/EVT-20260622-host02-009.svg)

# イベントID( EVT-20260624-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→8→43→50→…→12→11→12→13
* 開始   : 2026-06-24 03:00:00 (UTC)
* 終了   : 2026-06-24 04:45:00 (UTC)
* 現象   : 2026-06-24 04:45:00 (UTC)を境に水準が 15.05から16.41へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.95σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 22.6 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=43)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.289, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=34.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host02-003 active_connections の推移](charts/EVT-20260624-host02-003.svg)

# イベントID( EVT-20260629-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→18→…→14→13→11→12
* 開始   : 2026-06-29 01:10:00 (UTC)
* 終了   : 2026-06-29 19:25:00 (UTC)
* 現象   : 2026-06-29 19:25:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.911, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-001 active_connections の推移](charts/EVT-20260629-host02-001.svg)

# イベントID( EVT-20260629-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.087e+04→1.02e+04→1.128e+04→1.072e+04→…→1.07e+04→1.029e+04→1.063e+04→1.098e+04
* 開始   : 2026-06-29 01:35:00 (UTC)
* 終了   : 2026-06-29 18:20:00 (UTC)
* 現象   : 2026-06-29 18:20:00 (UTC)を境に水準が 9776から1.022e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.166σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=581.8, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2890, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-002 ou の推移](charts/EVT-20260629-host02-002.svg)

# イベントID( EVT-20260629-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→16→15→14→…→13→12→13→12
* 開始   : 2026-06-29 02:30:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.681, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-004 active_connections の推移](charts/EVT-20260629-host02-004.svg)

# イベントID( EVT-20260629-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→14→…→13→14→13→12
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.77から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.731, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.143, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-006 active_connections の推移](charts/EVT-20260629-host02-006.svg)

# イベントID( EVT-20260629-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→13→…→11→14→13→11
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 19:20:00 (UTC)
* 現象   : 2026-06-29 19:20:00 (UTC)を境に水準が 11.93から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-007 active_connections の推移](charts/EVT-20260629-host02-007.svg)

# イベントID( EVT-20260601-host02-002 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : FATAL
* データ : jvm_gc / fgct_delta (区間 Full GC 時間) / container=app02, host=host02
* 値     : 0.04→0.04→0.04→0.04→0.04→0.04→0.04→0.04→0.04
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 90.0日で 0.04から0.04へ増加した(平均 0/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=62735, p=2.549e-08, Sen勾配=0/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host02-002 fgct_delta の推移](charts/EVT-20260601-host02-002.svg)

# イベントID( EVT-20260601-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→9→14→10→10
* 開始   : 2026-06-01 03:35:00 (UTC)
* 終了   : 2026-06-01 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9786→9436→1.087e+04→1.001e+04→9959
* 開始   : 2026-06-01 04:05:00 (UTC)
* 終了   : 2026-06-01 04:05:00 (UTC)
* 現象   : 平常時(9606)に対し 1.132倍(1.087e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.788σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host02-005 ou の推移](charts/EVT-20260601-host02-005.svg)

# イベントID( EVT-20260601-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→20→21→23→…→21→23→17→18
* 開始   : 2026-06-01 08:10:00 (UTC)
* 終了   : 2026-06-01 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host02-006 active_connections の推移](charts/EVT-20260601-host02-006.svg)

# イベントID( EVT-20260602-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→16
* 開始   : 2026-06-02 06:00:00 (UTC)
* 終了   : 2026-06-02 06:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→18→22→15→16
* 開始   : 2026-06-02 17:05:00 (UTC)
* 終了   : 2026-06-02 17:05:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→12→13
* 開始   : 2026-06-03 04:10:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.053e+04→1.046e+04→1.003e+04→1.006e+04→…→1.077e+04→9800→1.063e+04→1.035e+04
* 開始   : 2026-06-03 17:05:00 (UTC)
* 終了   : 2026-06-03 17:40:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.718σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host02-008 ou の推移](charts/EVT-20260603-host02-008.svg)

# イベントID( EVT-20260604-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→9→8→11→…→11→13→11→15
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 04:40:00 (UTC)
* 現象   : 1.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.357, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260604-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host02-003 active_connections の推移](charts/EVT-20260604-host02-003.svg)

# イベントID( EVT-20260604-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→13→14→15→15→13→18
* 開始   : 2026-06-04 04:50:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 2026-06-04 05:25:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 22→20→24→20→20
* 開始   : 2026-06-04 09:30:00 (UTC)
* 終了   : 2026-06-04 09:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→15→15
* 開始   : 2026-06-04 18:35:00 (UTC)
* 終了   : 2026-06-04 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→12→6→9→9
* 開始   : 2026-06-04 21:15:00 (UTC)
* 終了   : 2026-06-04 21:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.5255(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host02-011 active_connections の推移](charts/EVT-20260604-host02-011.svg)

# イベントID( EVT-20260605-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→9
* 開始   : 2026-06-05 02:35:00 (UTC)
* 終了   : 2026-06-05 02:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→20→…→20→25→19→22
* 開始   : 2026-06-05 09:25:00 (UTC)
* 終了   : 2026-06-05 09:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host02-005 active_connections の推移](charts/EVT-20260605-host02-005.svg)

# イベントID( EVT-20260605-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 7→9→13→7→8
* 開始   : 2026-06-05 23:40:00 (UTC)
* 終了   : 2026-06-05 23:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host02-009 active_connections の推移](charts/EVT-20260605-host02-009.svg)

# イベントID( EVT-20260606-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→6→12→8→13→12→8→13→10
* 開始   : 2026-06-06 03:10:00 (UTC)
* 終了   : 2026-06-06 03:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→13→…→13→12→14→11
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host02-002 active_connections の推移](charts/EVT-20260606-host02-002.svg)

# イベントID( EVT-20260606-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→12→…→12→11→13→12
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 17:55:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.558, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.9 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260606-host02-003 active_connections の推移](charts/EVT-20260606-host02-003.svg)

# イベントID( EVT-20260606-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→13→12→13→…→11→13→11→10
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.877, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260606-host02-004 active_connections の推移](charts/EVT-20260606-host02-004.svg)

# イベントID( EVT-20260606-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→13→11→14→…→11→12→10→12
* 開始   : 2026-06-06 06:25:00 (UTC)
* 終了   : 2026-06-06 18:25:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.852, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260606-host02-005 active_connections の推移](charts/EVT-20260606-host02-005.svg)

# イベントID( EVT-20260606-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→10→14→12→…→12→10→13→11
* 開始   : 2026-06-06 06:50:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.4 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260606-host02-006 active_connections の推移](charts/EVT-20260606-host02-006.svg)

# イベントID( EVT-20260606-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9923→1.048e+04→9314→1.024e+04→…→1.057e+04→1.04e+04→1.039e+04→1.067e+04
* 開始   : 2026-06-06 07:00:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 11.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-595.8, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.3 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間

![EVT-20260606-host02-007 ou の推移](charts/EVT-20260606-host02-007.svg)

# イベントID( EVT-20260606-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→7→12→11→…→11→3→10→7
* 開始   : 2026-06-06 21:00:00 (UTC)
* 終了   : 2026-06-06 21:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260606-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260606-host02-010 active_connections の推移](charts/EVT-20260606-host02-010.svg)

# イベントID( EVT-20260606-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9542→9637→8364→9263→9862
* 開始   : 2026-06-06 23:00:00 (UTC)
* 終了   : 2026-06-06 23:00:00 (UTC)
* 現象   : 平常時(9422)に対し 0.8877(8364)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→10
* 開始   : 2026-06-06 23:55:00 (UTC)
* 終了   : 2026-06-07 00:00:00 (UTC)
* 現象   : 2026-06-07 00:00:00 (UTC)を境に水準が 11.76から11.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.024σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260606-host02-012 active_connections の推移](charts/EVT-20260606-host02-012.svg)

# イベントID( EVT-20260607-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→11→…→11→17→15→12
* 開始   : 2026-06-07 07:30:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260607-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→12→14
* 開始   : 2026-06-07 17:25:00 (UTC)
* 終了   : 2026-06-07 17:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.002e+04→9824→8756→9089→9515
* 開始   : 2026-06-08 21:25:00 (UTC)
* 終了   : 2026-06-08 21:25:00 (UTC)
* 現象   : 平常時(9802)に対し 0.8933(8756)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.126σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9826→9334→1.028e+04→1.06e+04→…→1.028e+04→1.06e+04→9494→9867
* 開始   : 2026-06-09 03:40:00 (UTC)
* 終了   : 2026-06-09 03:45:00 (UTC)
* 現象   : 平常時(9505)に対し 1.081倍(1.028e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.304σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→18→14→15→16→18→14→15→16
* 開始   : 2026-06-09 17:05:00 (UTC)
* 終了   : 2026-06-09 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→15→12→13→11→17→15→15→15
* 開始   : 2026-06-10 04:00:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 2026-06-10 05:10:00 (UTC)を境に水準が 14.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9946→9794→9123→9934→…→9934→1.075e+04→1.021e+04→1.003e+04
* 開始   : 2026-06-10 04:40:00 (UTC)
* 終了   : 2026-06-10 04:50:00 (UTC)
* 現象   : 平常時(9806)に対し 0.9304(9123)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→17→18
* 開始   : 2026-06-10 07:50:00 (UTC)
* 終了   : 2026-06-10 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→22→21→24→22→21→24→19→20
* 開始   : 2026-06-10 09:15:00 (UTC)
* 終了   : 2026-06-10 09:25:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→22→20
* 開始   : 2026-06-10 10:05:00 (UTC)
* 終了   : 2026-06-10 10:05:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→20→16→19→20
* 開始   : 2026-06-10 15:15:00 (UTC)
* 終了   : 2026-06-10 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→13→18→15→13→18→15→16→17
* 開始   : 2026-06-10 17:00:00 (UTC)
* 終了   : 2026-06-10 17:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.6996(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.894σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host02-011 active_connections の推移](charts/EVT-20260610-host02-011.svg)

# イベントID( EVT-20260611-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 7→7→12→9→9
* 開始   : 2026-06-11 02:10:00 (UTC)
* 終了   : 2026-06-11 02:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→12→11→12→…→12→14→12→11
* 開始   : 2026-06-11 03:05:00 (UTC)
* 終了   : 2026-06-11 04:35:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-10.07, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host02-002 active_connections の推移](charts/EVT-20260611-host02-002.svg)

# イベントID( EVT-20260611-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→13→12→…→12→15→12→9
* 開始   : 2026-06-11 03:30:00 (UTC)
* 終了   : 2026-06-11 03:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260611-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→16→18→20→…→18→20→17→18
* 開始   : 2026-06-11 07:00:00 (UTC)
* 終了   : 2026-06-11 07:40:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→19→23→20→20
* 開始   : 2026-06-12 08:50:00 (UTC)
* 終了   : 2026-06-12 08:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.249σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 22→21→26→21→21
* 開始   : 2026-06-12 12:20:00 (UTC)
* 終了   : 2026-06-12 12:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→7→12→12
* 開始   : 2026-06-12 20:10:00 (UTC)
* 終了   : 2026-06-12 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-008 active_connections の推移](charts/EVT-20260612-host02-008.svg)

# イベントID( EVT-20260612-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→13→8→9→…→8→9→12→10
* 開始   : 2026-06-12 20:15:00 (UTC)
* 終了   : 2026-06-12 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→8→9→6→8→9
* 開始   : 2026-06-12 21:50:00 (UTC)
* 終了   : 2026-06-12 21:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260612-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→10→…→12→14→12→10
* 開始   : 2026-06-13 04:25:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.174, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間

![EVT-20260613-host02-002 active_connections の推移](charts/EVT-20260613-host02-002.svg)

# イベントID( EVT-20260613-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→11→…→11→9→10→11
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.07, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間

![EVT-20260613-host02-003 active_connections の推移](charts/EVT-20260613-host02-003.svg)

# イベントID( EVT-20260613-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→9→11→9→…→9→10→11→10
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host02-004 active_connections の推移](charts/EVT-20260613-host02-004.svg)

# イベントID( EVT-20260613-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→11→…→14→12→11→14
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:05:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.669σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host02-005 active_connections の推移](charts/EVT-20260613-host02-005.svg)

# イベントID( EVT-20260613-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→8→…→12→14→12→9
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.553σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host02-006 active_connections の推移](charts/EVT-20260613-host02-006.svg)

# イベントID( EVT-20260613-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.026e+04→1.036e+04→1.004e+04→1.034e+04→…→9964→1.02e+04→1.049e+04→1.005e+04
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 17:45:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-532, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260613-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9998→9296→8400→1.015e+04→…→8400→1.015e+04→9435→9513
* 開始   : 2026-06-13 21:00:00 (UTC)
* 終了   : 2026-06-13 21:05:00 (UTC)
* 現象   : 平常時(9540)に対し 0.8805(8400)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.407σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260613-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→17→14→17→…→11→14→10→9
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 20:05:00 (UTC)
* 現象   : 2026-06-15 20:05:00 (UTC)を境に水準が 11.8から15.16へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.781, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→18→15→18→17
* 開始   : 2026-06-16 16:15:00 (UTC)
* 終了   : 2026-06-16 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→15→10→13→14
* 開始   : 2026-06-16 18:05:00 (UTC)
* 終了   : 2026-06-16 18:05:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6218(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host02-008 active_connections の推移](charts/EVT-20260616-host02-008.svg)

# イベントID( EVT-20260616-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→10→6→10→9
* 開始   : 2026-06-16 21:40:00 (UTC)
* 終了   : 2026-06-16 21:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→14→17
* 開始   : 2026-06-17 06:20:00 (UTC)
* 終了   : 2026-06-17 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.371倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.777σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-007 active_connections の推移](charts/EVT-20260617-host02-007.svg)

# イベントID( EVT-20260617-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→18→23→16→19
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 08:45:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-010 active_connections の推移](charts/EVT-20260617-host02-010.svg)

# イベントID( EVT-20260617-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.171e+04→1.201e+04→1.181e+04→1.143e+04→1.127e+04
* 開始   : 2026-06-17 10:10:00 (UTC)
* 終了   : 2026-06-17 11:20:00 (UTC)
* 現象   : 2026-06-17 11:20:00 (UTC)を境に水準が 1.023e+04から1.028e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2131, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→13→8→14→13
* 開始   : 2026-06-17 19:25:00 (UTC)
* 終了   : 2026-06-17 19:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.719σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-013 active_connections の推移](charts/EVT-20260617-host02-013.svg)

# イベントID( EVT-20260617-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→8→9
* 開始   : 2026-06-17 21:15:00 (UTC)
* 終了   : 2026-06-17 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→9→9
* 開始   : 2026-06-18 02:30:00 (UTC)
* 終了   : 2026-06-18 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→10→…→10→13→12→11
* 開始   : 2026-06-18 03:00:00 (UTC)
* 終了   : 2026-06-18 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.439, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host02-003 active_connections の推移](charts/EVT-20260618-host02-003.svg)

# イベントID( EVT-20260618-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9751→1.013e+04→9908→9410→1.054e+04
* 開始   : 2026-06-18 03:05:00 (UTC)
* 終了   : 2026-06-18 03:25:00 (UTC)
* 現象   : 2026-06-18 03:25:00 (UTC)を境に水準が 1.027e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.059σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2550, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→12→15→10→10
* 開始   : 2026-06-18 03:40:00 (UTC)
* 終了   : 2026-06-18 03:40:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.597σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host02-005 active_connections の推移](charts/EVT-20260618-host02-005.svg)

# イベントID( EVT-20260618-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→18→23→19→20
* 開始   : 2026-06-18 08:50:00 (UTC)
* 終了   : 2026-06-18 08:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→17→18
* 開始   : 2026-06-18 16:25:00 (UTC)
* 終了   : 2026-06-18 16:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→16→11→13→16→11→15
* 開始   : 2026-06-18 17:55:00 (UTC)
* 終了   : 2026-06-18 18:05:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→13→9→12→12
* 開始   : 2026-06-18 19:30:00 (UTC)
* 終了   : 2026-06-18 19:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→9→10
* 開始   : 2026-06-18 21:10:00 (UTC)
* 終了   : 2026-06-18 21:10:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host02-015 active_connections の推移](charts/EVT-20260618-host02-015.svg)

# イベントID( EVT-20260619-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→7→3→8→8
* 開始   : 2026-06-19 01:10:00 (UTC)
* 終了   : 2026-06-19 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 0.4(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→12→12
* 開始   : 2026-06-19 03:15:00 (UTC)
* 終了   : 2026-06-19 03:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→11→15→13→10
* 開始   : 2026-06-19 04:20:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→18→22→18→18
* 開始   : 2026-06-19 07:40:00 (UTC)
* 終了   : 2026-06-19 07:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.313倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.655σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host02-006 active_connections の推移](charts/EVT-20260619-host02-006.svg)

# イベントID( EVT-20260619-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→17→22→20→17
* 開始   : 2026-06-19 08:05:00 (UTC)
* 終了   : 2026-06-19 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-007 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→15→15→15→14→15→14→13→15
* 開始   : 2026-06-19 16:50:00 (UTC)
* 終了   : 2026-06-19 19:10:00 (UTC)
* 現象   : 2026-06-19 19:10:00 (UTC)を境に水準が 14.9から12.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→14→13
* 開始   : 2026-06-19 19:05:00 (UTC)
* 終了   : 2026-06-19 19:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→10→6→8→9
* 開始   : 2026-06-19 21:25:00 (UTC)
* 終了   : 2026-06-19 21:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 7→8→5→8→7
* 開始   : 2026-06-19 22:15:00 (UTC)
* 終了   : 2026-06-19 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→11→…→10→9→11→9
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.361, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host02-001 active_connections の推移](charts/EVT-20260620-host02-001.svg)

# イベントID( EVT-20260620-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→10→…→14→15→14→15
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.33, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.7 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host02-002 active_connections の推移](charts/EVT-20260620-host02-002.svg)

# イベントID( EVT-20260620-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→12→…→9→11→12→10
* 開始   : 2026-06-20 05:45:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.3 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host02-003 active_connections の推移](charts/EVT-20260620-host02-003.svg)

# イベントID( EVT-20260620-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→12→…→12→9→12→11
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.743, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host02-004 active_connections の推移](charts/EVT-20260620-host02-004.svg)

# イベントID( EVT-20260620-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→12→…→12→14→15→13
* 開始   : 2026-06-20 06:20:00 (UTC)
* 終了   : 2026-06-20 18:40:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.814, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260620-host02-005 active_connections の推移](charts/EVT-20260620-host02-005.svg)

# イベントID( EVT-20260620-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9752→9806→9897→1.012e+04→…→1.03e+04→1.021e+04→1.023e+04→1.08e+04
* 開始   : 2026-06-20 07:30:00 (UTC)
* 終了   : 2026-06-20 18:50:00 (UTC)
* 現象   : 11.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.062σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-552.3, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.7 時間
  - EVT-20260620-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間

![EVT-20260620-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9723→9243→1.044e+04→9082→9928
* 開始   : 2026-06-20 20:55:00 (UTC)
* 終了   : 2026-06-20 20:55:00 (UTC)
* 現象   : 平常時(9390)に対し 1.112倍(1.044e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260620-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→9→4→8→7
* 開始   : 2026-06-20 22:25:00 (UTC)
* 終了   : 2026-06-20 22:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.4248(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.778σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→9→4→7→9
* 開始   : 2026-06-21 01:20:00 (UTC)
* 終了   : 2026-06-21 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.081e+04→1.004e+04→1.107e+04→1.101e+04→…→1.075e+04→9787→9609→9636
* 開始   : 2026-06-22 04:10:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 9782から1.027e+04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=527, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2307, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→14→13→15→…→16→13→12→14
* 開始   : 2026-06-22 04:15:00 (UTC)
* 終了   : 2026-06-22 19:50:00 (UTC)
* 現象   : 2026-06-22 19:50:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.712, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→13→16→11→12
* 開始   : 2026-06-23 04:25:00 (UTC)
* 終了   : 2026-06-23 04:25:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→14→15
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 06:30:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→22→17→21→22
* 開始   : 2026-06-23 14:25:00 (UTC)
* 終了   : 2026-06-23 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→12→10→12→10→12→10→12
* 開始   : 2026-06-23 18:50:00 (UTC)
* 終了   : 2026-06-23 19:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.6102(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-015 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260623-host02-014 active_connections の推移](charts/EVT-20260623-host02-014.svg)

# イベントID( EVT-20260623-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9663→9956→8902→9215→…→8902→9215→9576→9707
* 開始   : 2026-06-23 19:40:00 (UTC)
* 終了   : 2026-06-23 19:45:00 (UTC)
* 現象   : 平常時(1.007e+04)に対し 0.8839(8902)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host02-015 ou の推移](charts/EVT-20260623-host02-015.svg)

# イベントID( EVT-20260624-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→10→13→8→7
* 開始   : 2026-06-24 02:20:00 (UTC)
* 終了   : 2026-06-24 02:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8967→9271→1.031e+04→9611→9876
* 開始   : 2026-06-24 03:05:00 (UTC)
* 終了   : 2026-06-24 03:05:00 (UTC)
* 現象   : 平常時(9278)に対し 1.111倍(1.031e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→11→17→15→15
* 開始   : 2026-06-24 05:30:00 (UTC)
* 終了   : 2026-06-24 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→13→14
* 開始   : 2026-06-24 05:55:00 (UTC)
* 終了   : 2026-06-24 05:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→20→16→18
* 開始   : 2026-06-24 06:55:00 (UTC)
* 終了   : 2026-06-24 06:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.051e+04→1.112e+04→1.028e+04→1.041e+04→…→1.041e+04→1.189e+04→1.094e+04→1.055e+04
* 開始   : 2026-06-24 15:25:00 (UTC)
* 終了   : 2026-06-24 15:35:00 (UTC)
* 現象   : 平常時(1.099e+04)に対し 0.9358(1.028e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→13→10→13→13
* 開始   : 2026-06-24 19:10:00 (UTC)
* 終了   : 2026-06-24 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→10→…→11→15→14→13
* 開始   : 2026-06-25 03:00:00 (UTC)
* 終了   : 2026-06-25 04:30:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.701, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260625-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host02-002 active_connections の推移](charts/EVT-20260625-host02-002.svg)

# イベントID( EVT-20260625-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→11→15→12→10
* 開始   : 2026-06-25 04:05:00 (UTC)
* 終了   : 2026-06-25 04:05:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260625-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→12→16→15→12→16→15
* 開始   : 2026-06-25 04:55:00 (UTC)
* 終了   : 2026-06-25 05:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 21→20→16→21→21
* 開始   : 2026-06-25 15:05:00 (UTC)
* 終了   : 2026-06-25 15:05:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→14→12
* 開始   : 2026-06-25 18:55:00 (UTC)
* 終了   : 2026-06-25 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→13→10→12→16
* 開始   : 2026-06-25 19:10:00 (UTC)
* 終了   : 2026-06-25 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→13→11
* 開始   : 2026-06-26 04:00:00 (UTC)
* 終了   : 2026-06-26 04:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host02-003 active_connections の推移](charts/EVT-20260626-host02-003.svg)

# イベントID( EVT-20260626-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→21→16→20→21
* 開始   : 2026-06-26 14:40:00 (UTC)
* 終了   : 2026-06-26 14:40:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.7529(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host02-010 active_connections の推移](charts/EVT-20260626-host02-010.svg)

# イベントID( EVT-20260626-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→19→15→21→20
* 開始   : 2026-06-26 15:45:00 (UTC)
* 終了   : 2026-06-26 15:45:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→13→9→11→13
* 開始   : 2026-06-26 19:30:00 (UTC)
* 終了   : 2026-06-26 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9684→8758→1.047e+04→9319→9758
* 開始   : 2026-06-27 03:35:00 (UTC)
* 終了   : 2026-06-27 03:35:00 (UTC)
* 現象   : 平常時(9348)に対し 1.12倍(1.047e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260627-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→10→…→9→10→11→9
* 開始   : 2026-06-27 05:05:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260627-host02-003 active_connections の推移](charts/EVT-20260627-host02-003.svg)

# イベントID( EVT-20260627-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→14→…→12→11→12→11
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.005, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host02-004 active_connections の推移](charts/EVT-20260627-host02-004.svg)

# イベントID( EVT-20260627-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→10→…→12→16→11→12
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.722, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.2 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260627-host02-005 active_connections の推移](charts/EVT-20260627-host02-005.svg)

# イベントID( EVT-20260627-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→11→…→13→11→15→10
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.249σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.827, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260627-host02-006 active_connections の推移](charts/EVT-20260627-host02-006.svg)

# イベントID( EVT-20260627-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→9→…→12→10→12→10
* 開始   : 2026-06-27 06:45:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.152, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260627-host02-007 active_connections の推移](charts/EVT-20260627-host02-007.svg)

# イベントID( EVT-20260627-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9589→9762→9956→9619→…→9795→1.022e+04→1.005e+04→1.058e+04
* 開始   : 2026-06-27 06:55:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-552.2, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→13→13
* 開始   : 2026-06-28 18:00:00 (UTC)
* 終了   : 2026-06-28 18:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→11→5→8→8
* 開始   : 2026-06-28 22:15:00 (UTC)
* 終了   : 2026-06-28 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→13→…→13→14→13→11
* 開始   : 2026-06-29 03:55:00 (UTC)
* 終了   : 2026-06-29 20:40:00 (UTC)
* 現象   : 2026-06-29 20:40:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.371, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→11→12
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 03:25:00 (UTC)
* 現象   : 2026-06-30 03:25:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→9→15→9→11
* 開始   : 2026-06-30 03:40:00 (UTC)
* 終了   : 2026-06-30 03:40:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→10→11
* 開始   : 2026-06-30 03:45:00 (UTC)
* 終了   : 2026-06-30 03:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.365σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9854→9485→1.078e+04→1.008e+04→1.028e+04
* 開始   : 2026-06-30 04:20:00 (UTC)
* 終了   : 2026-06-30 04:20:00 (UTC)
* 現象   : 平常時(9596)に対し 1.123倍(1.078e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host02-005 ou の推移](charts/EVT-20260630-host02-005.svg)

# イベントID( EVT-20260630-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→14→20→16→16
* 開始   : 2026-06-30 06:40:00 (UTC)
* 終了   : 2026-06-30 06:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.307σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→19→23→20→21
* 開始   : 2026-06-30 08:35:00 (UTC)
* 終了   : 2026-06-30 08:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.102e+04→1.12e+04→9961→1.14e+04→1.105e+04
* 開始   : 2026-06-30 15:00:00 (UTC)
* 終了   : 2026-06-30 15:00:00 (UTC)
* 現象   : 平常時(1.098e+04)に対し 0.9073(9961)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→10→6→5→…→6→5→9→8
* 開始   : 2026-06-01 00:45:00 (UTC)
* 終了   : 2026-06-01 00:50:00 (UTC)
* 現象   : 平常時(9.111)に対し 0.6585(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.174σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.092e+04→1.114e+04→1.194e+04→1.1e+04→…→1.1e+04→1.048e+04→1.129e+04→1.09e+04
* 開始   : 2026-06-01 11:20:00 (UTC)
* 終了   : 2026-06-01 11:30:00 (UTC)
* 現象   : 平常時(1.114e+04)に対し 1.072倍(1.194e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.088e+04→1.094e+04→1.045e+04→1.173e+04→…→1.045e+04→1.173e+04→1.121e+04→1.141e+04
* 開始   : 2026-06-01 13:55:00 (UTC)
* 終了   : 2026-06-01 14:00:00 (UTC)
* 現象   : 平常時(1.113e+04)に対し 0.939(1.045e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→12→11→13→…→13→10→14→11
* 開始   : 2026-06-01 19:15:00 (UTC)
* 終了   : 2026-06-01 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9507→9365→1.052e+04→1.052e+04→…→1.052e+04→1.052e+04→1.003e+04→1.002e+04
* 開始   : 2026-06-02 04:15:00 (UTC)
* 終了   : 2026-06-02 04:20:00 (UTC)
* 現象   : 平常時(9629)に対し 1.093倍(1.052e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→13→16→13→16→14→16
* 開始   : 2026-06-02 05:10:00 (UTC)
* 終了   : 2026-06-02 05:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260602-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260602-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→18→19→15→…→15→20→17→16
* 開始   : 2026-06-02 07:10:00 (UTC)
* 終了   : 2026-06-02 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→21→22→21→22→20
* 開始   : 2026-06-02 09:05:00 (UTC)
* 終了   : 2026-06-02 09:10:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→20→17→20→17→19→20
* 開始   : 2026-06-02 15:35:00 (UTC)
* 終了   : 2026-06-02 15:45:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→13→13→15→16→14→14→15→12
* 開始   : 2026-06-02 18:55:00 (UTC)
* 終了   : 2026-06-02 20:25:00 (UTC)
* 現象   : 2026-06-02 20:25:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.314, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→12→9→10→12→9→10
* 開始   : 2026-06-02 20:20:00 (UTC)
* 終了   : 2026-06-02 20:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-017 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9574→9010→1.015e+04→9430→…→9430→1.004e+04→9725→9410
* 開始   : 2026-06-03 02:05:00 (UTC)
* 終了   : 2026-06-03 02:15:00 (UTC)
* 現象   : 平常時(9188)に対し 1.104倍(1.015e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→12→10→12→10→8
* 開始   : 2026-06-03 02:25:00 (UTC)
* 終了   : 2026-06-03 02:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→12→14→13→13→13→12→11→15
* 開始   : 2026-06-03 03:50:00 (UTC)
* 終了   : 2026-06-03 04:35:00 (UTC)
* 現象   : 2026-06-03 04:35:00 (UTC)を境に水準が 14.99から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.578, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→17→18→17→19→18→17→19→17
* 開始   : 2026-06-03 06:25:00 (UTC)
* 終了   : 2026-06-03 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→19→16→19→16→17→19
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:35:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→17→13→14→17→13→15
* 開始   : 2026-06-03 17:25:00 (UTC)
* 終了   : 2026-06-03 17:35:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→15→14→14→14→13→15
* 開始   : 2026-06-03 18:20:00 (UTC)
* 終了   : 2026-06-03 19:00:00 (UTC)
* 現象   : 2026-06-03 19:00:00 (UTC)を境に水準が 15.01から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.02e+04→1.011e+04→9309→9430→…→9309→9430→1.023e+04→9762
* 開始   : 2026-06-03 19:00:00 (UTC)
* 終了   : 2026-06-03 19:05:00 (UTC)
* 現象   : 平常時(1.019e+04)に対し 0.9137(9309)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9906→9481→9746→9935→9616→9650→1.02e+04
* 開始   : 2026-06-03 21:05:00 (UTC)
* 終了   : 2026-06-03 21:35:00 (UTC)
* 現象   : 2026-06-03 21:35:00 (UTC)を境に水準が 1.025e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2387, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→8→9→8→10
* 開始   : 2026-06-03 23:15:00 (UTC)
* 終了   : 2026-06-03 23:35:00 (UTC)
* 現象   : 2026-06-03 23:35:00 (UTC)を境に水準が 16.34から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host02-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→9→10→9
* 開始   : 2026-06-03 23:50:00 (UTC)
* 終了   : 2026-06-04 00:15:00 (UTC)
* 現象   : 2026-06-04 00:15:00 (UTC)を境に水準が 14.92から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→10→10→9→10→10→10→11
* 開始   : 2026-06-04 02:05:00 (UTC)
* 終了   : 2026-06-04 02:40:00 (UTC)
* 現象   : 2026-06-04 02:40:00 (UTC)を境に水準が 15.01から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9543→9387→9425→9816→1.021e+04→9713→1.014e+04→1.015e+04
* 開始   : 2026-06-04 02:35:00 (UTC)
* 終了   : 2026-06-04 03:10:00 (UTC)
* 現象   : 2026-06-04 03:10:00 (UTC)を境に水準が 1.023e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2356, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→12→14→11→14→11→14→11
* 開始   : 2026-06-04 04:00:00 (UTC)
* 終了   : 2026-06-04 04:10:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→18→…→20→21→19→20
* 開始   : 2026-06-04 08:05:00 (UTC)
* 終了   : 2026-06-04 08:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 24→23→22→22→24→23→23→23→23
* 開始   : 2026-06-04 11:45:00 (UTC)
* 終了   : 2026-06-04 13:00:00 (UTC)
* 現象   : 2026-06-04 13:00:00 (UTC)を境に水準が 15.16から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→11→12→14→11→14→13
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 19:00:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9831→9577→9119→9347→9677→9344
* 開始   : 2026-06-04 22:20:00 (UTC)
* 終了   : 2026-06-04 23:55:00 (UTC)
* 現象   : 2026-06-04 23:55:00 (UTC)を境に水準が 1.022e+04から1.022e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2120, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→9→11→8→12→9→12
* 開始   : 2026-06-05 01:15:00 (UTC)
* 終了   : 2026-06-05 01:45:00 (UTC)
* 現象   : 2026-06-05 01:45:00 (UTC)を境に水準が 15.07から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→16→19→16→19→16→17
* 開始   : 2026-06-05 06:35:00 (UTC)
* 終了   : 2026-06-05 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.149e+04→1.107e+04→1.083e+04→1.102e+04→1.121e+04→1.089e+04→1.11e+04→1.084e+04→1.1e+04
* 開始   : 2026-06-05 08:30:00 (UTC)
* 終了   : 2026-06-05 09:25:00 (UTC)
* 現象   : 2026-06-05 09:25:00 (UTC)を境に水準が 1.023e+04から1.009e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 23→24→21→23→23→21→22→20→23
* 開始   : 2026-06-05 12:25:00 (UTC)
* 終了   : 2026-06-05 14:15:00 (UTC)
* 現象   : 2026-06-05 14:15:00 (UTC)を境に水準が 15.01から12.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.721, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.068e+04→1.054e+04→9916→1.085e+04→…→1.085e+04→9817→1.092e+04→1.029e+04
* 開始   : 2026-06-05 16:15:00 (UTC)
* 終了   : 2026-06-05 16:25:00 (UTC)
* 現象   : 平常時(1.084e+04)に対し 0.9149(9916)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.756σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→16→17→15→16→17
* 開始   : 2026-06-05 16:50:00 (UTC)
* 終了   : 2026-06-05 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→13→…→16→15→16→15
* 開始   : 2026-06-06 08:10:00 (UTC)
* 終了   : 2026-06-06 16:55:00 (UTC)
* 現象   : 8.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.584, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.8 時間
  - EVT-20260606-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 8.8 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.8 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間

![EVT-20260606-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2486→2507→2458→2518→…→2458→2518→2504→2535
* 開始   : 2026-06-06 12:35:00 (UTC)
* 終了   : 2026-06-06 12:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2458)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-60.49, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260606-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260606-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→13→11→13→11→13→9→8
* 開始   : 2026-06-07 03:15:00 (UTC)
* 終了   : 2026-06-07 03:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260607-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9314→9812→8866→9028→…→8866→9028→1.009e+04→9472
* 開始   : 2026-06-07 06:05:00 (UTC)
* 終了   : 2026-06-07 06:10:00 (UTC)
* 現象   : 平常時(9781)に対し 0.9064(8866)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→16→18→16→18→14→15
* 開始   : 2026-06-07 09:30:00 (UTC)
* 終了   : 2026-06-07 09:40:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→15→17→15→17→15→17
* 開始   : 2026-06-07 10:50:00 (UTC)
* 終了   : 2026-06-07 11:20:00 (UTC)
* 現象   : 2026-06-07 11:20:00 (UTC)を境に水準が 11.87から13.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→17→16→15→17→17→17
* 開始   : 2026-06-07 11:35:00 (UTC)
* 終了   : 2026-06-07 12:05:00 (UTC)
* 現象   : 2026-06-07 12:05:00 (UTC)を境に水準が 11.84から13.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→16→12→18→15→16→12→18→15
* 開始   : 2026-06-07 12:20:00 (UTC)
* 終了   : 2026-06-07 12:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→15→12→16→…→16→18→17→16
* 開始   : 2026-06-07 13:00:00 (UTC)
* 終了   : 2026-06-07 13:10:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→16→16→15→15→16→14→15→16
* 開始   : 2026-06-07 15:55:00 (UTC)
* 終了   : 2026-06-07 17:55:00 (UTC)
* 現象   : 2026-06-07 17:55:00 (UTC)を境に水準が 11.88から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→11→…→11→14→12→9
* 開始   : 2026-06-07 18:40:00 (UTC)
* 終了   : 2026-06-07 18:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260607-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→8→9→11→8→10→10→9→10
* 開始   : 2026-06-07 21:55:00 (UTC)
* 終了   : 2026-06-07 22:35:00 (UTC)
* 現象   : 2026-06-07 22:35:00 (UTC)を境に水準が 11.79から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.501, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 7→8→5→7→8→5→7→9
* 開始   : 2026-06-07 23:25:00 (UTC)
* 終了   : 2026-06-07 23:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→11→10→11
* 開始   : 2026-06-08 01:55:00 (UTC)
* 終了   : 2026-06-08 02:25:00 (UTC)
* 現象   : 2026-06-08 02:25:00 (UTC)を境に水準が 11.75から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→22→20→19→…→17→19→20→18
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 21:10:00 (UTC)
* 現象   : 2026-06-08 21:10:00 (UTC)を境に水準が 11.85から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.489, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9926→9284→1.012e+04→9311→9853
* 開始   : 2026-06-08 02:20:00 (UTC)
* 終了   : 2026-06-08 02:40:00 (UTC)
* 現象   : 2026-06-08 02:40:00 (UTC)を境に水準が 9793から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2547→2508→2549→2580→2554→2545→2557→2531→2555
* 開始   : 2026-06-08 06:55:00 (UTC)
* 終了   : 2026-06-08 14:10:00 (UTC)
* 現象   : 2026-06-08 14:10:00 (UTC)を境に水準が 2484から2499へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=51.43, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=260.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.002e+04→1.013e+04→9785→1.001e+04→1.013e+04→9802→1.006e+04→1.038e+04→1.024e+04
* 開始   : 2026-06-08 18:45:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 1.021e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=573.1, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2221, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→16→15→18→16→15
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→19→21→20→21→20→21→19→18
* 開始   : 2026-06-09 07:45:00 (UTC)
* 終了   : 2026-06-09 07:55:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→23→24→21→…→20→18→21→19
* 開始   : 2026-06-09 14:10:00 (UTC)
* 終了   : 2026-06-09 14:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→18→16→18→16→17→21
* 開始   : 2026-06-09 16:20:00 (UTC)
* 終了   : 2026-06-09 16:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→15→13→15→14
* 開始   : 2026-06-09 17:50:00 (UTC)
* 終了   : 2026-06-09 17:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→11→15→16→15→11→15→16→15
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260610-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 22→23→24→22→22→22→20→23→23
* 開始   : 2026-06-10 12:00:00 (UTC)
* 終了   : 2026-06-10 12:55:00 (UTC)
* 現象   : 2026-06-10 12:55:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.094e+04→1.121e+04→1.113e+04→1.105e+04→1.164e+04
* 開始   : 2026-06-10 15:45:00 (UTC)
* 終了   : 2026-06-10 16:05:00 (UTC)
* 現象   : 2026-06-10 16:05:00 (UTC)を境に水準が 1.026e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2136, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→14→…→14→11→15→13
* 開始   : 2026-06-10 18:15:00 (UTC)
* 終了   : 2026-06-10 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→16→14→16→14→16→13
* 開始   : 2026-06-11 05:05:00 (UTC)
* 終了   : 2026-06-11 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→21→22→19→21→22→19→21
* 開始   : 2026-06-11 08:40:00 (UTC)
* 終了   : 2026-06-11 08:45:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→22→21→20→19→24→21→22→22
* 開始   : 2026-06-11 09:40:00 (UTC)
* 終了   : 2026-06-11 10:40:00 (UTC)
* 現象   : 2026-06-11 10:40:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→23→22→22→22→24→21→22→23
* 開始   : 2026-06-11 13:30:00 (UTC)
* 終了   : 2026-06-11 14:10:00 (UTC)
* 現象   : 2026-06-11 14:10:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→19→20→19→19
* 開始   : 2026-06-11 16:10:00 (UTC)
* 終了   : 2026-06-11 16:30:00 (UTC)
* 現象   : 2026-06-11 16:30:00 (UTC)を境に水準が 15.04から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→16→15→16→15→16→17
* 開始   : 2026-06-11 16:40:00 (UTC)
* 終了   : 2026-06-11 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.005e+04→1.038e+04→1.118e+04→1.072e+04→…→1.072e+04→9775→1.008e+04→1.013e+04
* 開始   : 2026-06-11 18:05:00 (UTC)
* 終了   : 2026-06-11 18:15:00 (UTC)
* 現象   : 平常時(1.041e+04)に対し 1.074倍(1.118e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260611-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→10→11→14→16→10→11
* 開始   : 2026-06-11 19:45:00 (UTC)
* 終了   : 2026-06-11 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→9→12→9→10→9→10
* 開始   : 2026-06-11 23:20:00 (UTC)
* 終了   : 2026-06-11 23:50:00 (UTC)
* 現象   : 2026-06-11 23:50:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host02-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→8→9→9→6→10→10→9→10
* 開始   : 2026-06-11 23:50:00 (UTC)
* 終了   : 2026-06-12 00:55:00 (UTC)
* 現象   : 2026-06-12 00:55:00 (UTC)を境に水準が 14.98から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→13→10→14→13→10→12
* 開始   : 2026-06-12 04:00:00 (UTC)
* 終了   : 2026-06-12 04:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.412倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.843σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→11→15→14→11→15→14→13
* 開始   : 2026-06-12 04:50:00 (UTC)
* 終了   : 2026-06-12 04:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→12→18→16→12→18→16→14
* 開始   : 2026-06-12 05:55:00 (UTC)
* 終了   : 2026-06-12 06:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→22→19→21→22→19→20
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:15:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 17→17→16→16→13→17
* 開始   : 2026-06-12 18:00:00 (UTC)
* 終了   : 2026-06-12 18:25:00 (UTC)
* 現象   : 2026-06-12 18:25:00 (UTC)を境に水準が 14.94から12.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→11→10→9→10
* 開始   : 2026-06-12 23:25:00 (UTC)
* 終了   : 2026-06-12 23:45:00 (UTC)
* 現象   : 2026-06-12 23:45:00 (UTC)を境に水準が 15から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.278, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→8→5→8→…→8→11→8→9
* 開始   : 2026-06-13 01:45:00 (UTC)
* 終了   : 2026-06-13 01:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260613-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 17→13→16→15→…→16→14→13→15
* 開始   : 2026-06-13 08:50:00 (UTC)
* 終了   : 2026-06-13 17:40:00 (UTC)
* 現象   : 8.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.571, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host02-007 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.8 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.8 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間

![EVT-20260613-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→17→14→13→17→14
* 開始   : 2026-06-14 08:40:00 (UTC)
* 終了   : 2026-06-14 08:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.007e+04→1.077e+04→9673→1.09e+04→…→1.09e+04→9591→1.008e+04→1.069e+04
* 開始   : 2026-06-14 09:40:00 (UTC)
* 終了   : 2026-06-14 09:50:00 (UTC)
* 現象   : 平常時(1.042e+04)に対し 0.9281(9673)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260614-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→17→17→20→17
* 開始   : 2026-06-14 13:50:00 (UTC)
* 終了   : 2026-06-14 14:10:00 (UTC)
* 現象   : 2026-06-14 14:10:00 (UTC)を境に水準が 11.94から14.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→18→20→19→…→19→18→17→18
* 開始   : 2026-06-15 02:00:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.71から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.461, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2536→2500→2522→2531→2531→2568→2526→2552→2588
* 開始   : 2026-06-15 08:00:00 (UTC)
* 終了   : 2026-06-15 12:50:00 (UTC)
* 現象   : 2026-06-15 12:50:00 (UTC)を境に水準が 2484から2498へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=257.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 7→10→9→10→9→10→10
* 開始   : 2026-06-15 23:50:00 (UTC)
* 終了   : 2026-06-16 00:20:00 (UTC)
* 現象   : 2026-06-16 00:20:00 (UTC)を境に水準が 14.97から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→5→9→11→5→9→7
* 開始   : 2026-06-16 01:00:00 (UTC)
* 終了   : 2026-06-16 01:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→14→…→14→16→12→14
* 開始   : 2026-06-16 04:55:00 (UTC)
* 終了   : 2026-06-16 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→18→22→23→22→18→22→23→22
* 開始   : 2026-06-16 09:15:00 (UTC)
* 終了   : 2026-06-16 09:20:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→23→25→19→22→23→25→19→22
* 開始   : 2026-06-16 11:35:00 (UTC)
* 終了   : 2026-06-16 11:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→16→18→19→16→18
* 開始   : 2026-06-16 16:05:00 (UTC)
* 終了   : 2026-06-16 16:10:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.035e+04→1.074e+04→9599→1.019e+04→…→1.019e+04→9766→9989→1.011e+04
* 開始   : 2026-06-16 17:25:00 (UTC)
* 終了   : 2026-06-16 17:35:00 (UTC)
* 現象   : 平常時(1.055e+04)に対し 0.9103(9599)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.827σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→11→5→7→8→11→5→7→9
* 開始   : 2026-06-16 23:55:00 (UTC)
* 終了   : 2026-06-17 00:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→9→10→8→10→11→12
* 開始   : 2026-06-17 01:50:00 (UTC)
* 終了   : 2026-06-17 02:45:00 (UTC)
* 現象   : 2026-06-17 02:45:00 (UTC)を境に水準が 14.92から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→12→9→13→12→9→13→10→9
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→10→14→10→14→13
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→11→…→11→14→12→13
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 04:20:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.076e+04→1.062e+04→1.074e+04→1.014e+04→1.043e+04→1.043e+04→1.016e+04→1.068e+04→1.072e+04
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 07:20:00 (UTC)
* 現象   : 2026-06-17 07:20:00 (UTC)を境に水準が 1.022e+04から1.028e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2162, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→18→17→19→18→17
* 開始   : 2026-06-17 06:55:00 (UTC)
* 終了   : 2026-06-17 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→17→19→17→19→18→15
* 開始   : 2026-06-17 07:00:00 (UTC)
* 終了   : 2026-06-17 07:10:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.099e+04→1.091e+04→1.003e+04→9936→…→1.003e+04→9936→1.029e+04→1.032e+04
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:55:00 (UTC)
* 現象   : 平常時(1.073e+04)に対し 0.9347(1.003e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→…→12→9→12→13
* 開始   : 2026-06-17 19:45:00 (UTC)
* 終了   : 2026-06-17 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 7→11→5→7→11→5→7
* 開始   : 2026-06-17 23:20:00 (UTC)
* 終了   : 2026-06-17 23:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host02-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→9→9→8→8→9→8→8→10
* 開始   : 2026-06-17 23:45:00 (UTC)
* 終了   : 2026-06-18 00:40:00 (UTC)
* 現象   : 2026-06-18 00:40:00 (UTC)を境に水準が 14.84から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9263→9252→9433→9406→9877→9241→1.009e+04→9703→9437
* 開始   : 2026-06-18 00:10:00 (UTC)
* 終了   : 2026-06-18 01:40:00 (UTC)
* 現象   : 2026-06-18 01:40:00 (UTC)を境に水準が 1.025e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2118, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→13→16→14→16→14→16→13→15
* 開始   : 2026-06-18 05:20:00 (UTC)
* 終了   : 2026-06-18 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→17→…→16→17→15→14
* 開始   : 2026-06-18 05:40:00 (UTC)
* 終了   : 2026-06-18 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→20→21→20→21→20→18
* 開始   : 2026-06-18 08:15:00 (UTC)
* 終了   : 2026-06-18 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.082e+04→1.109e+04→1.032e+04→1.037e+04→…→1.037e+04→1.156e+04→1.08e+04→1.043e+04
* 開始   : 2026-06-18 15:30:00 (UTC)
* 終了   : 2026-06-18 15:40:00 (UTC)
* 現象   : 平常時(1.101e+04)に対し 0.9371(1.032e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260618-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→20→18→19→20→19→19→18→19
* 開始   : 2026-06-18 15:35:00 (UTC)
* 終了   : 2026-06-18 16:15:00 (UTC)
* 現象   : 2026-06-18 16:15:00 (UTC)を境に水準が 14.89から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→13→13→13→14
* 開始   : 2026-06-19 04:15:00 (UTC)
* 終了   : 2026-06-19 04:35:00 (UTC)
* 現象   : 2026-06-19 04:35:00 (UTC)を境に水準が 14.82から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→16→19→16→19→16→19
* 開始   : 2026-06-19 07:05:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.061e+04→1.092e+04→1.113e+04→1.127e+04→…→1.127e+04→1.139e+04→1.1e+04→1.064e+04
* 開始   : 2026-06-19 07:55:00 (UTC)
* 終了   : 2026-06-19 08:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→20→22→23→21→20→22→23→21
* 開始   : 2026-06-19 09:10:00 (UTC)
* 終了   : 2026-06-19 09:15:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→23→19→23→19→23→20→23
* 開始   : 2026-06-19 09:55:00 (UTC)
* 終了   : 2026-06-19 10:05:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260619-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→21→25→21→18→25→21→18→22
* 開始   : 2026-06-19 13:40:00 (UTC)
* 終了   : 2026-06-19 13:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9498→9846→9052→8941→…→9052→8941→9817→9498
* 開始   : 2026-06-19 21:00:00 (UTC)
* 終了   : 2026-06-19 21:05:00 (UTC)
* 現象   : 平常時(9749)に対し 0.9285(9052)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 7→6→10→7→6→10→7
* 開始   : 2026-06-19 22:00:00 (UTC)
* 終了   : 2026-06-19 22:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→13→…→15→14→15→14
* 開始   : 2026-06-20 07:50:00 (UTC)
* 終了   : 2026-06-20 16:15:00 (UTC)
* 現象   : 8.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.595, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.4 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間

![EVT-20260620-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→7→…→7→8→9→10
* 開始   : 2026-06-20 20:15:00 (UTC)
* 終了   : 2026-06-20 21:05:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.901, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260620-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260620-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260620-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.022e+04→9378→9114→1.052e+04→…→9114→1.052e+04→1.041e+04→1.033e+04
* 開始   : 2026-06-21 07:10:00 (UTC)
* 終了   : 2026-06-21 07:15:00 (UTC)
* 現象   : 平常時(9840)に対し 0.9262(9114)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260621-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→14→14→18→18→19
* 開始   : 2026-06-21 08:55:00 (UTC)
* 終了   : 2026-06-21 09:20:00 (UTC)
* 現象   : 2026-06-21 09:20:00 (UTC)を境に水準が 11.93から12.76へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.727σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→10→9→8
* 開始   : 2026-06-22 01:20:00 (UTC)
* 終了   : 2026-06-22 01:35:00 (UTC)
* 現象   : 2026-06-22 01:35:00 (UTC)を境に水準が 11.83から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→9→5→10→9→5→10
* 開始   : 2026-06-22 01:45:00 (UTC)
* 終了   : 2026-06-22 01:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→19→…→20→18→17→16
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 11.81から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.647, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.521, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2567→2554→2512→2546→2531→2545→2541→2542→2562
* 開始   : 2026-06-22 09:10:00 (UTC)
* 終了   : 2026-06-22 14:40:00 (UTC)
* 現象   : 2026-06-22 14:40:00 (UTC)を境に水準が 2484から2497へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=54.33, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=262.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9899→9329→9366→9327→9323→9314→9798
* 開始   : 2026-06-23 01:00:00 (UTC)
* 終了   : 2026-06-23 01:50:00 (UTC)
* 現象   : 2026-06-23 01:50:00 (UTC)を境に水準が 1.023e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=615.2, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2371, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→9→12→9→12→10
* 開始   : 2026-06-23 02:05:00 (UTC)
* 終了   : 2026-06-23 02:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.727σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-004 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→9→13→7→…→13→7→10→12
* 開始   : 2026-06-23 03:00:00 (UTC)
* 終了   : 2026-06-23 03:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→13→12→12→12→13→13→12
* 開始   : 2026-06-23 03:55:00 (UTC)
* 終了   : 2026-06-23 04:30:00 (UTC)
* 現象   : 2026-06-23 04:30:00 (UTC)を境に水準が 14.86から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→15→17→16→15→17→16
* 開始   : 2026-06-23 06:10:00 (UTC)
* 終了   : 2026-06-23 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260623-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→17→21→20→19→21→19→21→21
* 開始   : 2026-06-23 07:35:00 (UTC)
* 終了   : 2026-06-23 08:30:00 (UTC)
* 現象   : 2026-06-23 08:30:00 (UTC)を境に水準が 15.07から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.376, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→23→23→21→22→22→24→22→24
* 開始   : 2026-06-23 10:10:00 (UTC)
* 終了   : 2026-06-23 11:25:00 (UTC)
* 現象   : 2026-06-23 11:25:00 (UTC)を境に水準が 14.94から16.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→19→20→19→16→21→20
* 開始   : 2026-06-23 15:10:00 (UTC)
* 終了   : 2026-06-23 16:30:00 (UTC)
* 現象   : 2026-06-23 16:30:00 (UTC)を境に水準が 14.96から15.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→18→15→18→15→17→18
* 開始   : 2026-06-23 16:40:00 (UTC)
* 終了   : 2026-06-23 16:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→17→16→18→16→17→15→14→15
* 開始   : 2026-06-23 17:15:00 (UTC)
* 終了   : 2026-06-23 18:10:00 (UTC)
* 現象   : 2026-06-23 18:10:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.094, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→8→6→8→6→9→8
* 開始   : 2026-06-23 22:55:00 (UTC)
* 終了   : 2026-06-23 23:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260623-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→5→11→8→9→5→11→8→7
* 開始   : 2026-06-24 01:40:00 (UTC)
* 終了   : 2026-06-24 01:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→14→…→14→16→11→13
* 開始   : 2026-06-24 04:30:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9391→8894→8702→9194→…→9194→8441→8958→8830
* 開始   : 2026-06-24 22:50:00 (UTC)
* 終了   : 2026-06-24 23:00:00 (UTC)
* 現象   : 平常時(9427)に対し 0.9231(8702)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→6→10→9→6→10→7
* 開始   : 2026-06-24 22:55:00 (UTC)
* 終了   : 2026-06-24 23:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-011 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260624-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8874→9364→8604→8552→…→8604→8552→9520→9183
* 開始   : 2026-06-25 00:55:00 (UTC)
* 終了   : 2026-06-25 01:00:00 (UTC)
* 現象   : 平常時(9293)に対し 0.9259(8604)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→16→…→16→17→16→14
* 開始   : 2026-06-25 05:55:00 (UTC)
* 終了   : 2026-06-25 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 23→24→24→22→26→22
* 開始   : 2026-06-25 11:30:00 (UTC)
* 終了   : 2026-06-25 11:55:00 (UTC)
* 現象   : 2026-06-25 11:55:00 (UTC)を境に水準が 15.08から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→21→22→21→23→22→22→20→21
* 開始   : 2026-06-25 14:30:00 (UTC)
* 終了   : 2026-06-25 15:10:00 (UTC)
* 現象   : 2026-06-25 15:10:00 (UTC)を境に水準が 14.99から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→16→20→16→20→17
* 開始   : 2026-06-25 16:10:00 (UTC)
* 終了   : 2026-06-25 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9616→9226→9135→9901→9296→9777→9171→9728
* 開始   : 2026-06-25 23:00:00 (UTC)
* 終了   : 2026-06-25 23:35:00 (UTC)
* 現象   : 2026-06-25 23:35:00 (UTC)を境に水準が 1.024e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2849, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9637→9703→9469→9712
* 開始   : 2026-06-26 00:45:00 (UTC)
* 終了   : 2026-06-26 01:00:00 (UTC)
* 現象   : 2026-06-26 01:00:00 (UTC)を境に水準が 1.026e+04から1.023e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2285, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8899→9496→1.011e+04→1.029e+04→…→1.011e+04→1.029e+04→9275→9628
* 開始   : 2026-06-26 03:35:00 (UTC)
* 終了   : 2026-06-26 03:40:00 (UTC)
* 現象   : 平常時(9416)に対し 1.073倍(1.011e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.066σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→13→16→14→16→14→16→14
* 開始   : 2026-06-26 05:30:00 (UTC)
* 終了   : 2026-06-26 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→16→…→16→18→14→16
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→15→17→15→16
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:10:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 22→22→24→23→22→22→20→23→24
* 開始   : 2026-06-26 11:25:00 (UTC)
* 終了   : 2026-06-26 12:40:00 (UTC)
* 現象   : 2026-06-26 12:40:00 (UTC)を境に水準が 15.05から13.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.033, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 25→23→24→23
* 開始   : 2026-06-26 11:50:00 (UTC)
* 終了   : 2026-06-26 12:05:00 (UTC)
* 現象   : 2026-06-26 12:05:00 (UTC)を境に水準が 15.06から13.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→18→…→25→18→20→19
* 開始   : 2026-06-26 13:05:00 (UTC)
* 終了   : 2026-06-26 13:10:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.181倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→18→19→18
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 17:05:00 (UTC)
* 現象   : 2026-06-26 17:05:00 (UTC)を境に水準が 15.09から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→20→…→14→20→14→16
* 開始   : 2026-06-26 17:30:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→17→12→17→12→13→15
* 開始   : 2026-06-26 18:40:00 (UTC)
* 終了   : 2026-06-26 18:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→10→8→6→10→8
* 開始   : 2026-06-26 22:15:00 (UTC)
* 終了   : 2026-06-26 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→5→8→12→5→8→12→8→7
* 開始   : 2026-06-26 23:10:00 (UTC)
* 終了   : 2026-06-26 23:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→11→10→9→…→8→12→13→12
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 05:40:00 (UTC)
* 現象   : 1.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 1.0 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 55 分
  - EVT-20260627-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分

![EVT-20260627-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→13→15→13→…→12→13→12→13
* 開始   : 2026-06-27 08:10:00 (UTC)
* 終了   : 2026-06-27 17:00:00 (UTC)
* 現象   : 8.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.551, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.8 時間
  - EVT-20260627-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間

![EVT-20260627-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2496→2479→2448→2502→…→2448→2502→2502→2468
* 開始   : 2026-06-27 09:20:00 (UTC)
* 終了   : 2026-06-27 09:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2448)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-58.88, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260627-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2515→2492→2478→2506→…→2478→2506→2509→2477
* 開始   : 2026-06-27 11:10:00 (UTC)
* 終了   : 2026-06-27 11:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2478)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-55.81, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260627-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→10→11→7→10→11→10
* 開始   : 2026-06-27 19:40:00 (UTC)
* 終了   : 2026-06-27 19:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.97, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260627-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→8→10→8→7→11→10→11→9
* 開始   : 2026-06-27 23:20:00 (UTC)
* 終了   : 2026-06-28 01:15:00 (UTC)
* 現象   : 2026-06-28 01:15:00 (UTC)を境に水準が 11.87から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.008e+04→1.037e+04→9727→1.049e+04→1.009e+04→9846→1.03e+04→1.035e+04→1.066e+04
* 開始   : 2026-06-28 06:15:00 (UTC)
* 終了   : 2026-06-28 07:30:00 (UTC)
* 現象   : 2026-06-28 07:30:00 (UTC)を境に水準が 9767から9854へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→14→18→19→…→18→19→15→14
* 開始   : 2026-06-28 10:05:00 (UTC)
* 終了   : 2026-06-28 10:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.031e+04→9938→9636→1.089e+04→…→1.089e+04→9546→9930→1.024e+04
* 開始   : 2026-06-28 13:45:00 (UTC)
* 終了   : 2026-06-28 13:55:00 (UTC)
* 現象   : 平常時(1.038e+04)に対し 0.9287(9636)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→13→8→12→13→8→12→9
* 開始   : 2026-06-28 19:10:00 (UTC)
* 終了   : 2026-06-28 19:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→10
* 開始   : 2026-06-29 01:50:00 (UTC)
* 終了   : 2026-06-29 02:05:00 (UTC)
* 現象   : 2026-06-29 02:05:00 (UTC)を境に水準が 11.74から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.619, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→20→22→23→…→21→19→18→17
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 11.8から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.538, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2549→2536→2541→2534→2519→2532→2510→2551→2564
* 開始   : 2026-06-29 09:10:00 (UTC)
* 終了   : 2026-06-29 14:20:00 (UTC)
* 現象   : 2026-06-29 14:20:00 (UTC)を境に水準が 2485から2499へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=253.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→8→11→11→13→12→11
* 開始   : 2026-06-29 20:35:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 14.86から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→11→13→11→13→11→13→9→13
* 開始   : 2026-06-30 03:20:00 (UTC)
* 終了   : 2026-06-30 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→14→15→16→…→15→16→15→13
* 開始   : 2026-06-30 04:50:00 (UTC)
* 終了   : 2026-06-30 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.017e+04→9992→1.094e+04→1.101e+04→…→1.094e+04→1.101e+04→1.049e+04→1.017e+04
* 開始   : 2026-06-30 05:40:00 (UTC)
* 終了   : 2026-06-30 05:45:00 (UTC)
* 現象   : 平常時(9969)に対し 1.098倍(1.094e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.912σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→12→17→15
* 開始   : 2026-06-30 06:10:00 (UTC)
* 終了   : 2026-06-30 06:15:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→21→…→20→21→19→20
* 開始   : 2026-06-30 07:35:00 (UTC)
* 終了   : 2026-06-30 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→18→21→22→18→21→22
* 開始   : 2026-06-30 14:35:00 (UTC)
* 終了   : 2026-06-30 14:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.8308(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→16→15→18→…→17→14→16→17
* 開始   : 2026-06-30 17:10:00 (UTC)
* 終了   : 2026-06-30 17:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260630-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→11→12→10→9→12→11→10→11
* 開始   : 2026-06-30 20:40:00 (UTC)
* 終了   : 2026-06-30 21:40:00 (UTC)
* 現象   : 2026-06-30 21:40:00 (UTC)を境に水準が 14.88から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host02-015 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
