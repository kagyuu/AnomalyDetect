# host13 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host13 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 325 (SEVERE: 21, FATAL: 140, WARN: 164, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 140 | 164 | 325 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→…→11→14→11→12
* 開始   : 2026-07-06 01:40:00 (UTC)
* 終了   : 2026-07-06 20:45:00 (UTC)
* 現象   : 2026-07-06 20:45:00 (UTC)を境に水準が 11.81から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.753, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-001 active_connections の推移](charts/EVT-20260706-host13-001.svg)

# イベントID( EVT-20260706-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→12→14→13→…→17→15→12→15
* 開始   : 2026-07-06 01:55:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.033, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-002 active_connections の推移](charts/EVT-20260706-host13-002.svg)

# イベントID( EVT-20260706-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→13→14→15→13
* 開始   : 2026-07-06 02:00:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.81から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.936, 限界=2.695)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.117σ 外れた (平常値=16.01)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-003 active_connections の推移](charts/EVT-20260706-host13-003.svg)

# イベントID( EVT-20260706-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→17→…→13→12→11→13
* 開始   : 2026-07-06 02:45:00 (UTC)
* 終了   : 2026-07-06 19:35:00 (UTC)
* 現象   : 2026-07-06 19:35:00 (UTC)を境に水準が 11.8から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.688, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.507, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-005 active_connections の推移](charts/EVT-20260706-host13-005.svg)

# イベントID( EVT-20260706-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→15→…→12→14→10→12
* 開始   : 2026-07-06 03:00:00 (UTC)
* 終了   : 2026-07-06 20:15:00 (UTC)
* 現象   : 2026-07-06 20:15:00 (UTC)を境に水準が 11.85から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.819, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-006 active_connections の推移](charts/EVT-20260706-host13-006.svg)

# イベントID( EVT-20260713-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→13→14→…→13→12→17→13
* 開始   : 2026-07-13 00:55:00 (UTC)
* 終了   : 2026-07-13 22:15:00 (UTC)
* 現象   : 2026-07-13 22:15:00 (UTC)を境に水準が 11.63から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.66, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.884, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-001 active_connections の推移](charts/EVT-20260713-host13-001.svg)

# イベントID( EVT-20260713-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→13→16→15→…→14→13→14→13
* 開始   : 2026-07-13 01:10:00 (UTC)
* 終了   : 2026-07-13 21:40:00 (UTC)
* 現象   : 2026-07-13 21:40:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.641σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.703, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-002 active_connections の推移](charts/EVT-20260713-host13-002.svg)

# イベントID( EVT-20260713-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→13→16→13→11
* 開始   : 2026-07-13 01:40:00 (UTC)
* 終了   : 2026-07-13 19:45:00 (UTC)
* 現象   : 2026-07-13 19:45:00 (UTC)を境に水準が 11.84から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.846, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.52, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-003 active_connections の推移](charts/EVT-20260713-host13-003.svg)

# イベントID( EVT-20260713-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→15→…→12→13→12→10
* 開始   : 2026-07-13 02:20:00 (UTC)
* 終了   : 2026-07-13 21:25:00 (UTC)
* 現象   : 2026-07-13 21:25:00 (UTC)を境に水準が 11.82から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.021, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-005 active_connections の推移](charts/EVT-20260713-host13-005.svg)

# イベントID( EVT-20260713-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→17→21→19→…→13→14→11→12
* 開始   : 2026-07-13 03:40:00 (UTC)
* 終了   : 2026-07-13 20:25:00 (UTC)
* 現象   : 2026-07-13 20:25:00 (UTC)を境に水準が 11.96から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.709, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-006 active_connections の推移](charts/EVT-20260713-host13-006.svg)

# イベントID( EVT-20260720-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→13→14→15→…→14→12→11→12
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 20:10:00 (UTC)
* 現象   : 2026-07-20 20:10:00 (UTC)を境に水準が 11.82から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.66, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-001 active_connections の推移](charts/EVT-20260720-host13-001.svg)

# イベントID( EVT-20260720-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→13→…→12→15→12→11
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.92から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-002 active_connections の推移](charts/EVT-20260720-host13-002.svg)

# イベントID( EVT-20260720-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→15→16→15→…→13→15→13→12
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.972, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-003 active_connections の推移](charts/EVT-20260720-host13-003.svg)

# イベントID( EVT-20260720-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→14→…→14→13→14→13
* 開始   : 2026-07-20 03:20:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.99から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.219, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-004 active_connections の推移](charts/EVT-20260720-host13-004.svg)

# イベントID( EVT-20260720-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→14→17→16→…→12→13→10→12
* 開始   : 2026-07-20 03:40:00 (UTC)
* 終了   : 2026-07-20 19:25:00 (UTC)
* 現象   : 2026-07-20 19:25:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.879, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-005 active_connections の推移](charts/EVT-20260720-host13-005.svg)

# イベントID( EVT-20260720-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→14→17→14→…→14→13→15→13
* 開始   : 2026-07-20 03:40:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.856, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host13-006 active_connections の推移](charts/EVT-20260720-host13-006.svg)

# イベントID( EVT-20260727-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→19→17→15→…→13→12→14→11
* 開始   : 2026-07-27 02:05:00 (UTC)
* 終了   : 2026-07-27 19:55:00 (UTC)
* 現象   : 2026-07-27 19:55:00 (UTC)を境に水準が 11.81から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.655, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-001 active_connections の推移](charts/EVT-20260727-host13-001.svg)

# イベントID( EVT-20260727-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→15→…→13→14→12→13
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 22:50:00 (UTC)
* 現象   : 2026-07-27 22:50:00 (UTC)を境に水準が 11.81から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.776, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.511, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-005 active_connections の推移](charts/EVT-20260727-host13-005.svg)

# イベントID( EVT-20260727-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→14→…→14→15→14→15
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 23:00:00 (UTC)
* 現象   : 2026-07-27 23:00:00 (UTC)を境に水準が 11.79から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.79, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-006 active_connections の推移](charts/EVT-20260727-host13-006.svg)

# イベントID( EVT-20260727-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→16→…→16→15→16→15
* 開始   : 2026-07-27 03:20:00 (UTC)
* 終了   : 2026-07-27 19:25:00 (UTC)
* 現象   : 2026-07-27 19:25:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.801, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-007 active_connections の推移](charts/EVT-20260727-host13-007.svg)

# イベントID( EVT-20260727-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→13→…→14→16→14→15
* 開始   : 2026-07-27 03:25:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.73から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-008 active_connections の推移](charts/EVT-20260727-host13-008.svg)

# イベントID( EVT-20260701-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→8→4→8→7
* 開始   : 2026-07-01 00:15:00 (UTC)
* 終了   : 2026-07-01 00:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→6→12→9→10
* 開始   : 2026-07-01 01:30:00 (UTC)
* 終了   : 2026-07-01 01:30:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→20→17→20→22
* 開始   : 2026-07-01 13:35:00 (UTC)
* 終了   : 2026-07-01 13:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→15→19→16→15→19→16→20→18
* 開始   : 2026-07-01 15:45:00 (UTC)
* 終了   : 2026-07-01 15:55:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260701-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→11→5→9→9
* 開始   : 2026-07-02 02:45:00 (UTC)
* 終了   : 2026-07-02 02:45:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.489σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→12→16→13→11
* 開始   : 2026-07-02 04:40:00 (UTC)
* 終了   : 2026-07-02 04:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host13-003 active_connections の推移](charts/EVT-20260702-host13-003.svg)

# イベントID( EVT-20260702-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→17→21→18→17
* 開始   : 2026-07-02 06:50:00 (UTC)
* 終了   : 2026-07-02 06:50:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host13-005 active_connections の推移](charts/EVT-20260702-host13-005.svg)

# イベントID( EVT-20260702-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→17→19→17→19→17→18
* 開始   : 2026-07-02 07:00:00 (UTC)
* 終了   : 2026-07-02 07:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→21→24→20→22
* 開始   : 2026-07-02 09:40:00 (UTC)
* 終了   : 2026-07-02 09:40:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-013 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260702-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 23→22→22→22→24
* 開始   : 2026-07-02 13:20:00 (UTC)
* 終了   : 2026-07-02 14:40:00 (UTC)
* 現象   : 2026-07-02 14:40:00 (UTC)を境に水準が 14.89から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→12→7→10→11
* 開始   : 2026-07-02 20:40:00 (UTC)
* 終了   : 2026-07-02 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.182σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→11→16→11→11
* 開始   : 2026-07-03 03:35:00 (UTC)
* 終了   : 2026-07-03 03:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.536倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.902σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host13-001 active_connections の推移](charts/EVT-20260703-host13-001.svg)

# イベントID( EVT-20260703-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→20→24→21→22
* 開始   : 2026-07-03 09:40:00 (UTC)
* 終了   : 2026-07-03 09:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→23→26→21→22
* 開始   : 2026-07-03 10:45:00 (UTC)
* 終了   : 2026-07-03 10:45:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 27→22→24→21→23
* 開始   : 2026-07-03 12:50:00 (UTC)
* 終了   : 2026-07-03 13:10:00 (UTC)
* 現象   : 2026-07-03 13:10:00 (UTC)を境に水準が 15.04から13.25へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.547σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 7→10→13→8→8
* 開始   : 2026-07-04 02:10:00 (UTC)
* 終了   : 2026-07-04 02:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→9→14→8→10
* 開始   : 2026-07-04 02:50:00 (UTC)
* 終了   : 2026-07-04 02:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260704-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260704-host13-002 active_connections の推移](charts/EVT-20260704-host13-002.svg)

# イベントID( EVT-20260704-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→13→…→13→11→13→12
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 17:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.773, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260704-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260704-host13-004 active_connections の推移](charts/EVT-20260704-host13-004.svg)

# イベントID( EVT-20260704-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→11→…→12→11→13→11
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 18:55:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host13-005 active_connections の推移](charts/EVT-20260704-host13-005.svg)

# イベントID( EVT-20260704-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→13→…→12→9→12→11
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.882, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host13-006 active_connections の推移](charts/EVT-20260704-host13-006.svg)

# イベントID( EVT-20260704-host13-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→11→12→10→…→10→8→11→10
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:35:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.049, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host13-007 active_connections の推移](charts/EVT-20260704-host13-007.svg)

# イベントID( EVT-20260704-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→10→11→10→…→15→14→15→14
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 17:10:00 (UTC)
* 現象   : 11.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.702, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260704-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間

![EVT-20260704-host13-008 active_connections の推移](charts/EVT-20260704-host13-008.svg)

# イベントID( EVT-20260704-host13-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→12→…→10→12→10→12
* 開始   : 2026-07-04 06:20:00 (UTC)
* 終了   : 2026-07-04 19:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260704-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260704-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260704-host13-009 active_connections の推移](charts/EVT-20260704-host13-009.svg)

# イベントID( EVT-20260705-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→11→12→9→11→10
* 開始   : 2026-07-05 18:00:00 (UTC)
* 終了   : 2026-07-05 18:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.298σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260705-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260705-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260705-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260705-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→14→8→9→…→8→9→10→9
* 開始   : 2026-07-05 18:35:00 (UTC)
* 終了   : 2026-07-05 18:40:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→16→…→13→16→12→14
* 開始   : 2026-07-06 02:40:00 (UTC)
* 終了   : 2026-07-06 20:35:00 (UTC)
* 現象   : 2026-07-06 20:35:00 (UTC)を境に水準が 11.73から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.406, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-004 active_connections の推移](charts/EVT-20260706-host13-004.svg)

# イベントID( EVT-20260707-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→14→12
* 開始   : 2026-07-07 04:45:00 (UTC)
* 終了   : 2026-07-07 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→16→18→18→20
* 開始   : 2026-07-07 06:10:00 (UTC)
* 終了   : 2026-07-07 06:50:00 (UTC)
* 現象   : 2026-07-07 06:50:00 (UTC)を境に水準が 14.96から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.511, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→20→23→19→20
* 開始   : 2026-07-07 08:35:00 (UTC)
* 終了   : 2026-07-07 08:35:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→23→22
* 開始   : 2026-07-07 09:45:00 (UTC)
* 終了   : 2026-07-07 09:45:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→16→17→19→21→16→17→19→20
* 開始   : 2026-07-07 15:10:00 (UTC)
* 終了   : 2026-07-07 15:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→15→13→17→…→15→13→18→16
* 開始   : 2026-07-07 17:10:00 (UTC)
* 終了   : 2026-07-07 17:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→11→9→7→…→9→7→13→11
* 開始   : 2026-07-07 20:15:00 (UTC)
* 終了   : 2026-07-07 20:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→19→25→19→21
* 開始   : 2026-07-08 09:30:00 (UTC)
* 終了   : 2026-07-08 09:30:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.277倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.78σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host13-007 active_connections の推移](charts/EVT-20260708-host13-007.svg)

# イベントID( EVT-20260708-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→19→26→23→22
* 開始   : 2026-07-08 12:20:00 (UTC)
* 終了   : 2026-07-08 12:20:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 24→21→24→23→25
* 開始   : 2026-07-08 13:20:00 (UTC)
* 終了   : 2026-07-08 13:55:00 (UTC)
* 現象   : 2026-07-08 13:55:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→19→15→19→18
* 開始   : 2026-07-08 16:10:00 (UTC)
* 終了   : 2026-07-08 16:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→18→14→18→18
* 開始   : 2026-07-08 16:35:00 (UTC)
* 終了   : 2026-07-08 16:35:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→17→13→16→17→13→16→14
* 開始   : 2026-07-08 17:30:00 (UTC)
* 終了   : 2026-07-08 17:50:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→21→23→21→21
* 開始   : 2026-07-09 08:35:00 (UTC)
* 終了   : 2026-07-09 08:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260709-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 20→24→19→23→…→19→23→21→19
* 開始   : 2026-07-09 09:05:00 (UTC)
* 終了   : 2026-07-09 09:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.588σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host13-005 active_connections の推移](charts/EVT-20260709-host13-005.svg)

# イベントID( EVT-20260709-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→19→13→14→…→13→14→16→18
* 開始   : 2026-07-09 17:20:00 (UTC)
* 終了   : 2026-07-09 17:25:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→7→12→7→12→7→11→10
* 開始   : 2026-07-09 20:50:00 (UTC)
* 終了   : 2026-07-09 21:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host13-010 active_connections の推移](charts/EVT-20260709-host13-010.svg)

# イベントID( EVT-20260710-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 19→22→18→16→…→18→16→19→21
* 開始   : 2026-07-10 15:05:00 (UTC)
* 終了   : 2026-07-10 15:45:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260710-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→14→12→10→14→12→10→14
* 開始   : 2026-07-10 17:25:00 (UTC)
* 終了   : 2026-07-10 18:40:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→16→16
* 開始   : 2026-07-10 17:50:00 (UTC)
* 終了   : 2026-07-10 17:50:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→11→…→13→14→13→12
* 開始   : 2026-07-11 04:25:00 (UTC)
* 終了   : 2026-07-11 18:30:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.16, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host13-002 active_connections の推移](charts/EVT-20260711-host13-002.svg)

# イベントID( EVT-20260711-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→10→11→14→…→12→10→11→12
* 開始   : 2026-07-11 04:45:00 (UTC)
* 終了   : 2026-07-11 19:35:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.041, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260711-host13-003 active_connections の推移](charts/EVT-20260711-host13-003.svg)

# イベントID( EVT-20260711-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→…→12→14→13→12
* 開始   : 2026-07-11 05:20:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.089, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host13-004 active_connections の推移](charts/EVT-20260711-host13-004.svg)

# イベントID( EVT-20260711-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→…→11→12→13→11
* 開始   : 2026-07-11 05:25:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260711-host13-005 active_connections の推移](charts/EVT-20260711-host13-005.svg)

# イベントID( EVT-20260711-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→11→…→13→11→14→12
* 開始   : 2026-07-11 05:35:00 (UTC)
* 終了   : 2026-07-11 18:15:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260711-host13-006 active_connections の推移](charts/EVT-20260711-host13-006.svg)

# イベントID( EVT-20260711-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→13→…→13→11→13→10
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:25:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.851, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260711-host13-007 active_connections の推移](charts/EVT-20260711-host13-007.svg)

# イベントID( EVT-20260712-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 8→8→4→8→9
* 開始   : 2026-07-12 21:40:00 (UTC)
* 終了   : 2026-07-12 21:40:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.521σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260712-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host13-005 active_connections の推移](charts/EVT-20260712-host13-005.svg)

# イベントID( EVT-20260713-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→12→13→15→…→13→14→13→12
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 21:05:00 (UTC)
* 現象   : 2026-07-13 21:05:00 (UTC)を境に水準が 11.83から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.771, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.125, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→16→21→18→16
* 開始   : 2026-07-14 06:55:00 (UTC)
* 終了   : 2026-07-14 06:55:00 (UTC)
* 現象   : 平常時(16)に対し 1.312倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.521σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host13-003 active_connections の推移](charts/EVT-20260714-host13-003.svg)

# イベントID( EVT-20260714-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→19→23→19→16
* 開始   : 2026-07-14 08:25:00 (UTC)
* 終了   : 2026-07-14 08:25:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→21→22→24→…→22→24→22→20
* 開始   : 2026-07-15 09:20:00 (UTC)
* 終了   : 2026-07-15 09:25:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 21→20→26→20→22
* 開始   : 2026-07-15 12:15:00 (UTC)
* 終了   : 2026-07-15 12:15:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→22→20
* 開始   : 2026-07-15 15:10:00 (UTC)
* 終了   : 2026-07-15 15:10:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→11→10
* 開始   : 2026-07-15 20:10:00 (UTC)
* 終了   : 2026-07-15 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→7→7
* 開始   : 2026-07-16 00:10:00 (UTC)
* 終了   : 2026-07-16 00:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→17→20→17→16
* 開始   : 2026-07-16 06:55:00 (UTC)
* 終了   : 2026-07-16 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→18→12→16→16
* 開始   : 2026-07-16 17:10:00 (UTC)
* 終了   : 2026-07-16 17:10:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host13-009 active_connections の推移](charts/EVT-20260716-host13-009.svg)

# イベントID( EVT-20260716-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→16→11→15→13
* 開始   : 2026-07-16 18:25:00 (UTC)
* 終了   : 2026-07-16 18:25:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 8→8→4→8→10
* 開始   : 2026-07-17 00:25:00 (UTC)
* 終了   : 2026-07-17 00:25:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→18→17→16→15→18→17→16→15
* 開始   : 2026-07-17 05:45:00 (UTC)
* 終了   : 2026-07-17 05:50:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.227σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→17→18→20→22→17→19
* 開始   : 2026-07-17 07:50:00 (UTC)
* 終了   : 2026-07-17 07:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host13-004 active_connections の推移](charts/EVT-20260717-host13-004.svg)

# イベントID( EVT-20260717-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→20→23→19→21
* 開始   : 2026-07-17 08:40:00 (UTC)
* 終了   : 2026-07-17 08:40:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→18→17→17→17→16→16→17→17
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 18:30:00 (UTC)
* 現象   : 2026-07-17 18:30:00 (UTC)を境に水準が 15.08から12.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→14→10→14→13
* 開始   : 2026-07-17 18:45:00 (UTC)
* 終了   : 2026-07-17 18:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→15→8→10→15→8→12
* 開始   : 2026-07-17 19:45:00 (UTC)
* 終了   : 2026-07-17 19:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260717-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host13-008 active_connections の推移](charts/EVT-20260717-host13-008.svg)

# イベントID( EVT-20260717-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→11→9→13→11→9→13
* 開始   : 2026-07-17 20:15:00 (UTC)
* 終了   : 2026-07-17 20:50:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-086 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host13-009 active_connections の推移](charts/EVT-20260717-host13-009.svg)

# イベントID( EVT-20260718-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→10→7
* 開始   : 2026-07-18 01:45:00 (UTC)
* 終了   : 2026-07-18 01:45:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260718-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→13→…→10→11→10→11
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 19:50:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host13-003 active_connections の推移](charts/EVT-20260718-host13-003.svg)

# イベントID( EVT-20260718-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→10→…→13→12→13→12
* 開始   : 2026-07-18 05:30:00 (UTC)
* 終了   : 2026-07-18 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.876, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host13-004 active_connections の推移](charts/EVT-20260718-host13-004.svg)

# イベントID( EVT-20260718-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→10→…→10→9→11→12
* 開始   : 2026-07-18 05:35:00 (UTC)
* 終了   : 2026-07-18 20:10:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260718-host13-005 active_connections の推移](charts/EVT-20260718-host13-005.svg)

# イベントID( EVT-20260718-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→9→10→12→…→13→10→12→11
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 19:50:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.141, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260718-host13-006 active_connections の推移](charts/EVT-20260718-host13-006.svg)

# イベントID( EVT-20260718-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→10→…→11→10→9→11
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 19:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260718-host13-007 active_connections の推移](charts/EVT-20260718-host13-007.svg)

# イベントID( EVT-20260718-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→14→10→13→…→12→9→10→11
* 開始   : 2026-07-18 06:30:00 (UTC)
* 終了   : 2026-07-18 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host13-008 active_connections の推移](charts/EVT-20260718-host13-008.svg)

# イベントID( EVT-20260718-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→10→7→12→…→12→8→9→11
* 開始   : 2026-07-18 19:50:00 (UTC)
* 終了   : 2026-07-18 20:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分

![EVT-20260718-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→13→12
* 開始   : 2026-07-19 06:35:00 (UTC)
* 終了   : 2026-07-19 06:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→15→13
* 開始   : 2026-07-19 08:40:00 (UTC)
* 終了   : 2026-07-19 08:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→10→10
* 開始   : 2026-07-20 21:15:00 (UTC)
* 終了   : 2026-07-20 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260720-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→12→14→16→11→12→14→16→11
* 開始   : 2026-07-21 04:25:00 (UTC)
* 終了   : 2026-07-21 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host13-003 active_connections の推移](charts/EVT-20260721-host13-003.svg)

# イベントID( EVT-20260721-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→14→18→13→14
* 開始   : 2026-07-21 05:30:00 (UTC)
* 終了   : 2026-07-21 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host13-004 active_connections の推移](charts/EVT-20260721-host13-004.svg)

# イベントID( EVT-20260721-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→19→14→18→…→18→22→20→19
* 開始   : 2026-07-21 07:55:00 (UTC)
* 終了   : 2026-07-21 08:05:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260721-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 19→17→13→16→16
* 開始   : 2026-07-21 17:25:00 (UTC)
* 終了   : 2026-07-21 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260721-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→13→10→13→13
* 開始   : 2026-07-21 19:15:00 (UTC)
* 終了   : 2026-07-21 19:15:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260721-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 7→10→12→7→7
* 開始   : 2026-07-22 01:05:00 (UTC)
* 終了   : 2026-07-22 01:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→13→10→12→11→10→12→13→15
* 開始   : 2026-07-22 02:15:00 (UTC)
* 終了   : 2026-07-22 04:20:00 (UTC)
* 現象   : 2026-07-22 04:20:00 (UTC)を境に水準が 14.94から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.125, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→14→18→15→15
* 開始   : 2026-07-22 05:15:00 (UTC)
* 終了   : 2026-07-22 05:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.412倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host13-005 active_connections の推移](charts/EVT-20260722-host13-005.svg)

# イベントID( EVT-20260722-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→26→19→20→21→26→19→20→22
* 開始   : 2026-07-22 13:40:00 (UTC)
* 終了   : 2026-07-22 13:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→18→14→12→14→18→14→12→14
* 開始   : 2026-07-22 17:45:00 (UTC)
* 終了   : 2026-07-22 17:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host13-011 active_connections の推移](charts/EVT-20260722-host13-011.svg)

# イベントID( EVT-20260722-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→13→9→11→12
* 開始   : 2026-07-22 19:20:00 (UTC)
* 終了   : 2026-07-22 19:20:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.6506(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host13-014 active_connections の推移](charts/EVT-20260722-host13-014.svg)

# イベントID( EVT-20260722-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→8→7→11→12→8→7→11
* 開始   : 2026-07-22 20:10:00 (UTC)
* 終了   : 2026-07-22 20:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260722-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→9→12
* 開始   : 2026-07-23 04:00:00 (UTC)
* 終了   : 2026-07-23 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→13→13
* 開始   : 2026-07-23 04:50:00 (UTC)
* 終了   : 2026-07-23 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→14→14→15→15→15→17
* 開始   : 2026-07-23 04:55:00 (UTC)
* 終了   : 2026-07-23 06:00:00 (UTC)
* 現象   : 2026-07-23 06:00:00 (UTC)を境に水準が 14.97から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.021, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→17→14→18→17
* 開始   : 2026-07-23 16:50:00 (UTC)
* 終了   : 2026-07-23 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→15→13→14→13→14→13→16→17
* 開始   : 2026-07-23 17:30:00 (UTC)
* 終了   : 2026-07-23 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260723-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→11→15→13→11
* 開始   : 2026-07-24 04:05:00 (UTC)
* 終了   : 2026-07-24 04:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→16→12→16→15
* 開始   : 2026-07-24 17:30:00 (UTC)
* 終了   : 2026-07-24 17:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→15→10→13→14
* 開始   : 2026-07-24 18:20:00 (UTC)
* 終了   : 2026-07-24 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.6383(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.935σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host13-006 active_connections の推移](charts/EVT-20260724-host13-006.svg)

# イベントID( EVT-20260724-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→10→13→11→10→13→11→12
* 開始   : 2026-07-24 18:40:00 (UTC)
* 終了   : 2026-07-24 19:10:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260724-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→9→6→11→8
* 開始   : 2026-07-24 20:55:00 (UTC)
* 終了   : 2026-07-24 20:55:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.5333(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.645σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host13-008 active_connections の推移](charts/EVT-20260724-host13-008.svg)

# イベントID( EVT-20260724-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→7→4→9→…→9→5→7→10
* 開始   : 2026-07-24 22:45:00 (UTC)
* 終了   : 2026-07-24 22:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host13-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→8→9→…→12→11→14→10
* 開始   : 2026-07-25 04:55:00 (UTC)
* 終了   : 2026-07-25 18:30:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.275, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260725-host13-002 active_connections の推移](charts/EVT-20260725-host13-002.svg)

# イベントID( EVT-20260725-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→12→…→10→11→10→11
* 開始   : 2026-07-25 05:00:00 (UTC)
* 終了   : 2026-07-25 19:40:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.025, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260725-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260725-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260725-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260725-host13-003 active_connections の推移](charts/EVT-20260725-host13-003.svg)

# イベントID( EVT-20260725-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→10→8→11→…→13→10→13→12
* 開始   : 2026-07-25 05:00:00 (UTC)
* 終了   : 2026-07-25 18:40:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.87, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host13-004 active_connections の推移](charts/EVT-20260725-host13-004.svg)

# イベントID( EVT-20260725-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→16→…→9→12→11→10
* 開始   : 2026-07-25 05:15:00 (UTC)
* 終了   : 2026-07-25 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.039, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host13-005 active_connections の推移](charts/EVT-20260725-host13-005.svg)

# イベントID( EVT-20260725-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→14→…→9→8→11→10
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 20:15:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.099, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.8 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260725-host13-006 active_connections の推移](charts/EVT-20260725-host13-006.svg)

# イベントID( EVT-20260725-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→10→…→12→11→13→11
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 20:00:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.908, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260725-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.5 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間

![EVT-20260725-host13-007 active_connections の推移](charts/EVT-20260725-host13-007.svg)

# イベントID( EVT-20260726-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→12→16→13→14
* 開始   : 2026-07-26 06:40:00 (UTC)
* 終了   : 2026-07-26 06:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→13→12
* 開始   : 2026-07-26 15:45:00 (UTC)
* 終了   : 2026-07-26 15:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→14→14
* 開始   : 2026-07-26 16:05:00 (UTC)
* 終了   : 2026-07-26 16:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→9→9
* 開始   : 2026-07-26 22:55:00 (UTC)
* 終了   : 2026-07-26 22:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.4248(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.781σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260726-host13-006 active_connections の推移](charts/EVT-20260726-host13-006.svg)

# イベントID( EVT-20260727-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→11→14→8→9
* 開始   : 2026-07-27 02:10:00 (UTC)
* 終了   : 2026-07-27 02:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.57倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→18→16→15→…→13→14→13→12
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 12から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.17, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→8→4→8→9
* 開始   : 2026-07-27 23:55:00 (UTC)
* 終了   : 2026-07-27 23:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260727-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→12→11
* 開始   : 2026-07-28 03:45:00 (UTC)
* 終了   : 2026-07-28 03:45:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→19→13→17→18
* 開始   : 2026-07-28 16:45:00 (UTC)
* 終了   : 2026-07-28 16:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.53σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host13-009 active_connections の推移](charts/EVT-20260728-host13-009.svg)

# イベントID( EVT-20260728-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→11→8→14→11
* 開始   : 2026-07-28 19:50:00 (UTC)
* 終了   : 2026-07-28 19:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→8→6→…→8→6→10→9
* 開始   : 2026-07-28 21:10:00 (UTC)
* 終了   : 2026-07-28 21:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260728-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→9→9
* 開始   : 2026-07-29 02:50:00 (UTC)
* 終了   : 2026-07-29 02:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→17→16→…→17→16→13→15
* 開始   : 2026-07-29 05:20:00 (UTC)
* 終了   : 2026-07-29 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→13→17→15→15
* 開始   : 2026-07-29 05:35:00 (UTC)
* 終了   : 2026-07-29 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.11σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→16→19→23→16→19→23→18→19
* 開始   : 2026-07-29 07:40:00 (UTC)
* 終了   : 2026-07-29 08:45:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.1 時間
  - EVT-20260729-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260729-host13-006 active_connections の推移](charts/EVT-20260729-host13-006.svg)

# イベントID( EVT-20260729-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→8→…→8→9→12→11
* 開始   : 2026-07-29 19:30:00 (UTC)
* 終了   : 2026-07-29 19:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→12→13→10→10→11
* 開始   : 2026-07-30 02:20:00 (UTC)
* 終了   : 2026-07-30 02:45:00 (UTC)
* 現象   : 2026-07-30 02:45:00 (UTC)を境に水準が 14.84から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→13→15→13→12
* 開始   : 2026-07-30 04:20:00 (UTC)
* 終了   : 2026-07-30 04:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→12→16→13→14
* 開始   : 2026-07-30 04:45:00 (UTC)
* 終了   : 2026-07-30 04:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→19→14→14→12→15→16→17
* 開始   : 2026-07-30 05:25:00 (UTC)
* 終了   : 2026-07-30 06:00:00 (UTC)
* 現象   : 2026-07-30 06:00:00 (UTC)を境に水準が 14.88から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host13-004 active_connections の推移](charts/EVT-20260730-host13-004.svg)

# イベントID( EVT-20260730-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→16→17→19→17→16
* 開始   : 2026-07-30 06:10:00 (UTC)
* 終了   : 2026-07-30 06:15:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→16→20→22
* 開始   : 2026-07-30 09:50:00 (UTC)
* 終了   : 2026-07-30 09:50:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→10→6→8→9
* 開始   : 2026-07-30 21:20:00 (UTC)
* 終了   : 2026-07-30 21:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→9→8
* 開始   : 2026-07-30 21:25:00 (UTC)
* 終了   : 2026-07-30 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→7→13→11→10
* 開始   : 2026-07-31 02:45:00 (UTC)
* 終了   : 2026-07-31 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→17→15→13→…→13→14→16→15
* 開始   : 2026-07-31 16:45:00 (UTC)
* 終了   : 2026-07-31 16:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→16→13→15→17
* 開始   : 2026-07-31 16:55:00 (UTC)
* 終了   : 2026-07-31 16:55:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→14→9→11→12
* 開始   : 2026-07-31 19:25:00 (UTC)
* 終了   : 2026-07-31 19:25:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→12→13→13
* 開始   : 2026-07-01 03:30:00 (UTC)
* 終了   : 2026-07-01 03:45:00 (UTC)
* 現象   : 2026-07-01 03:45:00 (UTC)を境に水準が 15.2から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→13→16→13→16→13→15
* 開始   : 2026-07-01 05:20:00 (UTC)
* 終了   : 2026-07-01 05:30:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260701-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→17→18→17
* 開始   : 2026-07-01 06:20:00 (UTC)
* 終了   : 2026-07-01 06:25:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→19→…→19→21→20→19
* 開始   : 2026-07-01 08:05:00 (UTC)
* 終了   : 2026-07-01 08:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260701-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 22→21→18→20→21→18→20
* 開始   : 2026-07-01 15:10:00 (UTC)
* 終了   : 2026-07-01 15:15:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→15→18→15→18→15→17
* 開始   : 2026-07-01 16:40:00 (UTC)
* 終了   : 2026-07-01 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→13→16→13→…→15→12→14→13
* 開始   : 2026-07-01 18:00:00 (UTC)
* 終了   : 2026-07-01 18:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260701-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host02-013 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260701-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 7→10→12→11→…→11→6→8→7
* 開始   : 2026-07-01 23:20:00 (UTC)
* 終了   : 2026-07-01 23:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→13→10→8→13→10→9
* 開始   : 2026-07-02 03:00:00 (UTC)
* 終了   : 2026-07-02 03:05:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260702-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→17→15→17→16→17
* 開始   : 2026-07-02 05:55:00 (UTC)
* 終了   : 2026-07-02 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260702-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→22→16→18→20→22→16→18→20
* 開始   : 2026-07-02 08:30:00 (UTC)
* 終了   : 2026-07-02 08:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 22→24→22→23→24→23→22→26
* 開始   : 2026-07-02 12:00:00 (UTC)
* 終了   : 2026-07-02 12:35:00 (UTC)
* 現象   : 2026-07-02 12:35:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→21→18→22→18→22→18→21→23
* 開始   : 2026-07-02 14:15:00 (UTC)
* 終了   : 2026-07-02 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→21→16→20→21→16→20
* 開始   : 2026-07-02 15:20:00 (UTC)
* 終了   : 2026-07-02 15:25:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7934(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.934σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260702-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→16→15→18→16→15→18
* 開始   : 2026-07-02 16:55:00 (UTC)
* 終了   : 2026-07-02 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→7→12→7→12→7→12→11
* 開始   : 2026-07-02 20:45:00 (UTC)
* 終了   : 2026-07-02 20:55:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→11→7→8→7→8→7→10→8
* 開始   : 2026-07-02 21:25:00 (UTC)
* 終了   : 2026-07-02 21:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host02-021 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→12→14→12→14→12
* 開始   : 2026-07-03 03:55:00 (UTC)
* 終了   : 2026-07-03 04:00:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.436倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.971σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→15→16→17→15→18→18→17
* 開始   : 2026-07-03 06:00:00 (UTC)
* 終了   : 2026-07-03 06:45:00 (UTC)
* 現象   : 2026-07-03 06:45:00 (UTC)を境に水準が 14.99から14.67へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.875, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→19→16→17→19→16
* 開始   : 2026-07-03 06:35:00 (UTC)
* 終了   : 2026-07-03 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→23→25→19→21→23→25→19→21
* 開始   : 2026-07-03 12:25:00 (UTC)
* 終了   : 2026-07-03 12:30:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→16→14→13→12→13→14
* 開始   : 2026-07-03 17:45:00 (UTC)
* 終了   : 2026-07-03 19:15:00 (UTC)
* 現象   : 2026-07-03 19:15:00 (UTC)を境に水準が 14.97から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.562, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→11→10→11→10→13→11
* 開始   : 2026-07-03 19:40:00 (UTC)
* 終了   : 2026-07-03 19:50:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→9→8→10→…→10→9→10→13
* 開始   : 2026-07-04 04:35:00 (UTC)
* 終了   : 2026-07-04 05:15:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分

![EVT-20260704-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host13-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→9→10→11→…→10→11→13→11
* 開始   : 2026-07-04 18:35:00 (UTC)
* 終了   : 2026-07-04 18:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.903, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分

![EVT-20260704-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host13-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→9→8→9→…→8→9→12→10
* 開始   : 2026-07-04 20:30:00 (UTC)
* 終了   : 2026-07-04 20:35:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.796, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260704-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→9→10→10→12→10→10→11→11
* 開始   : 2026-07-05 03:25:00 (UTC)
* 終了   : 2026-07-05 04:35:00 (UTC)
* 現象   : 2026-07-05 04:35:00 (UTC)を境に水準が 11.64から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→13→…→13→15→13→15
* 開始   : 2026-07-05 06:35:00 (UTC)
* 終了   : 2026-07-05 06:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260705-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→18→14→12→18→14→16
* 開始   : 2026-07-05 10:35:00 (UTC)
* 終了   : 2026-07-05 10:40:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→14→14→13
* 開始   : 2026-07-05 17:30:00 (UTC)
* 終了   : 2026-07-05 17:45:00 (UTC)
* 現象   : 2026-07-05 17:45:00 (UTC)を境に水準が 11.84から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→13→…→13→8→10→9
* 開始   : 2026-07-05 19:05:00 (UTC)
* 終了   : 2026-07-05 19:15:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→11→11→11→13
* 開始   : 2026-07-05 19:45:00 (UTC)
* 終了   : 2026-07-05 20:05:00 (UTC)
* 現象   : 2026-07-05 20:05:00 (UTC)を境に水準が 11.66から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→7→10→11→11→8→9
* 開始   : 2026-07-05 21:10:00 (UTC)
* 終了   : 2026-07-05 21:45:00 (UTC)
* 現象   : 2026-07-05 21:45:00 (UTC)を境に水準が 11.72から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→9→12→8→…→8→6→10→9
* 開始   : 2026-07-05 22:15:00 (UTC)
* 終了   : 2026-07-05 22:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→7→6→7→6→9→7
* 開始   : 2026-07-06 22:15:00 (UTC)
* 終了   : 2026-07-06 22:25:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260706-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→8→9→9→11→10
* 開始   : 2026-07-06 23:45:00 (UTC)
* 終了   : 2026-07-07 00:10:00 (UTC)
* 現象   : 2026-07-07 00:10:00 (UTC)を境に水準が 14.93から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.545, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→16→17→16→18→17→16→18→16
* 開始   : 2026-07-07 06:15:00 (UTC)
* 終了   : 2026-07-07 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→21→20→22→21→20→22→21
* 開始   : 2026-07-07 08:40:00 (UTC)
* 終了   : 2026-07-07 08:50:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260707-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260707-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 22→21→25→19→…→25→19→23→20
* 開始   : 2026-07-07 12:25:00 (UTC)
* 終了   : 2026-07-07 12:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→16→…→13→16→13→14
* 開始   : 2026-07-07 17:40:00 (UTC)
* 終了   : 2026-07-07 18:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260707-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→15→12→15
* 開始   : 2026-07-07 18:25:00 (UTC)
* 終了   : 2026-07-07 18:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→8→7→6→7→6→9
* 開始   : 2026-07-07 22:05:00 (UTC)
* 終了   : 2026-07-07 22:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→5→7→5→7→5→7→6
* 開始   : 2026-07-07 23:15:00 (UTC)
* 終了   : 2026-07-07 23:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→8→9→10→8→8→9
* 開始   : 2026-07-08 00:15:00 (UTC)
* 終了   : 2026-07-08 01:00:00 (UTC)
* 現象   : 2026-07-08 01:00:00 (UTC)を境に水準が 14.79から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→11→12→10→11→12→10→12
* 開始   : 2026-07-08 02:55:00 (UTC)
* 終了   : 2026-07-08 03:00:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260708-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→16→15→16→17→16→15
* 開始   : 2026-07-08 05:45:00 (UTC)
* 終了   : 2026-07-08 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→14→15→18→14→15
* 開始   : 2026-07-08 06:10:00 (UTC)
* 終了   : 2026-07-08 06:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→19→18→17→20→20→19→21
* 開始   : 2026-07-08 07:40:00 (UTC)
* 終了   : 2026-07-08 08:15:00 (UTC)
* 現象   : 2026-07-08 08:15:00 (UTC)を境に水準が 14.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→18→20→19→…→19→21→18→19
* 開始   : 2026-07-08 07:45:00 (UTC)
* 終了   : 2026-07-08 07:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 24→25→22→25→23→23→21→25→24
* 開始   : 2026-07-08 10:20:00 (UTC)
* 終了   : 2026-07-08 12:05:00 (UTC)
* 現象   : 2026-07-08 12:05:00 (UTC)を境に水準が 15.07から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 23→20→18→22→18→22→18→19
* 開始   : 2026-07-08 14:00:00 (UTC)
* 終了   : 2026-07-08 14:10:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260708-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→15→13→16→13→16→13→14→17
* 開始   : 2026-07-08 17:40:00 (UTC)
* 終了   : 2026-07-08 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→14→11→12→14→11→14
* 開始   : 2026-07-08 18:50:00 (UTC)
* 終了   : 2026-07-08 19:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→14→9→12→…→12→15→11→10
* 開始   : 2026-07-08 20:35:00 (UTC)
* 終了   : 2026-07-08 20:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-075 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→14→12→14→12→14→14
* 開始   : 2026-07-09 04:10:00 (UTC)
* 終了   : 2026-07-09 04:40:00 (UTC)
* 現象   : 2026-07-09 04:40:00 (UTC)を境に水準が 15.1から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→15→…→14→15→13→12
* 開始   : 2026-07-09 04:15:00 (UTC)
* 終了   : 2026-07-09 04:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→19→20→15→16→19→20→15→19
* 開始   : 2026-07-09 07:10:00 (UTC)
* 終了   : 2026-07-09 07:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 20→21→20→21→18→20→20→17→20
* 開始   : 2026-07-09 15:10:00 (UTC)
* 終了   : 2026-07-09 16:25:00 (UTC)
* 現象   : 2026-07-09 16:25:00 (UTC)を境に水準が 14.94から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→11→14→11→13→12
* 開始   : 2026-07-09 19:05:00 (UTC)
* 終了   : 2026-07-09 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260709-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→15→11→15→11→14
* 開始   : 2026-07-09 19:05:00 (UTC)
* 終了   : 2026-07-09 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→12→15→12→15→14
* 開始   : 2026-07-10 04:40:00 (UTC)
* 終了   : 2026-07-10 04:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→15→…→14→9→15→14
* 開始   : 2026-07-10 04:45:00 (UTC)
* 終了   : 2026-07-10 04:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→18→19→17→15→18→19→17→18
* 開始   : 2026-07-10 07:00:00 (UTC)
* 終了   : 2026-07-10 07:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→17→…→17→13→16→14
* 開始   : 2026-07-10 17:35:00 (UTC)
* 終了   : 2026-07-10 17:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→9→11→9→…→9→12→8→10
* 開始   : 2026-07-11 02:35:00 (UTC)
* 終了   : 2026-07-11 02:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260711-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→8→…→9→8→13→10
* 開始   : 2026-07-11 19:25:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→7→12→10→7→12→10→9
* 開始   : 2026-07-12 03:35:00 (UTC)
* 終了   : 2026-07-12 03:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.582σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260712-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260712-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→14→14→13→13
* 開始   : 2026-07-12 07:05:00 (UTC)
* 終了   : 2026-07-12 07:25:00 (UTC)
* 現象   : 2026-07-12 07:25:00 (UTC)を境に水準が 11.91から12.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→18→19
* 開始   : 2026-07-12 11:10:00 (UTC)
* 終了   : 2026-07-12 11:35:00 (UTC)
* 現象   : 2026-07-12 11:35:00 (UTC)を境に水準が 11.84から13.37へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→12→11→10
* 開始   : 2026-07-12 19:40:00 (UTC)
* 終了   : 2026-07-12 20:05:00 (UTC)
* 現象   : 2026-07-12 20:05:00 (UTC)を境に水準が 11.86から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→8→6→9→5→6→9→5→7
* 開始   : 2026-07-13 22:45:00 (UTC)
* 終了   : 2026-07-13 22:55:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260713-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→13→11→10→13→11→10
* 開始   : 2026-07-14 03:15:00 (UTC)
* 終了   : 2026-07-14 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→13→14→16→17→13→16
* 開始   : 2026-07-14 05:45:00 (UTC)
* 終了   : 2026-07-14 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→22→25→23→22→23→21→22→25
* 開始   : 2026-07-14 11:45:00 (UTC)
* 終了   : 2026-07-14 12:30:00 (UTC)
* 現象   : 2026-07-14 12:30:00 (UTC)を境に水準が 14.92から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→19→17→21→19→17→21→22
* 開始   : 2026-07-14 14:55:00 (UTC)
* 終了   : 2026-07-14 15:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→20→17→18→20→17→18→21
* 開始   : 2026-07-14 15:45:00 (UTC)
* 終了   : 2026-07-14 15:50:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260714-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→18→16→18→16→18→17
* 開始   : 2026-07-14 16:20:00 (UTC)
* 終了   : 2026-07-14 16:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→14→12→14→12→14→12→13→14
* 開始   : 2026-07-14 18:25:00 (UTC)
* 終了   : 2026-07-14 18:35:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260714-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→13→11→13→14
* 開始   : 2026-07-14 19:05:00 (UTC)
* 終了   : 2026-07-14 19:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→12→12→13→13→11→11→12→14
* 開始   : 2026-07-14 20:00:00 (UTC)
* 終了   : 2026-07-14 21:10:00 (UTC)
* 現象   : 2026-07-14 21:10:00 (UTC)を境に水準が 14.95から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.818, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→9→13→6→9→13→6→9
* 開始   : 2026-07-14 22:30:00 (UTC)
* 終了   : 2026-07-14 22:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.486倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→8→9→9→8→6→10→12
* 開始   : 2026-07-14 22:40:00 (UTC)
* 終了   : 2026-07-14 23:20:00 (UTC)
* 現象   : 2026-07-14 23:20:00 (UTC)を境に水準が 15.01から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→8→8→8→12
* 開始   : 2026-07-14 23:40:00 (UTC)
* 終了   : 2026-07-15 00:10:00 (UTC)
* 現象   : 2026-07-15 00:10:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.312, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→20→…→22→21→22→19
* 開始   : 2026-07-15 08:25:00 (UTC)
* 終了   : 2026-07-15 08:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→22→25→22→25→22→21
* 開始   : 2026-07-15 12:25:00 (UTC)
* 終了   : 2026-07-15 12:30:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 19→17→20→17→20→17→19→21
* 開始   : 2026-07-15 15:30:00 (UTC)
* 終了   : 2026-07-15 15:40:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→18→15→14→…→15→14→17→16
* 開始   : 2026-07-15 16:45:00 (UTC)
* 終了   : 2026-07-15 16:50:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→16→14→13→…→14→13→15→16
* 開始   : 2026-07-15 17:30:00 (UTC)
* 終了   : 2026-07-15 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→8→11→7→8→11→7→9
* 開始   : 2026-07-15 20:45:00 (UTC)
* 終了   : 2026-07-15 20:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260715-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→11→15→12→15→12→15→12→15
* 開始   : 2026-07-16 04:40:00 (UTC)
* 終了   : 2026-07-16 04:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.582σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260716-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260716-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→21→19→20→21→19→23
* 開始   : 2026-07-16 08:10:00 (UTC)
* 終了   : 2026-07-16 10:35:00 (UTC)
* 現象   : 2026-07-16 10:35:00 (UTC)を境に水準が 14.91から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.453, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→20→22→19→…→19→22→20→18
* 開始   : 2026-07-16 08:45:00 (UTC)
* 終了   : 2026-07-16 09:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.817σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260716-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→20→20→19→21→20→21→19→21
* 開始   : 2026-07-16 14:10:00 (UTC)
* 終了   : 2026-07-16 15:25:00 (UTC)
* 現象   : 2026-07-16 15:25:00 (UTC)を境に水準が 14.94から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→18→17→20→18→17→20→19
* 開始   : 2026-07-16 15:10:00 (UTC)
* 終了   : 2026-07-16 15:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→22→16→19→…→18→15→18→16
* 開始   : 2026-07-16 16:15:00 (UTC)
* 終了   : 2026-07-16 16:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→14→…→14→11→14→13
* 開始   : 2026-07-16 18:40:00 (UTC)
* 終了   : 2026-07-16 19:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→11→16→14→11→16→12
* 開始   : 2026-07-16 19:10:00 (UTC)
* 終了   : 2026-07-16 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→11→10→11→10→11→13
* 開始   : 2026-07-16 19:20:00 (UTC)
* 終了   : 2026-07-16 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260716-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→12→14
* 開始   : 2026-07-17 04:00:00 (UTC)
* 終了   : 2026-07-17 04:50:00 (UTC)
* 現象   : 2026-07-17 04:50:00 (UTC)を境に水準が 15.04から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.863, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→9→12→10→10→10
* 開始   : 2026-07-17 20:50:00 (UTC)
* 終了   : 2026-07-17 21:25:00 (UTC)
* 現象   : 2026-07-17 21:25:00 (UTC)を境に水準が 14.97から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→7→…→7→14→12→10
* 開始   : 2026-07-18 04:30:00 (UTC)
* 終了   : 2026-07-18 04:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260718-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→10→9→10→9→8
* 開始   : 2026-07-18 23:05:00 (UTC)
* 終了   : 2026-07-18 23:30:00 (UTC)
* 現象   : 2026-07-18 23:30:00 (UTC)を境に水準が 11.71から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260718-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→9→9→10→10
* 開始   : 2026-07-19 00:35:00 (UTC)
* 終了   : 2026-07-19 01:50:00 (UTC)
* 現象   : 2026-07-19 01:50:00 (UTC)を境に水準が 11.77から11.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→8→5→8→5→8
* 開始   : 2026-07-19 02:20:00 (UTC)
* 終了   : 2026-07-19 02:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.566(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→12→16→14→15
* 開始   : 2026-07-19 15:15:00 (UTC)
* 終了   : 2026-07-19 15:35:00 (UTC)
* 現象   : 2026-07-19 15:35:00 (UTC)を境に水準が 11.87から14.3へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→14→16→12→15→15→14→14→14
* 開始   : 2026-07-19 15:45:00 (UTC)
* 終了   : 2026-07-19 16:30:00 (UTC)
* 現象   : 2026-07-19 16:30:00 (UTC)を境に水準が 11.88から14.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.875, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→12→11→6→12→11→6→8→6
* 開始   : 2026-07-20 23:00:00 (UTC)
* 終了   : 2026-07-20 23:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260720-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260720-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→8→12→8→12→11→9
* 開始   : 2026-07-21 02:20:00 (UTC)
* 終了   : 2026-07-21 02:30:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.455倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→13→…→12→13→12→11
* 開始   : 2026-07-21 03:20:00 (UTC)
* 終了   : 2026-07-21 03:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260721-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→14→17→18→…→17→18→19→16
* 開始   : 2026-07-21 06:10:00 (UTC)
* 終了   : 2026-07-21 06:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260721-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→16→19→16→…→16→20→17→19
* 開始   : 2026-07-21 07:00:00 (UTC)
* 終了   : 2026-07-21 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→20→…→19→20→19→18
* 開始   : 2026-07-21 07:30:00 (UTC)
* 終了   : 2026-07-21 07:35:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260721-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→18→14→17→18→14→17→16
* 開始   : 2026-07-21 17:05:00 (UTC)
* 終了   : 2026-07-21 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260721-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→13→12→13
* 開始   : 2026-07-21 18:35:00 (UTC)
* 終了   : 2026-07-21 18:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260721-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→9→13→9→…→7→10→6→9
* 開始   : 2026-07-21 21:40:00 (UTC)
* 終了   : 2026-07-21 22:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host13-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→10→7→10→7→9→7→9→8
* 開始   : 2026-07-21 21:45:00 (UTC)
* 終了   : 2026-07-21 21:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host13-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→12→8→12→8→12→11
* 開始   : 2026-07-22 02:10:00 (UTC)
* 終了   : 2026-07-22 02:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→12→10→9→10→11→10→12→11
* 開始   : 2026-07-22 02:15:00 (UTC)
* 終了   : 2026-07-22 02:55:00 (UTC)
* 現象   : 2026-07-22 02:55:00 (UTC)を境に水準が 15.02から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.631, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→12→15→16→12→14
* 開始   : 2026-07-22 05:40:00 (UTC)
* 終了   : 2026-07-22 05:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→18→17→19→18→19
* 開始   : 2026-07-22 07:00:00 (UTC)
* 終了   : 2026-07-22 07:05:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 19→20→21→19→20→21→19→18
* 開始   : 2026-07-22 07:40:00 (UTC)
* 終了   : 2026-07-22 07:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→18→21→21→24→21→22→22→22
* 開始   : 2026-07-22 08:05:00 (UTC)
* 終了   : 2026-07-22 10:25:00 (UTC)
* 現象   : 2026-07-22 10:25:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→14→…→14→11→14→13
* 開始   : 2026-07-22 18:55:00 (UTC)
* 終了   : 2026-07-22 19:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→14→11→12
* 開始   : 2026-07-22 19:05:00 (UTC)
* 終了   : 2026-07-22 19:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host13-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→11
* 開始   : 2026-07-22 23:30:00 (UTC)
* 終了   : 2026-07-22 23:45:00 (UTC)
* 現象   : 2026-07-22 23:45:00 (UTC)を境に水準が 15.06から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→12→15→12→14
* 開始   : 2026-07-23 04:20:00 (UTC)
* 終了   : 2026-07-23 04:25:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→16→20→18→20→18→20→18→15
* 開始   : 2026-07-23 07:30:00 (UTC)
* 終了   : 2026-07-23 07:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260723-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260723-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 23→22→18→25→…→18→25→20→23
* 開始   : 2026-07-23 10:25:00 (UTC)
* 終了   : 2026-07-23 10:30:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host13-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→12
* 開始   : 2026-07-23 20:00:00 (UTC)
* 終了   : 2026-07-23 20:15:00 (UTC)
* 現象   : 2026-07-23 20:15:00 (UTC)を境に水準が 15.1から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→11→10→8→8→8→9→9→10
* 開始   : 2026-07-24 00:15:00 (UTC)
* 終了   : 2026-07-24 01:10:00 (UTC)
* 現象   : 2026-07-24 01:10:00 (UTC)を境に水準が 15.03から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→13→13→16→14→12→15→16→18
* 開始   : 2026-07-24 04:15:00 (UTC)
* 終了   : 2026-07-24 06:15:00 (UTC)
* 現象   : 2026-07-24 06:15:00 (UTC)を境に水準が 14.93から14.64へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.622, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→16→23→20→…→19→16→23→19
* 開始   : 2026-07-24 14:35:00 (UTC)
* 終了   : 2026-07-24 14:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.912σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→10→12→10→…→10→6→10→12
* 開始   : 2026-07-25 02:50:00 (UTC)
* 終了   : 2026-07-25 03:00:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→9→7→8→9→9→10→9
* 開始   : 2026-07-26 00:45:00 (UTC)
* 終了   : 2026-07-26 01:20:00 (UTC)
* 現象   : 2026-07-26 01:20:00 (UTC)を境に水準が 11.81から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→12→7→8→13→7→8→13→9
* 開始   : 2026-07-26 19:55:00 (UTC)
* 終了   : 2026-07-26 20:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260726-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→6→10→12→6→10→8
* 開始   : 2026-07-27 02:15:00 (UTC)
* 終了   : 2026-07-27 02:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260727-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260727-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→9→7→9→9→8→9
* 開始   : 2026-07-28 00:35:00 (UTC)
* 終了   : 2026-07-28 01:05:00 (UTC)
* 現象   : 2026-07-28 01:05:00 (UTC)を境に水準が 15.02から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.511, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 8→5→8→11→5→8→11→8→9
* 開始   : 2026-07-28 00:55:00 (UTC)
* 終了   : 2026-07-28 01:05:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→10→12→9→10→12→9→8
* 開始   : 2026-07-28 02:30:00 (UTC)
* 終了   : 2026-07-28 02:35:00 (UTC)
* 現象   : 平常時(8)に対し 1.5倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.791σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260728-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→16→18→15→18→15→18→17→18
* 開始   : 2026-07-28 06:20:00 (UTC)
* 終了   : 2026-07-28 06:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→21→23→19→…→23→21→24→21
* 開始   : 2026-07-28 10:00:00 (UTC)
* 終了   : 2026-07-28 10:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→20→17→16→…→17→16→17→19
* 開始   : 2026-07-28 15:40:00 (UTC)
* 終了   : 2026-07-28 15:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260728-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→15→17→15→17→15→19
* 開始   : 2026-07-28 16:15:00 (UTC)
* 終了   : 2026-07-28 16:25:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→7→6→8→11→7→6→8→9
* 開始   : 2026-07-28 21:35:00 (UTC)
* 終了   : 2026-07-28 21:40:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260728-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→10→14→13→10→14→12
* 開始   : 2026-07-29 03:35:00 (UTC)
* 終了   : 2026-07-29 03:45:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→14→12→14→12→14→12→13
* 開始   : 2026-07-29 03:55:00 (UTC)
* 終了   : 2026-07-29 04:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.388倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 22→18→20→18→20→19
* 開始   : 2026-07-29 15:40:00 (UTC)
* 終了   : 2026-07-29 16:05:00 (UTC)
* 現象   : 2026-07-29 16:05:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 19→17→13→16→17→13→16→15
* 開始   : 2026-07-29 17:30:00 (UTC)
* 終了   : 2026-07-29 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→12→13→9→7→13→9→7→9
* 開始   : 2026-07-29 21:15:00 (UTC)
* 終了   : 2026-07-29 21:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host13-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→12
* 開始   : 2026-07-29 21:35:00 (UTC)
* 終了   : 2026-07-29 21:40:00 (UTC)
* 現象   : 2026-07-29 21:40:00 (UTC)を境に水準が 15.02から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.182, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→18→18→18→20→17→17
* 開始   : 2026-07-30 06:40:00 (UTC)
* 終了   : 2026-07-30 07:10:00 (UTC)
* 現象   : 2026-07-30 07:10:00 (UTC)を境に水準が 14.97から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.713, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→19→16→19→16→18
* 開始   : 2026-07-30 07:10:00 (UTC)
* 終了   : 2026-07-30 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.347σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→21→19→…→19→22→21→19
* 開始   : 2026-07-30 08:35:00 (UTC)
* 終了   : 2026-07-30 09:55:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260730-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 25→23→24→24→24
* 開始   : 2026-07-30 11:10:00 (UTC)
* 終了   : 2026-07-30 11:30:00 (UTC)
* 現象   : 2026-07-30 11:30:00 (UTC)を境に水準が 15から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→19→25→22→19→25→22→21
* 開始   : 2026-07-30 11:25:00 (UTC)
* 終了   : 2026-07-30 11:30:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→21→18→17→21→18→17→21→20
* 開始   : 2026-07-30 14:50:00 (UTC)
* 終了   : 2026-07-30 14:55:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→8→6→9→8→6→9→10
* 開始   : 2026-07-30 22:50:00 (UTC)
* 終了   : 2026-07-30 22:55:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→13→14→8→…→8→14→13→12
* 開始   : 2026-07-31 04:20:00 (UTC)
* 終了   : 2026-07-31 05:35:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260731-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260731-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260731-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→21→18→21→18→21→18
* 開始   : 2026-07-31 08:05:00 (UTC)
* 終了   : 2026-07-31 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 23→20→25→21→20→25→21
* 開始   : 2026-07-31 10:55:00 (UTC)
* 終了   : 2026-07-31 11:00:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.181倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→16→13→16→13→17→15
* 開始   : 2026-07-31 17:40:00 (UTC)
* 終了   : 2026-07-31 17:50:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-host02-015 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260731-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→11→13→17→11→13→17→13→15
* 開始   : 2026-07-31 19:00:00 (UTC)
* 終了   : 2026-07-31 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→10→9→8→10→9→8→10→9
* 開始   : 2026-07-31 20:40:00 (UTC)
* 終了   : 2026-07-31 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260731-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→9→8→7→9→8→7→9→12
* 開始   : 2026-07-31 21:20:00 (UTC)
* 終了   : 2026-07-31 21:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host13-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
