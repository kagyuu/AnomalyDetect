# host05 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host05 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 337 (SEVERE: 19, FATAL: 133, WARN: 185, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 133 | 185 | 337 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260705-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→18→16→17→…→13→14→13→14
* 開始   : 2026-07-05 23:20:00 (UTC)
* 終了   : 2026-07-06 19:55:00 (UTC)
* 現象   : 2026-07-06 19:55:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.588σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.88, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.437, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host05-011 active_connections の推移](charts/EVT-20260705-host05-011.svg)

# イベントID( EVT-20260706-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→16→17→16→…→13→14→13→14
* 開始   : 2026-07-06 02:25:00 (UTC)
* 終了   : 2026-07-06 19:35:00 (UTC)
* 現象   : 2026-07-06 19:35:00 (UTC)を境に水準が 11.73から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.953, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.736, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-002 active_connections の推移](charts/EVT-20260706-host05-002.svg)

# イベントID( EVT-20260706-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→17→…→12→14→13→14
* 開始   : 2026-07-06 03:35:00 (UTC)
* 終了   : 2026-07-06 21:40:00 (UTC)
* 現象   : 2026-07-06 21:40:00 (UTC)を境に水準が 12から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.807, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-003 active_connections の推移](charts/EVT-20260706-host05-003.svg)

# イベントID( EVT-20260706-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→…→13→15→12→10
* 開始   : 2026-07-06 03:55:00 (UTC)
* 終了   : 2026-07-06 21:40:00 (UTC)
* 現象   : 2026-07-06 21:40:00 (UTC)を境に水準が 11.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-004 active_connections の推移](charts/EVT-20260706-host05-004.svg)

# イベントID( EVT-20260706-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→15→…→13→16→14→11
* 開始   : 2026-07-06 03:55:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 12.03から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.843, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.959, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-005 active_connections の推移](charts/EVT-20260706-host05-005.svg)

# イベントID( EVT-20260706-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→17→16→19→…→11→13→9→11
* 開始   : 2026-07-06 04:35:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 11.92から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.065, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-006 active_connections の推移](charts/EVT-20260706-host05-006.svg)

# イベントID( EVT-20260713-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→16→17→16→…→12→13→11→13
* 開始   : 2026-07-13 01:10:00 (UTC)
* 終了   : 2026-07-13 19:20:00 (UTC)
* 現象   : 2026-07-13 19:20:00 (UTC)を境に水準が 11.84から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.95, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.741, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-001 active_connections の推移](charts/EVT-20260713-host05-001.svg)

# イベントID( EVT-20260713-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→17→15→14→…→13→12→13→12
* 開始   : 2026-07-13 02:20:00 (UTC)
* 終了   : 2026-07-13 19:30:00 (UTC)
* 現象   : 2026-07-13 19:30:00 (UTC)を境に水準が 11.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.74, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-002 active_connections の推移](charts/EVT-20260713-host05-002.svg)

# イベントID( EVT-20260713-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→17→16→15→…→11→16→11→14
* 開始   : 2026-07-13 03:10:00 (UTC)
* 終了   : 2026-07-13 19:10:00 (UTC)
* 現象   : 2026-07-13 19:10:00 (UTC)を境に水準が 11.88から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.858, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-006 active_connections の推移](charts/EVT-20260713-host05-006.svg)

# イベントID( EVT-20260720-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→18→17→16→…→13→14→12→14
* 開始   : 2026-07-20 02:30:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.82から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.713, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-002 active_connections の推移](charts/EVT-20260720-host05-002.svg)

# イベントID( EVT-20260720-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→13→15→…→14→12→11→13
* 開始   : 2026-07-20 02:50:00 (UTC)
* 終了   : 2026-07-20 19:20:00 (UTC)
* 現象   : 2026-07-20 19:20:00 (UTC)を境に水準が 11.77から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.286, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-004 active_connections の推移](charts/EVT-20260720-host05-004.svg)

# イベントID( EVT-20260720-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→16→…→14→11→14→13
* 開始   : 2026-07-20 02:55:00 (UTC)
* 終了   : 2026-07-20 20:15:00 (UTC)
* 現象   : 2026-07-20 20:15:00 (UTC)を境に水準が 11.94から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.898, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-006 active_connections の推移](charts/EVT-20260720-host05-006.svg)

# イベントID( EVT-20260720-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→13→16→19→…→14→13→12→14
* 開始   : 2026-07-20 03:55:00 (UTC)
* 終了   : 2026-07-20 22:15:00 (UTC)
* 現象   : 2026-07-20 22:15:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.906, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-007 active_connections の推移](charts/EVT-20260720-host05-007.svg)

# イベントID( EVT-20260720-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→16→15→16→…→16→14→12→13
* 開始   : 2026-07-20 04:45:00 (UTC)
* 終了   : 2026-07-20 20:00:00 (UTC)
* 現象   : 2026-07-20 20:00:00 (UTC)を境に水準が 12.09から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.939, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-008 active_connections の推移](charts/EVT-20260720-host05-008.svg)

# イベントID( EVT-20260727-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→13→15→16→…→14→13→14→12
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 19:30:00 (UTC)
* 現象   : 2026-07-27 19:30:00 (UTC)を境に水準が 11.89から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.705, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-003 active_connections の推移](charts/EVT-20260727-host05-003.svg)

# イベントID( EVT-20260727-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→15→18→19→…→16→12→14→15
* 開始   : 2026-07-27 03:20:00 (UTC)
* 終了   : 2026-07-27 20:40:00 (UTC)
* 現象   : 2026-07-27 20:40:00 (UTC)を境に水準が 11.89から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.044, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-004 active_connections の推移](charts/EVT-20260727-host05-004.svg)

# イベントID( EVT-20260727-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→14→…→14→13→12→10
* 開始   : 2026-07-27 03:45:00 (UTC)
* 終了   : 2026-07-27 20:35:00 (UTC)
* 現象   : 2026-07-27 20:35:00 (UTC)を境に水準が 11.93から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.588σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-005 active_connections の推移](charts/EVT-20260727-host05-005.svg)

# イベントID( EVT-20260727-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→17→…→12→14→13→12
* 開始   : 2026-07-27 03:55:00 (UTC)
* 終了   : 2026-07-27 20:55:00 (UTC)
* 現象   : 2026-07-27 20:55:00 (UTC)を境に水準が 12.01から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.793, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-006 active_connections の推移](charts/EVT-20260727-host05-006.svg)

# イベントID( EVT-20260727-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→13→17→15→…→13→12→14→12
* 開始   : 2026-07-27 04:10:00 (UTC)
* 終了   : 2026-07-27 21:35:00 (UTC)
* 現象   : 2026-07-27 21:35:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.023, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-007 active_connections の推移](charts/EVT-20260727-host05-007.svg)

# イベントID( EVT-20260701-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→13→18→14→13
* 開始   : 2026-07-01 05:35:00 (UTC)
* 終了   : 2026-07-01 05:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→19→19
* 開始   : 2026-07-01 14:50:00 (UTC)
* 終了   : 2026-07-01 14:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 21→20→15→19→19
* 開始   : 2026-07-01 15:55:00 (UTC)
* 終了   : 2026-07-01 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→11→8→13→11
* 開始   : 2026-07-01 19:45:00 (UTC)
* 終了   : 2026-07-01 19:45:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host05-016 active_connections の推移](charts/EVT-20260701-host05-016.svg)

# イベントID( EVT-20260702-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→8→13→9→11
* 開始   : 2026-07-02 02:50:00 (UTC)
* 終了   : 2026-07-02 02:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 7→14→10→7→14→10→9
* 開始   : 2026-07-02 03:05:00 (UTC)
* 終了   : 2026-07-02 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host05-002 active_connections の推移](charts/EVT-20260702-host05-002.svg)

# イベントID( EVT-20260702-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→15→12→13
* 開始   : 2026-07-02 03:35:00 (UTC)
* 終了   : 2026-07-02 03:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host05-003 active_connections の推移](charts/EVT-20260702-host05-003.svg)

# イベントID( EVT-20260702-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→19→15→20→19→15→20→18→16
* 開始   : 2026-07-02 07:00:00 (UTC)
* 終了   : 2026-07-02 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→24→24→23→27
* 開始   : 2026-07-03 12:55:00 (UTC)
* 終了   : 2026-07-03 13:15:00 (UTC)
* 現象   : 2026-07-03 13:15:00 (UTC)を境に水準が 15.04から13.25へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→18→15→18→18
* 開始   : 2026-07-03 16:15:00 (UTC)
* 終了   : 2026-07-03 16:15:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→12→12
* 開始   : 2026-07-03 19:30:00 (UTC)
* 終了   : 2026-07-03 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→11→6→11→11
* 開始   : 2026-07-03 20:15:00 (UTC)
* 終了   : 2026-07-03 20:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.5255(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.762σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host05-008 active_connections の推移](charts/EVT-20260703-host05-008.svg)

# イベントID( EVT-20260704-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→13→9→11→…→11→13→15→11
* 開始   : 2026-07-04 04:50:00 (UTC)
* 終了   : 2026-07-04 18:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260704-host05-002 active_connections の推移](charts/EVT-20260704-host05-002.svg)

# イベントID( EVT-20260704-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→13→10→13→…→10→11→13→11
* 開始   : 2026-07-04 04:50:00 (UTC)
* 終了   : 2026-07-04 18:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.964, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260704-host05-003 active_connections の推移](charts/EVT-20260704-host05-003.svg)

# イベントID( EVT-20260704-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→13→…→10→11→12→11
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 19:15:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.456σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.008, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260704-host05-004 active_connections の推移](charts/EVT-20260704-host05-004.svg)

# イベントID( EVT-20260704-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→11→12→11→…→10→9→7→10
* 開始   : 2026-07-04 05:40:00 (UTC)
* 終了   : 2026-07-04 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host05-005 active_connections の推移](charts/EVT-20260704-host05-005.svg)

# イベントID( EVT-20260704-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→14→…→12→11→12→11
* 開始   : 2026-07-04 06:25:00 (UTC)
* 終了   : 2026-07-04 19:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.846, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host05-006 active_connections の推移](charts/EVT-20260704-host05-006.svg)

# イベントID( EVT-20260704-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→13→14→13→…→13→11→13→10
* 開始   : 2026-07-04 06:35:00 (UTC)
* 終了   : 2026-07-04 19:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.039, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host05-007 active_connections の推移](charts/EVT-20260704-host05-007.svg)

# イベントID( EVT-20260705-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→10→9→11→11→10→10
* 開始   : 2026-07-05 02:20:00 (UTC)
* 終了   : 2026-07-05 03:15:00 (UTC)
* 現象   : 2026-07-05 03:15:00 (UTC)を境に水準が 11.86から11.77へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→8→14→6→8→14→6→8→10
* 開始   : 2026-07-05 03:50:00 (UTC)
* 終了   : 2026-07-05 03:55:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260705-host05-003 active_connections の推移](charts/EVT-20260705-host05-003.svg)

# イベントID( EVT-20260705-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→19→15→13
* 開始   : 2026-07-05 09:05:00 (UTC)
* 終了   : 2026-07-05 09:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→16→14
* 開始   : 2026-07-05 09:55:00 (UTC)
* 終了   : 2026-07-05 09:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→13→7→9→11
* 開始   : 2026-07-05 19:05:00 (UTC)
* 終了   : 2026-07-05 19:05:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→10→11→11→12→11→12
* 開始   : 2026-07-05 19:05:00 (UTC)
* 終了   : 2026-07-05 20:00:00 (UTC)
* 現象   : 2026-07-05 20:00:00 (UTC)を境に水準が 11.78から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.778σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→11→12→15→16→17
* 開始   : 2026-07-07 04:35:00 (UTC)
* 終了   : 2026-07-07 05:00:00 (UTC)
* 現象   : 2026-07-07 05:00:00 (UTC)を境に水準が 15から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→19→14→16
* 開始   : 2026-07-07 06:40:00 (UTC)
* 終了   : 2026-07-07 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→17→21→16→16
* 開始   : 2026-07-07 06:55:00 (UTC)
* 終了   : 2026-07-07 06:55:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.333倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-007 active_connections の推移](charts/EVT-20260707-host05-007.svg)

# イベントID( EVT-20260707-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→19→21→20→…→21→20→18→19
* 開始   : 2026-07-07 07:55:00 (UTC)
* 終了   : 2026-07-07 08:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→17→22→18→18
* 開始   : 2026-07-07 08:00:00 (UTC)
* 終了   : 2026-07-07 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.294倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260707-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-009 active_connections の推移](charts/EVT-20260707-host05-009.svg)

# イベントID( EVT-20260708-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→15→17→14→13
* 開始   : 2026-07-08 05:25:00 (UTC)
* 終了   : 2026-07-08 05:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→15→21→18→19
* 開始   : 2026-07-08 07:10:00 (UTC)
* 終了   : 2026-07-08 07:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→19→23→19→21
* 開始   : 2026-07-08 08:35:00 (UTC)
* 終了   : 2026-07-08 08:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→21→17→22→21
* 開始   : 2026-07-08 14:10:00 (UTC)
* 終了   : 2026-07-08 14:10:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→11→15→15
* 開始   : 2026-07-08 18:10:00 (UTC)
* 終了   : 2026-07-08 18:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→15→10→11→15→10→13
* 開始   : 2026-07-08 18:50:00 (UTC)
* 終了   : 2026-07-08 20:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260708-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→8→6→11→10
* 開始   : 2026-07-08 21:20:00 (UTC)
* 終了   : 2026-07-08 21:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→17→21→17→18
* 開始   : 2026-07-09 07:35:00 (UTC)
* 終了   : 2026-07-09 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 24→22→25→19→22→25→19→22→21
* 開始   : 2026-07-09 08:45:00 (UTC)
* 終了   : 2026-07-09 10:30:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260709-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→19→24→22→19
* 開始   : 2026-07-09 09:20:00 (UTC)
* 終了   : 2026-07-09 09:20:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→18→14→16→16
* 開始   : 2026-07-09 16:30:00 (UTC)
* 終了   : 2026-07-09 16:30:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→13→14
* 開始   : 2026-07-09 19:00:00 (UTC)
* 終了   : 2026-07-09 19:00:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260709-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→6→11→9
* 開始   : 2026-07-09 20:25:00 (UTC)
* 終了   : 2026-07-09 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.4898(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260709-host05-011 active_connections の推移](charts/EVT-20260709-host05-011.svg)

# イベントID( EVT-20260710-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→13→17→14→15
* 開始   : 2026-07-10 05:15:00 (UTC)
* 終了   : 2026-07-10 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→13→17→13→15
* 開始   : 2026-07-10 05:15:00 (UTC)
* 終了   : 2026-07-10 05:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host05-002 active_connections の推移](charts/EVT-20260710-host05-002.svg)

# イベントID( EVT-20260710-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→18→14→17→17
* 開始   : 2026-07-10 16:45:00 (UTC)
* 終了   : 2026-07-10 16:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→12→10→14→12→10→14→12
* 開始   : 2026-07-10 19:45:00 (UTC)
* 終了   : 2026-07-10 20:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→13→…→9→11→9→10
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.781, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.2 時間
  - EVT-20260711-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260711-host05-002 active_connections の推移](charts/EVT-20260711-host05-002.svg)

# イベントID( EVT-20260711-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→12→13→12→…→10→11→13→12
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.188, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host05-003 active_connections の推移](charts/EVT-20260711-host05-003.svg)

# イベントID( EVT-20260711-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→13→…→11→12→14→13
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.738, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host05-004 active_connections の推移](charts/EVT-20260711-host05-004.svg)

# イベントID( EVT-20260711-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→11→…→10→11→12→14
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 19:40:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host05-005 active_connections の推移](charts/EVT-20260711-host05-005.svg)

# イベントID( EVT-20260711-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→11→…→13→12→13→12
* 開始   : 2026-07-11 05:55:00 (UTC)
* 終了   : 2026-07-11 17:55:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.885, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260711-host05-006 active_connections の推移](charts/EVT-20260711-host05-006.svg)

# イベントID( EVT-20260711-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→10→…→11→12→13→11
* 開始   : 2026-07-11 06:05:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.296, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260711-host05-007 active_connections の推移](charts/EVT-20260711-host05-007.svg)

# イベントID( EVT-20260712-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→12→16→14→15→14→15
* 開始   : 2026-07-12 05:45:00 (UTC)
* 終了   : 2026-07-12 07:50:00 (UTC)
* 現象   : 2026-07-12 07:50:00 (UTC)を境に水準が 11.8から12.54へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.368, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→18→14→17→18→14→17→12→17
* 開始   : 2026-07-12 08:25:00 (UTC)
* 終了   : 2026-07-12 08:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260712-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260712-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→15→16
* 開始   : 2026-07-12 10:00:00 (UTC)
* 終了   : 2026-07-12 10:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 7→7→4→10→7
* 開始   : 2026-07-12 22:35:00 (UTC)
* 終了   : 2026-07-12 22:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→7→5→9→…→9→3→9→7
* 開始   : 2026-07-12 23:05:00 (UTC)
* 終了   : 2026-07-12 23:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→17→…→14→15→13→12
* 開始   : 2026-07-13 02:20:00 (UTC)
* 終了   : 2026-07-13 21:15:00 (UTC)
* 現象   : 2026-07-13 21:15:00 (UTC)を境に水準が 11.88から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.834, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→15→…→16→15→12→13
* 開始   : 2026-07-13 02:25:00 (UTC)
* 終了   : 2026-07-13 18:40:00 (UTC)
* 現象   : 2026-07-13 18:40:00 (UTC)を境に水準が 11.87から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.03, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-004 active_connections の推移](charts/EVT-20260713-host05-004.svg)

# イベントID( EVT-20260713-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→16→…→14→13→16→15
* 開始   : 2026-07-13 02:50:00 (UTC)
* 終了   : 2026-07-13 20:55:00 (UTC)
* 現象   : 2026-07-13 20:55:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.717, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-005 active_connections の推移](charts/EVT-20260713-host05-005.svg)

# イベントID( EVT-20260714-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→11→14→10→9
* 開始   : 2026-07-14 03:00:00 (UTC)
* 終了   : 2026-07-14 03:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→11→18→12→15
* 開始   : 2026-07-14 05:20:00 (UTC)
* 終了   : 2026-07-14 05:20:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→15→…→15→18→15→16
* 開始   : 2026-07-14 06:05:00 (UTC)
* 終了   : 2026-07-14 06:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260714-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→21→18→21→21
* 開始   : 2026-07-14 12:00:00 (UTC)
* 終了   : 2026-07-14 12:00:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→23→16→20→19
* 開始   : 2026-07-14 13:55:00 (UTC)
* 終了   : 2026-07-14 13:55:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7471(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.808σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host05-007 active_connections の推移](charts/EVT-20260714-host05-007.svg)

# イベントID( EVT-20260714-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 23→19→16→19→19
* 開始   : 2026-07-14 15:05:00 (UTC)
* 終了   : 2026-07-14 15:05:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.7649(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.414σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→15→…→13→11→13→14
* 開始   : 2026-07-14 18:30:00 (UTC)
* 終了   : 2026-07-14 18:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260714-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→17→14→14→14→16
* 開始   : 2026-07-14 19:00:00 (UTC)
* 終了   : 2026-07-14 19:55:00 (UTC)
* 現象   : 2026-07-14 19:55:00 (UTC)を境に水準が 14.87から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→14→13→14→13→16→14→18→16
* 開始   : 2026-07-15 05:05:00 (UTC)
* 終了   : 2026-07-15 05:50:00 (UTC)
* 現象   : 2026-07-15 05:50:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→19→18→17→16→19→18→17→15
* 開始   : 2026-07-15 06:35:00 (UTC)
* 終了   : 2026-07-15 07:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260715-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host05-005 active_connections の推移](charts/EVT-20260715-host05-005.svg)

# イベントID( EVT-20260715-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→16→18
* 開始   : 2026-07-15 06:40:00 (UTC)
* 終了   : 2026-07-15 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.348倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.588σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260715-host05-006 active_connections の推移](charts/EVT-20260715-host05-006.svg)

# イベントID( EVT-20260715-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 24→22→23→24→24
* 開始   : 2026-07-15 11:50:00 (UTC)
* 終了   : 2026-07-15 13:00:00 (UTC)
* 現象   : 2026-07-15 13:00:00 (UTC)を境に水準が 15.06から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.356σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→16→13→13
* 開始   : 2026-07-16 04:50:00 (UTC)
* 終了   : 2026-07-16 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→25→23→18→25→23→18→22→20
* 開始   : 2026-07-16 13:25:00 (UTC)
* 終了   : 2026-07-16 13:35:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260716-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→8→12→9
* 開始   : 2026-07-16 20:10:00 (UTC)
* 終了   : 2026-07-16 20:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→17→20→17→16
* 開始   : 2026-07-17 06:50:00 (UTC)
* 終了   : 2026-07-17 06:50:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.472σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host05-003 active_connections の推移](charts/EVT-20260717-host05-003.svg)

# イベントID( EVT-20260717-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→18→24→21→19
* 開始   : 2026-07-17 08:50:00 (UTC)
* 終了   : 2026-07-17 08:50:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.472σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host05-005 active_connections の推移](charts/EVT-20260717-host05-005.svg)

# イベントID( EVT-20260717-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→21→22
* 開始   : 2026-07-17 14:45:00 (UTC)
* 終了   : 2026-07-17 14:45:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→19→14→18→19
* 開始   : 2026-07-17 16:35:00 (UTC)
* 終了   : 2026-07-17 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 7→10→13→10→…→10→12→7→9
* 開始   : 2026-07-18 03:10:00 (UTC)
* 終了   : 2026-07-18 03:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260718-host05-002 active_connections の推移](charts/EVT-20260718-host05-002.svg)

# イベントID( EVT-20260718-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→11→…→12→13→14→13
* 開始   : 2026-07-18 04:25:00 (UTC)
* 終了   : 2026-07-18 20:30:00 (UTC)
* 現象   : 16.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.726, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.4 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間

![EVT-20260718-host05-003 active_connections の推移](charts/EVT-20260718-host05-003.svg)

# イベントID( EVT-20260718-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→13→…→12→11→12→11
* 開始   : 2026-07-18 04:35:00 (UTC)
* 終了   : 2026-07-18 18:55:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.924, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260718-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 14.3 時間
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260718-host05-004 active_connections の推移](charts/EVT-20260718-host05-004.svg)

# イベントID( EVT-20260718-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→12→…→9→8→9→10
* 開始   : 2026-07-18 05:00:00 (UTC)
* 終了   : 2026-07-18 19:45:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.931, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260718-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260718-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host05-005 active_connections の推移](charts/EVT-20260718-host05-005.svg)

# イベントID( EVT-20260718-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→11→13→12→…→13→12→13→14
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260718-host05-006 active_connections の推移](charts/EVT-20260718-host05-006.svg)

# イベントID( EVT-20260718-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→14→…→13→10→14→13
* 開始   : 2026-07-18 05:20:00 (UTC)
* 終了   : 2026-07-18 18:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.212, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260718-host05-007 active_connections の推移](charts/EVT-20260718-host05-007.svg)

# イベントID( EVT-20260718-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→14→9→14→…→12→13→11→12
* 開始   : 2026-07-18 05:25:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.932, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260718-host05-008 active_connections の推移](charts/EVT-20260718-host05-008.svg)

# イベントID( EVT-20260720-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→14→…→14→15→14→12
* 開始   : 2026-07-20 02:55:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 11.81から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.911, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 21→20→16→19→19
* 開始   : 2026-07-21 15:20:00 (UTC)
* 終了   : 2026-07-21 15:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→15→14→12→…→14→12→14→16
* 開始   : 2026-07-21 17:55:00 (UTC)
* 終了   : 2026-07-21 18:00:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→10→14→8→11
* 開始   : 2026-07-22 02:45:00 (UTC)
* 終了   : 2026-07-22 02:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→7→14→10→11
* 開始   : 2026-07-22 03:45:00 (UTC)
* 終了   : 2026-07-22 03:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→16→16→14
* 開始   : 2026-07-22 04:55:00 (UTC)
* 終了   : 2026-07-22 05:10:00 (UTC)
* 現象   : 2026-07-22 05:10:00 (UTC)を境に水準が 14.97から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.478, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→17→18→17→18→16→17
* 開始   : 2026-07-22 05:10:00 (UTC)
* 終了   : 2026-07-22 06:40:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260722-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host05-004 active_connections の推移](charts/EVT-20260722-host05-004.svg)

# イベントID( EVT-20260722-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→20→19→…→20→19→17→16
* 開始   : 2026-07-22 06:50:00 (UTC)
* 終了   : 2026-07-22 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→11→11→13
* 開始   : 2026-07-23 02:20:00 (UTC)
* 終了   : 2026-07-23 02:35:00 (UTC)
* 現象   : 2026-07-23 02:35:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.113, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→18→24→22→…→22→23→20→23
* 開始   : 2026-07-23 09:55:00 (UTC)
* 終了   : 2026-07-23 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-033 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→22→16→22→21
* 開始   : 2026-07-23 14:55:00 (UTC)
* 終了   : 2026-07-23 14:55:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→16→11→16→13
* 開始   : 2026-07-23 17:45:00 (UTC)
* 終了   : 2026-07-23 17:45:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260723-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host05-010 active_connections の推移](charts/EVT-20260723-host05-010.svg)

# イベントID( EVT-20260724-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→9→8→10→10→11→12→11→12
* 開始   : 2026-07-24 02:30:00 (UTC)
* 終了   : 2026-07-24 03:10:00 (UTC)
* 現象   : 2026-07-24 03:10:00 (UTC)を境に水準が 14.9から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→11→13
* 開始   : 2026-07-24 03:50:00 (UTC)
* 終了   : 2026-07-24 04:25:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260724-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260724-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host05-002 active_connections の推移](charts/EVT-20260724-host05-002.svg)

# イベントID( EVT-20260724-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→16→21→16→19
* 開始   : 2026-07-24 07:30:00 (UTC)
* 終了   : 2026-07-24 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→21→22→22→23→22→22→22→22
* 開始   : 2026-07-24 08:45:00 (UTC)
* 終了   : 2026-07-24 13:30:00 (UTC)
* 現象   : 2026-07-24 13:30:00 (UTC)を境に水準が 14.93から13.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.519, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→14→14
* 開始   : 2026-07-24 17:40:00 (UTC)
* 終了   : 2026-07-24 17:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→14→10→15→12
* 開始   : 2026-07-24 18:45:00 (UTC)
* 終了   : 2026-07-24 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→8→11
* 開始   : 2026-07-24 21:30:00 (UTC)
* 終了   : 2026-07-24 21:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-069 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260724-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→11→10→12→11
* 開始   : 2026-07-25 04:30:00 (UTC)
* 終了   : 2026-07-25 19:10:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.691σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.93, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.7 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260725-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260725-host05-003 active_connections の推移](charts/EVT-20260725-host05-003.svg)

# イベントID( EVT-20260725-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→11→10→11→…→12→13→12→13
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 18:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.291, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260725-host05-004 active_connections の推移](charts/EVT-20260725-host05-004.svg)

# イベントID( EVT-20260725-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→11→13→14→12
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:00:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260725-host05-005 active_connections の推移](charts/EVT-20260725-host05-005.svg)

# イベントID( EVT-20260725-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→16→…→13→10→14→11
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 20:00:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.168, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260725-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260725-host05-006 active_connections の推移](charts/EVT-20260725-host05-006.svg)

# イベントID( EVT-20260725-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→12→…→12→13→12→13
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 19:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260725-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host05-007 active_connections の推移](charts/EVT-20260725-host05-007.svg)

# イベントID( EVT-20260725-host05-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→16→…→12→13→14→13
* 開始   : 2026-07-25 06:20:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.171, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260725-host05-008 active_connections の推移](charts/EVT-20260725-host05-008.svg)

# イベントID( EVT-20260726-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→16→…→17→16→15→14
* 開始   : 2026-07-26 08:10:00 (UTC)
* 終了   : 2026-07-26 08:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260726-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→9→14→12
* 開始   : 2026-07-26 16:35:00 (UTC)
* 終了   : 2026-07-26 16:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6207(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.819σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host05-005 active_connections の推移](charts/EVT-20260726-host05-005.svg)

# イベントID( EVT-20260727-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→14→…→14→12→14→13
* 開始   : 2026-07-27 02:30:00 (UTC)
* 終了   : 2026-07-27 20:05:00 (UTC)
* 現象   : 2026-07-27 20:05:00 (UTC)を境に水準が 11.89から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.011, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→22→17→20→20
* 開始   : 2026-07-28 13:45:00 (UTC)
* 終了   : 2026-07-28 13:45:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host05-007 active_connections の推移](charts/EVT-20260728-host05-007.svg)

# イベントID( EVT-20260728-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→9→10→10→11→11→11
* 開始   : 2026-07-28 21:15:00 (UTC)
* 終了   : 2026-07-28 22:00:00 (UTC)
* 現象   : 2026-07-28 22:00:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→6→13→9→11
* 開始   : 2026-07-29 01:20:00 (UTC)
* 終了   : 2026-07-29 01:20:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.66倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host05-001 active_connections の推移](charts/EVT-20260729-host05-001.svg)

# イベントID( EVT-20260729-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→13→13
* 開始   : 2026-07-29 04:40:00 (UTC)
* 終了   : 2026-07-29 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.299σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 18→16→22→18→20
* 開始   : 2026-07-29 07:50:00 (UTC)
* 終了   : 2026-07-29 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host05-005 active_connections の推移](charts/EVT-20260729-host05-005.svg)

# イベントID( EVT-20260729-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→19→23→22→23
* 開始   : 2026-07-29 08:05:00 (UTC)
* 終了   : 2026-07-29 10:05:00 (UTC)
* 現象   : 2026-07-29 10:05:00 (UTC)を境に水準が 14.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→17→18
* 開始   : 2026-07-29 16:55:00 (UTC)
* 終了   : 2026-07-29 16:55:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→15→10→13→11
* 開始   : 2026-07-29 19:10:00 (UTC)
* 終了   : 2026-07-29 19:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→11→10
* 開始   : 2026-07-30 03:10:00 (UTC)
* 終了   : 2026-07-30 03:10:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→11→17→13→13
* 開始   : 2026-07-30 04:45:00 (UTC)
* 終了   : 2026-07-30 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.468倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-004 active_connections の推移](charts/EVT-20260730-host05-004.svg)

# イベントID( EVT-20260730-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→18→16→16→15
* 開始   : 2026-07-30 05:55:00 (UTC)
* 終了   : 2026-07-30 06:15:00 (UTC)
* 現象   : 2026-07-30 06:15:00 (UTC)を境に水準が 15から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.339σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→16→17
* 開始   : 2026-07-30 06:45:00 (UTC)
* 終了   : 2026-07-30 06:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→20→24→20→21
* 開始   : 2026-07-30 09:05:00 (UTC)
* 終了   : 2026-07-30 09:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→22→25→21→22
* 開始   : 2026-07-30 10:30:00 (UTC)
* 終了   : 2026-07-30 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→18→16
* 開始   : 2026-07-30 17:25:00 (UTC)
* 終了   : 2026-07-30 17:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→15→10→12→14
* 開始   : 2026-07-30 19:05:00 (UTC)
* 終了   : 2026-07-30 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260730-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→10→10
* 開始   : 2026-07-31 02:40:00 (UTC)
* 終了   : 2026-07-31 02:40:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→20→26→21→20
* 開始   : 2026-07-31 09:55:00 (UTC)
* 終了   : 2026-07-31 09:55:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.268倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.842σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host05-007 active_connections の推移](charts/EVT-20260731-host05-007.svg)

# イベントID( EVT-20260731-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→17→18
* 開始   : 2026-07-31 17:00:00 (UTC)
* 終了   : 2026-07-31 17:00:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→5→11→9→8→5→11→9
* 開始   : 2026-07-01 00:15:00 (UTC)
* 終了   : 2026-07-01 00:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 7→5→8→7→5→8→7
* 開始   : 2026-07-01 00:15:00 (UTC)
* 終了   : 2026-07-01 00:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.5769(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→11→11→12→14
* 開始   : 2026-07-01 03:15:00 (UTC)
* 終了   : 2026-07-01 03:35:00 (UTC)
* 現象   : 2026-07-01 03:35:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→14→10→12→14→10→13
* 開始   : 2026-07-01 04:00:00 (UTC)
* 終了   : 2026-07-01 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 18→16→19→20→…→17→20→15→18
* 開始   : 2026-07-01 07:10:00 (UTC)
* 終了   : 2026-07-01 07:25:00 (UTC)
* 現象   : 2026-07-01 07:25:00 (UTC)を境に水準が 14.92から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→20→21→21→22→24→21→22→22
* 開始   : 2026-07-01 08:55:00 (UTC)
* 終了   : 2026-07-01 09:35:00 (UTC)
* 現象   : 2026-07-01 09:35:00 (UTC)を境に水準が 14.92から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→23→20→19→22→23→20
* 開始   : 2026-07-01 08:55:00 (UTC)
* 終了   : 2026-07-01 09:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 21→24→22→21→21→21→23→21→23
* 開始   : 2026-07-01 09:55:00 (UTC)
* 終了   : 2026-07-01 11:20:00 (UTC)
* 現象   : 2026-07-01 11:20:00 (UTC)を境に水準が 15から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.709, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→24→22→24→23
* 開始   : 2026-07-01 10:30:00 (UTC)
* 終了   : 2026-07-01 10:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→15→18→15→18→15→17
* 開始   : 2026-07-01 16:35:00 (UTC)
* 終了   : 2026-07-01 16:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→11→…→12→11→15→14
* 開始   : 2026-07-01 18:25:00 (UTC)
* 終了   : 2026-07-01 18:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→13→…→13→11→12→14
* 開始   : 2026-07-01 19:10:00 (UTC)
* 終了   : 2026-07-01 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260701-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260701-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→11
* 開始   : 2026-07-01 21:15:00 (UTC)
* 終了   : 2026-07-01 21:30:00 (UTC)
* 現象   : 2026-07-01 21:30:00 (UTC)を境に水準が 14.93から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→10→11→8→9→7→8→11→9
* 開始   : 2026-07-01 21:40:00 (UTC)
* 終了   : 2026-07-01 22:30:00 (UTC)
* 現象   : 2026-07-01 22:30:00 (UTC)を境に水準が 14.95から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host05-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host05-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→6→10→6→10→6→8
* 開始   : 2026-07-01 22:55:00 (UTC)
* 終了   : 2026-07-01 23:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host05-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→13→14→11→14→11→14→13→12
* 開始   : 2026-07-02 04:15:00 (UTC)
* 終了   : 2026-07-02 04:25:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260702-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→20→17→20→17→20→19
* 開始   : 2026-07-02 07:35:00 (UTC)
* 終了   : 2026-07-02 07:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→17→20→17→18
* 開始   : 2026-07-02 07:40:00 (UTC)
* 終了   : 2026-07-02 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→17→20→16→…→16→21→18→19
* 開始   : 2026-07-02 07:45:00 (UTC)
* 終了   : 2026-07-02 07:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260702-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 25→23→20→24
* 開始   : 2026-07-02 11:55:00 (UTC)
* 終了   : 2026-07-02 12:10:00 (UTC)
* 現象   : 2026-07-02 12:10:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→17→19→16→17→19
* 開始   : 2026-07-02 16:30:00 (UTC)
* 終了   : 2026-07-02 16:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→19→16→15→…→17→15→18→19
* 開始   : 2026-07-02 16:30:00 (UTC)
* 終了   : 2026-07-02 16:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→14→11→14→11→13→12
* 開始   : 2026-07-02 18:40:00 (UTC)
* 終了   : 2026-07-02 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→9
* 開始   : 2026-07-02 20:45:00 (UTC)
* 終了   : 2026-07-02 22:10:00 (UTC)
* 現象   : 2026-07-02 22:10:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→8→11→8→11→8→11→9
* 開始   : 2026-07-02 20:45:00 (UTC)
* 終了   : 2026-07-02 20:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→10→8→9
* 開始   : 2026-07-02 20:50:00 (UTC)
* 終了   : 2026-07-02 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→12→13→14→…→10→13→14→10
* 開始   : 2026-07-03 03:15:00 (UTC)
* 終了   : 2026-07-03 03:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260703-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→17→15→14→…→15→14→18→17
* 開始   : 2026-07-03 17:00:00 (UTC)
* 終了   : 2026-07-03 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→12→10→12
* 開始   : 2026-07-03 19:50:00 (UTC)
* 終了   : 2026-07-03 19:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→9→13→11→9→13→11
* 開始   : 2026-07-03 20:00:00 (UTC)
* 終了   : 2026-07-03 20:05:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→8→11→8→11→8→10
* 開始   : 2026-07-04 01:05:00 (UTC)
* 終了   : 2026-07-04 01:10:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260704-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260704-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→7→7→9→8→8→8→7→10
* 開始   : 2026-07-05 00:00:00 (UTC)
* 終了   : 2026-07-05 01:15:00 (UTC)
* 現象   : 2026-07-05 01:15:00 (UTC)を境に水準が 11.91から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.964, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→11→14→11→14→12→14
* 開始   : 2026-07-05 05:40:00 (UTC)
* 終了   : 2026-07-05 05:50:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260705-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260705-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→13→15→11→13→15→11→13
* 開始   : 2026-07-05 07:20:00 (UTC)
* 終了   : 2026-07-05 07:25:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260705-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→16→16→15→14→15→12→15→15
* 開始   : 2026-07-05 14:50:00 (UTC)
* 終了   : 2026-07-05 16:05:00 (UTC)
* 現象   : 2026-07-05 16:05:00 (UTC)を境に水準が 12.02から14.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.964, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→9→10→9→8→12→10→11→11
* 開始   : 2026-07-06 01:35:00 (UTC)
* 終了   : 2026-07-06 03:25:00 (UTC)
* 現象   : 2026-07-06 03:25:00 (UTC)を境に水準が 11.73から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→11→13→11→13→11→9
* 開始   : 2026-07-07 02:55:00 (UTC)
* 終了   : 2026-07-07 03:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→11→13→10→11→13→10→12
* 開始   : 2026-07-07 03:30:00 (UTC)
* 終了   : 2026-07-07 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→13→…→13→18→14→16
* 開始   : 2026-07-07 06:00:00 (UTC)
* 終了   : 2026-07-07 06:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→19→16→19→16→17
* 開始   : 2026-07-07 06:50:00 (UTC)
* 終了   : 2026-07-07 07:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→21→18→21→18→21→18→19→18
* 開始   : 2026-07-07 15:10:00 (UTC)
* 終了   : 2026-07-07 15:20:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→14→16→13→14→15
* 開始   : 2026-07-07 18:00:00 (UTC)
* 終了   : 2026-07-07 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→17→12→14→12→14→12→13→14
* 開始   : 2026-07-07 18:20:00 (UTC)
* 終了   : 2026-07-07 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→13→…→13→10→13→11
* 開始   : 2026-07-07 19:30:00 (UTC)
* 終了   : 2026-07-07 19:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→11→12→11→12→12→12
* 開始   : 2026-07-07 19:45:00 (UTC)
* 終了   : 2026-07-07 21:10:00 (UTC)
* 現象   : 2026-07-07 21:10:00 (UTC)を境に水準が 14.91から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.982, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→11→…→11→14→8→10
* 開始   : 2026-07-07 20:50:00 (UTC)
* 終了   : 2026-07-07 22:10:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260707-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260707-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260707-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260707-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host05-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→11→11→10→9→8→9→11
* 開始   : 2026-07-07 22:10:00 (UTC)
* 終了   : 2026-07-07 22:45:00 (UTC)
* 現象   : 2026-07-07 22:45:00 (UTC)を境に水準が 14.92から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→15→14→13→15→13
* 開始   : 2026-07-08 04:25:00 (UTC)
* 終了   : 2026-07-08 04:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→16→15→18→18→17→17→20
* 開始   : 2026-07-08 06:30:00 (UTC)
* 終了   : 2026-07-08 07:05:00 (UTC)
* 現象   : 2026-07-08 07:05:00 (UTC)を境に水準が 14.91から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.226, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→20→21→16→17→20→21→16→18
* 開始   : 2026-07-08 07:50:00 (UTC)
* 終了   : 2026-07-08 07:55:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→19→22→20→19→22→20
* 開始   : 2026-07-08 08:45:00 (UTC)
* 終了   : 2026-07-08 08:50:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→22→19→22→19→22→21→20
* 開始   : 2026-07-08 08:55:00 (UTC)
* 終了   : 2026-07-08 09:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→16→…→15→12→14→13
* 開始   : 2026-07-08 17:25:00 (UTC)
* 終了   : 2026-07-08 18:20:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260708-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260708-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→11→14→11
* 開始   : 2026-07-08 19:15:00 (UTC)
* 終了   : 2026-07-08 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→11→12→10→10→10→13
* 開始   : 2026-07-09 03:10:00 (UTC)
* 終了   : 2026-07-09 03:40:00 (UTC)
* 現象   : 2026-07-09 03:40:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→9→13→11→13→11→13→11→10
* 開始   : 2026-07-09 03:10:00 (UTC)
* 終了   : 2026-07-09 03:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→16→15→19→16→17
* 開始   : 2026-07-09 06:35:00 (UTC)
* 終了   : 2026-07-09 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.965σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→18→19→18→16→18→19→18→15
* 開始   : 2026-07-09 06:40:00 (UTC)
* 終了   : 2026-07-09 06:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 23→22→19→21→22→19→21
* 開始   : 2026-07-09 13:40:00 (UTC)
* 終了   : 2026-07-09 13:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→16→19→18→…→18→20→18→17
* 開始   : 2026-07-10 07:15:00 (UTC)
* 終了   : 2026-07-10 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→21→18→24→…→18→24→20→21
* 開始   : 2026-07-10 11:40:00 (UTC)
* 終了   : 2026-07-10 11:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→23→22→22→23→22
* 開始   : 2026-07-10 13:40:00 (UTC)
* 終了   : 2026-07-10 14:05:00 (UTC)
* 現象   : 2026-07-10 14:05:00 (UTC)を境に水準が 14.91から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→18→13→16→13→16→13→14→15
* 開始   : 2026-07-10 18:05:00 (UTC)
* 終了   : 2026-07-10 18:15:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→12→14→9→…→9→8→9→10
* 開始   : 2026-07-10 20:55:00 (UTC)
* 終了   : 2026-07-10 21:05:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-083 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260710-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→10→13→9→13→9→13→9
* 開始   : 2026-07-11 04:10:00 (UTC)
* 終了   : 2026-07-11 04:20:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.431倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host05-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 8→10→9→8→…→9→8→9→10
* 開始   : 2026-07-11 20:05:00 (UTC)
* 終了   : 2026-07-11 20:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.738, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260711-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260711-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→12→8→9→12→8→9
* 開始   : 2026-07-11 20:20:00 (UTC)
* 終了   : 2026-07-11 20:25:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260711-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260711-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260711-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→12→9→8→12→11
* 開始   : 2026-07-12 03:25:00 (UTC)
* 終了   : 2026-07-12 06:00:00 (UTC)
* 現象   : 2026-07-12 06:00:00 (UTC)を境に水準が 11.72から11.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→14→19→15→12→19→15→12→16
* 開始   : 2026-07-12 12:50:00 (UTC)
* 終了   : 2026-07-12 13:00:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→12→18→16→17→12→18→16→13
* 開始   : 2026-07-12 14:20:00 (UTC)
* 終了   : 2026-07-12 14:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260712-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→8→8→8→9→7→11→8
* 開始   : 2026-07-12 21:20:00 (UTC)
* 終了   : 2026-07-12 23:25:00 (UTC)
* 現象   : 2026-07-12 23:25:00 (UTC)を境に水準が 11.8から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.982, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→7→8→10→7→8
* 開始   : 2026-07-12 21:25:00 (UTC)
* 終了   : 2026-07-12 21:30:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260712-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→11→8→11
* 開始   : 2026-07-13 23:00:00 (UTC)
* 終了   : 2026-07-13 23:15:00 (UTC)
* 現象   : 2026-07-13 23:15:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.113, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→20→17→21→20→17→21→19
* 開始   : 2026-07-14 07:35:00 (UTC)
* 終了   : 2026-07-14 07:45:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→20→22→20→21
* 開始   : 2026-07-14 08:15:00 (UTC)
* 終了   : 2026-07-14 08:35:00 (UTC)
* 現象   : 2026-07-14 08:35:00 (UTC)を境に水準が 15.04から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→19→15→14→…→15→14→15→17
* 開始   : 2026-07-14 16:40:00 (UTC)
* 終了   : 2026-07-14 16:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→15→14→…→14→16→14→15
* 開始   : 2026-07-15 05:10:00 (UTC)
* 終了   : 2026-07-15 05:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260715-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→16→14→16→14→16→14
* 開始   : 2026-07-15 05:20:00 (UTC)
* 終了   : 2026-07-15 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260715-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→18→17→15→17→18→17
* 開始   : 2026-07-15 06:25:00 (UTC)
* 終了   : 2026-07-15 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→20→21→19→22→22
* 開始   : 2026-07-15 08:50:00 (UTC)
* 終了   : 2026-07-15 09:15:00 (UTC)
* 現象   : 2026-07-15 09:15:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→22→24→23
* 開始   : 2026-07-15 13:40:00 (UTC)
* 終了   : 2026-07-15 13:55:00 (UTC)
* 現象   : 2026-07-15 13:55:00 (UTC)を境に水準が 15.06から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→17→23→20→…→19→17→23→19
* 開始   : 2026-07-15 15:10:00 (UTC)
* 終了   : 2026-07-15 15:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260715-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→10→13→11→10→13→11
* 開始   : 2026-07-15 19:15:00 (UTC)
* 終了   : 2026-07-15 19:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→16→…→16→18→17→14
* 開始   : 2026-07-16 06:10:00 (UTC)
* 終了   : 2026-07-16 07:25:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host05-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260716-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→15→17→16→18→17→16→18→16
* 開始   : 2026-07-16 06:25:00 (UTC)
* 終了   : 2026-07-16 06:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host05-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260716-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→17→16→18→20
* 開始   : 2026-07-16 06:30:00 (UTC)
* 終了   : 2026-07-16 06:55:00 (UTC)
* 現象   : 2026-07-16 06:55:00 (UTC)を境に水準が 14.95から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→15→17→18→15→16
* 開始   : 2026-07-16 06:30:00 (UTC)
* 終了   : 2026-07-16 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→23→…→22→23→21→20
* 開始   : 2026-07-16 08:55:00 (UTC)
* 終了   : 2026-07-16 09:00:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→21→22→20→21→18→20→19→20
* 開始   : 2026-07-16 15:00:00 (UTC)
* 終了   : 2026-07-16 15:40:00 (UTC)
* 現象   : 2026-07-16 15:40:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→20→16→18→20→16→18
* 開始   : 2026-07-16 15:55:00 (UTC)
* 終了   : 2026-07-16 16:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260716-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→13→14→16→…→14→12→15→14
* 開始   : 2026-07-16 18:05:00 (UTC)
* 終了   : 2026-07-16 18:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260716-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→14→11→12→13→11→12
* 開始   : 2026-07-16 19:00:00 (UTC)
* 終了   : 2026-07-16 20:20:00 (UTC)
* 現象   : 2026-07-16 20:20:00 (UTC)を境に水準が 14.91から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.636σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→14→11→10→14→11→10
* 開始   : 2026-07-17 03:50:00 (UTC)
* 終了   : 2026-07-17 03:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→11→15→13
* 開始   : 2026-07-17 04:15:00 (UTC)
* 終了   : 2026-07-17 04:40:00 (UTC)
* 現象   : 2026-07-17 04:40:00 (UTC)を境に水準が 15.07から14.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.862, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→21→18→17→21→19
* 開始   : 2026-07-17 07:50:00 (UTC)
* 終了   : 2026-07-17 08:15:00 (UTC)
* 現象   : 2026-07-17 08:15:00 (UTC)を境に水準が 14.94から14.2へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→21→24→22→21→24→22→21
* 開始   : 2026-07-17 10:10:00 (UTC)
* 終了   : 2026-07-17 10:15:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260717-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→22→21→19→20→20
* 開始   : 2026-07-17 15:30:00 (UTC)
* 終了   : 2026-07-17 15:55:00 (UTC)
* 現象   : 2026-07-17 15:55:00 (UTC)を境に水準が 14.94から12.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→14→11→14→11→12→13
* 開始   : 2026-07-17 19:05:00 (UTC)
* 終了   : 2026-07-17 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→14→9→11→14→9→11→12
* 開始   : 2026-07-17 19:50:00 (UTC)
* 終了   : 2026-07-17 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6879(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.871σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260717-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→10→8→11→8→11→8→12→8
* 開始   : 2026-07-17 21:10:00 (UTC)
* 終了   : 2026-07-17 21:20:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-087 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→10→10→9→11→10
* 開始   : 2026-07-17 22:10:00 (UTC)
* 終了   : 2026-07-17 22:35:00 (UTC)
* 現象   : 2026-07-17 22:35:00 (UTC)を境に水準が 14.9から11.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→5→7→8→6→5→7
* 開始   : 2026-07-17 23:05:00 (UTC)
* 終了   : 2026-07-17 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→8→7→12→8
* 開始   : 2026-07-18 02:15:00 (UTC)
* 終了   : 2026-07-18 02:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260718-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→7→9→8→10→8→10→11→8
* 開始   : 2026-07-19 01:45:00 (UTC)
* 終了   : 2026-07-19 02:25:00 (UTC)
* 現象   : 2026-07-19 02:25:00 (UTC)を境に水準が 11.59から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→8→5→8→10
* 開始   : 2026-07-19 02:35:00 (UTC)
* 終了   : 2026-07-19 02:40:00 (UTC)
* 現象   : 日曜2時台の平常値(8.762)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.109σ 外れた (平常値=8.762)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→12→9→12→9
* 開始   : 2026-07-19 03:40:00 (UTC)
* 終了   : 2026-07-19 03:45:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260719-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→14→15→12→11→14→15→12→11
* 開始   : 2026-07-19 05:50:00 (UTC)
* 終了   : 2026-07-19 05:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→17→18→16→17→15→14→19→16
* 開始   : 2026-07-19 12:25:00 (UTC)
* 終了   : 2026-07-19 13:10:00 (UTC)
* 現象   : 2026-07-19 13:10:00 (UTC)を境に水準が 11.94から13.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→16→16→17→16→15→18→18
* 開始   : 2026-07-19 13:00:00 (UTC)
* 終了   : 2026-07-19 13:35:00 (UTC)
* 現象   : 2026-07-19 13:35:00 (UTC)を境に水準が 11.64から13.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.982, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→14→11→14→11→13→12
* 開始   : 2026-07-19 16:50:00 (UTC)
* 終了   : 2026-07-19 17:00:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260719-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→9→9→10→9→9→11→10→9
* 開始   : 2026-07-20 01:55:00 (UTC)
* 終了   : 2026-07-20 02:40:00 (UTC)
* 現象   : 2026-07-20 02:40:00 (UTC)を境に水準が 11.75から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→10→9→11→9→11→11→11→12
* 開始   : 2026-07-20 02:35:00 (UTC)
* 終了   : 2026-07-20 03:20:00 (UTC)
* 現象   : 2026-07-20 03:20:00 (UTC)を境に水準が 11.97から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→9→12→6→…→12→6→8→10
* 開始   : 2026-07-21 02:30:00 (UTC)
* 終了   : 2026-07-21 02:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→15→17→16→16
* 開始   : 2026-07-21 05:50:00 (UTC)
* 終了   : 2026-07-21 06:15:00 (UTC)
* 現象   : 2026-07-21 06:15:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.862, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→15→16→14→15→16→14
* 開始   : 2026-07-21 05:50:00 (UTC)
* 終了   : 2026-07-21 05:55:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260721-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→18→17→14→15→15
* 開始   : 2026-07-21 18:00:00 (UTC)
* 終了   : 2026-07-21 19:35:00 (UTC)
* 現象   : 2026-07-21 19:35:00 (UTC)を境に水準が 14.94から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.754σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→15→10→14→10→14→10→12→15
* 開始   : 2026-07-21 18:55:00 (UTC)
* 終了   : 2026-07-21 19:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→19→20→18→19→20→18
* 開始   : 2026-07-22 07:30:00 (UTC)
* 終了   : 2026-07-22 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→21→…→20→21→20→16
* 開始   : 2026-07-22 07:45:00 (UTC)
* 終了   : 2026-07-22 07:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→23→20→21→23→20→21
* 開始   : 2026-07-22 09:15:00 (UTC)
* 終了   : 2026-07-22 09:20:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→20→19→21→20→19→21
* 開始   : 2026-07-22 13:55:00 (UTC)
* 終了   : 2026-07-22 14:00:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→22→20→23→22→21→21
* 開始   : 2026-07-22 14:40:00 (UTC)
* 終了   : 2026-07-22 15:40:00 (UTC)
* 現象   : 2026-07-22 15:40:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→14→13→17→13→17→13→14→16
* 開始   : 2026-07-22 18:00:00 (UTC)
* 終了   : 2026-07-22 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260722-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260722-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260722-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→10→9→8→10→10→9→9→11
* 開始   : 2026-07-22 22:05:00 (UTC)
* 終了   : 2026-07-22 23:00:00 (UTC)
* 現象   : 2026-07-22 23:00:00 (UTC)を境に水準が 14.91から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.942, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 7→5→7→11→5→7→11→9→10
* 開始   : 2026-07-22 23:50:00 (UTC)
* 終了   : 2026-07-23 00:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→11→9→12→10→13
* 開始   : 2026-07-23 03:15:00 (UTC)
* 終了   : 2026-07-23 03:40:00 (UTC)
* 現象   : 2026-07-23 03:40:00 (UTC)を境に水準が 14.91から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→11→…→11→14→11→12
* 開始   : 2026-07-23 03:35:00 (UTC)
* 終了   : 2026-07-23 03:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260723-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260723-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→14→11→…→14→15→9→13
* 開始   : 2026-07-23 03:55:00 (UTC)
* 終了   : 2026-07-23 04:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.86σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260723-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260723-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→9→14→9→14→9→14→12
* 開始   : 2026-07-23 04:15:00 (UTC)
* 終了   : 2026-07-23 04:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260723-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→21→16→22→21→16→22→21→20
* 開始   : 2026-07-23 09:35:00 (UTC)
* 終了   : 2026-07-23 09:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→17→14→17→16
* 開始   : 2026-07-23 17:00:00 (UTC)
* 終了   : 2026-07-23 17:05:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→12→…→14→12→14→13
* 開始   : 2026-07-23 18:20:00 (UTC)
* 終了   : 2026-07-23 18:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host14-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→11→10→9→8→9→8
* 開始   : 2026-07-23 21:00:00 (UTC)
* 終了   : 2026-07-23 22:05:00 (UTC)
* 現象   : 2026-07-23 22:05:00 (UTC)を境に水準が 14.9から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→11→16→12→16→12→16→12→15
* 開始   : 2026-07-24 04:25:00 (UTC)
* 終了   : 2026-07-24 05:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260724-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260724-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→17→18→17→15→17→18→17→15
* 開始   : 2026-07-24 06:20:00 (UTC)
* 終了   : 2026-07-24 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260724-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→21→20→17→21→20→20→21→21
* 開始   : 2026-07-24 08:00:00 (UTC)
* 終了   : 2026-07-24 09:35:00 (UTC)
* 現象   : 2026-07-24 09:35:00 (UTC)を境に水準が 14.96から14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→19→24→21→19→24→21
* 開始   : 2026-07-24 10:30:00 (UTC)
* 終了   : 2026-07-24 10:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.489σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→21→16→22→…→16→22→19→18
* 開始   : 2026-07-24 16:05:00 (UTC)
* 終了   : 2026-07-24 16:10:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 18→17→22→16→…→19→15→19→18
* 開始   : 2026-07-24 16:05:00 (UTC)
* 終了   : 2026-07-24 16:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→19→14→13→…→14→13→16→14
* 開始   : 2026-07-24 17:25:00 (UTC)
* 終了   : 2026-07-24 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260724-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→11→16→10→11→16→10→11
* 開始   : 2026-07-24 20:00:00 (UTC)
* 終了   : 2026-07-24 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260724-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→8→6→11→6→11→6→9→8
* 開始   : 2026-07-24 23:05:00 (UTC)
* 終了   : 2026-07-24 23:15:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→8→9→7→7→8→9→8→9
* 開始   : 2026-07-25 00:00:00 (UTC)
* 終了   : 2026-07-25 01:05:00 (UTC)
* 現象   : 2026-07-25 01:05:00 (UTC)を境に水準が 15.1から11.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260725-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→13→14→11→10→13→14→11
* 開始   : 2026-07-25 04:20:00 (UTC)
* 終了   : 2026-07-25 05:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.997, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260725-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 50 分
  - EVT-20260725-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 40 分
  - EVT-20260725-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260725-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260725-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→13→9→7→13→9→7→9→8
* 開始   : 2026-07-25 20:45:00 (UTC)
* 終了   : 2026-07-25 20:55:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 8→11→6→5→…→6→5→8→9
* 開始   : 2026-07-25 21:55:00 (UTC)
* 終了   : 2026-07-25 22:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260725-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→14→15→14→11→13→16→14→14
* 開始   : 2026-07-26 07:15:00 (UTC)
* 終了   : 2026-07-26 08:10:00 (UTC)
* 現象   : 2026-07-26 08:10:00 (UTC)を境に水準が 11.74から12.56へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.473, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→17→16→17→17→16→17→18→18
* 開始   : 2026-07-26 10:30:00 (UTC)
* 終了   : 2026-07-26 11:40:00 (UTC)
* 現象   : 2026-07-26 11:40:00 (UTC)を境に水準が 11.84から13.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→16→17→16→14→16→14→15→18
* 開始   : 2026-07-26 11:25:00 (UTC)
* 終了   : 2026-07-26 12:35:00 (UTC)
* 現象   : 2026-07-26 12:35:00 (UTC)を境に水準が 11.77から13.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.591, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→6→9→9→8→8→7→10→9
* 開始   : 2026-07-26 21:00:00 (UTC)
* 終了   : 2026-07-26 22:55:00 (UTC)
* 現象   : 2026-07-26 22:55:00 (UTC)を境に水準が 11.82から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→9→8→8→12→9→12
* 開始   : 2026-07-27 01:25:00 (UTC)
* 終了   : 2026-07-27 01:55:00 (UTC)
* 現象   : 2026-07-27 01:55:00 (UTC)を境に水準が 11.82から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→9→5→9→…→9→12→11→8
* 開始   : 2026-07-28 01:50:00 (UTC)
* 終了   : 2026-07-28 02:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→13→15→15→14→15→16→15→18
* 開始   : 2026-07-28 04:45:00 (UTC)
* 終了   : 2026-07-28 06:25:00 (UTC)
* 現象   : 2026-07-28 06:25:00 (UTC)を境に水準が 14.85から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→14→17→14→17→15→14
* 開始   : 2026-07-28 05:55:00 (UTC)
* 終了   : 2026-07-28 06:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260728-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→18→16→17→18→17→18→19→21
* 開始   : 2026-07-28 07:05:00 (UTC)
* 終了   : 2026-07-28 07:50:00 (UTC)
* 現象   : 2026-07-28 07:50:00 (UTC)を境に水準が 14.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.636σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→17→21→17→21→19
* 開始   : 2026-07-28 08:30:00 (UTC)
* 終了   : 2026-07-28 08:40:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260728-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260728-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→22→25→22→25→22→21
* 開始   : 2026-07-28 11:15:00 (UTC)
* 終了   : 2026-07-28 11:20:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.181倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→18→13→15→…→13→12→14→13
* 開始   : 2026-07-28 17:50:00 (UTC)
* 終了   : 2026-07-28 18:15:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260728-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→8→7→10→7→10→7→10→12
* 開始   : 2026-07-28 21:40:00 (UTC)
* 終了   : 2026-07-28 21:50:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260728-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→14→12→15→14→12
* 開始   : 2026-07-29 04:45:00 (UTC)
* 終了   : 2026-07-29 04:50:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.802σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→17→18→17→18→17
* 開始   : 2026-07-29 06:20:00 (UTC)
* 終了   : 2026-07-29 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→19→23→20→…→20→17→21→19
* 開始   : 2026-07-29 15:20:00 (UTC)
* 終了   : 2026-07-29 15:30:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→14→15→17→14→15
* 開始   : 2026-07-29 17:25:00 (UTC)
* 終了   : 2026-07-29 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→14→10→11→14→10→13
* 開始   : 2026-07-29 18:55:00 (UTC)
* 終了   : 2026-07-29 19:05:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260729-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→14→13→14→14
* 開始   : 2026-07-29 19:25:00 (UTC)
* 終了   : 2026-07-29 20:25:00 (UTC)
* 現象   : 2026-07-29 20:25:00 (UTC)を境に水準が 14.9から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→8→9→10→8→9
* 開始   : 2026-07-29 21:00:00 (UTC)
* 終了   : 2026-07-29 21:05:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260729-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 7→9→5→9→11→5→9→11→8
* 開始   : 2026-07-29 23:25:00 (UTC)
* 終了   : 2026-07-29 23:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→11→10→13→11→10
* 開始   : 2026-07-30 03:20:00 (UTC)
* 終了   : 2026-07-30 03:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→14→11→14
* 開始   : 2026-07-30 04:40:00 (UTC)
* 終了   : 2026-07-30 04:45:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-025 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→18→20→19→18→20→19
* 開始   : 2026-07-30 07:30:00 (UTC)
* 終了   : 2026-07-30 07:35:00 (UTC)
* 現象   : 平常時(16)に対し 1.25倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 20→23→21→20→23→21→20
* 開始   : 2026-07-30 08:45:00 (UTC)
* 終了   : 2026-07-30 08:50:00 (UTC)
* 現象   : 平常時(19)に対し 1.211倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 18→16→15→14→…→15→14→18→16
* 開始   : 2026-07-30 17:00:00 (UTC)
* 終了   : 2026-07-30 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→13→…→13→8→12→14
* 開始   : 2026-07-30 19:50:00 (UTC)
* 終了   : 2026-07-30 20:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→11→9→11→9→11→13
* 開始   : 2026-07-30 20:05:00 (UTC)
* 終了   : 2026-07-30 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-081 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 6→10→12→7→…→7→11→9→8
* 開始   : 2026-07-31 00:35:00 (UTC)
* 終了   : 2026-07-31 00:45:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.516倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.871σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→5→8→11→5→8→11→9→8
* 開始   : 2026-07-31 00:55:00 (UTC)
* 終了   : 2026-07-31 01:05:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→17→13→17→13→17→15→13
* 開始   : 2026-07-31 06:00:00 (UTC)
* 終了   : 2026-07-31 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260731-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→17→20→19→19→19→18
* 開始   : 2026-07-31 07:15:00 (UTC)
* 終了   : 2026-07-31 07:45:00 (UTC)
* 現象   : 2026-07-31 07:45:00 (UTC)を境に水準が 15.01から14.41へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→19→22→19→20
* 開始   : 2026-07-31 08:35:00 (UTC)
* 終了   : 2026-07-31 08:40:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→18→19→16→18
* 開始   : 2026-07-31 16:20:00 (UTC)
* 終了   : 2026-07-31 16:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→14→17→13→14→17
* 開始   : 2026-07-31 17:55:00 (UTC)
* 終了   : 2026-07-31 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→15→12→15→12→15
* 開始   : 2026-07-31 18:15:00 (UTC)
* 終了   : 2026-07-31 18:25:00 (UTC)
* 現象   : 平常時(16)に対し 0.75(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260731-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→15→11→16→15→11→16→14
* 開始   : 2026-07-31 18:55:00 (UTC)
* 終了   : 2026-07-31 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.7333(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→11→7→11→9
* 開始   : 2026-07-31 21:30:00 (UTC)
* 終了   : 2026-07-31 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-068 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260731-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 7→9→11→10→…→10→5→6→8
* 開始   : 2026-07-31 23:50:00 (UTC)
* 終了   : 2026-08-01 00:50:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260731-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260801-lsfhost01-001 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260731-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host05-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
