# host15 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host15 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 304 (SEVERE: 19, FATAL: 112, WARN: 173, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 112 | 173 | 304 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→17→15→14→…→13→15→14→13
* 開始   : 2026-07-06 02:00:00 (UTC)
* 終了   : 2026-07-06 21:15:00 (UTC)
* 現象   : 2026-07-06 21:15:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.918, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-001 active_connections の推移](charts/EVT-20260706-host15-001.svg)

# イベントID( EVT-20260706-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→15→…→10→13→10→11
* 開始   : 2026-07-06 02:35:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.88から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.73, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-002 active_connections の推移](charts/EVT-20260706-host15-002.svg)

# イベントID( EVT-20260706-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→13→18→16→…→13→15→13→12
* 開始   : 2026-07-06 02:50:00 (UTC)
* 終了   : 2026-07-06 19:40:00 (UTC)
* 現象   : 2026-07-06 19:40:00 (UTC)を境に水準が 11.76から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.197, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.699, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-004 active_connections の推移](charts/EVT-20260706-host15-004.svg)

# イベントID( EVT-20260706-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→14→…→15→14→13→15
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:40:00 (UTC)
* 現象   : 2026-07-06 20:40:00 (UTC)を境に水準が 11.82から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-005 active_connections の推移](charts/EVT-20260706-host15-005.svg)

# イベントID( EVT-20260706-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→15→…→13→15→12→13
* 開始   : 2026-07-06 03:50:00 (UTC)
* 終了   : 2026-07-06 20:40:00 (UTC)
* 現象   : 2026-07-06 20:40:00 (UTC)を境に水準が 11.91から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.066, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.751, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-006 active_connections の推移](charts/EVT-20260706-host15-006.svg)

# イベントID( EVT-20260713-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→14→…→12→14→13→14
* 開始   : 2026-07-13 02:00:00 (UTC)
* 終了   : 2026-07-13 20:15:00 (UTC)
* 現象   : 2026-07-13 20:15:00 (UTC)を境に水準が 11.76から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.019, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.848, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-001 active_connections の推移](charts/EVT-20260713-host15-001.svg)

# イベントID( EVT-20260713-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→14→15→13→…→14→15→14→15
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 20:35:00 (UTC)
* 現象   : 2026-07-13 20:35:00 (UTC)を境に水準が 11.75から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-002 active_connections の推移](charts/EVT-20260713-host15-002.svg)

# イベントID( EVT-20260713-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→16→…→16→15→13→14
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 20:30:00 (UTC)
* 現象   : 2026-07-13 20:30:00 (UTC)を境に水準が 11.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.762, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.338, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-004 active_connections の推移](charts/EVT-20260713-host15-004.svg)

# イベントID( EVT-20260713-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→…→13→14→15→13
* 開始   : 2026-07-13 03:40:00 (UTC)
* 終了   : 2026-07-13 20:50:00 (UTC)
* 現象   : 2026-07-13 20:50:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.167, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-005 active_connections の推移](charts/EVT-20260713-host15-005.svg)

# イベントID( EVT-20260713-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→12→14→15→12
* 開始   : 2026-07-13 04:20:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.91から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-006 active_connections の推移](charts/EVT-20260713-host15-006.svg)

# イベントID( EVT-20260720-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→14→…→14→13→14→12
* 開始   : 2026-07-20 02:15:00 (UTC)
* 終了   : 2026-07-20 19:30:00 (UTC)
* 現象   : 2026-07-20 19:30:00 (UTC)を境に水準が 11.82から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.891σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 5.059 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.126, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-001 active_connections の推移](charts/EVT-20260720-host15-001.svg)

# イベントID( EVT-20260720-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→16→15→14→…→14→11→13→12
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.73から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.446, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-002 active_connections の推移](charts/EVT-20260720-host15-002.svg)

# イベントID( EVT-20260720-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→18→17→15→…→15→14→13→14
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 22:05:00 (UTC)
* 現象   : 2026-07-20 22:05:00 (UTC)を境に水準が 11.76から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.917, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-003 active_connections の推移](charts/EVT-20260720-host15-003.svg)

# イベントID( EVT-20260720-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→14→16→14→15
* 開始   : 2026-07-20 03:30:00 (UTC)
* 終了   : 2026-07-20 21:35:00 (UTC)
* 現象   : 2026-07-20 21:35:00 (UTC)を境に水準が 11.96から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.981, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-006 active_connections の推移](charts/EVT-20260720-host15-006.svg)

# イベントID( EVT-20260727-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→14→…→13→15→12→13
* 開始   : 2026-07-27 02:25:00 (UTC)
* 終了   : 2026-07-27 20:35:00 (UTC)
* 現象   : 2026-07-27 20:35:00 (UTC)を境に水準が 11.72から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-001 active_connections の推移](charts/EVT-20260727-host15-001.svg)

# イベントID( EVT-20260727-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→16→…→16→14→12→15
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 19:20:00 (UTC)
* 現象   : 2026-07-27 19:20:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.788, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-002 active_connections の推移](charts/EVT-20260727-host15-002.svg)

# イベントID( EVT-20260727-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→12→13→12→13
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.79から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.865, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.902, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-003 active_connections の推移](charts/EVT-20260727-host15-003.svg)

# イベントID( EVT-20260727-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→13→…→16→15→13→15
* 開始   : 2026-07-27 02:40:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.75から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.053, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.675, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-004 active_connections の推移](charts/EVT-20260727-host15-004.svg)

# イベントID( EVT-20260727-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→14→…→15→13→15→13
* 開始   : 2026-07-27 03:25:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 11.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.131, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-006 active_connections の推移](charts/EVT-20260727-host15-006.svg)

# イベントID( EVT-20260701-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→15→18→12→17→15→18→12→17
* 開始   : 2026-07-01 05:20:00 (UTC)
* 終了   : 2026-07-01 06:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 35 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260701-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 1.0 時間
  - EVT-20260701-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260701-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→15→14→13→12→14→14
* 開始   : 2026-07-01 18:20:00 (UTC)
* 終了   : 2026-07-01 19:40:00 (UTC)
* 現象   : 2026-07-01 19:40:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→11→8→12→…→12→10→11→13
* 開始   : 2026-07-01 19:25:00 (UTC)
* 終了   : 2026-07-01 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260701-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260701-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host15-010 active_connections の推移](charts/EVT-20260701-host15-010.svg)

# イベントID( EVT-20260702-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→16→18→17→…→18→17→13→14
* 開始   : 2026-07-02 05:40:00 (UTC)
* 終了   : 2026-07-02 05:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260702-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→18→14→19→18
* 開始   : 2026-07-02 16:00:00 (UTC)
* 終了   : 2026-07-02 16:00:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host15-003 active_connections の推移](charts/EVT-20260702-host15-003.svg)

# イベントID( EVT-20260702-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→18→15→17→20
* 開始   : 2026-07-02 16:15:00 (UTC)
* 終了   : 2026-07-02 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→18→13→17→18
* 開始   : 2026-07-02 16:30:00 (UTC)
* 終了   : 2026-07-02 16:30:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.6964(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.959σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host15-005 active_connections の推移](charts/EVT-20260702-host15-005.svg)

# イベントID( EVT-20260703-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→24→26→22→21
* 開始   : 2026-07-03 11:50:00 (UTC)
* 終了   : 2026-07-03 11:50:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→9→4→10→8
* 開始   : 2026-07-04 00:00:00 (UTC)
* 終了   : 2026-07-04 00:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→9→…→11→10→13→12
* 開始   : 2026-07-04 04:30:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.017, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260704-host15-003 active_connections の推移](charts/EVT-20260704-host15-003.svg)

# イベントID( EVT-20260704-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→13→…→12→10→12→10
* 開始   : 2026-07-04 04:40:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260704-host15-004 active_connections の推移](charts/EVT-20260704-host15-004.svg)

# イベントID( EVT-20260704-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→11→…→12→10→11→10
* 開始   : 2026-07-04 04:50:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.738, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260704-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260704-host15-005 active_connections の推移](charts/EVT-20260704-host15-005.svg)

# イベントID( EVT-20260704-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→10→…→14→13→12→14
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.119, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host15-006 active_connections の推移](charts/EVT-20260704-host15-006.svg)

# イベントID( EVT-20260704-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→13→…→13→11→13→12
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 18:25:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260704-host15-007 active_connections の推移](charts/EVT-20260704-host15-007.svg)

# イベントID( EVT-20260704-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→11→…→11→12→14→10
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.131, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host15-008 active_connections の推移](charts/EVT-20260704-host15-008.svg)

# イベントID( EVT-20260705-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→5→8→12→5→8→12→10
* 開始   : 2026-07-05 02:55:00 (UTC)
* 終了   : 2026-07-05 03:05:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260705-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→14→16→17→…→13→15→13→12
* 開始   : 2026-07-06 02:40:00 (UTC)
* 終了   : 2026-07-06 20:20:00 (UTC)
* 現象   : 2026-07-06 20:20:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.756, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.743, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→11→15→11→10
* 開始   : 2026-07-07 03:45:00 (UTC)
* 終了   : 2026-07-07 03:45:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→20→15→17
* 開始   : 2026-07-07 06:50:00 (UTC)
* 終了   : 2026-07-07 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→21→22→24→26→24→20→22→22
* 開始   : 2026-07-07 10:40:00 (UTC)
* 終了   : 2026-07-07 11:20:00 (UTC)
* 現象   : 2026-07-07 11:20:00 (UTC)を境に水準が 14.98から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→15→12→11→…→12→11→13→12
* 開始   : 2026-07-07 18:30:00 (UTC)
* 終了   : 2026-07-07 18:35:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→14→9→15→15
* 開始   : 2026-07-07 19:00:00 (UTC)
* 終了   : 2026-07-07 19:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6243(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host15-008 active_connections の推移](charts/EVT-20260707-host15-008.svg)

# イベントID( EVT-20260708-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→15→16
* 開始   : 2026-07-08 05:30:00 (UTC)
* 終了   : 2026-07-08 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→19→…→17→19→13→16
* 開始   : 2026-07-08 05:55:00 (UTC)
* 終了   : 2026-07-08 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host15-005 active_connections の推移](charts/EVT-20260708-host15-005.svg)

# イベントID( EVT-20260708-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→20→16→18
* 開始   : 2026-07-08 06:50:00 (UTC)
* 終了   : 2026-07-08 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260708-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→24→18→23→…→23→17→20→22
* 開始   : 2026-07-09 09:20:00 (UTC)
* 終了   : 2026-07-09 09:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→13→17→12→14
* 開始   : 2026-07-10 05:15:00 (UTC)
* 終了   : 2026-07-10 05:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→12→13→11→12
* 開始   : 2026-07-11 04:35:00 (UTC)
* 終了   : 2026-07-11 18:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.755, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260711-host15-002 active_connections の推移](charts/EVT-20260711-host15-002.svg)

# イベントID( EVT-20260711-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→11→13→…→13→11→13→12
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 20:00:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.839, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260711-host15-003 active_connections の推移](charts/EVT-20260711-host15-003.svg)

# イベントID( EVT-20260711-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→11→…→12→14→10→11
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.079, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host15-004 active_connections の推移](charts/EVT-20260711-host15-004.svg)

# イベントID( EVT-20260711-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→13→11→10→13
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.231, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260711-host15-005 active_connections の推移](charts/EVT-20260711-host15-005.svg)

# イベントID( EVT-20260711-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→11→…→11→12→15→11
* 開始   : 2026-07-11 06:00:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260711-host15-006 active_connections の推移](charts/EVT-20260711-host15-006.svg)

# イベントID( EVT-20260711-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→12→…→13→11→13→12
* 開始   : 2026-07-11 06:00:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.894, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260711-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260711-host15-007 active_connections の推移](charts/EVT-20260711-host15-007.svg)

# イベントID( EVT-20260712-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→12→7→9→11
* 開始   : 2026-07-12 19:15:00 (UTC)
* 終了   : 2026-07-12 19:15:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260712-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→14→…→14→12→11→10
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 19:40:00 (UTC)
* 現象   : 2026-07-13 19:40:00 (UTC)を境に水準が 11.69から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.918, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→11→15→9→12
* 開始   : 2026-07-14 03:50:00 (UTC)
* 終了   : 2026-07-14 03:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260714-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→16→18
* 開始   : 2026-07-14 06:15:00 (UTC)
* 終了   : 2026-07-14 06:15:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→18→14→18→17
* 開始   : 2026-07-14 16:35:00 (UTC)
* 終了   : 2026-07-14 16:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→16→12→15→16
* 開始   : 2026-07-14 18:00:00 (UTC)
* 終了   : 2026-07-14 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→20→17→20→…→21→17→20→21
* 開始   : 2026-07-15 14:45:00 (UTC)
* 終了   : 2026-07-15 15:15:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260715-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260715-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→9→6→10→10
* 開始   : 2026-07-15 21:15:00 (UTC)
* 終了   : 2026-07-15 21:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→9→7
* 開始   : 2026-07-16 01:25:00 (UTC)
* 終了   : 2026-07-16 01:25:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.677倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→8→10
* 開始   : 2026-07-16 21:15:00 (UTC)
* 終了   : 2026-07-16 21:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→21→17→18
* 開始   : 2026-07-17 07:40:00 (UTC)
* 終了   : 2026-07-17 07:40:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→16→18→18→17→16→16
* 開始   : 2026-07-17 16:55:00 (UTC)
* 終了   : 2026-07-17 17:45:00 (UTC)
* 現象   : 2026-07-17 17:45:00 (UTC)を境に水準が 14.98から12.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→10→13→15→11→10→13
* 開始   : 2026-07-17 19:15:00 (UTC)
* 終了   : 2026-07-17 20:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 55 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分

![EVT-20260717-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→12→8→13→…→14→12→14→11
* 開始   : 2026-07-18 05:10:00 (UTC)
* 終了   : 2026-07-18 19:40:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.889, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host15-001 active_connections の推移](charts/EVT-20260718-host15-001.svg)

# イベントID( EVT-20260718-host15-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→9→10→12→…→9→10→11→13
* 開始   : 2026-07-18 05:15:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.904, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host15-002 active_connections の推移](charts/EVT-20260718-host15-002.svg)

# イベントID( EVT-20260718-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10→…→14→15→12→13
* 開始   : 2026-07-18 05:35:00 (UTC)
* 終了   : 2026-07-18 19:50:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260718-host15-003 active_connections の推移](charts/EVT-20260718-host15-003.svg)

# イベントID( EVT-20260718-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→13→…→14→13→12→13
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host15-004 active_connections の推移](charts/EVT-20260718-host15-004.svg)

# イベントID( EVT-20260718-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→12→…→10→9→12→10
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 19:15:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260718-host15-005 active_connections の推移](charts/EVT-20260718-host15-005.svg)

# イベントID( EVT-20260718-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→10→…→13→12→11→13
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.999, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host15-006 active_connections の推移](charts/EVT-20260718-host15-006.svg)

# イベントID( EVT-20260719-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 8→9→4→7→9
* 開始   : 2026-07-19 00:10:00 (UTC)
* 終了   : 2026-07-19 00:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.4404(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→9→14→11→13
* 開始   : 2026-07-19 04:45:00 (UTC)
* 終了   : 2026-07-19 04:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→17→…→15→17→14→13
* 開始   : 2026-07-19 07:10:00 (UTC)
* 終了   : 2026-07-19 07:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→12→13
* 開始   : 2026-07-19 16:55:00 (UTC)
* 終了   : 2026-07-19 16:55:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.6506(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260719-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→13→8→11→13
* 開始   : 2026-07-19 17:55:00 (UTC)
* 終了   : 2026-07-19 17:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→9→7→9→11→10→7→8→9
* 開始   : 2026-07-19 23:05:00 (UTC)
* 終了   : 2026-07-20 00:30:00 (UTC)
* 現象   : 2026-07-20 00:30:00 (UTC)を境に水準が 11.83から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→16→15→16→…→12→13→11→12
* 開始   : 2026-07-20 02:45:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.932, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.313, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-004 active_connections の推移](charts/EVT-20260720-host15-004.svg)

# イベントID( EVT-20260720-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→15→…→13→14→13→14
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.87から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.104, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→8→11→6→8→10
* 開始   : 2026-07-20 20:55:00 (UTC)
* 終了   : 2026-07-20 21:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→21→17→22→23
* 開始   : 2026-07-21 12:30:00 (UTC)
* 終了   : 2026-07-21 12:30:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.764(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host15-007 active_connections の推移](charts/EVT-20260721-host15-007.svg)

# イベントID( EVT-20260721-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→19→16→20→21
* 開始   : 2026-07-21 14:55:00 (UTC)
* 終了   : 2026-07-21 14:55:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→20→16→19→19
* 開始   : 2026-07-21 15:25:00 (UTC)
* 終了   : 2026-07-21 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→13→10→13→13
* 開始   : 2026-07-21 18:50:00 (UTC)
* 終了   : 2026-07-21 18:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→8→4→8→9
* 開始   : 2026-07-21 23:40:00 (UTC)
* 終了   : 2026-07-21 23:40:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→15→17→18→15→17→18→15→16
* 開始   : 2026-07-22 05:35:00 (UTC)
* 終了   : 2026-07-22 05:40:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.316倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→16→15
* 開始   : 2026-07-22 06:40:00 (UTC)
* 終了   : 2026-07-22 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→18→16
* 開始   : 2026-07-22 06:50:00 (UTC)
* 終了   : 2026-07-22 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→19→15→17→20
* 開始   : 2026-07-22 16:00:00 (UTC)
* 終了   : 2026-07-22 16:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.766(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→14→12→17→16
* 開始   : 2026-07-22 17:55:00 (UTC)
* 終了   : 2026-07-22 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→13→10→13→10→12→11
* 開始   : 2026-07-22 19:40:00 (UTC)
* 終了   : 2026-07-22 20:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-019 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260722-host13-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260722-host15-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→13→7→10→11
* 開始   : 2026-07-22 20:05:00 (UTC)
* 終了   : 2026-07-22 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-019 active_connections の推移](charts/EVT-20260722-host15-019.svg)

# イベントID( EVT-20260722-host15-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→12→7→9→8
* 開始   : 2026-07-22 20:45:00 (UTC)
* 終了   : 2026-07-22 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-078 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host15-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→14→18→15→15
* 開始   : 2026-07-23 06:00:00 (UTC)
* 終了   : 2026-07-23 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→23→21→23→21→23→21→20
* 開始   : 2026-07-23 08:40:00 (UTC)
* 終了   : 2026-07-23 08:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260723-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→17→14→19→…→15→18→13→18
* 開始   : 2026-07-23 16:35:00 (UTC)
* 終了   : 2026-07-23 16:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→7→4→7→10
* 開始   : 2026-07-24 01:15:00 (UTC)
* 終了   : 2026-07-24 01:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→14→12
* 開始   : 2026-07-24 04:35:00 (UTC)
* 終了   : 2026-07-24 04:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→15→12→14→14
* 開始   : 2026-07-24 17:55:00 (UTC)
* 終了   : 2026-07-24 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→11→8→11→10
* 開始   : 2026-07-24 20:10:00 (UTC)
* 終了   : 2026-07-24 20:10:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→10→11→13→…→12→14→13→12
* 開始   : 2026-07-25 05:20:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.738, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260725-host15-003 active_connections の推移](charts/EVT-20260725-host15-003.svg)

# イベントID( EVT-20260725-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→11→…→11→10→12→10
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:40:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260725-host15-004 active_connections の推移](charts/EVT-20260725-host15-004.svg)

# イベントID( EVT-20260725-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→12→9→13→…→13→14→16→14
* 開始   : 2026-07-25 06:05:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.183, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260725-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260725-host15-005 active_connections の推移](charts/EVT-20260725-host15-005.svg)

# イベントID( EVT-20260725-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→11→…→12→13→12→10
* 開始   : 2026-07-25 06:10:00 (UTC)
* 終了   : 2026-07-25 19:35:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260725-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260725-host15-006 active_connections の推移](charts/EVT-20260725-host15-006.svg)

# イベントID( EVT-20260725-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→13→…→10→11→12→11
* 開始   : 2026-07-25 06:40:00 (UTC)
* 終了   : 2026-07-25 19:20:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.573, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260725-host15-007 active_connections の推移](charts/EVT-20260725-host15-007.svg)

# イベントID( EVT-20260725-host15-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→12→…→11→10→11→10
* 開始   : 2026-07-25 06:50:00 (UTC)
* 終了   : 2026-07-25 19:15:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260725-host15-008 active_connections の推移](charts/EVT-20260725-host15-008.svg)

# イベントID( EVT-20260726-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→8→13→10→10
* 開始   : 2026-07-26 02:25:00 (UTC)
* 終了   : 2026-07-26 02:25:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→16→15→16→…→14→12→13→11
* 開始   : 2026-07-27 02:45:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 11.78から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.496, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→12→15→11→11
* 開始   : 2026-07-28 04:00:00 (UTC)
* 終了   : 2026-07-28 04:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→11→15→12→13
* 開始   : 2026-07-28 04:15:00 (UTC)
* 終了   : 2026-07-28 04:15:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→12→17→13→14
* 開始   : 2026-07-28 05:10:00 (UTC)
* 終了   : 2026-07-28 06:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260728-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host15-004 active_connections の推移](charts/EVT-20260728-host15-004.svg)

# イベントID( EVT-20260728-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→16→19→15→17
* 開始   : 2026-07-28 06:40:00 (UTC)
* 終了   : 2026-07-28 06:40:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→16→16
* 開始   : 2026-07-28 06:40:00 (UTC)
* 終了   : 2026-07-28 06:40:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→22→26→20→19
* 開始   : 2026-07-28 10:10:00 (UTC)
* 終了   : 2026-07-28 10:10:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.284倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-008 active_connections の推移](charts/EVT-20260728-host15-008.svg)

# イベントID( EVT-20260728-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→18→16→20→20
* 開始   : 2026-07-28 15:15:00 (UTC)
* 終了   : 2026-07-28 15:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→16→11→13→13
* 開始   : 2026-07-28 18:20:00 (UTC)
* 終了   : 2026-07-28 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host15-014 active_connections の推移](charts/EVT-20260728-host15-014.svg)

# イベントID( EVT-20260728-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→11→…→8→14→9→11
* 開始   : 2026-07-28 19:55:00 (UTC)
* 終了   : 2026-07-28 20:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host15-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 22→20→18→16→…→18→16→19→22
* 開始   : 2026-07-29 15:00:00 (UTC)
* 終了   : 2026-07-29 15:05:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→12→9→12→9→10→11
* 開始   : 2026-07-29 19:45:00 (UTC)
* 終了   : 2026-07-29 20:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260729-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260729-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→9→4→9→9
* 開始   : 2026-07-29 22:05:00 (UTC)
* 終了   : 2026-07-29 22:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.4211(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host15-009 active_connections の推移](charts/EVT-20260729-host15-009.svg)

# イベントID( EVT-20260730-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 6→9→13→10→9
* 開始   : 2026-07-30 02:05:00 (UTC)
* 終了   : 2026-07-30 02:05:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260730-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→9→13→9→9
* 開始   : 2026-07-30 02:20:00 (UTC)
* 終了   : 2026-07-30 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→14→18→13→13
* 開始   : 2026-07-30 05:20:00 (UTC)
* 終了   : 2026-07-30 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host15-003 active_connections の推移](charts/EVT-20260730-host15-003.svg)

# イベントID( EVT-20260730-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→22→19
* 開始   : 2026-07-30 09:10:00 (UTC)
* 終了   : 2026-07-30 09:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host15-004 active_connections の推移](charts/EVT-20260730-host15-004.svg)

# イベントID( EVT-20260730-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→22→22→24→24→20→23→26
* 開始   : 2026-07-30 10:35:00 (UTC)
* 終了   : 2026-07-30 12:05:00 (UTC)
* 現象   : 2026-07-30 12:05:00 (UTC)を境に水準が 14.86から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 23→22→26→22→22
* 開始   : 2026-07-31 11:30:00 (UTC)
* 終了   : 2026-07-31 11:30:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→23→26→23→21
* 開始   : 2026-07-31 13:25:00 (UTC)
* 終了   : 2026-07-31 13:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→22→17→20→19
* 開始   : 2026-07-31 15:05:00 (UTC)
* 終了   : 2026-07-31 15:05:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→18→16→20→…→20→15→17→19
* 開始   : 2026-07-31 16:45:00 (UTC)
* 終了   : 2026-07-31 17:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分

![EVT-20260731-host15-013 active_connections の推移](charts/EVT-20260731-host15-013.svg)

# イベントID( EVT-20260731-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→13→12→16→…→16→10→13→15
* 開始   : 2026-07-31 18:30:00 (UTC)
* 終了   : 2026-07-31 18:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260731-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host15-014 active_connections の推移](charts/EVT-20260731-host15-014.svg)

# イベントID( EVT-20260731-host15-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→9→6→8→9→6→10
* 開始   : 2026-07-31 20:50:00 (UTC)
* 終了   : 2026-07-31 21:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host15-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→13→12→12→12→13→12
* 開始   : 2026-07-01 03:05:00 (UTC)
* 終了   : 2026-07-01 03:35:00 (UTC)
* 現象   : 2026-07-01 03:35:00 (UTC)を境に水準が 15.09から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→11→13→9→11→13→9→12
* 開始   : 2026-07-01 03:20:00 (UTC)
* 終了   : 2026-07-01 03:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→18→…→17→18→15→16
* 開始   : 2026-07-01 06:00:00 (UTC)
* 終了   : 2026-07-01 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→17→19→19→20→21
* 開始   : 2026-07-01 07:30:00 (UTC)
* 終了   : 2026-07-01 07:55:00 (UTC)
* 現象   : 2026-07-01 07:55:00 (UTC)を境に水準が 15.03から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.167, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→16→20→21→…→20→21→18→19
* 開始   : 2026-07-01 07:50:00 (UTC)
* 終了   : 2026-07-01 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260701-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→20→20→19→19
* 開始   : 2026-07-01 15:15:00 (UTC)
* 終了   : 2026-07-01 15:35:00 (UTC)
* 現象   : 2026-07-01 15:35:00 (UTC)を境に水準が 14.96から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→13→14→11→13
* 開始   : 2026-07-01 18:45:00 (UTC)
* 終了   : 2026-07-01 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→13→8→13→8→9
* 開始   : 2026-07-01 21:25:00 (UTC)
* 終了   : 2026-07-01 21:30:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260701-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→17→20→15
* 開始   : 2026-07-02 07:45:00 (UTC)
* 終了   : 2026-07-02 07:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→15→12→13→…→13→11→12→13
* 開始   : 2026-07-02 18:15:00 (UTC)
* 終了   : 2026-07-02 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260702-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→10→5→11→10→5→11→10→8
* 開始   : 2026-07-02 23:45:00 (UTC)
* 終了   : 2026-07-02 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→20→18→21→20→18→21→17
* 開始   : 2026-07-03 07:25:00 (UTC)
* 終了   : 2026-07-03 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 24→23→22→22→21→22→24→23→24
* 開始   : 2026-07-03 10:15:00 (UTC)
* 終了   : 2026-07-03 11:30:00 (UTC)
* 現象   : 2026-07-03 11:30:00 (UTC)を境に水準が 15.06から13.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.812, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→23→21→21→21→23
* 開始   : 2026-07-03 13:50:00 (UTC)
* 終了   : 2026-07-03 14:15:00 (UTC)
* 現象   : 2026-07-03 14:15:00 (UTC)を境に水準が 14.97から12.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.167, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→13→15→15→14
* 開始   : 2026-07-03 18:15:00 (UTC)
* 終了   : 2026-07-03 18:35:00 (UTC)
* 現象   : 2026-07-03 18:35:00 (UTC)を境に水準が 14.96から12.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→16→12→17→12→17→12→14→12
* 開始   : 2026-07-03 18:20:00 (UTC)
* 終了   : 2026-07-03 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260703-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→11→13→10→11→13
* 開始   : 2026-07-03 19:35:00 (UTC)
* 終了   : 2026-07-03 19:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→9→8→11→13→9→8→11
* 開始   : 2026-07-03 20:35:00 (UTC)
* 終了   : 2026-07-03 20:40:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→7→6→7→6→7→8
* 開始   : 2026-07-03 23:00:00 (UTC)
* 終了   : 2026-07-03 23:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-083 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→11→12→11→12→10→8
* 開始   : 2026-07-04 03:00:00 (UTC)
* 終了   : 2026-07-04 03:10:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.44倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260704-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→9→8→11→9→8
* 開始   : 2026-07-05 01:45:00 (UTC)
* 終了   : 2026-07-05 01:50:00 (UTC)
* 現象   : 平常時(7.083)に対し 1.553倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260705-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→12→13→10→…→7→13→11→10
* 開始   : 2026-07-05 04:20:00 (UTC)
* 終了   : 2026-07-05 04:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→13→14→10→…→10→15→13→14
* 開始   : 2026-07-05 05:50:00 (UTC)
* 終了   : 2026-07-05 06:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→12→15→12→…→12→9→14→12
* 開始   : 2026-07-05 06:25:00 (UTC)
* 終了   : 2026-07-05 06:35:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260705-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→16→15→18→16
* 開始   : 2026-07-05 13:05:00 (UTC)
* 終了   : 2026-07-05 13:10:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→15→16→13→12→15→15
* 開始   : 2026-07-05 16:20:00 (UTC)
* 終了   : 2026-07-05 16:50:00 (UTC)
* 現象   : 2026-07-05 16:50:00 (UTC)を境に水準が 11.8から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→10→8→10→8→11
* 開始   : 2026-07-05 19:20:00 (UTC)
* 終了   : 2026-07-05 19:25:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→9→9→11→8→8→8→7
* 開始   : 2026-07-06 23:00:00 (UTC)
* 終了   : 2026-07-06 23:35:00 (UTC)
* 現象   : 2026-07-06 23:35:00 (UTC)を境に水準が 14.95から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→18→17→20→18→17
* 開始   : 2026-07-07 07:35:00 (UTC)
* 終了   : 2026-07-07 07:40:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 23→24→23→23→21→23→23→22→23
* 開始   : 2026-07-07 12:45:00 (UTC)
* 終了   : 2026-07-07 13:55:00 (UTC)
* 現象   : 2026-07-07 13:55:00 (UTC)を境に水準が 14.92から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.699, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 21→22→21→24→22→19→22→22→20
* 開始   : 2026-07-07 13:50:00 (UTC)
* 終了   : 2026-07-07 14:45:00 (UTC)
* 現象   : 2026-07-07 14:45:00 (UTC)を境に水準が 14.94から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→9→10→9→10→9→12→11
* 開始   : 2026-07-07 20:20:00 (UTC)
* 終了   : 2026-07-07 20:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→9→…→7→9→6→9
* 開始   : 2026-07-07 21:55:00 (UTC)
* 終了   : 2026-07-07 22:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260707-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→12→15→13→…→13→15→13→12
* 開始   : 2026-07-08 04:30:00 (UTC)
* 終了   : 2026-07-08 04:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 20 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→16→…→15→16→14→11
* 開始   : 2026-07-08 05:05:00 (UTC)
* 終了   : 2026-07-08 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→14→15→14→16→15→14→16→14
* 開始   : 2026-07-08 05:05:00 (UTC)
* 終了   : 2026-07-08 05:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→22→25→23→…→25→19→24→22
* 開始   : 2026-07-08 12:05:00 (UTC)
* 終了   : 2026-07-08 12:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→19→24→17→…→24→17→20→19
* 開始   : 2026-07-08 15:25:00 (UTC)
* 終了   : 2026-07-08 15:30:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.21倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→15→17→19→15→17→15
* 開始   : 2026-07-08 17:05:00 (UTC)
* 終了   : 2026-07-08 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260708-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→17→16→13→17→15→13
* 開始   : 2026-07-09 05:25:00 (UTC)
* 終了   : 2026-07-09 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→16→17→14→…→14→11→14→12
* 開始   : 2026-07-09 05:35:00 (UTC)
* 終了   : 2026-07-09 05:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host15-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→23→24→20→18→24→20→18→21
* 開始   : 2026-07-09 10:15:00 (UTC)
* 終了   : 2026-07-09 10:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→19→21→25→19→21→25→23
* 開始   : 2026-07-09 11:20:00 (UTC)
* 終了   : 2026-07-09 11:30:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→18→18→16→16→17→16→17→16
* 開始   : 2026-07-09 15:50:00 (UTC)
* 終了   : 2026-07-09 18:10:00 (UTC)
* 現象   : 2026-07-09 18:10:00 (UTC)を境に水準が 14.93から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→15→18→15→18→20
* 開始   : 2026-07-09 16:50:00 (UTC)
* 終了   : 2026-07-09 16:55:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7965(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→16→12→15→12→15→12→14→16
* 開始   : 2026-07-09 18:15:00 (UTC)
* 終了   : 2026-07-09 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260709-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260709-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→8→10→9→9→8→8→8→9
* 開始   : 2026-07-09 23:15:00 (UTC)
* 終了   : 2026-07-10 00:00:00 (UTC)
* 現象   : 2026-07-10 00:00:00 (UTC)を境に水準が 14.99から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→13→11→9→13→11→10
* 開始   : 2026-07-10 03:15:00 (UTC)
* 終了   : 2026-07-10 03:20:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→14→…→14→17→13→16
* 開始   : 2026-07-10 04:15:00 (UTC)
* 終了   : 2026-07-10 05:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.424倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→16→18→16→17
* 開始   : 2026-07-10 06:25:00 (UTC)
* 終了   : 2026-07-10 06:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→17→19→20→17→19→20→17→16
* 開始   : 2026-07-10 07:05:00 (UTC)
* 終了   : 2026-07-10 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→16→…→16→13→17→16
* 開始   : 2026-07-10 17:15:00 (UTC)
* 終了   : 2026-07-10 17:25:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260710-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→14→12→11→14→11
* 開始   : 2026-07-10 18:55:00 (UTC)
* 終了   : 2026-07-10 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→10→11→9→10→11→9→11
* 開始   : 2026-07-10 20:00:00 (UTC)
* 終了   : 2026-07-10 20:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→9→7→10→6→7→10→6→7
* 開始   : 2026-07-10 21:55:00 (UTC)
* 終了   : 2026-07-10 22:05:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→10→7→10→8→9→10→8→11
* 開始   : 2026-07-10 23:55:00 (UTC)
* 終了   : 2026-07-11 00:35:00 (UTC)
* 現象   : 2026-07-11 00:35:00 (UTC)を境に水準が 14.99から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.751, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 7→11→9→7→11→9
* 開始   : 2026-07-11 02:25:00 (UTC)
* 終了   : 2026-07-11 02:30:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260711-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host15-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 9→11→10→11→10→12→10→12→11
* 開始   : 2026-07-11 19:25:00 (UTC)
* 終了   : 2026-07-11 19:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260711-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→10→9→13→10
* 開始   : 2026-07-12 05:00:00 (UTC)
* 終了   : 2026-07-12 05:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260712-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→13→8→14→…→8→14→11→10
* 開始   : 2026-07-12 05:50:00 (UTC)
* 終了   : 2026-07-12 05:55:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→10→…→10→15→12→10
* 開始   : 2026-07-12 06:10:00 (UTC)
* 終了   : 2026-07-12 06:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→15→…→11→17→14→16
* 開始   : 2026-07-12 08:40:00 (UTC)
* 終了   : 2026-07-12 08:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→9→14→12→14→12→14→11→12
* 開始   : 2026-07-14 04:10:00 (UTC)
* 終了   : 2026-07-14 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260714-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→8→…→14→8→14→10
* 開始   : 2026-07-14 04:20:00 (UTC)
* 終了   : 2026-07-14 04:25:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260714-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→15→16→17→15→16→17→15
* 開始   : 2026-07-14 05:25:00 (UTC)
* 終了   : 2026-07-14 05:30:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260714-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→16→15→20→…→17→14→18→16
* 開始   : 2026-07-14 16:30:00 (UTC)
* 終了   : 2026-07-14 16:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→14→…→15→14→15→19
* 開始   : 2026-07-14 16:50:00 (UTC)
* 終了   : 2026-07-14 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→12→14→16→13→12→14
* 開始   : 2026-07-14 18:00:00 (UTC)
* 終了   : 2026-07-14 18:05:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→15→12→13→…→13→11→14→15
* 開始   : 2026-07-14 18:40:00 (UTC)
* 終了   : 2026-07-14 18:50:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→11→12→9→11
* 開始   : 2026-07-14 20:10:00 (UTC)
* 終了   : 2026-07-14 20:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→12→14→11→12→14→11→13
* 開始   : 2026-07-15 03:55:00 (UTC)
* 終了   : 2026-07-15 04:00:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→14→15→11→15→11→15→13
* 開始   : 2026-07-15 04:45:00 (UTC)
* 終了   : 2026-07-15 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→16→…→16→19→15→17
* 開始   : 2026-07-15 06:20:00 (UTC)
* 終了   : 2026-07-15 06:30:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→19→15→20→19
* 開始   : 2026-07-15 07:30:00 (UTC)
* 終了   : 2026-07-15 07:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.237倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→18→…→19→18→23→21
* 開始   : 2026-07-15 14:10:00 (UTC)
* 終了   : 2026-07-15 14:15:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→18→16→19→16→19→16→18
* 開始   : 2026-07-15 16:05:00 (UTC)
* 終了   : 2026-07-15 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→15→…→15→13→14→17
* 開始   : 2026-07-15 17:40:00 (UTC)
* 終了   : 2026-07-15 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→16→…→16→12→14→15
* 開始   : 2026-07-15 18:20:00 (UTC)
* 終了   : 2026-07-15 18:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260715-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→9→9→9→8→9→10
* 開始   : 2026-07-15 23:15:00 (UTC)
* 終了   : 2026-07-16 00:25:00 (UTC)
* 現象   : 2026-07-16 00:25:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.566, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→12→13→14→13→14→11→10
* 開始   : 2026-07-16 04:05:00 (UTC)
* 終了   : 2026-07-16 04:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→11→16→15→16→15→16→13→16
* 開始   : 2026-07-16 05:20:00 (UTC)
* 終了   : 2026-07-16 05:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260716-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→16→20→17→20→17→20→18
* 開始   : 2026-07-16 07:10:00 (UTC)
* 終了   : 2026-07-16 07:20:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.27倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→19→19→19→20→20→19→20→17
* 開始   : 2026-07-16 15:35:00 (UTC)
* 終了   : 2026-07-16 16:20:00 (UTC)
* 現象   : 2026-07-16 16:20:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→13→12→11→…→12→11→15→12
* 開始   : 2026-07-16 18:45:00 (UTC)
* 終了   : 2026-07-16 18:50:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→9→…→13→7→10→8
* 開始   : 2026-07-16 21:35:00 (UTC)
* 終了   : 2026-07-16 21:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260716-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→10→5→11→5→11→5→7→10
* 開始   : 2026-07-17 00:05:00 (UTC)
* 終了   : 2026-07-17 00:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.5769(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→15→16→17
* 開始   : 2026-07-17 06:10:00 (UTC)
* 終了   : 2026-07-17 06:30:00 (UTC)
* 現象   : 2026-07-17 06:30:00 (UTC)を境に水準が 14.92から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→23→23→22→22→23→20→24
* 開始   : 2026-07-17 12:45:00 (UTC)
* 終了   : 2026-07-17 13:20:00 (UTC)
* 現象   : 2026-07-17 13:20:00 (UTC)を境に水準が 14.94から13.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.893, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→19→19→19→15
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 17:00:00 (UTC)
* 現象   : 2026-07-17 17:00:00 (UTC)を境に水準が 15.13から12.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.376, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→17→16→18→17→16→18→20
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 16:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→17→18→18→17→17→18→16→18
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 17:45:00 (UTC)
* 現象   : 2026-07-17 17:45:00 (UTC)を境に水準が 15.01から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→9→…→10→9→11→12
* 開始   : 2026-07-17 20:10:00 (UTC)
* 終了   : 2026-07-17 20:15:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→10→11→8→11→8→11→7→9
* 開始   : 2026-07-19 01:25:00 (UTC)
* 終了   : 2026-07-19 01:35:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260719-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→15→15→13→12→16→16→14→13
* 開始   : 2026-07-19 06:25:00 (UTC)
* 終了   : 2026-07-19 07:10:00 (UTC)
* 現象   : 2026-07-19 07:10:00 (UTC)を境に水準が 11.79から12.31へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→13→12→14→12→15→12
* 開始   : 2026-07-19 16:40:00 (UTC)
* 終了   : 2026-07-19 17:55:00 (UTC)
* 現象   : 2026-07-19 17:55:00 (UTC)を境に水準が 11.77から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→8→6→8→6→8→7
* 開始   : 2026-07-19 22:00:00 (UTC)
* 終了   : 2026-07-19 22:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260719-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→15→…→13→15→12→15
* 開始   : 2026-07-21 04:10:00 (UTC)
* 終了   : 2026-07-21 04:25:00 (UTC)
* 現象   : 2026-07-21 04:25:00 (UTC)を境に水準が 14.94から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.453, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→18→17→14→18→13→16
* 開始   : 2026-07-21 06:20:00 (UTC)
* 終了   : 2026-07-21 06:30:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→15→18→15→17
* 開始   : 2026-07-21 06:25:00 (UTC)
* 終了   : 2026-07-21 06:30:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→20→19→21→20
* 開始   : 2026-07-21 08:10:00 (UTC)
* 終了   : 2026-07-21 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→23→21→22→24→20→20→21→23
* 開始   : 2026-07-21 09:30:00 (UTC)
* 終了   : 2026-07-21 10:40:00 (UTC)
* 現象   : 2026-07-21 10:40:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.699, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→23→25→24→25→24→25→22→21
* 開始   : 2026-07-21 11:05:00 (UTC)
* 終了   : 2026-07-21 11:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→20→16→20→16
* 開始   : 2026-07-21 16:15:00 (UTC)
* 終了   : 2026-07-21 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260721-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→20→19
* 開始   : 2026-07-21 16:45:00 (UTC)
* 終了   : 2026-07-21 16:55:00 (UTC)
* 現象   : 2026-07-21 16:55:00 (UTC)を境に水準が 15.03から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→14→11→12
* 開始   : 2026-07-21 18:55:00 (UTC)
* 終了   : 2026-07-21 19:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host15-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 8→9→9→10→10→12→10→8→12
* 開始   : 2026-07-21 20:55:00 (UTC)
* 終了   : 2026-07-21 21:35:00 (UTC)
* 現象   : 2026-07-21 21:35:00 (UTC)を境に水準が 15.01から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.019, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host15-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→10→11→9
* 開始   : 2026-07-22 00:10:00 (UTC)
* 終了   : 2026-07-22 00:25:00 (UTC)
* 現象   : 2026-07-22 00:25:00 (UTC)を境に水準が 14.93から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 7→10→5→8→…→8→11→8→9
* 開始   : 2026-07-22 01:05:00 (UTC)
* 終了   : 2026-07-22 01:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260722-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→9→11→8→9→10→10→11→9
* 開始   : 2026-07-22 01:20:00 (UTC)
* 終了   : 2026-07-22 02:00:00 (UTC)
* 現象   : 2026-07-22 02:00:00 (UTC)を境に水準が 14.98から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→14→10→14→10→14→12
* 開始   : 2026-07-22 04:10:00 (UTC)
* 終了   : 2026-07-22 04:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260722-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→11→16→14→…→14→17→16→15
* 開始   : 2026-07-22 05:20:00 (UTC)
* 終了   : 2026-07-22 05:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→17→17→18
* 開始   : 2026-07-22 05:50:00 (UTC)
* 終了   : 2026-07-22 06:05:00 (UTC)
* 現象   : 2026-07-22 06:05:00 (UTC)を境に水準が 15.19から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→17→15→18→19→20→19
* 開始   : 2026-07-22 06:30:00 (UTC)
* 終了   : 2026-07-22 07:15:00 (UTC)
* 現象   : 2026-07-22 07:15:00 (UTC)を境に水準が 15.12から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→17→21→17→21→18
* 開始   : 2026-07-22 08:15:00 (UTC)
* 終了   : 2026-07-22 08:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260722-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 20→23→22→21→20→23→22→21→19
* 開始   : 2026-07-22 08:50:00 (UTC)
* 終了   : 2026-07-22 08:55:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.227倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→19→17→19→18
* 開始   : 2026-07-22 15:25:00 (UTC)
* 終了   : 2026-07-22 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260722-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→12→12→11→12→11→12→13→11
* 開始   : 2026-07-22 19:45:00 (UTC)
* 終了   : 2026-07-22 20:50:00 (UTC)
* 現象   : 2026-07-22 20:50:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host15-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host15-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→9→12→11→9→12→11
* 開始   : 2026-07-22 19:50:00 (UTC)
* 終了   : 2026-07-22 19:55:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host15-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→17→16→17→16
* 開始   : 2026-07-23 05:50:00 (UTC)
* 終了   : 2026-07-23 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→17→20→21→17→20→21→17→20
* 開始   : 2026-07-23 07:40:00 (UTC)
* 終了   : 2026-07-23 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260723-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→18→20→18→…→19→21→18→20
* 開始   : 2026-07-23 07:55:00 (UTC)
* 終了   : 2026-07-23 08:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→19→20→21→19→20→23
* 開始   : 2026-07-23 13:10:00 (UTC)
* 終了   : 2026-07-23 13:15:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260723-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→16→15→18→15→18→15→17
* 開始   : 2026-07-23 17:05:00 (UTC)
* 終了   : 2026-07-23 17:15:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→14→16→14→16
* 開始   : 2026-07-23 17:10:00 (UTC)
* 終了   : 2026-07-23 17:15:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→12→16→14→13→12→16
* 開始   : 2026-07-23 18:05:00 (UTC)
* 終了   : 2026-07-23 18:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→12→9→11→9→11→9
* 開始   : 2026-07-23 20:20:00 (UTC)
* 終了   : 2026-07-23 20:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260723-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→13→12→15→13→14
* 開始   : 2026-07-24 04:50:00 (UTC)
* 終了   : 2026-07-24 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→15→…→15→19→18→17
* 開始   : 2026-07-24 06:40:00 (UTC)
* 終了   : 2026-07-24 06:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→19→17→19→17→19→16→17
* 開始   : 2026-07-24 06:50:00 (UTC)
* 終了   : 2026-07-24 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host15-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→19→17→18→19→17→18→17
* 開始   : 2026-07-24 15:25:00 (UTC)
* 終了   : 2026-07-24 15:30:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260724-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→19→22
* 開始   : 2026-07-24 15:35:00 (UTC)
* 終了   : 2026-07-24 15:45:00 (UTC)
* 現象   : 2026-07-24 15:45:00 (UTC)を境に水準が 14.96から12.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.203, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→16→18→16→14→17→15→16→18
* 開始   : 2026-07-24 17:00:00 (UTC)
* 終了   : 2026-07-24 17:50:00 (UTC)
* 現象   : 2026-07-24 17:50:00 (UTC)を境に水準が 15.07から12.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→9→6→9→6→9→10
* 開始   : 2026-07-25 02:35:00 (UTC)
* 終了   : 2026-07-25 02:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→11→12→9→11→12→9→10
* 開始   : 2026-07-25 03:30:00 (UTC)
* 終了   : 2026-07-25 03:35:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 7→10→6→11→…→11→5→9→7
* 開始   : 2026-07-25 22:00:00 (UTC)
* 終了   : 2026-07-25 22:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260725-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→9→10→7→9→9→8→8→10
* 開始   : 2026-07-25 23:10:00 (UTC)
* 終了   : 2026-07-25 23:55:00 (UTC)
* 現象   : 2026-07-25 23:55:00 (UTC)を境に水準が 11.77から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.366, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260725-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→10→9→10→9→9→11→10→9
* 開始   : 2026-07-26 01:15:00 (UTC)
* 終了   : 2026-07-26 01:55:00 (UTC)
* 現象   : 2026-07-26 01:55:00 (UTC)を境に水準が 11.8から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.751, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→12→13→9→…→9→7→8→12
* 開始   : 2026-07-26 04:25:00 (UTC)
* 終了   : 2026-07-26 04:35:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260726-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260726-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→14→13→16→14→13
* 開始   : 2026-07-26 07:35:00 (UTC)
* 終了   : 2026-07-26 07:40:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→15→17→16→14→15→17→16→14
* 開始   : 2026-07-26 07:50:00 (UTC)
* 終了   : 2026-07-26 07:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.333倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260726-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→18→17→18
* 開始   : 2026-07-26 10:55:00 (UTC)
* 終了   : 2026-07-26 11:10:00 (UTC)
* 現象   : 2026-07-26 11:10:00 (UTC)を境に水準が 11.8から13.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→19→13→18→15→19→13→18→13
* 開始   : 2026-07-26 13:20:00 (UTC)
* 終了   : 2026-07-26 13:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260726-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→9→5→7→5→7→5→9→6
* 開始   : 2026-07-26 23:30:00 (UTC)
* 終了   : 2026-07-26 23:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→9→10→8→10→9→7→10→13
* 開始   : 2026-07-27 20:50:00 (UTC)
* 終了   : 2026-07-27 22:00:00 (UTC)
* 現象   : 2026-07-27 22:00:00 (UTC)を境に水準が 14.74から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→8→9→8→9→9→9→12→12
* 開始   : 2026-07-28 01:20:00 (UTC)
* 終了   : 2026-07-28 02:30:00 (UTC)
* 現象   : 2026-07-28 02:30:00 (UTC)を境に水準が 14.88から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.013, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→21→20→18→21→20→19
* 開始   : 2026-07-28 08:15:00 (UTC)
* 終了   : 2026-07-28 08:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→22→22→23→21→23→22→23→25
* 開始   : 2026-07-28 10:30:00 (UTC)
* 終了   : 2026-07-28 12:40:00 (UTC)
* 現象   : 2026-07-28 12:40:00 (UTC)を境に水準が 14.97から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→20→16→18→16→18→16→20→16
* 開始   : 2026-07-28 16:35:00 (UTC)
* 終了   : 2026-07-28 16:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→14→15→13→14→13
* 開始   : 2026-07-28 17:40:00 (UTC)
* 終了   : 2026-07-28 17:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→16→13→15→13→15→13→16→13
* 開始   : 2026-07-28 17:50:00 (UTC)
* 終了   : 2026-07-28 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260728-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260728-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→17→14→11→17→14→11
* 開始   : 2026-07-28 19:00:00 (UTC)
* 終了   : 2026-07-28 19:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→9→…→9→6→7→9
* 開始   : 2026-07-28 21:55:00 (UTC)
* 終了   : 2026-07-28 22:05:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260728-host15-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host15-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→9→11→8→9
* 開始   : 2026-07-28 22:10:00 (UTC)
* 終了   : 2026-07-28 22:40:00 (UTC)
* 現象   : 2026-07-28 22:40:00 (UTC)を境に水準が 15から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.362, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host15-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→7→11→10→7→11→10→9
* 開始   : 2026-07-29 01:05:00 (UTC)
* 終了   : 2026-07-29 01:10:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→18→20→18→19→22→22→20→20
* 開始   : 2026-07-29 07:55:00 (UTC)
* 終了   : 2026-07-29 08:45:00 (UTC)
* 現象   : 2026-07-29 08:45:00 (UTC)を境に水準が 14.8から15.15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.743, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 24→22→23→21→21→21→25→21→24
* 開始   : 2026-07-29 10:20:00 (UTC)
* 終了   : 2026-07-29 11:25:00 (UTC)
* 現象   : 2026-07-29 11:25:00 (UTC)を境に水準が 14.89から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.313, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→23→19→20→23→19→20→22
* 開始   : 2026-07-29 14:15:00 (UTC)
* 終了   : 2026-07-29 14:20:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→17→16→16
* 開始   : 2026-07-29 17:40:00 (UTC)
* 終了   : 2026-07-29 17:55:00 (UTC)
* 現象   : 2026-07-29 17:55:00 (UTC)を境に水準が 14.97から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→12→…→13→12→14→15
* 開始   : 2026-07-29 18:10:00 (UTC)
* 終了   : 2026-07-29 18:15:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→11→15→11→15→11→14→13
* 開始   : 2026-07-30 18:55:00 (UTC)
* 終了   : 2026-07-30 19:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260730-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→6→5→9→5→9→5→10→9
* 開始   : 2026-07-31 00:05:00 (UTC)
* 終了   : 2026-07-31 00:15:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-001 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260731-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→10→13→14→11→10→13→14→11
* 開始   : 2026-07-31 03:55:00 (UTC)
* 終了   : 2026-07-31 04:00:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→14→12→16→14→13
* 開始   : 2026-07-31 05:35:00 (UTC)
* 終了   : 2026-07-31 05:40:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→19→18→21→19→20
* 開始   : 2026-07-31 08:15:00 (UTC)
* 終了   : 2026-07-31 08:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→22→20→22→20→21
* 開始   : 2026-07-31 08:55:00 (UTC)
* 終了   : 2026-07-31 09:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→21→23→22→22
* 開始   : 2026-07-31 09:35:00 (UTC)
* 終了   : 2026-07-31 09:55:00 (UTC)
* 現象   : 2026-07-31 09:55:00 (UTC)を境に水準が 14.85から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→21→23→23→24→24→24→21→22
* 開始   : 2026-07-31 13:10:00 (UTC)
* 終了   : 2026-07-31 13:55:00 (UTC)
* 現象   : 2026-07-31 13:55:00 (UTC)を境に水準が 14.95から12.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.752, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→24→18→21→24→18→21→19
* 開始   : 2026-07-31 14:25:00 (UTC)
* 終了   : 2026-07-31 14:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260731-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 20→17→16→20→17→16→20→19
* 開始   : 2026-07-31 15:20:00 (UTC)
* 終了   : 2026-07-31 15:25:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→15→12→13→13→14→13→13→12
* 開始   : 2026-07-31 19:05:00 (UTC)
* 終了   : 2026-07-31 20:00:00 (UTC)
* 現象   : 2026-07-31 20:00:00 (UTC)を境に水準が 14.9から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→14→10→14→10→13
* 開始   : 2026-07-31 19:30:00 (UTC)
* 終了   : 2026-07-31 19:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host15-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→14→9→10→14→9→10→11
* 開始   : 2026-07-31 20:30:00 (UTC)
* 終了   : 2026-07-31 20:35:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260731-host15-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host15-019 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→7→8→7→9→8→9→11→9
* 開始   : 2026-07-31 23:15:00 (UTC)
* 終了   : 2026-08-01 00:05:00 (UTC)
* 現象   : 2026-08-01 00:05:00 (UTC)を境に水準が 14.91から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host15-019 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
